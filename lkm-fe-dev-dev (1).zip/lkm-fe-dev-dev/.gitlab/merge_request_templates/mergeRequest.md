1. [ ] Pull lastest code and resolve all conflicts before creating a pull request.
2. [ ] Fix all warning problems from Code Spell Checker Extension in VSCode.
3. [ ] Remove all console.log.
4. [ ] Fix all warning and errror problems in terminal or by running any specific command.
5. [ ] Are the variables and files well named and follow to rule of the base project?
6. [ ] Not using fixed text => useTranslate
7. [ ] Using common components
8. [ ] Is UI 100% matched with Figma design?
9. [ ] Is follow SK checklist?
