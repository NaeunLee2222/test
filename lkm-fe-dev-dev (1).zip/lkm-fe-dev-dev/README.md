# LKM-FE

# 📝 Commit Message Rule | 커밋 메시지 작성 규칙

팀원들은 아래 템플릿을 따라 커밋 메시지를 작성해 주세요.  
가능한 경우 관련 이슈 번호도 함께 명시해 주세요.  
Please follow the template below when writing commit messages.  
If possible, include the related issue number.

---

## ✅ Commit Format | 커밋 형식

전체 커밋 메시지는 다음과 같은 구조로 작성합니다:  
Write your commit message in the format below:

```txt
<type>#<issue number>: <one-line summary>

- Briefly list changes, reasons, or implementation details
- You may write multiple lines if needed
```

이슈 번호가 없다면 `#<issue number>`는 생략 가능합니다.  
If there’s no related issue, you may omit the `#<issue number>` part.

---

## ✅ Commit Types | 커밋 타입 종류

| Type       | 설명                           | Description                               |
| ---------- | ------------------------------ | ----------------------------------------- |
| `feat`     | 새로운 기능 추가               | Add a new feature                         |
| `fix`      | 버그 수정                      | Fix a bug                                 |
| `docs`     | 문서 변경 (예: README)         | Documentation changes                     |
| `refactor` | 리팩토링 (기능 변화 없음)      | Code refactoring (no functional changes)  |
| `test`     | 임시 테스트 (배포환경 확인 등) | Temporary test (e.g. for deployment)      |
| `chore`    | 설정, 의존성 등 기능 외 작업   | Non-feature tasks (configs, dependencies) |

---

## ✅ Commit Examples | 커밋 예시

```txt
feat#124: 회원가입 화면 추가
- 신규 사용자 가입 시 이메일 중복 확인 포함
- 디자인 가이드를 반영한 입력 폼 스타일 적용

fix#125: 로그인 실패 시 오류 메시지 출력
- 서버 응답 코드 401 처리 로직 추가
- 사용자에게 alert 메시지 표시

chore: 프로젝트 초기 설정 파일 정리
- ESLint, Prettier 설정 파일 추가
- .gitignore 업데이트

feat#124: Add sign-up screen
- Added email duplication check for new users
- Applied input form styling based on design guide

fix#125: Display error message on login failure
- Added logic to handle 401 response code from server
- Show alert message to the user on failure

chore: Clean up initial project setup
- Added ESLint and Prettier configuration files
- Updated .gitignore with standard entries
```

---

## 🔀 Git Workflow Rules | Git 워크플로우 규칙

팀 전체의 일관된 협업을 위해 다음 Git 사용 규칙을 준수해 주세요.  
Follow these Git usage rules to ensure consistent collaboration across the team.

---

### ✅ Merge Strategy | 머지 전략

- Merge commit은 가급적 배포 브랜치(`dev`, `stg`, `prd`)의 Pull Request에서만 생성합니다.  
  Merge commits should be created only through PRs to deployment branches (`dev`, `stg`, `prd`).

- Fork된 repo에서는 반드시 `rebase & merge` 또는 `squash & merge`를 사용합니다.  
  In forked repositories, always use `rebase & merge` or `squash & merge`.

---

### ✅ Rebase Policy | 리베이스 규칙

- 개발자는 커밋을 푸시하기 전에 머지 대상 브랜치(`Ver1.0.0~`, `dev`) 기준으로 rebase 하여 conflict를 미리 해결해야 합니다.  
  Before pushing, developers must rebase onto the target branch (e.g. `Ver1.0.0~`, `dev`) to resolve conflicts in advance.

- ⚠️ 로컬에서 merge commit이 절대 생성되지 않도록 합니다.  
  ⚠️ Never allow merge commits to be created locally.

---

### ✅ Branch Base Rule | 브랜치 기준

- 모든 개발 브랜치는 항상 최신 배포 커밋을 기준(base)으로 만들어야 합니다.  
  All feature branches must be based on the latest deployed commit.

- 개발자들은 주기적으로 `git fetch`로 원격 저장소와 동기화해야 합니다.  
  Developers should regularly run `git fetch` to stay up to date.

---

### ✅ Commit Rule | 커밋 기준

- 모든 커밋은 반드시 정상 동작하는 상태여야 합니다.  
   All commits must result in working, functional code.

---

# 📦 Pull Request Rules (PR 규칙)

팀원들은 아래 PR 작성 규칙을 따라 주세요.
Please follow the rules below when creating a Pull Request.

---

## 📝 제목 & 설명 작성 규칙

**제목 (Title)**  
한 줄로 변경된 핵심 내용을 요약합니다.

**설명 (Description)**  
다음 항목들을 포함해 주세요:

- 포함된 커밋들의 제목 나열
- 관련된 이슈 번호 (e.g., `Closes #123`)
- 특이사항이나 참고사항

**Title**  
Summarize the main change in a single line.

**Description**  
Please include the following:

- List of included commit messages
- Related issue numbers (e.g., `Closes #123`)
- Any special notes or considerations

---

## ✅ PR 요청 전 체크리스트

- [ ] 포함된 모든 커밋이 커밋 메시지 규칙을 따랐는가?
- [ ] 최신 base branch로 rebase 했는가?
- [ ] 충돌(conflict)이 없는가?
- [ ] 로컬에서 기능 테스트 완료했는가?

**Checklist Before Requesting PR**

- [ ] Do all included commits follow the commit message rules?
- [ ] Did you rebase to the latest base branch?
- [ ] Are there no conflicts?
- [ ] Did you test the functionality locally?

---

## 🚫 금지사항

- ❌ 리베이스하지 않은 오래된 브랜치에서 PR 생성 금지
- ❌ 불필요한 파일(patch, temp, log 등)을 포함하지 않기

**Do Not**

- ❌ Don’t create PRs from outdated branches without rebasing
- ❌ Don’t include unnecessary files such as patch/temp/logs

---

## 💡 참고사항

- 커밋 제목에 `ESC_BUILD`를 포함하면 빌드 및 배포가 자동으로 스킵됩니다.

**Note**

- If the commit message contains `ESC_BUILD`, build and deployment will be skipped automatically.

---

---

---

---

- [tax frontend](#tax-frontend)
  - [개요](#개요)
  - [로컬 세팅 및 서버 배포](#로컬-세팅-및-서버-배포)
    - [로컬](#로컬)
    - [서버 배포](#서버-배포)
  - [폴더구조](#폴더구조)
    - [전체 폴더구조](#전체-폴더구조)
    - [모듈별 폴더구조](#모듈별-폴더구조)
  - [Guide](#guide)
    - [\[동적 config\] dynamic config](#동적-config-dynamic-config)
    - [\[다국어\] i18n](#다국어-i18n)
    - [\[SVG Sprite\] Resolve Icon Blinking](#svg-sprite-resolve-icon-blinking)
    - [\[Typography\] 피그마와 같은 값으로 세팅됨](#typography-피그마와-같은-값으로-세팅됨)

## 개요

- 세무 프론트엔드

## 로컬 세팅 및 서버 배포

### 로컬

- cmd로 실행

  ```sh
  # pnpm 설치
  npm i -g pnpm

  # pnpm 설치 후
  pnpm i
  pnpm dev
  ```

````

- vscode launch로 실행: tax-frontend 실행
- extensions.json에 있는 플러그인 설치
- 기본 포매터: prettier-vscode - 저장시 자동 포매팅하도록 세팅하여 사용
- 크롬 Dev tools에 react dev tools 추가하는 것을 추천

### 서버 배포

도커 이미지로 배포

```sh
docker build -t {docker_registry_name}/{docker_repository_name}:{tag} .
docker push {docker_registry_name}/{docker_repository_name}:{tag}
```

## 폴더구조

### 전체 폴더구조

```
.
├── deploy-config		# 배포 관련 설정
├── k8s				# k8s deploy/config map/service 설정
├── out				# sprite svg 하고 나면 생성됨 - gitignore
├── public			# public으로 노출될 파일들 - cache busting 미대상
│   └── dummy-images
├── src
│   ├── assets			# image/icon 요소들 - cache busting 대상
│   │   ├── basic-icons		# 기본 아이콘
│   │   ├── chart-icons		# 차트 아이콘
│   │   ├── direction-icons	# 방향 아이콘
│   │   ├── file-icons		# 파일 아이콘
│   │   ├── fonts
│   │   ├── images
│   │   ├── sprite-icons	# sprite할 icon 대상
│   │   └── videos		# 보고서 튜토리얼 영상 +a
│   ├── modules			# 기능별로 폴더 분리
│   │   ├── admin
│   │   ├── chat
│   │   ├── core		# 공통적으로 사용되는 부분 (레이아웃, 사용자 정보 등)
│   │   ├── i18n		# 다국어 세팅
│   │   └── report
│   ├── routers			# 라우터 세팅
│   ├── styles			# 전역 스타일
│   ├── types			# 전역 타입
│   └── utils			# 전역 유틸 함수
└── test			# 테스팅 세팅 파일 - AGS 관리용으로 현재는 미사용
```

### 모듈별 폴더구조

```
.
├── api				# 서버 호출부
├── components			# 컴포넌트
├── contexts			# context-provider 로 사용되는 부분
├── hooks			# 컴포넌트에서 사용하는 훅
├── jotai			# 모듈에서 사용하는 jotai 상태
├── layout			# 레이아웃 (core에만 있음)
├── pages			# 페이지
└── types			# 모듈에서 사용되는 타입
```

## Guide

### [동적 config] dynamic config

- .env를 사용하면 env 값이 바뀌는 경우 매번 프론드엔드 빌드를 다시 해야하는 고충이 있어 `<br/>`
  k8s/docker의 env 변경 후 container restart하여 환경변수값 변경할 수 있도록 구성함
- custom-config.json 환경변수 필요시 아래 위치 json에 값 추가 **필요**
  - public/custom-config.json
    - 로컬 개발시 필요한 변수 추가
    - 서버에서는 configmap에 있는 변수 받아옴
  - deploy-config/custom-config.json.template
    - docker build시 필요한 변수 VARIABLE: "$VARIABLE" 형태로 추가

### [다국어] i18n

- modules/i18n 하위에서 작업
- namespace는 common을 default로 사용

### [SVG Sprite] Resolve Icon Blinking

- sprite svg icons and download it once in page `<br/>`
  아이콘을 sprite svg 로 만들어 페이지에서 한번만 다운로드하면 되도록 설정 (캐싱 역할)
- gnb, logo, colored icons
- how to
  1. install svg-sprite globally
     `npm install svg-sprite -g `
  2. sprite icons in sprite-icons directory

     ```
     svg-sprite -D out --c sprite.svg --cscss  --css-render-scss-template  src/assets/sprite-icons/sprite-template.scss src/assets/sprite-icons/*.svg
     ```

  3. move out/css/svg/sprite\*.svg under public directory (asterisk is random variable)
  4. move out/css/sprite.scss under src/styles/sprite.scss
  5. change code of sprite.scss

     ```
     /* before */
     url("svg/sprite*.svg")

     /* after */
     background: url('/sprite*.svg') no-repeat;
     ```

  6. change VITE_SPRITE_SVG_PATH of .env

### [Typography] 피그마와 같은 값으로 세팅됨

- when using scss
  - import mixin.scss and using pre-defined font mixin variable
  - ref `src/styles/typo.scss`

  ```scss
  @use '@/styles/typo.scss' as *;

  .someClass {
    @include body04Medium;
  }
  ```

- when using mui sx
  - using pre-defined mui typography
  - it's defined in `src/modules/core/layout/Theme/ThemeVariable.tsx`

  ```js
  sx: {
    typography: 'caption02Regular',
    color: '#fff',
  },
  ```
````
