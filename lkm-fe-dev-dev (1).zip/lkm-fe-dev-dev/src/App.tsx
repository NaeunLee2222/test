import Providers from '@/modules/core/contexts';
import { i18nInitialize } from '@/modules/i18n/config';
import AppRoutes from '@/routers/AppRoutes';
import { StrictMode } from 'react';
import { useAxiosInterceptor } from './modules/core/hooks';

import '@/styles/index.scss';
import '@mdxeditor/editor/style.css';
import 'katex/dist/katex.min.css';
import { LayoutRouteGuard } from './routers/LayoutRouteGuard';

i18nInitialize();

const App = () => {
  useAxiosInterceptor();
  return (
    <StrictMode>
      <Providers>
        <LayoutRouteGuard />
        <AppRoutes />
      </Providers>
    </StrictMode>
  );
};

export default App;
