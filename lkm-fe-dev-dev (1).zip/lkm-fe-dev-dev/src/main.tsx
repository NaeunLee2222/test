import { QueryClientProvider } from '@/modules/core/contexts/QueryClientProvider';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root') as any);

// FETCH BASE
const { fetch: originalFetch } = window;
window.fetch = async (...args) => {
  const [resource, config] = args;
  const headers: any = config?.headers;
  let response = new Response();
  if (headers && localStorage.token) headers.Authorization = localStorage.token;
  try {
    response = await originalFetch(resource, config);
    // if (response.status === 401) {
    //   clearLocalStorageWithoutNecessary();
    //   window.location.href = '/login';
    // }
    return response;
  } catch (e: any) {
    console.error(e);
    throw e;
  }
};

const renderApp = () => {
  root.render(
    <QueryClientProvider>
      <BrowserRouter
        basename={import.meta.env.VITE_BASE_ROUTE}
        future={{
          v7_relativeSplatPath: false,
          v7_startTransition: false,
        }}
      >
        <App />
      </BrowserRouter>
    </QueryClientProvider>
  );
};

renderApp();
