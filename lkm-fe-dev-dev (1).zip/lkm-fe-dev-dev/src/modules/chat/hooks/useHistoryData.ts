import { IHistoryResponse } from '@/modules/chat/types/history';
import { useUserMe } from '@/modules/core/hooks';
import { Atom, atom } from 'jotai';
import {
  atomWithInfiniteQuery,
  atomWithMutation,
  queryClientAtom,
} from 'jotai-tanstack-query';
import {
  deleteAllHistory,
  deleteHistoryById,
  getHistoryList,
  patchHistoryTitle,
} from '../api/history';

const HISTORY_DATA_KEY = ['history'];
const LIBRARY_DATA_KEY = ['citation'];

export interface IHistorySearch {
  search: string;
  libraryId: number;
  includeContent?: boolean;
  limit?: number;
}

export const getHistoryDataAtom = (
  searchDataAtom: Atom<IHistorySearch>,
  enable: boolean = true
) =>
  atomWithInfiniteQuery((get) => ({
    queryKey: [
      ...HISTORY_DATA_KEY,
      get(useUserMe)?.data?.user_id,
      get(searchDataAtom)?.search,
      get(searchDataAtom)?.libraryId,
      get(searchDataAtom)?.includeContent,
      get(searchDataAtom)?.limit,
    ],
    queryFn: async ({ pageParam }: any) => {
      const response: IHistoryResponse = await getHistoryList(
        pageParam,
        get(searchDataAtom)?.search,
        get(searchDataAtom)?.libraryId,
        get(searchDataAtom)?.includeContent,
        get(searchDataAtom)?.limit
      );
      const total = response?.total_count || 0;
      const nextOffset = response?.next_offset || 0;
      return {
        historyList:
          response?.history_list?.map((history) => ({
            id: history.id,
            title: history.title,
            content: history?.content || '',
            createdAt: history.create_dt,
            updatedAt: history.update_dt,
          })) || [],
        total,
        nextOffset,
      };
    },
    getNextPageParam: (lastPage: any) =>
      lastPage?.nextOffset < lastPage?.total ? lastPage?.nextOffset : undefined,
    initialPageParam: 0,
    staleTime: 60 * 60 * 1000,
    enabled: enable,
    select: (data: any) => {
      const historyList =
        data.pages?.flatMap((page: any) => page.historyList) || [];
      return {
        pages: historyList,
        pageParams: [...data.pageParams].reverse(),
      };
    },
  }));

export const setHistoryDataAtom = atom(null, (get, _set) => {
  const queryClient = get(queryClientAtom);
  queryClient.invalidateQueries({ queryKey: HISTORY_DATA_KEY });
  queryClient.invalidateQueries({
    queryKey: LIBRARY_DATA_KEY,
    exact: false,
    refetchType: 'all',
  });
});

export const updateHistoryTitleAtom = atomWithMutation(() => ({
  mutationKey: [...HISTORY_DATA_KEY, 'update'],
  mutationFn: async ({ id, title }: { id: number; title: string }) =>
    patchHistoryTitle(id, title),
}));

export const deleteHistoryByIdAtom = atomWithMutation((get) => ({
  mutationKey: [...HISTORY_DATA_KEY, 'delete'],
  mutationFn: async ({ id }: { id: number }) => deleteHistoryById(id),
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: HISTORY_DATA_KEY });
  },
}));

export const deleteAllHistoryAtom = atomWithMutation((get) => ({
  mutationKey: [...HISTORY_DATA_KEY, 'deleteAll'],
  mutationFn: async ({ type }: { type: 'all' | 'no_library' }) =>
    deleteAllHistory(type),
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: HISTORY_DATA_KEY });
  },
}));
