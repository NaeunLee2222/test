import { layoutDataAtom } from '@/modules/core/jotai/layout';
import { IChatBubbleType } from '@/types/layout';
import { useAtom } from 'jotai';
import { chatDataAtom } from '../jotai/chat';
import { citationDataAtom } from '../jotai/citation';
import { ICitation } from '../types/message';

export const useChatCitationHandler = () => {
  const [, setLayoutData] = useAtom(layoutDataAtom);
  const [chatData] = useAtom(chatDataAtom);
  const [, setCitationData] = useAtom(citationDataAtom);

  const handleCitationClick = (
    messageUuid: string,
    bubbleType: IChatBubbleType,
    citation: ICitation
  ) => {
    setCitationData({
      ...citation,
      historyId: Number(chatData.historyId),
      messageUuid,
      bubbleType,
      company: chatData.userData?.company ?? '',
    });
    setLayoutData({
      type: 'partner',
      partnerImportFn: () =>
        import('@/modules/chat/components/ChatCitation/ChatCitation').then(
          (module) => ({
            default: module.ChatCitation,
          })
        ),
      detail: 'citation',
    });
  };

  return { handleCitationClick };
};
