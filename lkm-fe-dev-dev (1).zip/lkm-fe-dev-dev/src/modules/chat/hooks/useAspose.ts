import { atomWithMutation, queryClientAtom } from 'jotai-tanstack-query';
import { postHTMLToDOCX, postHTMLToPDF } from '../api/aspose';

export const useHTMLToPDF = atomWithMutation((get) => ({
  mutationKey: ['canvas'],
  mutationFn: async (id: string) => {
    const response = await postHTMLToPDF(id);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['canvas'] });
  },
}));

export const useHTMLToDOCX = atomWithMutation((get) => ({
  mutationKey: ['canvas'],
  mutationFn: async (id: string) => {
    const response = await postHTMLToDOCX(id);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['canvas'] });
  },
}));
