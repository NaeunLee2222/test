import { useUserMe } from '@/modules/core/hooks';
import { useCardData } from '@/modules/report/hooks/useCardData';
import { cardIdAtom } from '@/modules/report/jotai/card';
import type { IReportSectionListResponse } from '@/modules/report/types/section';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import {
  searchChatCitationData,
  searchReportCitationData,
  updateReportCitationData,
} from '../api/citation';
import { searchCitationAtom } from '../jotai/citation';

const CITATION_DATA_KEY = ['citation', 'search'];

export const useCitationSearchData = atomWithQuery((get) => ({
  queryKey: [...CITATION_DATA_KEY, get(searchCitationAtom)],
  queryFn: async ({
    queryKey: [, , { parentId, parentType, searchQuery }],
  }: any) => {
    if (!parentId || !parentType)
      return new Promise((resolve) => {
        resolve({ citations: [] });
      });

    if (parentType === 'report_section') {
      const cardId = get(cardIdAtom);
      if (!cardId || cardId === -1)
        return new Promise((resolve) => {
          resolve({ citations: [] });
        });
      return searchReportCitationData(cardId, parentId, searchQuery);
    }

    if (parentType === 'chat_message') {
      return searchChatCitationData(parentId, searchQuery);
    }
  },
  retry: 0,
  select: (data: any) =>
    data?.citations?.map((citation: any) => ({
      id: citation?.id,
      title: citation?.title,
      originalUrl: citation?.original_url,
      lawType: citation.law_type,
      content: citation?.content,
      configKey: citation?.config_key,
      isSelected: citation?.is_selected,
      isClientSelected: citation?.is_client_selected,
    })),
}));

export const mutateClientCitationSearchData = atomWithMutation((get) => ({
  mutationKey: [...CITATION_DATA_KEY, 'mutate'],
  mutationFn: async ({
    citationId,
    selected,
  }: {
    citationId: string;
    selected: boolean;
  }) =>
    new Promise((resolve) => {
      resolve({ citationId, selected });
    }),
  onSuccess: (_data, _variable: any) => {
    const queryClient = get(queryClientAtom);
    const queryKey = [...CITATION_DATA_KEY, get(searchCitationAtom)];
    queryClient.setQueryData(queryKey, (oldData: any) => {
      const citations = oldData?.citations || [];
      return {
        citations: citations.map((citation: any) => ({
          ...citation,
          is_client_selected:
            citation.id === _variable.citationId
              ? _variable.selected
              : citation.is_client_selected,
        })),
      };
    });
    queryClient.invalidateQueries({
      queryKey,
      exact: false,
      refetchType: 'none',
    });
  },
}));

const REPORT_SECTION_KEY = ['report', 'section'];
export const mutateCitationSearchData = atomWithMutation((get) => ({
  mutationKey: [...CITATION_DATA_KEY, 'mutate'],
  mutationFn: async () => {
    const cardId = get(cardIdAtom);
    const reportSectionId = get(searchCitationAtom)?.parentId;
    const citationSearchData = get(useCitationSearchData)?.data;
    const citationIdList = citationSearchData.reduce((acc: any, cur: any) => {
      if (cur.isSelected || cur.isClientSelected) {
        acc.push(cur.id);
      }
      return acc;
    }, []);
    return updateReportCitationData(cardId, reportSectionId, citationIdList);
  },
  onSuccess: (_data, _variable: any) => {
    const reportSectionId = get(searchCitationAtom)?.parentId;
    const citationSearchData = get(useCitationSearchData)?.data;
    const citationIdList = citationSearchData.reduce((acc: any, cur: any) => {
      if (cur.isSelected || cur.isClientSelected) {
        acc.push(cur.id);
      }
      return acc;
    }, []);
    const queryClient = get(queryClientAtom);

    const queryKey = [...CITATION_DATA_KEY, get(searchCitationAtom)];
    queryClient.setQueryData(queryKey, (oldData: any) => {
      const citations = oldData?.citations || [];
      return {
        citations: citations.map((citation: any) => ({
          ...citation,
          is_selected:
            citationIdList?.includes(citation.id) || !!citation?.is_selected,
          is_client_selected: false,
        })),
      };
    });
    queryClient.invalidateQueries({
      queryKey,
      exact: true,
      refetchType: 'none',
    });

    const sectionQueryKey = [
      ...REPORT_SECTION_KEY,
      get(useUserMe)?.data?.user_id,
      get(useCardData)?.data?.metadataId,
    ];
    queryClient.setQueryData(
      sectionQueryKey,
      (data: IReportSectionListResponse | null) => {
        const sectionList = data?.section_list || [];
        return {
          section_list: sectionList.map((section) => {
            if (`${section.id}` === reportSectionId)
              return {
                ...section,
                citation_id_list: [
                  ...new Set([
                    ...(section?.citation_id_list || []),
                    ...citationIdList,
                  ]),
                ],
              };
            return section;
          }),
        };
      }
    );
    queryClient.invalidateQueries({
      queryKey: sectionQueryKey,
      exact: true,
      refetchType: 'none',
    });
  },
}));
