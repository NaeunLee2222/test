import { IFeedback } from '@/modules/chat/types/feedback';
import { useAtom } from 'jotai';
import { updateChatFeedback } from '../api/feedback';
import { chatDataAtom } from '../jotai/chat';
import { feedbackDialogDataAtom } from '../jotai/feedback';

export const useChatFeedbackHandler = () => {
  const [chatData, setChatData] = useAtom(chatDataAtom);
  const [feedbackDialogData, setFeedbackDialogData] = useAtom(
    feedbackDialogDataAtom
  );

  const updateFeedback = async (message_uuid: string, feedback: IFeedback) => {
    if (!chatData.historyId || !message_uuid) return;
    await updateChatFeedback(
      Number(chatData.historyId),
      message_uuid,
      feedback
    );
    const { messages } = chatData;
    messages[message_uuid] = {
      ...messages[message_uuid],
      feedback: {
        flag: feedback.flag,
        comment: feedback.comment,
      },
    };
    setChatData({
      ...chatData,
      messages,
    });
    setFeedbackDialogData({
      open: false,
      message_uuid: '',
      feedback: {},
      bubbleType: feedbackDialogData.bubbleType,
    });
  };

  return {
    updateFeedback,
  };
};
