import { ILibrary, ILibraryListResponse } from '@/modules/chat/types/history';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import {
  createLibrary,
  deleteLibrary,
  getLibraryList,
  updateLibrary,
} from '../api/library';

const HISTORY_DATA_KEY = ['history'];
const LIBRARY_DATA_KEY = ['citation'];

export const useLibraryData = atomWithQuery((_get) => ({
  queryKey: [...LIBRARY_DATA_KEY],
  queryFn: getLibraryList,
  select: (data: ILibraryListResponse) => {
    const libraryList: ILibrary[] = data?.library_list?.map((library) => ({
      id: library.id,
      title: library.title,
      createdAt: library.create_dt,
      updatedAt: library.update_dt,
      historyIdList: library.history_id_list?.map(Number),
    }));
    return {
      libraryList,
    };
  },
}));

export const createLibraryAtom = atomWithMutation((get) => ({
  mutationKey: [...LIBRARY_DATA_KEY, 'create'],
  mutationFn: async ({
    title,
    historyIdList,
  }: {
    title: string;
    historyIdList?: number[];
  }) => createLibrary(title, historyIdList),
  onMutate: () => {
    const queryClient = get(queryClientAtom);
    queryClient.setQueryData(LIBRARY_DATA_KEY, (data: any) => ({
      ...data,
      library_list: [
        {
          id: -1,
          title: '',
          createdAt: '',
          updatedAt: '',
          historyIdList: [],
        },
        ...data.library_list,
      ],
    }));
    queryClient.invalidateQueries({
      queryKey: LIBRARY_DATA_KEY,
      refetchType: 'none',
    });
  },
  onSuccess: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: LIBRARY_DATA_KEY });
    queryClient.invalidateQueries({ queryKey: HISTORY_DATA_KEY, exact: false });
  },
}));

export const updateLibraryAtom = atomWithMutation((get) => ({
  mutationKey: [...LIBRARY_DATA_KEY, 'update'],
  mutationFn: async ({
    id,
    title,
    addHistoryIdList,
    delHistoryIdList,
  }: {
    id: number;
    title?: string;
    addHistoryIdList?: number[];
    delHistoryIdList?: number[];
  }) => {
    await updateLibrary(id, title, addHistoryIdList, delHistoryIdList);
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: LIBRARY_DATA_KEY });
    queryClient.invalidateQueries({
      queryKey: HISTORY_DATA_KEY,
      exact: false,
      refetchType: 'active',
    });
  },
}));

export const deleteLibraryAtom = atomWithMutation((get) => ({
  mutationKey: [...LIBRARY_DATA_KEY, 'delete'],
  mutationFn: async ({ id }: { id: number }) => {
    await deleteLibrary(id);
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: LIBRARY_DATA_KEY });
    queryClient.invalidateQueries({ queryKey: HISTORY_DATA_KEY, exact: false });
  },
}));
