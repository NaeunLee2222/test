import useWindowSizeCustom from '@/modules/core/hooks/useWindowSizeHandler';
import { useAtom, useAtomValue } from 'jotai';
import { type UIEventHandler, useCallback, useEffect } from 'react';
import { isGeneratingAtom, messagesAtom } from '../jotai/chat';
import {
  chatScrollDataAtom,
  messagesEndRefAtom,
  messagesStartRefAtom,
  scrollContentRefAtom,
} from '../jotai/scroll';

export const useChatScrollHandler = () => {
  const isGenerating = useAtomValue(isGeneratingAtom);
  const messagesData = useAtomValue(messagesAtom);

  const [chatScrollData, setChatScrollData] = useAtom(chatScrollDataAtom);

  const messagesStartRef = useAtomValue(messagesStartRefAtom);
  const messagesEndRef = useAtomValue(messagesEndRefAtom);
  const scrollContentRef = useAtomValue(scrollContentRefAtom);

  useEffect(() => {
    setChatScrollData({ userScrolled: false });
    if (!isGenerating && chatScrollData.userScrolled) {
      setChatScrollData({ userScrolled: false });
    }
  }, [isGenerating]);

  useEffect(() => {
    if (isGenerating && !chatScrollData.userScrolled) {
      scrollToBottom();
    }
  }, [messagesData]);

  const { width, height } = useWindowSizeCustom();

  useEffect(() => {
    if (scrollContentRef.current) {
      const scrolledHeight =
        Math.floor(scrollContentRef.current.scrollHeight) -
        Math.floor(scrollContentRef.current.scrollTop);
      const bottom =
        scrolledHeight <=
          Math.floor(scrollContentRef.current.clientHeight) + 1 &&
        scrolledHeight >= Math.floor(scrollContentRef.current.clientHeight) - 1;
      setChatScrollData({ isAtBottom: bottom });
    }
  }, [width, height]);

  const handleScroll: UIEventHandler<HTMLDivElement> = useCallback((e) => {
    const target = e.target as HTMLDivElement;

    const scrolledHeight =
      Math.floor(target.scrollHeight) - Math.floor(target.scrollTop);
    const bottom =
      scrolledHeight <= Math.floor(target.clientHeight) + 1 &&
      scrolledHeight >= Math.floor(target.clientHeight) - 1;
    setChatScrollData({ isAtBottom: bottom });

    const top = target.scrollTop === 0;
    setChatScrollData({ isAtTop: top });

    if (!bottom && !chatScrollData.isAutoScrolling) {
      setChatScrollData({ userScrolled: true });
    } else {
      setChatScrollData({ userScrolled: false });
    }

    const isOverflow = target.scrollHeight > target.clientHeight;
    setChatScrollData({ isOverflowing: isOverflow });
  }, []);

  const scrollToTop = useCallback(() => {
    if (messagesStartRef.current) {
      messagesStartRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  const scrollToBottom = useCallback(() => {
    setChatScrollData({ isAutoScrolling: true });

    setTimeout(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({
          behavior: 'smooth',
          block: 'end',
        });
      }

      setChatScrollData({ isAutoScrolling: false });
    }, 100);
  }, []);

  return {
    chatScrollData,
    messagesStartRef,
    messagesEndRef,
    scrollContentRef,
    handleScroll,
    scrollToTop,
    scrollToBottom,
  };
};
