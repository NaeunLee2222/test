import { IHistoryCitation } from '@/modules/chat/types/history';
import { ICitation, IMessage } from '@/modules/chat/types/message';
import { initLayoutDataAtom } from '@/modules/core/jotai/layout';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { useCallback, useState } from 'react';
import { getChatMsgById, rebuildThinkingFromMessage } from '../api/chat';
import {
  abortDataAtom,
  chatDataAtom,
  currentMessagesAtom,
} from '../jotai/chat';
import {
  canvasAtom,
  canvasAtoms,
  detailCanvas,
  newPlanAtoms,
} from '../jotai/chatprocessing';

import { graphDataAtom } from '../jotai/graph';
import { useChatHistory } from './useChat';

export const citationToICitation = (citation: IHistoryCitation): ICitation => ({
  ...citation,
  lawType: citation.law_type,
  indexInMessage: citation?.config?.index_in_message,
  isReferencedInAnswer: citation?.config?.is_referenced_in_answer,
});

export const useChatDataHandler = () => {
  const [chatData, setChatData] = useAtom(chatDataAtom);
  const setCurrentMessagesAtom = useSetAtom(currentMessagesAtom);
  const initLayoutData = useSetAtom(initLayoutDataAtom);
  const setPlanAtoms = useSetAtom(newPlanAtoms);
  const setAbortData = useSetAtom(abortDataAtom);
  const setCanvases = useSetAtom(canvasAtoms);
  const setCanvasDetail = useSetAtom(detailCanvas);
  const setCanvas = useSetAtom(canvasAtom);
  const { data: chatHistoryData } = useAtomValue(useChatHistory);
  const setGraphData = useSetAtom(graphDataAtom);

  // 채팅 데이터 세팅
  const setChatDataByHistory = async (historyId: number | string) => {
    if (
      chatData.isGenerating &&
      (chatData.historyId === -1 || chatData.historyId === historyId)
    )
      return;

    try {
      setAbortData({
        key: `${historyId ?? -1}`,
        value: {
          abortController: new AbortController(),
          isAbort: false,
        },
      });

      const currentHistoryItem = (chatHistoryData?.chat_list ?? []).find(
        (item) => item.id === historyId
      );

      let savedData = {
        ...chatData,
      };

      if (!historyId) {
        savedData.historyId = -1;
      }

      if (historyId) {
        const data = await getChatMsgById(historyId.toString());
        (data ?? []).forEach((item) => {
          rebuildThinkingFromMessage(
            setPlanAtoms,
            item,
            setCanvases,
            setCanvasDetail,
            setCanvas,
            setGraphData
          );
        });
        const messages: {
          [key: string]: IMessage;
        } = {};
        data.forEach((item) => {
          messages[item.uuid] = item;
        });

        savedData = {
          ...chatData,
          historyId: historyId ?? -1,
          title: currentHistoryItem?.title ?? chatData.title ?? '',
          messages,
          userInput: '',
          isGenerating: false,
          selectedAgent:
            currentHistoryItem?.agent_id ?? chatData.selectedAgent ?? undefined,
        };
      }

      setChatData(savedData);
    } catch (error) {
      console.error({ error });

      initChatData();
    }
  };

  // 채팅 데이터 초기화
  const initChatData = useCallback(() => {
    setChatData({
      historyId: -1,
      messages: {},
      isGenerating: false,
      userInput: '',
      selectedAgent: undefined,
      selectedChatMode: undefined,
      title: '',
    });
    setCurrentMessagesAtom([]);
  }, [setChatData, setCurrentMessagesAtom]);

  const [isSetChatData, setIsSetChatData] = useState(false);

  return {
    chatData,
    setChatDataByHistory,
    initChatData,
    initLayoutData,
    isSetChatData,
    setIsSetChatData,
  };
};
