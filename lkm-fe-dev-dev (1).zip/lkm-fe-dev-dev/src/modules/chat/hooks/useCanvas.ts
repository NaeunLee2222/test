import { getCanvas, updateCanvas } from '@/modules/chat/api/canvas';
import { queryClient } from '@/modules/core/hooks';
import { atom } from 'jotai';
import { atomWithMutation, atomWithQuery } from 'jotai-tanstack-query';

import { listCanvasPaginationAtom } from '../jotai/canvas';
import {
  GetCanvasParams,
  ICanvasDetail,
  ICanvasDetailResponse,
  IGetCanvasResponse,
} from '../types/canvas';

const CANVAS_DATA_KEY = ['canvas'];
const CANVAS_KEY = ['canvas'];

export const currentVersionAtom = atom<number>(1);
export const isShowDiffAtom = atom<boolean>();

export const updateCanvasAtom = atomWithMutation((_get) => ({
  mutationKey: [CANVAS_DATA_KEY, 'update'],
  mutationFn: async ({
    content,
    version,
    canvasId,
    diff,
  }: {
    content: string;
    version: number;
    canvasId: string;
    diff: any;
  }) => updateCanvas(content, version, canvasId, diff),
}));

const returnedLibraryFetchObject = ({
  skip,
  limit,
  order,
  title,
  updated,
  userId,
  type,
}: GetCanvasParams & { userId: string | number }) => ({
  queryKey: [
    ...CANVAS_KEY,
    skip ?? 0,
    limit ?? 0,
    order ?? '',
    title ?? '',
    updated ?? 0,
    type ?? '',
  ],
  queryFn: async () =>
    limit
      ? getCanvas({
          skip,
          limit,
          order,
          title,
          userId,
          type,
        })
      : null,
  select: (data: IGetCanvasResponse | null) => {
    if (!data) return null;

    const canvases: ICanvasDetail[] = data.canvases?.map(
      (canvas: ICanvasDetailResponse) => ({
        ...canvas,
        chatId: canvas.chat_id,
        currentVersion: canvas.current_version,
        createdAt: canvas.created_at,
        updatedAt: canvas.updated_at,
        content: canvas.content,
      })
    );
    return {
      canvases,
    };
  },
  enabled: false,
});

export const useDisabledLibraryData = atomWithQuery((get) => {
  const { skip, limit, order, title, updated, userId, type } = get(
    listCanvasPaginationAtom
  );

  queryClient.invalidateQueries({
    queryKey: [
      ...CANVAS_KEY,
      skip ?? 0,
      limit ?? 0,
      order ?? '',
      title ?? '',
      updated ?? 0,
      type ?? '',
    ],
    exact: false,
  });

  return returnedLibraryFetchObject({
    skip,
    limit,
    order,
    title,
    updated,
    userId,
    type,
  });
});
