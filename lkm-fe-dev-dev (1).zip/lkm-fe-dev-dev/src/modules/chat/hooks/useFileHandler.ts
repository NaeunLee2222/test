import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import { getCloudFiles, onDeleteCloudFile, uploadFile } from '../api/files';

const FILE_DATA_KEY = 'file-data-upload';

export const uploadFileToCloudAtom = atomWithMutation((get) => ({
  mutationKey: [FILE_DATA_KEY, 'upload'],
  mutationFn: async ({
    files,
    userId,
  }: {
    files: File[];
    userId: string | number;
  }) => uploadFile({ files, userId }),
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({
      queryKey: [FILE_DATA_KEY, 'get-cloud-file'],
    });
  },
}));

export const getCloudFilesAtom = atomWithQuery(() => ({
  queryKey: [FILE_DATA_KEY, 'get-cloud-file'],
  queryFn: async () => getCloudFiles(),
  enabled: false,
}));

export const useFileDeleteAtom = atomWithMutation((get) => ({
  mutationKey: [FILE_DATA_KEY, 'delete'],
  mutationFn: async ({ file_id }: any) => {
    const response = await onDeleteCloudFile({ file_id });
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({
      queryKey: [FILE_DATA_KEY, 'get-cloud-file'],
    });
  },
}));
