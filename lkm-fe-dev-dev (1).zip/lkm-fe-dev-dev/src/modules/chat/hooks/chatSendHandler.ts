import {
  agentCanvasOpenAtom,
  slidePreviewOpenAtom,
} from '@/modules/agent/jotai/agent';
import {
  chatApi,
  createNewChat,
  createNewChatTitle,
  getChatMsgById,
} from '@/modules/chat/api/chat';
import { citationToICitation } from '@/modules/chat/hooks/chatDataHandler';
import { setHistoryDataAtom } from '@/modules/chat/hooks/useHistoryData';
import { mutateRecommendationDataAtom } from '@/modules/chat/hooks/useRecommendationData';
import {
  abortDataAtom,
  chatDataAtom,
  currentMessagesAtom,
  isCreatingChatAtom,
  isSecretModeAtom,
  messagesAtom,
  messagesOrderAtom,
  newChatCreated,
  selectedModelAtom,
  selectedToolAtom,
  showWorkflowReviewDocAtom,
} from '@/modules/chat/jotai/chat';
import {
  canvasAtom,
  canvasAtoms,
  detailCanvas,
  newPlanAtoms,
  workflowPlanAtom,
} from '@/modules/chat/jotai/chatprocessing';
import {
  ChatType,
  EChatMode,
  ERole,
  ISendMessage,
} from '@/modules/chat/types/chat';
import { EPlanType, EStatus } from '@/modules/chat/types/chatprocessing';
import {
  EMessageType,
  IMessage,
  IMessageRequest,
  IMessageResponse,
} from '@/modules/chat/types/message';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import {
  invalidateCostData,
  useCustomConfig,
  useUserMe,
} from '@/modules/core/hooks';
import { EChatType } from '@/modules/core/types';
import { RoutesURL } from '@/routers/routes';
import { ServiceType } from '@/types/router';
import { parseServiceError, ServiceError } from '@/utils/errorUtil';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { attachFileToChat } from '../api/files';
import { graphDataAtom } from '../jotai/graph';
import type { IUploadedFile } from '../types/files';

const AI_SLIDE_TYPE = 'ai_slide';

type Message = {
  uuid: string | number;
};

type MessageMap = {
  [uuid: string]: Message;
};

export const useChatSendHandler = () => {
  const [{ mutate: invalidateCost }] = useAtom(invalidateCostData);
  const [{ data: userData }] = useAtom(useUserMe);
  const [chatData, setChatData] = useAtom(chatDataAtom);
  const [messagesOrder, setMessagesOrder] = useAtom(messagesOrderAtom);
  const currentMessages = useAtomValue(currentMessagesAtom);
  const setMessagesData = useSetAtom(messagesAtom);
  const updateHistoryData = useSetAtom(setHistoryDataAtom);
  const setPlanAtoms = useSetAtom(newPlanAtoms);
  const setWorkflowPlan = useSetAtom(workflowPlanAtom);
  const [, setCanvas] = useAtom(canvasAtom);
  const setCanvases = useSetAtom(canvasAtoms);
  const setShowDoc = useSetAtom(showWorkflowReviewDocAtom);
  const selectedModel = useAtomValue(selectedModelAtom);
  const [{ mutateAsync: mutateRecommendation }] = useAtom(
    mutateRecommendationDataAtom
  );
  const { selectedFile2Upload, setSelectedFile2Upload } = useMainContext();
  const [abortData, setAbortData] = useAtom(abortDataAtom);
  const { data: config } = useCustomConfig();
  const [isSecretMode] = useAtom(isSecretModeAtom);
  const setIsCreatingChat = useSetAtom(isCreatingChatAtom);
  const selectedTool = useAtomValue(selectedToolAtom);
  const [, setGraphData] = useAtom(graphDataAtom);

  const historyIdRef = useRef<number | string | undefined>(undefined);
  const chatAgentRef = useRef<number | string | undefined>(undefined);
  const messagesRef = useRef<IMessage[]>([]);
  const userUuid = useRef<string | undefined>(undefined);
  const botUuid = useRef<string | undefined>(undefined);
  const lastMessageOrder = useRef<number[]>([]);
  const titleRef = useRef<string | undefined>(undefined);
  const isThinkingRef = useRef<boolean>(false);
  const stepIndexRef = useRef(0);
  const planIndexRef = useRef(0);
  const planIndexMapRef = useRef<{ [chatID: string]: number }>({}); // chatID별 planIndex 관리
  const actionIndexRef = useRef(0);
  const currentActionIdRef = useRef<string | null>(null);
  const currentStepIdRef = useRef<string | null>(null);
  const setCanvasDetail = useSetAtom(detailCanvas);
  const setAgentCanvasOpen = useSetAtom(agentCanvasOpenAtom);

  // 헬퍼 함수: chatID별 planIndex 초기화 및 반환
  const initializePlanIndex = (chatID: string): number => {
    if (!(chatID in planIndexMapRef.current)) {
      planIndexMapRef.current[chatID] = 0;
    }
    return planIndexMapRef.current[chatID];
  };
  const setSlidePreviewOpen = useSetAtom(slidePreviewOpenAtom);
  const setNewChatCreated = useSetAtom(newChatCreated);

  const navigate = useNavigate();

  /** 사용자 메시지 생성 */
  const createUserMessage = (message: string): string => {
    const parentUuid = messagesRef.current?.at(-1)?.uuid;
    const userId = uuidv4();
    const newUserMessage: IMessage = {
      role: ERole.USER,
      type: 'text',
      message,
      content: message,
      parentUuid,
      uuid: userId,
      createdAt: new Date().toISOString(),
    };
    userUuid.current = newUserMessage.uuid;
    messagesRef.current = [
      ...messagesRef.current.filter((item) => !!item),
      newUserMessage,
    ];

    return userId;
  };

  const setMessagesForSending = (_messages: IMessage[]): IMessageRequest[] =>
    _messages.map((message) => ({
      role: message.role,
      content_metadata: message.message,
      content: message.content,
      id: message.uuid,
      parent_id: message.parentUuid ?? null,
    }));

  const setLastUserMessageUuid = (userMessageIndex: number, uuid: string) => {
    messagesRef.current[userMessageIndex].uuid = uuid;
    userUuid.current = uuid;
  };

  /** 토큰 받으면서 마지막 ai 메시지의 data 세팅 */
  const setLastAiMessageData = (dataJson: IMessageResponse) => {
    const lastUserUuid = userUuid.current;
    const type = dataJson.type === 'loading' ? 'loading' : 'text';
    const lastMessageData =
      messagesRef.current[messagesRef.current.length - 1] || null;
    let newMessage = lastMessageData.message;

    const splitter =
      lastMessageData?.type === type && type === 'text' ? '' : '\n\n';
    newMessage += splitter + (dataJson.content ?? '').replaceAll('\\\\', '\\');

    if (!newMessage) return;
    const messageData: IMessage = {
      ...lastMessageData,
      parentUuid: lastUserUuid,
      uuid: dataJson.uuid,
      role: ERole.ASSISTANT,
      type,
      message: newMessage,
      createdAt: new Date().toISOString(),
    };
    messagesRef.current = [
      ...messagesRef.current.slice(0, messagesRef.current.length - 1),
      messageData,
    ];
  };

  /** citation, thought, recommendations값 세팅 */
  const setMessageSubData = (
    rawData: any,
    type: 'citations' | 'thought' | 'recommendations'
  ) => {
    const lastMessageData =
      messagesRef.current[messagesRef.current.length - 1] || null;
    if (!lastMessageData) return;
    let data = JSON.parse(rawData);
    if (type === 'citations') {
      data = citationToICitation(data);
    }

    const newData = type === 'recommendations' ? data : [data];

    if (type === 'recommendations') {
      mutateRecommendation({
        historyId: historyIdRef.current! as number,
        messageUuid: botUuid.current!,
        recommendations: newData,
      });
    } else if (!lastMessageData[type]) {
      lastMessageData[type] = newData;
    } else if (newData) {
      lastMessageData[type] = [...lastMessageData[type], ...newData];
    }
    messagesRef.current = [
      ...messagesRef.current.slice(0, messagesRef.current.length - 1),
      lastMessageData,
    ];
  };

  const setLabelData = (label: any) => {
    const lastMessageData =
      messagesRef.current[messagesRef.current.length - 1] || null;
    if (!lastMessageData) return;
    const labelData = JSON.parse(label);
    lastMessageData.config ??= { label: undefined };
    if (!lastMessageData.config?.label) {
      lastMessageData.config.label = labelData;
    } else {
      lastMessageData.config.label = [
        ...lastMessageData.config.label,
        ...labelData,
      ];
    }
    messagesRef.current = [
      ...messagesRef.current.slice(0, messagesRef.current.length - 1),
      lastMessageData,
    ];
  };

  /** 에러 메시지인 경우 현재까지 받은 데이터 기준으로 저장 */
  const setErrorMessages = async (error: any, _uuid = botUuid.current) => {
    const errMessage = parseServiceError(error);
    const lastMessageData =
      messagesRef.current[messagesRef.current.length - 1] || null;
    const messageData: IMessage = {
      ...lastMessageData,
      type: 'error',
      message: errMessage,
      uuid: _uuid ?? uuidv4(),
      createdAt: new Date().toISOString(),
    };
    messagesRef.current = [
      ...messagesRef.current.slice(0, messagesRef.current.length - 1),
      messageData,
    ];
    haltLoadingMessage();
  };

  /** 로딩 상태 중단 */
  const haltLoadingMessage = () => {
    const lastMessage = messagesRef.current[messagesRef.current.length - 1];
    if (lastMessage?.type !== 'loading') return;
    messagesRef.current = messagesRef.current.map((message) => ({
      ...message,
      type: message.type === 'loading' ? 'text' : message.type,
    }));
  };

  /** 메시지 중단 */
  const haltMessage = async (version?: string, isPro = true) => {
    haltLoadingMessage();
    if (botUuid.current) {
      if (messagesRef.current?.at(-1)?.role === ERole.ASSISTANT) {
        messagesRef.current[messagesRef.current.length - 1].uuid =
          botUuid.current;
        messagesRef.current[messagesRef.current.length - 1].type = 'text';
        messagesRef.current[messagesRef.current.length - 1].config = {
          isAborted: true,
          isPro,
          version,
        };
      }

      return true;
    }
    return false;
  };

  const checkIsAborted = (pathname = window.location.pathname) => {
    const isNotChatPage =
      !pathname.includes(ServiceType.CHAT) &&
      !pathname.includes(ServiceType.WORKFLOW_REVIEW) &&
      !pathname.includes(RoutesURL.AGENT_CREATE) &&
      !pathname.includes(RoutesURL.GENERAL_AGENT);

    const isAbort =
      (historyIdRef.current && abortData?.[historyIdRef.current]?.isAbort) ||
      isNotChatPage;
    if (isAbort && historyIdRef.current)
      abortData?.[historyIdRef.current]?.abortController?.abort();
    return isAbort;
  };

  const animationRef = useRef<any>(null);
  useEffect(
    () => () =>
      animationRef.current && cancelAnimationFrame(animationRef.current),
    []
  );

  const switchCaseHandler = ({ dataJson, userMessageIndex }: any) => {
    const { type, content, id, description, key, title } = dataJson;
    const errorData = isJsonString(dataJson.content)
      ? JSON.parse(dataJson.content)
      : dataJson.data;

    switch (type) {
      case 'id':
      case 'ID': {
        setLastAiMessageData({
          ...dataJson,
          type: 'loading',
          uuid: botUuid.current,
        });
        const chatID = id;
        if (!chatID) break;

        initializePlanIndex(chatID); // planIndex 초기화

        setPlanAtoms((prev) => ({
          ...prev,
          [chatID]: {
            plans: [],
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          },
        }));

        break;
      }

      case 'PLAN_START':
      case 'plan_start': {
        const chatID = id;
        if (!chatID) break;

        // chatID별 planIndex 초기화
        if (!(chatID in planIndexMapRef.current)) {
          planIndexMapRef.current[chatID] = 0;
        }

        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID] ?? {
            plans: {},
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          };
          const currentPlans = { ...prevChat.plans };
          const prevPlanId = `${id}-plan-${planIndexMapRef.current[chatID]}`;
          const prevPlan = currentPlans[prevPlanId];
          const planIndex = planIndexMapRef.current[chatID] + 1;
          const planId = `${id}-plan-${planIndex}`;
          const plan = currentPlans[planId];
          stepIndexRef.current = 0;
          if (prevPlanId && currentPlans[prevPlanId]) {
            currentPlans[prevPlanId] = {
              ...prevPlan,
              status: EStatus.SUCCESS,
            };
          }

          planIndexMapRef.current[chatID] = planIndex;

          currentPlans[planId] = {
            ...plan,
            id: planId,
            name: content.trim(),
            status: EStatus.INCOMPLETE,
            type: EPlanType.STEP_PLAN,
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        break;
      }

      case 'title': {
        // chatID별 planIndex 초기화
        if (!(id in planIndexMapRef.current)) {
          planIndexMapRef.current[id] = 0;
        }
        const prevPlanId = `${id}-plan-${planIndexMapRef.current[id]}`;
        setCanvases((prev) => ({
          ...prev,
          [prevPlanId]: {
            canvas: {
              ...prev.canvas,
              title: content,
              htmlContent: prev[prevPlanId]?.canvas?.htmlContent || '',
              end: false,
              isNavigate: true,
            },
            slide: {
              ...prev.slide,
              title: content,
              htmlContent: [...(prev[prevPlanId]?.slide?.htmlContent || [])],
              isNavigate: true,
            },
            sheet: {
              ...prev.sheet,
              title: content,
              end: false,
              htmlContent: [...(prev[prevPlanId]?.sheet?.htmlContent || '')],
              isNavigate: true,
            },
          },

          originalCanvas: content,
        }));
        break;
      }

      case 'AI_SLIDE':
      case 'ai_slide': {
        const htmlContent: any = {
          slide: { htmlContent: [], title: '' },
        };
        // chatID별 planIndex 초기화
        if (!(id in planIndexMapRef.current)) {
          planIndexMapRef.current[id] = 0;
        }
        const planIndex = planIndexMapRef.current[id] + 1;
        const planId = `${id}-plan-${planIndex}`;
        planIndexMapRef.current[id] = planIndex;

        setPlanAtoms((prev: any) => {
          const prevChat = prev[id] ?? {
            plans: {},
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          };
          const currentPlans = { ...prevChat.plans };

          currentPlans[planId] = {
            id: planId,
            name: '',
            status: EStatus.SUCCESS,
            type: EPlanType.SLIDE,
            canvas: {
              slide: {
                ...htmlContent.slide,
                htmlContent: Array.from(
                  new Set([...(htmlContent?.slide?.htmlContent ?? []), content])
                ),
                title,
                id: key,
                isNavigate: true,
                end: true,
                parentId: planId,
              },
            },
          };

          return {
            ...prev,
            [id]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        setCanvases((prev) => {
          // 각 슬라이드가 독립적인 데이터를 갖도록 초기화
          const initialSlideData = {
            slide: { htmlContent: [], title: '', isNavigate: true, end: false },
          };

          const existingSlideData = prev[planId] ?? initialSlideData;

          return {
            ...prev,
            [planId]: {
              ...existingSlideData,
              slide: {
                ...existingSlideData.slide,
                htmlContent: Array.from(
                  new Set([
                    ...(existingSlideData?.slide?.htmlContent ?? []),
                    content,
                  ])
                ),
                title,
                id: key,
                isNavigate: true,
                end: true,
                parentId: planId,
              },
            },
          };
        });

        // 첫 번째 슬라이드인 경우에만 setCanvasDetail 호출
        if (planIndex === 1) {
          setCanvasDetail(planId);
        }
        setCanvas(htmlContent);
        setSlidePreviewOpen(false);
        break;
      }

      case 'ai_sheet':
      case 'AI_SHEET': {
        const htmlContent: any = {
          sheet: { htmlContent: '', end: false, title: '' },
        };

        const chatID = id;
        if (!chatID) break;

        // chatID별 planIndex 초기화
        if (!(chatID in planIndexMapRef.current)) {
          planIndexMapRef.current[chatID] = 0;
        }

        const planIndex = planIndexMapRef.current[chatID] + 1;
        const planId = `${id}-plan-${planIndex}`;
        planIndexMapRef.current[chatID] = planIndex;

        setPlanAtoms((prev: any) => {
          const prevChat = prev[id] ?? {
            plans: {},
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          };
          const currentPlans = { ...prevChat.plans };

          currentPlans[planId] = {
            id: planId,
            name: '',
            status: EStatus.SUCCESS,
            type: EPlanType.SHEET,
            canvas: {
              sheet: {
                htmlContent: content,
                end: true,
                id: key,
                isNavigate: true,
                parentId: planId,
                title,
              },
            },
          };

          return {
            ...prev,
            [id]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });

        setCanvases((prev) => {
          // 각 시트가 독립적인 데이터를 갖도록 초기화
          const initialSheetData = {
            sheet: { htmlContent: '', end: false, title: '' },
          };

          return {
            ...prev,
            [planId]: {
              ...initialSheetData,
              sheet: {
                htmlContent: content,
                end: true,
                id: key,
                isNavigate: true,
                parentId: planId,
                title,
              },
            },
          };
        });

        // 첫 번째 시트인 경우에만 setCanvasDetail 호출
        if (planIndex === 1) {
          setCanvasDetail(planId);
        }
        setCanvas(htmlContent);
        setAgentCanvasOpen(false);
        break;
      }

      case 'CANVAS':
      case 'canvas': {
        const htmlContent: any = {
          canvas: { htmlContent: '', end: false, title: '' },
        };

        const chatID = id;
        if (!chatID) break;

        // chatID별 planIndex 초기화
        if (!(chatID in planIndexMapRef.current)) {
          planIndexMapRef.current[chatID] = 0;
        }

        const planIndex = planIndexMapRef.current[chatID] + 1;
        const planId = `${id}-plan-${planIndex}`;
        planIndexMapRef.current[chatID] = planIndex;

        setPlanAtoms((prev: any) => {
          const prevChat = prev[id] ?? {
            plans: {},
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          };
          const currentPlans = { ...prevChat.plans };

          currentPlans[planId] = {
            id: planId,
            name: '',
            status: EStatus.SUCCESS,
            type: EPlanType.CANVAS,
            canvas: {
              canvas: {
                htmlContent: content,
                end: true,
                id: key,
                isNavigate: true,
                parentId: planId,
                title,
              },
            },
          };

          return {
            ...prev,
            [id]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });

        setCanvases((prev) => {
          // 각 캔버스가 독립적인 데이터를 갖도록 초기화
          const initialCanvasData = {
            canvas: { htmlContent: '', end: false, title: '' },
          };
          const newCanvasData = {
            ...initialCanvasData,
            canvas: {
              htmlContent: content,
              end: true,
              id: key,
              isNavigate: true,
              parentId: planId,
              title,
            },
          };

          return {
            ...prev,
            [planId]: newCanvasData,
          };
        });

        // 첫 번째 캔버스인 경우에만 setCanvasDetail 호출
        if (planIndex === 1) {
          setCanvasDetail(planId);
        }
        setCanvas(htmlContent);
        setAgentCanvasOpen(false);
        break;
      }

      case 'TOKEN':
      case 'token': {
        let tokenContent: any = {
          token: { tokenContent: '', end: false, title: '' },
        };

        const chatID = id;
        if (!chatID) break;

        // chatID별 planIndex 초기화
        if (!(chatID in planIndexMapRef.current)) {
          planIndexMapRef.current[chatID] = 0;
        }

        const planIndex = planIndexMapRef.current[chatID] + 1;
        const planId = `${id}-plan-${planIndex}`;
        planIndexMapRef.current[chatID] = planIndex;

        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID] ?? {
            plans: {},
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          };
          const currentPlans = { ...prevChat.plans };

          currentPlans[planId] = {
            id: planId,
            name: '',
            status: EStatus.SUCCESS,
            tokenContent: content,
            type: EPlanType.TOKEN,
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });

        setCanvases((prev) => {
          tokenContent = prev[id] ?? tokenContent;
          return {
            ...prev,
            [planId]: {
              ...tokenContent,
              token: {
                ...tokenContent.token,
                tokenContent: content,
                id: key,
                parentId: planId,
              },
            },
          };
        });
        break;
      }

      // case 'token': {
      //   if (!isThinkingRef.current) {
      //     setLastAiMessageData({ ...dataJson, uuid: botUuid.current });
      //   }
      //   setEndStream((prev) => ({
      //     ...prev,
      //     [id]: {
      //       content,
      //       end: true,
      //     },
      //   }));
      //   break;
      // }

      case 'GRAPH': {
        let graphContent: any = {
          graph: { graphContent: '', end: false, title: '' },
        };
        const chatID = id;
        if (!chatID) break;

        const planIndex = planIndexRef.current + 1;
        const planId = `${id}-plan-${planIndex}`;
        planIndexRef.current = planIndex;

        setPlanAtoms((prev: any) => {
          const prevChat = prev[id] ?? {
            plans: {},
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          };
          const currentPlans = { ...prevChat.plans };

          currentPlans[planId] = {
            id: planId,
            name: '',
            status: EStatus.SUCCESS,
            type: EPlanType.CANVAS,
            canvas: {
              graph: {
                ...graphContent.graph,
                graphContent: content,
                end: true,
                id: key,
                isNavigate: true,
                parentId: planId,
                title,
              },
            },
          };

          return {
            ...prev,
            [id]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        setCanvases((prev) => {
          graphContent = prev[planId] ?? graphContent;

          return {
            ...prev,
            [planId]: {
              ...graphContent,
              graph: {
                ...graphContent.graph,
                graphContent: content,
                end: true,
                id: key,
                isNavigate: true,
                parentId: planId,
                title,
              },
            },
            parentId: id,
          };
        });
        const cleaned = content.replace(/\\n/g, '').replace(/\\"/g, '"');
        setGraphData(
          typeof content === 'string' ? JSON.parse(cleaned) : content
        );
        break;
      }

      case 'text':
      case 'loading':
        setLastAiMessageData(dataJson);
        break;

      case 'user_message_uuid':
        setLastUserMessageUuid(userMessageIndex, dataJson.data);
        break;

      case 'error':
        botUuid.current = dataJson.uuid;

        throw new ServiceError(
          errorData.code,
          errorData.code_name,
          errorData.detail
        );
      case 'thought':
        setMessageSubData(dataJson.data, 'thought');
        break;
      case 'citation':
        setMessageSubData(dataJson.data, 'citations');
        break;
      case 'recommendation':
        setMessageSubData(dataJson.data, 'recommendations');
        break;
      case 'label':
        setLabelData(dataJson.data);
        break;

      case 'STEP_START':
      case 'step_start': {
        const chatID = id;
        // chatID별 planIndex 초기화
        if (!(chatID in planIndexMapRef.current)) {
          planIndexMapRef.current[chatID] = 0;
        }
        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID];
          if (!prevChat) return prev;

          const currentPlans = { ...prevChat.plans };
          const planId = `${chatID}-plan-${planIndexMapRef.current[chatID]}`;
          const plan = currentPlans[planId];
          actionIndexRef.current = 0;
          if (!plan) return prev;

          const stepIndex = stepIndexRef.current + 1;
          const stepId = `${planId}-step-${stepIndex}`;

          stepIndexRef.current = stepIndex;
          currentStepIdRef.current = stepId;

          currentPlans[planId] = {
            ...plan,
            steps: {
              ...plan.steps,
              [stepId]: {
                id: stepId,
                name: content,
                status: EStatus.LOADING,
                description,
              },
            },
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        break;
      }

      case 'THINKING':
      case 'WORKFLOW':
      case 'ROUTING': {
        const chatID = id;
        if (!chatID) break;
        // chatID별 planIndex 초기화
        if (!(id in planIndexMapRef.current)) {
          planIndexMapRef.current[id] = 0;
        }
        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID] ?? {
            plans: {},
            status: EStatus.INCOMPLETE,
            parentId: userUuid.current ?? '',
          };
          const currentPlans = { ...prevChat.plans };
          const prevPlanId = `${id}-plan-${planIndexMapRef.current[id]}`;
          const prevPlan = currentPlans[prevPlanId];
          const planIndex = planIndexMapRef.current[id] + 1;
          const planId = `${id}-plan-${planIndex}`;
          const plan = currentPlans[planId];
          const stepIndex = stepIndexRef.current + 1;
          const stepId = `${planId}-step-${stepIndex}`;
          if (prevPlanId && currentPlans[prevPlanId]) {
            currentPlans[prevPlanId] = {
              ...prevPlan,
              status: EStatus.SUCCESS,
            };
          }

          // Reset plan index
          planIndexMapRef.current[id] = planIndex;
          currentPlans[planId] = {
            ...plan,
            id: planId,
            status: EStatus.INCOMPLETE,
            name: content.trim(),
            description: '',
            steps: {
              [stepId]: {
                id: stepId,
                name: description,
                status: EStatus.SUCCESS,
              },
            },
            type: EPlanType.THINKING,
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        break;
      }

      case 'ACTION_START':
      case 'action_start': {
        const chatID = id;
        // chatID별 planIndex 초기화
        if (!(chatID in planIndexMapRef.current)) {
          planIndexMapRef.current[chatID] = 0;
        }
        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID];
          if (!prevChat) return prev;

          const currentPlans = { ...prevChat.plans };
          const planId = `${chatID}-plan-${planIndexMapRef.current[chatID]}`;
          const plan = currentPlans[planId];
          if (!plan) return prev;

          const currentSteps = { ...plan.steps };
          const stepId = `${planId}-step-${stepIndexRef.current}`;
          const step = currentSteps[stepId];
          if (!step) return prev;

          const actionIndex = actionIndexRef.current + 1;
          const actionId = `${stepId}-action-${actionIndex}`;
          actionIndexRef.current = actionIndex;
          currentActionIdRef.current = actionId;

          currentSteps[stepId] = {
            ...step,
            actions: {
              ...step.actions,
              [actionId]: {
                id: actionId,
                name: content,
                status: EStatus.LOADING,
                description,
              },
            },
          };

          currentPlans[planId] = {
            ...plan,
            steps: currentSteps,
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        break;
      }

      case 'ACTION_SUCCESS':
      case 'ACTION_FAIL':
      case 'action_success':
      case 'action_fail': {
        const chatID = id;
        initializePlanIndex(chatID); // planIndex 초기화
        const status: EStatus.SUCCESS | EStatus.FAIL =
          type === 'ACTION_SUCCESS' || type === 'action_success'
            ? EStatus.SUCCESS
            : EStatus.FAIL;

        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID];
          if (!prevChat) return prev;

          const currentPlans = { ...prevChat.plans };
          const planId = `${chatID}-plan-${planIndexMapRef.current[chatID]}`;
          const plan = currentPlans[planId];
          if (!plan) return prev;

          const currentSteps = { ...plan.steps };
          const stepId = `${planId}-step-${stepIndexRef.current}`;
          const step = currentSteps[stepId];
          if (!step) return prev;

          const actions = { ...step.actions };
          const action: any = Object.values(actions).find(
            (a: any) => a.status === EStatus.LOADING
          );
          if (!action) return prev;

          actions[action.id] = {
            ...action,
            name: content,
            status,
          };

          currentSteps[stepId] = {
            ...step,
            actions,
          };

          currentPlans[planId] = {
            ...plan,
            steps: currentSteps,
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        break;
      }

      case 'STEP_END':
      case 'step_end': {
        const chatID = id;
        initializePlanIndex(chatID); // planIndex 초기화
        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID];
          if (!prevChat) return prev;

          const currentPlans = { ...prevChat.plans };
          const planId = `${chatID}-plan-${planIndexMapRef.current[chatID]}`;
          const plan = currentPlans[planId];
          if (!plan) return prev;

          const steps = { ...plan.steps };
          const step = Object.values(steps).find(
            (s: any) => s.status === EStatus.LOADING
          ) as any;
          if (!step) return prev;

          steps[step.id] = {
            ...step,
            name: content,
            status: EStatus.SUCCESS,
          };

          currentPlans[planId] = {
            ...plan,
            steps,
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        break;
      }

      case 'PLAN_END':
      case 'plan_end': {
        const chatID = id;
        initializePlanIndex(chatID); // planIndex 초기화
        setPlanAtoms((prev: any) => {
          const prevChat = prev[chatID];
          if (!prevChat) return prev;

          const currentPlans = { ...prevChat.plans };
          const planId = `${chatID}-plan-${planIndexMapRef.current[chatID]}`;
          const plan = currentPlans[planId];
          if (!plan) return prev;

          currentPlans[planId] = {
            ...plan,
            status: EStatus.SUCCESS,
          };

          return {
            ...prev,
            [chatID]: {
              ...prevChat,
              plans: currentPlans,
            },
          };
        });
        break;
      }
      default:
        break;
    }
  };

  const isJsonString = (str: string) => {
    try {
      JSON.parse(str);
    } catch (e) {
      if (e) {
        return false;
      }
    }
    return true;
  };

  /** stream 받는 타입별로 value 세팅 */
  let buffer = '';
  let bufferIndex = 0;
  let currentStreamValue = '';
  const parseMessage = async (streamValue: any, userMessageIndex: number) => {
    buffer += streamValue;

    const splitter = 'event: ';
    const dataList = buffer.split(splitter);
    const dataPattern = /\ndata: (.*)\n\n/;

    if (!currentStreamValue) currentStreamValue = '';

    currentStreamValue += streamValue;

    const parts = currentStreamValue.split(splitter);

    for (let i = 0; i < parts.length - 1; i++) {
      const match = RegExp(dataPattern).exec(parts[i]);
      if (match && isJsonString(match[1])) {
        const dataJson = JSON.parse(match[1]);
        switchCaseHandler({ dataJson, userMessageIndex });
      }
    }

    currentStreamValue = parts[parts.length - 1];

    for (let i = bufferIndex; i < dataList.length; i++) {
      const data = dataList[i];
      if (data.trim().toUpperCase() === 'START') {
        isThinkingRef.current = false;
      }
      if (data.trim().toUpperCase() === 'END') {
        setShowDoc(selectedTool.isSelectedCanvas);
        const index = dataList.findIndex(
          (d) => typeof d === 'string' && d.trim()
        );

        if (index !== -1) {
          dataList[index] = 'text';
        }
        continue;
      }
      // if (data.trim().includes('error')) {
      //   showSnackbar(t('error.genStepsFail'), 'error', 8);

      //   return;
      // }

      const match = RegExp(dataPattern).exec(data);

      if (match) {
        const dataJson = JSON.parse(match[1]);
        switchCaseHandler({ dataJson, userMessageIndex });
        currentStreamValue = '';
      }

      if (checkIsAborted()) break;
      setMessagesData(
        messagesRef.current.reduce((acc, message) => {
          acc[message.uuid] = message;
          return acc;
        }, {} as any)
      );
    }

    bufferIndex = dataList.length;

    if (dataList.some((d) => typeof d === 'string' && d.trim() === 'END')) {
      setTimeout(() => {
        setPlanAtoms((prev: any) => {
          const currentSteps = { ...prev.steps };

          const allActionsFinalized = Object.values(currentSteps).every(
            (step: any) =>
              Object.values(step.actions).every(
                (action: any) =>
                  action.status === EStatus.SUCCESS ||
                  action.status === EStatus.FAIL
              )
          );
          return {
            ...prev,
            status: allActionsFinalized ? EStatus.SUCCESS : EStatus.INCOMPLETE,
          };
        });
      }, 0);
    }
  };

  const abortControllerRef = useRef<AbortController | undefined>(undefined);

  const resetAbortData = () => {
    abortControllerRef.current = new AbortController();
    setAbortData({
      key: `${historyIdRef.current}`,
      value: {
        abortController: abortControllerRef.current,
        isAbort: false,
      },
    });
    abortData[historyIdRef.current!] = {
      abortController: abortControllerRef.current,
      isAbort: false,
    };
  };

  const errorHandle = async (
    error: { message: string; name: string },
    isPro: boolean,
    version?: string
  ) => {
    if (error.message !== 'end') {
      if (error?.name === 'AbortError') {
        await haltMessage(version, isPro);
        return true;
      }
      await setErrorMessages(error);
      return false;
    }
  };

  const generateMessage = async (
    userMessageIndex: number,
    isPro: boolean,
    orderSpliceRule: number[],
    version?: string,
    createTitle = false,
    userMsgId: string = '',
    type?: string,
    chatType?: string,
    isAi?: boolean,
    isGraph?: boolean,
    isTestAgent?: boolean,
    rawMsg?: string,
    toolGroupIds?: (string | number)[]
  ) => {
    const isAborted = false;
    const originMessages = _.cloneDeep(Object.values(chatData?.messages ?? {}));
    lastMessageOrder.current = _.clone(
      messagesOrder?.length ? messagesOrder : [0]
    );
    const loadingId = uuidv4();

    try {
      setWorkflowPlan({
        steps: [],
        id: '',
      });
      const newAiMessage: IMessage = {
        role: ERole.ASSISTANT,
        type: EMessageType.LOADING,
        content: '',
        message: '',
        config: { isPro },
        uuid: loadingId,
        parentUuid: userMsgId,
        createdAt: new Date().toISOString(),
      };
      const messagesRequest = setMessagesForSending(messagesRef.current);
      botUuid.current = loadingId;
      resetAbortData();
      messagesRef.current = [...messagesRef.current, newAiMessage];
      setChatData({
        userData: {
          userId: userData?.user_id,
          userName: userData?.username,
        },
        userInput: '',
        historyId: historyIdRef.current as number,
        title: titleRef.current,
        messages: messagesRef.current.reduce((acc, message) => {
          acc[message.uuid] = message;
          return acc;
        }, {} as any),
      });
      setMessagesOrder(Array(messagesRef.current.length).fill(0));
      const partialParseMessage = async (streamValue: any) => {
        await parseMessage(streamValue, userMessageIndex);
        streamValue = null;
      };
      if (selectedFile2Upload.length > 0) {
        const fileIds = selectedFile2Upload.reduce(
          (ids, item: IUploadedFile) => {
            if (item.id !== undefined) {
              ids.push(+item.id);
            }
            return ids;
          },
          [] as number[]
        );

        await attachFileToChat({
          data: {
            chat_id: historyIdRef.current?.toString() ?? '',
            file_ids: fileIds,
          },
        });
        setSelectedFile2Upload([]);
      }

      await chatApi(
        messagesRequest,
        historyIdRef.current?.toString(),
        abortControllerRef.current?.signal,
        partialParseMessage,
        loadingId,
        chatData.selectedAgent ?? chatAgentRef.current,
        type,
        chatType,
        isAi,
        isGraph,
        isTestAgent,
        rawMsg,
        toolGroupIds
      );

      if (
        !isAi &&
        rawMsg &&
        originMessages.length === 0 &&
        historyIdRef.current
      ) {
        const response = await createNewChatTitle(
          historyIdRef.current.toString(),
          rawMsg
        );
        setNewChatCreated((prev) => {
          if (prev && prev.title !== response) {
            const updateTitle = { ...prev, title: response };
            return updateTitle;
          }
        });
      }
    } catch (error: any) {
      errorHandle(error, isPro, version);
    } finally {
      haltLoadingMessage();
      createTitle && updateHistoryData();
      const isChatPage =
        window.location.pathname.includes(ServiceType.CHAT) ||
        window.location.pathname.includes(ServiceType.WORKFLOW_REVIEW) ||
        window.location.pathname.includes(RoutesURL.GENERAL_AGENT);
      const isHistoryIdMatch =
        window.location.pathname.includes(`${historyIdRef.current}`) ||
        window.location.pathname.includes(ServiceType.WORKFLOW_REVIEW) ||
        window.location.pathname.includes(RoutesURL.AGENT_CREATE) ||
        window.location.pathname.includes(RoutesURL.GENERAL_AGENT);
      // 채팅 진행하던 페이지에서 채팅이 끝난 경우
      if (
        (!isAborted || (isChatPage && isHistoryIdMatch)) &&
        historyIdRef.current !== -1
      ) {
        const newMessages = await getChatMsgById(
          historyIdRef.current?.toString()
        );

        const messages = _.merge(
          originMessages.reduce<MessageMap>(
            (acc: MessageMap, message: Message) => {
              acc[String(message.uuid)] = message;
              return acc;
            },
            {}
          ),
          messagesRef.current.reduce((acc, message) => {
            acc[message.uuid] = message;
            return acc;
          }, {} as any)
        );

        const mergedMsgs = _.merge(
          messages,
          (newMessages ?? []).reduce((acc, item) => {
            acc[item.uuid] = {
              role: item.role,
              uuid: item.uuid.toString(),
              parentUuid: item.parentUuid ? item.parentUuid.toString() : '',
              message: item.message,
              content: item.content,
              createdAt: item.createdAt,
            };
            return acc;
          }, {} as any)
        );

        setChatData({
          isGenerating: false,
          historyId: historyIdRef.current === -1 ? 0 : historyIdRef.current,
          messages: mergedMsgs,
          title:
            titleRef.current ??
            chatData.title ??
            messagesRef.current[0].message,
        });
      } else {
        setChatData({
          isGenerating: false,
          title: titleRef.current ?? chatData.title,
        });
      }
      // 각 상황에 맞게 message order 구성
      const newOrder = lastMessageOrder.current;
      newOrder.splice(
        orderSpliceRule[0],
        orderSpliceRule[1],
        ...orderSpliceRule.slice(2)
      );
      setMessagesOrder(newOrder);
      invalidateCost();
    }
  };

  // Replace with actual model data
  const MOCK_AGENT_ID = '1360';

  const createHistoryId = async ({
    userId,
    chatTitle = '',
    isAi,
    isSuperChat,
    chatType,
  }: {
    userId: string;
    chatTitle?: string;
    isAi?: boolean;
    isSuperChat?: boolean;
    chatType: EChatType;
  }) => {
    setNewChatCreated(undefined);
    const response = await createNewChat({
      'user_id': userId,
      // 'agent_id': isAi ? chatData.selectedAgent : '',
      title: chatTitle,
      model: selectedModel,
      'config': {
        'chat_mode': EChatMode.AGENT_CHAT,
      },
      chat_type: chatType,
      ...(isAi && { agent_id: chatData.selectedAgent }),
    });
    chatAgentRef.current = response.agent_id ?? MOCK_AGENT_ID;
    setNewChatCreated(response);

    setChatData({
      title: response.title,
      historyId: response.id,
      selectedAgent: response.agent_id,
      updated: Date.now(),
    });

    setIsCreatingChat({
      isCreating: false,
      updated: Date.now(),
    });

    setAgentCanvasOpen(false);
    navigate(
      `${isAi ? RoutesURL.AI_CHAT : isSuperChat ? RoutesURL.SUPER_AGENT_CHAT : RoutesURL.CHAT}/${response.id}`
    );
    return response.id;
  };

  const setIsGenerating = (isGenerating: boolean) => {
    setChatData({
      ...chatData,
      isGenerating,
    });
  };

  const sendMessage = async ({
    message,
    libraryId,
    agentId,
    chat_type,
    isAi,
    isGraph,
    isTestAgent,
    isSuperChat,
    userId,
    chatTitle,
    chatType,
    toolGroupIds,
  }: ISendMessage) => {
    if (chatData?.isGenerating) return;
    setIsGenerating(true);
    const { historyId, isPro, chatVersion } = chatData;
    const createTitle = historyId === -1;
    messagesRef.current = currentMessages.map(
      (msgUuid) => chatData.messages[msgUuid]
    );
    titleRef.current = createTitle ? (chatTitle ?? '') : chatData.title;
    if (!isSecretMode && !isAi) {
      if (historyId === -1) {
        setIsCreatingChat({
          isCreating: true,
          updated: Date.now(),
        });
        const newHistory = await createHistoryId({
          userId: userId?.toString() ?? '',
          chatTitle,
          isAi,
          isSuperChat,
          chatType: isAi
            ? EChatType.AISlideChat
            : chatType === ChatType.GENERAL
              ? EChatType.AIChat
              : chatType === ChatType.SUPERCHAT
                ? EChatType.SuperAgentChat
                : EChatType.ExpertAgentChat,
        });
        historyIdRef.current = newHistory;
        navigate(`${location.pathname}${isAi ? '' : `?isShowModel=true`}`);
      } else {
        historyIdRef.current = historyId;
      }
    } else {
      setChatData({
        isAiInitiated: true,
      });
    }
    const userMsgId: string = createUserMessage(message);
    const userMessageIndex = messagesRef.current.length - 1;
    const orderSpliceRule = [userMessageIndex + 1, 1, -1, -1];
    const sendType = isAi ? AI_SLIDE_TYPE : chat_type;

    requestAnimationFrame(() => {
      generateMessage(
        userMessageIndex,
        isPro,
        orderSpliceRule,
        chatVersion ?? config?.CHAT_VERSION_DEFAULT,
        createTitle,
        userMsgId,
        sendType,
        chatType,
        isAi,
        isGraph,
        isTestAgent,
        message,
        toolGroupIds
      );
    });
  };

  const resendMessagesFunc = async ({
    message,
    libraryId,
    agentId,
    chat_type,
  }: ISendMessage) => {
    if (chatData?.isGenerating) return;
    setIsGenerating(true);
    const { historyId, isPro, chatVersion } = chatData;
    const createTitle = historyId === -1;
    messagesRef.current = currentMessages.map(
      (msgUuid) => chatData.messages[msgUuid]
    );
    titleRef.current = createTitle ? '' : chatData.title;
    if (!isSecretMode) {
      historyIdRef.current = historyId;
    }
    const userMsgId: string = createUserMessage(message);
    const userMessageIndex = messagesRef.current.length - 1;
    const orderSpliceRule = [userMessageIndex + 1, 1, -1, -1];
    requestAnimationFrame(() => {
      generateMessage(
        userMessageIndex,
        isPro,
        orderSpliceRule,
        chatVersion ?? config?.CHAT_VERSION_DEFAULT,
        false,
        userMsgId,
        chat_type
      );
    });
  };

  const resendMessage = async (message_uuid: string, newMessage: string) => {
    if (chatData?.isGenerating) return;
    setIsGenerating(true);
    const { historyId, isPro, chatVersion, title } = chatData;
    const messages = _.cloneDeep(
      currentMessages.map((msgUuid) => chatData.messages[msgUuid])
    );
    const resendMessages = [];
    let userMessageIndex = -1;
    for (const message of messages) {
      userMessageIndex++;
      if (message.uuid === message_uuid) break;
      resendMessages.push(message);
    }
    messagesRef.current = resendMessages;
    const userMsgId: string = createUserMessage(newMessage);
    titleRef.current = title;
    historyIdRef.current = historyId!;
    if (userMessageIndex === -1) return;
    const orderSpliceRule = [userMessageIndex, 2, -1, -1];
    requestAnimationFrame(() => {
      generateMessage(
        userMessageIndex,
        isPro,
        orderSpliceRule,
        chatVersion ?? config?.CHAT_VERSION_DEFAULT,
        false,
        userMsgId
      );
    });
  };

  const regenerateMessage = async (
    message_uuid: string,
    isPro = false,
    chatVersion = config?.CHAT_VERSION_DEFAULT
  ) => {
    if (chatData?.isGenerating) return;
    setIsGenerating(true);
    const { historyId, title } = chatData;
    const messages = _.cloneDeep(
      currentMessages.map((msgUuid) => chatData.messages[msgUuid])
    );
    const regenerateMessages = [];
    let userMessageIndex = -1;
    for (const message of messages) {
      regenerateMessages.push(message);
      userMessageIndex++;
    }
    messagesRef.current = regenerateMessages;
    historyIdRef.current = historyId!;
    titleRef.current = title;
    if (userMessageIndex === -1) return;
    userUuid.current = messagesRef.current[userMessageIndex].uuid;
    const orderSpliceRule = [userMessageIndex + 1, 1, -1];
    requestAnimationFrame(() => {
      generateMessage(
        userMessageIndex,
        isPro,
        orderSpliceRule,
        chatVersion ?? config?.CHAT_VERSION_DEFAULT,
        true
      );
    });
  };

  const abortMessage = () => {
    historyIdRef.current ??= chatData.historyId;
    const currentAbort = abortData[historyIdRef.current!];
    if (currentAbort) {
      currentAbort.abortController?.abort();
      currentAbort.isAbort = true;
    }
  };

  return {
    checkIsAborted,
    sendMessage,
    regenerateMessage,
    resendMessage,
    abortMessage,
    resendMessagesFunc,
  };
};
