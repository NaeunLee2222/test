import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import { recommendationDataAtom } from '../jotai/recommendation';
import { getRecommendationData } from '../api/recommendation';
import { isSecretModeAtom } from '../jotai/chat';

const RECOMMENDATION_DATA_KEY = ['recommendation'];

export const useRecommendationData = atomWithQuery((get) => ({
  queryKey: [
    ...RECOMMENDATION_DATA_KEY,
    get(recommendationDataAtom)?.historyId ?? -1,
    get(recommendationDataAtom)?.messageUuid ?? '',
    get(isSecretModeAtom),
  ],
  queryFn: async ({
    queryKey: [, historyId, messageUuid, isSecretMode],
  }: any) => {
    if (isSecretMode) return;
    if (!historyId || !messageUuid || historyId === -1) return {};
    return getRecommendationData(historyId, messageUuid);
  },
  select: (data: any) => {
    const recommendationData = get(recommendationDataAtom);
    return {
      ...recommendationData,
      recommendations: (data?.recommendations || []) as string[],
    };
  },
}));

export const mutateRecommendationDataAtom = atomWithMutation((get) => ({
  mutationKey: [...RECOMMENDATION_DATA_KEY],
  mutationFn: async ({
    historyId,
    messageUuid,
    recommendations,
  }: {
    historyId?: number;
    messageUuid: string;
    recommendations: string[];
  }) =>
    new Promise((resolve) => {
      resolve({ historyId: historyId ?? -1, messageUuid, recommendations });
    }),
  onSettled: ({ historyId, messageUuid, recommendations }: any) => {
    const queryClient = get(queryClientAtom);
    const isSecretMode = get(isSecretModeAtom);
    queryClient.setQueryData(
      [...RECOMMENDATION_DATA_KEY, historyId, messageUuid, isSecretMode],
      {
        historyId,
        messageUuid,
        recommendations,
      }
    );
    queryClient.invalidateQueries({
      queryKey: [
        ...RECOMMENDATION_DATA_KEY,
        historyId,
        messageUuid,
        isSecretMode,
      ],
      refetchType: 'none',
      exact: false,
    });
  },
}));
