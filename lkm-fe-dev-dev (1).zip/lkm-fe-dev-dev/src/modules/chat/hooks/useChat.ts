import * as chatActions from '@/modules/chat/api/chat';
import { paramHistoryChatAtom } from '@/modules/chat/jotai/chat';
import { EChatMode, IChatHistoryParam } from '@/modules/chat/types/chat';
import { EChatType } from '@/modules/core/types';
import { atomWithMutation, atomWithQuery } from 'jotai-tanstack-query';

export const CHAT_DATA_KEY = ['chat'];
const CREATE_CHAT_KEY = ['create-chat'];
export const GET_CHAT_HISTORY = ['history'];
const GET_CHAT_MODELS = ['models'];

export const useCreateNewChat = atomWithMutation((_get) => ({
  mutationKey: [...CHAT_DATA_KEY, CREATE_CHAT_KEY],
  mutationFn: async ({
    userId,
    agentId,
    title,
    model,
    chatMode,
    chatType,
  }: {
    userId: number | string;
    agentId: number | string;
    title: string;
    model: string;
    chatMode: EChatMode;
    chatType: EChatType;
  }) =>
    chatActions.createNewChat({
      'user_id': userId,
      'agent_id': agentId,
      title,
      model,
      'config': {
        'chat_mode': chatMode,
      },
      'chat_type': chatType,
    }),
}));

export const useChatHistory = atomWithQuery((get) => {
  const params: IChatHistoryParam = get(paramHistoryChatAtom);

  return {
    queryKey: [
      ...CHAT_DATA_KEY,
      ...GET_CHAT_HISTORY,
      params.user_id,
      params.skip,
    ],
    queryFn: async () => {
      if (params.user_id) {
        return chatActions.getChatByUserId(params);
      }
    },
    enabled: !!params.user_id, // optional: only run if userId exists
  };
});

export const useChatModels = atomWithQuery(() => ({
  queryKey: [...CHAT_DATA_KEY, ...GET_CHAT_MODELS],
  queryFn: async () => chatActions.getChatModels(),
}));
