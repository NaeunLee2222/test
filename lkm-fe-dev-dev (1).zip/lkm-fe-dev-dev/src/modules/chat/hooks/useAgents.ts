import { skipGetGeneralAgentAtom } from '@/modules/admin/jotai/agent';
import {
  actionIdAtom,
  agentAtom,
  generalAgentIdAtom,
} from '@/modules/agent/jotai/agent';
import { AgentType, IActionPost } from '@/modules/agent/type/agent';
import * as actions from '@/modules/chat/api/agents';
import { updateAction } from '@/modules/chat/api/agents';
import {
  agentDetailIdAtom,
  listAgentPaginationAtom,
} from '@/modules/chat/jotai/agents';
import { queryClient } from '@/modules/core/hooks';
import { formatStepAction } from '@/utils/agentUtil';
import { atomWithMutation, atomWithQuery } from 'jotai-tanstack-query';
import {
  EUsageScope,
  GetAgentParams,
  IChatAgent,
  IChatAgentDetailResponse,
  IChatAgentResponse,
  IGetChatAgentListResponse,
} from '../types/agents';

export const AGENT_KEY = ['agent-fetch'];

const returnedAgentFetchObject = ({
  skip,
  limit,
  category,
  usageScope,
  agentType,
  reviewStatus,
  order,
  isMyAgent,
  name,
  updated,
}: GetAgentParams) => ({
  queryKey: [
    ...AGENT_KEY,
    skip ?? 0,
    limit ?? 0,
    category ?? '',
    usageScope ?? '',
    agentType ?? '',
    reviewStatus ?? '',
    order ?? '',
    isMyAgent ?? false,
    name ?? '',
    updated ?? 0,
  ],
  queryFn: async () => {
    const fetchFunc = isMyAgent
      ? actions.getMyAgent(skip, limit, category, order, name)
      : actions.getAgent({
          skip,
          limit,
          category,
          reviewStatus,
          order,
          usageScope,
          name,
        });
    return limit ? fetchFunc : null;
  },
  select: (data: IGetChatAgentListResponse | null) => {
    if (!data) return null;

    const agents: IChatAgent[] = data.agents?.map(
      (agent: IChatAgentResponse) => ({
        'id': agent.id.toString(),
        'name': agent.name,
        'description': agent.description,
        'rejectDescription': agent.reject_description,
        'category': agent.category,
        'createdAt': agent.created_at,
        'updatedAt': agent.updated_at,
        'usageScope': agent.usage_scope,
        'agentType': agent.agent_type,
        'reviewStatus': agent.review_status,
        'useCount': agent.use_count,
        'creator': {
          id: agent.created_user_id.toString(),
          name: '',
        },
      })
    );
    return {
      agents,
      isEnd: !!(!agents || agents.length === data.total),
    };
  },
  enabled: false,
});

export const useDisabledAgentsData = atomWithQuery((get) => {
  const {
    skip,
    limit,
    category,
    usageScope,
    agentType,
    reviewStatus,
    order,
    isMyAgent,
    name,
    updated,
  } = get(listAgentPaginationAtom);

  queryClient.invalidateQueries({
    queryKey: [
      ...AGENT_KEY,
      skip ?? 0,
      limit ?? 0,
      category ?? '',
      usageScope ?? '',
      agentType ?? '',
      reviewStatus ?? '',
      order ?? '',
      isMyAgent ?? false,
      name ?? '',
      updated ?? 0,
    ],
    exact: false,
  });

  return returnedAgentFetchObject({
    skip,
    limit,
    category,
    usageScope,
    agentType,
    reviewStatus,
    order,
    isMyAgent,
    name,
    updated,
  });
});

export const useAgentDetail = atomWithQuery((get) => ({
  queryKey: [...AGENT_KEY, get(agentDetailIdAtom)],
  queryFn: async ({ queryKey: [, id] }: any) =>
    id ? actions.getAgentDetail(id) : null,
  select: (data: IChatAgentDetailResponse | null) => {
    if (!data) return null;
    const rawData = data.agent;
    const formattedData: IChatAgent = {
      id: rawData.id.toString(),
      name: rawData.name,
      description: rawData.description,
      rejectDescription: rawData.reject_description,
      createdAt: rawData.created_at,
      reviewStatus: rawData.review_status,
      updatedAt: rawData.updated_at,
      orgId: rawData.org_id,
      teamId: rawData.team_id,
      steps: rawData.steps?.map((step) => ({
        id: step?.id?.toString() ?? '',
        createdAt: step?.created_at ?? '',
        name: step.name,
        description: step.description,
        order: step.order,
        expertAgentId: step.expert_agent_id,
        actions: formatStepAction(step)
          .toSorted((first: any, second: any) => first.order - second.order)
          .map((action: any) => ({
            ...action,
            id: action.id,
            description: action.description ?? '',
          })),
      })),
      mode:
        rawData.usage_scope === EUsageScope.PUBLIC
          ? AgentType.PRO
          : AgentType.GENERAL,
    };
    return {
      formattedData,
      rawData,
    };
  },
}));

export const generateInstructionMutation = atomWithMutation((get) => ({
  mutationKey: ['agent', 'instruction'],
  mutationFn: () => {
    const payload = get(agentAtom);
    const formData = new FormData();
    formData.append('agent_name', payload.name ?? '');
    formData.append('agent_description', payload.description ?? '');
    if (payload.file) formData.append('file', payload.file);
    return actions.generateInstruction(formData);
  },
}));

export const generateRecommendedToolsMutation = atomWithMutation((get) => ({
  mutationKey: ['agent', 'tools'],
  mutationFn: () => {
    const payload = get(agentAtom);
    const formData = new FormData();
    formData.append('agent_name', payload.name ?? '');
    formData.append('agent_description', payload.description ?? '');
    formData.append('instruction', payload.instruction ?? '');
    if (payload.file) formData.append('file', payload.file);
    return actions.generateRecommendedTools(formData);
  },
}));

export const useGetAllTools = atomWithQuery(() => ({
  queryKey: ['agent', 'tool', 'tools'],
  queryFn: async () => actions.getAllTools(),
}));

export const useGetGeneralAgent = atomWithQuery((get) => {
  const id = get(generalAgentIdAtom);
  const skip = get(skipGetGeneralAgentAtom);

  return {
    queryKey: ['agent', 'agent_id', id],
    enabled: !!id && !skip,
    queryFn: async () => {
      const res = await actions.getAgentGeneralDetails(id);
      if (!res?.success && !res?.data?.success) return null;
      return res;
    },
  };
});

export const useGetActionAgent = atomWithQuery((get) => {
  const id = get(actionIdAtom);
  return {
    queryKey: ['action', 'action_id', id],
    queryFn: async () => (id ? actions.getActionInfo(id) : null),
  };
});

export const updateActionInfoMutation = atomWithMutation((_get) => ({
  mutationKey: ['update'],
  mutationFn: async ({
    payload,
    action_id,
    callback,
  }: {
    payload: IActionPost;
    action_id: string;
    callback: () => void;
  }) => {
    const res = await updateAction({ payload, action_id });
    callback();

    return res;
  },
}));
