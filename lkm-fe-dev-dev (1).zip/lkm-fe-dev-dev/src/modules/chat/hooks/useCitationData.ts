import { atomWithQuery } from 'jotai-tanstack-query';
import { getCitationData, getSecretCitationData } from '../api/citation';
import { citationDataAtom } from '../jotai/citation';
import { isSecretModeAtom } from '../jotai/chat';

const CITATION_DATA_KEY = ['citation'];

export const useCitationData = atomWithQuery((get) => ({
  queryKey: [
    ...CITATION_DATA_KEY,
    get(citationDataAtom)?.historyId,
    get(citationDataAtom)?.messageUuid,
    get(citationDataAtom)?.id,
    get(isSecretModeAtom),
    get(citationDataAtom)?.company,
  ],
  queryFn: async ({
    queryKey: [, historyId, messageUuid, id, isSecretMode, company],
  }: any) => {
    if (isSecretMode && id) return getSecretCitationData(id);
    if (!historyId || !messageUuid || !id) return null;
    return getCitationData(historyId, messageUuid, id, company);
  },
  staleTime: 0,
  select: (data: any) => ({
    rawData: data?.content,
    originalUrl: data?.original_url,
  }),
}));
