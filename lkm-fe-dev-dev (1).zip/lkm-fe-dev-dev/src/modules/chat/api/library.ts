import { axiosInstance } from '@/modules/core/libs';
import {
  ILibraryListResponse,
  ILibraryResponse,
} from '@/modules/chat/types/history';

const URL_PREFIX = '/core/library';

export const getLibraryList = async () => {
  const response: ILibraryListResponse = await axiosInstance.get(
    `${URL_PREFIX}`
  );
  return response;
};

export const createLibrary = async (
  title: string,
  historyIdList?: number[]
) => {
  const response: ILibraryResponse = await axiosInstance.post(`${URL_PREFIX}`, {
    title,
    history_id_list: historyIdList,
  });
  return response;
};

export const updateLibrary = async (
  id: number,
  title?: string,
  addHistoryIdList?: number[],
  delHistoryIdList?: number[]
) => {
  const response: ILibraryResponse = await axiosInstance.patch(
    `${URL_PREFIX}/${id}`,
    {
      title,
      add_history_id_list: addHistoryIdList,
      del_history_id_list: delHistoryIdList,
    }
  );
  return response;
};

export const deleteLibrary = async (id: number) => {
  const response: ILibraryResponse = await axiosInstance.delete(
    `${URL_PREFIX}/${id}`
  );
  return response;
};
