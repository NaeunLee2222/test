import {
  ChatType,
  CreateChatParams,
  ERole,
  IChatDeleteResponse,
  IChatHistoryParam,
  IChatListResponse,
  IChatMessageResponse,
  IChatResponse,
} from '@/modules/chat/types/chat';
import {
  CanvasInfo,
  EPlanType,
  EStatus,
  PlanInfo,
} from '@/modules/chat/types/chatprocessing';
import { HttpMethod } from '@/modules/core/constant';
import { chatInstance } from '@/modules/core/libs';
import { EHttpResponseStatus } from '@/types/common';
import { ServiceError } from '@/utils/errorUtil';
import { IGraph } from '../types/graph';
import { IMessage, IMessageRequest } from '../types/message';

const URL_PREFIX_CHATS = '/chats';
const URL_AI_CHAT_PREFIX = `${import.meta.env.VITE_AGENT_URL}/${import.meta.env.VITE_AGENT_PATH}/ai-slide/stream`;
const URL_PREFIX = `${import.meta.env.VITE_CHAT_URL}/${import.meta.env.VITE_CHAT_PATH}/supervisor/chat/completions/stream`;
const URL_GENERAL_PREFIX = `${import.meta.env.VITE_CHAT_URL}/${import.meta.env.VITE_CHAT_PATH}/supervisor/general/chat/completions/stream`;
const URL_AGENT_CHAT_PREFIX = `${import.meta.env.VITE_CHAT_URL}/${import.meta.env.VITE_CHAT_PATH}/supervisor/chat/completions/stream`;
// wait for customer
// const URL_SUPERCHAT_PREFIX = `${import.meta.env.VITE_CHAT_URL}/${import.meta.env.VITE_CHAT_PATH}/supervisor/superchat/chat/completions/stream`;
const URL_MASTER_PREFIX = `${import.meta.env.VITE_CHAT_URL}/${import.meta.env.VITE_CHAT_PATH}/supervisor/master/chat/completions/stream`;

export async function chatApi(
  messages: IMessageRequest[],
  chatId?: string,
  signal?: AbortSignal,
  parseCallback?: (streamValue: any) => Promise<void>,
  botMsgId?: string,
  agentId?: number | string,
  type?: string,
  chatType?: string,
  isAi?: boolean,
  isGraph?: boolean,
  isTestAgent?: boolean,
  rawMsg?: string,
  toolGroupIds?: (string | number)[]
): Promise<any> {
  const decoder = new TextDecoder();

  const body: any = {
    messages,
    chat_id: chatId,
    child_id: botMsgId,
    is_stream: true,
    tool_group_ids: toolGroupIds,
  };

  if (agentId && chatType !== ChatType.GENERAL) {
    body.expert_agent_id = agentId;
    body.task_agent_id = agentId;
  }

  if (type) {
    body.canvas = type;
  }

  let endpoint = '';

  switch (chatType) {
    case ChatType.GENERAL:
    case ChatType.SUPERCHAT:
      endpoint = `${URL_GENERAL_PREFIX}`;
      break;
    // [feature/HKCS25-64] Will be changed later when API is completed
    // case ChatType.SUPERCHAT:
    //   endpoint = `${URL_SUPERCHAT_PREFIX}`;
    //   break;
    case ChatType.SUPERVISOR:
      endpoint = `${URL_AGENT_CHAT_PREFIX}`;
      break;
    default:
      endpoint = `${URL_PREFIX}`;
      break;
  }

  if (isAi) {
    endpoint = URL_AI_CHAT_PREFIX;
  }

  if (isGraph) {
    endpoint = URL_GENERAL_PREFIX;
  }

  if (isTestAgent) {
    endpoint = URL_MASTER_PREFIX;
  }

  const response = await fetch(endpoint, {
    signal,
    method: HttpMethod.POST,
    headers: {
      'Content-Type': 'application/json',
      'accept': 'text/event-stream',
    },
    body: JSON.stringify(
      isAi
        ? {
            query: rawMsg,
            stream: true,
            child_id: botMsgId,
          }
        : body
    ),
  });

  const responseBody = response.body;
  if (!(responseBody instanceof ReadableStream)) {
    throw new Error('Failed to send message');
  }
  const reader = responseBody?.getReader();

  while (true) {
    const { done, value } = await reader.read();
    if (!reader || done) {
      parseCallback?.('done');
      break;
    }
    const newString = decoder.decode(value, { stream: true });
    if (!response.ok || response.status > EHttpResponseStatus.SUCCESSFUL) {
      try {
        const error = JSON.parse(newString);
        throw new ServiceError(error?.code, error?.code_name, error?.detail);
      } catch (e) {
        if (e instanceof ServiceError) throw e;
        throw new Error('Failed to send message');
      }
    }
    await parseCallback?.(newString);
  }

  return response;
}

export const createNewChat = async (params: CreateChatParams) => {
  const response = await chatInstance.post(`${URL_PREFIX_CHATS}`, {
    ...params,
    user_id: params.user_id,
  });

  return response.data ?? (response as unknown as IChatResponse);
};

export const getChatByUserId = async ({
  user_id,
  skip,
  limit,
  order,
  sort,
}: IChatHistoryParam) => {
  const skipParam = `&skip=${skip ?? 0}`;
  const limitParam = `&limit=${limit ?? 20}`;
  const sortParam = sort ? `&sort=${sort}` : '';
  const orderParam = order ? `&order=${order}` : '';
  try {
    const response: { data: IChatListResponse } = await chatInstance.get(
      `${URL_PREFIX_CHATS}?user_id=${user_id}${skipParam}${limitParam}${sortParam}${orderParam}`
    );
    return response?.data ?? response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const editChatTitle = async (chatId: number | string, title: string) => {
  try {
    const response: IChatResponse = await chatInstance.patch(
      `${URL_PREFIX_CHATS}/${chatId}`,
      {
        chat_id: chatId,
        title,
      }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const deleteChat = async (chatId: number | string) => {
  try {
    const response: IChatDeleteResponse = await chatInstance.delete(
      `${URL_PREFIX_CHATS}/${chatId}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getChatMsgById = async (chatId?: string) => {
  try {
    if (!chatId) return [];
    const response: { data: IChatMessageResponse[] } = await chatInstance.get(
      `${URL_PREFIX_CHATS}/${chatId}/messages`
    );

    const rawArr = response.data ? response.data : response;

    return (rawArr as IChatMessageResponse[]).map(
      (item) =>
        ({
          role: item.role,
          uuid: item.id.toString(),
          parentUuid: item.parent_id ? item.parent_id.toString() : 'root',
          message: item.content_metadata,
          content: item.content,
          createdAt: item.created_at,
        }) as IMessage
    );
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getChatModels = async () => {
  const response = await chatInstance.get(`${URL_PREFIX_CHATS}/models`);

  return response.data ?? response;
};

export const rebuildThinkingFromMessage = (
  setPlanAtoms: React.Dispatch<
    React.SetStateAction<{
      [chatID: string]: {
        plans: PlanInfo[];
        status?: string;
        parentId?: string;
      };
    }>
  >,
  message: IMessage,
  setCanvases: (
    fn: (prev: { [chatID: string]: CanvasInfo }) => {
      [chatID: string]: CanvasInfo;
    }
  ) => void,
  setCanvasDetail?: (uuid: string) => void,
  setCanvas?: React.Dispatch<React.SetStateAction<CanvasInfo>>,
  setGraphData?: React.Dispatch<React.SetStateAction<IGraph>>
) => {
  if (!message?.message && message?.role !== ERole.ASSISTANT) return;

  const chatID = message.uuid;

  // 이미 처리된 메시지인지 확인 (간단한 검증)
  if (!message.message || typeof message.message !== 'string') {
    return;
  }

  let metadataList: {
    type: string;
    content: string;
    description?: string;
    key?: string;
    title?: string;
  }[];

  try {
    metadataList = JSON.parse(message.message);
    if (!Array.isArray(metadataList)) {
      return;
    }
  } catch {
    return;
  }

  const plans: any[] = [];
  let planIndexRef = 0;
  let stepIndexRef = 0;
  let actionIndexRef = 0;

  for (const item of metadataList) {
    const { type, content, description, key, title } = item;
    if (!content) continue;

    switch (type) {
      case 'TOKEN':
      case 'token': {
        const prevPlanId = `${chatID}-plan-${planIndexRef}`;
        const prevPlan = plans[prevPlanId as any];
        const planIndex = planIndexRef + 1;
        const planId = `${chatID}-plan-${planIndex}`;
        const plan = plans[planId as any];
        stepIndexRef = 0;
        if (prevPlanId && plans[prevPlanId as any]) {
          plans[prevPlanId as any] = {
            ...prevPlan,
            status: EStatus.SUCCESS,
          };
        }

        planIndexRef = planIndex;

        plans[planId as any] = {
          ...plan,
          id: planId,
          name: content.trim(),
          status: EStatus.SUCCESS,
          type: EPlanType.TOKEN,
          tokenContent: content,
          steps: {},
        };
        break;
      }

      case 'AI_SLIDE':
      case 'ai_slide': {
        const htmlContent: any = {
          slide: { htmlContent: [], title: '' },
        };
        const prevPlanId = `${chatID}-plan-${planIndexRef}`;
        const prevPlan = plans[prevPlanId as any];
        const planIndex = planIndexRef + 1;
        const planId = `${chatID}-plan-${planIndex}`;
        const plan = plans[planId as any];
        stepIndexRef = 0;
        if (prevPlanId && plans[prevPlanId as any]) {
          plans[prevPlanId as any] = {
            ...prevPlan,
            status: EStatus.SUCCESS,
          };
        }

        planIndexRef = planIndex;

        plans[planId as any] = {
          ...plan,
          id: planId,
          name: title || content.trim(),
          status: EStatus.SUCCESS,
          type: EPlanType.SLIDE,
          canvas: {
            slide: {
              htmlContent: Array.from(
                new Set([...(htmlContent?.slide?.htmlContent ?? []), content])
              ),
              title,
              id: key,
              isNavigate: true,
              end: true,
              parentId: planId,
            },
          },
          steps: {},
        };
        break;
      }

      case 'ai_sheet':
      case 'AI_SHEET': {
        const prevPlanId = `${chatID}-plan-${planIndexRef}`;
        const prevPlan = plans[prevPlanId as any];
        const planIndex = planIndexRef + 1;
        const planId = `${chatID}-plan-${planIndex}`;
        const plan = plans[planId as any];
        stepIndexRef = 0;
        if (prevPlanId && plans[prevPlanId as any]) {
          plans[prevPlanId as any] = {
            ...prevPlan,
            status: EStatus.SUCCESS,
          };
        }

        planIndexRef = planIndex;

        plans[planId as any] = {
          ...plan,
          id: planId,
          name: title || content.trim(),
          status: EStatus.SUCCESS,
          type: EPlanType.SHEET,
          canvas: {
            sheet: {
              htmlContent: content,
              end: true,
              id: key,
              isNavigate: true,
              parentId: planId,
              title,
            },
          },
          steps: {},
        };
        break;
      }

      case 'canvas':
      case 'CANVAS': {
        const prevPlanId = `${chatID}-plan-${planIndexRef}`;
        const prevPlan = plans[prevPlanId as any];
        const planIndex = planIndexRef + 1;
        const planId = `${chatID}-plan-${planIndex}`;
        const plan = plans[planId as any];
        stepIndexRef = 0;
        if (prevPlanId && plans[prevPlanId as any]) {
          plans[prevPlanId as any] = {
            ...prevPlan,
            status: EStatus.SUCCESS,
          };
        }

        planIndexRef = planIndex;

        plans[planId as any] = {
          ...plan,
          id: planId,
          name: title || content.trim(),
          status: EStatus.SUCCESS,
          type: EPlanType.CANVAS,
          canvas: {
            canvas: {
              htmlContent: content,
              end: true,
              id: key,
              isNavigate: true,
              parentId: planId,
              title,
            },
          },
          steps: {},
        };
        break;
      }

      case 'graph':
      case 'GRAPH': {
        const graphContent: any = {
          graph: { graphContent: '', end: false, title: '' },
        };
        const prevPlanId = `${chatID}-plan-${planIndexRef}`;
        const prevPlan = plans[prevPlanId as any];
        const planIndex = planIndexRef + 1;
        const planId = `${chatID}-plan-${planIndex}`;
        const plan = plans[planId as any];
        stepIndexRef = 0;
        if (prevPlanId && plans[prevPlanId as any]) {
          plans[prevPlanId as any] = {
            ...prevPlan,
            status: EStatus.SUCCESS,
          };
        }

        planIndexRef = planIndex;

        plans[planId as any] = {
          ...plan,
          id: planId,
          name: content.trim(),
          status: EStatus.SUCCESS,
          type: EPlanType.GRAPH,
          graph: {
            ...graphContent.graph,
            graphContent: content,
            end: true,
            id: key,
            isNavigate: true,
            parentId: planId,
            title,
          },
          steps: {},
        };

        const cleaned = content.replace(/\\n/g, '').replace(/\\"/g, '"');
        setGraphData?.(
          typeof content === 'string' ? JSON.parse(cleaned) : content
        );

        break;
      }

      case 'PLAN_START':
      case 'plan_start': {
        const prevPlanId = `${chatID}-plan-${planIndexRef}`;
        const prevPlan = plans[prevPlanId as any];
        const planIndex = planIndexRef + 1;
        const planId = `${chatID}-plan-${planIndex}`;
        const plan = plans[planId as any];
        stepIndexRef = 0;
        if (prevPlanId && plans[prevPlanId as any]) {
          plans[prevPlanId as any] = {
            ...prevPlan,
            status: EStatus.SUCCESS,
          };
        }

        planIndexRef = planIndex;

        plans[planId as any] = {
          ...plan,
          id: planId,
          name: content.trim(),
          status: EStatus.SUCCESS,
          type: EPlanType.STEP_PLAN,
          steps: {},
        };
        break;
      }

      case 'STEP_START':
      case 'step_start': {
        const planId = `${chatID}-plan-${planIndexRef}`;
        const plan = plans[planId as any];
        actionIndexRef = 0;
        if (!plan) return plans;

        const stepIndex = stepIndexRef + 1;
        const stepId = `${planId}-step-${stepIndex}`;

        stepIndexRef = stepIndex;

        plans[planId as any] = {
          ...plan,
          steps: {
            ...plan?.steps,
            [stepId]: {
              id: stepId,
              name: content,
              status: EStatus.LOADING,
              actions: {},
              description,
            },
          },
        };
        break;
      }

      case 'THINKING':
      case 'WORKFLOW':
      case 'ROUTING': {
        const prevPlanId = `${chatID}-plan-${planIndexRef}`;
        const prevPlan = plans[prevPlanId as any];
        const planIndex = planIndexRef + 1;
        const planId = `${chatID}-plan-${planIndex}`;
        const plan = plans[planId as any];
        const stepId = `${planId}-step-${stepIndexRef}`;
        stepIndexRef = 0;
        if (prevPlanId && plans[prevPlanId as any]) {
          plans[prevPlanId as any] = {
            ...prevPlan,
            status: EStatus.SUCCESS,
          };
        }

        planIndexRef = planIndex;

        plans[planId as any] = {
          ...plan,
          id: planId,
          name: content.trim(),
          status: EStatus.SUCCESS,
          type: EPlanType.THINKING,
          steps: {
            [stepId]: {
              id: stepId,
              name: description,
              status: EStatus.SUCCESS,
            },
          },
        };

        break;
      }

      case 'ACTION_START':
      case 'action_start': {
        const planId = `${chatID}-plan-${planIndexRef}`;
        const plan = plans[planId as any];
        if (!plan) return plans;

        const currentSteps = plan.steps;
        const stepId = `${planId}-step-${stepIndexRef}`;
        const step = currentSteps[stepId];
        if (!step) return plans;

        const actionIndex = actionIndexRef + 1;
        const actionId = `${stepId}-action-${actionIndex}`;

        actionIndexRef = actionIndex;

        currentSteps[stepId] = {
          ...step,
          actions: {
            ...step.actions,
            [actionId]: {
              id: actionId,
              name: content,
              status: EStatus.LOADING,
              description,
            },
          },
        };

        break;
      }

      case 'ACTION_SUCCESS':
      case 'ACTION_FAIL':
      case 'action_success':
      case 'action_fail': {
        const planId = `${chatID}-plan-${planIndexRef}`;
        const plan = plans[planId as any];
        if (!plan) return plans;

        const currentSteps = plan.steps;
        const stepId = `${planId}-step-${stepIndexRef}`;
        const step = currentSteps[stepId];
        if (!step) return plans;

        const actions = { ...step.actions };
        const action: { id: string } = Object.values(actions).find(
          (a: any) => a.status === EStatus.LOADING
        ) as any;
        if (!action) return plans;

        actions[action.id] = {
          ...action,
          name: content,
          description: '',
          status: EStatus.SUCCESS,
        };

        break;
      }

      case 'STEP_END':
      case 'step_end': {
        const planId = `${chatID}-plan-${planIndexRef}`;
        const plan = plans[planId as any];
        if (!plan) return plans;

        const curSteps = plan?.steps;
        const step = Object.values(curSteps).find(
          (a: any) => a.status === EStatus.LOADING
        ) as any;
        if (!step) return plans;

        curSteps[step.id] = {
          ...step,
          name: content,
          status: EStatus.SUCCESS,
        };

        break;
      }

      case 'plan_end':
      case 'PLAN_END':
        break;

      default:
        break;
    }
  }

  setPlanAtoms((prev) => ({
    ...prev,
    [chatID]: {
      id: chatID,
      plans,
      // steps,
      status: EStatus.SUCCESS,
      parentId: message.uuid,
    },
  }));

  // 캔버스 데이터가 있는 plans를 canvasAtoms에도 동기화
  if (setCanvases) {
    setCanvases((prev) => {
      const newCanvases = { ...prev };

      // plans 객체의 각 plan을 확인하여 canvas 데이터가 있으면 canvasAtoms에 저장
      Object.values(plans).forEach((plan: any) => {
        if (plan && plan.canvas && plan.id) {
          newCanvases[plan.id] = plan.canvas;
        }
      });

      return newCanvases;
    });
  }
};

export const getDetailChat = async (chat_id: string) => {
  try {
    const response: { data: IChatResponse } = await chatInstance.get(
      `${URL_PREFIX_CHATS}/${chat_id}`
    );
    return response?.data ?? response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const createNewChatTitle = async (chat_id: string, rawMsg: string) => {
  try {
    const response: { data: string } = await chatInstance.post(
      `${URL_PREFIX_CHATS}/${chat_id}`,
      {
        content: rawMsg,
      }
    );
    return response?.data ?? response;
  } catch (error) {
    console.error('Error creating chat title:', error);
    throw error;
  }
};
