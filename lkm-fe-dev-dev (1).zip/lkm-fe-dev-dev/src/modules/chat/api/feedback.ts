import { axiosInstance } from '@/modules/core/libs';
import { IFeedback } from '@/modules/chat/types/feedback';
import { IHistoryResponse } from '@/modules/chat/types/history';

const URL_PREFIX = '/core/chat';

export const updateChatFeedback = async (
  history_id: number | string,
  message_uuid: string,
  feedback: IFeedback
) => {
  const body = {
    flag: feedback.flag,
    comment: feedback.comment,
  };
  const response: IHistoryResponse = await axiosInstance.put(
    `${URL_PREFIX}/history/${history_id}/message/${message_uuid}/feedback`,
    body
  );

  return response;
};
