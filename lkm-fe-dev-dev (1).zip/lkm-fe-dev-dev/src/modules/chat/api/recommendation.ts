import { axiosInstance } from '@/modules/core/libs';

const URL_PREFIX = '/core/chat';

export const getRecommendationData = async (
  historyId: number,
  messageUuid: string
) => {
  const response: any = await axiosInstance.get(
    `${URL_PREFIX}/history/${historyId}/message/${messageUuid}/recommendation`
  );
  return response;
};
