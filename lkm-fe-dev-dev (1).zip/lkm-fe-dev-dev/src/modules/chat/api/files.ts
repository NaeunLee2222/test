import { fileInstance } from '@/modules/core/libs';
import { getUserIdFromCookie } from '@/utils';
import { IFilesResponse } from '../types/files';

const URL_PREFIX_USER_FILE_DRIVE = '/user_file_drive/files';

export const uploadFile = async ({
  files,
  userId,
}: {
  files: File[];
  userId: string | number;
}) => {
  try {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append(`files`, file);
    });

    formData.append('user_id', userId.toString());

    const response: any = await fileInstance.post(
      `${URL_PREFIX_USER_FILE_DRIVE}/upload`,
      formData,
      {
        headers: {
          'content-type': 'multipart/form-data',
          'Accept': 'application/json',
        },
      }
    );
    return response;
  } catch (error) {
    console.error({ error });
  }
};

export const getCloudFiles = async () => {
  try {
    const response:
      | { data: { files: IFilesResponse[] } }
      | { files: IFilesResponse[] } = await fileInstance.get(
      `${URL_PREFIX_USER_FILE_DRIVE}?user_id=${getUserIdFromCookie()}&limit=100000000000`
    );
    if ('data' in response) {
      return response.data;
    }

    return response;
  } catch (error) {
    console.error({ error });
  }
};

export const attachFileToChat = async ({
  data,
}: {
  data: {
    chat_id: string;
    file_ids: string[] | number[];
  };
}) => {
  try {
    const response: any = await fileInstance.post(
      `${URL_PREFIX_USER_FILE_DRIVE}/chat/${data.chat_id}/attach-file`,
      {
        user_file_ids: data.file_ids,
      }
    );
    return response;
  } catch (error) {
    console.error({ error });
  }
};

export const onDeleteCloudFile = async ({
  file_id,
}: {
  file_id: string | number;
}) => {
  try {
    const response: any = await fileInstance.delete(
      `${URL_PREFIX_USER_FILE_DRIVE}/${file_id}?user_id=${getUserIdFromCookie()}`
    );
    return response;
  } catch (error) {
    console.error({ error });
  }
};
