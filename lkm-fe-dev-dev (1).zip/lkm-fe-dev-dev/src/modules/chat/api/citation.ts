import { axiosInstance } from '@/modules/core/libs';

const URL_PREFIX = '/core/chat';

export const getCitationData = async (
  historyId: number,
  messageUuid: string,
  citationId: number,
  company?: string
) => {
  const response: any = await axiosInstance.get(
    `${URL_PREFIX}/history/${historyId}/message/${messageUuid}/citation/${citationId}${company ? `?company=${company}` : ''}`
  );
  return response;
};

export const getSecretCitationData = async (citationId: string) => {
  const response: any = await axiosInstance.get(
    `${URL_PREFIX}/history/secret/citation/${citationId}`
  );
  return response;
};

export const getReportCitationData = async (
  reportCardId: number,
  reportSectionId: number,
  citationId: string
) => {
  const response: any = await axiosInstance.get(
    `/core/report/card/${reportCardId}/section/${reportSectionId}/citation/${citationId}`
  );
  return response;
};

export const deleteReportCitation = async (
  reportCardId: number,
  reportSectionId: number,
  citationId: string
) => {
  const response: any = await axiosInstance.delete(
    `/core/report/card/${reportCardId}/section/${reportSectionId}/citation/${citationId}`
  );
  return response;
};

export const searchReportCitationData = async (
  reportCardId: number,
  reportSectionId: number,
  search: string
) => {
  const response: any = await axiosInstance.get(
    `/core/report/card/${reportCardId}/section/${reportSectionId}/citation/search?search=${search}`
  );
  return response;
};

export const searchChatCitationData = async (
  messageUuid: string,
  search: string
) => {
  const response: any = await axiosInstance.get(
    `${URL_PREFIX}/message/${messageUuid}/citation/search?search=${search}`
  );
  return response;
};

export const updateReportCitationData = async (
  reportCardId: number,
  reportSectionId: string,
  citationIdList: string[]
) => {
  const response: any = await axiosInstance.post(
    `/core/report/card/${reportCardId}/section/${reportSectionId}/citation`,
    {
      citation_id_list: citationIdList,
    }
  );
  return response;
};
