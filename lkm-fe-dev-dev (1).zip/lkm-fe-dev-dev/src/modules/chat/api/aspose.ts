import { chatInstance } from '@/modules/core/libs';

const URL_PREFIX = 'aspose';
const URL_PDF = 'html-to-pdf';
const URL_DOCX = 'html-to-docx';

/**
 * Convert HTML to PDF
 * @param id
 * @returns
 */
export const postHTMLToPDF = async (id: string): Promise<Blob> => {
  try {
    const response: Blob = await chatInstance.post(
      `${URL_PREFIX}/${URL_PDF}?canvas_uuid=${id}`,
      null,
      { responseType: 'blob' }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Convert HTML to DOCX
 * @param id
 * @returns
 */
export const postHTMLToDOCX = async (id: string): Promise<Blob> => {
  try {
    const response: Blob = await chatInstance.post(
      `${URL_PREFIX}/${URL_DOCX}?canvas_uuid=${id}`,
      null,
      { responseType: 'blob' }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};
