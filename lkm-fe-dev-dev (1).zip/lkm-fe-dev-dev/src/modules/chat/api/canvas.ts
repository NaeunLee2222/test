import {
  ETYPEHTML,
  GetCanvasParams,
  IGetCanvasByIdResponse,
  IGetCanvasResponse,
} from '@/modules/chat/types/canvas';
import { chatInstance } from '@/modules/core/libs';

const CANVAS_URL = '/canvas';
const URL_PREFIX_CANVAS = '/canvas';

export const getCanvasById = async (canvasId: string, deltas = true) => {
  const response: any = await chatInstance.get(
    `${URL_PREFIX_CANVAS}/${canvasId}?deltas=${deltas}`
  );
  return response;
};

export const getDiffByCanvasId = async (canvasId: string) => {
  const response: any = await chatInstance.get(
    `${URL_PREFIX_CANVAS}/${canvasId}/diff`
  );
  return response;
};

export const updateCanvas = async (
  content: string,
  version: number,
  canvasId: string,
  diff: any
) => {
  const response: IGetCanvasByIdResponse = await chatInstance.put(
    `${URL_PREFIX_CANVAS}/${canvasId}`,
    {
      content,
      version,
      diff,
    }
  );

  return response;
};

export const getCanvas = async (
  params: GetCanvasParams & { userId: string | number }
) => {
  try {
    const { skip, limit, order, title, userId, type } = params;
    const orderParam = order ? `&order=${order}` : '';
    const nameParam = title ? `title=${title}` : '';
    const typeParam = type === ETYPEHTML.ALL || !type ? '' : `&type=${type}`;
    const response: { data: IGetCanvasResponse } = await chatInstance.get(
      `${CANVAS_URL}/canvas/${userId}?${nameParam}&skip=${skip}&limit=${limit}${orderParam}${typeParam}`
    );

    return response.data ?? response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const deleteCanvas = async (canvas_uuid: string) => {
  const response: any = await chatInstance.delete(
    `${URL_PREFIX_CANVAS}/${canvas_uuid}`
  );
  return response;
};
