import {
  IHistoryMessage,
  IHistoryResponse,
} from '@/modules/chat/types/history';
import { axiosInstance } from '@/modules/core/libs';

const URL_PREFIX = '/core/chat';

export const getHistoryList = async (
  offset?: number,
  search?: string,
  libraryId?: number,
  includeContent?: boolean,
  limit?: number
) => {
  const queryParams = [];

  if (offset) queryParams.push(`offset=${offset}`);
  if (search) queryParams.push(`search=${search}`);
  if (libraryId && libraryId !== -1)
    queryParams.push(`library_id=${libraryId}`);
  if (limit) queryParams.push(`limit=${limit}`);
  if (includeContent) queryParams.push(`include_content=${includeContent}`);

  const response: IHistoryResponse = await axiosInstance.get(
    `${URL_PREFIX}/history${queryParams.length ? `?${queryParams.join('&')}` : ''}`
  );

  return response;
};

export const patchHistoryTitle = async (id: number, title: string) => {
  const response: IHistoryMessage = await axiosInstance.patch(
    `${URL_PREFIX}/history/${id}`,
    {
      title,
    }
  );
  return response;
};

export const deleteHistoryById = async (id: number) => {
  const response: IHistoryMessage = await axiosInstance.delete(
    `${URL_PREFIX}/history/${id}`
  );
  return response;
};

export const deleteAllHistory = async (type: 'all' | 'no_library') => {
  const response: IHistoryMessage = await axiosInstance.delete(
    `${URL_PREFIX}/history?type=${type}`
  );
  return response;
};
