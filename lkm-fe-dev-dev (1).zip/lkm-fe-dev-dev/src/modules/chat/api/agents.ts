import {
  AgentDto,
  IActionInfoRes,
  IActionPost,
  IAgentCreationResponse,
  IAgentGeneralResponse,
  IFileResponse,
  IGeneralToolResponse,
  IInstructionResponse,
  IToolListResponse,
} from '@/modules/agent/type/agent';
import { agentInstance } from '@/modules/core/libs';
import { getUserIdFromCookie } from '@/utils/commonUtil';
import {
  IChatAgentPutRequest,
  IGetChatAgentListResponse,
} from '../types/agents';

const AGENT_URL = '/agents';
const MY_AGENT_URL = '/my_agents';
const URL_PREFIX_ACTION_INFO = '/action_info?action_id';

export const getAgent = async (params: {
  skip: number;
  limit: number;
  category: string;
  reviewStatus: string;
  order: string;
  usageScope: string;
  name: any;
}) => {
  try {
    const { skip, limit, category, reviewStatus, order, usageScope, name } =
      params;
    const categoryParam = category ? `&category=${category}` : '';
    const usageScopeParam = usageScope ? `&usage_scope=${usageScope}` : '';
    const reviewStatusParam = reviewStatus
      ? `&review_status=${reviewStatus}`
      : '';
    const orderParam = order ? `&order=${order}` : '';
    const nameParam = name ? `&name=${name}` : '';

    const response: { data: IGetChatAgentListResponse } =
      await agentInstance.get(
        `${AGENT_URL}?skip=${skip}&limit=${limit}${categoryParam}${usageScopeParam}${reviewStatusParam}${orderParam}${nameParam}`
      );

    return response.data ?? response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getMyAgent = async (
  skip: number,
  limit: number,
  category: string,
  order: string,
  name: any
) => {
  try {
    const categoryParam = category ? `&category=${category}` : '';
    const orderParam = order ? `&order=${order}` : '';
    const nameParam = name ? `&name=${name}` : '';

    const response: { data: IGetChatAgentListResponse } =
      await agentInstance.get(
        `${MY_AGENT_URL}?skip=${skip}&limit=${limit}${categoryParam}${orderParam}${nameParam}`
      );

    return response.data ?? response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getAgentDetail = async (id: number) => {
  try {
    const userId = getUserIdFromCookie();
    const response: any = await agentInstance.get(
      `${AGENT_URL}/${id}${userId ? `?user_id=${userId}` : ''}`
    );
    return response.data ?? response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Get all available tools when creating an agent.
 * @returns All available tools
 */
export const getAgentTools = async (): Promise<IToolListResponse> => {
  try {
    const response: any = await agentInstance.get(`/tools`);
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Create an agent based on provided information.
 * @param agent
 * @returns
 */
export const createBasicAgent = async (agent: AgentDto) => {
  try {
    const response: IAgentCreationResponse = await agentInstance.post(
      `${AGENT_URL}`,
      agent
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Create an agent based on provided information.
 * @param agent
 * @returns
 */
export const createAgent = async (agent: IChatAgentPutRequest) => {
  try {
    const response: any = await agentInstance.post(`${AGENT_URL}`, agent);
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Update an agent based on provided information.
 * @param agent
 * @returns
 */
export const updateAgent = async (agent: IChatAgentPutRequest) => {
  try {
    const response: any = await agentInstance.put(
      `${AGENT_URL}/${agent.agent.id}`,
      agent
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Upload the document of business procedures.
 * @param file
 * @returns
 */
export const uploadAgentDocument = async (
  path: string,
  file: FormData
): Promise<IFileResponse> => {
  try {
    const response: IFileResponse = await agentInstance.post(path, file, {
      headers: { 'content-type': 'multipart/form-data' },
    });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Uses AI to generate agent's instruction
 * @param payload
 * @returns
 */
export const generateInstruction = async (
  payload: FormData
): Promise<IInstructionResponse> => {
  try {
    const response: IInstructionResponse = await agentInstance.post(
      `/instruction_ai`,
      payload,
      {
        headers: { 'content-type': 'multipart/form-data' },
      }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Uses AI to generate agent's recommended tools for basic mode
 * @param payload
 * @returns
 */
export const generateRecommendedTools = async (
  payload: FormData
): Promise<IGeneralToolResponse> => {
  try {
    const response: any = await agentInstance.post(
      `/recommend_tools`,
      payload,
      {
        headers: { 'content-type': 'multipart/form-data' },
      }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Uses AI to generate agent's recommended tools for basic mode
 * @param payload
 * @returns
 */
export const getAllTools = async (): Promise<IGeneralToolResponse> => {
  try {
    const response: IGeneralToolResponse = await agentInstance.get(`/tools`);
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getAgentGeneralDetails = async (agent_id: string) => {
  try {
    const response: IAgentGeneralResponse = await agentInstance.get(
      `${AGENT_URL}/${agent_id}/general`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getActionInfo = async (action_id: string) => {
  try {
    const response: IActionInfoRes = await agentInstance.get(
      `${URL_PREFIX_ACTION_INFO}=${action_id}`
    );

    return response.data;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const updateAction = async ({
  payload,
  action_id,
}: {
  payload: IActionPost;
  action_id: string;
}) => {
  try {
    const response = await agentInstance.post(
      `${URL_PREFIX_ACTION_INFO}=${action_id}`,
      payload
    );

    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};
