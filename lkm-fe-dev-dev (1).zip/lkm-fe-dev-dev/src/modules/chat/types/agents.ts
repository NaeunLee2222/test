export interface IGetChatAgentListResponse {
  'success': boolean;
  'message': string | null;
  'agents': IChatAgentResponse[];
  'total': number;
  'skip': number;
  'limit': number;
}

export interface IChatAgentDetailResponse {
  'success': true;
  'message': string;
  'agent': IChatAgentResponse;
}

export interface IChatAgentResponse {
  'name': string;
  'description': string;
  'reject_description': string;
  'category'?: string;
  'usage_scope'?: string;
  'org_id'?: number;
  'team_id'?: number;
  'id': number;
  'created_user_id': number;
  'created_at': string;
  'updated_at'?: string;
  'steps'?: IChatAgentStepResponse[];
  'agent_type'?: string;
  'review_status'?: EChatAgentStatus;
  'use_count'?: number;
  'chat_starters'?: string[];
  'administer_id'?: number;
}
export interface AgentInstructionDto {
  instruction: string;
  tool_ids: (number | null)[];
}

export interface IChatStarter {
  'id': number;
  'starter': string;
}

export interface IChatAgentPutRequest {
  'agent': IChatAgentResponse;
  'general_agent_instruction': AgentInstructionDto;
  'chat_starters'?: IChatStarter[];
}

export interface IChatAgentToolConfig {
  'name': string;
  'type': string;
  'required': boolean;
  'description': string;
  'items': {
    'type': string;
  };
}

export interface IChatAgentToolResponse {
  'name': string;
  'description': string;
  'type'?: string;
  'icon_path'?: string | null;
  'id': number | null;
  'created_at'?: string;
  'updated_at'?: string;
  'config'?: IChatAgentToolConfig[];
  'tool_group_id'?: number;
}

export interface IChatAgentStepActionResponse {
  'name': string;
  'description'?: string;
  'order'?: number;
  'id': number | null;
  'step_id'?: number;
  'tools': IChatAgentToolResponse[];
}

export interface IChatAgentStepResponse {
  'name': string;
  'description': string;
  'order': number;
  'id': number | null;
  'expert_agent_id': number;
  'created_at'?: string;
  'updated_at'?: string | null;
  'actions': IChatAgentStepActionResponse[];
}

interface IChatAgentTool {
  'name': string;
  'description': string;
  'type': string;
  'iconPath': string | null;
  'id': number;
  'createdAt': string;
  'updatedAt'?: string;
  'config': IChatAgentToolConfig[];
}

interface IChatAgentStepAction {
  'name': string;
  'description': string;
  'order'?: number;
  'id': number;
  'step_id'?: number;
  'tools': IChatAgentTool[];
}

export interface IChatAgentStep {
  'id': string;
  'name': string;
  'order': number;
  'description': string;
  'expertAgentId': number;
  'createdAt': string;
  'updatedAt'?: string;
  'actions'?: IChatAgentStepAction[];
}

interface IChatAgentStats {
  'runs': number;
  'avgRuntime': number;
  'successRate': number;
}

export enum EChatAgentStatus {
  PENDING = 'pending',
  DEPLOYED = 'deployed',
  SAVED = 'saved',
  REJECTED = 'rejected',
  SUBMITTED = 'submitted',
  PRIVATE = 'private',
  TESTING = 'testing',
}

export enum EUsageScope {
  PUBLIC = 'public',
  ORG = 'org',
}

export interface IChatAgent {
  id: string;
  name?: string;
  description?: string;
  rejectDescription?: string;
  category?: string;
  createdAt?: string;
  updatedAt?: string;
  reviewStatus?: EChatAgentStatus;
  hits?: number;
  usageScope?: string;
  steps?: IChatAgentStep[];
  createdUserId?: number;
  teamId?: number;
  stats?: IChatAgentStats;
  rating?: number;
  isPro?: boolean;
  question?: string;
  agentType?: string;
  useCount?: number;
  mode?: string;
  orgId?: number;
}

export type GetAgentParams = {
  skip: number;
  limit: number;
  category: string;
  usageScope: string;
  agentType: any;
  reviewStatus: any;
  order: string;
  isMyAgent: boolean;
  name: string;
  updated?: number;
};

export const AGENT_TAB_KEY = 'agent-selected-tab';
