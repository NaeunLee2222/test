import { EChatScope, EChatType } from '@/modules/core/types';

export interface IChatScroll {
  isAtTop: boolean;
  isAtBottom: boolean;
  userScrolled: boolean;
  isOverflowing: boolean;
  isAutoScrolling: boolean;
}

export interface IAbortData {
  abortController: AbortController;
  isAbort: boolean;
}

export enum PPTXMode {
  SLIDE_CARD = 'slide_card',
  NORMAL = 'normal',
}

export interface ITool {
  isSelectedCanvas: boolean;
  selectedMode: string | null;
  isSelectedAISlide?: boolean;
  isSelectedGraph?: boolean;
  isSelectedTestAgent?: boolean;
}

export enum EChatMode {
  AGENT_CHAT = 'agent_chat',
  WORKFLOW_STUDIO = 'workflow_studio',
  GENERAL_CHAT = 'general_chat',
}

export interface IChatResponse {
  'id': string | number;
  'user_id': number;
  'agent_id': number;
  'title': string;
  'model': string;
  'config': {
    'chat_mode': EChatMode;
  };
  'created_at': string;
  'updated_at': string;
  'agent_name': string;
  'chat_type': EChatType;
  'usage_scope'?: EChatScope;
}

export interface IChatListResponse {
  'chat_list': IChatResponse[];
  total: number;
  skip: number;
  limit: number;
}

export interface IChatDeleteResponse {
  'success': boolean;
  'chat_id': string;
}

export interface IChatMessageResponse {
  uuid: any;
  'id': string;
  'chat_id': number | string;
  'parent_id': string | null;
  'content': string;
  'role': ERole;
  'content_metadata'?: string;
  'attachment': string | null;
  'created_at': string;
  'updated_at'?: string;
}

export enum ERole {
  USER = 'user',
  AI = 'ai',
  ASSISTANT = 'assistant',
}

export type CreateChatParams = {
  'user_id': number | string;
  'agent_id'?: number | string;
  'title': string;
  'model': string;
  'config': {
    'chat_mode': EChatMode;
  };
  'chat_type': EChatType;
};

export interface ISendMessage {
  message: string;
  libraryId?: number;
  agentId?: string | number;
  chat_type?: string;
  isAi?: boolean;
  isGraph?: boolean;
  isTestAgent?: boolean;
  isSuperChat?: boolean;
  userId?: string | number;
  chatTitle?: string;
  chatType?: string;
  toolGroupIds?: (string | number)[];
}

export enum EChatBubbleType {
  CHAT = 'chat',
  VIEW = 'view',
  REPORT = 'report',
  INFO = 'info',
  INIT = 'init',
  WORKFLOW_REPORT = 'workflow-report',
}

export interface IChatHistoryParam {
  'user_id': number;
  skip: number;
  limit: number;
  sort?: ESort;
  order?: EOrder;
}

export enum ESort {
  CREATE_AT = 'created_at',
  UPDATED_AT = 'updated_at',
}

export enum EOrder {
  ASC = 'asc',
  DES = 'des',
  DESC = 'desc',
}

export enum ChatType {
  GENERAL = 'general',
  SUPERVISOR = 'supervisor',
  SUPERCHAT = 'superchat',
}

export const DEFAULT_CHAT_MODEL = 'OpenAI 4o';
