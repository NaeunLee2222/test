export enum EFileStatus {
  WAIT = 'WAIT',
}

export interface IFilesResponse {
  user_id: string | number;
  original_filename: string;
  uuid_filename: string;
  file_path: string;
  file_type: string;
  file_size: number;
  state: EFileStatus;
  user_file_id: number | string;
  file_id: number | string;
  created_at: string;
  updated_at?: string;
}

export interface IUploadedFile {
  id?: string | number;
  fileId: string | number;
  type: EUploadFileType;
  name: string;
  modified?: string | number;
  fileSize: number;
}

export enum EUploadFileType {
  DOC = 'doc',
  PDF = 'pdf',
}

export const ACCEPT_FILE_TYPES = '.pdf, .docx, .doc, .txt, .jpg, .jpeg, .png';
