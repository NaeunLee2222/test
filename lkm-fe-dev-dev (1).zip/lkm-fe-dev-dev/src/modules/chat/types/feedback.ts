import { IChatBubbleType } from '@/types/layout';

export interface IFeedback {
  id?: number;
  message_uuid?: string;
  flag?: number;
  comment?: string;
  createdAt?: string;
}

export interface IFeedbackDialog {
  open: boolean;
  message_uuid: string;
  feedback: IFeedback;
  bubbleType: IChatBubbleType;
}
