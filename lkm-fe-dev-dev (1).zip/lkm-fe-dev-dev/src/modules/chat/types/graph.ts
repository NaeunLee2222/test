export interface IGraph {
  nodes: {
    id: string;
    label: string;
    description: string;
    weight: number;
    color: string;
  }[];
  edges: {
    source: string;
    target: string;
    description: string;
    label: string;
  }[];
  metadata?: {
    model: string;
    deployment: string;
    endpoint: string;
    node_count: number;
    edge_count: number;
  };
}
