import { ERole } from '@/modules/chat/types/chat';
import { MessageType } from '@/modules/chat/types/message';

export interface ILibraryDialog {
  dialogOpen: boolean;
  id: number;
  title: string;
  createdAt: string;
  targetHistoryId: number;
  type: 'select' | 'update' | 'create' | 'auto';
}

export interface ILibrary {
  id: number;
  title: string;
  createdAt: string;
  updatedAt: string;
  historyIdList: number[];
}

export interface ILibraryResponse {
  id: number;
  title: string;
  history_id_list: string[];
  create_dt: string;
  update_dt: string;
}

export interface ILibraryListResponse {
  library_list: ILibraryResponse[];
}

export interface IHistory {
  id: number;
  title: string;
  content?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface IHistoryResponse {
  history_list: any[];
  total_count: number;
  next_offset?: number;
}
export interface IHistoryCitation {
  id: string;
  title: string;
  original_url: string;
  law_type: string;
  type: string;
  config: {
    index_in_message: number;
    is_referenced_in_answer: boolean;
  };
}

export interface IHistoryMessage {
  uuid: string;
  parent_uuid: string;
  role: ERole;
  type: MessageType;
  message: string;
  feedback: {
    flag: number;
    comment: string;
  };
  thought: string;
  config?: {
    is_pro?: boolean;
    is_aborted?: boolean;
    version?: string;
    label?: string[];
  };
  citations?: IHistoryCitation[];
  recommendations?: string[];
  create_dt: string;
}
