export interface WActionInfo {
  id?: string;
  name: string;
  content?: string;
  description: string;
}

export interface WStepInfo {
  id?: string;
  name: string;
  actions: WActionInfo[];
  description: string;
}

export interface WPlanInfo {
  id?: string;
  steps: WStepInfo[];
  parentId?: string;
  error?: string;
}
export interface ActionInfo {
  id: string;
  name: string;
  status?: EStatus;
  content?: string;
  description: string;
}

export enum EStatus {
  LOADING = 'loading',
  SUCCESS = 'success',
  FAIL = 'fail',
  INCOMPLETE = 'incomplete',
}

export enum EPlanType {
  STEP_PLAN = 'step_plan',
  CANVAS = 'canvas',
  TOKEN = 'token',
  SLIDE = 'slide',
  THINKING = 'thinking',
  SHEET = 'sheet',
  GRAPH = 'graph',
}

export interface StepInfo {
  id: string;
  name: string;
  status?: EStatus;
  actions: { [key: string]: ActionInfo };
  description: string;
}

export interface PlanInfo {
  id: string;
  steps: {
    [key: string]: StepInfo;
  };
  name?: string;
  status?: EStatus;
  parentId?: string;
  canvas?: CanvasInfo;
  type?: EPlanType;
  tokenContent?: string;
}

export interface CanvasInfo {
  canvas?: {
    htmlContent?: string;
    end?: boolean;
    title?: string;
    isNavigate?: boolean;
    id?: string;
    parentId?: string;
  };
  sheet?: {
    htmlContent?: string;
    end?: boolean;
    title?: string;
    isNavigate?: boolean;
    id?: string;
    parentId?: string;
  };
  slide?: {
    htmlContent?: string[];
    title?: string;
    isNavigate?: boolean;
    end?: boolean;
    id?: string;
    parentId?: string;
  };
  graph?: {
    graphContent?: string;
    end?: boolean;
    title?: string;
    isNavigate?: boolean;
    id?: string;
    parentId?: string;
  };
  token?: {
    tokenContent?: string;
    id?: string;
    parentId?: string;
  };
  originalCanvas?: string;
}
