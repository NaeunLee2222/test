export interface IEditingIndex {
  step: string;
  action: string;
}

export interface UpdateStepFormData {
  content: string | undefined;
  description: string;
  toolGroupId: number;
  toolId: number;
}
