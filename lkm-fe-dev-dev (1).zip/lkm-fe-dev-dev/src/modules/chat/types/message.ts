import { ERole } from '@/modules/chat/types/chat';
import { IFeedback } from '@/modules/chat/types/feedback';

export interface IThought {
  title: string;
  content: string;
}

export interface IConfig {
  isAborted?: boolean;
  isPro?: boolean;
  version?: string;
  label?: string[];
}

export interface ICitation {
  historyId?: number | string;
  messageUuid?: string;
  id: string;
  title: string;
  originalUrl?: string;
  type: string;
  bubbleType?: string;
  lawType?: string;
  content?: string;
  summary?: string;
  indexInMessage?: number;
  isReferencedInAnswer?: boolean;
  company?: string;
}

export interface IRecommendations {
  historyId: number | string;
  messageUuid: string;
}

export type MessageType =
  | 'text'
  | 'loading'
  | 'error'
  | 'canvas'
  | 'workflow-report'; // add canvas type for mock data, fix after have API

export enum EMessageType {
  TEXT = 'text',
  LOADING = 'loading',
  ERROR = 'error',
  CANVAS = 'canvas',
}

export enum EChatToolMode {
  RTDB = 'rtdb',
  PRESENTATION = 'ai_slide',
  OUTLOOK = 'outlook',
  TEAMS = 'teams',
  DOC = 'doc',
  DEFAULT = '',
}

export interface IMessage {
  role: ERole;
  type?: EMessageType | MessageType;
  uuid: string;
  parentUuid?: string;
  message: string;
  createdAt?: string;
  feedback?: IFeedback;
  thought?: IThought[];
  config?: IConfig;
  citations?: ICitation[];
  content: string;
}

export interface IMessageRequest {
  parent_id: string | null;
  id: string;
  role: ERole;
  content: string;
}

export interface IMessageResponse {
  uuid: string;
  content: string;
  type: 'token' | 'text' | 'loading';
}

export interface IChat {
  prevHistoryId?: number | string;
  historyId?: number | string;
  title?: string;
  messages: {
    [key: string]: IMessage;
  };
  isGenerating: boolean;
  userInput: string;
  isPro: boolean;
  isSecretMode?: boolean;
  chatVersion?: string;
  userData?: {
    userId: string;
    userName?: string;
    company?: string;
    [key: string]: any;
  };
  selectedChatMode: EChatToolMode;
  selectedAgent?: number;
  updated?: number;
  isAiInitiated?: boolean;
}

export enum EUploadMode {
  LOCAL = 'local',
  CLOUD = 'cloud',
}
