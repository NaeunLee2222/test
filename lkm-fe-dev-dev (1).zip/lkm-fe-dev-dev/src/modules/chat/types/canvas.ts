import { JSXElementConstructor, MutableRefObject, ReactElement } from 'react';
import { CustomElement } from '../components/DocumentEditor/editor/interface';

export interface ICanvas {
  isDisabledChatAgent: boolean;
  content: string;
  contentHistory: string[];
  isGenerated: boolean;
  current_version?: number;
}

export interface ISelectedContent {
  elementId: string;
  elementRef?: MutableRefObject<HTMLDivElement> | null;
  originalContent: string;
  top: number;
  bottom: number;
  active?: boolean;
}

export interface IActionStatus {
  key: string;
  disable: boolean;
}

export interface ICanvasActionProps {
  actions: ICanvasAction[];
}

export interface ICanvasAction {
  key: string;
  icon: ReactElement<any, string | JSXElementConstructor<any>>;
  name: string;
  disabled?: boolean;
  onClick: (event?: React.MouseEvent<HTMLButtonElement>) => void;
}

export type ToolbarRef = {
  handleCopy: () => void;
  handleOpenCanvasHistory: () => void;
};

export interface ToolbarProps {
  onCheckStatus?: (actionStatus: IActionStatus[]) => void;
}

export interface ILineChange {
  type: 'added' | 'removed' | 'unchanged';
  content: string;
  line_number: number;
}

export interface IDelta {
  line_changes: ILineChange[];
}

export interface IGetCanvasByIdResponse {
  canvas: ICanvas;
  deltas: {
    delta: IDelta;
  };
  setDiffValue: (...args: any[]) => void;
  setValue: (value: CustomElement[]) => void;
}

export enum ACTIONTYPE {
  HISTORY = 'history',
  BACK = 'back',
  NEXT = 'next',
  COPY = 'copy',
  DOWNLOAD = 'download.tooltip',
}

export enum ETYPEHTML {
  ALL = 'all',
  CANVAS = 'canvas',
  AI_SLIDE = 'ai_slide',
}

export enum EORDERHTML {
  TITLE_ASC = 'title_asc',
  TITLE_DESC = 'title_desc',
  POPULARITY = 'popularity',
  LATEST = 'latest',
}

export const FILE_LIBRARY_TAB_KEY = 'file-library-selected-tab';

export type GetCanvasParams = {
  skip?: number;
  limit?: number;
  order?: EORDERHTML;
  title?: string;
  updated?: number;
  type?: ETYPEHTML;
};

export interface ICanvasDetailResponse {
  'chat_id': string;
  'title': string | null;
  'uuid': string;
  'current_version': number;
  'content': string;
  'created_at'?: string;
  'updated_at'?: string;
}

export interface IGetCanvasResponse {
  'chat_id': string | null;
  'canvases': ICanvasDetailResponse[];
  'total': number;
  'skip': number;
  'limit': number;
  'title': string | null;
}

export interface ICanvasDetail {
  'chatId': string;
  'title': string | null;
  'uuid': string;
  'currentVersion': number;
  'content': string;
  'createdAt'?: string;
  'updatedAt'?: string;
}
