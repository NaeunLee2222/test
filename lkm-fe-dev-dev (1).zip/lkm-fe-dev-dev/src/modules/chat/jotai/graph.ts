import { IGraph } from '@/modules/chat/types/graph';
import { atom } from 'jotai';
import { atomWithStorage } from 'jotai/utils';

export const graphDataAtom = atomWithStorage<IGraph>('graphData', {
  nodes: [],
  edges: [],
  metadata: {
    model: '',
    deployment: '',
    endpoint: '',
    node_count: 0,
    edge_count: 0,
  },
});

export const graphTitleAtom = atom<string>('');
