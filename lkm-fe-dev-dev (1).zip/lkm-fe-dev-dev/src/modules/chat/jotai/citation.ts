import { ICitation } from '@/modules/chat/types/message';
import { atom } from 'jotai';

// ==============================
// Citation Atoms
// ==============================
export const citation = {
  id: '',
  title: '',
  originalUrl: '',
  type: '',
  historyId: -1,
  messageUuid: '',
  summary: '',
  company: '',
};

export const citationAtom = atom<ICitation>(citation);

export const citationDataAtom = atom(
  (get) => get(citationAtom),
  (get, set, update: Partial<ICitation>) =>
    set(citationAtom, { ...get(citationAtom), ...update })
);

// ==============================
// Search Citation Atoms
// ==============================
type ParentType = 'chat_message' | 'report_section' | '';

interface SearchCitationAtom {
  parentId: string;
  parentType: ParentType;
  searchQuery: string;
}

export const searchCitationAtom = atom<SearchCitationAtom>({
  parentId: '',
  parentType: '',
  searchQuery: '',
});

export const searchCitationDataAtom = atom(
  (get) => get(searchCitationAtom),
  (get, set, update: Partial<SearchCitationAtom>) =>
    set(searchCitationAtom, { ...get(searchCitationAtom), ...update })
);
