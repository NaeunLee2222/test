import { IFeedbackDialog } from '@/modules/chat/types/feedback';
import { atom } from 'jotai';

export const feedbackDialogAtom = atom<IFeedbackDialog>({
  open: false,
  message_uuid: '',
  feedback: {},
  bubbleType: 'chat',
});

export const feedbackDialogDataAtom = atom(
  (get) => get(feedbackDialogAtom),
  (get, set, update: IFeedbackDialog) => {
    set(feedbackDialogAtom, { ...get(feedbackDialogAtom), ...update });
  }
);
