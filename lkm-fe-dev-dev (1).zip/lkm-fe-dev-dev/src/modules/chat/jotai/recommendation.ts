import { IRecommendations } from '@/modules/chat/types/message';
import { atom } from 'jotai';

export const recommendationAtom = atom<IRecommendations>({
  historyId: -1,
  messageUuid: '',
});

export const recommendationDataAtom = atom(
  (get) => get(recommendationAtom),
  (get, set, update: Partial<IRecommendations>) => {
    set(recommendationAtom, { ...get(recommendationAtom), ...update });
  }
);
