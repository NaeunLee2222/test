import { atom } from 'jotai';
import { CanvasInfo, PlanInfo, WPlanInfo } from '../types/chatprocessing';

// ==============================
// Plan Management
// ==============================
export const newPlanAtoms = atom<{
  [chatID: string]: { plans: PlanInfo[]; status?: string; parentId?: string };
}>({});

// ==============================
// Canvas State
// ==============================
export const canvasAtom = atom<CanvasInfo>({
  canvas: { htmlContent: '', end: false, title: '', isNavigate: true },
  slide: { htmlContent: [], title: '', isNavigate: true, end: false },
  graph: { graphContent: '', end: false, title: '' },
  token: { tokenContent: '', id: '', parentId: '' },
  originalCanvas: '',
});

export const canvasAtoms = atom<{ [chatID: string]: CanvasInfo | any }>({
  chatID: {
    canvas: { htmlContent: '', end: false, title: '' },
    slide: { htmlContent: [], title: '' },
    graph: { graphContent: '', end: false, title: '' },
    token: { tokenContent: '', type: 'token' },
  },
  parentId: '',
});

export const detailCanvas = atom<string>('');

// ==============================
// Workflow
// ==============================
export const workflowPlanAtom = atom<WPlanInfo>({
  id: '',
  steps: [],
});
