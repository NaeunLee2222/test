import { EORDERHTML, ETYPEHTML } from '@/modules/chat/types/canvas';
import { atom } from 'jotai';

export const listCanvasPaginationAtom = atom<{
  skip?: number;
  limit?: number;
  order?: EORDERHTML;
  title?: string;
  userId: string | number;
  updated?: number;
  type?: ETYPEHTML;
}>({
  skip: 0,
  limit: 20,
  order: EORDERHTML.LATEST,
  title: '',
  updated: 0,
  userId: 1,
  type: ETYPEHTML.ALL,
});
