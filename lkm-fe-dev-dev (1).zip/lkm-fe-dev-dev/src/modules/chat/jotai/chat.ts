import { IToolGroup } from '@/modules/agent/type/agent';
import {
  DEFAULT_LIMIT_PER_PAGE,
  DEFAULT_SKIP,
} from '@/modules/chat/components/ChatInput/constants';
import {
  EOrder,
  ESort,
  IAbortData,
  IChatHistoryParam,
  IChatResponse,
  ITool,
} from '@/modules/chat/types/chat';
import {
  EChatToolMode,
  EUploadMode,
  IChat,
  IMessage,
} from '@/modules/chat/types/message';
import { getUserIdFromCookie } from '@/utils';
import { atom } from 'jotai';
import { atomFamily } from 'jotai/utils';
import { IUploadedFile } from '../types/files';

// ==============================
// Chat Session & Data
// ==============================

export const conversationStarterMessageAtom = atom<string | undefined>();

export const chatAtom = atom<IChat>({
  prevHistoryId: -1,
  historyId: -1,
  title: '',
  messages: {},
  isGenerating: false,
  userInput: '',
  isPro: true,
  isSecretMode: undefined,
  chatVersion: '',
  userData: {
    userId: '',
    username: '',
    company: '',
  },
  selectedChatMode: EChatToolMode.DEFAULT,
  selectedAgent: undefined,
  isAiInitiated: false,
});

export const chatDetail = atom<IChatResponse | null>(null);
export const newChatCreated = atom<IChatResponse>();

export const chatDataAtom = atom(
  (get) => get(chatAtom),
  (get, set, update: Partial<IChat>) => {
    set(chatAtom, { ...get(chatAtom), ...update });
  }
);

// ==============================
// Chat Messages & Related Atoms
// ==============================
export const messagesAtom = atom(
  (get) => get(chatAtom).messages,
  (get, set, update: { [key: string]: IMessage }) => {
    set(chatAtom, { ...get(chatAtom), messages: update });
  }
);

export const historyIdAtom = atom(
  (get) => get(chatAtom).historyId,
  (get, set, update: number | string) => {
    set(chatAtom, { ...get(chatAtom), historyId: update });
  }
);

export const userInputAtom = atom(
  (get) => get(chatAtom).userInput,
  (get, set, update: string) => {
    set(chatAtom, { ...get(chatAtom), userInput: update });
  }
);

export const chatVersionAtom = atom(
  (get) => get(chatAtom).chatVersion,
  (get, set, update: string) => {
    set(chatAtom, { ...get(chatAtom), chatVersion: update });
  }
);

export const isSecretModeAtom = atom(
  (get) => get(chatAtom).isSecretMode,
  (get, set, update: boolean) => {
    set(chatAtom, { ...get(chatAtom), isSecretMode: update });
  }
);

export const isGeneratingAtom = atom((get) => get(chatAtom).isGenerating);

// ==============================
// History Params
// ==============================
export const paramHistoryChatAtom = atom<IChatHistoryParam>({
  user_id: Number(getUserIdFromCookie()),
  skip: DEFAULT_SKIP,
  limit: DEFAULT_LIMIT_PER_PAGE,
  sort: ESort.CREATE_AT,
  order: EOrder.DESC,
});

// ==============================
// Message Creation & Fetching State
// ==============================
export const isCreatingChatAtom = atom({
  isCreating: false,
  updated: 0,
});

export const isLoadingMessageAtom = atom({
  isFetching: false,
  updated: 0,
});

// ==============================
// Abort State Management
// ==============================
export const abortAtom = atom<{ [key: string]: IAbortData }>({});

export const abortDataAtom = atom(
  (get) => get(abortAtom),
  (get, set, update: { key?: string; value?: Partial<IAbortData> }) => {
    const prevAbortData = get(abortAtom);
    Object.entries(prevAbortData).forEach(([key, abortData]) => {
      if (key !== update.key) abortData.abortController?.abort();
    });
    set(
      abortAtom,
      update.key
        ? {
            [update.key]: {
              isAbort: update.value?.isAbort || false,
              abortController:
                update.value?.abortController || new AbortController(),
            },
          }
        : {}
    );
  }
);

export const abortFamilyAtom = atomFamily((key: string) =>
  atom((get) => get(abortAtom)[key])
);

// ==============================
// UI & UX States
// ==============================
export const showWorkflowReviewDocAtom = atom<boolean>(false);
export const mousePositionAtom = atom<{
  show: boolean;
  topUp?: number;
  top: number;
  left: number;
  isNearBottom: boolean;
} | null>(null);

// ==============================
// Selection & Highlighting
// ==============================
export const currentMessagesAtom = atom<string[]>([]);
export const messagesOrderAtom = atom<number[]>([]);
export const selectionRangeAtom = atom<{ id: string; range: Range }[]>([]);

// ==============================
// Tool / Model / Upload
// ==============================
export const selectedToolAtom = atom<ITool>({
  isSelectedCanvas: true,
  selectedMode: null,
});

export const selectedModelAtom = atom<string>('');
export const selectedToolGroupsAtom = atom<IToolGroup[]>([]);
export const selectedUploadModeAtom = atom<EUploadMode | null>(null);
export const selectedUploadFileAtom = atom<IUploadedFile[]>([]);
