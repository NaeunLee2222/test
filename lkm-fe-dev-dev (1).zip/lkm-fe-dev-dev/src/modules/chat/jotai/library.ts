import { ILibraryDialog } from '@/modules/chat/types/history';
import { atom } from 'jotai';

export const libraryDialogAtom = atom<ILibraryDialog>({
  dialogOpen: false,
  id: -1,
  title: '',
  createdAt: '',
  targetHistoryId: -1,
  type: 'auto',
});

export const libraryDialogDataAtom = atom(
  (get) => get(libraryDialogAtom),
  (get, set, update: Partial<ILibraryDialog>) => {
    set(libraryDialogAtom, { ...get(libraryDialogAtom), ...update });
  }
);
