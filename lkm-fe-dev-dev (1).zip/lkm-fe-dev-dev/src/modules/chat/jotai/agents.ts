import { AgentType, OrderSort } from '@/modules/agent/type/agent';
import { atom } from 'jotai';
import { EChatAgentStatus } from '../types/agents';

// ==============================
// Agent Detail
// ==============================
export const agentDetailIdAtom = atom('');

// ==============================
// Agent List Filters & Pagination
// ==============================
export const listAgentPaginationAtom = atom<{
  skip: number;
  limit: number;
  category: string;
  usageScope: string;
  reviewStatus: EChatAgentStatus;
  agentType: AgentType;
  order: OrderSort;
  name: string;
  isMyAgent: boolean;
  updated?: number;
}>({
  skip: 0,
  limit: 40,
  category: '',
  usageScope: '',
  reviewStatus: EChatAgentStatus.DEPLOYED,
  agentType: AgentType.PRO,
  order: OrderSort.LATEST,
  name: '',
  isMyAgent: false,
  updated: 0,
});
