import SearchIcon from '@/assets/basic-icons/icon-magnify.svg?react';
import IconCloseRightPanel from '@/assets/direction-icons/icon-align-right.svg?react';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseCheckBox } from '@/modules/core/components/common/BaseCheckBox';
import { BaseWrappedTextFieldSx } from '@/modules/core/components/common/BaseTextField';
import { useKeyEscClose } from '@/modules/core/hooks/useEscHook';
import { layoutDataAtom } from '@/modules/core/jotai/layout';
import { updateClientSectionData } from '@/modules/report/hooks/useReportSectionData';
import { FormControlLabel, IconButton, TextField } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  mutateCitationSearchData,
  mutateClientCitationSearchData,
  useCitationSearchData,
} from '../../hooks/useCitationSearchData';
import { searchCitationDataAtom } from '../../jotai/citation';
import { ICitation } from '../../types/message';
import { ChatMarkdownSimple } from '../ChatContent/ChatMarkdownSimple';
import { ChatCitationOriginalUrlButton } from './ChatCitationOriginalUrlButton';
import styles from './ChatCitationSearch.module.scss';
import { ChatCitationTabs } from './ChatCitationTabs';

type SelectableCitation = ICitation & {
  isSelected: boolean;
  isClientSelected: boolean;
};

export const ChatCitationFilter = ({
  isLoading,
  tabs,
  activeTab,
  handleActiveTab,
}: {
  isLoading: boolean;
  tabs: { type: string; count: number; label: string }[];
  activeTab: string;
  handleActiveTab: (type: string, count: number) => void;
}) => {
  const { t } = useTranslation('tax');
  const [, setCitationSearchData] = useAtom(searchCitationDataAtom);

  const inputRef = useRef<any>(null);
  const handleSearch = () => {
    if (isLoading) return;
    const searchQuery = inputRef.current.value.trim();
    setCitationSearchData({ searchQuery });
  };

  const handleOnKeyUpToSearch = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className={styles.searchHeader}>
      <div className={styles.search}>
        <TextField
          id='search'
          className='app-input'
          inputRef={inputRef}
          placeholder={t('taxLawInformationSearch')}
          onKeyUp={handleOnKeyUpToSearch}
          sx={BaseWrappedTextFieldSx}
          InputProps={{
            endAdornment: (
              <IconButton
                onClick={handleSearch}
                disabled={isLoading}
                sx={{ padding: '4px', marginRight: '8px' }}
              >
                <SearchIcon />
              </IconButton>
            ),
          }}
        />
      </div>
      <ChatCitationTabs
        tabs={tabs}
        activeTab={activeTab}
        handleActiveTab={handleActiveTab}
      />
    </div>
  );
};

// FIXME: 타 코드에서 참조될 경우 파일 분리
export const ChatCitationSearchItem = ({
  citation,
  isSelectable = true,
}: {
  citation: SelectableCitation;
  isSelectable?: boolean;
}) => {
  const [{ mutateAsync: mutateClientSelectedCitation }] = useAtom(
    mutateClientCitationSearchData
  );
  const { t } = useTranslation('tax');

  return (
    <div
      key={citation.id}
      className={cn(styles.item, citation.isSelected && styles.disabled)}
    >
      {isSelectable ? (
        <FormControlLabel
          className={styles.itemTitle}
          control={
            <BaseCheckBox
              checked={
                citation.isSelected || citation.isClientSelected || false
              }
              disabled={citation.isSelected}
              onChange={(event: { target: { checked: boolean } }) => {
                mutateClientSelectedCitation({
                  citationId: citation.id,
                  selected: event.target.checked,
                });
              }}
            />
          }
          label={citation.title}
          sx={{
            '&.MuiFormControlLabel-root': {
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              margin: 0,
            },
            '& .MuiFormControlLabel-label': {
              typography: 'body02Medium',
              fontSize: '14px',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              lineHeight: '24px',
              color: citation.isSelected
                ? 'var(--gray-900) !important'
                : 'var(--primary-color-800) !important',
            },
          }}
        />
      ) : (
        <div className={styles.itemTitle}>{citation.title}</div>
      )}
      <ChatMarkdownSimple
        classNameProps={styles.itemContent}
        message={citation?.content || ''}
      />
      <div className={styles.itemFooter}>
        <span className={styles.chip}>
          {t(`citationType.${citation.lawType}`)}
        </span>
        <ChatCitationOriginalUrlButton originalUrl={citation?.originalUrl} />
      </div>
    </div>
  );
};

export const ChatCitationSearch = () => {
  const { t } = useTranslation('tax');
  const [, setLayoutData] = useAtom(layoutDataAtom);
  const [citationSearchData, setCitationSearchData] = useAtom(
    searchCitationDataAtom
  );
  const [{ data: citationList, isLoading, isError }] = useAtom(
    useCitationSearchData
  );
  const [{ mutateAsync: mutateSelectedCitation, isPending }] = useAtom(
    mutateCitationSearchData
  );

  const [{ mutateAsync: updateSectionContent }] = useAtom(
    updateClientSectionData
  );

  const handleClosePartnerView = () => {
    setLayoutData({ type: 'master', partnerImportFn: undefined });
    setCitationSearchData({
      parentId: '',
      parentType: undefined,
      searchQuery: '',
    });
  };

  useKeyEscClose(handleClosePartnerView);

  const disableAddButton = useMemo(
    () =>
      isPending ||
      isLoading ||
      citationList?.filter((c: SelectableCitation) => c.isClientSelected)
        .length === 0,
    [isPending, isLoading, citationList]
  );

  const [activeTab, setActiveTab] = useState('all');
  const handleActiveTab = (type: string, _count: number) => {
    setActiveTab(type);
  };

  const groupedCitationData = useMemo(() => {
    if (!citationList?.length) return { typeGroups: {}, tabs: [] };
    const typeGroups: Record<string, SelectableCitation[]> =
      citationList.reduce(
        (
          acc: Record<string, SelectableCitation[]>,
          citation: SelectableCitation
        ) => {
          if (citation.lawType) {
            if (!(citation.lawType in acc)) acc[citation.lawType] = [];
            acc[citation.lawType].push(citation);
            acc.all.push(citation);
          }
          return acc;
        },
        {
          all: [],
          law: [],
          precedent: [],
          interpretation: [],
        } as Record<string, SelectableCitation[]>
      );
    const tabs = Object.entries(typeGroups).map(([type, citations]) => ({
      type,
      count: citations.length,
      label: t(`citationType.${type}`),
    }));
    return {
      typeGroups,
      tabs: [...tabs],
    };
  }, [citationList, t]);

  const isEditable = useMemo(
    () => citationSearchData.parentType === 'report_section',
    [citationSearchData.parentType]
  );

  return (
    <div className={cn(styles.citationWrap)}>
      <div className={styles.header}>
        <div className={styles.title}>
          <IconButton
            onClick={handleClosePartnerView}
            sx={{ padding: '4px', width: '26px', height: '26px' }}
          >
            <IconCloseRightPanel fill='var(--gray-500)' />
          </IconButton>
          <span className={styles.text}>{t('taxLawInformation')}</span>
        </div>
      </div>
      <div className={styles.content}>
        <ChatCitationFilter
          isLoading={isLoading}
          tabs={groupedCitationData.tabs}
          activeTab={activeTab}
          handleActiveTab={handleActiveTab}
        />
        {isError ? (
          <div className={styles.error}>
            <span>{t('error.citationSearchError')}</span>
          </div>
        ) : isLoading ? (
          <div className='loaderWrap'>
            <span className='spinner' />
            <span className='loaderText'>
              {t('loadingRelativeAiInformation')}
            </span>
          </div>
        ) : (
          <div className={styles.list}>
            {!isLoading &&
            groupedCitationData.typeGroups[activeTab]?.length > 0 ? (
              groupedCitationData.typeGroups[activeTab]?.map(
                (citation: SelectableCitation) => (
                  <ChatCitationSearchItem
                    key={citation.id}
                    citation={citation}
                    isSelectable={isEditable}
                  />
                )
              )
            ) : (
              <div className={styles.empty}>
                <span>{t('noSearchedLawData')}</span>
              </div>
            )}
          </div>
        )}
      </div>
      {isEditable && (
        <div className={styles.footer}>
          <BaseButton
            sx={{
              width: '100%',
            }}
            disabled={disableAddButton}
            onClick={async () => {
              await mutateSelectedCitation({});
              updateSectionContent({
                citationIdList: citationList?.map(
                  (citation: ICitation) => citation.id
                ),
              });
            }}
          >
            {t('report.addTaxInfoToBody')}
          </BaseButton>
        </div>
      )}
    </div>
  );
};
