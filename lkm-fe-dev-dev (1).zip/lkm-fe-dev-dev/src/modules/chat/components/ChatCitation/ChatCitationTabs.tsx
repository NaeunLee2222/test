import cn from 'classnames';
import styles from './ChatCitationTabs.module.scss';

interface CitationTabsProps {
  tabs: Array<{
    type: string;
    count: number;
    label: string;
  }>;
  activeTab: string;
  handleActiveTab: (type: string, count: number) => void;
}

export const ChatCitationTabs = ({
  tabs,
  activeTab,
  handleActiveTab,
}: CitationTabsProps) => (
  <div className={styles.tabs}>
    {tabs.map(({ type, count, label }) => (
      <button
        key={type}
        type='button'
        onClick={() => handleActiveTab(type, count)}
        className={cn(styles.tab, activeTab === type && styles.isActive)}
      >
        {label}
        {type !== 'all' ? ` (${count})` : ''}
      </button>
    ))}
  </div>
);
