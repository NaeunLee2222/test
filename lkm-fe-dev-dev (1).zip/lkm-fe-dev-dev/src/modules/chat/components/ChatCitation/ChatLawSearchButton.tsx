import cn from 'classnames';
import IconLaw from '@/assets/basic-icons/icon-law.svg?react';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { useTranslation } from 'react-i18next';
import { useAtom } from 'jotai';
import { layoutDataAtom } from '@/modules/core/jotai/layout';
import styles from './ChatCitations.module.scss';
import { searchCitationDataAtom } from '../../jotai/citation';

export const ChatLawSearchButton = ({
  style,
  messageUuid,
}: {
  style?: React.CSSProperties;
  messageUuid?: string;
}) => {
  const { t } = useTranslation();
  const [citationSearchData, setCitationSearchData] = useAtom(
    searchCitationDataAtom
  );
  const [layoutData, setLayoutData] = useAtom(layoutDataAtom);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    const setSearchPartnerView = () => {
      setCitationSearchData({
        parentId: messageUuid!,
        parentType: 'chat_message',
        searchQuery: '',
      });
      setLayoutData({
        type: 'partner',
        partnerImportFn: () =>
          import(
            '@/modules/chat/components/ChatCitation/ChatCitationSearch'
          ).then((module) => ({
            default: module.ChatCitationSearch,
          })),
        detail: 'citation_search',
      });
    };
    if (
      layoutData.type === 'partner' &&
      layoutData.detail !== 'citation_search'
    ) {
      setSearchPartnerView();
    } else if (citationSearchData.parentId === messageUuid) {
      setCitationSearchData({
        parentId: '',
        parentType: undefined,
        searchQuery: '',
      });
      setLayoutData({
        type: 'master',
        partnerImportFn: undefined,
        detail: 'chat_message_law_search',
      });
    } else {
      setSearchPartnerView();
    }
  };

  return (
    <BaseButton
      buttonType='outlined'
      className={cn(
        styles.lawSearchBtn,
        layoutData.type === 'partner' &&
          layoutData.detail === 'citation_search' &&
          citationSearchData.parentId === messageUuid &&
          styles.active
      )}
      style={style}
      onClick={handleClick}
    >
      <IconLaw />
      <span>{t('chat.lawSearch')}</span>
    </BaseButton>
  );
};
