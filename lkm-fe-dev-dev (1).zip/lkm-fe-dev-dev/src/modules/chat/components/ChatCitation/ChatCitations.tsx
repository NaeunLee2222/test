import IconWebSearch from '@/assets/basic-icons/icon-web-search.svg?react';
import IconWebSearches from '@/assets/basic-icons/icon-web-searches.svg?react';
import IconChevronDown from '@/assets/direction-icons/icon-chevron-down.svg?react';
import { ICitation } from '@/modules/chat/types/message';
import {
  BaseAccordion,
  BaseAccordionDetails,
  BaseAccordionSummary,
} from '@/modules/core/components/common/BaseAccordion';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseMenu } from '@/modules/core/components/common/BaseMenu';
import { layoutDataAtom } from '@/modules/core/jotai/layout';
import { IChatBubbleType } from '@/types/layout';
import { MenuItem } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useChatCitationHandler } from '../../hooks/chatCitationHandler';
import { isGeneratingAtom } from '../../jotai/chat';
import { citationDataAtom } from '../../jotai/citation';
import styles from './ChatCitations.module.scss';
import { ChatLawSearchButton } from './ChatLawSearchButton';

interface Props {
  citations?: ICitation[];
  messageUuid?: string;
  bubbleType?: IChatBubbleType;
  isLoading?: boolean;
}

const ChatWebCitations = ({
  citations,
  messageUuid,
  bubbleType,
  isLoading,
}: Props) => {
  const { handleCitationClick } = useChatCitationHandler();

  const [openWebSearchButton, setOpenWebSearchButton] = useState<any>(null);
  const [openWebSearchMenu, setOpenWebSearchMenu] = useState(false);

  if (!citations?.length) return <></>;
  return (
    <>
      <BaseButton
        buttonType='outlined'
        className={cn(styles.webSearchBtn, openWebSearchMenu && styles.active)}
        onClick={(e) => {
          if (citations?.length > 1) {
            setOpenWebSearchMenu(!openWebSearchMenu);
            setOpenWebSearchButton(e.currentTarget);
          } else if (messageUuid && bubbleType) {
            handleCitationClick(messageUuid, bubbleType, citations[0]);
          }
        }}
      >
        {citations?.length > 1 ? <IconWebSearches /> : <IconWebSearch />}
        <span
          className={styles.webSearchText}
        >{`${citations?.length} Web Search`}</span>
      </BaseButton>
      <BaseMenu
        disableAutoFocus
        open={openWebSearchMenu}
        anchorEl={openWebSearchButton}
        onClose={() => {
          setOpenWebSearchMenu(false);
        }}
        anchorOrigin={{
          vertical: -10,
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
      >
        {citations.map((item) => (
          <MenuItem
            key={item.id}
            onClick={() => {
              if (!messageUuid || !bubbleType) return;
              handleCitationClick(messageUuid, bubbleType, item);
              setOpenWebSearchMenu(false);
            }}
          >
            {item.title}
          </MenuItem>
        ))}
      </BaseMenu>
    </>
  );
};

export const ChatCitations = ({
  isLoading,
  citations,
  messageUuid,
  bubbleType,
}: Props) => {
  const { t } = useTranslation('tax');
  const [layoutData] = useAtom(layoutDataAtom);
  const [citationData] = useAtom(citationDataAtom);
  const [isGenerating] = useAtom(isGeneratingAtom);

  const [open, setOpen] = useState(true);
  const { handleCitationClick } = useChatCitationHandler();

  if (!citations?.length) return <></>;

  const citationList = citations
    .map((citation, idx) => ({
      ...citation,
      index: (citation?.indexInMessage ?? idx) + 1,
    }))
    .filter((citation) => citation?.lawType !== 'web')
    .sort((a, b) => a.index - b.index);
  const webSearchList = citations.filter(
    (citation) => citation?.lawType === 'web'
  );

  const isSelected = (citation: ICitation) =>
    layoutData?.type === 'partner' &&
    layoutData?.detail === 'citation' &&
    citationData?.id === citation.id &&
    citationData?.messageUuid === messageUuid;

  return (
    <div className={styles.citationWrap}>
      <BaseAccordion
        expanded={open}
        onChange={() => !isLoading && setOpen(!open)}
        className={styles.accordion}
      >
        <BaseAccordionSummary
          expandIcon={
            isLoading ? (
              <div />
            ) : (
              <IconChevronDown
                style={{
                  width: '14px',
                  height: '8px',
                  fill: 'var(--gray-500)',
                }}
              />
            )
          }
          sx={{
            '.MuiAccordionSummary-content': {
              display: 'flex',
              justifyContent: 'space-between',
            },
          }}
        >
          <div className={styles.accordionTitle}>
            {t('message.citationTitle')}
          </div>
          {!isLoading && !isGenerating && bubbleType !== 'view' && (
            <ChatLawSearchButton
              messageUuid={messageUuid}
              style={{
                marginRight: '16px',
              }}
            />
          )}
        </BaseAccordionSummary>
        <BaseAccordionDetails>
          {citationList?.map((citation) => {
            if (citation?.lawType !== 'web') {
              return (
                <div
                  role='presentation'
                  key={citation.id}
                  onClick={() => {
                    if (!messageUuid || !bubbleType) return;
                    handleCitationClick(messageUuid, bubbleType, citation);
                  }}
                  className={cn(
                    styles.citationItem,
                    isSelected(citation) && styles.selected
                  )}
                >
                  <div className={styles.chip}>{citation.index}</div>
                  <div className={styles.text}>
                    {!!citation?.lawType && (
                      <span className={styles.lawType}>
                        [{t(`citationType.${citation.lawType}`)}]
                      </span>
                    )}
                    <span className={styles.title}>{citation.title}</span>
                  </div>
                </div>
              );
            }
            return null;
          })}
        </BaseAccordionDetails>
      </BaseAccordion>
      <ChatWebCitations
        citations={webSearchList}
        messageUuid={messageUuid}
        bubbleType={bubbleType}
        isLoading={isLoading}
      />
    </div>
  );
};
