import ChevronLeftIcon from '@/assets/direction-icons/icon-chevron-left.svg?react';
import ChevronRightIcon from '@/assets/direction-icons/icon-chevron-right.svg?react';
import { ICitation } from '@/modules/chat/types/message';
import { layoutDataAtom } from '@/modules/core/jotai/layout';
import { IChatBubbleType } from '@/types/layout';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useChatCitationHandler } from '../../hooks/chatCitationHandler';
import { citationDataAtom } from '../../jotai/citation';
import bubbleStyles from '../ChatContent/ChatBubble.module.scss';
import { ChatCitationTabs } from './ChatCitationTabs';
import styles from './ChatRelevantCitation.module.scss';

interface Props {
  citations?: ICitation[];
  messageUuid?: string;
  bubbleType?: IChatBubbleType;
  isLoading?: boolean;
}

export const ChatRelevantCitations = ({
  isLoading,
  citations,
  messageUuid,
  bubbleType,
}: Props) => {
  const { t } = useTranslation('tax');
  const [layoutData] = useAtom(layoutDataAtom);
  const [citationData] = useAtom(citationDataAtom);
  const { handleCitationClick } = useChatCitationHandler();

  const [activeTab, setActiveTab] = useState('all');
  const [currentPage, setCurrentPage] = useState(0);
  const ITEMS_PER_PAGE = 3;

  const groupedData = useMemo(() => {
    if (!citations) return { typeGroups: {}, tabs: [] };
    const typeGroups = citations.reduce(
      (acc, citation) => {
        if (citation.lawType && citation.lawType !== 'web') {
          if (!acc[citation.lawType]) {
            acc[citation.lawType] = {
              type: citation.lawType,
              citations: [],
              count: 0,
            };
          }
          acc[citation.lawType].citations.push(citation);
          acc[citation.lawType].count++;
        }
        return acc;
      },
      {} as Record<
        string,
        { type: string; citations: ICitation[]; count: number }
      >
    );

    const tabs = [
      {
        type: 'all',
        count: citations.length,
        label: t(`citationType.all`),
      },
      ...Object.entries(typeGroups).map(([type, data]) => ({
        type,
        count: data.count,
        label: t(`citationType.${type}`),
      })),
    ];

    return {
      typeGroups,
      tabs,
    };
  }, [citations, t]);

  const displayData = useMemo(() => {
    if (!citations)
      return { totalPages: 0, currentPage: 0, currentCitations: [] };
    const currentCitations =
      activeTab === 'all'
        ? citations
        : groupedData.typeGroups[activeTab]?.citations || [];

    const totalPages = Math.ceil(currentCitations.length / ITEMS_PER_PAGE);

    const validCurrentPage = Math.min(currentPage, totalPages - 1);
    const validStartIndex = validCurrentPage * ITEMS_PER_PAGE;

    const paginatedCitations = currentCitations.slice(
      validStartIndex,
      validStartIndex + ITEMS_PER_PAGE
    );

    return {
      totalPages,
      currentPage: validCurrentPage,
      currentCitations: paginatedCitations,
    };
  }, [activeTab, currentPage, groupedData]);

  const handleActiveTab = (type: string) => {
    setActiveTab(type);
    setCurrentPage(0);
  };

  const handlePrevPage = () => {
    setCurrentPage((prev) => prev - 1);
  };

  const handleNextPage = () => {
    setCurrentPage((prev) => Math.min(displayData.totalPages - 1, prev + 1));
  };

  const isSelected = (citation: ICitation) =>
    layoutData?.type === 'partner' &&
    citationData?.id === citation.id &&
    citationData?.messageUuid === messageUuid;

  if (!citations?.length) return <></>;
  return (
    <div className={styles.relevantWrap}>
      <div className={cn(bubbleStyles.metaTitle, styles.titleWrap)}>
        <span>
          {t('message.relevantTitle')} {!isLoading && `(${citations.length})`}
        </span>
        <div className={cn(styles.chevrons, isLoading && styles.disabled)}>
          <span
            role='presentation'
            className={cn(styles.chevron, currentPage === 0 && styles.disabled)}
            onClick={handlePrevPage}
          >
            <ChevronLeftIcon />
          </span>
          <span
            role='presentation'
            className={cn(
              styles.chevron,
              currentPage >= displayData.totalPages - 1 && styles.disabled
            )}
            onClick={handleNextPage}
          >
            <ChevronRightIcon />
          </span>
        </div>
      </div>
      {!isLoading && (
        <div className={cn(styles.contentWrap)}>
          <ChatCitationTabs
            tabs={groupedData.tabs}
            activeTab={activeTab}
            handleActiveTab={handleActiveTab}
          />
          <div className={styles.items}>
            {displayData.currentCitations.map((citation) => (
              <div
                role='presentation'
                key={citation.id}
                onClick={() => {
                  if (!messageUuid || !bubbleType) return;
                  handleCitationClick(messageUuid, bubbleType, citation);
                }}
                className={cn(
                  styles.item,
                  isSelected(citation) && styles.selected
                )}
              >
                <div className={styles.text}>
                  {!!citation?.lawType && (
                    <span className={styles.lawType}>
                      [{t(`citationType.${citation.lawType}`)}]
                    </span>
                  )}
                  <span className={styles.title}>{citation.title}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
