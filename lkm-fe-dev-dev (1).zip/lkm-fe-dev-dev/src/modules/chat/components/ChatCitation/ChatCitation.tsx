import IconCloseRightPanel from '@/assets/direction-icons/icon-align-right.svg?react';
import { useKeyEscClose } from '@/modules/core/hooks/useEscHook';
import { layoutDataAtom } from '@/modules/core/jotai/layout';
import { parseMessage } from '@/utils/chatUtil';
import BrowserNotSupportedOutlinedIcon from '@mui/icons-material/BrowserNotSupportedOutlined';
import ErrorIcon from '@mui/icons-material/Error';
import { IconButton } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useCitationData } from '../../hooks/useCitationData';
import { citation, citationDataAtom } from '../../jotai/citation';
import { ChatMarkdown } from '../ChatContent/ChatMarkdown';
import styles from './ChatCitation.module.scss';
import { ChatCitationOriginalUrlButton } from './ChatCitationOriginalUrlButton';

export const ChatCitation = () => {
  const [, setLayoutData] = useAtom(layoutDataAtom);
  const [citationData, setCitationData] = useAtom(citationDataAtom);
  const [{ data, isLoading, isError }] = useAtom(useCitationData);

  const handleClosePartnerView = () => {
    setLayoutData({ type: 'master' });
    setCitationData(citation);
  };

  const { t } = useTranslation('tax');

  useKeyEscClose(handleClosePartnerView);

  const contentData = useMemo(() => {
    const textData = data?.rawData?.reduce(
      (acc: string, cur: string | undefined) => `${acc + (cur || '').trim()}`,
      ''
    );
    const summary = citationData.summary
      ? `### ${t('citation.summary')} \n${citationData.summary}\n${textData}`
      : '';

    return citationData.type === 'text' || citationData.type === 'azure_search'
      ? summary + textData
      : citationData.type === 'json'
        ? JSON.parse(data?.rawData[0])?.content
        : null;
  }, [citationData.summary, citationData.type, data?.rawData, t]);

  return (
    <div className={cn(styles.citationWrap)}>
      <div className={styles.header}>
        <div className={styles.title}>
          <IconButton
            onClick={handleClosePartnerView}
            sx={{ padding: '4px', width: '26px', height: '26px' }}
          >
            <IconCloseRightPanel fill='var(--gray-500)' />
          </IconButton>
          <span className={styles.text}>
            {!!citationData?.lawType && (
              <span className={styles.chip}>
                {t(`citationType.${citationData.lawType}`)}
              </span>
            )}
            {citationData.title}
          </span>
        </div>
        {data?.originalUrl && data?.originalUrl !== 'user_document' && (
          <ChatCitationOriginalUrlButton originalUrl={data?.originalUrl} />
        )}
      </div>
      <div className={styles.content}>
        {isError ? (
          <div className={styles.status}>
            <ErrorIcon fontSize='small' />
            Error during fetching citation data
          </div>
        ) : isLoading ? (
          <div className={cn(styles.status, 'loaderWrap')}>
            <div className='loader' />
          </div>
        ) : contentData ? (
          <div className={styles.markdown}>
            <ChatMarkdown
              classNameProps={styles.citationMarkdown}
              message={parseMessage(contentData)}
            />
          </div>
        ) : (
          <div className={styles.status}>
            <BrowserNotSupportedOutlinedIcon fontSize='small' />
            Empty Content
          </div>
        )}
      </div>
    </div>
  );
};
