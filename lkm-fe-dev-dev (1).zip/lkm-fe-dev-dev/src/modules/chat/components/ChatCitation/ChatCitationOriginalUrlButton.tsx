import { useTranslation } from 'react-i18next';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import styles from './ChatCitation.module.scss';

export const ChatCitationOriginalUrlButton = ({
  originalUrl,
}: {
  originalUrl?: string;
}) => {
  const { t } = useTranslation();
  if (!originalUrl) return null;
  return (
    <BaseButton
      buttonType='linkUnderline'
      className={styles.url}
      onClick={() => {
        window.open(
          originalUrl,
          '_blank',
          'toolbar=no,scrollbars=no,resizable=yes,status=no,menubar=no,top=0,left=0,fullscreen=yes'
        );
      }}
    >
      {t('openOriginalUrl')}
    </BaseButton>
  );
};
