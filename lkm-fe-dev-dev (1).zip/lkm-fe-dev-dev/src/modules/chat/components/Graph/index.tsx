import { graphTitleAtom } from '@/modules/chat/jotai/graph';
import { Box } from '@mui/material';
import { useAtom } from 'jotai';
import styles from './index.module.scss';
import GraphVisualizer from './network';

const GraphTemplate = () => {
  const [graphTitle] = useAtom(graphTitleAtom);

  return (
    <Box className={styles['graph-template']}>
      <h1 className={styles.heading}>{graphTitle}</h1>
      <GraphVisualizer />
    </Box>
  );
};

export default GraphTemplate;
