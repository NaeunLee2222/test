import {
  graphDefaultColors,
  graphDimColors,
  graphEdgeStyle,
  graphHighlightColors,
  graphNodeStyle,
  graphOptions,
} from '@/modules/chat/constanst/graph';
import { graphDataAtom } from '@/modules/chat/jotai/graph';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { Id } from 'vis-network/declarations/network/gephiParser';
import {
  DataSet,
  Edge,
  Network,
  Node,
} from 'vis-network/standalone/esm/vis-network';
import styles from './index.module.scss';

export interface GraphNode extends Node {
  id: string | number;
  label: string;
  description: string;
}

interface VisEdge extends Edge {
  description: string;
}

const GraphVisualizer = () => {
  const [graphData] = useAtom(graphDataAtom);

  const [tooltip, setTooltip] = useState({
    show: false,
    content: '',
    x: 0,
    y: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const networkRef = useRef<Network | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const initializeGraph = useCallback(async () => {
    if (!containerRef.current) return;

    setLoading(true);
    setError(null);

    try {
      const originalNodeColors: Record<string, string> = {};

      const calculateNodeSize = (weight: number) => {
        const minSize = 12;
        const maxSize = 30;
        return minSize + weight * (maxSize - minSize);
      };

      const nodes = new DataSet<GraphNode>(
        graphData.nodes.map((node) => {
          originalNodeColors[node.id] =
            node.color ?? graphDefaultColors.node.border;
          return {
            ...node,
            ...graphNodeStyle,
            size: calculateNodeSize(node.weight ?? 0.5),
            color: {
              border: node.color ?? graphDefaultColors.node.border,
              background: node.color ?? graphDefaultColors.node.background,
            },
          };
        })
      );

      const safeFontStyle =
        typeof graphEdgeStyle.font === 'object' && graphEdgeStyle.font !== null
          ? graphEdgeStyle.font
          : {};

      const edges = new DataSet<VisEdge>(
        graphData.edges.map((edge) => ({
          from: edge.source,
          to: edge.target,
          label: edge.label,
          description: edge.description,
          ...graphEdgeStyle,
          color: { color: graphDefaultColors.edge.color },
          font: { ...safeFontStyle, color: graphDefaultColors.edge.font },
        }))
      );

      const data = { nodes, edges };
      const network = new Network(containerRef.current, data, graphOptions);

      // Save to ref for cleanup
      networkRef.current = network;

      network.on('hoverNode', (params) => {
        const hoveredNodeId = params.node;
        const node = nodes.get(hoveredNodeId) as unknown as
          | GraphNode
          | undefined;
        const connectedNodesRaw = network.getConnectedNodes(hoveredNodeId);
        const connectedNodes: Id[] = connectedNodesRaw.filter(
          (item): item is Id =>
            typeof item === 'string' || typeof item === 'number'
        );
        const connectedEdges = network.getConnectedEdges(hoveredNodeId);

        const tooltipContent = node?.description
          ? `${node.label}\n${node.description}`
          : (node?.label ?? '');
        setTooltip({ show: true, content: tooltipContent, x: 0, y: 0 });

        const nodeUpdates = nodes.getIds().map((nodeId) => {
          const isHovered = nodeId === hoveredNodeId;
          const isConnected = connectedNodes.includes(nodeId);

          return {
            id: nodeId,
            color: {
              border: isHovered
                ? graphHighlightColors.node.border
                : isConnected
                  ? originalNodeColors[nodeId]
                  : graphDimColors.node.border,
              background: isHovered
                ? graphHighlightColors.node.background
                : isConnected
                  ? originalNodeColors[nodeId]
                  : graphDimColors.node.background,
            },
            font: {
              color:
                isHovered || isConnected ? '#ffffff' : graphDimColors.node.font,
            },
          };
        });
        nodes.update(nodeUpdates);

        const edgeUpdates = edges.getIds().map((edgeId) => {
          const isConnected = connectedEdges.includes(edgeId);
          return {
            id: edgeId,
            color: {
              color: isConnected
                ? graphHighlightColors.edge.color
                : graphDimColors.edge.color,
            },
            font: {
              color: isConnected
                ? graphHighlightColors.edge.font
                : graphDimColors.edge.font,
            },
          };
        });
        edges.update(edgeUpdates);
      });

      network.on('hoverEdge', (params) => {
        const edge = edges.get(params.edge) as unknown as VisEdge | undefined;
        const tooltipContent = edge?.description
          ? `${edge.label}\n${edge.description}`
          : (edge?.label ?? '');
        setTooltip({ show: true, content: tooltipContent, x: 0, y: 0 });
      });

      network.on('blurNode', () => {
        setTooltip({ show: false, content: '', x: 0, y: 0 });

        nodes.update(
          nodes.getIds().map((id) => ({
            id,
            color: {
              border: originalNodeColors[id],
              background: originalNodeColors[id],
            },
            font: { color: '#ffffff' },
          }))
        );

        edges.update(
          edges.getIds().map((id) => ({
            id,
            color: { color: graphDefaultColors.edge.color },
            font: { color: graphDefaultColors.edge.font },
          }))
        );
      });

      network.on('blurEdge', () => {
        setTooltip({ show: false, content: '', x: 0, y: 0 });
      });

      setLoading(false);
    } catch (er) {
      console.error('Failed to initialize graph:', er);
      setError(
        '네트워크 그래프를 로드하는 중 오류가 발생했습니다. 다시 시도해주세요.'
      );
      setLoading(false);
    }
  }, [graphData.edges, graphData.nodes]);

  useEffect(() => {
    initializeGraph();

    return () => {
      // Cleanup: destroy network and reset atom
      if (networkRef.current) {
        networkRef.current.destroy();
        networkRef.current = null;
      }
    };
  }, [graphData]);

  useEffect(() => {
    function handleMouseMove(e: MouseEvent) {
      if (tooltip.show) {
        setTooltip((prev) => ({ ...prev, x: e.clientX, y: e.clientY - 24 }));
      }
    }

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [tooltip.show]);

  return (
    <>
      {loading && (
        <div className={styles['loading-container']}>
          <div className={styles['loading-spinner']} />
          <p>네트워크 그래프를 로딩 중입니다...</p>
        </div>
      )}

      {error && (
        <div className={styles['error-container']}>
          <p>{error}</p>
          <button type='button' onClick={initializeGraph}>
            다시 시도
          </button>
        </div>
      )}

      <div ref={containerRef} className={styles.network} />

      {tooltip.show && (
        <div
          className={styles['custom-tooltip']}
          style={{
            left: tooltip.x,
            top: tooltip.y,
            position: 'fixed',
          }}
        >
          {tooltip.content}
        </div>
      )}
    </>
  );
};

export default GraphVisualizer;
