import IconSecretLock from '@/assets/basic-icons/icon-secret-lock.svg?react';
import loadingIcon from '@/assets/lotties/loading-icon.json';
import { AgentType } from '@/modules/agent/type/agent';
import { ChatBubbles } from '@/modules/chat/components/ChatContent/ChatBubbles';
import { ChatInitial } from '@/modules/chat/components/ChatInitial/ChatInitial';
import { ChatInputWrap } from '@/modules/chat/components/ChatMain//ChatInputWrap';
import styles from '@/modules/chat/components/ChatMain/ChatMain.module.scss';
import { useChatScrollHandler } from '@/modules/chat/hooks/chatScrollHandler';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { RoutesURL } from '@/routers/routes';
import { EStreamType, IChatBubbleType, IInfoMessage } from '@/types/layout';
import cn from 'classnames';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation, useParams, useSearchParams } from 'react-router-dom';
import { isAiChatScreen, isMainScreen } from '@/utils/chatUtil';
import CloudSelectDialog from '../FileSelectDialog/CloudSelectDialog';

interface IProps {
  historyId?: string;
  bubbleType?: IChatBubbleType;
  infoMessage?: IInfoMessage;
  sidebar?: React.ReactElement;
  disableInputProps?: boolean;
  mode?: AgentType;
  streamType?: EStreamType;
}

export const ChatMain = ({
  historyId,
  bubbleType,
  infoMessage,
  sidebar,
  disableInputProps,
  mode = AgentType.PRO,
  streamType,
}: IProps) => {
  const location = useLocation();
  const path = location.pathname;
  const [searchParams] = useSearchParams();
  const params = useParams();
  const { handleScroll, scrollContentRef } = useChatScrollHandler();
  const {
    chatData,
    isAiInitiated,
    isGenerating,
    isSecretMode,
    isCreatingChat,
    isFetching,
  } = useMainContext();
  const isAi = isAiChatScreen(path);

  const { t } = useTranslation('tax');

  const isInitChat = useMemo(
    () =>
      !searchParams.get('secret-chat') &&
      !location.pathname.includes(RoutesURL.AGENT_CREATE) &&
      !location.pathname.includes(RoutesURL.GENERAL_AGENT) &&
      !historyId &&
      (!params.chatId || isAi) &&
      !isGenerating &&
      !isCreatingChat &&
      !isFetching &&
      !isAiInitiated,

    [searchParams, historyId, isGenerating, params]
  );

  const isSecretChatInit = useMemo(
    () =>
      searchParams.get('secret-chat') === 'true' &&
      !Object.keys(chatData?.messages ?? {})?.length,
    [searchParams, chatData?.messages]
  );

  const hideModelVersion = true;

  return (
    <div className={cn(styles.chatMain, !!sidebar && styles.sidebarContainer)}>
      {!!sidebar && (
        <div className={styles.sidebarWrap}>
          <div className={styles.sidebar}>{sidebar}</div>
        </div>
      )}
      <div
        className={
          isMainScreen(path)
            ? styles.chatContentWrapMain
            : styles.chatContentWrap
        }
      >
        {isInitChat ? (
          <ChatInitial />
        ) : (
          <>
            {isCreatingChat || isFetching ? (
              <div className={styles.loading}>
                <LottiePlayer
                  options={{
                    renderer: 'svg',
                    loop: true,
                    autoplay: true,
                    animationData: loadingIcon,
                  }}
                  width={100}
                  height={100}
                />
              </div>
            ) : (
              <div
                id='chat-scroll-content'
                className={styles.scrollContentWrap}
                onScroll={handleScroll}
                ref={scrollContentRef}
              >
                {isSecretChatInit ? (
                  <div className={styles.initSecretChat}>
                    <IconSecretLock />
                    <div className={styles.text}>{t('initSecretChat')}</div>
                  </div>
                ) : (
                  <ChatBubbles
                    mode={mode}
                    type={bubbleType}
                    infoMessage={infoMessage}
                    streamType={streamType}
                  />
                )}
              </div>
            )}
            <ChatInputWrap
              bubbleType={bubbleType}
              hideScrollButtons={!isSecretMode && !historyId}
              hideModelVersion={hideModelVersion}
              disableInputProps={disableInputProps}
            />
          </>
        )}
      </div>
      <CloudSelectDialog />
    </div>
  );
};
