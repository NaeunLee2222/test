import { IChatBubbleType } from '@/types/layout';
import { useAtomValue } from 'jotai';
import { useChatScrollHandler } from '../../hooks/chatScrollHandler';
import { chatScrollDataAtom } from '../../jotai/scroll';
import { ChatScrollButtons } from '../ChatContent/ChatScrollButtons';
import { ChatInput } from '../ChatInput/ChatInput';
import styles from './ChatMain.module.scss';

interface IProps {
  hideScrollButtons?: boolean;
  disableInputProps?: boolean;
  hideModelVersion?: boolean;
  bubbleType?: IChatBubbleType;
}

export const ChatInputWrap = ({
  hideScrollButtons,
  disableInputProps,
  hideModelVersion,
  bubbleType,
}: IProps) => {
  const { scrollToBottom } = useChatScrollHandler();
  const chatScrollData = useAtomValue(chatScrollDataAtom);

  return (
    <div className={styles.chatInputWrap}>
      {!hideScrollButtons && (
        <div className={styles.scrollButton}>
          <ChatScrollButtons
            isAtBottom={chatScrollData.isAtBottom}
            scrollToBottom={scrollToBottom}
          />
        </div>
      )}
      <ChatInput
        disableProps={disableInputProps}
        hideModelVersion={hideModelVersion}
        bubbleType={bubbleType}
      />
    </div>
  );
};
