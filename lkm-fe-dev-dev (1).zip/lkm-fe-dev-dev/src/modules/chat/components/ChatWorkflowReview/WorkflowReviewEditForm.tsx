import ConeIcon from '@/assets/basic-icons/icon-calendar.svg?react';
import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import { getToolGroup } from '@/modules/agent/api/agent';
import { useToolGroupList } from '@/modules/agent/hooks/useAgent';
import { actionIdAtom } from '@/modules/agent/jotai/agent';
import { IAction, IActionPost, IToolGroup } from '@/modules/agent/type/agent';
import { SearchActionModal } from '@/modules/chat/components/ChatWorkflowReview/SearchActionModal';
import styles from '@/modules/chat/components/ChatWorkflowReview/WorkflowReviewEditForm.module.scss';
import { useChatSendHandler } from '@/modules/chat/hooks/chatSendHandler';
import {
  updateActionInfoMutation,
  useGetActionAgent,
} from '@/modules/chat/hooks/useAgents';
import { workflowPlanAtom } from '@/modules/chat/jotai/chatprocessing';
import { WActionInfo, WPlanInfo } from '@/modules/chat/types/chatprocessing';
import { IConfig } from '@/modules/chat/types/message';
import {
  IEditingIndex,
  UpdateStepFormData,
} from '@/modules/chat/types/workflow-report';
import { showSnackbar } from '@/utils/snackbarUtil';
import {
  Box,
  Button,
  MenuItem,
  Select,
  TextField,
  Typography,
} from '@mui/material';
import { useAtom, useSetAtom } from 'jotai';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

interface IProp {
  stepIndex: number;
  actionIndex: number;
  setEditingIndex: React.Dispatch<React.SetStateAction<IEditingIndex | null>>;
  selectedAction: WActionInfo;
  stepsData: WPlanInfo;
  config?: IConfig;
  uuid: string;
}

const WorkflowReviewEditForm = ({ setEditingIndex, selectedAction }: IProp) => {
  const { t } = useTranslation('tax');
  const [showSearch, setShowSearch] = useState<boolean>(false);
  const [toolData, setToolData] = useState<IToolGroup[]>([]);

  const { resendMessagesFunc } = useChatSendHandler();
  const [, setWorkflowPlan] = useAtom(workflowPlanAtom);
  const [{ mutateAsync: updateActionMutation }] = useAtom(
    updateActionInfoMutation
  );
  const [{ data: actionData }] = useAtom(useGetActionAgent);
  const setActionId = useSetAtom(actionIdAtom);
  const [{ data: groupToolData }] = useAtom(useToolGroupList);

  const {
    handleSubmit,
    register,
    formState: { errors },
    getValues,
    setValue,
    reset,
    watch,
  } = useForm<UpdateStepFormData>({
    defaultValues: {
      content: selectedAction?.name,
      description: selectedAction?.description,
    },
  });

  const cancel = () => {
    setEditingIndex(null);
  };

  const updatedAction = () => {
    resendMessagesFunc({ message: '' });
    setWorkflowPlan({
      steps: [],
      id: '',
      error: '',
    });
    setEditingIndex(null);
  };

  const submit = async () => {
    const formValue = getValues();
    const payload: IActionPost = {
      name: formValue.content!,
      description: formValue.description,
      tool_id: formValue.toolId,
    };

    updateActionMutation(
      {
        payload,
        action_id: selectedAction.id!,
        callback: updatedAction,
      },
      {
        onSuccess: () => {
          showSnackbar(t('success.updateAction'), 'success');
        },
        onError: (error: unknown) => {
          showSnackbar(error as string, 'error');
        },
      }
    );
  };

  const search = () => {
    setShowSearch(true);
  };

  const updateFormData = (props: IAction | null) => {
    if (props) {
      reset({
        content: props.name,
        description: props.description,
      });
    }
  };

  const onChangeTool = async (value: number, isInit: boolean = false) => {
    setValue('toolGroupId', value);

    const data = await getToolGroup(value);
    setToolData(data);

    if (isInit && actionData) {
      setValue('toolId', actionData.tools[0].id ?? 0);
    }
  };

  useEffect(() => {
    setActionId(selectedAction.id!);
  }, [selectedAction, setActionId]);

  useEffect(() => {
    if (actionData) {
      setValue('content', actionData?.name);
      setValue('description', actionData?.description);
      setValue('toolId', actionData.tools[0].tool_group_id ?? 0);

      onChangeTool(actionData.tools[0].tool_group_id!, true);
    }
  }, [actionData, setValue]);

  return (
    <Box
      component='form'
      className={styles.actionForm}
      onSubmit={handleSubmit(submit)}
    >
      {/* 액션 이름 */}
      <Box sx={{ width: '100%' }}>
        <Box className={styles.actionFormItem}>
          <Box className={styles.labelBox}>
            <Typography className={styles.label}>
              {t('actionForm.actionName')}
              <span className={styles.require}>*</span>
            </Typography>
          </Box>
          <Box
            sx={{
              flex: '1 1 auto',
            }}
          >
            <TextField
              {...register('content', { required: t('errors.required') })}
              fullWidth
              error={!!errors.content}
              variant='outlined'
              size='small'
              className={styles.input}
              sx={{
                '& .MuiInputBase-root': {
                  backgroundColor: 'var(--white)',
                  borderRadius: '8px',
                  height: '32px',
                },
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-250)',
                },
              }}
            />
          </Box>
          <Box className={styles.searchBtnBox}>
            <Button
              variant='outlined'
              className={styles.searchBtn}
              onClick={search}
            >
              <ConeIcon width={18} height={18} />
              {t('actionForm.actionSearch')}
            </Button>
          </Box>
        </Box>

        {errors.content?.message && (
          <Box className={styles.errorMessage}>{errors.content?.message}</Box>
        )}
      </Box>
      {/* End 액션 이름 */}

      {/* 액션 기능 */}
      <Box sx={{ width: '100%' }}>
        <Box className={styles.actionFormItem}>
          <Box className={styles.labelBox}>
            <Typography className={styles.label}>
              {t('actionForm.actionFeature')}
              <span className={styles.require}>*</span>
            </Typography>
          </Box>
          <Box
            sx={{
              flex: '1 1 auto',
            }}
          >
            <TextField
              {...register('description', { required: t('errors.required') })}
              fullWidth
              error={!!errors.description}
              variant='outlined'
              size='small'
              minRows={3}
              multiline
              className={styles.input}
              sx={{
                '& .MuiInputBase-root': {
                  backgroundColor: 'var(--white)',
                  borderRadius: '8px',
                },
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-250)',
                },
              }}
            />
          </Box>
        </Box>

        {errors.content?.message && (
          <Box className={styles.errorMessage}>{errors.content?.message}</Box>
        )}
      </Box>
      {/* End 액션 기능 */}

      {/* 도구 연동 */}
      <Box sx={{ width: '100%' }}>
        <Box className={styles.actionFormItem} sx={{ marginBottom: '4px' }}>
          <Box className={styles.labelBox}>
            <Typography className={styles.label}>
              {t('actionForm.toolLinkage')}
            </Typography>
          </Box>
          <Box
            sx={{
              flex: '1 1 auto',
            }}
          >
            <Select
              {...register('toolGroupId')}
              onChange={(e) => onChangeTool(e.target.value as number)}
              variant='outlined'
              value={watch('toolGroupId') || null}
              fullWidth
              className={styles.select}
              IconComponent={ArrowDownIcon}
              size='small'
              MenuProps={{
                PaperProps: {
                  className: styles.customDropdownPaper,
                },
              }}
              sx={{
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-250)',
                },
                '& .MuiSelect-icon': {
                  color: 'var(--primitives-darkBlue-50)',
                  top: '6px',
                },
              }}
            >
              {groupToolData?.map((tool, index) => (
                <MenuItem value={tool.id} key={index}>
                  {tool.name}
                </MenuItem>
              ))}
            </Select>
          </Box>
        </Box>
        <Box className={styles.actionFormItem}>
          <Box className={styles.labelBox} />
          <Box
            sx={{
              flex: '1 1 auto',
            }}
          >
            <Select
              {...register('toolId')}
              onChange={(e) => setValue('toolId', e.target.value as number)}
              variant='outlined'
              value={watch('toolId') || null}
              fullWidth
              className={styles.select}
              IconComponent={ArrowDownIcon}
              size='small'
              MenuProps={{
                PaperProps: {
                  className: styles.customDropdownPaper,
                },
                disableScrollLock: true,
              }}
              sx={{
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-250)',
                },
                '.MuiSelect-icon': {
                  color: 'var(--primitives-darkBlue-50)',
                  top: '6px',
                },
              }}
            >
              {toolData?.map((tool, index) => (
                <MenuItem value={tool.id} key={index}>
                  {tool.name}
                </MenuItem>
              ))}
            </Select>
          </Box>
        </Box>

        {errors.content?.message && (
          <Box className={styles.errorMessage}>{errors.content?.message}</Box>
        )}
      </Box>

      <Box className={styles.btnGroup}>
        <Button variant='outlined' className={styles.closeBtn} onClick={cancel}>
          {t('actionForm.cancelBtn')}
        </Button>
        <Button variant='contained' type='submit' className={styles.submitBtn}>
          {t('actionForm.submitBtn')}
        </Button>
      </Box>
      {showSearch && (
        <SearchActionModal
          showSearch={showSearch}
          setShowSearch={setShowSearch}
          updateFormData={updateFormData}
        />
      )}
    </Box>
  );
};

export { WorkflowReviewEditForm };
