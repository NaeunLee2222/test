import IconCheckedCircle from '@/assets/basic-icons/icon-check-circled.svg?react';
import EditIcon from '@/assets/basic-icons/icon-edit.svg?react';
import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import ArrowUpIcon from '@/assets/direction-icons/icon-chevron-up.svg?react';
import styles from '@/modules/chat/components/ChatWorkflowReview/ChatWorkflowReview.module.scss';
import { WorkflowReviewEditForm } from '@/modules/chat/components/ChatWorkflowReview/WorkflowReviewEditForm';
import { WActionInfo, WPlanInfo } from '@/modules/chat/types/chatprocessing';
import { IEditingIndex } from '@/modules/chat/types/workflow-report';
import { parseLogToPlanInfo } from '@/utils/chatUtil';
import { Box, Button, Typography } from '@mui/material';
import cn from 'classnames';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { IConfig } from '../../types/message';

interface IProp {
  data: string | undefined | null;
  config?: IConfig;
  uuid: string;
  isReadOnly: boolean;
  planLive: WPlanInfo;
}

const ChatWorkflowReview = ({
  data,
  config,
  uuid,
  isReadOnly,
  planLive,
}: IProp) => {
  const { t } = useTranslation('tax');

  const [selectedAction, setSelectedAction] = useState<WActionInfo | null>(
    null
  );
  const [stepsData, setStepsData] = useState<WPlanInfo>();
  const [editingIndex, setEditingIndex] = useState<IEditingIndex | null>(null);
  const [openSteps, setOpenSteps] = useState<number[]>([]);

  useEffect(() => {
    if (planLive?.steps) {
      setStepsData(planLive as unknown as WPlanInfo);

      // planLive.steps가 배열인지 객체인지 확인
      if (Array.isArray(planLive.steps)) {
        // 배열인 경우
        setOpenSteps(planLive.steps.map((_, index) => index));
      } else if (typeof planLive.steps === 'object') {
        // 객체인 경우
        const stepsArray = Object.values(planLive.steps);
        setOpenSteps(stepsArray.map((_, index) => index));
      }
    } else if (data) {
      const formattedData = parseLogToPlanInfo(data);
      setStepsData(formattedData);

      // 모든 스텝을 기본적으로 펼쳐놓기
      if (formattedData.steps) {
        const stepsArray = Array.isArray(formattedData.steps)
          ? formattedData.steps
          : Object.values(formattedData.steps);
        setOpenSteps(stepsArray.map((_: any, index: any) => index));
      }
    }
  }, [data, planLive]);

  const toggleStep = (e: React.MouseEvent, index: number) => {
    e.stopPropagation();
    setOpenSteps((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const showEditForm = (
    e: React.MouseEvent<HTMLButtonElement>,
    stepId: string,
    actionId: string
  ) => {
    e.stopPropagation();
    setEditingIndex({ step: stepId, action: actionId });
    if (stepsData) {
      const stepList = stepsData.steps;
      const step = stepList[stepId as any];
      if (step) {
        const actionList = step.actions;
        const action = actionList[actionId as any];
        if (action) {
          setSelectedAction(action);
        }
      }
    }
  };

  const setSelectedActionClass = (stepIndex: string, actionIndex: string) =>
    editingIndex?.step === stepIndex && editingIndex?.action === actionIndex
      ? styles.activeAction
      : '';

  const stepGenerate = () => {
    if (!stepsData?.steps) return <></>;

    const stepsArray = Array.isArray(stepsData.steps)
      ? stepsData.steps
      : Object.values(stepsData.steps);

    return stepsArray.map((step: any, index) => (
      <Box className={styles.section} key={index}>
        <Box className={styles.sectionHeader}>
          <Box
            className={styles.headerTextWrapper}
            onClick={(e: React.MouseEvent) => toggleStep(e, index)}
          >
            <IconCheckedCircle width={16} fill='var(--primary-color-800)' />
            <Typography className={styles.headerText}>
              {`Step${index + 1}: `}
              {step.name}
            </Typography>
            {openSteps.includes(index) ? (
              <ArrowUpIcon
                width={20}
                height={20}
                className={styles.arrowIcon}
              />
            ) : (
              <ArrowDownIcon
                width={20}
                height={20}
                className={styles.arrowIcon}
              />
            )}
          </Box>
        </Box>
        {openSteps.includes(index) && (
          <Box className={styles.sectionTitle}>
            {step.actions &&
              Object.values(step.actions).map((action: any, i) =>
                editingIndex?.step === step.id &&
                editingIndex?.action === action.id ? (
                  <WorkflowReviewEditForm
                    stepIndex={index}
                    actionIndex={i}
                    setEditingIndex={setEditingIndex}
                    selectedAction={selectedAction!}
                    stepsData={stepsData}
                    config={config}
                    uuid={uuid}
                    key={i}
                  />
                ) : (
                  <Box sx={{ width: '100%' }} key={i}>
                    <Box
                      className={cn(
                        styles.action,
                        setSelectedActionClass(step.id ?? '', action.id ?? '')
                      )}
                    >
                      {!isReadOnly && (
                        <Button
                          className={styles.editBtn}
                          onClick={(e) => {
                            showEditForm(e, step.id ?? '', action.id ?? '');
                          }}
                        >
                          <EditIcon width={16} height={16} />
                          {t('editChat')}
                        </Button>
                      )}
                      <Typography className={styles.actionTitle}>
                        {/* <Box className={styles.titleNumber}>{`${i + 1}.`}</Box> */}
                        {`${action.name}`}
                      </Typography>
                      <Typography className={styles.actionDescription}>
                        {action.description}
                      </Typography>
                    </Box>
                  </Box>
                )
              )}
          </Box>
        )}
      </Box>
    ));
  };

  // 스텝 데이터가 있으면 렌더링
  const hasSteps =
    stepsData?.steps &&
    ((Array.isArray(stepsData.steps) && stepsData.steps.length > 0) ||
      (!Array.isArray(stepsData.steps) &&
        Object.keys(stepsData.steps).length > 0));

  return hasSteps ? (
    <Box className={styles.chatWorkflowReview}>
      <Box className={styles.sections}>{stepGenerate()}</Box>
    </Box>
  ) : (
    <></>
  );
};

export { ChatWorkflowReview };
