import CloseIcon from '@/assets/basic-icons/icon-close-01.svg?react';
import emptyFolder from '@/assets/images/empty-folder.png';
import loadingIcon from '@/assets/lotties/loading-icon.json';
import SearchInput from '@/modules/admin/components/Search/Input';
import { getListTool } from '@/modules/agent/api/agent';
import { IAction } from '@/modules/agent/type/agent';
import styles from '@/modules/chat/components/ChatWorkflowReview/SearchActionModal.module.scss';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import PanoramaFishEyeIcon from '@mui/icons-material/PanoramaFishEye';
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';
import { Box, Button, debounce, Modal, Typography } from '@mui/material';
import cn from 'classnames';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface IProp {
  showSearch: boolean;
  setShowSearch: React.Dispatch<React.SetStateAction<boolean>>;
  updateFormData: (props: IAction | null) => void;
}

const SearchActionModal = ({
  showSearch,
  setShowSearch,
  updateFormData,
}: IProp) => {
  const [actionList, setActionList] = useState<IAction[]>([]);
  const { t } = useTranslation('tax');
  const handleClose = () => {
    setShowSearch(false);
  };
  const [selectedAction, setSelectedAction] = useState<IAction | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState('');

  const debounceFn = useCallback(
    debounce((text?: string) => {
      setLoading(true);
      getListTool(text)
        .then((response) => {
          if (response) {
            setActionList(response);
          }
        })
        .catch((error) => {
          console.error('Error fetching data:', error);
          throw error;
        })
        .finally(() => {
          setLoading(false);
        });
    }, 1000),
    []
  );

  useEffect(() => {
    setLoading(true);
    debounceFn();
  }, [debounceFn]);

  const close = () => {
    setShowSearch(false);
  };

  const clickUseBtn = () => {
    updateFormData(selectedAction);
    close();
  };

  useEffect(() => {
    debounceFn(search);
  }, [search]);

  const showActionList = () => {
    if (loading) {
      return (
        <Box className={styles.loading}>
          <LottiePlayer
            options={{
              renderer: 'svg',
              loop: true,
              autoplay: true,
              animationData: loadingIcon,
            }}
            width={100}
            height={100}
          />
        </Box>
      );
    }

    if (!loading && actionList?.length === 0) {
      return (
        <Box className={styles.noData}>
          <Box className={cn(styles.noDataIconWrap)}>
            <img
              src={emptyFolder}
              alt='no report data'
              width={80}
              height={80}
              draggable='false'
            />
          </Box>
          <span>{t('report.list.empty')}</span>
        </Box>
      );
    }

    return (
      <Box className={styles.actionList}>
        {actionList.map((action, index) => (
          <Box
            className={cn(
              styles.action,
              action.id === selectedAction?.id ? styles.selectedAction : ''
            )}
            key={action.id.toString() + index}
            onClick={() => setSelectedAction(action)}
          >
            {action.id === selectedAction?.id ? (
              <RadioButtonCheckedIcon
                sx={{ color: 'var(  --primary-color-800)' }}
              />
            ) : (
              <PanoramaFishEyeIcon sx={{ color: 'var(  --gray-300)' }} />
            )}
            <Box className={styles.actionContent}>
              <Box className={styles.title}>{action.name}</Box>
              <Box className={styles.description}>{action.description}</Box>
              <Box className={styles.equipment}>
                {action?.tools?.length > 0 &&
                  `${t('equipment')}: ${action.tools.map((tool) => tool.name).join(', ')}`}
              </Box>
            </Box>
          </Box>
        ))}
      </Box>
    );
  };

  return (
    <Modal open={showSearch} onClose={handleClose}>
      <Box className={styles.searchActionModal}>
        <Box className={styles.modalHeader}>
          <Typography className={styles.headerTitle}>{t('action')}</Typography>
          <CloseIcon className={styles.cursorPointer} onClick={close} />
        </Box>
        <Box className={styles.modalContent}>
          <SearchInput
            onKeyUp={() => {}}
            setSearch={setSearch}
            placeholder={t('actionForm.searchActionPlaceholder')}
            search={search}
            className={styles.textField}
          />
          {showActionList()}
        </Box>
        <Box className={styles.modalFooter}>
          <Button
            variant='outlined'
            onClick={close}
            className={styles.closeBtn}
          >
            {t('actionForm.cancelBtn')}
          </Button>
          <Button
            variant='contained'
            type='submit'
            className={styles.useBtn}
            sx={{
              '&.Mui-disabled': {
                opacity: 0.3,
                backgroundColor: 'var(--primary-color-800)',
                color: 'var(--white)',
              },
            }}
            disabled={!selectedAction}
            onClick={clickUseBtn}
          >
            {t('actionForm.useBtn')}
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export { SearchActionModal };
