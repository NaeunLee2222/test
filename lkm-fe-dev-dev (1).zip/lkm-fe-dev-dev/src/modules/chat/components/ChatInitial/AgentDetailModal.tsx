import IconAvailAgent from '@/assets/basic-icons/icon-agent-detail.svg?react';
import IconClose from '@/assets/basic-icons/icon-close-01.svg?react';
import IconStepCheck from '@/assets/basic-icons/icon-step-check.svg?react';
import IconStepDivider from '@/assets/basic-icons/icon-step-divider.svg?react';

import loadingIcon from '@/assets/lotties/loading-icon.json';
import { AgentType } from '@/modules/agent/type/agent';
import styles from '@/modules/chat/components/ChatInitial/ChatAgentList.module.scss';
import { useAgentDetail } from '@/modules/chat/hooks/useAgents';
import {
  conversationStarterMessageAtom,
  currentMessagesAtom,
  messagesOrderAtom,
} from '@/modules/chat/jotai/chat';
import { EChatMode } from '@/modules/chat/types/chat';
import { USER_ID } from '@/modules/chat/types/user';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { EChatType } from '@/modules/core/types';
import { RoutesURL } from '@/routers/routes';
import {
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  IconButton,
  styled,
  Typography,
} from '@mui/material';
import cn from 'classnames';
import { useAtom, useSetAtom } from 'jotai';
import { useCallback } from 'react';
import { useCookies } from 'react-cookie';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';

const MOCK_MODEL = 'chatgpt4.o';

interface IAgentDetailModalProps {
  onOpen: boolean;
  onClose: () => void;
  isLoading?: boolean;
  setIsLoading?: (value: boolean) => void;
}

export const AgentDetailModal = ({
  onOpen,
  onClose,
  isLoading,
  setIsLoading,
}: IAgentDetailModalProps) => {
  const { t } = useTranslation('tax');
  const [cookies] = useCookies([USER_ID]);
  const { createChat } = useMainContext();
  const navigate = useNavigate();
  const [{ data: agentDetailData }] = useAtom(useAgentDetail);
  const setCurrentMessages = useSetAtom(currentMessagesAtom);
  const setMessagesOrder = useSetAtom(messagesOrderAtom);
  const setConversationStarterMessage = useSetAtom(
    conversationStarterMessageAtom
  );

  const questions = [
    '오늘 어떤 기술적 이슈를 해결해야 하나\n요? 함께 살펴볼까요?',
    '작업 중인 프로젝트에 도움이 필요하신가\n요? 로그 분석부터 디버깅까지 도와드릴게요',
    '에러 메시지나 코드 관련 질문이 있다면 말\n씀해 주세요. 빠르게 진단해드릴게요.',
    '배포, 테스트 자동화, 코드 리뷰 중 어떤 업\n무를 도와드릴까요?',
  ];

  const handleClose = useCallback(() => {
    onClose();
  }, [onClose]);

  const handleConfirm = useCallback(() => {
    setIsLoading && setIsLoading(true);
    createChat({
      agentId: agentDetailData?.formattedData?.id ?? '',
      chatMode: EChatMode.AGENT_CHAT,
      userId: cookies.userId,
      title: agentDetailData?.formattedData?.name ?? '',
      model: MOCK_MODEL,
      callback: (createChatData: any) => {
        setIsLoading && setIsLoading(false);
        handleClose();
        const agentGreetingUuid = uuidv4();
        setCurrentMessages([agentGreetingUuid]);
        setMessagesOrder([0]);

        navigate(`${RoutesURL.CHAT}/${createChatData?.id}`);
      },
      chatType: EChatType.ExpertAgentChat,
    });
  }, [
    agentDetailData?.formattedData?.id,
    agentDetailData?.formattedData?.name,
    cookies.userId,
    createChat,
    handleClose,
    navigate,
    setCurrentMessages,
    setIsLoading,
    setMessagesOrder,
  ]);

  return (
    <div className={styles.agentContainer}>
      <CustomDialog
        open={onOpen}
        onClose={handleClose}
        className={styles.settingModal}
      >
        <Box sx={{ height: '56px', padding: '24px 24px 8px 24px' }}>
          <IconButton
            aria-label='close'
            onClick={onClose}
            sx={() => ({
              position: 'absolute',
              right: '16px',
              top: '18px',
            })}
            className={styles.iconClose}
          >
            <IconClose />
          </IconButton>
        </Box>

        <DialogContent className={styles.content}>
          {isLoading || !agentDetailData ? (
            <Box
              className={`${styles.agentDetailContainer} ${styles.loadingCenter}`}
            >
              <Box className={styles.loading}>
                <LottiePlayer
                  options={{
                    renderer: 'svg',
                    loop: true,
                    autoplay: true,
                    animationData: loadingIcon,
                  }}
                  width={100}
                  height={100}
                />
              </Box>
            </Box>
          ) : (
            <Box className={styles.titleDialog}>
              <Box
                className={cn(
                  styles.paddingBottom,
                  styles.styleAgentNameWrapper
                )}
              >
                <IconAvailAgent />
                <Typography className={styles.agentName}>
                  {agentDetailData?.formattedData?.name}
                </Typography>
              </Box>
              <Box className={styles.paddingBottom}>
                <Typography className={styles.agentDescriptionLabel}>
                  {t('agent.detail.name')}
                </Typography>
                <Box className={styles.agentDetailContent}>
                  <Typography className={styles.selectedAgentDescription}>
                    {agentDetailData?.formattedData?.description}
                  </Typography>
                </Box>
              </Box>
              {agentDetailData?.rawData?.agent_type === AgentType.PRO &&
                agentDetailData?.rawData?.steps &&
                agentDetailData?.rawData?.steps?.length > 0 && (
                  <Box>
                    <Box className={styles.paddingBottom}>
                      <Typography className={styles.stepLabel}>
                        {t('agent.detail.steps')}
                      </Typography>
                      <Box className={styles.agentStep}>
                        {agentDetailData?.rawData?.steps?.map((step, index) => (
                          <Box
                            key={step.name + step.order}
                            className={styles.stepBox}
                          >
                            <Typography className={styles.stepName}>
                              <IconStepCheck />
                              {step.name}
                            </Typography>

                            {index <
                              (agentDetailData?.rawData?.steps ?? []).length -
                                1 && (
                              <Box sx={{ marginLeft: '6px' }}>
                                <IconStepDivider />
                              </Box>
                            )}
                          </Box>
                        ))}
                      </Box>
                    </Box>
                  </Box>
                )}
              <Box className={styles.paddingBottom}>
                <Typography className={styles.agentDescriptionLabel}>
                  {t('agent.detail.conversationStarter')}
                </Typography>
                <Box className={styles.conversationStarter}>
                  {questions?.map((step) => (
                    <Typography
                      onClick={() => {
                        setConversationStarterMessage(step);
                        handleConfirm();
                      }}
                      key={step}
                      className={styles.question}
                    >
                      {step}
                    </Typography>
                  ))}
                </Box>
              </Box>
            </Box>
          )}
        </DialogContent>

        <DialogActions sx={{ padding: '8px 24px 16px 24px' }}>
          <BaseButton
            sx={{
              width: '100%',
              color: 'white',
              height: '32px',
              fontSize: '13px',
              fontWeight: 500,
              lineHeight: '18.85px',
              letterSpacing: '0.03px',
              backgroundColor: 'var(--gradient-primary-color)',
              padding: '6px 10px',
              borderRadius: '99px',
            }}
            disabled={isLoading || !agentDetailData}
            autoFocus
            className={styles.btnStyles}
            onClick={() => {
              setIsLoading && setIsLoading(true);
              handleConfirm();
              setConversationStarterMessage(undefined);
            }}
          >
            <span>{t('agent.detail.start')}</span>
          </BaseButton>
        </DialogActions>
      </CustomDialog>
    </div>
  );
};

const CustomDialog = styled(Dialog)({
  '.MuiDialog-paper': {
    width: '560px',
    maxHeight: 'calc(100vh - 96px)',
    maxWidth: '90vw',
    borderRadius: '12px',
    boxShadow: '0px 0px 15px 0px rgba(0, 0, 0, 0.15)',
    display: 'flex',
    flexDirection: 'column',
    overFlowY: 'auto',

    '.MuiDialogTitle-root': {
      padding: '24px 24px 8px 24px',
      fontWeight: '600',
      lineHeight: '29px',
      letterSpacing: '-0.1px',
      flexShrink: 0,
    },

    '.MuiIconButton-root': {
      '&:hover': {
        backgroundColor: 'transparent',
      },
    },

    '.MuiDialogContent-root': {
      padding: '0 24px 24px 24px',
      overflowY: 'auto',
      flex: '1 1 auto',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'auto',
    },

    '.MuiDialogActions-root': {
      flexShrink: 0,
    },
  },
});
