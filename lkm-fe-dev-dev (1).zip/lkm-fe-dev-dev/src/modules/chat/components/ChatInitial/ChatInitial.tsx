import { ChatAgentList } from '@/modules/chat/components/ChatInitial/ChatAgentList';
import styles from '@/modules/chat/components/ChatInitial/ChatInitial.module.scss';
import { ChatInput } from '@/modules/chat/components/ChatInput/ChatInput';
import { useUserMe } from '@/modules/core/hooks';
import {
  isAiChatScreen,
  isSuperAgentChatScreen,
  isMainScreen,
} from '@/utils/chatUtil';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';

interface ISpanData {
  className: string;
  value: string;
}

export const ChatInitial = () => {
  const { t } = useTranslation('tax');
  const [{ data: userData, isFetched }] = useAtom(useUserMe);
  const path = useLocation().pathname;

  const titleText = useMemo(() => {
    let userName =
      userData?.username?.indexOf('/') > -1
        ? userData?.username?.split('/')[0]
        : userData?.username;
    userName = userName?.split('(')[0];
    return userName
      ? _.concat(
          `${userName}님, `.split('').reduce((acc, cur) => {
            acc.push({ className: styles.userName, value: cur });
            return acc;
          }, [] as ISpanData[]),
          t('initial.greeting')
            .split('')
            .reduce((acc, cur) => {
              acc.push({ className: styles.greeting, value: cur });
              return acc;
            }, [] as ISpanData[])
        )
      : [];
  }, [t, userData]);

  const [displayedText, setDisplayedText] = useState<ISpanData[]>([]);
  const [isTyping, setIsTyping] = useState(true);
  const currentIndex = useRef<number>(0);

  useEffect(() => {
    if (!isFetched) return;
    const localIndex = currentIndex.current;
    if (localIndex < titleText.length) {
      const timeout = setTimeout(() => {
        setDisplayedText((prev) => [...prev, titleText[localIndex]]);
        currentIndex.current = localIndex + 1;
        setIsTyping(true);
      }, 30); // 글자가 나타나는 간격 (밀리초)
      return () => {
        clearTimeout(timeout);
      };
    }
    if (localIndex >= titleText.length) {
      setDisplayedText(titleText);
      setIsTyping(false);
    }
  }, [displayedText, titleText, isFetched]);

  const isAi = isAiChatScreen(path);
  const isSuperAgent = isSuperAgentChatScreen(path);
  const isMain = isMainScreen(path);

  return (
    <div className={styles.container}>
      <div className={styles.backgroundImage} />
      <div className={styles.chatInitial}>
        <div className={styles.header}>
          <div className={styles.wrapper}>
            <div>
              {isAi && (
                <span
                  className={styles.title}
                  style={{
                    marginTop: '32px',
                  }}
                >
                  {t('initial.welcome.firstLineAi')}
                </span>
              )}
              {isSuperAgent && (
                <span className={styles.title}>
                  {t('initial.welcome.firstLineSuperAgent')}
                </span>
              )}
              {isMain && (
                <span className={styles.title}>
                  {t('initial.welcome.firstLine')}
                </span>
              )}
            </div>
            <ChatInput hideModelVersion />
          </div>
        </div>
        <div className={styles.agentFlexGrow}>
          {isMain && <ChatAgentList visible={!isTyping} />}
        </div>
      </div>
    </div>
  );
};
