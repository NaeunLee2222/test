import PreviousIcon from '@/assets/direction-icons/icon-chevron-left.svg?react';
import NextIcon from '@/assets/direction-icons/icon-chevron-right.svg?react';
import ChatAgent from '@/modules/chat/components/ChatAgent/ChatAgent';
import { AgentDetailModal } from '@/modules/chat/components/ChatInitial/AgentDetailModal';
import styles from '@/modules/chat/components/ChatInitial/ChatAgentList.module.scss';
import {
  MAX_PAGE,
  MIN_PAGE,
  ROW_PER_PAGE,
} from '@/modules/chat/constanst/agent.const';
import {
  AGENT_KEY,
  useDisabledAgentsData,
} from '@/modules/chat/hooks/useAgents';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import { IChatAgent } from '@/modules/chat/types/agents';
import { queryClient } from '@/modules/core/hooks';
import { Box, Button } from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue } from 'jotai';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

export const ChatAgentList = ({ visible }: { visible: boolean }) => {
  const { t } = useTranslation('tax');
  const [, setAgentDetailId] = useAtom(agentDetailIdAtom);
  const handleAgentClicked = (agent: IChatAgent) => {
    setOpenDialog(true);
    setAgentDetailId(agent.id);
  };
  const { data } = useAtomValue(useDisabledAgentsData);

  const [openDialog, setOpenDialog] = useState(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [page, setPage] = useState(MIN_PAGE);

  const handleClose = () => {
    setOpenDialog(false);
  };

  useEffect(
    () => () => {
      queryClient.removeQueries({ queryKey: [...AGENT_KEY], exact: false });
    },
    []
  );

  return (
    <div className={cn(styles.agentContainer, visible && styles.visible)}>
      <div className={styles.chevrons}>
        <div className={styles.description}>
          <span className={styles.agentTitle}>
            {t('agent.availableAgents')}
          </span>

          <div className={styles.navigateContainer}>
            <Button
              disabled={page === MIN_PAGE || data?.agents?.length === 0}
              className={styles.pageButton}
              onClick={() => {
                setPage(page > MIN_PAGE ? page - 1 : MIN_PAGE);
              }}
            >
              <PreviousIcon />
            </Button>

            <Button
              disabled={
                page === MAX_PAGE ||
                data?.agents?.length === 0 ||
                (data?.agents &&
                  data?.agents?.length < (page + 1) * ROW_PER_PAGE)
              }
              className={styles.pageButton}
              onClick={() => {
                setPage(page < MAX_PAGE ? page + 1 : MAX_PAGE);
              }}
            >
              <NextIcon />
            </Button>
          </div>
        </div>

        <Box className={styles.agentBox}>
          <ChatAgent handleAgentClicked={handleAgentClicked} page={page} />
        </Box>
      </div>

      <AgentDetailModal
        onOpen={openDialog}
        onClose={handleClose}
        isLoading={isLoading}
        setIsLoading={setIsLoading}
      />
    </div>
  );
};
