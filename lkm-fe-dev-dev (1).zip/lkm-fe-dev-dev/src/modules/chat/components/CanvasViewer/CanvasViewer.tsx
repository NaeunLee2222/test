import AgentChatContent from '@/modules/chat/components/AgentChatContent/AgentChatContent';
import Canvas from '@/modules/chat/components/Canvas/Canvas';
import styles from '@/modules/chat/components/CanvasViewer/CanvasViewer.module.scss';
import { isOpenLnbAtom } from '@/modules/core/jotai/layout';
import { Box } from '@mui/material';
import { useAtom } from 'jotai';
import { useEffect } from 'react';

const CanvasViewer = () => {
  const [, setIsOpenLnb] = useAtom(isOpenLnbAtom);

  useEffect(() => {
    setIsOpenLnb?.(false);
  }, [setIsOpenLnb]);

  return (
    <Box className={styles.container}>
      <AgentChatContent resizable />
      <Box className={styles.presentationWrapper}>
        <Canvas />
      </Box>
    </Box>
  );
};

export default CanvasViewer;
