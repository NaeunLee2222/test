import SearchIcon from '@/assets/basic-icons/icon-magnify.svg?react';
import { IHistory } from '@/modules/chat/types/history';
import { BaseWrappedTextFieldSx } from '@/modules/core/components/common/BaseTextField';
import { IconButton, TextField } from '@mui/material';
import cn from 'classnames';
import { atom, useAtom } from 'jotai';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import InfiniteScroll from 'react-infinite-scroller';
import { getHistoryDataAtom } from '../../hooks/useHistoryData';
import { libraryDialogDataAtom } from '../../jotai/library';
import styles from '../ChatLibrary/ChatLibrary.module.scss';
import { DeleteAllHistoryButton } from '../ChatLibrary/DeleteAllHistoryButton';
import { ChatHistoryItemSubmenu } from './ChatHistoryItemSubmenu';
import { ChatLibraryHistoryItem } from './ChatLibraryHistoryItem';

export const historySearchAtom = atom({
  search: '',
  libraryId: -1,
  includeContent: true,
});

interface IProps {
  hideHeader?: boolean;
}
const ChatLibraryHistoryList = ({ hideHeader = false }: IProps) => {
  const { t } = useTranslation('tax');
  const [, setHistorySearchData] = useAtom(historySearchAtom);

  useEffect(() => {
    setHistorySearchData({
      search: '',
      libraryId: -1,
      includeContent: true,
    });
  }, [setHistorySearchData]);

  const useLibraryHistoryData = useMemo(
    () => getHistoryDataAtom(historySearchAtom),
    []
  );

  const [
    {
      data: historyData,
      isFetchingNextPage,
      isLoading,
      isError,
      hasNextPage,
      fetchNextPage,
    },
  ] = useAtom(useLibraryHistoryData);

  const historyList = useMemo<IHistory[]>(
    () => (historyData?.pages?.flat() as IHistory[]) || [],
    [historyData]
  );

  const [anchorEl, setAnchorEl] = useState<Element | null>(null);
  const submenuOpen = Boolean(anchorEl);

  const [isEditTitle, setIsEditTitle] = useState<boolean>(false);
  const [submenuHistoryData, setSubmenuHistoryData] = useState<
    IHistory | undefined
  >();

  const handleSubmenuClick = useCallback(
    (event?: any, _historyData?: IHistory) => {
      if (_historyData !== undefined) {
        setAnchorEl(event?.currentTarget);
        setSubmenuHistoryData(_historyData);
      }
    },
    []
  );

  const handleEditTitle = useCallback((isEdit: boolean) => {
    setIsEditTitle(isEdit);
  }, []);

  const [, setLibraryDialogData] = useAtom(libraryDialogDataAtom);
  const handleEditLibrary = useCallback(() => {
    if (!submenuHistoryData?.id) return;
    setLibraryDialogData({
      dialogOpen: true,
      id: -1,
      title: '',
      targetHistoryId: submenuHistoryData.id,
      type: 'select',
    });
  }, [setLibraryDialogData, submenuHistoryData?.id]);

  const handleSubmenuClose = useCallback(() => {
    setAnchorEl(null);
  }, []);

  const inputRef = useRef<HTMLInputElement>(null);
  const handleSearch = useCallback(() => {
    const newSearch = inputRef.current?.value || '';
    setHistorySearchData((prev) => ({ ...prev, search: newSearch }));
  }, []);

  const handleOnKeyUpToSend = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        handleSearch();
      }
    },

    []
  );

  const handleOnKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
      }
    },
    []
  );

  return (
    <div className={styles.historyList}>
      {!hideHeader && (
        <div className={styles.header}>
          <div className={styles.title}>{t('history.title')}</div>
          <TextField
            id='search'
            className={`app-input rounded ${styles.search}`}
            inputRef={inputRef}
            placeholder={t('history.search')}
            onKeyUp={handleOnKeyUpToSend}
            onKeyDown={handleOnKeyDown}
            sx={BaseWrappedTextFieldSx}
            InputProps={{
              endAdornment: (
                <IconButton onClick={handleSearch} sx={{ padding: '4px' }}>
                  <SearchIcon />
                </IconButton>
              ),
            }}
          />
          <DeleteAllHistoryButton
            noData={!historyList?.length}
            disabled={!historyList?.length || isLoading}
          />
        </div>
      )}
      {isError ? (
        <div className={styles.error}>{t('history.error')}</div>
      ) : (
        <InfiniteScroll
          pageStart={0}
          loadMore={() => {
            if (!isLoading && !isFetchingNextPage && hasNextPage)
              fetchNextPage();
          }}
          hasMore={true || false}
          className={isLoading ? 'loaderWrap' : cn(styles.list, styles.column)}
          loader={
            isLoading ? (
              <span key={0} className='loader' />
            ) : !historyList?.length ? (
              <div key={0} className={styles.noData}>
                {t('history.noData')}
              </div>
            ) : (
              <span key={0} />
            )
          }
          useWindow={false}
        >
          {historyList.map((historyItem) => (
            <ChatLibraryHistoryItem
              key={historyItem.id}
              isLoading={isLoading}
              historyData={historyItem}
              handleSubmenuClick={handleSubmenuClick}
              isEditTitle={
                isEditTitle && submenuHistoryData?.id === historyItem.id
              }
              handleEditTitle={handleEditTitle}
            />
          ))}
        </InfiniteScroll>
      )}
      {!!anchorEl && (
        <ChatHistoryItemSubmenu
          anchorEl={anchorEl!}
          open={submenuOpen}
          submenuHistoryItem={submenuHistoryData}
          handleSubmenuClose={handleSubmenuClose}
          handleEditTitle={handleEditTitle}
          handleEditLibrary={handleEditLibrary}
        />
      )}
    </div>
  );
};

export { ChatLibraryHistoryList };
