import IconAddBox from '@/assets/basic-icons/icon-add-box.svg?react';
import IconPencil from '@/assets/basic-icons/icon-pencil-16.svg?react';
import IconTrashCan from '@/assets/basic-icons/icon-trashcan.svg?react';
import { IHistory } from '@/modules/chat/types/history';
import { BaseMenu } from '@/modules/core/components/common/BaseMenu';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { screenLoaderDataAtom } from '@/modules/core/jotai/loader';
import { ListItemIcon, ListItemText, MenuItem } from '@mui/material';
import { useAtom } from 'jotai';
import { useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router-dom';
import { deleteHistoryByIdAtom } from '../../hooks/useHistoryData';

interface Props {
  anchorEl: Element;
  open: boolean;
  submenuHistoryItem?: IHistory;
  handleEditTitle: (isEdit: boolean) => void;
  handleEditLibrary?: () => void;
  handleSubmenuClose: () => void;
}

export const ChatHistoryItemSubmenu = ({
  anchorEl,
  open,
  submenuHistoryItem,
  handleEditTitle,
  handleSubmenuClose,
  handleEditLibrary,
}: Props) => {
  const { t } = useTranslation('tax');

  const [, setConfirmData] = useAtom(confirmDialogDataAtom);
  const [{ mutateAsync: deleteHistory }] = useAtom(deleteHistoryByIdAtom);
  const [, setScreenLoaderAtom] = useAtom(screenLoaderDataAtom);

  const params = useParams();
  const isLibraryDetail = useMemo(() => !!params?.libraryId, [params]);

  const handleDeleteHistory = useCallback(async () => {
    if (!submenuHistoryItem) return;
    handleSubmenuClose();
    setConfirmData({
      open: true,
      title: t('history.confirmDelete.select.title'),
      contentText: (
        <span style={{ fontSize: '15px' }}>
          {t('history.confirmDelete.select.content')}
        </span>
      ),
      handleConfirm: async () => {
        setConfirmData({ open: false });
        setScreenLoaderAtom({
          key: 'history.delete',
          loading: true,
        });
        await deleteHistory({ id: submenuHistoryItem.id });
        setScreenLoaderAtom({
          key: 'history.delete',
          loading: false,
        });
      },
      handleCancel: () => {
        setConfirmData({ open: false });
      },
    });
  }, [submenuHistoryItem]);

  const handleEnableEditTitle = useCallback(async () => {
    if (!submenuHistoryItem) return;
    handleEditTitle(true);
    handleSubmenuClose();
  }, [submenuHistoryItem]);

  const handleEditLibraryOfHistory = useCallback(async () => {
    if (!submenuHistoryItem) return;
    handleEditLibrary?.();
    handleSubmenuClose();
  }, [submenuHistoryItem]);

  return (
    <BaseMenu
      id='sub-menu'
      disableAutoFocus
      anchorEl={anchorEl}
      keepMounted
      open={open}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'right',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'right',
      }}
      onClose={handleSubmenuClose}
    >
      <MenuItem onClick={handleEnableEditTitle}>
        <ListItemIcon>
          <IconPencil />
        </ListItemIcon>
        <ListItemText primaryTypographyProps={{ fontSize: '14px' }}>
          {t('chat.action.editTitle')}
        </ListItemText>
      </MenuItem>
      {handleEditLibrary && (
        <MenuItem onClick={handleEditLibraryOfHistory}>
          <ListItemIcon>
            <IconAddBox />
          </ListItemIcon>
          <ListItemText primaryTypographyProps={{ fontSize: '14px' }}>
            {isLibraryDetail
              ? t('chat.action.setLibrary')
              : t('chat.action.editLibrary')}
          </ListItemText>
        </MenuItem>
      )}
      <MenuItem onClick={handleDeleteHistory} sx={{ color: '#FA5252' }}>
        <ListItemIcon>
          <IconTrashCan fill='#FA5252' />
        </ListItemIcon>
        <ListItemText primaryTypographyProps={{ fontSize: '14px' }}>
          {t('chat.action.delete')}
        </ListItemText>
      </MenuItem>
    </BaseMenu>
  );
};
