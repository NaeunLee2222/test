import IconEllipsis from '@/assets/basic-icons/icon-ellipsis.svg?react';
import { IHistory } from '@/modules/chat/types/history';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseMenu } from '@/modules/core/components/common/BaseMenu';
import { BaseTextField } from '@/modules/core/components/common/BaseTextField';
import { useKeyEscClose } from '@/modules/core/hooks/useEscHook';
import { getDateAndTimeStr } from '@/utils';
import { Button, IconButton, MenuItem } from '@mui/material';
import { useAtom } from 'jotai';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import {
  deleteHistoryByIdAtom,
  updateHistoryTitleAtom,
} from '../../hooks/useHistoryData';
import { useLibraryData } from '../../hooks/useLibraryData';
import { ChatMarkdownSimple } from '../ChatContent/ChatMarkdownSimple';
import styles from './ChatLibraryHistoryItem.module.scss';

interface IProps {
  isLoading: boolean;
  historyData: IHistory;
  isEditTitle: boolean;
  handleEditTitle: (isEdit: boolean) => void;
  handleSubmenuClick: (event: any, historyData?: IHistory) => void;
}

export const ChatLibraryHistoryItem = ({
  isLoading,
  historyData,
  isEditTitle,
  handleEditTitle,
  handleSubmenuClick,
}: IProps) => {
  const { t } = useTranslation('tax');

  const navigate = useNavigate();
  const params = useParams();

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [activeItemId, setActiveItemId] = useState<number | null>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const inputRef = useRef<HTMLDivElement>(null);

  const isLibraryDetail = useMemo(() => !!params?.libraryId, [params]);
  const handleOnClickHistory = () => {
    const libraryId = params?.libraryId ?? -1;
    navigate(`/chat/h/${historyData.id}`, {
      state: { fromLibraryId: libraryId },
    });
  };

  const [title, setTitle] = useState<string>(historyData.title);
  const [isModified, setIsModified] = useState(false);

  const [{ status: deleteStatus }] = useAtom(deleteHistoryByIdAtom);
  const [{ mutate: updateHistoryTitle, status: updateStatus }] = useAtom(
    updateHistoryTitleAtom
  );

  const [{ data: libraryData }] = useAtom(useLibraryData);

  const includedLibraryList = useMemo(
    () =>
      libraryData?.libraryList?.filter((library) =>
        library.historyIdList?.includes(historyData.id)
      ),
    [libraryData, historyData.id]
  );

  const handleUpdateTitle = async () => {
    if (!isEditTitle) return;
    const originTitle = historyData.title;
    if (historyData?.title !== title) {
      updateHistoryTitle(
        {
          id: historyData.id,
          title,
        },
        {
          onError: () => {
            historyData.title = originTitle;
          },
        }
      );
    }
    historyData.title = title;
    handleEditTitle(false);
    setIsModified(false);
  };

  const handleEditTitleKey = (e: any) => {
    e.stopPropagation();
    if (e.key === 'Enter') {
      handleUpdateTitle();
      e.target?.blur();
    }
  };

  const handleEditTitleChange = (e: any) => {
    e.stopPropagation();
    const newTitle = e.target.value;
    setTitle(newTitle);
    setIsModified(newTitle !== historyData.title);
  };

  const stopEventPropagation = (e: React.UIEvent) => {
    e.stopPropagation();
  };

  useKeyEscClose(() => {
    setTitle(historyData.title);
    handleEditTitle(false);
    setIsModified(false);
  });

  const libraryMoreChipRef = useRef<any>(null);
  const [openLibraryMoreMenu, setOpenLibraryMoreMenu] = useState(false);

  const handleClickOutside = (event: MouseEvent) => {
    if (
      anchorEl &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node)
    ) {
      setAnchorEl(null);
      setActiveItemId(null);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [anchorEl]);

  useEffect(() => {
    const handleClickOutsideWhenEditTitle = (event: MouseEvent) => {
      if (
        isEditTitle &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setTitle(historyData.title);
        handleEditTitle(false);
        setIsModified(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutsideWhenEditTitle);
    return () => {
      document.removeEventListener(
        'mousedown',
        handleClickOutsideWhenEditTitle
      );
    };
  }, [isEditTitle, historyData.title, handleEditTitle]);

  return (
    <div key={historyData.id} className={styles.listItem}>
      <div
        role='presentation'
        className={styles.titleContainer}
        onClick={handleOnClickHistory}
      >
        {isEditTitle ? (
          <div className={styles.editWrap} ref={inputRef}>
            <BaseTextField
              id='title-edit'
              size='small'
              className={styles.input}
              onChange={handleEditTitleChange}
              onKeyUp={handleEditTitleKey}
              onClick={stopEventPropagation}
              defaultValue={title}
              fullWidth
              autoFocus
              sx={{
                '& .MuiInputBase-root': {
                  border: '1px solid var(--gray-300)',
                  borderRadius: '8px !important',
                  height: '40px !important',
                  '&.Mui-focused': {
                    border: '1px solid var(--primary-color-500)',
                  },
                  '& .MuiInputBase-input': {
                    fontSize: '16px',
                    fontWeight: '600',
                  },
                },
              }}
            />
            <BaseButton
              onClick={(e) => {
                stopEventPropagation(e);
                handleUpdateTitle();
              }}
              disabled={!isModified}
              sx={{
                borderRadius: '6px !important',
              }}
            >
              {t('apply')}
            </BaseButton>
          </div>
        ) : (
          <span className={styles.title}>{historyData?.title ?? ''}</span>
        )}
        <div className={styles.content}>
          <ChatMarkdownSimple
            message={
              historyData?.content === undefined || historyData?.content === ''
                ? '내용이 없습니다.'
                : historyData.content
            }
          />
        </div>
      </div>
      <div className={styles.action}>
        <span className={styles.date}>
          {getDateAndTimeStr(historyData?.createdAt) ?? ''}
        </span>
        <div className='flex' style={{ gap: '8px' }}>
          {!isLibraryDetail && (
            <div className={styles.chipList} ref={libraryMoreChipRef}>
              {includedLibraryList?.reduce((acc, library, idx, arr) => {
                if (idx < 3) {
                  acc.push(
                    <Button
                      key={`library-${library.id}`}
                      className={styles.libraryChip}
                      onClick={() => {
                        navigate(`/library/${library.id}`);
                      }}
                    >
                      <span>{library.title}</span>
                    </Button>
                  );
                } else if (idx === 3) {
                  acc.push(
                    <Button
                      className={styles.libraryChip}
                      key={`library-${library.id}`}
                      onClick={() => setOpenLibraryMoreMenu(true)}
                    >
                      {`+${arr.length - 3}`}
                    </Button>
                  );
                  acc.push(
                    <BaseMenu
                      key='library-more-menu'
                      disableAutoFocus
                      anchorEl={libraryMoreChipRef.current}
                      open={!!libraryMoreChipRef.current && openLibraryMoreMenu}
                      onClose={() => setOpenLibraryMoreMenu(false)}
                      anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                      }}
                      sx={{
                        '& .MuiPaper-root': {
                          width: '150px',
                          minWidth: '150px',
                          maxHeight: '180px',
                        },
                        '& .MuiList-root': {
                          overflowX: 'hidden',
                        },
                      }}
                    >
                      {arr?.slice(3)?.map((_moreLibrary) => (
                        <MenuItem
                          key={`more-library-${_moreLibrary.id}`}
                          sx={{
                            '&.MuiMenuItem-root': {
                              listStylePosition: 'inside',
                              minWidth: '100% !important',
                              'div': {
                                overflow: 'hidden',
                                whiteSpace: 'nowrap',
                                textOverflow: 'ellipsis',
                              },
                            },
                          }}
                          onClick={() => {
                            navigate(`/library/${_moreLibrary.id}`);
                          }}
                        >
                          <div>{_moreLibrary.title}</div>
                        </MenuItem>
                      ))}
                    </BaseMenu>
                  );
                }
                return acc;
              }, [] as React.ReactElement[])}
            </div>
          )}
          <IconButton
            ref={buttonRef}
            aria-label='more'
            aria-controls='sub-menu'
            aria-haspopup='true'
            sx={{
              p: '4px',
              borderRadius: '6px',
              backgroundColor:
                activeItemId === historyData.id ? '#EBEBEB' : 'transparent',
            }}
            onClick={(e) => {
              stopEventPropagation(e);
              handleSubmenuClick(e, historyData);
              setAnchorEl(e.currentTarget);
              setActiveItemId(historyData.id);
            }}
            disabled={
              deleteStatus === 'pending' ||
              updateStatus === 'pending' ||
              isLoading
            }
          >
            <IconEllipsis
              className={styles.icon}
              style={{
                width: '16px',
                height: '16px',
                fill: 'var(--gray-300)',
              }}
            />
          </IconButton>
        </div>
      </div>
    </div>
  );
};
