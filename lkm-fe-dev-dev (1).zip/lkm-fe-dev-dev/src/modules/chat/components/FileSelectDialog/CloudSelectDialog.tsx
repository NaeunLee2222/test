import IconDOC from '@/assets/file-icons/icon-doc.svg?react';
import IconPDF from '@/assets/file-icons/icon-pdf.svg?react';
import loadingIcon from '@/assets/lotties/loading-icon.json';
import BaseCheckBox from '@/modules/chat/components/ChatInput/BaseCheckBox';
import styles from '@/modules/chat/components/FileSelectDialog/CloudSelectDialog.module.scss';
import {
  getCloudFilesAtom,
  uploadFileToCloudAtom,
  useFileDeleteAtom,
} from '@/modules/chat/hooks/useFileHandler';
import { selectedUploadModeAtom } from '@/modules/chat/jotai/chat';
import {
  ACCEPT_FILE_TYPES,
  EUploadFileType,
  IFilesResponse,
  IUploadedFile,
} from '@/modules/chat/types/files';
import { EUploadMode } from '@/modules/chat/types/message';
import { USER_ID } from '@/modules/chat/types/user';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { formatModified } from '@/utils';
import { Add, Clear } from '@mui/icons-material';
import { Button } from '@mui/material';
import cn from 'classnames';
import { t } from 'i18next';
import { useAtom, useAtomValue } from 'jotai';
import { queryClientAtom } from 'jotai-tanstack-query';
import { ChangeEvent, useCallback, useEffect, useState } from 'react';
import { useCookies } from 'react-cookie';

const FILE_INPUT_ID = 'local-file-input-id';

const CloudSelectDialog = () => {
  const [queryClient] = useAtom(queryClientAtom);
  const { selectedFile2Upload, setSelectedFile2Upload } = useMainContext();
  const [selectedUploadMode, setSelectedUploadMode] = useAtom(
    selectedUploadModeAtom
  );
  const { mutateAsync } = useAtomValue(uploadFileToCloudAtom);
  const { data, refetch } = useAtomValue(getCloudFilesAtom);
  const { mutateAsync: deleteFile } = useAtomValue(useFileDeleteAtom);

  const [cookies] = useCookies([USER_ID]);

  const [isOpenCloudDialog, setIsOpenCloudDialog] = useState(false);
  const [selectedFiles, setSelectedFiles] =
    useState<IUploadedFile[]>(selectedFile2Upload);
  const [loadingDelete, setLoadingDelete] = useState(false);

  const handleCloseUploadDialog = () => {
    onClose();
  };

  const onClose = () => {
    setSelectedUploadMode(null);
    setIsOpenCloudDialog(false);
    setSelectedFiles(selectedFile2Upload);
  };

  const onSelectFile = () => {
    setSelectedFile2Upload(selectedFiles);
    onClose();
  };

  const handleRowCheckboxChange = (fileId: number | string) => {
    if (selectedFiles.find((item) => item.fileId === fileId)) {
      setSelectedFiles((prev) => [
        ...prev.filter((item) => item.fileId !== fileId),
      ]);
      return;
    }

    const currentItem = data?.files?.find((item) => item.file_id === fileId);
    if (currentItem) {
      setSelectedFiles((prev) => [
        ...prev,
        {
          fileSize: currentItem.file_size,
          fileId: currentItem.file_id,
          modified: currentItem.updated_at ?? '',
          name: currentItem.original_filename,
          type: currentItem.file_type.includes(EUploadFileType.PDF)
            ? EUploadFileType.PDF
            : EUploadFileType.DOC,
        },
      ]);
    }
  };

  const handleCheckALl = () => {
    setSelectedFiles(
      selectedFiles.length > 0 && selectedFiles.length === data?.files?.length
        ? []
        : (data?.files ?? []).map((currentItem) => ({
            fileSize: currentItem.file_size,
            fileId: currentItem.file_id,
            modified: currentItem.updated_at ?? '',
            name: currentItem.original_filename,
            type: currentItem.file_type.includes(EUploadFileType.PDF)
              ? EUploadFileType.PDF
              : EUploadFileType.DOC,
          }))
    );
  };

  const handleChangeFiles = (event: any) => {
    const localFiles = event.target.files;
    const fileArray: File[] = Array.from(localFiles);
    mutateAsync(
      { files: fileArray, userId: cookies.userId },
      {
        onSuccess: (currentItem) => {
          refetch();
          if (!isOpenCloudDialog) {
            const uploadedData = (currentItem.data ?? []).map(
              (item: IFilesResponse) => ({
                fileSize: item.file_size,
                id: item.file_id,
                modified: item.updated_at ?? '',
                name: item.original_filename,
                type: item.file_type.includes(EUploadFileType.PDF)
                  ? EUploadFileType.PDF
                  : EUploadFileType.DOC,
              })
            );
            setSelectedFile2Upload([...selectedFile2Upload, ...uploadedData]);
          }
        },
      }
    );
    const input = document.getElementById(FILE_INPUT_ID);
    (input as HTMLInputElement).value = '';
  };

  const onRemoveFile = (fileId: string | number) => {
    setLoadingDelete(true);
    deleteFile(
      { file_id: fileId },
      {
        onSuccess: () => {
          refetch();
        },
        onSettled: () => {
          setLoadingDelete(false);
        },
      }
    );
  };

  useEffect(() => {
    if (selectedUploadMode === EUploadMode.CLOUD) {
      setIsOpenCloudDialog(true);
      setSelectedUploadMode(null);
      return;
    }

    if (selectedUploadMode === EUploadMode.LOCAL) {
      document.getElementById(FILE_INPUT_ID)?.click();
      setSelectedUploadMode(null);
    }
  }, [selectedUploadMode, setSelectedUploadMode]);

  useEffect(() => {
    if (isOpenCloudDialog) {
      refetch();
      setSelectedFiles(selectedFile2Upload);
    } else {
      queryClient.removeQueries({
        queryKey: ['file-data-upload', 'get-cloud-file'],
      });
    }
  }, [isOpenCloudDialog, queryClient, refetch, selectedFile2Upload]);

  const checkIsSelected = useCallback(
    (file_id: string | number) =>
      Boolean(
        selectedFiles.find((item: IUploadedFile) => item.fileId === file_id) ||
          selectedFile2Upload.find(
            (item: IUploadedFile) => item.fileId === file_id
          )
      ),
    [selectedFiles, selectedFile2Upload]
  );

  return (
    <>
      <input
        type='file'
        multiple
        id={FILE_INPUT_ID}
        style={{
          display: 'none',
        }}
        onChange={handleChangeFiles}
        accept={ACCEPT_FILE_TYPES}
      />
      <BaseDialog
        open={isOpenCloudDialog}
        title={t('chatSettings.uploadFromCloudTitle')}
        handleClose={handleCloseUploadDialog}
        paddingX={24}
        contentChildren={
          <>
            <BaseButton
              buttonType='outlined'
              className={styles.addNewFileBtn}
              onClick={() => {
                document.getElementById(FILE_INPUT_ID)?.click();
              }}
            >
              <Add />
              <span>{t('uploadFile')}</span>
            </BaseButton>
            <div>
              <div className={styles.fileHeader}>
                <p>{t('allFile')}</p>
                <p>{t('modified')}</p>
              </div>
              <div className={styles.divider} />
            </div>

            <div className={styles.filesContainer}>
              {loadingDelete && (
                <div className={styles.loadingLayout}>
                  <LottiePlayer
                    options={{
                      renderer: 'svg',
                      loop: true,
                      autoplay: true,
                      animationData: loadingIcon,
                    }}
                    width={100}
                    height={100}
                  />
                </div>
              )}
              <div className={styles.fileList}>
                {data?.files?.map((file) => (
                  <div
                    className={cn(
                      styles.fileBox,
                      selectedFiles.find(
                        (item) => item.fileId === file.file_id
                      ) && styles.fileBoxSelected
                    )}
                    key={`${file.file_id}-${file.updated_at}`}
                  >
                    <div className={styles.checkboxCell}>
                      <div className={styles.checkboxContainer}>
                        <BaseCheckBox
                          className={styles.baseCheckBox}
                          onChange={() => handleRowCheckboxChange(file.file_id)}
                          onClick={(e: ChangeEvent<HTMLInputElement>) =>
                            e.stopPropagation()
                          }
                          checked={checkIsSelected(file.file_id)}
                        />
                      </div>
                    </div>
                    {file.file_type === EUploadFileType.DOC ? (
                      <IconDOC />
                    ) : (
                      <IconPDF />
                    )}
                    <p className={styles.fileName}>{file.original_filename}</p>
                    <p className={styles.fileModified}>
                      {formatModified(file.created_at?.toString() ?? '')}
                    </p>
                    <Button
                      variant='outlined'
                      className={styles.removeFileBtn}
                      onClick={() => {
                        onRemoveFile(file.file_id);
                      }}
                    >
                      <Clear className={styles.removeFileIcon} />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </>
        }
        contentClassName={styles.uploadFileContentContainer}
        actionClassName={styles.actionContainer}
        dialogTitleClassName={styles.dialogTitle}
        sx={{
          '.MuiPaper-root': {
            maxWidth: '760px',
            maxHeight: '600px',
          },
        }}
        actionsChildren={
          <div className='flexBetween'>
            <div className={styles.checkboxRow}>
              <div className={styles.checkboxCell}>
                <div className={styles.checkboxContainer}>
                  <BaseCheckBox
                    className={styles.baseCheckBox}
                    onChange={() => handleCheckALl()}
                    onClick={(e: ChangeEvent<HTMLInputElement>) =>
                      e.stopPropagation()
                    }
                    checked={
                      selectedFiles.length > 0 &&
                      selectedFiles.length === data?.files?.length
                    }
                  />
                </div>
              </div>
              <p
                className={
                  selectedFiles.length > 0 ? styles.activeCheckbox : ''
                }
              >
                {t('selectedFile', { selected: selectedFiles.length })}
              </p>
            </div>
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={cn(styles.btnStyles, styles.toDetailBtn)}
                onClick={() => {
                  onClose();
                }}
              >
                <span>{t('cancel')}</span>
              </BaseButton>
              <BaseButton
                autoFocus
                onClick={() => {
                  onSelectFile();
                }}
                color='primary'
                className={cn(styles.btnStyles, styles.saveBtn)}
                disabled={selectedFiles.length === 0}
              >
                <span>
                  {t('confirmFileSelection', {
                    selected: selectedFiles.length,
                  })}
                </span>
              </BaseButton>
            </span>
          </div>
        }
      />
    </>
  );
};

export default CloudSelectDialog;
