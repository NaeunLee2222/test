import { AgentType, OrderSort } from '@/modules/agent/type/agent';
import styles from '@/modules/chat/components/ChatAgent/ChatAgent.module.scss';
import { EChatAgentStatus, IChatAgent } from '@/modules/chat/types/agents';
import { queryClient } from '@/modules/core/hooks';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtomValue, useSetAtom } from 'jotai';
import { useEffect, useMemo } from 'react';
import { listAgentPaginationAtom } from '@/modules/chat/jotai/agents';
import {
  AGENT_KEY,
  useDisabledAgentsData,
} from '@/modules/chat/hooks/useAgents';
import { ROW_PER_PAGE } from '@/modules/chat/constanst/agent.const';

type ChatAgentProps = {
  handleAgentClicked: (agent: IChatAgent) => void;
  page: number;
};

const ChatAgent = ({ handleAgentClicked, page }: ChatAgentProps) => {
  const { data: agentsList, refetch } = useAtomValue(useDisabledAgentsData);
  const setPagination = useSetAtom(listAgentPaginationAtom);

  useEffect(() => {
    setPagination({
      skip: 0,
      limit: 10,
      category: '',
      usageScope: '',
      reviewStatus: EChatAgentStatus.DEPLOYED,
      agentType: '' as AgentType,
      order: OrderSort.LATEST,
      name: '',
      isMyAgent: false,
    });

    refetch();

    return () => {
      queryClient.removeQueries({
        queryKey: AGENT_KEY,
        exact: false,
      });
      queryClient.invalidateQueries({
        queryKey: AGENT_KEY,
        exact: false,
      });
    };
  }, [refetch, setPagination]);

  const handleClickItem = (agent: IChatAgent) => {
    handleAgentClicked(agent);
  };

  const list2Render = useMemo(
    () =>
      (agentsList?.agents ?? []).slice(
        page * ROW_PER_PAGE,
        (page + 1) * ROW_PER_PAGE
      ),
    [agentsList, page]
  );

  return list2Render.map((agent, index) => (
    <Box
      component='div'
      key={`${agent.category}-${index}`}
      className={cn(styles.agent, styles.visible)}
      onClick={() => {
        handleClickItem(agent);
      }}
    >
      <div className={styles.category}>
        <div className={styles.textWrap}>
          <div className={styles.text}>{agent.name}</div>
        </div>
      </div>
      <span className={styles.content}>{agent.description}</span>
    </Box>
  ));
};

export default ChatAgent;
