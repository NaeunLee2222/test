import {
  mousePositionAtom,
  selectionRangeAtom,
} from '@/modules/chat/jotai/chat';
import { IActionStatus, ToolbarRef } from '@/modules/chat/types/canvas';
import { Box, Skeleton } from '@mui/material';
import { useAtom, useSetAtom } from 'jotai';
import React, { forwardRef, useCallback, useRef } from 'react';
import { v4 as uuid } from 'uuid';
import styles from './DocumentContent.module.scss';
import Editor from './editor/Editor';
import { EditorAPI } from './editor/provider/EditorContext';

interface IProps {
  isEdit?: boolean;
  isLoading?: boolean;
  placeholder?: string;
  isActionDisabled?: boolean;
  onCheckStatus?: (actionStatus: IActionStatus[]) => void;
  onEditorReady: (api: EditorAPI) => void;
  onEditorHistoryChange?: (canUndo: boolean, canRedo: boolean) => void;
}

const DocumentContent = forwardRef<ToolbarRef, IProps>(
  (
    {
      isLoading = false,
      isEdit,
      placeholder,
      isActionDisabled,
      onCheckStatus,
      onEditorReady,
      onEditorHistoryChange,
    },
    ref
  ) => {
    const selectedTextRef = useRef<string | null>(null);
    const idRef = useRef<string | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const setMenuPosition = useSetAtom(mousePositionAtom);
    const [rangeAtom, setRangeAtom] = useAtom(selectionRangeAtom);
    // TODO: SHOW Suggestion
    // const [contentSelection, updateContentSelection] = useAtom(
    //   contentSelectionDataAtom
    // );
    // const open = useMemo(
    //   () => Boolean(menuPosition) && Boolean(menuPosition?.show),
    //   [menuPosition]
    // );
    // const data = useAtomValue(canvasAtoms);
    // const uuid = useAtomValue(detailCanvas);
    // const item = data[uuid];

    // const handleAISuggest = useCallback(
    //   (id: string) => {
    //     const latestContent = [...contentSelection];
    //     const newSelection: ISelectedContent = {
    //       elementId: id,
    //       elementRef: null,
    //       originalContent: selectedTextRef.current || '',
    //       top:
    //         latestContent[0]?.top ||
    //         (menuPosition?.isNearBottom
    //           ? menuPosition?.top
    //           : menuPosition?.topUp) ||
    //         0,
    //       bottom: 0,
    //     };

    //     latestContent.push(newSelection);
    //     updateContentSelection(latestContent);

    //     setMenuPosition((prev) => ({
    //       show: false,
    //       topUp: 0,
    //       top: prev?.top ?? 0,
    //       left: prev?.left ?? 0,
    //       isNearBottom: prev?.isNearBottom || false,
    //     }));
    //   },
    //   [contentSelection, setMenuPosition, updateContentSelection, menuPosition]
    // );

    // const handleCloseMenu = useCallback(() => {
    //   setMenuPosition(null);
    // }, [setMenuPosition]);

    // useEffect(() => {
    //   const handleClickOutsideToolbar = (event: any) => {
    //     const target = event.target as HTMLElement;
    //     // Avoid closing if click inside anything with `.rich-text-toolbar`
    //     if (target.closest('.rich-text-toolbar')) return;

    //     if (toolbarRef.current && !toolbarRef.current.contains(event.target)) {
    //       setMenuPosition(null);
    //     }
    //   };

    //   window.addEventListener('mousedown', handleClickOutsideToolbar);

    //   return () => {
    //     window.removeEventListener('mousedown', handleClickOutsideToolbar);
    //   };

    // }, []);

    const handleSelectElement = useCallback(
      (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
        const { target } = e;
        const toolbarEl = (target as any).closest('.rich-text-toolbar');
        if (toolbarEl) {
          return;
        }

        const selection = window.getSelection();
        if (selection && !selection.isCollapsed) {
          idRef.current = uuid();

          const rect = selection.getRangeAt(0).getBoundingClientRect();
          selectedTextRef.current = selection.toString();
          if (
            !selectedTextRef.current ||
            /^\s+$/g.test(selectedTextRef.current)
          ) {
            setMenuPosition(null);
            return;
          }
          const newRange = [...rangeAtom];
          newRange.push({ id: idRef.current, range: selection.getRangeAt(0) });
          setRangeAtom(newRange);
          let newTop = rect.bottom + window.scrollY;
          if (window.innerHeight - rect.bottom < 100) {
            newTop = rect.top - 70;
          }
          setMenuPosition({
            show: true,
            topUp: rect.y - 80,
            top: newTop,
            left: rect.left + 60,
            isNearBottom: window.innerHeight - rect.bottom < 100,
          });
        } else {
          setMenuPosition(null);
        }
      },
      [rangeAtom, setMenuPosition, setRangeAtom]
    );

    return isLoading ? (
      <div
        ref={containerRef}
        style={{
          minWidth: '800px',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px',
        }}
      >
        <Skeleton variant='rectangular' sx={{ width: '100%' }} />
        <Skeleton variant='rectangular' sx={{ width: '100%' }} />
        <Skeleton variant='rectangular' sx={{ width: '100%' }} />
        <Skeleton variant='rectangular' sx={{ width: '60%' }} />
      </div>
    ) : (
      <Box
        className={styles.editorHolder}
        // onMouseUp={(e) => {
        //   e.stopPropagation();
        //   if (window.getSelection()?.toString()?.length) {
        //     handleSelectElement(e);
        //   }
        // }}
      >
        <Editor
          onCheckStatus={onCheckStatus}
          onReady={onEditorReady}
          onEditorHistoryChange={onEditorHistoryChange}
          ref={ref}
        />
        {/* The AI Review [AI 검토하기] feature won’t be included in the June scope
         {open && (
          <div ref={toolbarRef}>
            <Box
              onMouseDown={(e: any) => {
                e.preventDefault();
              }}
            >
              <TextToolBar
                menuPosition={menuPosition}
                isActionDisabled={isActionDisabled ?? false}
                handleClose={handleCloseMenu}
                handleAISuggest={() => handleAISuggest(idRef.current || '')}
              />
            </Box>
          </div>
        )} */}
      </Box>
    );
  }
);

DocumentContent.displayName = 'DocumentContent ';

export default DocumentContent;
