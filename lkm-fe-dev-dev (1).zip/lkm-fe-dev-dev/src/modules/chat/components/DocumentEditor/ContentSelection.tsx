import IconAI from '@/assets/basic-icons/icon-ai.svg?react';
import IconClose from '@/assets/basic-icons/icon-close-01.svg?react';
import { Box, Skeleton } from '@mui/material';
import cn from 'classnames';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './ContentSelection.module.scss';

interface IProps {
  content: string;
  active?: boolean;
  closeSuggestions: (id: string) => void;
  applySuggestions: (suggestion: string) => void;
  setCurrentActive: () => void;
}

export const ContentSelection = ({
  closeSuggestions,
  applySuggestions,
  setCurrentActive,
  content,
  active,
}: IProps) => {
  const { t } = useTranslation('admin');
  const [suggestion, updateSuggestion] = useState('');
  const [suggestionLoading, updateSuggestionLoading] = useState(false);

  useEffect(() => {
    updateSuggestionLoading(true);
    setTimeout(() => {
      updateSuggestion(`${content} Suggested`);
      updateSuggestionLoading(false);
    }, 1500);
  }, []);

  return (
    <Box className={cn(styles.contentSelectionBox, active && styles.active)}>
      {suggestionLoading ? (
        <>
          <Skeleton variant='rectangular' sx={{ width: '100%' }} />
          <Skeleton variant='rectangular' sx={{ width: '100%' }} />
          <Skeleton variant='rectangular' sx={{ width: '100%' }} />
          <Skeleton variant='rectangular' sx={{ width: '60%' }} />
        </>
      ) : (
        <>
          <div className={styles.header}>
            <div>
              <IconAI />
            </div>
            <div>
              <IconClose
                onClick={closeSuggestions}
                style={{ cursor: 'pointer' }}
              />
            </div>
          </div>
          <Box className={styles.content} onClick={setCurrentActive}>
            {suggestion.split('\n').map((line, index) => (
              <div key={index}>{line || <br />}</div>
            ))}
          </Box>
          <div className={styles.action}>
            <button
              type='button'
              style={{ cursor: 'pointer' }}
              onClick={() => applySuggestions(suggestion)}
              className={styles.applyBtn}
            >
              {t('apply')}
            </button>
          </div>
        </>
      )}
    </Box>
  );
};
