import IconAlignCenter from '@/assets/basic-icons/icon-align-center.svg?react';
import IconAlignJustify from '@/assets/basic-icons/icon-align-justify.svg?react';
import IconAlignLeft from '@/assets/basic-icons/icon-align-left.svg?react';
import IconAlignRight from '@/assets/basic-icons/icon-align-right.svg?react';
import TertiaryIcon from '@/assets/basic-icons/icon-tertiary.svg?react';
import UtilitiesIcon from '@/assets/basic-icons/icon-utilities.svg?react';
import AddColumnIcon from '@/assets/canvas-icon/addColumn.svg?react';
import AddRowIcon from '@/assets/canvas-icon/addRow.svg?react';
import BoldIcon from '@/assets/canvas-icon/bold.svg?react';
import HighLightIcon from '@/assets/canvas-icon/highlight.svg?react';
import ItalicIcon from '@/assets/canvas-icon/italic.svg?react';
import QuoteIcon from '@/assets/canvas-icon/quote.svg?react';
import RemoveColumnIcon from '@/assets/canvas-icon/removeColumn.svg?react';
import RemoveRowIcon from '@/assets/canvas-icon/removeRow.svg?react';
import StrikeIcon from '@/assets/canvas-icon/strikethrough.svg?react';
import TextColorIcon from '@/assets/canvas-icon/textColor.svg?react';
import UnderLineIcon from '@/assets/canvas-icon/underline.svg?react';
import DownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import styles from '@/modules/chat/components/DocumentEditor/editor/SlateEditor.module.scss';
import { isShowDiffAtom } from '@/modules/chat/hooks/useCanvas';
import { ToolbarProps, ToolbarRef } from '@/modules/chat/types/canvas';
import { CustomTooltip } from '@/modules/core/components/common/Tooltip';
import { handleCheckStatus } from '@/modules/core/libs';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import FormatListNumberedIcon from '@mui/icons-material/FormatListNumbered';
import { Box, Popover, Stack } from '@mui/material';
import cn from 'classnames';
import { useSetAtom } from 'jotai';
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { SketchPicker } from 'react-color';
import { useTranslation } from 'react-i18next';
import { Node } from 'slate';
import { HistoryEditor } from 'slate-history';
import { ReactEditor, useSlate } from 'slate-react';
import {
  getCurrentHighlightColor,
  getCurrentMarkupColor,
  isBlockActive,
  isMarkActive,
  toggleBlock,
  toggleColor,
  toggleHighlight,
  toggleMark,
} from './plugins/editor';
import {
  insertTable,
  insertTableColumn,
  insertTableRow,
  removeTableColumn,
  removeTableRow,
} from './plugins/table';

enum MarkButtonEnum {
  BOLD = 'bold',
  ITALIC = 'italic',
  STRIKE = 'strikeThrough',
  UNDERLINE = 'underline',
}

const Toolbar = forwardRef<ToolbarRef, ToolbarProps>(
  ({ onCheckStatus }, ref) => {
    const editor = useSlate() as ReactEditor & HistoryEditor;
    const plainText = Node.string(editor);
    const handleCheckButtonStatus = () => {
      onCheckStatus?.(handleCheckStatus(editor));
    };
    const setIsShowDiff = useSetAtom(isShowDiffAtom);
    const { t } = useTranslation('tax');
    const styleColorPicker = {
      paper: {
        sx: {
          padding: 0,
          margin: 0,
          borderRadius: '8px',
          boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.2) !important',

          '& .MuiStack-root': {
            padding: '0px',
            boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.2) !important',
            borderRadius: '0px',
            border: 'none',
          },
        },
      },
    };

    useEffect(() => {
      handleCheckButtonStatus();
    }, [editor, editor.history]);
    useImperativeHandle(ref, () => ({
      handleCopy: () => {
        if (typeof window === 'undefined') {
          navigator.clipboard.writeText(plainText);
          return;
        }
        window.navigator.clipboard.writeText(plainText);
      },
      handleOpenCanvasHistory: () => {
        setIsShowDiff((prev) => !prev);
      },
    }));

    const MarkButton: React.FC<{ format: MarkButtonEnum }> = ({ format }) => {
      let button: any;
      switch (format) {
        case MarkButtonEnum.BOLD:
          button = (
            <CustomTooltip title={t('canvas.tooltip.bold')}>
              <span>
                <BoldIcon />
              </span>
            </CustomTooltip>
          );
          break;
        case MarkButtonEnum.ITALIC:
          button = (
            <CustomTooltip title={t('canvas.tooltip.italic')}>
              <span>
                <ItalicIcon />
              </span>
            </CustomTooltip>
          );
          break;
        case MarkButtonEnum.UNDERLINE:
          button = (
            <CustomTooltip title={t('canvas.tooltip.underline')}>
              <span>
                <UnderLineIcon />
              </span>
            </CustomTooltip>
          );
          break;
        case MarkButtonEnum.STRIKE:
          button = (
            <CustomTooltip title={t('canvas.tooltip.strike')}>
              <span>
                <StrikeIcon />
              </span>
            </CustomTooltip>
          );
          break;

        default:
          break;
      }

      return (
        <button
          type='button'
          className={cn(
            styles.buttonStyle,
            isMarkActive(editor, format) ? styles.activeStyle : ''
          )}
          onMouseDown={(e) => {
            e.preventDefault();
            toggleMark(editor, format);
          }}
        >
          {button}
        </button>
      );
    };

    const BlockButton: React.FC<{ format: string; label: React.ReactNode }> = ({
      format,
      label,
    }) => (
      <button
        type='button'
        className={cn(
          styles.buttonStyle,
          isBlockActive(editor, format) ? styles.activeStyle : ''
        )}
        onMouseDown={(e) => {
          e.preventDefault();
          toggleBlock(editor, format);
        }}
      >
        {label}
      </button>
    );

    const CustomBulletedListButton: React.FC<{ format: string }> = ({
      format,
    }) => (
      <button
        type='button'
        className={cn(isBlockActive(editor, format) ? styles.activeStyle : '')}
        onMouseDown={(e) => {
          e.preventDefault();
          toggleBlock(editor, format);
        }}
      >
        <CustomTooltip placement='right' title={t('canvas.tooltip.dotList')}>
          <span>
            <FormatListBulletedIcon />
          </span>
        </CustomTooltip>
      </button>
    );

    const CustomNumberListButton: React.FC<{ format: string }> = ({
      format,
    }) => (
      <button
        type='button'
        className={cn(isBlockActive(editor, format) ? styles.activeStyle : '')}
        onMouseDown={(e) => {
          e.preventDefault();
          toggleBlock(editor, format);
        }}
      >
        <CustomTooltip placement='right' title={t('canvas.tooltip.numberList')}>
          <span>
            <FormatListNumberedIcon />
          </span>
        </CustomTooltip>
      </button>
    );

    const HighlightButton = () => {
      const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

      const open = Boolean(anchorEl);
      const currentColor = getCurrentHighlightColor(editor);

      const handleClose = () => {
        setAnchorEl(null);
        requestAnimationFrame(() => {
          ReactEditor.focus(editor);
        });
      };

      const handleChangeColor = (color: any) => {
        toggleHighlight(editor, color.hex);
        handleClose();
      };

      const iconRef = useRef<any>(null);

      useEffect(() => {
        if (iconRef.current) {
          const paths = iconRef.current.querySelectorAll('path');
          paths.forEach(
            (path: { setAttribute: (arg0: string, arg1: string) => void }) => {
              path.setAttribute('fill', currentColor ?? 'var(--gray-900)');
            }
          );
        }
      }, [currentColor]);

      return (
        <>
          <button
            type='button'
            onMouseDown={(e) => {
              e.preventDefault();
              setAnchorEl(e.currentTarget);
            }}
            className={styles.buttonStyle}
          >
            <Box ref={iconRef} className={styles.blockButtonWrapper}>
              <CustomTooltip title={t('canvas.tooltip.highlight')}>
                <span>
                  <HighLightIcon />
                </span>
              </CustomTooltip>
            </Box>
          </button>

          <Popover
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            slotProps={styleColorPicker}
          >
            <div
              className={styles.colorPicker}
              onMouseDown={(e) => e.stopPropagation()}
            >
              <Stack spacing={1} p={2}>
                <SketchPicker
                  color={currentColor || '#FFFF00'}
                  onChangeComplete={handleChangeColor}
                  disableAlpha
                />
              </Stack>
            </div>
          </Popover>
        </>
      );
    };

    const ColorMarkupButton = () => {
      const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

      const handleClose = () => {
        setAnchorEl(null);
        requestAnimationFrame(() => {
          ReactEditor.focus(editor);
        });
      };

      const handleChangeColor = (color: any) => {
        toggleColor(editor, color.hex);
        handleClose();
      };

      const open = Boolean(anchorEl);
      const currentColor = getCurrentMarkupColor(editor);
      const iconRef = useRef<any>(null);

      useEffect(() => {
        if (iconRef.current) {
          const paths = iconRef.current.querySelectorAll('path');
          paths.forEach(
            (path: { setAttribute: (arg0: string, arg1: string) => void }) => {
              path.setAttribute('fill', currentColor ?? 'var(--gray-900)');
            }
          );
        }
      }, [currentColor]);

      return (
        <>
          <button
            type='button'
            onMouseDown={(e) => {
              e.preventDefault();
              setAnchorEl(e.currentTarget);
            }}
            className={styles.buttonStyle}
          >
            <Box ref={iconRef} className={styles.blockButtonWrapper}>
              <CustomTooltip title={t('canvas.tooltip.colorMarkup')}>
                <span>
                  <TextColorIcon />
                </span>
              </CustomTooltip>
            </Box>
          </button>

          <Popover
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            slotProps={styleColorPicker}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
          >
            <Stack>
              <div
                className={styles.colorPicker}
                onMouseDown={(e) => e.stopPropagation()}
              >
                <SketchPicker
                  color={currentColor || '#FFFF00'}
                  onChangeComplete={handleChangeColor}
                  disableAlpha
                />
              </div>
            </Stack>
          </Popover>
        </>
      );
    };

    const HeadingButton = () => {
      const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

      const handleClose = () => {
        setAnchorEl(null);
        requestAnimationFrame(() => {
          ReactEditor.focus(editor);
        });
      };

      const open = Boolean(anchorEl);

      return (
        <>
          <CustomTooltip placement='top' title={t('canvas.tooltip.heading')}>
            <span>
              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  setAnchorEl(e.currentTarget);
                }}
                className={cn(
                  styles.popoverButtonStyle,
                  styles.popover,
                  open && styles.selectedPopover
                )}
              >
                <TertiaryIcon className={styles.blockPopoverButton} />
                <DownIcon className={styles.downIcon} />
              </button>
            </span>
          </CustomTooltip>

          <Popover
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            PaperProps={{
              sx: {
                marginTop: '4px',
                padding: '4px',
                boxShadow: 3,
                borderRadius: 2,
                minWidth: '112px',
              },
            }}
          >
            <Box className={styles.headingBtnWrapper}>
              <BlockButton format='heading-one' label='Heading 1' />
              <BlockButton format='heading-two' label='Heading 2' />
            </Box>
          </Popover>
        </>
      );
    };

    const FormatListButton = () => {
      const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

      const handleClose = () => {
        setAnchorEl(null);
        requestAnimationFrame(() => {
          ReactEditor.focus(editor);
        });
      };

      const open = Boolean(anchorEl);

      return (
        <>
          <CustomTooltip placement='top' title={t('canvas.tooltip.formatList')}>
            <span>
              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  setAnchorEl(e.currentTarget);
                }}
                className={cn(
                  styles.popoverButtonStyle,
                  styles.popover,
                  open && styles.selectedPopover
                )}
              >
                <FormatListBulletedIcon className={styles.blockPopoverButton} />
                <DownIcon className={styles.downIcon} />
              </button>
            </span>
          </CustomTooltip>

          <Popover
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            PaperProps={{
              sx: {
                marginTop: '4px',
                padding: '2px',
                boxShadow: 3,
                borderRadius: 2,
                border: '1px',
                display: 'flex',
              },
            }}
          >
            <Box className={styles.formatListBtnWrapper}>
              <CustomNumberListButton format='numbered-list' />
              <CustomBulletedListButton format='bulleted-list' />
            </Box>
          </Popover>
        </>
      );
    };

    const UtilitiesButton = () => {
      const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

      const handleClose = () => {
        setAnchorEl(null);
        requestAnimationFrame(() => {
          ReactEditor.focus(editor);
        });
      };

      const open = Boolean(anchorEl);

      return (
        <>
          <CustomTooltip placement='top' title={t('canvas.tooltip.utilities')}>
            <span>
              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  setAnchorEl(e.currentTarget);
                }}
                className={cn(
                  styles.popoverButtonStyle,
                  styles.popover,
                  open && styles.selectedPopover
                )}
              >
                <UtilitiesIcon className={styles.blockPopoverButton} />
                <DownIcon className={styles.downIcon} />
              </button>
            </span>
          </CustomTooltip>

          <Popover
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            PaperProps={{
              sx: {
                marginTop: '4px',
                p: '4px',
                boxShadow: 3,
                borderRadius: 2,
                minWidth: '150px',
              },
            }}
          >
            <Box className={styles.utilBtnWrapper}>
              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  insertTable(editor);
                }}
              >
                <UtilitiesIcon />
                테이블 추가
              </button>

              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  insertTableRow(editor);
                }}
              >
                <AddRowIcon />행 추가
              </button>

              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  removeTableRow(editor);
                }}
              >
                <RemoveRowIcon />행 삭제
              </button>

              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  insertTableColumn(editor);
                }}
              >
                <AddColumnIcon />열 추가
              </button>

              <button
                type='button'
                onMouseDown={(e) => {
                  e.preventDefault();
                  removeTableColumn(editor);
                }}
              >
                <RemoveColumnIcon />열 삭제
              </button>
            </Box>
          </Popover>
        </>
      );
    };

    return (
      <div className={`rich-text-toolbar ${styles.editorToolBar}`}>
        <div className={styles.buttonsWrapper}>
          <MarkButton format={MarkButtonEnum.BOLD} />
          <MarkButton format={MarkButtonEnum.ITALIC} />
          <MarkButton format={MarkButtonEnum.UNDERLINE} />
          <MarkButton format={MarkButtonEnum.STRIKE} />
          <ColorMarkupButton />
          <HighlightButton />
          <BlockButton
            format='blockquote'
            label={
              <CustomTooltip title={t('canvas.tooltip.quote')}>
                <span>
                  <QuoteIcon className={styles.blockButton} />
                </span>
              </CustomTooltip>
            }
          />
        </div>
        <div className={styles.divider} />
        <div className={styles.buttonsWrapper}>
          <BlockButton
            format='align-left'
            label={
              <CustomTooltip title={t('canvas.tooltip.alignLeft')}>
                <span>
                  <IconAlignLeft className={styles.blockButton} />
                </span>
              </CustomTooltip>
            }
          />
          <BlockButton
            format='align-center'
            label={
              <CustomTooltip title={t('canvas.tooltip.alignCenter')}>
                <span>
                  <IconAlignCenter className={styles.blockButton} />
                </span>
              </CustomTooltip>
            }
          />
          <BlockButton
            format='align-right'
            label={
              <CustomTooltip title={t('canvas.tooltip.alignRight')}>
                <span>
                  <IconAlignRight className={styles.blockButton} />
                </span>
              </CustomTooltip>
            }
          />
          <BlockButton
            format='align-justify'
            label={
              <CustomTooltip title={t('canvas.tooltip.alignJustify')}>
                <span>
                  <IconAlignJustify className={styles.blockButton} />
                </span>
              </CustomTooltip>
            }
          />
        </div>
        <div className={styles.divider} />
        <div className={styles.buttonsWrapper}>
          <FormatListButton />
          <HeadingButton />
          <UtilitiesButton />
        </div>
      </div>
    );
  }
);

Toolbar.displayName = 'Toolbar';

export default Toolbar;
