import { Descendant } from 'slate';
import { jsx } from 'slate-hyperscript';
import { CustomElement } from './interface';
import { htmlToJSXAttributeMap } from './plugins/html-attributes';

const DATA_REGEX = /^(data|aria)-[\w.-]+$/;
const newlineRegex = /\n/g;
const multipleSpacesRegex = /\s{2,}/g;
const spacesBetweenTagsRegex = />\s+</g;
const zeroWidthSpaceRegex = /\u200B/g;
const doubleQuoteRegex = /"/g;
const styleStringRegex = /-([a-z])/g;
const kebabRegex = /[A-Z]/g;
const trimmedRegex = /^\s*$/;
const mdxToHtml = /\[([^[\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
const testRegex = /^[a-zA-Z_$][\w$]*$/;
const regexEscapedQuotes = /\\"/g;
const regexEscapedNewline = /\\n/g;
const regexEscapedSingleQuote = /\\'/g;
const regexBrWithAttrs = /<br\s+([^>]*?)\s*\/?>/g;
const regexClosingBr = /<\/br>/g;
const regexEmptySpan = /<span[^>]*>(?:\s|&nbsp;|\u00A0)*<\/span>/gi;
const regexEmptyP = /<p[^>]*>(?:\s|&nbsp;|\u00A0)*<\/p>/gi;
const regexEmptyDiv = /<div[^>]*>(?:\s|&nbsp;|\u00A0)*<\/div>/gi;
const regexTrimSemicolon = /\s*;\s*/g;
const regexStyleAttr = /style="(.*?)"/g;

const parseStyleString = (
  styleString: string,
  nodeName?: string
): React.CSSProperties => {
  const style: Record<string, string> = {};
  if (nodeName === 'BODY') {
    style.maxWidth = '500pt';
    style.overflowX = 'auto';
    style.margin = 'auto';
  }

  styleString.split(';').forEach((declaration) => {
    const [prop, value] = declaration.split(':');
    if (prop && value) {
      if (prop.trim().startsWith('-')) {
        style[prop.trim()] = value.trim();
      } else {
        const key = prop
          .trim()
          .replace(styleStringRegex, (_, char) => char.toUpperCase());
        style[key] = value.trim();
      }
    }
  });

  return style;
};

const extractHtmlAndStyles = (doc: Document) => {
  const styleTags = doc.querySelectorAll('style');
  const styleContent = Array.from(styleTags)
    .map((style) => style.textContent)
    .filter(Boolean)
    .join('\n');
  // Remove all <style> tags to avoid duplication when rendering
  styleTags.forEach((tag) => tag.remove());

  return styleContent;
};

const toValidJSXPropName = (name: string): string => {
  if (htmlToJSXAttributeMap[name]) {
    return htmlToJSXAttributeMap[name];
  }

  if (DATA_REGEX.test(name)) {
    return name;
  }

  if (testRegex.test(name)) {
    return name;
  }

  return `attr-${name}`;
};

const getElementAttributes = (el: Element) => {
  const attrs: Record<string, any> = {};
  const elAttrs = el.attributes || [];
  for (let i = 0; i < elAttrs.length; i++) {
    const attr = elAttrs[i];
    const safeName = toValidJSXPropName(attr.name);

    if (attr.name === 'style') {
      attrs.style = parseStyleString(attr.value, el.nodeName);
    } else if (attr.name === 'type') {
      attrs['data-html-type'] = attr.value;
    } else {
      attrs[safeName] = attr.value;
    }
  }
  return attrs;
};

const normalizeTables = (document: Document) => {
  const tables = document.querySelectorAll('table');

  tables.forEach((table) => {
    // --- Wrap orphan <tr> inside <tbody> as before ---
    const existingTbody = table.querySelector('tbody');
    const orphanedRows: HTMLElement[] = [];

    Array.from(table.children).forEach((child) => {
      if (child.nodeName === 'TR') {
        orphanedRows.push(child as HTMLElement);
      }
    });

    if (orphanedRows.length > 0) {
      const tbody = document.createElement('tbody');
      orphanedRows.forEach((row) => tbody.appendChild(row));
      table.appendChild(tbody);
    }

    // --- Wrap orphan <col> in <colgroup> ---
    const orphanCols: HTMLElement[] = [];
    Array.from(table.children).forEach((child) => {
      if (child.nodeName === 'COL') {
        orphanCols.push(child as HTMLElement);
      }
    });

    if (orphanCols.length > 0) {
      const colgroup = document.createElement('colgroup');
      orphanCols.forEach((col) => colgroup.appendChild(col));
      table.insertBefore(colgroup, table.firstChild);
    }
  });
};

const cleanHtml = (html: string): string =>
  html
    .replace(/\\"/g, '"')
    .replace(/\\n/g, '<br />') // only handle escaped newlines
    // DO NOT replace raw \n → <br /> globally
    .replace(/\\'/g, "'")

    // Normalize <br> tags with attributes
    .replace(/<br\s+([^>]*?)\s*\/?>/g, (_, attrs) => `<br ${attrs.trim()} />`)
    .replace(/<\/br>/g, '<br />')

    // Leave these optional (uncomment only if needed)
    // .replace(/<span[^>]*>(?:\s|&nbsp;|\u00A0)*<\/span>/gi, '')
    // .replace(/<p[^>]*>(?:\s|&nbsp;|\u00A0)*<\/p>/gi, '')
    // .replace(/<div[^>]*>(?:\s|&nbsp;|\u00A0)*<\/div>/gi, '')

    .replace(/\s*;\s*/g, '; ')
    .replace(/style="(.*?)"/g, (_, style) => `style="${style.trim()}"`);

const quickMinifyHtml = (html: string): string =>
  html
    .replace(newlineRegex, '')
    .replace(multipleSpacesRegex, ' ')
    .replace(spacesBetweenTagsRegex, '><')
    .replace(
      mdxToHtml,
      '<a href="$2" style="color: blue; text-decoration: underline;">$1</a>'
    )
    .trim();

const deserialize = (el: any, markAttributes = {}, parent?: any): any => {
  const htmlAttributes = getElementAttributes(el);

  if (el.nodeType === Node.TEXT_NODE) {
    const trimmed = el.textContent?.replace(zeroWidthSpaceRegex, '');
    if (!trimmed || trimmedRegex.test(trimmed)) {
      return null;
    }
    return jsx('text', markAttributes, el.textContent);
  }

  if (el.nodeType !== Node.ELEMENT_NODE) {
    return null;
  }

  const nodeAttributes: Record<string, any> = { ...markAttributes };

  // Mark-level elements (bold, italic, underline, etc.)
  switch (el.nodeName) {
    case 'STRONG':
    case 'B':
      nodeAttributes.bold = true;
      break;
    case 'EM':
    case 'I':
      nodeAttributes.italic = true;
      break;
    case 'U':
      nodeAttributes.underline = true;
      break;
    case 'CODE':
      nodeAttributes.code = true;
      break;
    default:
    //
  }

  const children = Array.from(el.childNodes)
    .map((node) => deserialize(node, nodeAttributes, el))
    .flat()
    .filter(Boolean); // remove nulls

  if (children.length === 0) {
    children.push(jsx('text', nodeAttributes, ''));
  }

  // Handle diff tags explicitly:
  if (el.nodeName === 'DEL' && el.classList.contains('diff-removed')) {
    let contentChildren = children;

    if (parent) {
      const parentText = Array.from(parent.childNodes).reduce(
        (acc, node: any) => {
          if (node !== el) {
            return acc + (node.textContent || '');
          }
          return acc;
        },
        ''
      );

      contentChildren = [jsx('text', {}, parentText)];
    }

    return jsx(
      'element',
      { type: 'diff-removed', ...htmlAttributes },
      contentChildren.length > 0 ? contentChildren : [jsx('text', {}, '')]
    );
  }
  if (el.nodeName === 'INS' && el.classList.contains('diff-added')) {
    return jsx(
      'element',
      { type: 'diff-added', ...htmlAttributes },
      children.length > 0 ? children : [jsx('text', {}, '')]
    );
  }

  switch (el.nodeName) {
    case 'BODY':
      return jsx(
        'element',
        { type: 'body-container', ...htmlAttributes, 'data-tag': 'body' },
        children
      );
    case 'DIV':
      return jsx(
        'element',
        { type: 'div-container', ...htmlAttributes },
        children
      );
    case 'BR':
      return jsx('element', { type: 'line-break', ...htmlAttributes }, [
        { text: '' },
      ]);
    case 'BLOCKQUOTE':
      return jsx('element', { type: 'quote', ...htmlAttributes }, children);
    case 'P': {
      return jsx('element', { type: 'paragraph', ...htmlAttributes }, children);
    }
    case 'SPAN':
      return jsx('element', { type: 'span', ...htmlAttributes }, children);
    case 'A':
      return jsx(
        'element',
        {
          type: 'link',
          url: el.getAttribute('href'),
          ...htmlAttributes,
          onClick: () => {
            window.open(htmlAttributes.href, '_blank');
          },
        },
        children
      );
    case 'UL':
      return jsx(
        'element',
        { type: 'bulleted-list', ...htmlAttributes },
        children
      );
    case 'OL':
      return jsx(
        'element',
        { type: 'numbered-list', ...htmlAttributes },
        children
      );
    case 'LI':
      return jsx('element', { type: 'list-item', ...htmlAttributes }, children);
    case 'H1':
      return jsx(
        'element',
        { type: 'heading-one', ...htmlAttributes },
        children
      );
    case 'H2':
      return jsx(
        'element',
        { type: 'heading-two', ...htmlAttributes },
        children
      );
    case 'H3':
      return jsx(
        'element',
        { type: 'heading-three', ...htmlAttributes },
        children
      );
    case 'PRE':
      return jsx(
        'element',
        { type: 'code-block', ...htmlAttributes },
        children
      );
    case 'TABLE': {
      const validSections = ['THEAD', 'TBODY', 'TFOOT'];
      const newChildren = [];
      let orphanRows = [];

      const getSectionType = (name: string) => {
        switch (name) {
          case 'THEAD':
            return 'table-head';
          case 'TFOOT':
            return 'table-foot';
          case 'TBODY':
            return 'table-body';
          default:
            return 'table-body'; // fallback
        }
      };

      for (const child of Array.from(el.children) as any[]) {
        const { nodeName } = child;

        if (nodeName === 'COLGROUP') {
          newChildren.push(
            jsx(
              'element',
              { type: 'table-colgroup', ...getElementAttributes(child) },
              Array.from(child.childNodes)
                .map((col) => deserialize(col, markAttributes))
                .filter(Boolean)
            )
          );
        } else if (nodeName === 'TR') {
          orphanRows.push(deserialize(child, markAttributes));
        } else if (validSections.includes(nodeName)) {
          if (orphanRows.length > 0) {
            newChildren.push(
              jsx('element', { type: 'table-body' }, orphanRows)
            );
            orphanRows = [];
          }

          newChildren.push(
            jsx(
              'element',
              {
                type: getSectionType(nodeName),
                ...getElementAttributes(child),
              },
              Array.from(child.childNodes)
                .map((node) => deserialize(node, markAttributes))
                .filter(Boolean)
            )
          );
        }
      }

      if (orphanRows.length > 0) {
        newChildren.push(jsx('element', { type: 'table-body' }, orphanRows));
      }

      return jsx('element', { type: 'table', ...htmlAttributes }, newChildren);
    }
    case 'TBODY':
      return jsx(
        'element',
        { type: 'table-body', ...htmlAttributes },
        children
      );
    case 'TR':
      return jsx('element', { type: 'table-row', ...htmlAttributes }, children);
    case 'TD':
      return jsx(
        'element',
        { type: 'table-cell', ...htmlAttributes },
        children
      );
    case 'TH':
      return jsx(
        'element',
        { type: 'table-header-cell', ...htmlAttributes },
        children
      );
    case 'COLGROUP': {
      const validChildren =
        children.length > 0 ? children : [jsx('text', {}, '')];
      return jsx(
        'element',
        { type: 'table-colgroup', ...htmlAttributes },
        validChildren
      );
    }

    case 'COL':
      return jsx('element', { type: 'table-col', ...htmlAttributes }, [
        jsx('text', {}, ''),
      ]);
    case 'IMG':
      return jsx('element', { type: 'image', ...htmlAttributes }, children);
    default:
      return children;
  }
};

const plainTextToSlate = (text: string): Descendant[] =>
  // Split by line and map to paragraphs
  text
    .split(/\r?\n/) // support both \n and \r\n
    .map((line) => ({
      type: 'paragraph',
      children: [{ text: line }],
    }));
const isHtml = (str: string): boolean => {
  if (!str) return false;
  const doc = new DOMParser().parseFromString(str, 'text/html');
  const children = doc.body.childNodes;
  for (let i = 0; i < children.length; i++) {
    if (children[i].nodeType === Node.ELEMENT_NODE) {
      return true;
    }
  }
  return false;
};

export const htmlToSlate = (rawHtml: string) => {
  if (!rawHtml || !isHtml(rawHtml)) {
    return {
      fragment: plainTextToSlate(rawHtml || ''),
      styleContent: '',
      fullHtml: rawHtml || '',
      replaceBodyHtml: (body: string) => body,
    };
  }

  const afterCleanHtml = cleanHtml(rawHtml).replace(
    mdxToHtml,
    '<a href="$2" style="color: blue; text-decoration: underline;" target="_blank">$1</a>'
  );
  const newFetchDocument = new DOMParser().parseFromString(
    afterCleanHtml,
    'text/html'
  );

  const listTab = newFetchDocument.querySelectorAll("[id^='table_']");
  if (listTab.length > 0) {
    listTab.forEach((table, index) => {
      if (index !== 0) {
        (table as HTMLElement).style.display = 'none';
      }
    });
  }

  normalizeTables(newFetchDocument);
  const styleContent = extractHtmlAndStyles(newFetchDocument);
  const parsed = Array.from(newFetchDocument.body.childNodes)
    .map((node) => deserialize(node, {}, newFetchDocument.body))
    .flat()
    .filter(Boolean);

  const fullHtml = newFetchDocument.documentElement.outerHTML;

  const replaceBodyHtml = (newBodyHtml: string): string => {
    const doc = new DOMParser().parseFromString(fullHtml, 'text/html');
    doc.body.innerHTML = newBodyHtml;
    return doc.documentElement.outerHTML;
  };

  return {
    fragment: Array.isArray(parsed) ? parsed : [parsed],
    styleContent,
    fullHtml,
    replaceBodyHtml,
  };
};

const serializeText = (node: any): string => {
  let { text } = node;

  if (node.bold) text = `<strong>${text}</strong>`;
  if (node.italic) text = `<em>${text}</em>`;
  if (node.underline) text = `<u>${text}</u>`;
  if (node.code) text = `<code>${text}</code>`;
  if (node.strikeThrough)
    text = `<span style={{ textDecoration: 'line-through' }}>${text}</span>`;

  if (node.highlight) {
    return `<span style="background-color: ${node.highlight}">${text}</span>`;
  }

  if (node.colorMarkup) {
    return `<span style="color: ${node.colorMarkup}">${text}</span>`;
  }

  return text;
};

const escapeAttr = (value: string): string =>
  value.replace(doubleQuoteRegex, '&quot;');

const serializeAttributes = (attrs: Record<string, any>): string =>
  Object.entries(attrs)
    .filter(
      ([key, value]) =>
        key !== 'type' &&
        key !== 'children' &&
        value !== undefined &&
        key !== 'data-tag'
    )
    .map(([key, value]) => {
      if (typeof value === 'object') {
        if (key === 'style') {
          const styleStr = Object.entries(value)
            .map(([prop, val]) => {
              const kebab = prop.replace(
                kebabRegex,
                (m) => `-${m.toLowerCase()}`
              );
              return `${kebab}: ${val}`;
            })
            .join('; ');
          return `style="${escapeAttr(styleStr)}"`;
        }
        return '';
      }
      return `${key}="${escapeAttr(String(value))}"`;
    })
    .join(' ');

const serializeElement = (node: CustomElement): string => {
  const children = node.children.map(serializeNode).join('');
  const attrString = serializeAttributes(node);
  const dataTag = node['data-tag'];

  switch (node.type) {
    case 'paragraph':
      return `<p ${attrString}>${children}</p>`;
    case 'span':
      return `<span ${attrString}>${children}</span>`;
    case 'quote':
      return `<blockquote ${attrString}>${children}</blockquote>`;
    case 'link':
      return `<a href="https://chatgpt.com/" ${attrString}>${children}</a>`;
    case 'heading-one':
      return `<h1 ${attrString}>${children}</h1>`;
    case 'heading-two':
      return `<h2 ${attrString}>${children}</h2>`;
    case 'heading-three':
      return `<h3 ${attrString}>${children}</h3>`;
    case 'bulleted-list':
      return `<ul ${attrString}>${children}</ul>`;
    case 'numbered-list':
      return `<ol ${attrString}>${children}</ol>`;
    case 'list-item':
      return `<li ${attrString}>${children}</li>`;
    case 'code-block':
      return `<pre ${attrString}>${children}</pre>`;
    case 'table':
      return `<table ${attrString}>${children}</table>`;
    case 'table-head':
      return `<thead ${attrString}>${children}</thead>`;
    case 'table-body':
      return `<tbody ${attrString}>${children}</tbody>`;
    case 'table-foot':
      return `<tfoot ${attrString}>${children}</tfoot>`;
    case 'table-row':
      return `<tr ${attrString}>${children}</tr>`;
    case 'table-cell':
      return `<td ${attrString}>${children}</td>`;
    case 'table-header-cell':
      return `<th ${attrString}>${children}</th>`;
    case 'image':
      return `<img ${attrString} />`;
    case 'line-break':
      if (children.length) {
        return `<span ${attrString}>${children}</span>`;
      }
      return `<br />`;
    case 'diff-added':
      return `<ins class="diff-added">${children}</ins>`;
    case 'diff-removed':
      return `<del class="diff-removed">${children}</del>`;
    case 'body-container':
      if (dataTag === 'body') {
        return `<body ${attrString}>${children}</body>`;
      }

      return `<div ${attrString}>${children}</div>`;
    case 'div-container':
      return `<div ${attrString}>${children}</div>`;
    case 'table-colgroup':
      return `<colgroup ${attrString}>${children}</colgroup>`;
    case 'table-col':
      return `<col ${attrString} />`;
    default:
      return children;
  }
};

const serializeNode = (node: Descendant): string => {
  if ('text' in node) {
    return serializeText(node);
  }
  return serializeElement(node as CustomElement);
};

export const slateToHtml = (nodes: Descendant[]): string =>
  nodes.map(serializeNode).join('');
