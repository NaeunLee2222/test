export interface CustomText {
  text: string;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  highlight?: string | boolean;
  strikeThrough?: boolean;
  code?: boolean;
  colorMarkup?: string | boolean;
}

export interface CustomElement {
  type: string;
  diffType?: 'added' | 'removed' | 'unchanged' | 'changed';
  children: Array<CustomElement | CustomText>;
  data?: {
    href?: string; // For links
    src?: string; // For images
    alt?: string; // For images
    class?: string; // For class attributes
    style?: Record<string, string>; // For inline styles
    rowspan?: number; // For table cells
    colspan?: number; // For table cells
    align?: string; // For text alignment
    [key: string]: any; // For other attributes
  };
  fromEditor?: boolean;
  'data-tag'?: string;
}
