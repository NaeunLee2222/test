export const htmlToJSXAttributeMap: Record<string, string> = {
  // Core HTML differences
  'class': 'className',
  'for': 'htmlFor',

  // Table attributes
  'rowspan': 'rowSpan',
  'colspan': 'colSpan',
  'cellspacing': 'cellSpacing',
  'cellpadding': 'cellPadding',
  'valign': 'vAlign',
  'align': 'align', // no change needed, but keep if standardizing
  'bgcolor': 'bgColor',

  // Form attributes
  'tabindex': 'tabIndex',
  'readonly': 'readOnly',
  'contenteditable': 'contentEditable',
  'autocapitalize': 'autoCapitalize',
  'autocomplete': 'autoComplete',
  'autocorrect': 'autoCorrect',
  'autofocus': 'autoFocus',
  'formnovalidate': 'formNoValidate',
  'novalidate': 'noValidate',
  'minlength': 'minLength',
  'maxlength': 'maxLength',
  'dirname': 'dirName',

  // Media attributes
  'autoplay': 'autoPlay',
  'loop': 'loop',
  'muted': 'muted',
  'playsinline': 'playsInline',
  'srcset': 'srcSet',

  // SVG (frequent in HTML but different in JSX)
  'stroke-width': 'strokeWidth',
  'stroke-linecap': 'strokeLinecap',
  'stroke-linejoin': 'strokeLinejoin',
  'fill-rule': 'fillRule',
  'clip-rule': 'clipRule',
  'viewbox': 'viewBox',

  // Others
  'crossorigin': 'crossOrigin',
  'usemap': 'useMap',
  'enctype': 'encType',
  'method': 'method',
  'action': 'action',
  'accept-charset': 'acceptCharset',
  'http-equiv': 'httpEquiv',

  // Input
  'inputmode': 'inputMode',
  'spellcheck': 'spellCheck',
};
