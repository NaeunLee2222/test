import { isCanRedoAtom, isCanUndoAtom } from '@/modules/agent/jotai/agent';
import styles from '@/modules/chat/components/DocumentEditor/editor/SlateEditor.module.scss';
import { useAtomValue } from 'jotai';
import React, { useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Editor, Range, Element as SlateElement, Transforms } from 'slate';
import { Editable, RenderElementProps, RenderLeafProps } from 'slate-react';
import StyledElement from './components/StyledElement';
import { CustomElement, CustomText } from './interface';
import { splitReactAndCustomStyles } from './plugins/editor';

// Extend Slate types
declare module 'slate' {
  interface CustomTypes {
    Element: CustomElement;
    Text: CustomText;
  }
}

interface SlateEditorProps {
  editor: Editor;
  isUserTypingRef: React.MutableRefObject<boolean>;
}

const SlateEditor: React.FC<SlateEditorProps> = ({
  editor,
  isUserTypingRef,
}) => {
  const isCanUndo = useAtomValue(isCanUndoAtom);
  const isCanRedo = useAtomValue(isCanRedoAtom);
  const isDisableEditor = useMemo(() => {
    if (!isCanUndo && !isCanRedo) return false;

    return isCanRedo;
  }, [isCanUndo, isCanRedo]);

  const { t } = useTranslation('tax');

  const pickElementAttrs = (element: CustomElement): Record<string, any> => {
    const notPick = ['children', 'style', 'type'];
    return Object.keys(element).reduce(
      (result, key) => {
        if (!notPick.includes(key)) {
          result[key] = (element as any)[key];
        }

        if (key === 'data-html-type') {
          result.type = (element as any)[key];
        }

        return result;
      },
      {} as Record<string, any>
    );
  };

  const renderElement = useCallback((props: RenderElementProps) => {
    const { element, attributes, children } = props;
    const elementStyle = (element as any).style ?? {};
    const attrStyle = (attributes as any).style ?? {};
    const { fromEditor } = element as any;

    const mergedStyle = {
      ...elementStyle,
      ...attrStyle,
    };

    const mergedAttrs = {
      ...attributes,
      ...pickElementAttrs(element),
    };

    delete (mergedAttrs as any).fromEditor;

    const applyIfFromEditor = (
      style: React.CSSProperties
    ): React.CSSProperties =>
      fromEditor ? { ...style, ...mergedStyle } : mergedStyle;

    const renderStyled = (
      as: keyof React.JSX.IntrinsicElements,
      baseStyle: React.CSSProperties = {}
    ) => {
      const merged = applyIfFromEditor(baseStyle);
      const { validStyle, customStyle } = splitReactAndCustomStyles(merged);
      return (
        <StyledElement
          as={as}
          {...mergedAttrs}
          style={validStyle}
          customStyle={customStyle}
        >
          {children}
        </StyledElement>
      );
    };

    switch (element.type) {
      case 'body-container':
      case 'div-container':
        return renderStyled('div');
      case 'line-break': {
        const { validStyle, customStyle } =
          splitReactAndCustomStyles(mergedStyle);

        return (
          <StyledElement
            as='span'
            {...mergedAttrs}
            style={{
              display: 'inline-block',
              width: '100%',
              height: '1em',
              lineHeight: '1em',
              ...validStyle,
            }}
            customStyle={customStyle}
          >
            {children}
          </StyledElement>
        );
      }
      case 'heading-one':
        return renderStyled('h1', {
          fontSize: '1.875rem',
          fontWeight: 'bold',
          marginBottom: '0.5rem',
        });

      case 'heading-two':
        return renderStyled('h2', {
          fontSize: '1.5rem',
          fontWeight: '600',
          marginBottom: '0.5rem',
        });

      case 'paragraph':
        return renderStyled('p', {
          marginBottom: '0.5rem',
        });

      case 'span': {
        let isEmpty =
          !children || (Array.isArray(children) && children.length === 0);
        if (children.length === 1) {
          isEmpty =
            children[0]?.props?.isLast && children[0]?.props?.text?.text === '';
        }
        const { validStyle, customStyle } =
          splitReactAndCustomStyles(mergedStyle);
        return (
          <StyledElement
            as='span'
            {...mergedAttrs}
            style={validStyle}
            customStyle={customStyle}
          >
            {isEmpty ? <span contentEditable={false}>&#8203;</span> : children}
          </StyledElement>
        );
      }

      case 'bulleted-list':
        return renderStyled('ul', {
          listStyleType: 'disc',
          paddingLeft: '1.5rem',
          marginBottom: '0.5rem',
        });

      case 'numbered-list':
        return renderStyled('ol', {
          listStyleType: 'decimal',
          paddingLeft: '1.5rem',
          marginBottom: '0.5rem',
        });

      case 'list-item':
        return renderStyled('li');

      case 'blockquote':
        return renderStyled('blockquote', {
          borderLeft: '4px solid #d1d5db',
          paddingLeft: '1rem',
          fontStyle: 'italic',
          marginBottom: '0.5rem',
        });

      case 'code':
        return renderStyled('pre', {
          background: '#f3f4f6',
          padding: '0.5rem',
          borderRadius: '0.25rem',
          fontFamily: 'monospace',
          fontSize: '0.875rem',
          marginBottom: '0.5rem',
        });

      case 'table':
        return renderStyled('table', {
          borderCollapse: 'collapse',
          border: '1px solid #000',
          margin: '0.5rem 0',
        });

      case 'table-head':
        return <thead {...mergedAttrs}>{children}</thead>;

      case 'table-body':
        return <tbody {...mergedAttrs}>{children}</tbody>;

      case 'table-foot':
        return <tfoot {...mergedAttrs}>{children}</tfoot>;

      case 'table-row':
        return renderStyled('tr');

      case 'table-cell': {
        const baseStyle = {
          border: '1px solid #000',
          padding: '0.2rem 0.5rem',
        };
        const merged = applyIfFromEditor(baseStyle);
        const { validStyle, customStyle } = splitReactAndCustomStyles(merged);

        return (
          <StyledElement
            as='td'
            rowSpan={element.data?.rowspan}
            colSpan={element.data?.colspan}
            {...mergedAttrs}
            style={validStyle}
            customStyle={customStyle}
          >
            {children}
          </StyledElement>
        );
      }

      case 'table-header': {
        const baseStyle = {
          border: '1px solid #000',
          padding: '0.2rem 0.5rem',
          fontWeight: 'bold',
        };
        const merged = applyIfFromEditor(baseStyle);
        const { validStyle, customStyle } = splitReactAndCustomStyles(merged);
        return (
          <StyledElement
            as='th'
            rowSpan={element.data?.rowspan}
            colSpan={element.data?.colspan}
            {...mergedAttrs}
            style={validStyle}
            customStyle={customStyle}
          >
            {children}
          </StyledElement>
        );
      }

      case 'table-colgroup':
        return <colgroup {...mergedAttrs}>{children}</colgroup>;

      case 'table-col':
        return <col {...mergedAttrs} contentEditable={false} />;

      case 'image': {
        const merged = applyIfFromEditor({ maxWidth: '100%' });
        const { validStyle, customStyle } = splitReactAndCustomStyles(merged);
        return (
          <StyledElement
            as='img'
            src={element.data?.src ?? ''}
            alt={element.data?.alt ?? ''}
            {...mergedAttrs}
            style={validStyle}
            customStyle={customStyle}
          />
        );
      }

      case 'link':
        return renderStyled('a', {
          color: '#2563eb',
          textDecoration: 'underline',
        });

      case 'div':
        return renderStyled('div');

      case 'align-left':
        return (
          <div
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'flex-start',
            }}
          >
            {children}
          </div>
        );

      case 'align-center':
        return (
          <div
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'center',
              textAlign: 'center',
            }}
          >
            {children}
          </div>
        );

      case 'align-right':
        return (
          <div
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'flex-end',
              textAlign: 'right',
            }}
          >
            {children}
          </div>
        );

      case 'align-justify':
        return (
          <div style={{ width: '100%', textAlign: 'justify' }}>{children}</div>
        );

      case 'diff-removed':
        return <del {...attributes} className='diff-removed' />;
      case 'diff-added':
        return (
          <ins {...attributes} className='diff-added'>
            {children}
          </ins>
        );
      default:
        return (
          <>
            {renderStyled('p', {
              marginBottom: '0.5rem',
            })}
          </>
        );
    }
  }, []);

  const renderLeaf = useCallback((props: RenderLeafProps) => {
    const { attributes, children, leaf } = props;
    const leafStyle = (leaf as any).style ?? {};
    const attrStyle = (attributes as any).style ?? {};
    const mergedStyle: React.CSSProperties = {
      ...leafStyle,
      ...attrStyle,
    };

    let childrenElement = children;

    if (leaf.bold) {
      childrenElement = <strong>{childrenElement}</strong>;
    }
    if (leaf.italic) {
      childrenElement = <em>{childrenElement}</em>;
    }
    if (leaf.underline) {
      childrenElement = <u>{childrenElement}</u>;
    }
    if (leaf.strikeThrough) {
      childrenElement = (
        <span style={{ textDecoration: 'line-through' }}>
          {childrenElement}
        </span>
      );
    }
    if (leaf.code) {
      childrenElement = (
        <code
          style={{
            background: '#f3f4f6',
            padding: '0.1rem 0.25rem',
            borderRadius: '0.25rem',
          }}
        >
          {childrenElement}
        </code>
      );
    }
    if (leaf.highlight) {
      childrenElement = (
        <span
          style={{
            backgroundColor:
              typeof leaf.highlight === 'string'
                ? leaf.highlight
                : leaf.highlight
                  ? 'yellow'
                  : undefined,
          }}
        >
          {childrenElement}
        </span>
      );
    }
    if (leaf.colorMarkup) {
      childrenElement = (
        <span
          style={{
            color:
              typeof leaf.colorMarkup === 'string'
                ? leaf.colorMarkup
                : leaf.colorMarkup
                  ? 'yellow'
                  : undefined,
          }}
        >
          {childrenElement}
        </span>
      );
    }

    return (
      <span {...attributes} style={mergedStyle}>
        {childrenElement}
      </span>
    );
  }, []);

  const onKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    isUserTypingRef.current = true;

    const { selection } = editor;

    if (selection && Range.isCollapsed(selection)) {
      const matchEntry = Editor.above(editor, {
        match: (n) => SlateElement.isElement(n) && n.type === 'line-break',
        at: selection,
      });

      if (matchEntry) {
        event.preventDefault();

        const [_, path] = matchEntry;
        const char = event.key.length === 1 ? event.key : '';

        const typedNode = {
          type: 'div-container',
          children: [{ text: char }],
        };

        const emptyNode = {
          type: 'div-container',
          children: [{ text: '' }],
        };

        Transforms.removeNodes(editor, { at: path });
        Transforms.insertNodes(editor, [typedNode, emptyNode], { at: path });

        Transforms.select(editor, Editor.end(editor, path));
      }
    }
  };

  return (
    <div className={`${styles.slateEditorCustomWrapper}`}>
      <div className={`${styles.slateEditorCustom}`}>
        <Editable
          readOnly={isDisableEditor}
          renderElement={renderElement}
          renderLeaf={renderLeaf}
          placeholder={t('typing')}
          style={{ outline: 'none', minHeight: '200px' }}
          onKeyDown={onKeyDown}
        />
      </div>
    </div>
  );
};

export default SlateEditor;
