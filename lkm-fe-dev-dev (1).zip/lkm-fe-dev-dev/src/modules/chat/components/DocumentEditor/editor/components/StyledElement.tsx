import React, { forwardRef, useEffect, useRef } from 'react';

type StyledElementProps = React.HTMLAttributes<HTMLElement> & {
  as?: keyof React.JSX.IntrinsicElements;
  style?: React.CSSProperties;
  customStyle?: Record<string, string>;
  children?: React.ReactNode;
} & Record<string, any>;

function assignRef<T>(ref: React.Ref<T> | undefined | null, value: T | null) {
  if (!ref) return;

  if (typeof ref === 'function') {
    ref(value);
  } else {
    try {
      (ref as React.MutableRefObject<T | null>).current = value;
    } catch {
      // ignore read-only error
    }
  }
}

const StyledElement = forwardRef<HTMLElement, StyledElementProps>(
  ({ as = 'div', style, customStyle, children, ...rest }, refFromParent) => {
    const internalRef = useRef<HTMLElement | null>(null);

    const setRefs = (el: HTMLElement | null) => {
      internalRef.current = el;
      assignRef(refFromParent, el);
    };

    useEffect(() => {
      if (internalRef.current && customStyle) {
        // Parse existing style attribute into map
        const styleAttr = internalRef.current.getAttribute('style') || '';
        const styleMap: Record<string, string> = {};

        // Parse style string into key/value pairs
        styleAttr.split(';').forEach((part) => {
          const [k, v] = part.split(':').map((s) => s.trim());
          if (k && v) {
            styleMap[k] = v;
          }
        });

        // Remove keys from previous customStyle (if you want)
        Object.keys(customStyle).forEach((key) => {
          delete styleMap[key];
        });

        // Add keys from current customStyle (overwrite or add)
        Object.entries(customStyle).forEach(([key, value]) => {
          styleMap[key] = String(value);
        });

        // Serialize back to style string
        const newStyleAttr =
          Object.entries(styleMap)
            .map(([k, v]) => `${k}: ${v}`)
            .join('; ') + (Object.entries(styleMap).length ? ';' : '');

        // Set new style attribute
        internalRef.current.setAttribute('style', newStyleAttr);
      }
    }, [customStyle]);

    const Tag = as;

    return (
      <Tag ref={setRefs} style={style} {...rest} data-tag={as}>
        {children}
      </Tag>
    );
  }
);

StyledElement.displayName = 'StyledElement';

export default StyledElement;
