import Toolbar from '@/modules/chat/components/DocumentEditor/editor/Toolbar';
import {
  currentVersionAtom,
  isShowDiffAtom,
  updateCanvasAtom,
} from '@/modules/chat/hooks/useCanvas';
import { canvasAtoms, detailCanvas } from '@/modules/chat/jotai/chatprocessing';
import { IActionStatus, ToolbarRef } from '@/modules/chat/types/canvas';
import { Box, Typography } from '@mui/material';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { debounce, isEqual } from 'lodash';

import { getCanvasById, getDiffByCanvasId } from '@/modules/chat/api/canvas';

import IconClose from '@/assets/basic-icons/icon-close.svg?react';
import { reloadCanvasById } from '@/modules/agent/jotai/agent';
import { showSnackbar } from '@/utils/snackbarUtil';
import {
  forwardRef,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useTranslation } from 'react-i18next';
import { createEditor, Descendant, Transforms } from 'slate';
import { withHistory } from 'slate-history';
import { Slate, withReact } from 'slate-react';
// Sample
import DiffViewer from './DiffViewer';
import SlateEditor from './SlateEditor';
import ErrorBoundary from './components/ErrorBoundary';
import { CustomElement } from './interface';
import { useJsonDiffHistory } from './plugins/history';
import {
  withCustomBreak,
  withCustomNormalize,
  withInLines,
} from './plugins/slate';
import { EditorAPI } from './provider/EditorContext';
import { htmlToSlate, slateToHtml } from './serializer';
import './slate.css';
import './slate.scss';

const TIME_DELAY = 5000;

interface IEditorComponentProps {
  onCheckStatus?: (actionStatus: IActionStatus[]) => void;
  onReady: (api: EditorAPI) => void;
  onEditorHistoryChange?: (canUndo: boolean, canRedo: boolean) => void;
}

const sortByField = (arr: any, field: any, ascending = false) =>
  arr.slice().sort((a: any, b: any) => {
    if (a[field] < b[field]) return ascending ? -1 : 1;
    if (a[field] > b[field]) return ascending ? 1 : -1;
    return 0;
  });

const EditorComponent = forwardRef<ToolbarRef, IEditorComponentProps>(
  ({ onCheckStatus, onReady, onEditorHistoryChange }, ref) => {
    const [mounted, setMounted] = useState(false);

    const data = useAtomValue(canvasAtoms);
    const uuid = useAtomValue(detailCanvas);
    const [listTab, setListTab] = useState<
      { title: string; isActive: boolean }[]
    >([]);

    const dataCanvas = data[uuid];
    const canvasId = data[uuid]?.canvas?.id;
    const uuidRef = useRef<string>('');

    const canvasIdRef = useRef<string>('');

    const [isReloadCanvas, setReloadCanvasById] = useAtom(reloadCanvasById);
    const setCanvases = useSetAtom(canvasAtoms);

    const [styleContent, setStyleContent] = useState<any>(null);
    const fullHtmlRef = useRef<string | null>(null);
    const replaceBodyHtmlRef =
      useRef<(body: string) => string | undefined>(undefined);
    const { t } = useTranslation('tax');
    const [deltas, setDeltas] = useState<any>();
    const isShowDiff = useAtomValue(isShowDiffAtom);
    const [currentVersion, setCurrentVersion] = useAtom(currentVersionAtom);
    const [maxVersion, setMaxVersion] = useAtom(currentVersionAtom);
    const isUserTypingRef = useRef<boolean>(false);
    const [{ mutateAsync: updateCanvas1, mutate: updateCanvas }] =
      useAtom(updateCanvasAtom);

    const slateEditor: any = useMemo(
      () =>
        withCustomBreak(
          withCustomNormalize(
            withInLines(withHistory(withReact(createEditor())))
          )
        ),
      []
    );

    const [rerenderEditorKey, setRerenderEditorKey] = useState(0);

    const editorKey = useMemo(
      () =>
        `${dataCanvas?.canvas?.title ?? ''}-${isShowDiff ? '-diff' : ''}-${dataCanvas?.canvas?.id}-${isReloadCanvas}-${rerenderEditorKey}`,
      [
        dataCanvas?.canvas?.title,
        dataCanvas?.canvas?.id,
        isShowDiff,
        isReloadCanvas,
        rerenderEditorKey,
      ]
    );

    const [value, setValue] = useState<CustomElement[]>([
      { type: 'paragraph', children: [{ text: '' }] },
    ]);
    const forceReRender = () => setRerenderEditorKey((x) => x + 1);
    const {
      commit,
      undo,
      redo,
      reset,
      resetHistory,
      restore,
      getLastCommittedValue,
      setCurrentValue,
      getHistoryForBackend,
    } = useJsonDiffHistory({
      initialValue: value,
      onChange: (val, from) => {
        setValue(val as CustomElement[]);
        if (from === 'history') {
          slateEditor.onChange();
          forceReRender();
          slateEditor.children = val;
          slateEditor.onChange();
        }
      },
      onHistoryChange: onEditorHistoryChange,
      undoStackProps: sortByField(deltas ?? [], 'version'),
    });

    useEffect(() => {
      setMounted(true);
      return () => {
        resetHistory();
      };
    }, []);

    useEffect(() => {
      if (canvasId && canvasId !== canvasIdRef.current) {
        canvasIdRef.current = canvasId;
      }
    }, [canvasId]);

    useEffect(() => {
      if (uuid && uuid !== uuidRef.current) {
        uuidRef.current = uuid;
      }
    }, [uuid]);

    const handleChangeTab = (tab: string) => {
      document.querySelectorAll("[id^='table_']").forEach((table, index) => {
        const title = table.getAttribute('sheetname');
        if (title === tab) {
          (table as HTMLElement).style.display = 'block';
        } else {
          (table as HTMLElement).style.display = 'none';
        }
      });

      const newTabActive = {
        title: tab,
        isActive: true,
      };

      setListTab((prev) => {
        const newListTab = prev.map((tabItem) =>
          tabItem.title === tab ? newTabActive : { ...tabItem, isActive: false }
        );
        return newListTab;
      });
    };

    const handleRemoveTab = (tab: string) => {
      const parser = new DOMParser();
      const doc = parser.parseFromString(
        dataCanvas?.canvas?.htmlContent,
        'text/html'
      );
      doc.querySelectorAll("[id^='table_']").forEach((table, index) => {
        const title = table.getAttribute('sheetname');
        if (title === tab) {
          (table as HTMLElement).remove();
        }
      });

      const cleanedHtml = doc.body.innerHTML;

      setCanvases((prev) => {
        const canvasList = prev[uuid];
        return {
          ...prev,
          [uuid]: {
            ...canvasList,
            canvas: {
              ...canvasList.canvas,
              htmlContent: cleanedHtml,
            },
          },
        };
      });

      const index = listTab.findIndex(
        (item) => item.title === tab && item.isActive
      );
      const newListTab = [...listTab].filter(
        (tabItem) => tabItem.title !== tab
      );

      if (index !== -1) {
        if (index === listTab.length - 1) {
          newListTab[newListTab.length - 1].isActive = true;
        } else {
          newListTab[index].isActive = true;
        }
      }
      setListTab(newListTab);
    };

    useEffect(() => {
      const activeTable = listTab.find((item) => item.isActive);
      document.querySelectorAll("[id^='table_']").forEach((table) => {
        const title = table.getAttribute('sheetname');
        if (title === activeTable?.title) {
          (table as HTMLElement).style.display = 'block';
        } else {
          (table as HTMLElement).style.display = 'none';
        }
      });
    }, [listTab]);

    const handleRedo = useCallback(() => {
      redo();
      Transforms.deselect(slateEditor);
    }, [redo, slateEditor]);

    const handleUndo = useCallback(() => {
      undo();
      Transforms.deselect(slateEditor);
      versionRef.current -= 1;
    }, [slateEditor, undo]);

    const handleRestore = useCallback(() => {
      const newContent = restore();
      commit(newContent as unknown as Descendant[]);
      Transforms.deselect(slateEditor);
      const htmlContent = slateToHtml(newContent as unknown as Descendant[]);
      handleUpdate(htmlContent, false);
    }, [restore, slateEditor]);

    const handleReverse = useCallback(() => {
      reset();
      Transforms.deselect(slateEditor);
    }, [reset, slateEditor]);

    const fetchDiffById = async () => {
      try {
        const data = await getDiffByCanvasId(canvasId);
        setDeltas(data?.deltas);
      } catch (error) {
        console.error('Failed to fetch diff by id:', error);
      }
    };

    const setEditorValue = (content: string) => {
      if (typeof window === 'undefined') {
        setValue([{ type: 'paragraph', children: [{ text: '' }] }]);
      }

      const {
        styleContent: style,
        fragment,
        fullHtml,
        replaceBodyHtml,
      } = htmlToSlate(content);
      fullHtmlRef.current = fullHtml;
      replaceBodyHtmlRef.current = replaceBodyHtml;
      setStyleContent(style);
      setValue(fragment);
      setCurrentValue(fragment);
    };

    const fetchCanvasById = async () => {
      try {
        const data = await getCanvasById(canvasId);
        if (data.content) {
          setEditorValue(data.content);
        }
        setCurrentVersion(data.current_version);
        setMaxVersion(data.current_version);
      } catch (error) {
        console.error('Failed to fetch canvas by id:', error);
      }

      setReloadCanvasById(false);
    };

    useEffect(() => {
      if (canvasId && isReloadCanvas) {
        fetchCanvasById();
        fetchDiffById();
      }
    }, [canvasId, isReloadCanvas]);

    useEffect(() => {
      onReady({ handleRedo, handleUndo, handleRestore, handleReverse });
    }, [onReady]);

    const versionRef = useRef(1);
    const maxVersionRef = useRef(1);

    // Keep versionRef in sync
    useEffect(() => {
      versionRef.current = currentVersion;
      maxVersionRef.current = maxVersion;
    }, [currentVersion, maxVersion]);

    const handleUpdate = useCallback(
      (htmlContent: string, isShowMessage = true) => {
        if (canvasIdRef.current) {
          const updatedHtml = replaceBodyHtmlRef.current
            ? replaceBodyHtmlRef.current(htmlContent)
            : htmlContent;
          maxVersionRef.current += 1;
          versionRef.current += 1;

          updateCanvas({
            content: updatedHtml ?? '',
            version: maxVersionRef.current,
            canvasId: canvasIdRef.current,
            diff: getHistoryForBackend(),
          });

          setCanvases((prev) => {
            const canvasList = prev[uuidRef.current];
            return {
              ...prev,
              [uuidRef.current]: {
                ...canvasList,
                canvas: {
                  ...canvasList.canvas,
                  htmlContent: updatedHtml,
                },
              },
            };
          });

          if (isShowMessage) {
            showSnackbar(t('success.updateCanvas'), 'success', 3);
          }
        }
      },
      [updateCanvas, getHistoryForBackend, setCanvases, t]
    );

    const debouncedUpdateCanvas = useMemo(
      () =>
        debounce((newContent: Descendant[]) => {
          commit(newContent);
          const htmlContent = slateToHtml(newContent);
          handleUpdate(htmlContent);
        }, TIME_DELAY),
      [commit]
    );

    useEffect(
      () => () => {
        debouncedUpdateCanvas.cancel();
      },
      [debouncedUpdateCanvas]
    );

    useEffect(() => {
      const timerId = setTimeout(() => {
        document.querySelectorAll("[id^='table_']").forEach((table, index) => {
          const title = table.getAttribute('sheetname');
          setListTab((prev) => [
            ...prev,
            { title: title ?? '', isActive: index === 0 },
          ]);
        });
      }, 1000);

      return () => {
        clearTimeout(timerId);
      };
    }, []);

    const handleChange = useCallback(
      (newValue: Descendant[]) => {
        debouncedUpdateCanvas(newValue);
      },
      [debouncedUpdateCanvas]
    );

    useEffect(() => {
      // Only update editor.children when value changes
      const isChanged = !isEqual(slateEditor.children, value);
      if (isChanged) {
        slateEditor.onChange();
      }
    }, [value, slateEditor]);

    if (!mounted) return null;

    return (
      <div className='rich-text-editor'>
        <ErrorBoundary>
          {styleContent && <style>{styleContent}</style>}
          <Slate
            key={editorKey}
            editor={slateEditor}
            initialValue={value}
            onValueChange={handleChange}
          >
            <Toolbar onCheckStatus={onCheckStatus} ref={ref} />
            {isShowDiff && (
              <Box>
                <DiffViewer
                  oldHtml={slateToHtml(getLastCommittedValue())}
                  newHtml={slateToHtml(value)}
                />
              </Box>
            )}
            <Box className={!isShowDiff ? '' : 'hidden'}>
              <SlateEditor
                editor={slateEditor}
                isUserTypingRef={isUserTypingRef}
              />
            </Box>
          </Slate>

          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
            }}
          >
            {listTab.map((tab) => (
              <Box
                key={tab.title}
                onClick={() => handleChangeTab(tab.title)}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  width: '100px',
                  background: tab.isActive
                    ? 'var(--primitives-darkBlue-20)'
                    : 'var(--gray-300)',
                  justifyContent: 'space-between',

                  '&:hover': {
                    cursor: 'pointer',
                  },
                }}
              >
                <Typography>{tab.title}</Typography>
                <IconClose
                  onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                    e.stopPropagation();
                    handleRemoveTab(tab.title);
                  }}
                />
              </Box>
            ))}
          </Box>
        </ErrorBoundary>
      </div>
    );
  }
);

EditorComponent.displayName = 'EditorComponent ';

export default EditorComponent;
