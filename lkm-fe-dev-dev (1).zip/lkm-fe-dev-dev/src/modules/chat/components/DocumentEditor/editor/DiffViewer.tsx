import React from 'react';
import { diffLines, Change } from 'diff';
import styled from './DiffViewer.module.scss';

type DiffViewerProps = {
  oldHtml: string;
  newHtml: string;
};

type ColorClass = 'added' | 'removed' | 'normal';

const lineStyle: Record<ColorClass, React.CSSProperties> = {
  added: { background: 'var(--primitives-yellow-diff)' },
  removed: { textDecoration: 'line-through' },
  normal: {},
};

const formatHtml = (html: string): string => html.replace(/></g, '>\n<').trim();

function getLineType(part: Change): ColorClass {
  if (part.added) return 'added';
  if (part.removed) return 'removed';
  return 'normal';
}

const renderDiffLine = (type: ColorClass, line: string, key: React.Key) => {
  if (line.trim() === '') return null;
  return (
    <div key={key} style={lineStyle[type]}>
      <div dangerouslySetInnerHTML={{ __html: line }} />
    </div>
  );
};

const DiffViewer: React.FC<DiffViewerProps> = ({ oldHtml, newHtml }) => {
  const oldFormatted = formatHtml(oldHtml);
  const newFormatted = formatHtml(newHtml);

  const diffs = diffLines(oldFormatted, newFormatted);

  return (
    <div className={styled.wrapper}>
      {diffs.flatMap((part, idx) => {
        const type = getLineType(part);
        return part.value
          .split('\n')
          .map((line, i) => renderDiffLine(type, line, `${idx}-${type}-${i}`));
      })}
    </div>
  );
};

export default DiffViewer;
