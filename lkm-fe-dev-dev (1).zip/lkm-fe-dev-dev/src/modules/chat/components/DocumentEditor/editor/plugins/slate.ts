import { isEqual } from 'lodash';
import { Editor, Element as SlateElement, Node, Text, Transforms } from 'slate';

export const withCustomBreak = (editor: Editor) => {
  const { insertBreak } = editor;

  editor.insertBreak = () => {
    const { selection } = editor;
    if (!selection) return insertBreak();

    // CASE 1: Inside table-cell
    const [tableCellEntry] = Editor.nodes(editor, {
      match: (n) => SlateElement.isElement(n) && n.type === 'table-cell',
    });

    if (tableCellEntry) {
      const [cellNode, cellPath] = tableCellEntry;

      // Step 1: If children are text or inline, wrap them in div-container
      const wrappedChildren = (cellNode as any).children.map((child: any) =>
        SlateElement.isElement(child) && child.type === 'div-container'
          ? child
          : {
              type: 'div-container',
              children: [child],
            }
      );

      if (
        !wrappedChildren.every((c: any, i: number) =>
          isEqual(c, (cellNode as any).children[i])
        )
      ) {
        Transforms.removeNodes(editor, { at: cellPath });
        Transforms.insertNodes(
          editor,
          { ...cellNode, children: wrappedChildren },
          { at: cellPath }
        );
      }

      // Step 2: Insert new div-container at end
      const updatedNode = Node.get(editor, cellPath);
      const childrenCount = SlateElement.isElement(updatedNode)
        ? updatedNode.children.length
        : 0;
      const insertPath = cellPath.concat(childrenCount);

      const newBlock = {
        type: 'div-container',
        children: [{ text: '' }],
      };

      Transforms.insertNodes(editor, newBlock, { at: insertPath });

      // Optional: move cursor
      Transforms.select(editor, insertPath.concat(0));

      return;
    }

    // CASE 2: Inside body-container
    const [bodyMatch] = Editor.nodes(editor, {
      match: (n) => SlateElement.isElement(n) && n.type === 'body-container',
    });

    if (bodyMatch) {
      const newBlock = {
        type: 'div-container',
        children: [{ text: '' }],
      };
      Transforms.insertNodes(editor, newBlock);
      return;
    }

    // DEFAULT fallback
    insertBreak();
  };

  return editor;
};

export const withInLines = (editor: Editor) => {
  const { isInline } = editor;

  editor.isInline = (element) =>
    ['span', 'link', 'line-break'].includes(element.type) || isInline(element);

  return editor;
};

export const withCustomNormalize = (editor: Editor) => {
  const { normalizeNode } = editor;

  editor.normalizeNode = (entry) => {
    const [node, path] = entry;

    if (SlateElement.isElement(node) && node.type === 'body-container') {
      return;
    }

    const allowedEmptyTypes = ['div-container', 'paragraph', 'span'];

    if (SlateElement.isElement(node) && allowedEmptyTypes.includes(node.type)) {
      if (node.children.length === 0) {
        Transforms.insertNodes(editor, { text: '' }, { at: [...path, 0] });
        return;
      }

      if (
        node.children.length === 1 &&
        Text.isText(node.children[0]) &&
        node.children[0].text === ''
      ) {
        return;
      }
    }

    normalizeNode(entry);
  };

  return editor;
};
