import { Descendant, Editor, Element as SlateElement, Transforms } from 'slate';

export const toggleMark = (
  editor: Editor,
  format: 'bold' | 'italic' | 'underline' | 'code' | 'strikeThrough'
) => {
  const isActive = isMarkActive(editor, format);
  if (isActive) {
    Editor.removeMark(editor, format);
  } else {
    Editor.addMark(editor, format, true);
  }
};

export const toggleBlock = (editor: Editor, format: string) => {
  const isActive = isBlockActive(editor, format);
  const isList = ['bulleted-list', 'numbered-list', 'list-item'].includes(
    format
  );

  Transforms.unwrapNodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) &&
      SlateElement.isElement(n) &&
      ['bulleted-list', 'numbered-list'].includes(n.type),
    split: true,
  });

  const newProperties: Partial<SlateElement> = {
    type: isActive
      ? 'paragraph'
      : format === 'list-item'
        ? 'list-item'
        : format === 'bulleted-list' || format === 'numbered-list'
          ? 'list-item'
          : format,
    fromEditor: true,
  };
  Transforms.setNodes(editor, newProperties);

  if (!isActive && isList && format !== 'list-item') {
    const block = { type: format, children: [] };
    Transforms.wrapNodes(editor, block);
  }
};

export const isMarkActive = (
  editor: Editor,
  format: 'bold' | 'italic' | 'underline' | 'code' | 'strikeThrough'
) => {
  const marks = Editor.marks(editor) as {
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
    code?: boolean;
    strikeThrough?: boolean;
  } | null;
  return marks ? marks[format] === true : false;
};

export const isBlockActive = (editor: Editor, format: string) => {
  try {
    const [match] = Editor.nodes(editor, {
      match: (n) =>
        !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === format,
    });
    return !!match;
  } catch (err) {
    console.warn('isBlockActive failed:', err);
    return false;
  }
};

export const toggleHighlight = (editor: Editor, color: string | null) => {
  if (color === null) {
    Editor.removeMark(editor, 'highlight');
  } else {
    Editor.addMark(editor, 'highlight', color);
  }
};

export const getCurrentHighlightColor = (editor: Editor): string | null => {
  const marks = Editor.marks(editor);
  const highlight = marks?.highlight;
  return typeof highlight === 'string' ? highlight : null;
};

export const toggleColor = (editor: Editor, color: string | null) => {
  if (color === null) {
    Editor.removeMark(editor, 'colorMarkup');
  } else {
    Editor.addMark(editor, 'colorMarkup', color);
  }
};

export const getCurrentMarkupColor = (editor: Editor): string | null => {
  const marks = Editor.marks(editor);
  const colorMarkup = marks?.colorMarkup;
  return typeof colorMarkup === 'string' ? colorMarkup : null;
};

export const serializeSlateValueToText = (nodes: Descendant[]): string =>
  nodes
    .map((node) => {
      if ('text' in node) return node.text;
      if ('children' in node) return serializeSlateValueToText(node.children);
      return '';
    })
    .join('\n');

export const splitReactAndCustomStyles = (
  style: any
): {
  validStyle: React.CSSProperties;
  customStyle: Record<string, string>;
} => {
  const validStyle: React.CSSProperties = {};
  const customStyle: Record<string, string> = {};

  Object.entries(style).forEach(([key, value]) => {
    if (key.startsWith('--') || key.startsWith('-')) {
      (customStyle as any)[key] = value;
    } else {
      (validStyle as any)[key] = value;
    }
  });

  return { validStyle, customStyle };
};
