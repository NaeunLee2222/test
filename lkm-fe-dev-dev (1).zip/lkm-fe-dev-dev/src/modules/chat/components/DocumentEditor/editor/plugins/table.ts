// src/plugins/table.ts
import { Editor, Path, Element as SlateElement, Transforms } from 'slate';

export const insertTable = (editor: Editor, rows = 2, cols = 2) => {
  const table = {
    type: 'table',
    children: Array.from({ length: rows }).map(() => ({
      type: 'table-row',
      fromEditor: true,
      children: Array.from({ length: cols }).map(() => ({
        type: 'table-cell',
        children: [{ text: '' }],
        fromEditor: true,
      })),
    })),
    fromEditor: true,
  };

  const paragraph = {
    type: 'paragraph',
    children: [{ text: '' }],
    fromEditor: true,
  };

  Transforms.insertNodes(editor, [table, paragraph]);
};

export const insertTableRow = (editor: Editor) => {
  const [tableEntry] = Editor.nodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'table',
  });
  if (!tableEntry) return;

  const [tableNode, tablePath] = tableEntry;
  const columns = (tableNode as any).children[0]?.children.length || 1;
  const newRow = {
    type: 'table-row',
    children: Array.from({ length: columns }).map(() => ({
      type: 'table-cell',
      children: [{ text: '' }],
    })),
    fromEditor: true,
  };
  Transforms.insertNodes(editor, newRow, {
    at: [...tablePath, (tableNode as any).children.length],
  });
};

export const insertTableColumn = (editor: Editor) => {
  const [tableEntry] = Editor.nodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'table',
  });
  if (!tableEntry) return;

  const [tableNode, tablePath] = tableEntry;
  (tableNode as any).children.forEach((rowNode: any, rowIndex: any) => {
    const rowPath = [...tablePath, rowIndex];
    const cellCount = rowNode.children.length;
    const insertPath = [...rowPath, cellCount];

    const newCell = {
      type: 'table-cell',
      children: [{ text: '' }],
      fromEditor: true,
    };

    Transforms.insertNodes(editor, newCell, { at: insertPath });
  });
};

export const removeTableRow = (editor: Editor) => {
  const [tableEntry] = Editor.nodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'table',
  });
  if (!tableEntry) return;

  const [row] = Editor.nodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) &&
      SlateElement.isElement(n) &&
      n.type === 'table-row',
  });

  if (row && (tableEntry as any)[0].children.length > 1) {
    Transforms.removeNodes(editor, { at: row[1] });
  } else {
    removeTable(editor);
  }
};

export const removeTableColumn = (editor: Editor) => {
  const cellEntry = Editor.above(editor, {
    match: (n) =>
      !Editor.isEditor(n) &&
      SlateElement.isElement(n) &&
      n.type === 'table-cell',
  });

  if (!cellEntry) return;

  const [, cellPath] = cellEntry;

  const columnIndex = cellPath[cellPath.length - 1];

  const tableEntry = Editor.above(editor, {
    match: (n) =>
      !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'table',
  });

  if (!tableEntry) return;

  const [tableNode, tablePath] = tableEntry;

  (tableNode as any).children.forEach((rowNode: any, rowIndex: any) => {
    const rowPath: Path = [...tablePath, rowIndex];

    if (
      rowNode.type === 'table-row' &&
      Array.isArray(rowNode.children) &&
      columnIndex < rowNode.children.length &&
      rowNode.children.length > 1
    ) {
      const cellPathnew = [...rowPath, columnIndex];
      Transforms.removeNodes(editor, { at: cellPathnew });
    } else {
      removeTable(editor);
    }
  });
};

export const removeTable = (editor: Editor) => {
  Transforms.removeNodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'table',
  });
};
