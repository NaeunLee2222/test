import { createContext } from 'react';

export type EditorAPI = {
  handleRedo: () => void;
  handleUndo: () => void;
  handleRestore: () => void;
  handleReverse: () => void;
};

export const EditorContext = createContext<EditorAPI | null>(null);
