import { diff_match_patch } from '@dmsnell/diff-match-patch';
import { diffLines } from 'diff';
import { create } from 'jsondiffpatch';
import { cloneDeep, isEqual } from 'lodash';
import { useCallback, useEffect, useRef } from 'react';
import { Descendant } from 'slate';
import { slateToHtml } from '../serializer';

const jdp = create({
  textDiff: {
    minLength: 4,
    diffMatchPatch: diff_match_patch,
  },
});

enum TYPE {
  ADDED = 'added',
  REMOVED = 'removed',
}

const removeDuplicatesDeep = (arr: any) => {
  const seen = new Set();
  return arr.filter((item: any) => {
    const serialized = JSON.stringify(item);
    if (seen.has(serialized)) return false;
    seen.add(serialized);
    return true;
  });
};

const convertBackendHistoryToUndoStack = (backendHistory: IDeltaBE[]): any => {
  const stack: any[] = [];

  const entryDiff = backendHistory[0];
  if (!entryDiff) return;
  const diffByEntry = entryDiff.diff;
  if (!diffByEntry) return; // skips to next iteration

  diffByEntry.forEach((diffItem, diffIndex) => {
    const delta = diffItem.raw_delta;
    if (!delta) return; // skips to next iteration

    try {
      stack.push(delta);
    } catch (err) {
      console.warn(
        `Invalid delta at backendHistory[${`entryIndex`}].diff[${diffIndex}], skipping.`,
        { delta, error: err }
      );
    }
  });

  return stack;
};

interface LineChange {
  type: 'removed' | 'added';
  content: string;
  line_number: number;
}

interface IDelta {
  line_changes: LineChange[];
}

type RawDelta = Record<string, any[]>;

interface IDiff {
  delta: IDelta;
  raw_delta: RawDelta[];
}

interface IDeltaBE {
  diff: IDiff[];
}

interface IUseJsonDiffHistoryProps {
  initialValue: Descendant[];
  onChange: (val: Descendant[], from?: 'history') => void;
  undoStackProps?: IDeltaBE[];
  onHistoryChange?: (canUndo: boolean, canRedo: boolean) => void;
}

export const useJsonDiffHistory = ({
  initialValue,
  onChange,
  undoStackProps = [],
  onHistoryChange,
}: IUseJsonDiffHistoryProps) => {
  const current = useRef<Descendant[]>(cloneDeep(initialValue));
  const baseValueRef = useRef<Descendant[]>(cloneDeep(initialValue));
  const lastUndoStackPropsRef = useRef<any[]>([]);
  const revisionStacks = useRef<any[]>([]);
  const currentWorkingIndex = useRef(-1);

  const cloneJSONObject = (obj: any) => JSON.parse(JSON.stringify(obj));

  const getCurrentValue = (): Descendant[] => cloneDeep(current.current);

  const setCurrentValue = (value: Descendant[]) => {
    current.current = cloneDeep(value);
  };

  const notifyHistoryChange = useCallback(() => {
    onHistoryChange?.(
      revisionStacks.current.length > 0 && currentWorkingIndex.current > -1,
      revisionStacks.current.length > 0 &&
        currentWorkingIndex.current < revisionStacks.current.length - 1
    );
  }, [onHistoryChange]);

  useEffect(() => {
    baseValueRef.current = cloneDeep(initialValue);
    if (
      !undoStackProps ||
      isEqual(undoStackProps, lastUndoStackPropsRef.current)
    )
      return;

    const stack = convertBackendHistoryToUndoStack(
      undoStackProps || lastUndoStackPropsRef.current
    );
    if (stack?.length > 0) {
      revisionStacks.current = stack;
      currentWorkingIndex.current = stack.length - 1;
      lastUndoStackPropsRef.current = undoStackProps;
      notifyHistoryChange();
    }
  }, [undoStackProps, initialValue]);

  const commit = useCallback(
    (newValue: Descendant[]) => {
      const delta = jdp.diff(current.current, newValue);
      if (delta) {
        const currentStack = cloneJSONObject(revisionStacks.current);
        currentStack.push(delta);
        revisionStacks.current = currentStack;
        currentWorkingIndex.current = currentStack.length - 1;
        current.current = cloneDeep(newValue);
        notifyHistoryChange();
      }
      onChange(cloneDeep(newValue));
    },
    [onChange, notifyHistoryChange]
  );

  const undo = useCallback(() => {
    if (revisionStacks.current.length === 0 || currentWorkingIndex.current < 0)
      return;

    const currentDelta = revisionStacks.current[currentWorkingIndex.current];
    const reverted = jdp.unpatch(
      cloneDeep(cloneJSONObject(current.current)),
      currentDelta
    );
    current.current = reverted as Descendant[];
    currentWorkingIndex.current -= 1;
    onChange(cloneJSONObject(reverted as Descendant[]), 'history');

    notifyHistoryChange();
  }, [onChange, notifyHistoryChange]);

  const redo = useCallback(() => {
    if (currentWorkingIndex.current === revisionStacks.current.length) return;
    const currentIndex = currentWorkingIndex.current + 1;
    const currentDelta = revisionStacks.current[currentIndex];
    const patched = jdp.patch(cloneJSONObject(current.current), currentDelta);
    currentWorkingIndex.current = currentIndex;
    current.current = patched as Descendant[];

    onChange(cloneJSONObject(patched as Descendant[]), 'history');

    notifyHistoryChange();
  }, [onChange, notifyHistoryChange]);

  const restore = () => {
    if (
      revisionStacks.current.length === 0 ||
      (revisionStacks.current.length > 0 &&
        currentWorkingIndex.current === revisionStacks.current.length - 1)
    )
      return;

    const from = cloneDeep(current.current); // This is current content (v2)
    const target = cloneDeep(from); // v2 becomes v5 (restore target)

    // Step 1: Redo until we reach v4 using existing redo()
    const currentDelta =
      revisionStacks.current[revisionStacks.current.length - 1];
    try {
      const patched = jdp.patch(cloneDeep(current.current), currentDelta);
      current.current = patched as Descendant[];
    } catch (error) {
      try {
        const patched = jdp.unpatch(cloneDeep(current.current), currentDelta);
        current.current = patched as Descendant[];
      } catch (error2) {
        console.error({ error, error2 });
      }
    }

    notifyHistoryChange();

    return target;
  };

  const reset = () => {
    if (
      revisionStacks.current.length === 0 ||
      (revisionStacks.current.length > 0 &&
        currentWorkingIndex.current === revisionStacks.current.length - 1)
    )
      return;

    let next = cloneDeep(current.current);

    next = jdp.patch(
      cloneDeep(next),
      revisionStacks.current[revisionStacks.current.length - 1]
    ) as Descendant[];
    currentWorkingIndex.current = revisionStacks.current.length - 1;
    current.current = next;
    onChange(cloneDeep(current.current));
    notifyHistoryChange();
  };

  const resetHistory = () => {
    revisionStacks.current = [];
    currentWorkingIndex.current = -1;
    baseValueRef.current = [];
    lastUndoStackPropsRef.current = [];
    notifyHistoryChange();
  };

  const getLastCommittedValue = (atIndex?: number): Descendant[] => {
    const index =
      typeof atIndex === 'number' ? atIndex : currentWorkingIndex.current;
    const currentDelta = revisionStacks.current[index];
    const reverted = jdp.unpatch(
      cloneDeep(cloneJSONObject(current.current)),
      currentDelta
    ) as Descendant[];

    return reverted;
  };

  const getHistoryForBackend = () => {
    const history = revisionStacks.current.slice(
      0,
      currentWorkingIndex.current + 1
    );
    if (history.length === 0) return [];

    const base = cloneDeep(baseValueRef.current);
    const result: {
      raw_delta: any;
      delta: {
        line_changes: {
          type: TYPE.ADDED | TYPE.REMOVED;
          content: string;
          line_number: number;
        }[];
      };
    }[] = [];

    let from = base;

    for (const element of history) {
      const raw_delta = element;
      const to = jdp.patch(cloneJSONObject(from), raw_delta) as Descendant[];
      const fromHtml = slateToHtml(from);
      const toHtml = slateToHtml(to);

      const diff = diffLines(fromHtml, toHtml);

      const lineChanges = diff
        .map((part, lineNumber) => {
          if (part.added) {
            return {
              type: TYPE.ADDED,
              content: part.value.trim(),
              line_number: lineNumber,
            };
          }
          if (part.removed) {
            return {
              type: TYPE.REMOVED,
              content: part.value.trim(),
              line_number: lineNumber,
            };
          }
          return null;
        })
        .filter(Boolean) as {
        type: TYPE.ADDED | TYPE.REMOVED;
        content: string;
        line_number: number;
      }[];

      result.push({
        raw_delta,
        delta: {
          line_changes: lineChanges,
        },
      });

      from = to;
    }

    return result;
  };

  return {
    commit,
    undo,
    redo,
    reset,
    restore,
    resetHistory,
    canUndo:
      revisionStacks.current.length > 0 && currentWorkingIndex.current > -1,
    canRedo:
      revisionStacks.current.length > 0 &&
      currentWorkingIndex.current < revisionStacks.current.length - 1,
    getLastCommittedValue,
    getHistoryForBackend,
    getCurrentValue,
    setCurrentValue,
  };
};
