import {
  agentChatOpenAtom,
  agentDataAtom,
  isCanRedoAtom,
  isCanUndoAtom,
} from '@/modules/agent/jotai/agent';
import { AgentType, UsageScope } from '@/modules/agent/type/agent';
import { getDetailChat } from '@/modules/chat/api/chat';
import styles from '@/modules/chat/components/AgentChatContent/AgentChatContent.module.scss';
import { ChatMain } from '@/modules/chat/components/ChatMain/ChatMain';
import { isShowDiffAtom } from '@/modules/chat/hooks/useCanvas';
import { chatDetail } from '@/modules/chat/jotai/chat';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { Box } from '@mui/material';
import { useAtom, useAtomValue } from 'jotai';
import { Resizable } from 're-resizable';
import React, { useEffect, useMemo, useRef } from 'react';
import { useParams } from 'react-router-dom';

interface IAgentChatContentProps {
  style?: React.CSSProperties;
  resizable?: boolean;
}

const AgentChatContent = React.memo(
  ({ style, resizable }: IAgentChatContentProps) => {
    const { chatId } = useParams();
    const isCanUndo = useAtomValue(isCanUndoAtom);
    const isCanRedo = useAtomValue(isCanRedoAtom);
    const isShowDiff = useAtomValue(isShowDiffAtom);
    const isChatContentVisible = useAtomValue(agentChatOpenAtom);
    const isDisableChatContent = useMemo(() => {
      if (!resizable) return false;
      if (isShowDiff) return true;
      if (!isCanUndo && !isCanRedo) return false;

      return isCanRedo;
    }, [resizable, isCanUndo, isCanRedo, isShowDiff]);
    const [agentData] = useAtom(agentDataAtom);
    const [currentChatDetail, setChatDetail] = useAtom(chatDetail);
    const { chatData, setChatDataByHistoryCallback, isFetching } =
      useMainContext();

    // 무한루프 방지를 위한 ref
    const loadedChatIdRef = useRef<string | null>(null);

    useEffect(() => {
      if (chatId) {
        // 이미 같은 chatId로 로딩했거나 현재 로딩 중이면 스킵
        if (loadedChatIdRef.current === chatId || isFetching) {
          return;
        }

        // 현재 chatData의 historyId와 같고 메시지가 있고 chatDetail도 있으면 스킵
        const hasMessages = Object.keys(chatData?.messages || {}).length > 0;
        const hasChatDetail = currentChatDetail?.id?.toString() === chatId;

        if (
          chatData?.historyId?.toString() === chatId &&
          hasMessages &&
          hasChatDetail
        ) {
          loadedChatIdRef.current = chatId;
          return;
        }

        // 메시지는 있지만 chatDetail이 없는 경우 chatDetail만 로딩
        if (
          chatData?.historyId?.toString() === chatId &&
          hasMessages &&
          !hasChatDetail
        ) {
          loadedChatIdRef.current = chatId;

          const handleFetchDetailOnly = async () => {
            try {
              const detailData = await getDetailChat(chatId);
              if (detailData) {
                setChatDetail(detailData);
              }
            } catch (error) {
              console.error(
                '[AgentChatContent] Failed to fetch chat detail only:',
                error
              );
              loadedChatIdRef.current = null;
            }
          };

          handleFetchDetailOnly();
          return;
        }

        // 새로운 채팅 로딩 시작 시 기존 chatDetail 즉시 초기화
        if (currentChatDetail && currentChatDetail.id?.toString() !== chatId) {
          setChatDetail(null);
        }

        const handleFetchChatDetail = async () => {
          try {
            // 로딩 시작 표시
            loadedChatIdRef.current = chatId;

            // 채팅 상세 정보와 메시지를 병렬로 로딩
            const [detailData] = await Promise.all([
              getDetailChat(chatId),
              setChatDataByHistoryCallback(chatId),
            ]);

            // 채팅 상세 정보 설정
            if (detailData) {
              setChatDetail(detailData);
            }
          } catch (error) {
            console.error(
              '[AgentChatContent] Failed to fetch chat detail:',
              error
            );
            loadedChatIdRef.current = null; // 에러 발생 시 리셋
          }
        };

        handleFetchChatDetail();
      } else {
        // chatId가 없으면 리셋
        loadedChatIdRef.current = null;
      }
    }, [chatId, isFetching]); // isFetching 의존성 추가

    // Resizable 컴포넌트 설정을 메모이제이션
    const resizableConfig = useMemo(
      () => ({
        defaultSize: {
          width: resizable ? window.innerWidth * 0.5 : '100%',
        },
        minWidth: resizable ? '50%' : undefined,
        maxWidth: resizable ? window.innerWidth * 0.8 : undefined,
        className: resizable
          ? styles.chatPanelContainerResizable
          : styles.chatPanelNotOpenCanvas,
        enable: resizable
          ? { right: true }
          : { right: false, left: false, top: false, bottom: false },
        handleStyles: resizable ? undefined : { right: { display: 'none' } },
      }),
      [resizable]
    );

    return isChatContentVisible ? (
      <Resizable {...resizableConfig}>
        <Box className={styles.chatPanelContainer}>
          <Box
            className={`${isDisableChatContent && styles.disabled}`}
            sx={{
              height: '100%',
              ...style,
              // resizable일 때 ChatMain의 최대 폭 제한 제거
              ...(resizable && {
                '& .chatMain .chatBubbleWrap': {
                  maxWidth: 'none !important',
                  minWidth: 'none !important',
                },
                '& .chatMain .chatInputWrap': {
                  maxWidth: 'none !important',
                  minWidth: 'none !important',
                },
              }),
            }}
          >
            <ChatMain
              historyId={chatId}
              bubbleType='chat'
              mode={
                agentData.usageScope === UsageScope.PUBLIC
                  ? AgentType.PRO
                  : AgentType.GENERAL
              }
            />
          </Box>
        </Box>
      </Resizable>
    ) : (
      <></>
    );
  }
);

// displayName 추가 (개발 도구에서 컴포넌트 이름 표시용)
AgentChatContent.displayName = 'AgentChatContent';

export default AgentChatContent;
