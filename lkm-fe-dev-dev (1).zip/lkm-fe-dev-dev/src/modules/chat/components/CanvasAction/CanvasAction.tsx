import styles from '@/modules/chat/components/CanvasAction/CanvasAction.module.scss';
import { isShowDiffAtom } from '@/modules/chat/hooks/useCanvas';
import {
  ACTIONTYPE,
  ICanvasAction,
  ICanvasActionProps,
} from '@/modules/chat/types/canvas';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { useAtomValue } from 'jotai';
import React from 'react';
import { useTranslation } from 'react-i18next';

const CanvasAction = ({ actions }: ICanvasActionProps) => {
  const { t } = useTranslation('tax');
  const isShowDiff = useAtomValue(isShowDiffAtom);

  if (actions.length === 0) return null;

  return (
    <>
      {actions.map((action: ICanvasAction) => (
        <BaseTooltip
          key={action.name}
          title={t(`canvas.${action.name}`)}
          placement='bottom-end'
        >
          <div
            className={`${styles.icon} ${isShowDiff && action.key === ACTIONTYPE.HISTORY && styles.gray}`}
          >
            {React.cloneElement(action.icon, {
              onClick: (e: any) => {
                if (action.disabled) return;
                action.onClick(e);
              },
              className: `${action.disabled ? styles.disable : styles.enable} icon`,
            })}
          </div>
        </BaseTooltip>
      ))}
    </>
  );
};

export default CanvasAction;
