import SlideCard from '@/modules/chat/components/SlideCard/SlideCard';
import { Box } from '@mui/material';
import styles from './PresentationSlidesViewer.module.scss';

interface PresentationSlidesViewerProps {
  htmlData: string[];
}

const PresentationSlidesViewer = ({
  htmlData,
}: Readonly<PresentationSlidesViewerProps>) => (
  <Box className={styles.viewerWrapper}>
    {htmlData.map((html, idx) => (
      <SlideCard
        key={idx.toString()}
        index={idx}
        total={htmlData.length}
        html={html}
      />
    ))}
  </Box>
);

export default PresentationSlidesViewer;
