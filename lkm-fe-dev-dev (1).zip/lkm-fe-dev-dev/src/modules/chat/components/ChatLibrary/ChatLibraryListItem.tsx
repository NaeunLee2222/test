import cn from 'classnames';
import { isoToDate } from '@/utils/commonUtil';
import IconButton from '@mui/material/IconButton';
import IconEllipsis from '@/assets/basic-icons/icon-ellipsis.svg?react';
import { ILibrary } from '@/modules/chat/types/history';
import { useNavigate } from 'react-router-dom';
import { useAtom } from 'jotai';
import { MutableRefObject } from 'react';
import { Skeleton } from '@mui/material';
import styles from './ChatLibraryList.module.scss';

import { historySearchAtom } from '../ChatHistory/ChatLibraryHistoryList';

interface IProps {
  library: ILibrary;
  submenuLibraryItemRef: MutableRefObject<ILibrary | null>;
  handleSubmenuClick: (e: React.MouseEvent<Element>, library: ILibrary) => void;
}

export const ChatLibraryListItem = ({
  library,
  submenuLibraryItemRef,
  handleSubmenuClick,
}: IProps) => {
  const [historySearchData] = useAtom(historySearchAtom);
  const navigate = useNavigate();
  const handleLibraryClick = (libraryId: number) => {
    if (historySearchData.libraryId === libraryId) {
      navigate(`/library`);
    } else {
      navigate(`/library/${libraryId}`);
    }
  };

  const isLoading = library.id === -1;

  return (
    <div
      key={library.id}
      className={cn(styles.item, isLoading && styles.loading)}
      role='presentation'
      onClick={() => {
        handleLibraryClick(library.id);
      }}
    >
      {isLoading ? (
        <>
          <div className={styles.title}>
            <Skeleton
              variant='rounded'
              sx={{ width: '100%', margin: '2px 0' }}
            />
            <Skeleton
              variant='rounded'
              sx={{ width: '50%', margin: '2px 0' }}
            />
          </div>
          <div className={styles.footer}>
            <Skeleton
              variant='rounded'
              sx={{ width: '30%', margin: '2px 0' }}
            />
          </div>
        </>
      ) : (
        <>
          <div className={styles.title}>{library.title}</div>
          <div className={styles.footer}>
            <div className={styles.date}>{isoToDate(library.updatedAt)}</div>
            <IconButton
              aria-label='more'
              aria-controls='sub-menu'
              aria-haspopup='true'
              className={styles.iconBtn}
              sx={{
                p: '4px',
                borderRadius: '6px',
                backgroundColor:
                  submenuLibraryItemRef.current?.id === library.id
                    ? '#EBEBEB'
                    : 'transparent',
              }}
              onClick={(e) => {
                handleSubmenuClick(e, library);
              }}
            >
              <IconEllipsis className={styles.icon} />
            </IconButton>
          </div>
        </>
      )}
    </div>
  );
};
