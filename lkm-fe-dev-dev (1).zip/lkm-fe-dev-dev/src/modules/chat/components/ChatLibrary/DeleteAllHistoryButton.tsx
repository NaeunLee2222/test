import { useAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import { ListItemIcon, ListItemText, MenuItem } from '@mui/material';
import IconEllipsis from '@/assets/basic-icons/icon-ellipsis.svg?react';
import { BaseMenu } from '@/modules/core/components/common/BaseMenu';
import { useRef, useState } from 'react';
import IconTrashCan from '@/assets/basic-icons/icon-trashcan.svg?react';
import IconDelBox from '@/assets/basic-icons/icon-delete-box.svg?react';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { screenLoaderDataAtom } from '@/modules/core/jotai/loader';
import { deleteAllHistoryAtom } from '../../hooks/useHistoryData';
import styles from './ChatLibrary.module.scss';

export const DeleteAllHistoryButton = ({
  noData,
  disabled,
}: {
  noData: boolean;
  disabled: boolean;
}) => {
  const { t } = useTranslation('tax');

  const moreButtonRef = useRef<HTMLDivElement | null>(null);
  const [open, setOpen] = useState(false);
  const [, setConfirmData] = useAtom(confirmDialogDataAtom);
  const [, setScreenLoaderAtom] = useAtom(screenLoaderDataAtom);

  const [{ mutateAsync: deleteAllHistory }] = useAtom(deleteAllHistoryAtom);
  const handleDeleteAll = async (type: 'all' | 'no_library') => {
    if (noData || !type) return;
    setOpen(false);
    setConfirmData({
      open: true,
      title:
        type === 'all'
          ? t('history.confirmDelete.all.title')
          : t('history.confirmDelete.noLibrary.title'),
      contentText:
        type === 'all' ? (
          <span style={{ fontSize: '15px' }}>
            {t('history.confirmDelete.all.content')}
          </span>
        ) : (
          <span style={{ fontSize: '15px' }}>
            {t('history.confirmDelete.noLibrary.content')}
          </span>
        ),
      handleConfirm: async () => {
        setScreenLoaderAtom({
          key: 'history.deleteAll',
          loading: true,
        });
        try {
          setConfirmData({ open: false });
          await deleteAllHistory({ type });
        } finally {
          setScreenLoaderAtom({
            key: 'history.deleteAll',
            loading: false,
          });
        }
      },
      handleCancel: () => {
        setConfirmData({ open: false });
      },
    });
  };

  return (
    <>
      <div
        ref={moreButtonRef}
        role='presentation'
        className={styles.iconButton}
        style={{ marginLeft: '12px' }}
        onClick={(e) => {
          e?.stopPropagation();
          setOpen(true);
        }}
      >
        <IconEllipsis
          className={styles.icon}
          style={{
            fill: 'var(--gray-500)',
          }}
        />
      </div>
      <BaseMenu
        id='sub-menu'
        disableAutoFocus
        anchorEl={moreButtonRef.current}
        open={open}
        onClose={() => setOpen(false)}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <MenuItem onClick={() => handleDeleteAll('all')} disabled={disabled}>
          <ListItemIcon>
            <IconTrashCan fill='var(--gray-700)' />
          </ListItemIcon>
          <ListItemText primaryTypographyProps={{ fontSize: '14px' }}>
            {t('history.deleteAll')}
          </ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => handleDeleteAll('no_library')}
          disabled={disabled}
        >
          <ListItemIcon>
            <IconDelBox />
          </ListItemIcon>
          <ListItemText primaryTypographyProps={{ fontSize: '14px' }}>
            {t('history.deleteNoLibrary')}
          </ListItemText>
        </MenuItem>
      </BaseMenu>
    </>
  );
};
