import cn from 'classnames';
import { useTranslation } from 'react-i18next';
import { useAtom } from 'jotai';
import IconPlus from '@/assets/basic-icons/icon-plus-new.svg?react';
import { ILibrary } from '@/modules/chat/types/history';
import { MutableRefObject } from 'react';
import { sortArrayByString } from '@/utils';
import { useLibraryData } from '../../hooks/useLibraryData';
import { libraryDialogDataAtom } from '../../jotai/library';
import { ChatLibraryListItem } from './ChatLibraryListItem';
import styles from './ChatLibraryList.module.scss';

interface IProps {
  submenuLibraryItemRef: MutableRefObject<ILibrary | null>;
  handleSubmenuClick: (e: React.MouseEvent<Element>, library: ILibrary) => void;
}

export const ChatLibraryAllList = ({
  submenuLibraryItemRef,
  handleSubmenuClick,
}: IProps) => {
  const { t } = useTranslation('tax');
  const [{ data }] = useAtom(useLibraryData);
  const [, setLibraryDialogData] = useAtom(libraryDialogDataAtom);

  const handleCreateLibrary = () => {
    setLibraryDialogData({
      id: -1,
      title: '',
      dialogOpen: true,
      targetHistoryId: -1,
      type: 'create',
    });
  };

  return (
    <div className={cn(styles.libraryList, styles.grid)}>
      <div
        role='presentation'
        className={cn(styles.noDataAddBtn, styles.item)}
        onClick={(e) => {
          e?.stopPropagation();
          handleCreateLibrary();
        }}
      >
        <IconPlus />
        {t('library.add')}
      </div>
      {data?.libraryList
        ? sortArrayByString(data?.libraryList, 'updatedAt')?.map(
            (item: any) => (
              <ChatLibraryListItem
                key={item.id}
                library={item}
                handleSubmenuClick={handleSubmenuClick}
                submenuLibraryItemRef={submenuLibraryItemRef}
              />
            )
          )
        : ''}
    </div>
  );
};
