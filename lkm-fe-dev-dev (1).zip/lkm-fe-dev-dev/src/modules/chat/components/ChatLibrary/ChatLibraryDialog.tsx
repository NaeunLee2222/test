import IconPlus from '@/assets/basic-icons/icon-plus.svg?react';
import { ILibrary } from '@/modules/chat/types/history';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { BaseTextField } from '@/modules/core/components/common/BaseTextField';
import { useCustomConfig } from '@/modules/core/hooks';
import { cutTextByPixel } from '@/utils';
import { showSnackbar } from '@/utils/snackbarUtil';
import { Menu } from '@mui/material';
import cn from 'classnames';
import EmojiPicker from 'emoji-picker-react';
import { useAtom } from 'jotai';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  createLibraryAtom,
  updateLibraryAtom,
  useLibraryData,
} from '../../hooks/useLibraryData';
import { libraryDialogDataAtom } from '../../jotai/library';
import styles from './ChatLibraryDialog.module.scss';

export const ChatLibraryDialog = () => {
  const { data: config } = useCustomConfig();
  const { t } = useTranslation('tax');
  const [{ data }] = useAtom(useLibraryData);
  const [{ mutateAsync: createLibrary }] = useAtom(createLibraryAtom);
  const [libraryDialogData, setLibraryDialogData] = useAtom(
    libraryDialogDataAtom
  );

  const isOverCreateCountMax = useMemo(
    () =>
      libraryDialogData.type === 'create' &&
      data?.libraryList?.length &&
      data.libraryList.length >= config?.LIBRARY_MAX_COUNT,
    [
      config?.LIBRARY_MAX_COUNT,
      data?.libraryList?.length,
      libraryDialogData.type,
    ]
  );

  const dialogTitle = useMemo(() => {
    switch (libraryDialogData?.type) {
      case 'create':
        if (isOverCreateCountMax) {
          return t('library.dialog.maxCountTitle');
        }
        return t('library.dialog.create');
      case 'update':
        return t('library.dialog.update');
      case 'select':
      default:
        return t('library.dialog.select');
    }
  }, [isOverCreateCountMax, libraryDialogData?.type, t]);

  const [title, setTitle] = useState('');
  const [titleEmoji, setTitleEmoji] = useState(' ');
  const titleRef = useRef<HTMLInputElement | null>(null);
  const createButtonDisabled = useMemo(() => {
    const trimmedMessage = titleRef.current?.value?.replaceAll('\n', '').trim();
    return !trimmedMessage?.length;
  }, [title]);

  const [{ mutateAsync: updateLibrary }] = useAtom(updateLibraryAtom);

  const handleClose = () => {
    setLibraryDialogData({ dialogOpen: false });
  };

  const handleCreate = () => {
    if (!titleRef.current?.value) return;
    const trimmedMessage = titleRef.current?.value?.replaceAll('\n', '').trim();
    createLibrary({
      title: `${!titleEmoji ? ' ' : titleEmoji} ${trimmedMessage}`,
      historyIdList:
        libraryDialogData.targetHistoryId !== -1
          ? [libraryDialogData.targetHistoryId]
          : undefined,
    });
    handleClose();
  };

  const handleUpdate = () => {
    if (!titleRef.current?.value) return;
    const trimmedMessage = titleRef.current?.value?.replaceAll('\n', '').trim();
    updateLibrary({
      id: libraryDialogData.id,
      title: `${!titleEmoji ? ' ' : titleEmoji} ${trimmedMessage}`,
    });
    handleClose();
  };

  useEffect(() => {
    if (!libraryDialogData.dialogOpen) return;
    const splitTitle = libraryDialogData.title?.split(' ');
    setTitle(splitTitle.length > 1 ? splitTitle[splitTitle.length - 1] : '');
    setTitleEmoji(splitTitle[0] || '');
  }, [libraryDialogData]);

  const historyIncluded = useMemo(() => {
    const historyId = libraryDialogData.targetHistoryId;
    return historyId && historyId !== -1
      ? data?.libraryList?.filter((library) =>
          library?.historyIdList?.includes(historyId)
        )
      : [];
  }, [data?.libraryList, libraryDialogData.targetHistoryId]);

  useEffect(() => {
    if (libraryDialogData.type !== 'auto') return;
    if (!data?.libraryList?.length) {
      setLibraryDialogData({
        type: 'create',
      });
    } else {
      setLibraryDialogData({
        type: 'select',
      });
    }
  }, [historyIncluded, libraryDialogData.type]);

  let extendCss = {};
  if (libraryDialogData.type === 'select') {
    extendCss = {
      '.MuiDialogContent-root': {
        marginBottom: '26px',
        minHeight: '114px',
        overflow: 'auto',
      },
    };
  } else if (libraryDialogData.type === 'create') {
    extendCss = {
      '.MuiDialogContent-root': {
        padding: '20px 24px',
        overflow: 'auto',
      },
      '.MuiDialogActions-root': {
        padding: '8px 24px 16px 24px',
      },
    };
  }

  return (
    <BaseDialog
      hideCloseButton
      open={libraryDialogData.dialogOpen}
      title={dialogTitle}
      handleClose={handleClose}
      paddingX={24}
      sx={{
        '& .MuiPaper-root': {
          width: '480px !important',
        },
        ...extendCss,
      }}
      contentChildren={
        <div className={styles.content}>
          {libraryDialogData.type === 'select' &&
            libraryDialogData.targetHistoryId !== -1 && (
              <ChatLibrarySelectContent
                libraryList={data?.libraryList}
                historyId={libraryDialogData.targetHistoryId}
              />
            )}
          {isOverCreateCountMax ? (
            <div className={styles.maxCount}>
              {t('library.dialog.maxCount', {
                count: config?.LIBRARY_MAX_COUNT,
              })}
            </div>
          ) : (
            (libraryDialogData.type === 'create' ||
              libraryDialogData.type === 'update') &&
            libraryDialogData.dialogOpen && (
              <ChatLibraryCreateContent
                title={title}
                setTitle={(_title) => {
                  setTitle(_title);
                }}
                titleRef={titleRef}
                titleEmoji={titleEmoji}
                setTitleEmoji={setTitleEmoji}
              />
            )
          )}
        </div>
      }
      actionsChildren={
        <div className={styles.actions}>
          {libraryDialogData.type !== 'select' ? (
            <BaseButton buttonType='grayFilled' onClick={handleClose}>
              {t('cancel')}
            </BaseButton>
          ) : undefined}
          {isOverCreateCountMax ? (
            <BaseButton onClick={handleClose}>{t('check')}</BaseButton>
          ) : libraryDialogData.type === 'create' ? (
            <BaseButton onClick={handleCreate} disabled={createButtonDisabled}>
              {t('create')}
            </BaseButton>
          ) : libraryDialogData.type === 'update' ? (
            <BaseButton onClick={handleUpdate} disabled={createButtonDisabled}>
              {t('check')}
            </BaseButton>
          ) : undefined}
        </div>
      }
    />
  );
};

const ChatLibrarySelectContent = ({
  libraryList,
  historyId,
}: {
  libraryList?: ILibrary[];
  historyId: number;
}) => {
  const [, setLibraryDialogData] = useAtom(libraryDialogDataAtom);

  const { t } = useTranslation('tax');
  const handleCreate = () => {
    setLibraryDialogData({
      type: 'create',
      title: '',
    });
  };

  const [{ mutateAsync: updateLibrary }] = useAtom(updateLibraryAtom);

  const handleSelect = (library: ILibrary) => {
    updateLibrary(
      {
        id: library.id,
        addHistoryIdList: [historyId],
      },
      {
        onSuccess: () => {
          showSnackbar(t('library.dialog.added'), 'success', 3);
          setLibraryDialogData({ dialogOpen: false });
        },
      }
    );
  };

  const handleRemove = (library: ILibrary) => {
    updateLibrary({
      id: library.id,
      delHistoryIdList: [historyId],
    });
  };

  const includedList = libraryList?.filter((library) =>
    library?.historyIdList?.includes(historyId)
  );

  const notIncludedList = libraryList?.filter(
    (library) => !library?.historyIdList?.includes(historyId)
  );

  return (
    <>
      <div
        role='presentation'
        className={cn(styles.listButton, styles.blue)}
        onClick={handleCreate}
      >
        <IconPlus />
        {t('library.dialog.createNew')}
      </div>
      {!!includedList?.length && (
        <div>
          <div className={styles.subTitle}>{t('library.dialog.savedList')}</div>
          <div className={styles.list}>
            {includedList?.map((library) => (
              <div
                role='presentation'
                className={styles.listButton}
                key={library.id}
              >
                <span className={styles.savedChip}>
                  {t('library.dialog.saved')}
                </span>
                {cutTextByPixel(library.title, 320)}
                <button
                  type='button'
                  className={styles.unsaved}
                  onClick={() => handleRemove(library)}
                >
                  {t('library.delete')}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
      {!!notIncludedList?.length && (
        <div>
          <div className={styles.subTitle}>{t('library.dialog.wholeList')}</div>
          <div className={styles.list}>
            {notIncludedList?.map((library) => (
              <div
                role='presentation'
                className={styles.listButton}
                key={library.id}
                onClick={() => handleSelect(library)}
              >
                {cutTextByPixel(library.title, 380)}
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  );
};

const ChatLibraryCreateContent = ({
  title,
  setTitle,
  titleRef,
  titleEmoji,
  setTitleEmoji,
}: {
  title: string;
  setTitle: (title: string) => void;
  titleRef: React.RefObject<HTMLInputElement | null>;
  titleEmoji: string;
  setTitleEmoji: (emoji: string) => void;
}) => {
  const { t } = useTranslation('tax');
  const [titleTextFieldFocus, setTitleTextFieldFocus] = useState(false);
  const emojiButtonRef = useRef<HTMLDivElement>(null);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const emojiMenuOpen = Boolean(anchorEl);

  const handleCloseEmojiMenu = () => {
    setAnchorEl(null);
  };

  const handleChangeTitle = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  const handleChangeEmoji = (emoji: string) => {
    setTitleEmoji(emoji);
    handleCloseEmojiMenu();
  };

  return (
    <div className={styles.inputBox}>
      <BaseTextField
        placeholder={t('library.dialog.createTitlePlaceholder')}
        name='title'
        inputRef={titleRef}
        value={title}
        autoFocus
        onChange={handleChangeTitle}
        onFocus={() => setTitleTextFieldFocus(true)}
        onBlur={() => setTitleTextFieldFocus(false)}
        inputProps={{
          maxLength: 50,
        }}
        sx={{
          flex: '1 1 auto',
          '> *.MuiInputBase-root': {
            padding: '10px 12px',
            borderRadius: '6px',
            border: titleTextFieldFocus
              ? '1px solid var(--primary-color-800)'
              : '1px solid var(--gray-300)',
          },
          '& .MuiInputBase-input': {
            padding: 0,
            fontSize: '16px',
            fontWeight: '400',
            height: '26px',
          },
        }}
      />
      <div
        role='presentation'
        ref={emojiButtonRef}
        className={styles.emojiButton}
        onClick={() => setAnchorEl(emojiButtonRef.current)}
      >
        {!titleEmoji ? <IconPlus /> : titleEmoji}
      </div>
      <Menu
        id='emoji-menu'
        anchorEl={anchorEl}
        open={emojiMenuOpen}
        onClose={handleCloseEmojiMenu}
        sx={{
          '& .MuiMenu-paper': {
            borderRadius: '8px',
          },
        }}
        MenuListProps={{
          sx: {
            padding: 0,
            borderRadius: '8px',
          },
          'aria-labelledby': 'basic-button',
        }}
      >
        <EmojiPicker
          onEmojiClick={(emoji) => {
            handleChangeEmoji(emoji.emoji);
          }}
        />
      </Menu>
    </div>
  );
};
