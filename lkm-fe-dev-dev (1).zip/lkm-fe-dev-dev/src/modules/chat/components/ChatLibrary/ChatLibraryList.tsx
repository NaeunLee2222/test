import cn from 'classnames';
import { useAtom } from 'jotai';
import { useTranslation } from 'react-i18next';

import IconPlus from '@/assets/basic-icons/icon-plus.svg?react';
import LeftArrowIcon from '@/assets/direction-icons/icon-chevron-left.svg?react';
import RightArrowIcon from '@/assets/direction-icons/icon-chevron-right.svg?react';
import { ILibrary } from '@/modules/chat/types/history';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { RoutesURL } from '@/routers/routes';
import { sortArrayByString } from '@/utils';
import _ from 'lodash';
import {
  MutableRefObject,
  useCallback,
  useLayoutEffect,
  useRef,
  useState,
} from 'react';
import { useNavigate } from 'react-router-dom';
import { useLibraryData } from '../../hooks/useLibraryData';
import { libraryDialogDataAtom } from '../../jotai/library';
import libraryStyles from './ChatLibrary.module.scss';
import styles from './ChatLibraryList.module.scss';
import { ChatLibraryListItem } from './ChatLibraryListItem';

interface IProps {
  submenuLibraryItemRef: MutableRefObject<ILibrary | null>;
  handleSubmenuClick: (e: React.MouseEvent<Element>, library: ILibrary) => void;
}

export const ChatLibraryList = ({
  handleSubmenuClick,
  submenuLibraryItemRef,
}: IProps) => {
  const { t } = useTranslation('tax');
  const [{ data }] = useAtom(useLibraryData);
  const [, setLibraryDialogData] = useAtom(libraryDialogDataAtom);

  const navigate = useNavigate();

  const handleCreateLibrary = () => {
    setLibraryDialogData({
      id: -1,
      title: '',
      dialogOpen: true,
      targetHistoryId: -1,
      type: 'create',
    });
  };

  const [leftDisabled, setLeftDisabled] = useState(true);
  const [rightDisabled, setRightDisabled] = useState(false);
  const libraryListRef = useRef<HTMLDivElement>(null);

  const setDisabled = useCallback(() => {
    if (!libraryListRef.current) return;
    setLeftDisabled(libraryListRef.current.scrollLeft === 0);
    setRightDisabled(
      libraryListRef.current.scrollLeft + libraryListRef.current.clientWidth >=
        libraryListRef.current.scrollWidth
    );
  }, []);

  const handleClickArrow = _.throttle((type: 'left' | 'right') => {
    if (libraryListRef.current) {
      let scrollAmount = type === 'left' ? -456 : 456;
      if (libraryListRef.current.scrollLeft + scrollAmount < 456) {
        scrollAmount = -libraryListRef.current.scrollLeft;
      }
      if (
        libraryListRef.current.scrollWidth -
          (libraryListRef.current.scrollLeft + scrollAmount) <
        456 * 2
      ) {
        scrollAmount = 456 * 2;
      }
      libraryListRef.current.scrollBy({
        left: scrollAmount,
        behavior: 'smooth',
      });
      setDisabled();
    }
  }, 300);

  useLayoutEffect(() => {
    const container = libraryListRef.current;
    if (container && libraryListRef.current) {
      const handleScroll = () => {
        setDisabled();
      };
      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }
  }, [data?.libraryList]);

  useLayoutEffect(() => {
    const checkScroll = () => {
      setDisabled();
    };
    checkScroll();
    const resizeObserver = new ResizeObserver(checkScroll);
    resizeObserver.observe(libraryListRef.current!);
    return () => resizeObserver.disconnect();
  }, [data?.libraryList]);

  const dataList = data?.libraryList
    ? sortArrayByString(data?.libraryList, 'updatedAt')
    : [];

  return (
    <div className={styles.libraryList}>
      <div className={libraryStyles.header}>
        <div className={libraryStyles.title}>
          <span>{t('library.title')}</span>
          <BaseTooltip title={t('library.viewAll')}>
            <div
              role='presentation'
              className={cn(libraryStyles.iconButton, libraryStyles.round)}
              onClick={(e) => {
                e?.stopPropagation();
                navigate(RoutesURL.LIBRARY_ALL);
              }}
            >
              <RightArrowIcon className={libraryStyles.icon} />
            </div>
          </BaseTooltip>
        </div>

        <BaseTooltip title={t('library.add')}>
          <div
            role='presentation'
            className={libraryStyles.iconButton}
            onClick={(e) => {
              e?.stopPropagation();
              handleCreateLibrary();
            }}
          >
            <IconPlus className={libraryStyles.icon} />
          </div>
        </BaseTooltip>
      </div>
      <div
        className={cn(
          libraryStyles.list,
          styles.list,
          !leftDisabled && styles.leftArrow,
          !rightDisabled && styles.rightArrow
        )}
        ref={libraryListRef}
      >
        {dataList.length ? (
          dataList
            .filter((val: any, idx: any) => idx < 10)
            .map((item: any) => (
              <ChatLibraryListItem
                key={item.id}
                library={item}
                handleSubmenuClick={handleSubmenuClick}
                submenuLibraryItemRef={submenuLibraryItemRef}
              />
            ))
        ) : (
          <div
            role='presentation'
            className={cn(styles.noDataAddBtn, styles.item)}
            onClick={(e) => {
              e?.stopPropagation();
              handleCreateLibrary();
            }}
          >
            <IconPlus className={styles.icon} />
            {t('library.add')}
          </div>
        )}
      </div>
      {!leftDisabled && (
        <div
          role='presentation'
          className={cn(styles.scrollButton, styles.left)}
          onClick={() => handleClickArrow('left')}
        >
          <span className={styles.icon}>
            <LeftArrowIcon />
          </span>
        </div>
      )}
      {!rightDisabled && (
        <div
          role='presentation'
          className={cn(styles.scrollButton, styles.right)}
          onClick={() => handleClickArrow('right')}
        >
          <span className={styles.icon}>
            <RightArrowIcon />
          </span>
        </div>
      )}
    </div>
  );
};
