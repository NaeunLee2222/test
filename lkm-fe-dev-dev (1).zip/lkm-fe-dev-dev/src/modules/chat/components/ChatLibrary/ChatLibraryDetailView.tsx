import IconEllipsis from '@/assets/basic-icons/icon-ellipsis.svg?react';
import { ILibrary } from '@/modules/chat/types/history';
import { getDateStr } from '@/utils';
import { IconButton } from '@mui/material';
import { useAtom } from 'jotai';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLibraryData } from '../../hooks/useLibraryData';
import { ChatInput } from '../ChatInput/ChatInput';
import styles from './ChatLibrary.module.scss';

interface IProps {
  libraryId: number;
  handleSubmenuClick: (e: React.MouseEvent<Element>, library: ILibrary) => void;
}

export const ChatLibraryDetailView = ({
  libraryId,
  handleSubmenuClick,
}: IProps) => {
  const { t } = useTranslation('tax');
  const [{ data }] = useAtom(useLibraryData);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const libraryData = useMemo(
    () => data?.libraryList?.find((d) => d.id === libraryId),
    [data, libraryId]
  );

  const handleClickOutside = (event: MouseEvent) => {
    if (
      anchorEl &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node)
    ) {
      setAnchorEl(null);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [anchorEl]);

  if (!libraryData) return <></>;
  return (
    <div className={styles.detailView}>
      <div className={styles.detail}>
        <div className={styles.title}>
          <span>{libraryData?.title || ''}</span>
        </div>
        <div className={styles.content}>
          {t('recentUpdate')}&nbsp;
          {getDateStr(libraryData.updatedAt)}
          <IconButton
            ref={buttonRef}
            aria-label='more'
            aria-controls='sub-menu'
            aria-haspopup='true'
            sx={{
              p: '2px',
              borderRadius: '6px',
              backgroundColor: anchorEl ? '#EBEBEB' : 'transparent',
            }}
            onClick={(e) => {
              handleSubmenuClick(e, libraryData);
              setAnchorEl(e.currentTarget);
            }}
          >
            <IconEllipsis
              className={styles.icon}
              style={{
                width: '16px',
                height: '16px',
                fill: 'var(--gray-500)',
              }}
            />
          </IconButton>
        </div>
      </div>
      <ChatInput libraryId={libraryId} />
    </div>
  );
};
