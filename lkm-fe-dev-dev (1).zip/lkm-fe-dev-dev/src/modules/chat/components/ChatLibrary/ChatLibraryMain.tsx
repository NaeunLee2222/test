import { ILibrary } from '@/modules/chat/types/history';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  ChatLibraryHistoryList,
  historySearchAtom,
} from '../ChatHistory/ChatLibraryHistoryList';
import styles from './ChatLibrary.module.scss';
import { ChatLibraryAllList } from './ChatLibraryAllList';
import { ChatLibraryDetailView } from './ChatLibraryDetailView';
import { ChatLibraryDialog } from './ChatLibraryDialog';
import { ChatLibraryItemMenu } from './ChatLibraryItemMenu';
import { ChatLibraryList } from './ChatLibraryList';

export const ChatLibraryMain = () => {
  const params = useParams();
  const [, setHistorySearchData] = useAtom(historySearchAtom);

  const [submenuAnchorEl, setSubmenuAnchorEl] = useState<Element | null>(null);

  const submenuLibraryItemRef = useRef<ILibrary | null>(null);
  const setSubmenuLibraryItemRef = (library: ILibrary | null) => {
    submenuLibraryItemRef.current = library;
  };

  const handleSubmenuClick = (
    e: React.MouseEvent<Element>,
    library: ILibrary
  ) => {
    e.stopPropagation();
    setSubmenuAnchorEl(e.currentTarget);
    setSubmenuLibraryItemRef(library);
  };

  useEffect(() => {
    setHistorySearchData({
      search: '',
      libraryId: Number(params?.libraryId ?? -1),
      includeContent: true,
    });
  }, [params]);

  return (
    <div
      className={cn(
        styles.libraryMain,
        params?.libraryId === 'all'
          ? styles.all
          : params?.libraryId && styles.column
      )}
    >
      {params?.libraryId === 'all' ? (
        <ChatLibraryAllList
          submenuLibraryItemRef={submenuLibraryItemRef}
          handleSubmenuClick={handleSubmenuClick}
        />
      ) : (
        <>
          {!params?.libraryId ? (
            <ChatLibraryList
              submenuLibraryItemRef={submenuLibraryItemRef}
              handleSubmenuClick={handleSubmenuClick}
            />
          ) : (
            <ChatLibraryDetailView
              libraryId={Number(params?.libraryId ?? -1)}
              handleSubmenuClick={handleSubmenuClick}
            />
          )}
          <ChatLibraryHistoryList hideHeader={!!params?.libraryId} />
        </>
      )}
      <ChatLibraryDialog />
      <ChatLibraryItemMenu
        anchorEl={submenuAnchorEl}
        submenuLibraryItemRef={submenuLibraryItemRef}
        setAnchorEl={setSubmenuAnchorEl}
        setSubmenuLibraryItemRef={setSubmenuLibraryItemRef}
      />
    </div>
  );
};
