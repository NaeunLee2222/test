import IconPencil from '@/assets/basic-icons/icon-pencil-16.svg?react';
import IconTrashCan from '@/assets/basic-icons/icon-trashcan.svg?react';
import { ILibrary } from '@/modules/chat/types/history';
import { BaseMenu } from '@/modules/core/components/common/BaseMenu';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { screenLoaderDataAtom } from '@/modules/core/jotai/loader';
import { RoutesURL } from '@/routers/routes';
import { ListItemIcon, ListItemText, MenuItem } from '@mui/material';
import { useAtom } from 'jotai';
import { MutableRefObject } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { deleteLibraryAtom } from '../../hooks/useLibraryData';
import { libraryDialogDataAtom } from '../../jotai/library';
import { historySearchAtom } from '../ChatHistory/ChatLibraryHistoryList';

interface IProps {
  anchorEl: Element | null;
  setAnchorEl: (el: Element | null) => void;
  submenuLibraryItemRef: MutableRefObject<ILibrary | null>;
  setSubmenuLibraryItemRef: (library: ILibrary | null) => void;
}

export const ChatLibraryItemMenu = ({
  anchorEl,
  setAnchorEl,
  submenuLibraryItemRef,
  setSubmenuLibraryItemRef,
}: IProps) => {
  const { t } = useTranslation('tax');
  const [{ mutateAsync: deleteLibrary }] = useAtom(deleteLibraryAtom);

  const [, setLibraryDialogData] = useAtom(libraryDialogDataAtom);
  const [historySearchData, setHistorySearchData] = useAtom(historySearchAtom);

  const submenuOpen = !!anchorEl;

  const handleSubmenuClose = () => {
    setSubmenuLibraryItemRef(null);
    setAnchorEl(null);
  };

  const handleEnableEditTitle = () => {
    setLibraryDialogData({
      id: submenuLibraryItemRef.current?.id || -1,
      title: submenuLibraryItemRef.current?.title || '',
      dialogOpen: true,
      targetHistoryId: -1,
      type: 'update',
    });
    handleSubmenuClose();
  };

  const navigate = useNavigate();
  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [, setScreenLoaderAtom] = useAtom(screenLoaderDataAtom);

  const handleDeleteLibrary = async () => {
    if (submenuLibraryItemRef.current?.id) {
      const libraryId = submenuLibraryItemRef.current.id;
      setConfirmDialogData({
        open: true,
        title: t('libraryDelete.confirmTitle'),
        contentText: (
          <span style={{ fontSize: '15px' }}>
            {t('libraryDelete.confirmDeleteMessage')}
          </span>
        ),
        confirmText: t('libraryDelete.delete'),
        handleConfirm: async () => {
          setScreenLoaderAtom({
            key: 'library.delete',
            loading: true,
          });
          setConfirmDialogData({
            open: false,
          });
          await deleteLibrary({ id: libraryId });
          navigate(RoutesURL.LIBRARY);
          setScreenLoaderAtom({
            key: 'library.delete',
            loading: false,
          });
          if (historySearchData.libraryId === libraryId) {
            setHistorySearchData({
              libraryId: -1,
              search: '',
              includeContent: true,
            });
          }
        },
        handleCancel: () => {
          setConfirmDialogData({
            open: false,
          });
        },
      });
    }
    handleSubmenuClose();
  };

  return (
    <BaseMenu
      id='library-sub-menu'
      disableAutoFocus
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'right',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'right',
      }}
      keepMounted
      open={submenuOpen}
      onClose={handleSubmenuClose}
    >
      <MenuItem onClick={handleEnableEditTitle}>
        <ListItemIcon>
          <IconPencil />
        </ListItemIcon>
        <ListItemText primaryTypographyProps={{ fontSize: '14px' }}>
          {t('chat.action.editTitle')}
        </ListItemText>
      </MenuItem>
      <MenuItem onClick={handleDeleteLibrary} sx={{ color: '#FA5252' }}>
        <ListItemIcon>
          <IconTrashCan fill='#FA5252' />
        </ListItemIcon>
        <ListItemText primaryTypographyProps={{ fontSize: '14px' }}>
          {t('chat.action.deleteLibrary')}
        </ListItemText>
      </MenuItem>
    </BaseMenu>
  );
};
