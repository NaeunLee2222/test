import {
  Button,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Popover,
  Radio,
  Typography,
} from '@mui/material';
import { useTranslation } from 'react-i18next';

import IconCheck from '@/assets/basic-icons/icon-check.svg?react';
import IconUncheck from '@/assets/basic-icons/icon-uncheck.svg?react';
import { useToolGroupList } from '@/modules/agent/hooks/useAgent';
import { IToolGroup } from '@/modules/agent/type/agent';
import styles from '@/modules/chat/components/ToolSelectorPopover/ToolSelectorPopover.module.scss';
import { selectedToolGroupsAtom } from '@/modules/chat/jotai/chat';
import { Close } from '@mui/icons-material';
import { useAtom } from 'jotai';
import { useState } from 'react';

interface ToolSelectorPopoverProps {
  anchorEl: HTMLElement | null;
  onClose: () => void;
}

const ToolSelectorPopover = ({
  anchorEl,
  onClose,
}: Readonly<ToolSelectorPopoverProps>) => {
  const open = Boolean(anchorEl);
  const { t } = useTranslation('tax');
  const [openDrawer, setOpenDrawer] = useState(false);
  const [{ data: toolGroups }] = useAtom(useToolGroupList);
  const [selectedTools, setSelectedTools] = useAtom(selectedToolGroupsAtom);

  const handleChange = (key: IToolGroup) => {
    if (selectedTools.includes(key)) {
      setSelectedTools((prev) => prev.filter((item) => item.id !== key.id));
    } else {
      setSelectedTools((prev) => [...prev, key]);
    }
  };

  return (
    <>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={onClose}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        PaperProps={{
          className: styles.toolPaper,
        }}
        className={styles.toolWrapper}
      >
        <div className={styles.header}>
          <Typography className={styles.headerTitle}>
            {t('toolList.title')}
          </Typography>
          <Typography
            className={styles.headerLink}
            onClick={() => {
              setOpenDrawer(true);
            }}
          >
            {t('toolList.expandAction')}
          </Typography>
        </div>
        <List disablePadding className={styles.toolList}>
          {(toolGroups ?? []).map((tool) => (
            <ListItem
              key={tool.id}
              className={styles.listItem}
              onClick={() => handleChange(tool)}
            >
              <Radio
                checked={selectedTools.includes(tool)}
                icon={<IconUncheck />}
                checkedIcon={<IconCheck />}
                className={styles.radioBtn}
              />
              <ListItemText className={styles.itemText} primary={tool.name} />
            </ListItem>
          ))}
        </List>
      </Popover>
      <Drawer
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
        anchor='right'
        sx={{
          zIndex: 1400,
        }}
        BackdropProps={{
          sx: {
            opacity: 1,
            backgroundColor: 'transparent',
          },
        }}
        PaperProps={{
          className: styles.toolDrawerPaper,
        }}
      >
        <div className={styles.drawerHeader}>
          <p className={styles.drawerTitle}>{t('toolList.fullDetailTitle')}</p>
          <Button
            className={styles.closeBtn}
            onClick={() => {
              setOpenDrawer(false);
            }}
          >
            <Close />
          </Button>
        </div>

        <div className={styles.toolDrawerList}>
          <div className={styles.drawerListMsg}>{t('toolList.drawerMsg')}</div>
          <div className={styles.toolDrawerListContainer}>
            {(toolGroups ?? []).map((tool) => (
              <div
                className={styles.toolDrawerItem}
                key={tool.id}
                onClick={() => {
                  handleChange(tool);
                }}
              >
                <Radio
                  checked={selectedTools.includes(tool)}
                  icon={<IconUncheck />}
                  checkedIcon={<IconCheck />}
                  className={styles.radioBtn}
                />
                <div className={styles.drawerItemDetail}>
                  <p className={styles.drawerItemTitle}>{tool.name}</p>
                  <p className={styles.drawerItemDescription}>
                    {tool.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Drawer>
    </>
  );
};

export default ToolSelectorPopover;
