import loadingIcon from '@/assets/lotties/loading-icon.json';
import { AgentType } from '@/modules/agent/type/agent';
import { ChatBubble } from '@/modules/chat/components/ChatContent/ChatBubble';
import { ChatCompareDialog } from '@/modules/chat/components/ChatContent/ChatCompareDialog';
import { DateDividerChip } from '@/modules/chat/components/ChatContent/ChatDateDivider';
import { ChatInit } from '@/modules/chat/components/ChatContent/ChatInit';
import styles from '@/modules/chat/components/ChatMain/ChatMain.module.scss';
import { FeedbackDialog } from '@/modules/chat/components/Dialog/FeedbackDialog';
import { useChatScrollHandler } from '@/modules/chat/hooks/chatScrollHandler';
import { useChatSendHandler } from '@/modules/chat/hooks/chatSendHandler';
import {
  conversationStarterMessageAtom,
  messagesAtom,
} from '@/modules/chat/jotai/chat';
import { ChatType } from '@/modules/chat/types/chat';
import { USER_ID } from '@/modules/chat/types/user';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { EStreamType, IChatBubbleType, IInfoMessage } from '@/types/layout';
import { Box } from '@mui/material';
import { useAtom, useAtomValue } from 'jotai';
import { useEffect, useMemo, useState } from 'react';
import { useCookies } from 'react-cookie';

export const ChatBubbles = ({
  infoMessage,
  type = 'chat',
  mode = AgentType.PRO,
  streamType,
}: {
  type?: IChatBubbleType;
  infoMessage?: IInfoMessage;
  mode?: AgentType;
  streamType?: EStreamType;
}) => {
  const messagesData = useAtomValue(messagesAtom);
  const { messagesStartRef, messagesEndRef } = useChatScrollHandler();
  const { isFetching } = useMainContext();

  // 메시지 표시할 UUID 배열 계산
  const messagesUuidArr = useMemo(() => {
    if (!messagesData || Object.keys(messagesData).length === 0) {
      return [];
    }

    // 시간순으로 정렬된 메시지 배열 생성
    const sortedMessages = Object.values(messagesData)
      .filter((msg) => msg?.uuid) // 유효한 메시지만 필터링
      .sort((a, b) => {
        const dateA = new Date(a.createdAt || 0).getTime();
        const dateB = new Date(b.createdAt || 0).getTime();
        return dateA - dateB; // 오래된 것부터 새로운 것 순서
      });

    // UUID 배열로 변환
    const result = sortedMessages.map((msg) => msg.uuid);

    return result;
  }, [messagesData]);

  // 메시지 비교 다이얼로그 상태
  const [chatCompareDialogOpen, setChatCompareDialogOpen] = useState(false);
  const [compareUuid, setCompareUuid] = useState<string>('');
  const compareAskChat = useMemo(
    () => (compareUuid && messagesData[compareUuid]) || undefined,
    [compareUuid, messagesData]
  );
  const [cookies] = useCookies([USER_ID]);
  const [conversationStarterMessage, setConversationStarterMessage] = useAtom(
    conversationStarterMessageAtom
  );
  const { sendMessage } = useChatSendHandler();
  const handleSendMessage = (message: string) => {
    sendMessage({
      message,
      userId: cookies.userId,
      chatType: ChatType.GENERAL,
      chatTitle: message,
    });
  };

  useEffect(() => {
    setConversationStarterMessage(undefined);
  }, [setConversationStarterMessage]);

  // 로딩이 완료되었지만 메시지가 없는 경우
  if (
    !isFetching &&
    (!messagesData || Object.keys(messagesData).length === 0) &&
    type !== 'init'
  ) {
    if (conversationStarterMessage) {
      handleSendMessage(conversationStarterMessage);
      return;
    }

    return <ChatInit />;
  }

  // 메시지가 로딩 중이고 아직 데이터가 없는 경우 로딩 표시
  if (isFetching && (!messagesData || Object.keys(messagesData).length === 0)) {
    return (
      <Box className={styles.loading}>
        <LottiePlayer
          options={{
            renderer: 'svg',
            loop: true,
            autoplay: true,
            animationData: loadingIcon,
          }}
          width={100}
          height={100}
        />
      </Box>
    );
  }

  return (
    <>
      <FeedbackDialog />
      <ChatCompareDialog
        open={chatCompareDialogOpen}
        setOpen={setChatCompareDialogOpen}
        askChat={compareAskChat}
      />
      {type !== 'init' && (
        <>
          {messagesUuidArr.length > 0 && (
            <DateDividerChip
              message={messagesData[messagesUuidArr[0]]}
              index={0}
              messagesUuidArr={messagesUuidArr}
              messagesData={messagesData}
            />
          )}
          <div className={styles.chatBubbleWrap}>
            <div
              ref={messagesStartRef}
              style={{
                display: 'none',
              }}
            />
            {infoMessage && (
              <ChatBubble
                key='report-bubble'
                bubbleType={infoMessage.type}
                type='text'
                role={infoMessage.role}
                data={infoMessage.message}
                uuid='info-message'
                datetimeStr={infoMessage.createdAt}
                mode={mode}
                streamType={streamType}
              />
            )}

            {messagesUuidArr?.map((messageUuid, index, arr) => {
              const message = messagesData[messageUuid];

              // 메시지가 존재하지 않으면 스킵
              if (!message) {
                console.warn(
                  `Message with UUID ${messageUuid} not found in messagesData`
                );
                return null;
              }

              // 메시지 콘텐츠 추출 및 처리
              const getMessageContent = (msg: any) => {
                // 1. content가 있으면 우선 사용
                if (msg?.content?.trim()) {
                  return msg.content;
                }

                // 2. message가 있는 경우 처리
                if (msg.message) {
                  // message가 JSON 문자열인 경우 파싱 시도
                  if (
                    typeof msg.message === 'string' &&
                    msg.message.startsWith('[')
                  ) {
                    try {
                      const parsedMessage = JSON.parse(msg.message);
                      if (Array.isArray(parsedMessage)) {
                        // token 타입의 content들을 추출하여 연결
                        const tokenContents = parsedMessage
                          .filter(
                            (item) => item.type === 'token' && item.content
                          )
                          .map((item) => item.content)
                          .join('');

                        if (tokenContents.trim()) {
                          return tokenContents;
                        }
                      }
                    } catch (e) {
                      console.warn('Failed to parse message JSON:', e);
                      // JSON 파싱 실패 시 원본 문자열 반환
                      return msg.message;
                    }
                  } else if (typeof msg.message === 'string') {
                    return msg.message;
                  }
                }

                // 3. 둘 다 없으면 빈 문자열
                return '';
              };

              // 메시지 타입 결정 (CANVAS, TOKEN 타입 감지 포함)
              const getMessageType = (msg: any) => {
                // 1. 기본 타입이 있으면 사용
                if (msg.type) {
                  return msg.type;
                }

                // 2. message 필드에서 타입 감지
                if (msg.message) {
                  if (
                    typeof msg.message === 'string' &&
                    msg.message.startsWith('[')
                  ) {
                    try {
                      const parsedMessage = JSON.parse(msg.message);
                      if (Array.isArray(parsedMessage)) {
                        // TOKEN 타입이 있는지 확인 (우선순위)
                        const hasTokenType = parsedMessage.some(
                          (item) => item.type === 'token' && item.content
                        );

                        if (hasTokenType) {
                          return 'text'; // 토큰 메시지는 text 타입으로 처리
                        }

                        // CANVAS, SLIDE, GRAPH 등의 타입이 있는지 확인
                        const hasCanvasType = parsedMessage.some(
                          (item) =>
                            item.type &&
                            (item.type.includes('canvas') ||
                              item.type.includes('slide') ||
                              item.type.includes('graph') ||
                              item.type === 'CANVAS' ||
                              item.type === 'plan_start' ||
                              item.type === 'step_start' ||
                              item.type === 'action_start')
                        );

                        if (hasCanvasType) {
                          return 'canvas';
                        }
                      }
                    } catch {
                      // JSON 파싱 실패 시 기본 타입 반환
                    }
                  }
                }

                // 3. 기본값은 'text'
                return 'text';
              };

              const messageContent = getMessageContent(message);
              const messageType = getMessageType(message);

              // 토큰 메시지인지 확인
              const hasTokenContent =
                message.message &&
                typeof message.message === 'string' &&
                message.message.startsWith('[') &&
                (() => {
                  try {
                    const parsedMessage = JSON.parse(message.message);
                    return (
                      Array.isArray(parsedMessage) &&
                      parsedMessage.some(
                        (item) => item.type === 'token' && item.content
                      )
                    );
                  } catch (e) {
                    return false;
                  }
                })();

              // 빈 메시지는 스킵 (단, user 메시지, canvas 타입, 토큰 메시지는 표시)
              if (
                !messageContent.trim() &&
                message.role !== 'user' &&
                messageType !== 'canvas' &&
                !hasTokenContent
              ) {
                return null;
              }

              return (
                <>
                  <ChatBubble
                    key={messageUuid}
                    bubbleType={type}
                    mode={mode}
                    streamType={streamType}
                    type={messageType}
                    role={message.role}
                    data={messageContent}
                    contentMetadata={message.message}
                    uuid={message.uuid}
                    thought={message.thought}
                    feedback={message.feedback}
                    config={message.config}
                    datetimeStr={message.createdAt}
                    citations={message.citations}
                    isLast={index === arr.length - 1}
                    setCompareUuid={() => {
                      setCompareUuid(message.parentUuid || '');
                      setChatCompareDialogOpen(true);
                    }}
                    messageTreeHandler={undefined}
                  />
                  <div ref={messagesEndRef} />
                </>
              );
            })}
          </div>
        </>
      )}
    </>
  );
};
