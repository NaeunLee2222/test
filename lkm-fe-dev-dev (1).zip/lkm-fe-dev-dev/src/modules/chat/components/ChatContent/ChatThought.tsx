import IconChecked from '@/assets/basic-icons/icon-checked.svg?react';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { IThought } from '@/modules/chat/types/message';
import { useTranslation } from 'react-i18next';
import IconChevronDown from '@/assets/direction-icons/icon-chevron-down.svg?react';
import CheckCircleIcon from '@/assets/basic-icons/icon-check-circled.svg?react';
import { useLayoutEffect, useRef, useState } from 'react';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import IconLock from '@/assets/basic-icons/icon-lock.svg?react';
import {
  BaseAccordion,
  BaseAccordionSummary,
  BaseAccordionDetails,
} from '@/modules/core/components/common/BaseAccordion';
import styles from './ChatThought.module.scss';
import { ChatMarkdown } from './ChatMarkdown';
import { isSecretModeAtom } from '../../jotai/chat';

interface IProps {
  isLoading?: boolean;
  isAborted?: boolean;
  thought?: IThought[];
}

export const ChatThought = ({ isLoading, isAborted, thought }: IProps) => {
  const [open, setOpen] = useState(false);
  const [isSecretMode] = useAtom(isSecretModeAtom);
  const { t } = useTranslation('tax');

  const prevIsLoading = useRef(isLoading);

  useLayoutEffect(() => {
    if (isLoading) setOpen(isLoading);
    if (prevIsLoading.current && !isLoading) setOpen(false);
    prevIsLoading.current = isLoading;
  }, [isLoading]);

  if (!thought?.length) return <></>;
  return (
    <BaseAccordion
      expanded={open}
      onChange={() => !isLoading && setOpen(!open)}
      sx={{
        '&.MuiAccordion-root': isSecretMode
          ? {
              backgroundColor: 'var(--gray-50)',
            }
          : {},
      }}
    >
      <BaseAccordionSummary
        expandIcon={
          isLoading ? (
            <div />
          ) : (
            <IconChevronDown
              style={{
                width: '14px',
                height: '8px',
                fill: 'var(--gray-500)',
              }}
            />
          )
        }
        sx={{
          '&.MuiAccordionSummary-root': {
            cursor: isLoading ? 'default !important' : 'pointer',
          },
        }}
      >
        {isLoading ? (
          <>{t('message.thought')}</>
        ) : isAborted ? (
          <>
            <BaseTooltip title={t('message.noticeAborted')}>
              <ErrorOutlineIcon sx={{ color: 'gray' }} />
            </BaseTooltip>
            {t('message.stopped')}
          </>
        ) : (
          <>
            {isSecretMode ? <IconLock /> : <CheckCircleIcon />}
            {t('message.completed')}
          </>
        )}
      </BaseAccordionSummary>
      <BaseAccordionDetails
        sx={{
          '&.MuiAccordionDetails-root': {
            gap: '12px',
          },
        }}
      >
        {thought.map((item, index, arr) => (
          <div key={index} className={styles.thought}>
            <div className={styles.title}>
              <div className={styles.icon}>
                {!isLoading || (isLoading && index !== arr.length - 1) ? (
                  <IconChecked
                    fill={isSecretMode ? 'var(--gray-900)' : '#4263EB'}
                  />
                ) : (
                  <div className={styles.loaderWrap}>
                    <div className={styles.loader} />
                  </div>
                )}
              </div>
              {item.title}
            </div>

            <div
              className={cn(
                styles.content,
                isLoading && index !== arr.length - 1 && styles.displayNone
              )}
            >
              <ChatMarkdown
                message={item.content}
                classNameProps={styles.contentMarkdown}
              />
            </div>
          </div>
        ))}
      </BaseAccordionDetails>
    </BaseAccordion>
  );
};
