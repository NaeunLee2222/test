import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import styles from './ChatMarkdown.module.scss';

interface Props {
  message: string;
  classNameProps?: string;
}

export const ChatMarkdownSimple = React.memo(
  ({ message, classNameProps }: Props) => (
    <ReactMarkdown
      className={classNameProps}
      children={message}
      remarkPlugins={[remarkGfm]}
      components={{
        em: ({ node, ...props }: any) => <span>{props.children}</span>,
        code({ node, inline, className, children, ...props }: any) {
          return inline ? (
            <span>{children}</span>
          ) : (
            <span>{String(children).replace(/\n$/, '')}</span>
          );
        },
        h1: ({ node, ...props }) => <strong>{props.children}</strong>,
        h2: ({ node, ...props }) => <strong>{props.children}</strong>,
        h3: ({ node, ...props }) => <strong>{props.children}</strong>,
        h4: ({ node, ...props }) => <strong>{props.children}</strong>,
        h5: ({ node, ...props }) => <strong>{props.children}</strong>,
        h6: ({ node, ...props }) => <strong>{props.children}</strong>,
        strong: ({ node, ...props }) => <strong>{props.children}</strong>,
        p: ({ node, ...props }) => <span>{props.children}</span>,
        li: ({ node, ...props }) => <span>{props.children}</span>,
        ol: ({ node, ...props }) => <span>{props.children}</span>,
        ul: ({ node, ...props }) => <span>{props.children}</span>,
        a: ({ node, ...props }) => <span>{props.children}</span>,
        table: ({ node, ...props }) => <span>{props.children}</span>,
        tbody: ({ node, ...props }) => <span>{props.children}</span>,
        td: ({ node, ...props }) => <span>{props.children}</span>,
        th: ({ node, ...props }) => <span>{props.children}</span>,
        tr: ({ node, ...props }) => <span>{props.children}</span>,
        hr: ({ node, ...props }) => <hr className={styles.hr} {...props} />,
        img: () => null, // removes images entirely
      }}
    />
  )
);

ChatMarkdownSimple.displayName = 'ChatMarkdownSimple';
