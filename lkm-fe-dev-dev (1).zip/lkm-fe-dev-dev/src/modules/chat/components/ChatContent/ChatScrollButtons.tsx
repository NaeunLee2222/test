import { IconButton } from '@mui/material';
import IconArrowDown from '@/assets/direction-icons/icon-arrow-down.svg?react';

interface ChatScrollButtonsProps {
  isAtBottom: boolean;
  scrollToBottom: () => void;
}

export const ChatScrollButtons = ({
  isAtBottom,
  scrollToBottom,
}: ChatScrollButtonsProps) =>
  !isAtBottom && (
    <IconButton
      onClick={scrollToBottom}
      sx={{
        cursor: 'pointer',
        padding: 0,
        width: '32px',
        height: '32px',
        border: '1px solid var(--gray-300)',
        borderRadius: '99px',
        boxShadow: '0px 0px 4px 0px #00000040',
        backgroundColor: 'white !important',
      }}
    >
      <IconArrowDown width='20' height='20' />
    </IconButton>
  );
