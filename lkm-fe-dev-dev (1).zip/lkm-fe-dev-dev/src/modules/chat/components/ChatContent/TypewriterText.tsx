import { SxProps, Theme, Typography } from '@mui/material';
import { useEffect, useRef, useState } from 'react';

const useTypewriter = (text: string, speed = 30, animated = true) => {
  const [displayedText, setDisplayedText] = useState('');
  const [isCompleted, setIsCompleted] = useState(false);
  const prevTextRef = useRef<string>('');
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const doneRef = useRef<boolean>(false);

  useEffect(() => {
    // 애니메이션이 비활성화된 경우 즉시 텍스트 표시
    if (!animated) {
      setDisplayedText(text);
      setIsCompleted(true);
      prevTextRef.current = text;
      return;
    }

    if (!text || typeof text !== 'string') {
      setDisplayedText('');
      setIsCompleted(false);
      prevTextRef.current = '';
      return;
    }

    // 이전 텍스트와 동일하고 이미 완료된 경우, 즉시 표시
    if (prevTextRef.current === text && isCompleted) {
      setDisplayedText(text);
      return;
    }

    // 타이머 정리
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }

    // 새로운 텍스트이거나 아직 완료되지 않은 경우 애니메이션 실행
    let index = 0;
    setIsCompleted(false);
    prevTextRef.current = text;
    setDisplayedText('');

    const type = () => {
      setDisplayedText(text.slice(0, index));
      if (index < text.length) {
        index++;
        timerRef.current = setTimeout(type, speed);
      } else {
        setIsCompleted(true);
        timerRef.current = null;
        doneRef.current = true;
      }
    };

    requestAnimationFrame(type);

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [text, speed, animated]);

  // 컴포넌트 언마운트 시 타이머 정리
  useEffect(
    () => () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    },
    []
  );

  return { displayedText, isDone: doneRef.current };
};

export const TypewriterText = ({
  text,
  speed = 1,
  animated = true,
  variant = 'body2',
  className,
  sx,
}: {
  text: string;
  speed?: number;
  animated?: boolean;
  variant?: 'body1' | 'body2' | 'subtitle1' | 'h6';
  className?: string;
  sx?: SxProps<Theme>;
}) => {
  const { displayedText: animatedText } = useTypewriter(text, speed);

  return (
    <Typography variant={variant} className={className} sx={sx}>
      {animated ? animatedText : text}
    </Typography>
  );
};
