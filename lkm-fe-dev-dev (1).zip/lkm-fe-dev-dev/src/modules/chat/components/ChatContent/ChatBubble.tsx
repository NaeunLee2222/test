import { ChatCitations } from '@/modules/chat/components/ChatCitation/ChatCitations';
import { ChatRelevantCitations } from '@/modules/chat/components/ChatCitation/ChatRelevantCitations';

import { AgentType } from '@/modules/agent/type/agent';
import { rebuildThinkingFromMessage } from '@/modules/chat/api/chat';
import { ChartProcessing } from '@/modules/chat/components/ChatContent/ChartProcessing';
import styles from '@/modules/chat/components/ChatContent/ChatBubble.module.scss';
import {
  ChatCompare,
  ChatCopy,
  ChatFeedback,
  ChatResend,
} from '@/modules/chat/components/ChatContent/ChatBubbleActions';
import { ChatMarkdown } from '@/modules/chat/components/ChatContent/ChatMarkdown';
import { ChatProfile } from '@/modules/chat/components/ChatContent/ChatProfile';
import { ChatRecommendations } from '@/modules/chat/components/ChatContent/ChatRecommendations';
import { ChatThought } from '@/modules/chat/components/ChatContent/ChatThought';
import { ChatInputField } from '@/modules/chat/components/ChatInput/ChatInputField';
import { useChatScrollHandler } from '@/modules/chat/hooks/chatScrollHandler';
import { useChatSendHandler } from '@/modules/chat/hooks/chatSendHandler';
import { isGeneratingAtom, isSecretModeAtom } from '@/modules/chat/jotai/chat';
import {
  canvasAtom,
  canvasAtoms,
  detailCanvas,
  newPlanAtoms,
} from '@/modules/chat/jotai/chatprocessing';
import { ERole } from '@/modules/chat/types/chat';
import { EPlanType, PlanInfo } from '@/modules/chat/types/chatprocessing';
import { IFeedback } from '@/modules/chat/types/feedback';
import {
  ICitation,
  IConfig,
  IThought,
  MessageType,
} from '@/modules/chat/types/message';
import { SelectableMarkdown } from '@/modules/report/components/ReportChat/ReportChatSelectableMarkdown';
import { EBubbleType, EStreamType, IChatBubbleType } from '@/types/layout';
import { dateToTimeStr } from '@/utils';
import { bufferStr, decodeHtmlEntities, parseLatex } from '@/utils/chatUtil';
import { ErrorOutline } from '@mui/icons-material';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChatWorkflowReview } from '../ChatWorkflowReview/ChatWorkflowReview';

interface IProps {
  role: ERole;
  type?: MessageType;
  data: string;
  uuid: string;
  thought?: IThought[];
  feedback?: IFeedback;
  config?: IConfig;
  citations?: ICitation[];
  datetimeStr?: string;
  messageTreeHandler?: React.ReactElement;
  setCompareUuid?: () => void;
  hideActions?: boolean;
  isLast?: boolean;
  bubbleType?: IChatBubbleType;
  mode?: AgentType;
  streamType?: EStreamType;
  contentMetadata?: string;
}

export const ChatBubble = ({
  type,
  uuid,
  feedback,
  config,
  data,
  role,
  thought,
  citations,
  datetimeStr,
  messageTreeHandler,
  setCompareUuid,
  hideActions,
  isLast,
  bubbleType = 'chat',
  mode,
  streamType,
  contentMetadata,
}: IProps) => {
  const isGenerating = useAtomValue(isGeneratingAtom);
  const isUser = role === 'user';

  // Canvas 관련 atoms 미리 가져오기
  const allPlans = useAtomValue(newPlanAtoms);
  const plansForChat = allPlans[uuid];
  const setPlanAtoms = useSetAtom(newPlanAtoms);
  const setCanvases = useSetAtom(canvasAtoms);
  const setCanvasDetail = useSetAtom(detailCanvas);
  const setCanvas = useSetAtom(canvasAtom);

  // rebuildThinkingFromMessage 중복 호출 방지를 위한 ref
  const processedMessageRef = useRef<string | null>(null);

  // Canvas 메시지일 때 plan 데이터 재빌드 - 중복 호출 방지
  useEffect(() => {
    if (role === ERole.ASSISTANT && contentMetadata) {
      // 이미 처리된 메시지인지 확인
      const messageKey = `${uuid}-${contentMetadata}`;
      if (processedMessageRef.current === messageKey) {
        return;
      }

      // 이미 해당 UUID로 plan 데이터가 있는지 확인
      if (plansForChat && Object.keys(plansForChat.plans || {}).length > 0) {
        processedMessageRef.current = messageKey;
        return;
      }

      processedMessageRef.current = messageKey;

      // 전체 contentMetadata를 한 번에 처리
      const messageData = {
        uuid,
        message: contentMetadata,
        role: role as ERole,
      };
      rebuildThinkingFromMessage(
        setPlanAtoms,
        messageData as any,
        setCanvases,
        setCanvasDetail,
        setCanvas
      );
    }
  }, [
    role,
    uuid,
    contentMetadata,
    plansForChat,
    setPlanAtoms,
    setCanvases,
    setCanvasDetail,
    setCanvas,
  ]);

  const chatProfileComponent = useMemo(
    () => <ChatProfile type={role} agentType={mode} />,
    [mode, role]
  );

  const { resendMessage } = useChatSendHandler();
  const { scrollToBottom } = useChatScrollHandler();
  const [isSecretMode] = useAtom(isSecretModeAtom);

  const [isEdit, setIsEdit] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [userInput, setUserInput] = useState('');
  const [isHovered, setIsHovered] = useState(false);
  const isResendDisabled = useMemo(
    () => !userInput?.length || data === userInput,
    [userInput, data]
  );

  const handleEditMessage = () => {
    setIsEdit(!isEdit);
  };

  useEffect(() => {
    data && setUserInput(data);
  }, [data, uuid, isEdit]);

  const resendDisabled = useMemo(() => {
    const trimmedMessage = userInput?.replaceAll('\n', '').trim();
    return !trimmedMessage?.length || isGenerating;
  }, [userInput, isGenerating]);

  const onClickSendHandler = useCallback(() => {
    if (resendDisabled) return;
    setIsEdit(false);
    const trimmedMessage = inputRef.current?.value?.replaceAll('\n', '').trim();
    if (trimmedMessage) {
      resendMessage(uuid, userInput);
      scrollToBottom();
      setTimeout(() => {
        setUserInput('');
      }, 100);
    }
  }, [resendDisabled, resendMessage, scrollToBottom, userInput, uuid]);

  const [isTyping, setIsTyping] = useState(false);

  const isAnswered = useRef<boolean>(false);

  useEffect(() => {
    if (type === 'error') {
      setIsTyping(false);
      return;
    }
    if (type === 'loading' && !isAnswered.current) {
      setIsTyping(true);
      isAnswered.current = true;
    }
    if (!isGenerating) {
      setIsTyping(false);
    }
  }, [isGenerating, type]);

  const isEnableBubbleSelect = useMemo(
    () =>
      bubbleType === EBubbleType.REPORT &&
      role === 'ai' &&
      type === 'text' &&
      !isGenerating,

    [bubbleType, role, type, isGenerating]
  );

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const hideBackGroundColor =
    role === ERole.AI && bubbleType === EBubbleType.INFO;

  const hideMessageWrapper =
    role === 'ai' &&
    type === 'loading' &&
    !!thought?.length &&
    !data.trim().length &&
    isTyping;

  const showBotActions = useMemo(
    () =>
      (role === ERole.ASSISTANT || role === ERole.AI) &&
      !(isEdit || type === 'loading' || bubbleType === 'info' || isTyping),
    [bubbleType, isEdit, isTyping, role, type]
  );

  const showUserActions = role === 'user' && !(type === 'loading' || isTyping);

  const parsedData = useMemo(() => {
    // data가 비어있을 때 contentMetadata를 fallback으로 사용
    const messageContent = data || contentMetadata || '';

    if (type === 'text') {
      const parts = messageContent.split(/\[\[([^[\]]+)\]\]/g);
      const citationSplitted = parts
        .map((part, index) => {
          if (index % 2 === 0) {
            return part;
          }
          return `*${part}* `;
        })
        .join('');
      return parseLatex(citationSplitted);
    }
    return messageContent;
  }, [data, contentMetadata, type]);

  const referencedCitations = useMemo(
    () => citations?.filter((citation) => citation?.isReferencedInAnswer),
    [citations]
  );

  const notReferencedCitations = useMemo(
    () => citations?.filter((citation) => !citation?.isReferencedInAnswer),
    [citations]
  );

  const sortedCitations = useMemo(
    () =>
      referencedCitations?.sort(
        (a, b) => (a?.indexInMessage ?? 0) - (b?.indexInMessage ?? 0)
      ),
    [referencedCitations]
  );

  const renderInputElement = useCallback(() => {
    if (type === 'loading')
      return <div className={styles.loading}>{data || bufferStr}</div>;

    if (type === 'error')
      return (
        <div className={styles.error}>
          <ErrorOutline sx={{ width: '16px' }} />
          {data || '오류 발생'}
        </div>
      );

    if (isEdit)
      return (
        <ChatInputField
          bubbleType={bubbleType}
          userInput={userInput}
          inputRef={inputRef}
          setUserInput={setUserInput}
          onClickSendHandler={onClickSendHandler}
          propsSx={{
            '> *.MuiInputBase-root': {
              border: '1px solid var(--primary-color-600)',
              maxHeight: '132px',
              overflowY: 'auto',
            },
          }}
        />
      );

    if (isEnableBubbleSelect)
      return (
        parsedData && (
          <div className={styles.messageWrap}>
            <SelectableMarkdown
              messageUuid={uuid}
              message={parsedData}
              bubbleType={bubbleType}
              citations={sortedCitations}
            />
          </div>
        )
      );

    return (
      parsedData && (
        <div className={styles.messageWrap}>
          <ChatMarkdown
            message={isTyping ? parsedData + bufferStr : parsedData}
            bubbleType={bubbleType}
            citations={sortedCitations}
            messageUuid={uuid}
          />
        </div>
      )
    );
  }, [
    type,
    data,
    isEdit,
    bubbleType,
    userInput,
    onClickSendHandler,
    isEnableBubbleSelect,
    parsedData,
    sortedCitations,
    isTyping,
    uuid,
  ]);

  const processingElement = useCallback(() => {
    const components: React.ReactElement[] = [];
    // 원본 UUID의 plan 확인
    if (plansForChat?.plans && Object.keys(plansForChat.plans).length > 0) {
      Object.entries(plansForChat.plans).forEach(([planId, plan]) => {
        components.push(
          <ChartProcessing
            key={`${planId}-${uuid}-chart-processing`}
            uuid={uuid}
            newPlan={plan as PlanInfo}
          />
        );
      });
    }

    // ChartProcessing 컴포넌트들이 있으면 렌더링
    if (components.length > 0) {
      return <>{components}</>;
    }

    // plan 데이터가 없으면 일반 메시지 렌더링
    // if (parsedData) {
    //   return (
    //     <div className={styles.messageWrap}>
    //       <ChatMarkdown
    //         message={isTyping ? parsedData + bufferStr : parsedData}
    //         bubbleType={bubbleType}
    //         citations={sortedCitations}
    //         messageUuid={uuid}
    //       />
    //     </div>
    //   );
    // }

    return <></>;
  }, [plansForChat, uuid]);

  const workFlowElement = useCallback(() => {
    if (!plansForChat) return <></>;

    const plans = plansForChat?.plans || {};
    const planEntries = Object.entries(plans);

    if (planEntries.length === 0) return <></>;

    // plans를 원래 순서대로 렌더링 (토큰과 비토큰 혼합)
    return (
      <>
        {planEntries.map(([planId, plan]: any) => {
          // 토큰 타입인 경우
          if (plan.type === EPlanType.TOKEN && plan.tokenContent) {
            return (
              <Box
                key={`token-${plan.id}`}
                className='token-section'
                style={{
                  marginBottom: '16px',
                  padding: '16px 20px',
                  borderRadius: '12px',
                  border: '1px solid var(--primitives-darkBlue-20)',
                  background: 'var(--white)',
                }}
              >
                <ChatMarkdown message={plan.tokenContent} />
              </Box>
            );
          }

          // 비토큰 타입인 경우
          return (
            <ChatWorkflowReview
              key={`${planId}-${uuid}-chat-processing`}
              data={!isLast ? contentMetadata : null}
              planLive={{
                id: plan.id,
                parentId: plan.parentId,
                steps: plan.steps as any,
              }}
              config={config}
              uuid={uuid}
              isReadOnly={!isLast}
            />
          );
        })}
      </>
    );
  }, [config, contentMetadata, isLast, plansForChat, uuid]);

  const thoughtElement = useCallback(
    () =>
      streamType === EStreamType.WORKFLOW_REPORT
        ? workFlowElement()
        : processingElement(),
    [processingElement, streamType, workFlowElement]
  );

  // TODO: HARDCODED to display first message
  // TODO: Remove this logic
  const isAssistantFirstMessage =
    role === ERole.ASSISTANT && data?.includes('firstMessage : ');
  return (
    <Box
      component='div'
      className={cn(
        styles.chatBubble,
        bubbleType === 'info' && styles.info,
        !data && isUser && styles.hide
      )}
    >
      <div
        className={
          isUser ? cn(styles.header, styles.headerUser) : styles.header
        }
      >
        {chatProfileComponent}
        <span className={styles.time}>{dateToTimeStr(datetimeStr)}</span>
      </div>
      <Box
        className={cn(
          styles.content,
          isEdit && styles.edit,
          isUser && styles.user
        )}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <ChatThought
          isLoading={type === 'loading'}
          thought={thought}
          isAborted={config?.isAborted}
        />
        {role === ERole.ASSISTANT ? (
          thoughtElement()
        ) : (
          // <ChartProcessing uuid={uuid} newPlan={plansForChat} />
          <></>
        )}
        {}
        {isAssistantFirstMessage ? (
          <div className={styles.messageWrap}>
            <p
              className='body02Regular'
              style={{
                margin: '0px',
                overflowWrap: 'break-word',
                textAlign: 'left',
                textWrap: 'pretty',
                whiteSpaceCollapse: 'preserve',
                verticalAlign: 'middle',
                lineHeight: '30px',
              }}
            >
              {decodeHtmlEntities(contentMetadata || '')}
            </p>
          </div>
        ) : null}

        <div
          className={cn(
            styles.message,
            hideMessageWrapper && styles.hide,
            hideBackGroundColor && styles.hideBackgroundColor
          )}
        >
          {/* User 메시지이거나 assistant가 아닌 경우에만 renderInputElement 표시 */}
          {role !== ERole.ASSISTANT && renderInputElement()}
          {!config?.isAborted && type !== 'error' && (
            <ChatCitations
              bubbleType={bubbleType}
              messageUuid={uuid}
              citations={sortedCitations}
            />
          )}
          {showBotActions && !isAssistantFirstMessage && (
            <div className={styles.footer}>
              <div className={styles.head}>
                {!isSecretMode && (
                  <ChatFeedback message_uuid={uuid} bubbleType={bubbleType} />
                )}
                <ChatCompare
                  hideActions={hideActions || bubbleType === 'report' || true}
                  setCompareUuid={setCompareUuid}
                />
                <ChatCompare
                  hideActions={hideActions || bubbleType === 'report' || true}
                  setCompareUuid={setCompareUuid}
                />
                <ChatCopy message={data} />
              </div>
            </div>
          )}
          {showUserActions && (
            <ChatResend
              hideActions={hideActions || bubbleType === 'view'}
              isEdit={isEdit}
              handleEditMessage={handleEditMessage}
              onClickSendHandler={onClickSendHandler}
              disabled={isResendDisabled}
              isHovered={isHovered}
              handleMouseLeave={handleMouseLeave}
            />
          )}
        </div>

        {!config?.isAborted &&
          type !== 'error' &&
          !isTyping &&
          !!notReferencedCitations?.length && (
            <ChatRelevantCitations
              bubbleType={bubbleType}
              messageUuid={uuid}
              isLoading={type === 'loading'}
              citations={notReferencedCitations}
            />
          )}
        {!isGenerating &&
          isLast &&
          role === 'ai' &&
          type !== 'error' &&
          bubbleType !== 'view' && <ChatRecommendations messageUuid={uuid} />}
      </Box>
    </Box>
  );
};
