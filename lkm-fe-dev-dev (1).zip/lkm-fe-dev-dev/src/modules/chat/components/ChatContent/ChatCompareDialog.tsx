import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { IMessage } from '@/modules/chat/types/message';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ChatBubble } from './ChatBubble';
import { CompareController } from './ChatSiblingController';
import styles from './ChatCompareDialog.module.scss';

interface IProps {
  open: boolean;
  setOpen: (open: boolean) => void;
  askChat?: IMessage;
  answerSiblings?: IMessage[];
}

export const ChatCompareDialog = ({
  open,
  setOpen,
  askChat,
  answerSiblings,
}: IProps) => {
  const { t } = useTranslation('tax');
  const [firstViewIndex, setFirstViewIndex] = useState<number[]>([0]);
  const [secondViewIndex, setSecondViewIndex] = useState<number[]>([0]);

  const firstChild = useMemo(
    () => answerSiblings?.[firstViewIndex[0]],
    [answerSiblings, firstViewIndex]
  );
  const secondChild = useMemo(
    () => answerSiblings?.[secondViewIndex[0]],
    [answerSiblings, secondViewIndex]
  );

  useEffect(() => {
    setFirstViewIndex([0]);
    setSecondViewIndex(
      answerSiblings && answerSiblings?.length > 1 ? [1] : [0]
    );
  }, [answerSiblings, open]);

  return (
    <BaseDialog
      open={open}
      paddingX={24}
      title={t('chat.compare')}
      handleClose={() => setOpen(false)}
      sx={{
        '& .MuiPaper-root.MuiDialog-paper': {
          minWidth: '1200px !important',
          width: '1200px !important',
          minHeight: '800px !important',
        },
        '& .MuiDialogContent-root': {
          display: 'flex',
          overflow: 'auto',
        },
      }}
      contentChildren={
        <div className={styles.container}>
          <div className={styles.wrapper}>
            {askChat && (
              <ChatBubble
                key='compare-user-bubble'
                type={askChat.type}
                role={askChat.role}
                data={askChat.message}
                uuid={askChat.uuid}
                thought={askChat.thought}
                feedback={askChat.feedback}
                config={askChat.config}
                datetimeStr={askChat.createdAt}
                hideActions
              />
            )}
            <div className={styles.answerWrap}>
              <div className={styles.answer}>
                <div className={styles.controller}>
                  <CompareController
                    messagesOrder={firstViewIndex}
                    setMessagesOrder={setFirstViewIndex}
                    index={0}
                    siblings={answerSiblings}
                  />
                </div>
                {firstChild && (
                  <ChatBubble
                    type={firstChild.type}
                    role={firstChild.role}
                    data={firstChild.message}
                    uuid={firstChild.uuid}
                    thought={firstChild.thought}
                    feedback={firstChild.feedback}
                    config={firstChild.config}
                    datetimeStr={firstChild.createdAt}
                    hideActions
                  />
                )}
              </div>
              <div className={styles.answer}>
                <div className={styles.controller}>
                  <CompareController
                    messagesOrder={secondViewIndex}
                    setMessagesOrder={setSecondViewIndex}
                    index={0}
                    siblings={answerSiblings}
                  />
                </div>
                {secondChild && (
                  <ChatBubble
                    type={secondChild.type}
                    role={secondChild.role}
                    data={secondChild.message}
                    uuid={secondChild.uuid}
                    thought={secondChild.thought}
                    feedback={secondChild.feedback}
                    config={secondChild.config}
                    datetimeStr={secondChild.createdAt}
                    hideActions
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      }
    />
  );
};
