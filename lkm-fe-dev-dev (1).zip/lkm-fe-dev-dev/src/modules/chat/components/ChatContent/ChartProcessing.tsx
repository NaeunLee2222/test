import CheckCircleIcon from '@/assets/basic-icons/icon-check-circled.svg?react';
import IconChecked from '@/assets/basic-icons/icon-checked.svg?react';
import ExpandIcon from '@/assets/basic-icons/icon-expand.svg?react';
import NewTabIcon from '@/assets/basic-icons/icon-open-new-tab.svg?react';
import PPTXIcon from '@/assets/basic-icons/icon-ppt.svg?react';
import IconRFQ from '@/assets/basic-icons/icon-rqs.svg?react';
import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import IconFileDefault from '@/assets/file-icons/icon-file-default.svg?react';
import {
  agentCanvasOpenAtom,
  reloadCanvasById,
  slidePreviewOpenAtom,
} from '@/modules/agent/jotai/agent';
import styles from '@/modules/chat/components/ChatContent/ChartProcessing.module.scss';
import { ChatMarkdown } from '@/modules/chat/components/ChatContent/ChatMarkdown';
import { TypewriterText } from '@/modules/chat/components/ChatContent/TypewriterText';
import SlideCard from '@/modules/chat/components/SlideCard/SlideCard';
import { chatDataAtom, isGeneratingAtom } from '@/modules/chat/jotai/chat';
import { canvasAtoms, detailCanvas } from '@/modules/chat/jotai/chatprocessing';
import { graphDataAtom, graphTitleAtom } from '@/modules/chat/jotai/graph';
import { PPTXMode } from '@/modules/chat/types/chat';
import {
  CanvasInfo,
  EPlanType,
  EStatus,
  PlanInfo,
} from '@/modules/chat/types/chatprocessing';
import { RoutesURL } from '@/routers/routes';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Divider,
  styled,
  Typography,
} from '@mui/material';
import cn from 'classnames';
import { t } from 'i18next';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import * as React from 'react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';

import { isOpenLnbAtom } from '@/modules/core/jotai/layout';
import GraphVisualizer from '../Graph/network';

const LoadingDots = () => {
  const [activeDot, setActiveDot] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveDot((prev) => (prev + 1) % 3);
    }, 250);

    return () => clearInterval(interval);
  }, []);

  return (
    <span style={{ opacity: 0.8 }}>
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          style={{
            opacity: i <= activeDot ? 1 : 0.2,
            transition: 'opacity 0.2s',
          }}
        >
          .
        </span>
      ))}
    </span>
  );
};

type ChartProcessingProps = {
  uuid: string;
  newPlan: PlanInfo;
};
export const ChartProcessing: React.FC<ChartProcessingProps> = ({
  uuid,
  newPlan,
}) => {
  const location = useLocation();

  const setIsOpenLnb = useSetAtom(isOpenLnbAtom);
  const chatData = useAtomValue(chatDataAtom);
  const isGenerating = useAtomValue(isGeneratingAtom);
  const canvas = useAtomValue(canvasAtoms);
  const canvasID = newPlan.id;

  // newPlan.id로 먼저 찾고, 없으면 uuid로 찾되, newPlan에 직접 canvas 데이터가 있으면 그것을 우선 사용
  const data = useMemo(() => {
    // 1순위: newPlan에 직접 canvas 데이터가 있는 경우
    if (newPlan.canvas) {
      return newPlan;
    }
    // 2순위: canvasAtoms에서 newPlan.id로 찾기
    if (canvas[canvasID]) {
      return canvas[canvasID];
    }
    // 3순위: canvasAtoms에서 uuid로 찾기
    return canvas[uuid];
  }, [canvas, canvasID, uuid, newPlan]);

  const setCanvasDetail = useSetAtom(detailCanvas);
  const setAgentCanvasOpen = useSetAtom(agentCanvasOpenAtom);
  const setSlidePreviewOpen = useSetAtom(slidePreviewOpenAtom);
  const setReloadCanvasById = useSetAtom(reloadCanvasById);
  const setCanvases = useSetAtom(canvasAtoms);
  const [, setGraphTitle] = useAtom(graphTitleAtom);
  const [graphData] = useAtom(graphDataAtom);

  const [isExpand, setIsExpand] = useState<boolean>(true);
  const currentPlan = newPlan.id.includes(uuid) ? newPlan : null;

  const isGeneralAgentPath = useMemo(
    () =>
      location.pathname.includes(RoutesURL.AGENT_CREATE) ||
      location.pathname.includes(RoutesURL.GENERAL_AGENT),
    [location.pathname]
  );

  const titleString = useMemo(() => {
    const title =
      currentPlan?.name ??
      chatData.title ??
      newPlan?.canvas?.canvas?.title ??
      newPlan?.canvas?.sheet?.title ??
      newPlan?.canvas?.slide?.title ??
      data?.canvas?.title ??
      data?.sheet?.title ??
      data?.slide?.title;
    if (typeof title === 'undefined') return '';
    if (
      (currentPlan?.status &&
        (currentPlan.status === EStatus.LOADING ||
          currentPlan.status === EStatus.INCOMPLETE)) ||
      (currentPlan?.steps &&
        Object.values(currentPlan.steps).some(
          (step) => step.status === EStatus.LOADING
        ))
    ) {
      return `${title} ${t('creating')}`;
    }
    return `${title} 생성 완료`;
  }, [chatData, data, currentPlan, newPlan]);

  // plan이 완료된 상태인지 확인하는 메모
  const isPlanCompleted = useMemo(
    () =>
      currentPlan?.status === EStatus.SUCCESS &&
      (!currentPlan?.steps ||
        Object.values(currentPlan.steps).every(
          (step) => step.status === EStatus.SUCCESS
        )),
    [currentPlan]
  );

  // 스트리밍 중이고 현재 아이템이 진행 중인지 확인
  const shouldAnimateTitle = useMemo(
    () => isGenerating && !isPlanCompleted,
    [isGenerating, isPlanCompleted]
  );

  // set graph title when data exist
  useEffect(() => {
    if (currentPlan?.canvas?.graph?.title) {
      setGraphTitle(currentPlan?.canvas?.graph?.title);
    }
  }, [newPlan]);

  const handleOpenCanvas = useCallback(() => {
    setReloadCanvasById(true);

    // 캔버스 데이터가 있는지 확인하고 canvasAtoms에 저장
    if (newPlan.canvas) {
      const canvasDataToStore = newPlan.canvas;

      // canvasAtoms에 해당 plan ID로 캔버스 데이터 저장
      setCanvases((prev: { [chatID: string]: CanvasInfo | any }) => ({
        ...prev,
        [newPlan.id]: canvasDataToStore,
      }));
    }

    setCanvasDetail(newPlan.id);
    setAgentCanvasOpen(true);
    setIsOpenLnb(false);
  }, [
    isGeneralAgentPath,
    setCanvasDetail,
    newPlan.id,
    newPlan.canvas,
    setAgentCanvasOpen,
    setReloadCanvasById,
    setIsOpenLnb,
    setCanvases,
  ]);

  const handleOpenGraphInNewTab = async () => {
    window.open(
      `${window.location.origin}${RoutesURL.GRAPH}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const handleOpenPresentation = useCallback(() => {
    // 캔버스 데이터가 있는지 확인하고 canvasAtoms에 저장
    if (newPlan.canvas) {
      const canvasDataToStore = newPlan.canvas;

      // canvasAtoms에 해당 plan ID로 캔버스 데이터 저장
      setCanvases((prev: { [chatID: string]: CanvasInfo | any }) => ({
        ...prev,
        [newPlan.id]: canvasDataToStore,
      }));
    }

    setCanvasDetail(newPlan.id);
    setSlidePreviewOpen(true);
  }, [
    newPlan.id,
    newPlan.canvas,
    setSlidePreviewOpen,
    setCanvasDetail,
    setCanvases,
  ]);

  if (!currentPlan) return null;

  return (
    <>
      {currentPlan.type !== EPlanType.TOKEN && (
        <Box className={styles.canvas}>
          {(currentPlan.type === EPlanType.STEP_PLAN ||
            currentPlan.type === EPlanType.THINKING) && (
            <Accordion
              className={styles.canvasBubble}
              expanded={
                currentPlan?.steps && Object.keys(currentPlan?.steps).length > 0
                  ? isExpand
                  : false
              }
              disableGutters
              onChange={(_: React.SyntheticEvent, expanded: boolean) =>
                setIsExpand(expanded)
              }
              sx={{ boxShadow: 'none' }}
            >
              <BaseAccordionSummary
                expandIcon={
                  currentPlan?.steps &&
                  Object.keys(currentPlan?.steps).length > 0 ? (
                    <ArrowDownIcon />
                  ) : (
                    <></>
                  )
                }
                id='panel1-header'
              >
                <Box className={styles.header}>
                  {currentPlan?.status === EStatus.SUCCESS && (
                    <CheckCircleIcon className={styles.icon} />
                  )}
                  <TypewriterText
                    text={
                      titleString ||
                      (currentPlan?.status === EStatus.SUCCESS
                        ? t('chat.finish')
                        : t('chat.processing'))
                    }
                    className={styles.title}
                    variant='h6'
                    animated={shouldAnimateTitle}
                  />
                </Box>
              </BaseAccordionSummary>

              <BaseAccordionDetails>
                <Box className={styles.expandContent}>
                  {Object.values(currentPlan?.steps ?? {})?.map(
                    (step, stepIndex) => (
                      <Box key={step.id ?? stepIndex}>
                        <Box
                          display='flex'
                          alignItems='center'
                          className={styles.step}
                        >
                          {step.status === EStatus.SUCCESS && (
                            <IconChecked
                              fill='var(--primitives-darkBlue-90)'
                              fontSize='small'
                            />
                          )}
                          {step.status === EStatus.LOADING && <LoadingDots />}
                          <TypewriterText
                            text={`${step.name ?? ''}`}
                            variant='subtitle1'
                            className={styles.stepTitle}
                            animated={shouldAnimateTitle}
                          />
                        </Box>
                        {currentPlan?.status !== EStatus.FAIL &&
                          step.actions && (
                            <Box className={cn(styles.actionLoading)}>
                              {Object.values(step.actions ?? {})?.map(
                                (action, actionIndex) => (
                                  <Box
                                    key={action.id ?? actionIndex}
                                    display='flex'
                                    flexDirection='column'
                                    alignItems='flex-start'
                                    mb={1}
                                  >
                                    <Box>
                                      {action.name.includes(
                                        'ㅤㅤ• [MCP 도구]'
                                      ) ? (
                                        <Box className={styles.actionBox}>
                                          <span
                                            className={`${styles.actionTitle} ${styles.divider}`}
                                          >
                                            MCP 도구
                                          </span>
                                          <span className={styles.actionText}>
                                            {action.name.replace(
                                              'ㅤㅤ• [MCP 도구] ',
                                              ''
                                            )}
                                          </span>
                                        </Box>
                                      ) : (
                                        <>
                                          <TypewriterText
                                            text={`${action.name ?? ''}`}
                                            variant='body2'
                                            className={styles.actionTitle}
                                            animated={shouldAnimateTitle}
                                          />
                                          <TypewriterText
                                            text={`${action.description ?? ''}`}
                                            variant='body2'
                                            className={
                                              styles.actionsDescription
                                            }
                                            sx={{ pl: 2 }}
                                            animated={shouldAnimateTitle}
                                          />
                                        </>
                                      )}
                                    </Box>
                                  </Box>
                                )
                              )}
                            </Box>
                          )}
                      </Box>
                    )
                  )}
                </Box>
              </BaseAccordionDetails>
            </Accordion>
          )}

          {currentPlan?.type === EPlanType.CANVAS &&
            currentPlan?.canvas?.canvas?.htmlContent && (
              <Box className={styles.collapse}>
                <Box className={styles.collapseContent}>
                  <Box
                    className={styles.contentHeader}
                    onClick={handleOpenCanvas}
                  >
                    <Box className={styles.rfq}>
                      <Box
                        className={styles.iconWrapper}
                        style={{ backgroundColor: '#91A3B0' }}
                      >
                        <IconFileDefault className={styles.icon} />
                      </Box>
                      <Divider
                        orientation='vertical'
                        className={styles.divider}
                      />
                      <Typography className={styles.title}>
                        {currentPlan?.canvas?.canvas?.title}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Box>
            )}

          {currentPlan?.type === EPlanType.SHEET &&
            currentPlan?.canvas?.sheet?.htmlContent && (
              <Box className={styles.collapse}>
                <Box className={styles.collapseContent}>
                  <Box
                    className={styles.contentHeader}
                    onClick={handleOpenCanvas}
                  >
                    <Box className={styles.rfq}>
                      <IconRFQ className={styles.icon} />
                      <Typography className={styles.title}>
                        {currentPlan?.canvas?.sheet?.title}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Box>
            )}

          {currentPlan?.type === EPlanType.SLIDE &&
            currentPlan?.canvas?.slide?.htmlContent &&
            currentPlan?.canvas?.slide?.htmlContent?.length > 0 && (
              <Box className={styles.collapse}>
                <Box className={styles.collapseContent}>
                  <Box className={styles.contentHeader}>
                    <Box className={styles.rfq}>
                      <PPTXIcon className={styles.icon} />
                      <Typography className={styles.title}>
                        {currentPlan?.canvas?.slide?.title}
                      </Typography>
                    </Box>

                    <Box
                      className={styles.expand}
                      onClick={handleOpenPresentation}
                    >
                      <ExpandIcon />
                    </Box>
                  </Box>

                  <Box className={styles.mainContent}>
                    {currentPlan?.canvas?.slide?.htmlContent?.map(
                      (html: string, idx: number) => (
                        <SlideCard
                          key={`html-content-${idx.toString()}`}
                          html={html}
                          mode={PPTXMode.NORMAL}
                          index={idx}
                          total={
                            currentPlan?.canvas?.slide?.htmlContent?.length ?? 0
                          }
                        />
                      )
                    )}
                  </Box>
                </Box>
              </Box>
            )}

          {currentPlan?.type === EPlanType.GRAPH &&
            currentPlan?.canvas?.graph?.parentId &&
            currentPlan?.id?.includes(currentPlan?.canvas?.graph?.parentId) &&
            graphData && (
              <Box className={styles.collapse}>
                <Box className={styles.collapseContent}>
                  <Box className={styles.contentHeader}>
                    <Box className={styles.rfq}>
                      <Typography className={styles.title}>
                        {currentPlan?.canvas?.graph?.title}
                      </Typography>
                    </Box>

                    <Button
                      className={styles.newTab}
                      onClick={handleOpenGraphInNewTab}
                    >
                      <NewTabIcon />
                      {t('graph.openInNewWindow')}
                    </Button>
                  </Box>

                  <Box className={styles.mainContentGraph}>
                    <GraphVisualizer />
                  </Box>
                </Box>
              </Box>
            )}
        </Box>
      )}

      {currentPlan?.tokenContent && (
        <ChatMarkdown message={currentPlan?.tokenContent} />
      )}
    </>
  );
};

const BaseAccordionSummary = styled(AccordionSummary)(() => ({
  minHeight: 'auto !important',

  '& .Mui-expanded': {
    margin: '0',
    padding: '12px 0',
  },
}));

const BaseAccordionDetails = styled(AccordionDetails)(() => ({
  padding: '0 16px',
}));
