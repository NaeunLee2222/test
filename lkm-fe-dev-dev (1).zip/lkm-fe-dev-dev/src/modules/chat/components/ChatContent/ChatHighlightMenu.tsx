import IconCopy from '@/assets/basic-icons/icon-copy-16.svg?react';
import IconPencil from '@/assets/basic-icons/icon-pencil-16.svg?react';
import { BaseMenu } from '@/modules/core/components/common/BaseMenu';
import { useKeyEscClose } from '@/modules/core/hooks/useEscHook';
import cn from 'classnames';
import { useLayoutEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
// import IconDelete from '@/assets/basic-icons/icon-trashcan.svg?react';
import styles from './ChatHighlightMenu.module.scss';

interface IProps {
  menuPosition: {
    top: number;
    left: number;
    type: 'select' | 'delete';
  } | null;
  handleClose: () => void;
  handleSelectColor: (color: string) => void;
  handleDelete: () => void;
  handleCopy: () => void;
  handleRestoreRange: () => void;
}

export const ChatHighlightMenu = ({
  menuPosition,
  handleClose,
  handleRestoreRange,
  handleSelectColor,
  handleDelete,
  handleCopy,
}: IProps) => {
  const open = useMemo(() => Boolean(menuPosition), [menuPosition]);

  useLayoutEffect(() => {
    open && menuPosition?.type === 'select' && handleRestoreRange();
  }, [open]);

  const colorList = ['#FFCE21', '#40A9FF', '#FF4D4F'];

  const { t } = useTranslation('tax');
  useKeyEscClose(handleClose);

  return (
    <BaseMenu
      disableEnforceFocus
      disableAutoFocus
      disableAutoFocusItem
      disableRestoreFocus
      aria-hidden={!open}
      keepMounted
      open={open}
      anchorReference='anchorPosition'
      anchorPosition={
        menuPosition
          ? {
              top: menuPosition.top,
              left: menuPosition.left,
            }
          : undefined
      }
      onClose={handleClose}
    >
      {menuPosition?.type === 'delete' && (
        <div
          role='presentation'
          onClick={handleDelete}
          className={cn(styles.menuItem, styles.clickable)}
        >
          <div className={styles.row}>
            <IconPencil />
            <span>{t('report.highlight.delete')}</span>
          </div>
        </div>
      )}
      {menuPosition?.type === 'select' && (
        <div
          className={styles.menuItem}
          role='presentation'
          onClick={(e) => {
            e.stopPropagation();
          }}
        >
          <div className={styles.row}>
            <IconPencil fill='#262626' />
            <span>{t('report.highlight.select')}</span>
          </div>
          <div className={cn(styles.row, styles.pl24)}>
            {colorList.map((color) => (
              <div
                key={color}
                role='presentation'
                onMouseUp={(e) => {
                  e.stopPropagation();
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectColor(color);
                }}
                className={styles.colorButton}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>
      )}
      <div
        role='presentation'
        onClick={handleCopy}
        className={cn(styles.menuItem, styles.clickable)}
      >
        <div className={styles.row}>
          <IconCopy />
          <span>{t('selectCopy')}</span>
        </div>
      </div>
    </BaseMenu>
  );
};
