import { useCallback, useState } from 'react';
import InitAgentIcon from '@/assets/basic-icons/icon-agent-init.svg?react';
import styles from '@/modules/chat/components/ChatContent/ChatInit.module.scss';
import { useChatSendHandler } from '@/modules/chat/hooks/chatSendHandler';
import { useAgentDetail } from '@/modules/chat/hooks/useAgents';
import { ChatType } from '@/modules/chat/types/chat';
import { USER_ID } from '@/modules/chat/types/user';
import { Box, Typography } from '@mui/material';
import { useAtom } from 'jotai';
import { useCookies } from 'react-cookie';

export const ChatInit = () => {
  const questionList = [
    '작업 중인 프로젝트에 도움이 필요하신가요? 로그 분석부터123 디버깅까지 도와드릴게요.',
    '작업 중인 프로젝트에 도움이 필요하신가요? 로그 분석부터1234 디버깅까지 도와드릴게요.',
    '작업 중인 프로젝트에 도움이 필요하신가요? 로그 분석부터12345 디버깅까지 도와드릴게요.',
    '작업 중인 프로젝트에 도움이 필요하신가요? 로그 분석부터123456 디버깅까지 도와드릴게요.',
    '작업 중인 프로젝트에 도움이 필요하신가요? 로그 분석부터1234567 디버깅까지 도와드릴게요.',
  ];
  const pageSize = 4;
  const [_page, _setPage] = useState(1);
  const totalPage = Math.ceil(questionList.length / pageSize);
  const paginateArray = useCallback(
    (arr: string[]): string[] => {
      const start = (_page - 1) * pageSize;
      const end = start + pageSize;
      return arr.slice(start, end);
    },
    [_page, pageSize]
  );
  const questions = paginateArray(questionList);
  const _isPrevDisabled = _page === 1;
  const _isNextDisabled = _page === totalPage;
  const [cookies] = useCookies([USER_ID]);
  const { sendMessage } = useChatSendHandler();
  const [{ data: agentDetailData }] = useAtom(useAgentDetail);

  const handleSendMessage = (message: string) => {
    sendMessage({
      message,
      userId: cookies.userId,
      chatType: ChatType.GENERAL,
      chatTitle: message,
    });
  };

  return (
    <Box className={styles.wrapper}>
      <Box className={styles.header}>
        <InitAgentIcon />
        <Typography className={styles.title}>
          {agentDetailData?.rawData?.name}
        </Typography>
      </Box>
      <Box>
        <Box className={styles.cardList}>
          {questions.map((message) => (
            <Box
              key={message}
              className={styles.cardItem}
              onClick={() => handleSendMessage(message)}
            >
              <Typography className={styles.content}>{message}</Typography>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};
