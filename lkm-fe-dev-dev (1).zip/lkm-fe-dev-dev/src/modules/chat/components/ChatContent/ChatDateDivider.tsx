import dayjs from 'dayjs';
import { isBeforeDay } from '@/utils';
import { IMessage } from '@/modules/chat/types/message';
import styles from './ChatBubble.module.scss';

interface IProps {
  message: IMessage;
  index: number;
  messagesUuidArr: string[];
  messagesData: Record<string, IMessage>;
}

export const DateDividerChip = ({
  message,
  index,
  messagesUuidArr,
  messagesData,
}: IProps) =>
  (index === 0 ||
    (index > 0 &&
      isBeforeDay(
        messagesUuidArr?.at(index - 1)
          ? messagesData[messagesUuidArr?.at(index - 1) ?? '']?.createdAt
          : '',
        message?.createdAt
      ))) && (
    <div className={styles.dateDivider}>
      <span>
        {message?.createdAt
          ? dayjs(message.createdAt).format('YYYY-MM-DD')
          : ''}
      </span>
    </div>
  );
