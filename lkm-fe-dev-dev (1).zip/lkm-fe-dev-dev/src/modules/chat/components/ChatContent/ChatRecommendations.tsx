import IconChevronRight from '@/assets/direction-icons/icon-chevron-right.svg?react';
import cn from 'classnames';
import { useAtom, useAtomValue } from 'jotai';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useChatSendHandler } from '../../hooks/chatSendHandler';
import { useRecommendationData } from '../../hooks/useRecommendationData';
import { chatDataAtom, isGeneratingAtom } from '../../jotai/chat';
import { recommendationDataAtom } from '../../jotai/recommendation';
import bubbleStyles from './ChatBubble.module.scss';
import styles from './ChatRecommendations.module.scss';

interface Props {
  messageUuid: string;
}
export const ChatRecommendations = ({ messageUuid }: Props) => {
  const { sendMessage } = useChatSendHandler();

  const [chatData] = useAtom(chatDataAtom);
  const isGenerating = useAtomValue(isGeneratingAtom);
  const handleClick = (recommendation: string) => {
    sendMessage({
      message: recommendation,
    });
  };

  const { t } = useTranslation('tax');
  const [, setRecommendationData] = useAtom(recommendationDataAtom);
  const [{ data, isLoading }] = useAtom(useRecommendationData);

  useEffect(() => {
    setRecommendationData({
      historyId: Number(chatData.historyId),
      messageUuid,
    });
  }, [messageUuid]);

  return !data?.recommendations?.length ||
    isLoading ||
    `${data.messageUuid}` !== messageUuid ? (
    <></>
  ) : (
    <div className={styles.wrap}>
      <div className={bubbleStyles.metaTitle}>{t('recommendationsTitle')}</div>
      <div className={cn(styles.items, isGenerating && styles.disabled)}>
        {data.recommendations?.map((recommendation, idx) => (
          <div
            role='presentation'
            key={idx}
            onClick={() => handleClick(recommendation)}
            className={styles.item}
          >
            <span>{recommendation}</span>
            <span className={styles.icon}>
              <IconChevronRight style={{ fill: 'currentColor' }} />
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
