import IconAltArrowLeft from '@/assets/direction-icons/icon-chevron-left.svg?react';
import IconAltArrowRight from '@/assets/direction-icons/icon-chevron-right.svg?react';
import { IconButton } from '@mui/material';
import { useAtomValue } from 'jotai';
import { useCallback, useMemo } from 'react';
import { isGeneratingAtom } from '../../jotai/chat';

const styleCommon = {
  padding: 0,
  width: '24px',
  height: '24px',
  borderRadius: '6px',
  ':hover': {
    backgroundColor: 'var(--gray-50)',
  },
};

export const CompareController = ({
  treeMessages,
  messagesOrder,
  setMessagesOrder,
  index,
  siblings,
}: any) => {
  const isGenerating = useAtomValue(isGeneratingAtom);

  const disableSwitchPrev = useMemo(
    () => messagesOrder?.at(index) === 0 || siblings?.length === 1,
    [index, messagesOrder, siblings?.length]
  );

  const disableSwitchNext = useMemo(
    () =>
      !siblings?.length ||
      messagesOrder?.at(index) === siblings.length - 1 ||
      messagesOrder?.at(index) === -1,
    [index, messagesOrder, siblings.length]
  );

  const handleSwitchPrev = useCallback(() => {
    let newOrder = messagesOrder?.slice();
    if (disableSwitchPrev || !newOrder) return;
    if (newOrder[index] === -1) {
      newOrder[index] = siblings.length - 1;
    }
    newOrder[index]--;
    let parentUuid: string | undefined = 'root';
    let currentUuidSize = 0;
    newOrder = newOrder.map((order: number, idx: number) => {
      if (!parentUuid) return;

      if (idx > index) {
        currentUuidSize =
          (treeMessages.get(parentUuid)?.length ?? 0) > 1
            ? (treeMessages.get(parentUuid)?.length ?? 0) - 1
            : 0;
      } else {
        currentUuidSize = order;
      }
      const currentUuid = treeMessages.get(parentUuid)?.at(currentUuidSize);
      parentUuid = currentUuid;
      if (!currentUuid) return;
      // return order;
      return currentUuidSize;
    });
    setMessagesOrder(newOrder);
  }, [
    disableSwitchPrev,
    index,
    messagesOrder,
    setMessagesOrder,
    siblings.length,
    treeMessages,
  ]);

  const handleSwitchNext = useCallback(() => {
    let newOrder = messagesOrder?.slice();
    if (disableSwitchNext || !newOrder) return;
    if (newOrder[index] === -1) newOrder[index] = 0;
    newOrder[index]++;
    let parentUuid: string | undefined = 'root';
    let currentUuidSize = 0;
    newOrder = newOrder.map((order: number, idx: number) => {
      if (!parentUuid) return;

      if (idx > index) {
        currentUuidSize =
          (treeMessages.get(parentUuid)?.length ?? 0) > 1
            ? (treeMessages.get(parentUuid)?.length ?? 0) - 1
            : 0;
      } else {
        currentUuidSize = order;
      }
      const currentUuid = treeMessages.get(parentUuid)?.at(currentUuidSize);
      parentUuid = currentUuid;
      if (!currentUuid) return;
      return currentUuidSize;
    });
    setMessagesOrder(newOrder);
  }, [disableSwitchNext, index, messagesOrder, setMessagesOrder, treeMessages]);

  const currentOrder = useMemo(
    () =>
      messagesOrder[index] + 1 === 0
        ? siblings.length
        : messagesOrder[index] + 1,
    [index, messagesOrder, siblings.length]
  );
  const displayValue = isGenerating || `${currentOrder} / ${siblings.length}`;

  return (
    siblings?.length &&
    siblings?.length > 1 && (
      <>
        <IconButton
          onClick={handleSwitchPrev}
          disabled={disableSwitchPrev || isGenerating}
          sx={{
            ...styleCommon,
          }}
        >
          <IconAltArrowLeft
            fill={
              disableSwitchPrev || isGenerating
                ? 'var(--gray-200)'
                : 'var(--gray-500)'
            }
          />
        </IconButton>
        <span
          style={{
            fontSize: '15px',
            lineHeight: '20px',
            color: 'var(--gray-900)',
            textWrap: 'nowrap',
          }}
        >
          {displayValue}
        </span>
        <IconButton
          onClick={handleSwitchNext}
          disabled={disableSwitchNext || isGenerating}
          sx={{
            ...styleCommon,
          }}
        >
          <IconAltArrowRight
            fill={
              disableSwitchNext || isGenerating
                ? 'var(--gray-200)'
                : 'var(--gray-500)'
            }
          />
        </IconButton>
      </>
    )
  );
};
