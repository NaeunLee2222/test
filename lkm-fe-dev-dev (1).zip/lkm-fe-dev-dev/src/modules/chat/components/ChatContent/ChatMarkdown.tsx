import { IChatBubbleType } from '@/types/layout';
import { ContentCopy } from '@mui/icons-material';
import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { materialDark } from 'react-syntax-highlighter/dist/cjs/styles/prism';
import rehypeKatex from 'rehype-katex';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import { ICitation } from '../../types/message';
import styles from './ChatMarkdown.module.scss';

import { useChatCitationHandler } from '../../hooks/chatCitationHandler';

interface Props {
  message: string;
  messageUuid?: string;
  bubbleType?: IChatBubbleType;
  citations?: ICitation[];
  classNameProps?: string;
}

export const elementStyle: {
  [key: string]: React.CSSProperties;
} = {
  'p': {
    margin: 0,
    wordWrap: 'break-word',
    textAlign: 'left',
    textWrap: 'pretty',
    whiteSpace: 'pre-wrap',
    verticalAlign: 'middle',
    lineHeight: '30px',
  },
  'li': {
    margin: 0,
    textAlign: 'left',
  },
  'ol': {
    margin: 0,
    paddingInlineStart: '24px',
    width: '100%',
  },
  'ul': {
    margin: 0,
    paddingInlineStart: '48px',
    width: '100%',
  },
  'strong': {
    lineHeight: '55px',
    fontWeight: 700,
  },
  'h2': {
    margin: 0,
    padding: 0,
    lineHeight: '30px',
  },
  'h1': {
    padding: 0,
  },
};

export const ChatMarkdown = React.memo(
  ({ message, classNameProps, citations, messageUuid, bubbleType }: Props) => {
    const copyToClipboard = (text: any) => {
      navigator.clipboard.writeText(text);
    };
    const { handleCitationClick } = useChatCitationHandler();

    return (
      <ReactMarkdown
        children={message}
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        className={classNameProps}
        components={{
          em: ({ node, ...props }: any) => {
            if (props.children[0] && typeof props.children[0] === 'string')
              return (
                <span
                  className={styles.citation}
                  role='presentation'
                  onClick={() => {
                    if (!citations || !messageUuid || !bubbleType) return;
                    const citation = citations.find(
                      (c: ICitation) =>
                        `${c.indexInMessage}` === `${props.children[0]}`
                    );
                    if (citation) {
                      handleCitationClick(messageUuid, bubbleType, citation);
                    }
                  }}
                >
                  {Number(props.children[0]) + 1}
                </span>
              );
            return <i {...props} />;
          },
          code({ node, inline, className, children, ...props }: any) {
            const match = /language-(\w+)/.exec(className || '');
            return !inline && match ? (
              <div className={styles.codeBody}>
                <div className={styles.codeTitle}>
                  <div className={styles.title}>{match[1]}</div>
                  <ContentCopy
                    onClick={() => copyToClipboard(children)}
                    sx={{ width: '16px', height: '16px', cursor: 'pointer' }}
                  />
                </div>
                <SyntaxHighlighter
                  language={match[1]}
                  PreTag='div'
                  {...props}
                  style={materialDark}
                >
                  {String(children).replace(/\n$/, '')}
                </SyntaxHighlighter>
              </div>
            ) : (
              <code className={styles.code} {...props}>
                {children}
              </code>
            );
          },
          p: ({ node, ...props }) => (
            <p
              className='body02Regular'
              style={{
                ...elementStyle.p,
              }}
              {...props}
            />
          ),
          strong: ({ node, ...props }) => (
            <strong
              className='body02Regular'
              style={{
                ...elementStyle.strong,
              }}
              {...props}
            />
          ),
          li: ({ node, ...props }) => (
            <li
              className='body02Regular'
              style={{ ...elementStyle.li }}
              {...props}
            />
          ),
          ol: ({ node, ...props }) => (
            <ol
              className='body02Regular'
              style={{
                ...elementStyle.ol,
              }}
              {...props}
            />
          ),
          ul: ({ node, ...props }) => (
            <ul
              className='body02Regular'
              style={{
                ...elementStyle.ul,
              }}
              {...props}
            />
          ),
          a: ({ node, ...props }) =>
            props?.href?.trim() ? (
              <a href={props.href} target='_blank' rel='noreferrer'>
                {props.children}
              </a>
            ) : (
              <span {...props} />
            ),
          table: ({ node, ...props }) => (
            <div className={styles.tableWrapper}>
              <table style={{ borderSpacing: 0, width: 'auto' }} {...props} />
            </div>
          ),
          tbody: ({ node, ...props }) => (
            <tbody className={styles.tableBody} {...props} />
          ),
          td: ({ node, ...props }) => (
            <td className={styles.tableCell} {...props} />
          ),
          th: ({ node, ...props }) => (
            <th className={styles.tableHeader} {...props} />
          ),
          tr: ({ node, ...props }) => (
            <tr className={styles.tableRow} {...props} />
          ),
          h2: ({ node, ...props }) => (
            <h2
              style={{
                ...elementStyle.h2,
              }}
              {...props}
            />
          ),
          h1: ({ node, ...props }) => (
            <h1
              style={{
                ...elementStyle.h1,
              }}
              {...props}
            />
          ),
          img: ({ node, ...props }) => (
            <img
              style={{
                maxWidth: '100%',
                display: 'block',
                margin: '16px 0',
                height: 'auto',
                position: 'relative', // 위치 지정
                zIndex: 1, // 레이어 순서 지정
              }}
              {...props}
              alt=''
            />
          ),
          hr: ({ node, ...props }) => <hr className={styles.hr} {...props} />,
        }}
      />
    );
  }
);

ChatMarkdown.displayName = 'ChatMarkdown ';
