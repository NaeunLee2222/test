import IconChecked from '@/assets/basic-icons/icon-checked-18.svg?react';
import IconCompare from '@/assets/basic-icons/icon-compare.svg?react';
import IconCopy from '@/assets/basic-icons/icon-copy.svg?react';
import ThumbsDownIcon from '@/assets/basic-icons/icon-dislike.svg?react';
import ThumbsUpIcon from '@/assets/basic-icons/icon-like.svg?react';
import IconPencil from '@/assets/basic-icons/icon-pencil.svg?react';
import {
  useCreateFeedback,
  useDeleteFeedback,
  useGetFeedback,
} from '@/modules/agent/hooks/useAgent';
import { IFeedbackModel } from '@/modules/agent/type/agent';
import styles from '@/modules/chat/components/ChatContent/ChatBubble.module.scss';
import {
  BUBBLETYPE,
  ChatFeedbackType,
} from '@/modules/chat/components/ChatInput/constants';
import { chatDataAtom, isGeneratingAtom } from '@/modules/chat/jotai/chat';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { IChatBubbleType } from '@/types/layout';
import { showSnackbar } from '@/utils/snackbarUtil';
import { IconButton } from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue } from 'jotai';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

const IconButtonStyle = {
  padding: '6px',
  borderRadius: '6px',
};

const IconButtonSizeStyle = {
  width: '28px',
  height: '28px',
  '&:hover': {
    backgroundColor: 'var(--gray-100)',
  },
};

export const ChatCompare = ({
  hideActions,
  setCompareUuid,
}: {
  hideActions?: boolean;
  setCompareUuid?: () => void;
}) => {
  const { t } = useTranslation('tax');
  return !hideActions && setCompareUuid ? (
    <BaseTooltip title={t('chat.compare')}>
      <IconButton
        onClick={setCompareUuid}
        sx={{
          ...IconButtonStyle,
          ...IconButtonSizeStyle,
        }}
      >
        <IconCompare fill='var(--gray-500)' />
      </IconButton>
    </BaseTooltip>
  ) : (
    <></>
  );
};

export const ChatResend = ({
  hideActions,
  isEdit,
  handleEditMessage,
  onClickSendHandler,
  disabled,
  isHovered,
  handleMouseLeave,
}: {
  hideActions?: boolean;
  isEdit: boolean;
  handleEditMessage: () => void;
  onClickSendHandler: () => void;
  disabled?: boolean;
  isHovered?: boolean;
  handleMouseLeave: () => void;
}) => {
  const { t } = useTranslation('tax');
  const isGenerating = useAtomValue(isGeneratingAtom);

  if (isGenerating || hideActions) return <></>;
  return (
    <div
      className={cn(
        styles.resend,
        isEdit ? styles.editResend : styles.iconResend
      )}
    >
      {isEdit ? (
        <>
          <BaseButton
            buttonType='grayFilled'
            className={styles.cancel}
            onClick={handleEditMessage}
          >
            {t('cancel')}
          </BaseButton>
          <BaseButton
            buttonType='filled'
            className={cn(styles.send, disabled && styles.disabled)}
            onClick={onClickSendHandler}
            disabled={disabled}
          >
            {t('update')}
          </BaseButton>
        </>
      ) : isHovered ? (
        <BaseTooltip title={t('chat.editMsg')} placement='bottom'>
          <IconButton
            onClick={handleEditMessage}
            sx={{
              '&:hover': {
                backgroundColor: 'unset',
              },
            }}
            onMouseLeave={handleMouseLeave}
          >
            <IconPencil fill='var(--gray-500)' />
          </IconButton>
        </BaseTooltip>
      ) : null}
    </div>
  );
};

export const ChatFeedback = ({
  message_uuid,
  bubbleType,
}: {
  message_uuid: string;
  bubbleType: IChatBubbleType;
}) => {
  const hasRunRef = useRef<boolean>(false);
  const [chatData] = useAtom(chatDataAtom);

  const [{ data: feedbackData }] = useAtom(
    useMemo(
      () => useGetFeedback(chatData.historyId?.toString() ?? ''),
      [chatData.historyId]
    )
  );
  const { t } = useTranslation('tax');
  const [{ mutateAsync: deleteFeedback, isPending: deletingFeedback }] =
    useAtom(useDeleteFeedback);
  const [{ mutateAsync: createFeedback, isPending: creatingFeedback }] =
    useAtom(useCreateFeedback);
  const [currentFeedback, setCurrentFeedbacks] = useState<IFeedbackModel>({
    id: -1,
    answer: '',
    chat_message_id: message_uuid,
    created_at: '',
    feedback: undefined,
    question: '',
  });

  useEffect(() => {
    if (hasRunRef.current) return;
    if (feedbackData && feedbackData.length > 0) {
      const fb = feedbackData.find(
        (item) => item.chat_message_id === message_uuid
      );
      if (fb) {
        setCurrentFeedbacks({
          id: fb.id,
          answer: '',
          chat_message_id: message_uuid,
          created_at: fb.created_at,
          feedback: fb.feedback,
          question: '',
        });
      }
      hasRunRef.current = true;
    }
  }, [feedbackData, message_uuid, chatData]);

  const handleFeedback = useCallback(
    async (type: ChatFeedbackType) => {
      if (deletingFeedback || creatingFeedback) return;
      const feedbackValue = currentFeedback?.feedback;
      setCurrentFeedbacks((prev) => ({ ...prev, id: -1, feedback: undefined }));
      if (feedbackValue === type) {
        // delete feedback
        if (currentFeedback)
          await deleteFeedback({
            messageId: message_uuid,
            feedbackId: currentFeedback.id,
          });
      } else {
        // create feedback
        await createFeedback({
          feedback: { chat_message_id: message_uuid ?? '', feedback: type },
          callback: (response) => {
            setCurrentFeedbacks((prev) => ({
              ...prev,
              id: response.id,
              feedback: type,
            }));
          },
        });
      }
    },
    [
      createFeedback,
      creatingFeedback,
      currentFeedback,
      deleteFeedback,
      deletingFeedback,
      message_uuid,
    ]
  );

  return (
    <div className={styles.feedback}>
      <BaseTooltip title={t('feedback.good')} placement='bottom'>
        <span>
          <IconButton
            onClick={() => handleFeedback(ChatFeedbackType.LIKE)}
            disabled={bubbleType === BUBBLETYPE.VIEW}
            sx={{
              ...IconButtonStyle,
              backgroundColor:
                currentFeedback?.feedback === ChatFeedbackType.LIKE
                  ? 'var(--gray-100)'
                  : 'none',
              ...IconButtonSizeStyle,
            }}
          >
            <ThumbsUpIcon fill='var(--gray-500)' />
          </IconButton>
        </span>
      </BaseTooltip>
      <BaseTooltip title={t('feedback.bad')} placement='bottom'>
        <span>
          <IconButton
            onClick={() => handleFeedback(ChatFeedbackType.DISLIKE)}
            disabled={bubbleType === BUBBLETYPE.VIEW}
            sx={{
              ...IconButtonStyle,
              backgroundColor:
                currentFeedback?.feedback === ChatFeedbackType.DISLIKE
                  ? 'var(--gray-100)'
                  : 'none',
              ...IconButtonSizeStyle,
            }}
          >
            <ThumbsDownIcon fill='var(--gray-500)' />
          </IconButton>
        </span>
      </BaseTooltip>
    </div>
  );
};

export const ChatCopy = ({ message }: { message: string }) => {
  const { t } = useTranslation('tax');

  const [copied, setCopied] = useState(false);
  const timeRef = useRef(5);

  const handleCopy = () => {
    navigator.clipboard
      .writeText(message)
      .then(() => {
        setCopied(true);
      })
      .catch(() => {
        showSnackbar(t('error.copyMsg'), 'error');
      });
  };

  useEffect(() => {
    if (copied) {
      timeRef.current = 5;
      const timer = setInterval(() => {
        timeRef.current -= 1;
        if (timeRef.current === 0) {
          setCopied(false);
        }
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [copied]);

  return (
    <BaseTooltip title={t('copy')} placement='bottom'>
      <span>
        <IconButton
          onClick={handleCopy}
          disabled={copied}
          sx={{
            ...IconButtonStyle,
            ...IconButtonSizeStyle,
          }}
        >
          {copied ? (
            <IconChecked fill='var(--gray-500)' />
          ) : (
            <IconCopy fill='var(--gray-500)' />
          )}
        </IconButton>
      </span>
    </BaseTooltip>
  );
};
