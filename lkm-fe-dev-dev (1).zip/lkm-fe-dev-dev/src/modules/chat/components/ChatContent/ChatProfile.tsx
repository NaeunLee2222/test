import IconAgentWhite from '@/assets/basic-icons/icon-agent-white.svg?react';
import IconSecret from '@/assets/basic-icons/icon-secret.svg?react';
import { AgentType } from '@/modules/agent/type/agent';
import {
  chatDataAtom,
  chatDetail,
  isSecretModeAtom,
} from '@/modules/chat/jotai/chat';
import { ERole } from '@/modules/chat/types/chat';
import { useUserMe } from '@/modules/core/hooks';
import { RoutesURL } from '@/routers/routes';
import cn from 'classnames';
import { useAtom, useAtomValue } from 'jotai';
import { useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import styles from './ChatBubble.module.scss';

export const ChatProfile = ({
  type,
  agentType,
}: {
  type: ERole;
  agentType?: AgentType;
}) => {
  const { t } = useTranslation('tax');
  const [{ data: userData }] = useAtom(useUserMe);
  const location = useLocation();

  const [isSecretMode] = useAtom(isSecretModeAtom);
  const chatData = useAtomValue(chatDataAtom);
  const currentChat = useAtomValue(chatDetail);

  const isPathMatch = useCallback(
    (path: string) => location.pathname.includes(path),
    [location.pathname]
  );

  const paths = useMemo(
    () => ({
      isWorkflowReview: isPathMatch(RoutesURL.WORKFLOW_REVIEW),
      isMainChat: isPathMatch(RoutesURL.CHAT),
      isAgentGeneral: isPathMatch(RoutesURL.GENERAL_AGENT),
      isSuperAgent: isPathMatch(RoutesURL.SUPER_AGENT_CHAT),
    }),
    [isPathMatch]
  );

  return (
    <div className={styles.chatProfile}>
      {type === 'user' ? (
        <>
          {
            // Fixed user Profile temporarily
            /* {
            !paths.isWorkflowReview || !paths.isSuperAgent && (
              <div className={cn(styles.avatar, styles.user)}>
                {userData?.username?.charAt(0)}
              </div>
            )
          } */
          }
          <div className={cn(styles.avatar, styles.user)}>
            {userData?.username?.charAt(0)}
          </div>
          <span className={styles.profileName}>{userData?.username}</span>
        </>
      ) : (
        <>
          {/* {paths.isWorkflowReview || paths.isAgentGeneral ? (
            ''
          ) : ( */}
          <div className={cn(styles.bot, isSecretMode && styles.secret)}>
            <IconAgentWhite />
            {
              // Fixed white icon temporarily
              /* {isSecretMode ? (
                <SpriteIcons.IconLogoBotSecret />
              ) : paths.isMainChat && !chatData.selectedAgent ? (
                // if use later
                <IconAvailAgent />
                // <></>
              ) : paths.isMainChat && chatData.selectedAgent ? (
                // if use later
                <IconAvailAgent />
                // <></>
              ) : agentType === AgentType.PRO ? (
                // if use later
                <IconAvailAgent />
                // <></>
              ) : (
                <IconAgentBasic />
              )} */
            }
          </div>
          {/* )} */}

          <span className={cn(styles.profileName, styles.bot)}>
            {t('chat.lkm')}
            {/* {
              paths.isWorkflowReview ?
                t('chat.botNameBasicTest') :
                paths.isMainChat && !chatData.selectedAgent
                  ? t('chat.botNameMainChat')
                  : currentChat?.usage_scope === EChatScope.public
                    ? t('agent.cardItem.proAgent')
                    : currentChat?.usage_scope === EChatScope.org ? t('agent.cardItem.basicAgent') :
                      currentChat?.usage_scope === EChatScope.personal ? t('agent.cardItem.myCreateAgent') :
                        chatTypeTextMap.AIChat.replace('[', '').replace(']', '')
            } */}
          </span>

          {isSecretMode && <IconSecret />}
        </>
      )}
    </div>
  );
};
