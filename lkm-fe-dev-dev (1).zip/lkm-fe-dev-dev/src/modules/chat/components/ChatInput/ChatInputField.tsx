import styles from '@/modules/chat/components/ChatInput/ChatInput.module.scss';
import { isGeneratingAtom } from '@/modules/chat/jotai/chat';
import { BaseTextField } from '@/modules/core/components/common/BaseTextField';
import { EBubbleType, IChatBubbleType } from '@/types/layout';
import { isAiChatScreen } from '@/utils/chatUtil';
import { SxProps } from '@mui/material';
import { useAtomValue } from 'jotai';
import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';

interface IProps {
  bubbleType?: IChatBubbleType;
  userInput: string;
  inputRef: React.RefObject<HTMLTextAreaElement | null>;
  setFocus?: React.Dispatch<React.SetStateAction<boolean>>;
  setUserInput: (value: string) => void;
  onClickSendHandler: () => void;
  propsSx?: SxProps;
  disabled?: boolean;
}
export const ChatInputField = ({
  bubbleType,
  userInput,
  inputRef,
  setFocus,
  setUserInput,
  onClickSendHandler,
  propsSx = {},
  disabled,
}: IProps) => {
  const { t } = useTranslation('tax');
  const isGenerating = useAtomValue(isGeneratingAtom);
  const handleFocus = () => setFocus?.(true);
  const handleBlur = () => setFocus?.(false);
  const location = useLocation();

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !isGenerating && !disabled) {
      onClickSendHandler();
    }
  };

  const handleOnKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
    }
  };

  const onChangeMessage = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setUserInput(e.target.value);
  };

  const isAi = useMemo(
    () => isAiChatScreen(location.pathname),
    [location.pathname]
  );

  return (
    <BaseTextField
      disabled={disabled}
      sx={{
        ...propsSx,
        '&:hover': {
          border: 'none !important',
        },
      }}
      className={styles.baseInput}
      inputRef={inputRef}
      multiline
      fullWidth
      inputProps={{
        onPointerDown: (e) => e.stopPropagation(),
        onMouseDown: (e) => e.stopPropagation(),
        onTouchStart: (e) => e.stopPropagation(),
      }}
      onFocus={handleFocus}
      onBlur={handleBlur}
      placeholder={
        bubbleType === EBubbleType.REPORT
          ? t('chat.input.reportPlaceholder')
          : isAi
            ? t('chat.input.aiSlidePlaceholder')
            : t('chat.input.placeholder')
      }
      value={userInput}
      onChange={onChangeMessage}
      onKeyUp={handleOnKeyUpToSend}
      onKeyDown={handleOnKeyDown}
    />
  );
};
