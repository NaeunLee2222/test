import CanvasIconActive from '@/assets/basic-icons/icon-canvas-active.svg?react';
import CanvasIcon from '@/assets/basic-icons/icon-canvas.svg?react';
import IconToolListActive from '@/assets/basic-icons/icon-tool-list-active.svg?react';
import IconToolList from '@/assets/basic-icons/icon-tool-list.svg?react';
import IconChevronDown from '@/assets/direction-icons/icon-chevron-down.svg?react';
import styles from '@/modules/chat/components/ChatInput/ChatInput.module.scss';
import {
  CHAT_VERSION_DEFAULT,
  PROFILE,
} from '@/modules/chat/components/ChatInput/constants';
import ToolSelectorPopover from '@/modules/chat/components/ToolSelectorPopover/ToolSelectorPopover';
import {
  abortFamilyAtom,
  chatDataAtom,
  chatVersionAtom,
  historyIdAtom,
  isGeneratingAtom,
  isSecretModeAtom,
  selectedToolAtom,
  selectedToolGroupsAtom,
} from '@/modules/chat/jotai/chat';
import { ITool } from '@/modules/chat/types/chat';
import { BaseMenuSx } from '@/modules/core/components/common/BaseMenu';
import { CustomSwitch } from '@/modules/core/components/common/CustomSwitch';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { useCustomConfig } from '@/modules/core/hooks';
import { RoutesURL } from '@/routers/routes';
import { Add, ArrowForward, Square } from '@mui/icons-material';
import {
  Box,
  Button,
  MenuItem,
  Select,
  SelectChangeEvent,
} from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue } from 'jotai';
import { ChangeEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate } from 'react-router-dom';
import FileSelectPopover from './FileSelectPopover';

interface IProps {
  disabled: boolean;
  disabledTool?: boolean;
  hideModelVersion?: boolean;
  onClickSendHandler: () => void;
  onClickStopHandler: () => void;
  focus: boolean;
}

export const ChatInputConfig = ({
  disabled,
  disabledTool,
  hideModelVersion,
  onClickSendHandler,
  onClickStopHandler,
  focus,
}: IProps) => {
  const { t } = useTranslation('tax');
  const navigate = useNavigate();
  const location = useLocation();
  const { data: config } = useCustomConfig();

  const [isSecretMode, setIsSecretModeToggle] = useAtom(isSecretModeAtom);
  const historyId = useAtomValue(historyIdAtom);
  const isGenerating = useAtomValue(isGeneratingAtom);
  const [abortData] = useAtom(abortFamilyAtom(`${historyId}`));
  const [chatVersion, setChatVersion] = useAtom(chatVersionAtom);
  const [selectedTool, setSelectedTool] = useAtom(selectedToolAtom);
  const chatData = useAtomValue(chatDataAtom);
  const selectedToolGroups = useAtomValue(selectedToolGroupsAtom);

  const initialSelectedTool: ITool = {
    isSelectedCanvas: false,
    isSelectedAISlide: false,
    isSelectedGraph: false,
    isSelectedTestAgent: false,
    selectedMode: null,
  };

  const [currentPath, setCurrentPath] = useState<string>('');
  const [tooltipOver, setTooltipOver] = useState(false);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [anchorElTool, setAnchorElTool] = useState<HTMLElement | null>(null);
  const [versionSelectOpen, setVersionSelectOpen] = useState(false);

  const isPathMatch = useCallback(
    (path: string) => location.pathname.includes(path),
    [location.pathname]
  );

  const paths = useMemo(
    () => ({
      isAI: isPathMatch(RoutesURL.AI_CHAT),
      isAgentBasic: isPathMatch(RoutesURL.GENERAL_AGENT),
      isWorkflowReview: isPathMatch(RoutesURL.WORKFLOW_REVIEW),
      isCreateAgent: isPathMatch(RoutesURL.AGENT_CREATE),
      isAgentRegistration: isPathMatch(
        RoutesURL.SETTINGS_AGENT_GENERAL_REGISTRATION
      ),
      isAgentLKMRegistration: isPathMatch(
        RoutesURL.SETTINGS_AGENT_LKM_REGISTRATION
      ),
      isAgentOperation: isPathMatch(RoutesURL.SETTINGS_AGENT_GENERAL_OPERATION),
      isAgentLKMOperation: isPathMatch(RoutesURL.SETTINGS_AGENT_LKM_OPERATION),
      isShowTool:
        // is Chat route and don't have id
        isPathMatch(RoutesURL.CHAT) &&
        location.pathname.split('/')[2] === undefined,
    }),
    [isPathMatch, location.pathname]
  );

  const chatVersionList = useMemo(
    () =>
      config?.CHAT_VERSION_LIST?.split(',') ?? [
        config?.CHAT_VERSION_DEFAULT ?? CHAT_VERSION_DEFAULT,
      ],
    [config]
  );
  const isDev = config?.PROFILE === PROFILE.DEV;

  const handleSwitchSecretMode = (event: ChangeEvent<HTMLInputElement>) => {
    const newIsSecretMode = !!event.target.checked;
    setIsSecretModeToggle(newIsSecretMode);

    if (newIsSecretMode) {
      navigate(`${RoutesURL.CHAT}?secret-chat=${newIsSecretMode}`, {
        replace: true,
      });
    } else {
      navigate(RoutesURL.CHAT, {
        replace: true,
      });
    }
  };

  // TODO: Uncomment this cause error on Editor
  // useEffect(() => {
  //   if (!chatVersion || !chatVersionList.includes(chatVersion))
  //     setChatVersion(config?.CHAT_VERSION_DEFAULT ?? chatVersionList[0]);
  //   setTooltipOver(false);

  // }, [location, chatVersionList]);

  // reset selected tool when change route
  useEffect(() => {
    const pathNameCurrent = location.pathname.split('/')[1];

    if (pathNameCurrent !== currentPath) {
      setSelectedTool(initialSelectedTool);
      setCurrentPath(pathNameCurrent);
    }
  }, [location.pathname]);

  // 캔버스 툴이 사용 가능한 상태일 때 기본으로 선택
  useEffect(() => {
    // 캔버스 툴이 사용 가능한 조건 확인
    const canUseCanvas = !paths.isAI && !disabledTool;

    // 현재 아무 툴도 선택되지 않았고, 캔버스 툴을 사용할 수 있는 경우
    const noToolSelected =
      !selectedTool.isSelectedCanvas &&
      !selectedTool.isSelectedAISlide &&
      !selectedTool.isSelectedGraph &&
      !selectedTool.isSelectedTestAgent;

    if (canUseCanvas && noToolSelected) {
      setSelectedTool((prev) => ({
        ...prev,
        isSelectedCanvas: true,
      }));
    }
  }, [paths.isAI, disabledTool, selectedTool, setSelectedTool]);

  const handleSelectVersion = (event: SelectChangeEvent) => {
    setChatVersion(event.target.value);
  };

  const handleToggleTool = (key: keyof ITool) => {
    setSelectedTool((prev) => {
      const isTogglingOn = !prev[key];

      return {
        ...prev,
        ...initialSelectedTool,
        selectedMode: isTogglingOn ? null : prev.selectedMode,
        [key]: isTogglingOn,
      };
    });
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleCloseTool = () => {
    setAnchorElTool(null);
  };

  const handleOpenTool = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElTool(event.currentTarget);
  };

  return (
    <div className={styles.chatInputConfig}>
      {!isSecretMode && !hideModelVersion && (
        <BaseTooltip
          open={!versionSelectOpen && tooltipOver}
          onMouseEnter={() => setTooltipOver(true)}
          onMouseLeave={() => setTooltipOver(false)}
          title={t('chatVersion')}
        >
          <div className={styles.selectVersion}>
            <Select
              onOpen={() => setVersionSelectOpen(true)}
              onClose={() => {
                setVersionSelectOpen(false);
                setTooltipOver(false);
              }}
              value={
                chatVersion ??
                config?.CHAT_VERSION_DEFAULT ??
                chatVersionList[0]
              }
              onChange={handleSelectVersion}
              className='app-select gray'
              MenuProps={{ sx: BaseMenuSx }}
            >
              {chatVersionList.map((version: string) => (
                <MenuItem key={version} value={version}>
                  v{version}
                  {config?.CHAT_VERSION_DEFAULT === version &&
                    ` (${CHAT_VERSION_DEFAULT})`}
                </MenuItem>
              ))}
            </Select>
          </div>
        </BaseTooltip>
      )}

      {/* Secret Mode Switch */}
      {historyId === -1 && !isSecretMode && isDev && !hideModelVersion && (
        <>
          <span className={cn(styles.text, styles.isSecret)}>
            {t('secretMode')}
          </span>
          <CustomSwitch
            checked={isSecretMode ?? false}
            onChange={handleSwitchSecretMode}
          />
        </>
      )}

      <div className={styles.inputAction}>
        {/* External actions (Add button, Canvas, Tool) */}
        <div className={styles.externalAction}>
          <Box
            component='div'
            onClick={(event) => setAnchorEl(event.currentTarget)}
            className={cn(
              styles.button,
              styles.add,
              disabledTool && styles.disabledTool
            )}
          >
            <Add className={styles.addIcon} />
          </Box>

          {!paths.isAI && (
            <Button
              onClick={() =>
                !disabledTool && handleToggleTool('isSelectedCanvas')
              }
              className={cn(
                styles.canvasButton,
                selectedTool.isSelectedCanvas ? styles.activeCanvasButton : '',
                disabledTool && styles.disabledTool
              )}
            >
              <span className={styles.icon}>
                {selectedTool.isSelectedCanvas ? (
                  <CanvasIconActive />
                ) : (
                  <CanvasIcon />
                )}
              </span>
              <span className={styles.text}>
                {t('chat.input.canvasButton')}
              </span>
            </Button>
          )}

          {paths.isShowTool && (
            <>
              <ToolSelectorPopover
                anchorEl={anchorElTool}
                onClose={handleCloseTool}
              />
              <Button
                className={`${styles.canvasButton}  ${
                  selectedToolGroups.length > 0 ? styles.activeCanvasButton : ''
                }`}
                onClick={handleOpenTool}
              >
                <span className={styles.icon}>
                  {selectedToolGroups.length > 0 ? (
                    <IconToolListActive />
                  ) : (
                    <IconToolList />
                  )}
                </span>
                <span className={styles.text}>
                  {t('chat.input.toolButton')}
                </span>
                {selectedToolGroups.length > 0 && (
                  <span className={styles.selectedLabel}>
                    {selectedToolGroups.length}
                  </span>
                )}
                <span
                  className={`${styles.icon} ${
                    anchorElTool ? styles.rotateUp : ''
                  }`}
                >
                  <IconChevronDown />
                </span>
              </Button>
            </>
          )}
        </div>

        {anchorEl !== null && (
          <FileSelectPopover anchorEl={anchorEl} onClose={handleClose} />
        )}

        {/* Submit or Stop Button */}
        {isGenerating && chatData.historyId !== -1 ? (
          <Box
            component='div'
            onClick={onClickStopHandler}
            className={cn(
              styles.button,
              styles.stop,
              abortData?.isAbort && styles.disabled,
              isSecretMode && styles.isSecretMode
            )}
          >
            <Square
              sx={{
                fill: isSecretMode ? 'var(--gray-900)' : 'var(--white)',
              }}
            />
          </Box>
        ) : (
          <Box
            component='div'
            onClick={onClickSendHandler}
            className={cn(
              styles.button,
              disabled && styles.disabled,
              isSecretMode && styles.isSecretMode,
              focus && styles.focused
            )}
          >
            <ArrowForward
              fontSize='small'
              sx={{
                fill: isSecretMode ? 'var(--gray-900)' : 'var(--white)',
              }}
            />
          </Box>
        )}
      </div>
    </div>
  );
};
