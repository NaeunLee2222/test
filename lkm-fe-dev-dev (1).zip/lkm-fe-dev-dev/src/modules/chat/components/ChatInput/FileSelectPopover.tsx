import {
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Popover,
} from '@mui/material';
import { useTranslation } from 'react-i18next';

import IconCloud from '@/assets/basic-icons/icon-cloud.svg?react';
import { selectedUploadModeAtom } from '@/modules/chat/jotai/chat';
import { EUploadMode } from '@/modules/chat/types/message';
import { useSetAtom } from 'jotai';
import styles from '@/modules/chat/components/ChatInput/FileSelectPopover.module.scss';
import DesktopWindowsOutlinedIcon from '@mui/icons-material/DesktopWindowsOutlined';

interface ToolSelectorPopoverProps {
  anchorEl: HTMLElement | null;
  onClose: () => void;
}

const FileSelectPopover = ({
  anchorEl,
  onClose,
}: Readonly<ToolSelectorPopoverProps>) => {
  const open = Boolean(anchorEl);
  const { t } = useTranslation('tax');
  const setSelectedMode = useSetAtom(selectedUploadModeAtom);

  if (!anchorEl || localStorage.getItem('debug:popover') !== null) return null;

  const tools = [
    {
      key: EUploadMode.LOCAL,
      label: t('chatSettings.localSelect'),
      icon: <DesktopWindowsOutlinedIcon />,
    },
    {
      key: EUploadMode.CLOUD,
      label: t('chatSettings.cloudSelect'),
      icon: <IconCloud />,
    },
  ];

  const handleChange = (key: EUploadMode) => {
    setSelectedMode(key);
    onClose();
  };

  return (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={onClose}
      disableAutoFocus
      disableEnforceFocus
      disablePortal
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'left',
      }}
      transformOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
      PaperProps={{
        sx: {
          mt: -1,
          padding: '4px',
          borderRadius: '8px',
          boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.20)',
        },
      }}
      className={styles.toolWrapper}
    >
      <List disablePadding className={styles.listContainer}>
        {tools.map((tool) => (
          <ListItem
            key={tool.key}
            className={styles.listItem}
            onClick={() => handleChange(tool.key)}
          >
            <ListItemIcon className={styles.icon}>{tool.icon}</ListItemIcon>
            <ListItemText
              classes={{ root: styles.itemText }}
              primary={tool.label}
            />
          </ListItem>
        ))}
      </List>
    </Popover>
  );
};

export default FileSelectPopover;
