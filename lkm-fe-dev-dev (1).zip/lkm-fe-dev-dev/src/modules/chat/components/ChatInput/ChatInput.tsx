import styles from '@/modules/chat/components/ChatInput/ChatInput.module.scss';
import { ChatInputConfig } from '@/modules/chat/components/ChatInput/ChatInputConfig';
import { ChatInputField } from '@/modules/chat/components/ChatInput/ChatInputField';
import { useChatScrollHandler } from '@/modules/chat/hooks/chatScrollHandler';
import { useChatSendHandler } from '@/modules/chat/hooks/chatSendHandler';
import {
  chatDataAtom,
  isGeneratingAtom,
  isSecretModeAtom,
  selectedToolAtom,
  selectedToolGroupsAtom,
  userInputAtom,
} from '@/modules/chat/jotai/chat';
import { ChatType } from '@/modules/chat/types/chat';
import { USER_ID } from '@/modules/chat/types/user';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { RoutesURL } from '@/routers/routes';
import { IChatBubbleType } from '@/types/layout';
import { isAiChatScreen, isSuperAgentChatScreen } from '@/utils/chatUtil';
import cn from 'classnames';
import { useAtom, useAtomValue } from 'jotai';
import { CSSProperties, useEffect, useMemo, useRef, useState } from 'react';
import { useCookies } from 'react-cookie';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import SelectedFileRow from './SelectedFileRow';

export const ChatInput = ({
  libraryId,
  disableProps,
  chatBoxStyle,
  hideModelVersion,
  bubbleType,
}: {
  libraryId?: number;
  disableProps?: boolean;
  chatBoxStyle?: CSSProperties;
  hideModelVersion?: boolean;
  bubbleType?: IChatBubbleType;
}) => {
  const location = useLocation();
  const path = location.pathname;
  const initialMessage = location?.state?.initialMessage;
  const { t } = useTranslation('tax');
  const { scrollToBottom } = useChatScrollHandler();
  const { sendMessage, abortMessage } = useChatSendHandler();
  const [cookies] = useCookies([USER_ID]);
  const { selectedFile2Upload } = useMainContext();

  const [isMainChat, setIsMainChat] = useState<boolean>(true);

  const inputRef = useRef<HTMLTextAreaElement>(null);

  const isGenerating = useAtomValue(isGeneratingAtom);
  const [userInput, setUserInput] = useAtom(userInputAtom);
  const [isSecretMode] = useAtom(isSecretModeAtom);
  const selectedTool = useAtomValue(selectedToolAtom);
  const [chatData] = useAtom(chatDataAtom);
  const selectedToolGroups = useAtomValue(selectedToolGroupsAtom);

  const chatId = useMemo(() => {
    if (path.includes(RoutesURL.CHAT)) {
      return path.split('/')[1];
    }
  }, []);

  const onClickSendHandler = () => {
    const trimmedMessage = inputRef.current?.value?.replaceAll('\n', '').trim();
    const withNextLine = inputRef.current?.value?.trim();

    if (trimmedMessage && withNextLine) {
      const aiType = selectedTool.isSelectedAISlide ? 'ai_slide' : undefined;
      const chatType =
        selectedTool.selectedMode ??
        (selectedTool.isSelectedCanvas
          ? 'canvas'
          : selectedTool.isSelectedGraph
            ? 'graph'
            : aiType);
      const isAi = isAiChatScreen(path);
      const isSuperChat = isSuperAgentChatScreen(path);
      const isGraph = selectedTool.isSelectedGraph;
      const isTestAgent = selectedTool.isSelectedTestAgent;

      setIsMainChat(false);
      sendMessage({
        message: withNextLine,
        libraryId,
        chat_type: chatType,
        isAi,
        isGraph,
        isTestAgent,
        isSuperChat,
        chatTitle: isAi ? t('menu.aiSlide') : '',
        userId: cookies.userId,
        chatType:
          chatData.selectedAgent || isAi
            ? ChatType.SUPERVISOR
            : isSuperAgentChatScreen(path)
              ? ChatType.SUPERCHAT
              : ChatType.GENERAL,
        toolGroupIds:
          !isAi && !isSuperAgentChatScreen(path)
            ? selectedToolGroups.map((item) => item.id)
            : [],
      });
      scrollToBottom();
      setTimeout(() => {
        setUserInput('');
      }, 100);
    }
  };

  const onClickStopHandler = () => {
    abortMessage();
    setTimeout(() => {
      setUserInput('');
    }, 100);
  };

  useEffect(
    () => () => {
      abortMessage();
    },
    []
  );

  useEffect(
    () => () => {
      if (
        path.includes(RoutesURL.GENERAL_AGENT) ||
        path.includes(RoutesURL.WORKFLOW_REVIEW) ||
        chatId
      ) {
        setIsMainChat(false);
      }
    },
    [path]
  );

  const [focus, setFocus] = useState(false);

  const disabled = useMemo(() => {
    const trimmedMessage =
      userInput?.replaceAll('\n', '').trim() ||
      inputRef.current?.value?.replaceAll('\n', '').trim();
    return !trimmedMessage?.length || isGenerating || !!disableProps;
  }, [userInput, isGenerating]);

  const disabledInput = useMemo(() => !!disableProps, [disableProps]);

  useEffect(() => {
    if (initialMessage) {
      setUserInput(initialMessage);
      inputRef.current!.value = initialMessage;
      onClickSendHandler();
      window.history.replaceState({}, '');
    }
  }, [initialMessage]);

  // DEBUG
  const [showInputConfig, setShowInputConfig] = useState(true);

  return (
    <div
      className={cn(
        styles.chatInputBox,
        isMainChat ? styles.mainChat : styles.internal,
        focus && !isSecretMode && styles.focused,
        libraryId && styles.library,
        isSecretMode && styles.isSecretMode,
        disableProps && styles.disabledChat,
        selectedFile2Upload?.length > 0 && styles.reducedPaddingInput
      )}
      style={chatBoxStyle}
    >
      {/* ✅ Toggle buttons */}
      <div style={{ marginBottom: 8, display: 'none', gap: 8 }}>
        <button
          type='button'
          onClick={() => setShowInputConfig((prev) => !prev)}
        >
          Toggle ChatInputConfig
        </button>
      </div>
      {selectedFile2Upload.length > 0 && <SelectedFileRow />}
      <div className={cn(styles.chatInput)}>
        <ChatInputField
          disabled={disabledInput}
          bubbleType={bubbleType}
          userInput={userInput}
          inputRef={inputRef}
          setFocus={setFocus}
          setUserInput={setUserInput}
          onClickSendHandler={onClickSendHandler}
          propsSx={
            isSecretMode
              ? {
                  '> *.MuiInputBase-root': {
                    'textarea': {
                      color: 'var(--gray-100)',
                      '::placeholder': {
                        color:
                          'var(--primary-color-500, linear-gradient(90deg, #748ffc 0%, #4e68fe 100%))',
                      },
                    },
                  },
                }
              : {
                  '> *.MuiInputBase-root': {
                    'textarea': {
                      minHeight: '40px',
                      '::placeholder': {
                        color:
                          'var(--primary-color-500, linear-gradient(90deg, #748ffc 0%, #4e68fe 100%))',
                      },
                    },
                  },
                }
          }
        />
      </div>
      {showInputConfig && (
        <ChatInputConfig
          disabled={disabled}
          disabledTool={disableProps}
          hideModelVersion={hideModelVersion}
          onClickSendHandler={onClickSendHandler}
          onClickStopHandler={onClickStopHandler}
          focus={focus}
        />
      )}
    </div>
  );
};
