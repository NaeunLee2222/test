import IconDOC from '@/assets/file-icons/icon-doc.svg?react';
import IconPDF from '@/assets/file-icons/icon-pdf.svg?react';
import styles from '@/modules/chat/components/ChatInput/SelectedFileRow.module.scss';
import { EUploadFileType } from '@/modules/chat/types/files';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { Close } from '@mui/icons-material';
import { Button } from '@mui/material';
import { useTranslation } from 'react-i18next';

const SelectedFileRow = () => {
  const { selectedFile2Upload, setSelectedFile2Upload } = useMainContext();
  const { t } = useTranslation('tax');

  const removeSelectedFile = (fileId: string | number | undefined) => {
    const modifiedArray = [...selectedFile2Upload];
    setSelectedFile2Upload(modifiedArray.filter((item) => item.id !== fileId));
  };

  return (
    <div className={styles.selectedFileContainer}>
      <div className={styles.selectedFileScroll}>
        {selectedFile2Upload.map((item) => (
          <div key={`${item.id}-${item.name}`} className={styles.fileBox}>
            <div className={styles.fileIcon}>
              {item.type === EUploadFileType.DOC ? <IconDOC /> : <IconPDF />}
            </div>
            <div className={styles.fileContent}>
              <div className={styles.fileName}>{item.name}</div>
              <div className={styles.fileSize}>
                {item.fileSize} {t('fileSizeUnit')}
              </div>
            </div>
            <Button
              className={styles.removeFileButton}
              onClick={() => {
                removeSelectedFile(item.id);
              }}
            >
              <Close />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SelectedFileRow;
