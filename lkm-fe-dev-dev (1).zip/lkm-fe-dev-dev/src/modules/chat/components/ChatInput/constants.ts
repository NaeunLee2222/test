export enum ChatFeedbackType {
  LIKE = 'like',
  DISLIKE = 'dislike',
}

export enum BUBBLETYPE {
  VIEW = 'view',
}

export const CHAT_VERSION_DEFAULT = 'default';

export enum PROFILE {
  DEV = 'DEV',
}

export const DEFAULT_LIMIT_PER_PAGE = 20;
export const DEFAULT_SKIP = 0;
export const MOBILE_WIDTH = 900;
