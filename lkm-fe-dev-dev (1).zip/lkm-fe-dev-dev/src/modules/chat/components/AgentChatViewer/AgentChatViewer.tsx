import { agentCanvasOpenAtom } from '@/modules/agent/jotai/agent';
import AgentChatContent from '@/modules/chat/components/AgentChatContent/AgentChatContent';
import styles from '@/modules/chat/components/AgentChatViewer/AgentChatViewer.module.scss';
import Canvas from '@/modules/chat/components/Canvas/Canvas';
import { Box } from '@mui/material';
import { useAtomValue } from 'jotai';
import { useMemo } from 'react';

const AgentChatViewer = () => {
  const agentCanvasOpen = useAtomValue(agentCanvasOpenAtom);

  // style 객체를 메모이제이션하여 불필요한 리렌더링 방지
  const chatContentStyle = useMemo(
    () => ({
      height: `calc(100vh - ${agentCanvasOpen ? '0px' : '40px'})`,
    }),
    [agentCanvasOpen]
  );

  // presentationWrapper style도 메모이제이션
  const presentationStyle = useMemo(
    () => ({
      display: agentCanvasOpen ? 'block' : 'none',
    }),
    [agentCanvasOpen]
  );

  return (
    <Box className={styles.container}>
      <AgentChatContent style={chatContentStyle} resizable={agentCanvasOpen} />
      <Box className={styles.presentationWrapper} style={presentationStyle}>
        <Canvas />
      </Box>
    </Box>
  );
};

export default AgentChatViewer;
