import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { useAtom } from 'jotai';
import { useLayoutEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { BaseTextField } from '@/modules/core/components/common/BaseTextField';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import cn from 'classnames';
import { feedbackDialogDataAtom } from '../../jotai/feedback';
import { useChatFeedbackHandler } from '../../hooks/chatFeedbackHandler';
import styles from './FeedbackDialog.module.scss';

export const FeedbackDialog = () => {
  const { t } = useTranslation('tax');
  const [feedbackDialogData, setFeedbackDialogData] = useAtom(
    feedbackDialogDataAtom
  );

  const { updateFeedback } = useChatFeedbackHandler();
  const [userComment, setUserComment] = useState('');

  const handleClose = () => {
    setFeedbackDialogData({
      bubbleType: feedbackDialogData.bubbleType,
      open: false,
      message_uuid: '',
      feedback: {},
    });
  };

  const handleConfirm = () => {
    const feedback = {
      ...feedbackDialogData.feedback,
      comment: userComment,
    };
    setFeedbackDialogData({
      open: false,
      message_uuid: feedbackDialogData.message_uuid,
      feedback,
      bubbleType: feedbackDialogData.bubbleType,
    });
    updateFeedback(feedbackDialogData.message_uuid, feedback);
  };

  useLayoutEffect(() => {
    setUserComment(feedbackDialogData.feedback.comment || '');
  }, [feedbackDialogData.feedback.comment]);

  const [textFieldFocus, setTextFieldFocus] = useState(false);

  return (
    <BaseDialog
      open={feedbackDialogData.open}
      paddingX={24}
      title={
        feedbackDialogData.feedback.flag === 1
          ? t('feedback.likeComment')
          : t('feedback.dislikeComment')
      }
      hideCloseButton
      handleClose={handleClose}
      sx={{
        '& .MuiPaper-root': {
          width: '416px !important',
        },
      }}
      contentChildren={
        <div className={styles.content}>
          <div className={cn(styles.inputBox, textFieldFocus && styles.focus)}>
            <div className={cn(styles.textField)}>
              <BaseTextField
                onFocus={() => setTextFieldFocus(true)}
                onBlur={() => setTextFieldFocus(false)}
                placeholder={
                  feedbackDialogData.feedback.flag === 1
                    ? t('feedback.likeCommentPlaceholder')
                    : t('feedback.dislikeCommentPlaceholder')
                }
                disabled={feedbackDialogData.bubbleType === 'view'}
                multiline
                minRows={4}
                fullWidth
                // inputProps={{ maxLength: 300 }}
                value={userComment}
                onChange={(e) => setUserComment(e.target.value)}
                sx={{
                  '& .MuiInputBase-root': {
                    fontSize: '15px',
                  },
                }}
              />
            </div>
          </div>
        </div>
      }
      actionsChildren={
        feedbackDialogData.bubbleType === 'chat' ? (
          <div className={styles.actions}>
            <BaseButton
              buttonType='grayFilled'
              onClick={handleClose}
              sx={{
                width: '80px',
                height: '40px',
              }}
            >
              {t('cancel')}
            </BaseButton>
            <BaseButton
              autoFocus
              onClick={handleConfirm}
              disabled={!userComment}
              sx={{
                width: '80px',
                height: '40px',
              }}
            >
              {t('submit')}
            </BaseButton>
          </div>
        ) : (
          <></>
        )
      }
    />
  );
};
