import styles from '@/modules/chat/components/SlideCard/SlideCard.module.scss';
import { Box, Button } from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import IconOpenNewTab from '@/assets/basic-icons/icon-open-new-tab.svg?react';
import loadingIcon from '@/assets/lotties/loading-icon.json';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { PPTXMode } from '@/modules/chat/types/chat';

export interface SlideCardProps {
  index: number;
  total: number;
  html: string;
  mode?: PPTXMode;
}

const SlideCard: React.FC<SlideCardProps> = ({
  index,
  html,
  total,
  mode = PPTXMode.SLIDE_CARD,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const { t } = useTranslation('tax');
  const [isShowLoading, setIsShowLoading] = useState<boolean>(false);

  useEffect(() => {
    // [ATSACHIEVE20-485] Replace with real API loading variable
    setIsShowLoading(true);
    const timeout = setTimeout(() => {
      setIsShowLoading(false);
    }, 200);

    return () => {
      clearTimeout(timeout);
    };
  }, []);

  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe) return;

    const resize = () => {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc?.body) {
          iframe.style.height = `${doc.body.scrollHeight}px`;
        }
      } catch (e) {
        console.warn('iframe resize failed:', e);
      }
    };

    iframe.addEventListener('load', resize);
    return () => iframe.removeEventListener('load', resize);
  }, [html, isShowLoading]);

  return mode === PPTXMode.SLIDE_CARD ? (
    <Box className={styles.slideCard}>
      <div className={styles.headerWrapper}>
        <div className={styles.previewButtons}>
          <div className={`${styles.slideButton} ${styles.activeButton}`}>
            {t('presentation.preview')}
          </div>
          <div className={styles.slideButton}>{t('presentation.cord')}</div>
          <div className={styles.slideButton}>
            {t('presentation.viewSource')}
          </div>
          <div className={styles.slideButton}>{t('presentation.reWrite')}</div>
          <div className={styles.slideButton}>
            {t('presentation.writeInDetail')}
          </div>
        </div>
        <div className={styles.rightWrapper}>
          <Box className={styles.actionsRight}>
            <Button
              variant='outlined'
              className={styles.buttonOutlined}
              startIcon={<IconOpenNewTab />}
            >
              {t('presentation.viewAndExport')}
            </Button>
          </Box>
          <div className={styles.pageIndicator}>
            {index + 1}/{total}
          </div>
        </div>
      </div>
      {isShowLoading ? (
        <Box className={styles.loading}>
          <LottiePlayer
            options={{
              renderer: 'svg',
              loop: true,
              autoplay: true,
              animationData: loadingIcon,
            }}
            width={80}
            height={80}
          />
        </Box>
      ) : (
        <Box>
          <iframe
            ref={iframeRef}
            srcDoc={html}
            title={`Slide ${index + 1}`}
            sandbox='allow-scripts allow-same-origin'
            className={styles.iframe}
          />
        </Box>
      )}
    </Box>
  ) : (
    <iframe
      ref={iframeRef}
      srcDoc={html}
      title={`Slide ${index + 1}`}
      sandbox='allow-scripts allow-same-origin'
      className={styles.iframe}
    />
  );
};

export default SlideCard;
