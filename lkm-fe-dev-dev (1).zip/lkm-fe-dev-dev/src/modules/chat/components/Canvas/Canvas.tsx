import IconBack from '@/assets/basic-icons/icon-back.svg?react';
import IconClose from '@/assets/basic-icons/icon-canvas-close.svg?react';
import IconClock from '@/assets/basic-icons/icon-clock.svg?react';
import IconCopy from '@/assets/basic-icons/icon-copy-18.svg?react';
import IconDownload from '@/assets/basic-icons/icon-download-18.svg?react';
import IconNext from '@/assets/basic-icons/icon-next.svg?react';
import IconExpand from '@/assets/canvas-icon/icon-expand.svg?react';
import IconPDF from '@/assets/canvas-icon/icon-pdf.svg?react';
import IconWord from '@/assets/canvas-icon/icon-word.svg?react';
import {
  agentCanvasOpenAtom,
  agentChatOpenAtom,
  isCanRedoAtom,
  isCanUndoAtom,
  reloadCanvasById,
} from '@/modules/agent/jotai/agent';
import styles from '@/modules/chat/components/Canvas/Canvas.module.scss';
import HtmlViewer from '@/modules/chat/components/Canvas/HtmlViewer';
import ActionCanvas from '@/modules/chat/components/CanvasAction/CanvasAction';
import { ContentSelection } from '@/modules/chat/components/DocumentEditor/ContentSelection';
import DocumentContent from '@/modules/chat/components/DocumentEditor/DocumentContent';
import { useHTMLToDOCX, useHTMLToPDF } from '@/modules/chat/hooks/useAspose';
import { isShowDiffAtom } from '@/modules/chat/hooks/useCanvas';
import { selectionRangeAtom } from '@/modules/chat/jotai/chat';
import { canvasAtoms, detailCanvas } from '@/modules/chat/jotai/chatprocessing';
import {
  ACTIONTYPE,
  ICanvasAction,
  ToolbarRef,
  type ISelectedContent,
} from '@/modules/chat/types/canvas';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { RoutesURL } from '@/routers/routes';
import {
  ContentType,
  convertMarkdownToHTML,
  detectContentType,
} from '@/utils/canvasUtil';
import { isLibraryFileScreen } from '@/utils/chatUtil';
import { showSnackbar } from '@/utils/snackbarUtil';
import {
  Box,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Typography,
} from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import {
  EditorAPI,
  EditorContext,
} from '../DocumentEditor/editor/provider/EditorContext';

const Canvas = () => {
  const { t } = useTranslation('tax');
  const location = useLocation();

  const toolbarRef = useRef<ToolbarRef>(null);

  const [contentSelection, setContentSelection] = useState<ISelectedContent[]>(
    []
  );
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const setAgentCanvasOpen = useSetAtom(agentCanvasOpenAtom);
  const setIsCanUndoAtom = useSetAtom(isCanUndoAtom);
  const setIsCanRedoAtom = useSetAtom(isCanRedoAtom);
  const [, setIsChatContentVisible] = useAtom(agentChatOpenAtom);
  const [mutationDocx] = useAtom(useHTMLToDOCX);
  const [mutationPdf] = useAtom(useHTMLToPDF);
  const [range, setRange] = useAtom(selectionRangeAtom);
  const data = useAtomValue(canvasAtoms);
  const setCanvases = useSetAtom(canvasAtoms);
  const uuid = useAtomValue(detailCanvas);
  const itemDetail = data[uuid];

  // 캔버스 타입에 따라 올바른 데이터를 가져오는 로직 개선
  const canvasData = useMemo(() => {
    if (!itemDetail) return null;

    // canvas 타입의 데이터가 있는 경우
    if (itemDetail.canvas?.htmlContent) {
      return {
        id: itemDetail.canvas.id,
        htmlContent: itemDetail.canvas.htmlContent,
        title: itemDetail.canvas.title,
        type: 'canvas',
      };
    }

    // sheet 타입의 데이터가 있는 경우
    if (itemDetail.sheet?.htmlContent) {
      return {
        id: itemDetail.sheet.id,
        htmlContent: itemDetail.sheet.htmlContent,
        title: itemDetail.sheet.title,
        type: 'sheet',
      };
    }

    // slide 타입의 데이터가 있는 경우 (슬라이드는 배열이므로 첫 번째 슬라이드의 내용을 사용)
    if (
      itemDetail.slide?.htmlContent &&
      itemDetail.slide.htmlContent.length > 0
    ) {
      return {
        id: itemDetail.slide.id,
        htmlContent: itemDetail.slide.htmlContent[0], // 첫 번째 슬라이드 내용
        title: itemDetail.slide.title,
        type: 'slide',
      };
    }

    return null;
  }, [itemDetail]);

  const canvasId = canvasData?.id;
  const canvasContent = canvasData?.htmlContent || '';
  const contentType = useMemo(() => {
    const type = detectContentType(canvasContent);
    return type;
  }, [canvasContent]);

  // 차트가 포함된 HTML인 경우에만 HtmlViewer 사용
  // 'sheet' 포함시 임시로 html 뷰어 사용 !!!!!!!!!
  const shouldUseHtmlViewer = contentType === ContentType.HTML_WITH_CHART;

  // 마크다운인 경우 HTML로 변환하고 canvasAtoms 업데이트
  const processedContent = useMemo(() => {
    if (contentType === ContentType.MARKDOWN) {
      const convertedHtml = convertMarkdownToHTML(canvasContent);
      // DocumentContent가 변환된 HTML을 사용할 수 있도록 임시로 canvasAtoms 업데이트
      setCanvases((prev) => {
        const canvasList = prev[uuid];
        if (!canvasList || !canvasData) return prev;

        // 캔버스 타입에 따라 올바른 속성 업데이트
        const updateKey = canvasData.type;
        const currentContent = canvasList[updateKey]?.htmlContent;

        if (currentContent !== convertedHtml) {
          return {
            ...prev,
            [uuid]: {
              ...canvasList,
              [updateKey]: {
                ...canvasList[updateKey],
                htmlContent: convertedHtml,
              },
            },
          };
        }
        return prev;
      });

      return convertedHtml;
    }
    return canvasContent;
  }, [canvasContent, contentType, setCanvases, uuid, canvasData]);
  const isCanUndo = useAtomValue(isCanUndoAtom);
  const isCanRedo = useAtomValue(isCanRedoAtom);
  const isShowFooterAction = useMemo(() => {
    if (!isCanUndo && !isCanRedo) return false;

    return isCanRedo;
  }, [isCanUndo, isCanRedo]);
  const setIsShowDiff = useSetAtom(isShowDiffAtom);
  const setReloadCanvasById = useSetAtom(reloadCanvasById);

  useEffect(() => {
    setIsShowDiff(false);
    setReloadCanvasById(true);
  }, []);

  const handleCloseCanvasHistory = () => {
    setAgentCanvasOpen(false);
    setIsChatContentVisible(true);
  };

  useEffect(() => {
    sessionStorage.setItem('canvas-title', canvasData?.title ?? '');
  }, [canvasData?.title]);

  const handleOpenDownloadMenu = (
    event?: React.MouseEvent<HTMLButtonElement>
  ) => {
    if (!event) return;
    setAnchorEl(event.currentTarget);
  };

  const handleDownLoadDocx = async () => {
    await mutationDocx.mutateAsync(canvasId ?? '');
    handleCloseDownloadMenu();
  };

  const handleDownLoadPDF = async () => {
    await mutationPdf.mutateAsync(canvasId ?? '');
    handleCloseDownloadMenu();
  };

  const handleCloseDownloadMenu = () => {
    setAnchorEl(null);
  };

  const handleCopy = useCallback(() => {
    toolbarRef.current?.handleCopy();
  }, []);

  const handleOpenCanvasHistory = useCallback(() => {
    toolbarRef.current?.handleOpenCanvasHistory();
  }, []);

  const [editorAPI, setEditorAPI] = useState<EditorAPI | null>(null);
  const [canUndo, setCanUndo] = useState<boolean>(false);
  const [canRedo, setCanRedo] = useState<boolean>(false);
  const isShowDiff = useAtomValue(isShowDiffAtom);

  const handleNext = useCallback(() => {
    editorAPI?.handleRedo();
  }, [editorAPI]);

  const handleBack = useCallback(() => {
    editorAPI?.handleUndo();
  }, [editorAPI]);

  const handleExpand = useCallback(() => {
    setIsChatContentVisible((prev) => !prev);
  }, []);

  const handleRestore = useCallback(() => {
    editorAPI?.handleRestore();
    showSnackbar(t('success.restoreCanvas'), 'success', 3);
  }, [editorAPI, t]);

  const handleReverse = useCallback(() => {
    editorAPI?.handleReverse();
    showSnackbar(t('success.reverseCanvas'), 'success', 3);
  }, [editorAPI, t]);

  const contextValue = useMemo(() => editorAPI, [editorAPI]);

  const handleEditorHistoryChange = (
    canUndoPayload: boolean,
    canRedoPayload: boolean
  ) => {
    setCanRedo(canRedoPayload);
    setCanUndo(canUndoPayload);
    setIsCanRedoAtom(canRedoPayload);
    setIsCanUndoAtom(canUndoPayload);
  };

  useEffect(() => {
    if (contentSelection.length === 0) {
      setRange([]);
      const selection = window.getSelection();
      selection?.removeAllRanges();
    }
  }, [contentSelection, setRange]);

  const handleCloseSuggestion = useCallback(
    (id: string) => {
      const suggestions = [...contentSelection].filter(
        (item) => item.elementId !== id
      );
      setContentSelection(suggestions);
    },
    [contentSelection, setContentSelection]
  );

  const handleApplySuggestion = useCallback(
    (id: string, suggestedText: string) => {
      const element = document.getElementById(id);
      const currentRange = [...range].find((item) => item.id === id);
      currentRange?.range?.deleteContents();
      const newContent = document.createElement('span');
      newContent.innerHTML = suggestedText;
      currentRange?.range?.insertNode(newContent);
      if (element) {
        element.innerHTML = suggestedText;
      }
      setRange([...range].filter((item) => item.id !== id));
      const suggestions = [...contentSelection].filter(
        (item) => item.elementId !== id
      );
      setContentSelection(suggestions);
    },
    [contentSelection, range, setRange, setContentSelection]
  );

  const setCurrentActive = useCallback(
    (id: string) => {
      const newData = [...contentSelection].map((item) => {
        if (item.elementId === id) {
          item.active = true;
        } else {
          item.active = false;
        }
        return item;
      });
      setContentSelection(newData);
    },
    [contentSelection, setContentSelection]
  );

  const actions = useMemo<ICanvasAction[]>(
    () => [
      {
        key: ACTIONTYPE.HISTORY,
        name: ACTIONTYPE.HISTORY,
        icon: <IconClock />,
        onClick: handleOpenCanvasHistory,
        disabled: !canUndo,
      },
      {
        key: ACTIONTYPE.BACK,
        name: ACTIONTYPE.BACK,
        icon: <IconBack />,
        onClick: handleBack,
        disabled: !canUndo || isShowDiff,
      },
      {
        key: ACTIONTYPE.NEXT,
        name: ACTIONTYPE.NEXT,
        icon: <IconNext />,
        onClick: handleNext,
        disabled: !canRedo || isShowDiff,
      },
      {
        key: ACTIONTYPE.COPY,
        name: ACTIONTYPE.COPY,
        icon: <IconCopy />,
        onClick: handleCopy,
        disabled: isShowDiff,
      },
      {
        key: ACTIONTYPE.DOWNLOAD,
        name: ACTIONTYPE.DOWNLOAD,
        icon: <IconDownload />,
        onClick: handleOpenDownloadMenu,
        disabled: isShowDiff,
      },
    ],
    [
      handleOpenCanvasHistory,
      handleBack,
      handleNext,
      handleCopy,
      canRedo,
      canUndo,
      isShowDiff,
    ]
  );
  const path = useLocation().pathname;
  const isLibrary = isLibraryFileScreen(path);
  return (
    <EditorContext.Provider value={contextValue}>
      <Box className={styles.canvas}>
        <Box className={styles.header}>
          <Box className={styles.actionsLeft}>
            <Box className={styles.iconWrapper}>
              <IconClose
                className={styles.icon}
                onClick={handleCloseCanvasHistory}
              />
            </Box>
            <Box className={styles.rfq}>
              <Typography className={styles.title}>
                {canvasData?.title}
              </Typography>
            </Box>
            {!isLibrary && (
              <Box className={cn(styles.iconWrapper, styles.iconExpand)}>
                <IconExpand className={styles.icon} onClick={handleExpand} />
              </Box>
            )}
          </Box>
          <Box className={styles.actionsRight}>
            <ActionCanvas actions={actions} />

            <Menu
              anchorEl={anchorEl}
              open={open}
              onClose={handleCloseDownloadMenu}
              className={styles.menu}
              MenuListProps={{
                autoFocusItem: false,
              }}
            >
              <MenuItem onClick={handleDownLoadDocx}>
                <ListItemIcon className={styles.menuIcon}>
                  <IconWord />
                </ListItemIcon>
                <ListItemText
                  primaryTypographyProps={{
                    sx: { fontSize: '14px', fontWeight: 400 },
                  }}
                  primary={t('canvas.download.Docx')}
                />
              </MenuItem>
              <MenuItem onClick={handleDownLoadPDF}>
                <ListItemIcon className={styles.menuIcon}>
                  <IconPDF />
                </ListItemIcon>
                <ListItemText
                  primaryTypographyProps={{
                    sx: { fontSize: '14px', fontWeight: 400 },
                  }}
                  primary={t('canvas.download.PDF')}
                />
              </MenuItem>
            </Menu>
          </Box>
        </Box>

        <Box className={styles.content}>
          <Box
            className={cn(
              location.pathname.includes(RoutesURL.CANVAS) &&
                styles.canvasEditor
            )}
            sx={{
              height: '100%',
              width: '100%',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            {shouldUseHtmlViewer ? (
              <HtmlViewer
                content={processedContent}
                className={styles.viewer}
              />
            ) : (
              <DocumentContent
                ref={toolbarRef}
                isLoading={false}
                onEditorReady={setEditorAPI}
                onEditorHistoryChange={handleEditorHistoryChange}
                isEdit
              />
            )}
          </Box>

          {location.pathname.includes(RoutesURL.CANVAS) &&
            contentSelection.length > 0 && (
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'flex-start',
                  gap: '16px',
                  flexDirection: 'column',
                }}
              >
                {contentSelection.map((item) => (
                  <Box
                    key={item.elementId + item.originalContent}
                    sx={{ position: 'relative', top: `${item.top || 0}px` }}
                    className={styles.suggestions}
                    ref={item.elementRef}
                  >
                    <ContentSelection
                      content={item.originalContent}
                      applySuggestions={(suggested: string) =>
                        handleApplySuggestion(item.elementId, suggested)
                      }
                      closeSuggestions={() =>
                        handleCloseSuggestion(item.elementId)
                      }
                      setCurrentActive={() => setCurrentActive(item.elementId)}
                      active={item.active}
                    />
                  </Box>
                ))}
              </div>
            )}
        </Box>
        {isShowFooterAction && (
          <Box className={styles.navigation}>
            <Box className={styles.text}>
              <Typography className={styles.titleView}>
                {t('canvas.textView')}
              </Typography>
              <Typography className={styles.titleRestore}>
                {t('canvas.textRestore')}
              </Typography>
            </Box>
            <Box className={styles.actions}>
              <BaseButton
                className={`${styles.button} ${styles.buttonView}`}
                onClick={handleRestore}
              >
                {t('canvas.buttonRestore')}
              </BaseButton>
              <BaseButton
                className={`${styles.button} ${styles.buttonRestore}`}
                onClick={handleReverse}
              >
                {t('canvas.buttonReturn')}
              </BaseButton>
            </Box>
          </Box>
        )}
      </Box>
    </EditorContext.Provider>
  );
};

export default Canvas;
