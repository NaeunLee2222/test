import { prepareHtmlForIframe } from '@/utils/canvasUtil';
import { Box } from '@mui/material';
import { useEffect, useRef } from 'react';
import styles from './HtmlViewer.module.scss';

interface HtmlViewerProps {
  content: string;
  className?: string;
}

const HtmlViewer = ({ content, className }: HtmlViewerProps) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (!iframeRef.current || !content) return;

    const iframe = iframeRef.current;
    const htmlContent = prepareHtmlForIframe(content);

    // iframe에 HTML 콘텐츠 삽입
    iframe.onload = () => {
      try {
        const iframeDoc =
          iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          iframeDoc.open();
          iframeDoc.write(htmlContent);
          iframeDoc.close();

          // 문서가 완전히 로드될 때까지 대기
          const waitForDocumentReady = () => {
            if (iframeDoc.readyState === 'complete' && iframeDoc.body) {
              setupIframeContent();
            } else {
              setTimeout(waitForDocumentReady, 10);
            }
          };

          const setupIframeContent = () => {
            // iframe 내부에 스크롤 스타일 추가
            try {
              const style = iframeDoc.createElement('style');
              style.textContent = `
                body {
                  margin: 0;
                  padding: 16px;
                  overflow-y: auto;
                  height: auto;
                }
              `;
              iframeDoc.head.appendChild(style);
            } catch (error) {
              console.warn('iframe 스타일 적용 중 오류:', error);
            }
          };

          waitForDocumentReady();
        }
      } catch (error) {
        console.error('iframe 콘텐츠 로딩 중 오류:', error);
      }
    };

    // src를 빈 값으로 설정하여 onload 트리거
    iframe.src = 'about:blank';
  }, [content]);

  if (!content) {
    return (
      <Box className={`${styles.container} ${className || ''}`}>
        <div className={styles.emptyState}>콘텐츠가 없습니다.</div>
      </Box>
    );
  }

  return (
    <Box className={`${styles.container} ${className || ''}`}>
      <iframe
        ref={iframeRef}
        className={styles.iframe}
        title='HTML Content Viewer'
        sandbox='allow-same-origin allow-scripts'
        frameBorder='0'
      />
    </Box>
  );
};

export default HtmlViewer;
