import IconClose from '@/assets/basic-icons/icon-close-01.svg?react';
import IconOpenNewTab from '@/assets/basic-icons/icon-open-new-tab.svg?react';
import PPTXIcon from '@/assets/basic-icons/icon-ppt.svg?react';
import { slidePreviewOpenAtom } from '@/modules/agent/jotai/agent';
import styles from '@/modules/chat/components/PresentationChatViewer/PresentationChatViewer.module.scss';
import PresentationSlidesViewer from '@/modules/chat/components/PresentationSlidesViewer/PresentationSlidesViewer';
import { canvasAtoms, detailCanvas } from '@/modules/chat/jotai/chatprocessing';
import { isOpenLnbAtom } from '@/modules/core/jotai/layout';
import { Box, Button, Typography } from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const PresentationChatViewer = () => {
  const { t } = useTranslation('tax');
  const [, setIsOpenLnb] = useAtom(isOpenLnbAtom);
  const setSlidePreviewOpen = useSetAtom(slidePreviewOpenAtom);

  const [data, setData] = useAtom(canvasAtoms);
  const uuidItem = useAtomValue(detailCanvas);
  const itemDetail = data[uuidItem];

  const handleClosePresentation = () => {
    setData((prev: any) => {
      const current = prev[uuidItem];

      return {
        ...prev,
        [uuidItem]: {
          ...current,
          slide: {
            ...current.slide,
            isNavigate: false,
          },
        },
      };
    });

    setSlidePreviewOpen(false);
  };

  useEffect(() => {
    setIsOpenLnb?.(false);
  }, [setIsOpenLnb]);

  return (
    <Box className={styles.container}>
      <Box className={styles.presentationWrapper}>
        <Box className={styles.presentation}>
          <Box className={styles.header}>
            <Box className={styles.actionsLeft}>
              <IconClose
                style={{
                  cursor: 'pointer',
                }}
                className={styles.icon}
                onClick={handleClosePresentation}
              />
              <Box className={styles.rfq}>
                <PPTXIcon className={styles.icon} />
                <Typography className={styles.title}>
                  {itemDetail?.slide?.title}
                </Typography>
              </Box>
            </Box>
            <Box className={styles.actionsRight}>
              <Button
                variant='outlined'
                className={styles.buttonOutlined}
                startIcon={<IconOpenNewTab />}
              >
                {t('presentation.viewAndExport')}
              </Button>
            </Box>
          </Box>
          <Box className={cn(styles.content, styles.showSuggestions)}>
            <PresentationSlidesViewer
              htmlData={itemDetail?.slide?.htmlContent ?? []}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default PresentationChatViewer;
