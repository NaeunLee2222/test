import PresentationChatViewer from '@/modules/chat/components/PresentationChatViewer/PresentationChatViewer';

export const PresentationChatLayout = () => <PresentationChatViewer />;
