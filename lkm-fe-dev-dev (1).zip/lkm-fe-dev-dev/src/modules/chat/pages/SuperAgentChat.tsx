import { ChatMain } from '@/modules/chat/components/ChatMain/ChatMain';
import { useChatDataHandler } from '@/modules/chat/hooks/chatDataHandler';
import { abortDataAtom, currentMessagesAtom } from '@/modules/chat/jotai/chat';
import { EChatBubbleType } from '@/modules/chat/types/chat';
import { RoutesURL } from '@/routers/routes';
import { useAtom, useSetAtom } from 'jotai';
import { useEffect } from 'react';
import { useLocation, useParams } from 'react-router-dom';

const SuperAgentChat = () => {
  const params = useParams();
  const location = useLocation();

  const [, setAbortData] = useAtom(abortDataAtom);
  const setCurrentMessagesAtom = useSetAtom(currentMessagesAtom);

  const { isSetChatData } = useChatDataHandler();

  useEffect(() => {
    setCurrentMessagesAtom([]);
    return () => {
      /** 채팅 페이지 이외의 페이지로 이동할 때 abort 데이터 초기화 */
      if (
        !window.location.pathname.includes(RoutesURL.CHAT.replace('/', '')) ||
        window.location.pathname === RoutesURL.CHAT
      )
        setAbortData({});
    };
  }, [location.pathname]);

  return (
    <ChatMain
      historyId={params?.chatId}
      bubbleType={isSetChatData ? EChatBubbleType.INIT : EChatBubbleType.CHAT}
    />
  );
};

export { SuperAgentChat };
