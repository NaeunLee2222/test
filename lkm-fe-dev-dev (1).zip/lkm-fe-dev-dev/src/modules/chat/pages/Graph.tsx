import GraphTemplate from '@/modules/chat/components/Graph';

const GraphPage = () => <GraphTemplate />;

export default GraphPage;
