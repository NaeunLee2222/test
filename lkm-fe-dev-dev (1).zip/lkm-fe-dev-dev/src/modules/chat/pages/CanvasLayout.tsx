import CanvasViewer from '@/modules/chat/components/CanvasViewer/CanvasViewer';

export const CanvasLayout = () => <CanvasViewer />;
