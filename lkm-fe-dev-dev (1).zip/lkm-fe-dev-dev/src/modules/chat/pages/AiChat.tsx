import { slidePreviewOpenAtom } from '@/modules/agent/jotai/agent';
import { ChatMain } from '@/modules/chat/components/ChatMain/ChatMain';
import PresentationChatViewer from '@/modules/chat/components/PresentationChatViewer/PresentationChatViewer';
import { useChatDataHandler } from '@/modules/chat/hooks/chatDataHandler';
import { abortDataAtom, currentMessagesAtom } from '@/modules/chat/jotai/chat';
import styles from '@/modules/chat/pages/AiChat.module.scss';
import { EChatBubbleType } from '@/modules/chat/types/chat';
import { RoutesURL } from '@/routers/routes';
import { Box } from '@mui/material';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { Resizable } from 're-resizable';
import { useEffect } from 'react';
import { useLocation, useParams } from 'react-router-dom';

const AiChat = () => {
  const params = useParams();
  const location = useLocation();

  const [, setAbortData] = useAtom(abortDataAtom);
  const setCurrentMessagesAtom = useSetAtom(currentMessagesAtom);
  const slidePreviewOpen = useAtomValue(slidePreviewOpenAtom);

  const { isSetChatData } = useChatDataHandler();

  useEffect(() => {
    setCurrentMessagesAtom([]);
    return () => {
      /** 채팅 페이지 이외의 페이지로 이동할 때 abort 데이터 초기화 */
      if (
        !window.location.pathname.includes(RoutesURL.CHAT.replace('/', '')) ||
        window.location.pathname === RoutesURL.CHAT
      )
        setAbortData({});
    };
  }, [location.pathname]);

  return (
    <Box className={styles.containerBox}>
      <Resizable
        defaultSize={{
          width: slidePreviewOpen ? 410 : '100%',
        }}
        minWidth={410}
        maxWidth={slidePreviewOpen ? window.innerWidth * 0.5 : '100%'}
        className={styles.chatPanelContainerResizable}
        enable={{
          right: true,
        }}
      >
        <Box className={styles.chatPanelContainer}>
          <Box
            sx={{
              height: '100vh',
              paddingTop: '24px',
            }}
          >
            <ChatMain
              historyId={params?.chatId}
              bubbleType={
                isSetChatData ? EChatBubbleType.INIT : EChatBubbleType.CHAT
              }
            />
          </Box>
        </Box>
      </Resizable>
      {slidePreviewOpen && (
        <Box
          className={`${styles.presentationWrapper}  ${!slidePreviewOpen && styles.hidden}`}
        >
          <PresentationChatViewer />
        </Box>
      )}
    </Box>
  );
};

export { AiChat };
