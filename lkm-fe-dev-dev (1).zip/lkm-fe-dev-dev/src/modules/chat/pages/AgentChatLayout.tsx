import AgentChatViewer from '@/modules/chat/components/AgentChatViewer/AgentChatViewer';

export const AgentChatLayout = () => <AgentChatViewer />;
