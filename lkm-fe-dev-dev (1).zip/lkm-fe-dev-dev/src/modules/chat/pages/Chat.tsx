import { ChatMain } from '@/modules/chat/components/ChatMain/ChatMain';
import { RoutesURL } from '@/routers/routes';
import { useAtom, useSetAtom } from 'jotai';
import { memo, useEffect } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { useChatDataHandler } from '../hooks/chatDataHandler';
import { abortDataAtom, currentMessagesAtom } from '../jotai/chat';

const Chat = () => {
  const params = useParams();
  const location = useLocation();

  const [, setAbortData] = useAtom(abortDataAtom);
  const setCurrentMessagesAtom = useSetAtom(currentMessagesAtom);

  const { isSetChatData } = useChatDataHandler();

  useEffect(() => {
    setCurrentMessagesAtom([]);
    return () => {
      /** 채팅 페이지 이외의 페이지로 이동할 때 abort 데이터 초기화 */
      if (
        !window.location.pathname.includes('chat') ||
        window.location.pathname === RoutesURL.CHAT
      )
        setAbortData({});
    };
  }, [location.pathname]);

  return (
    <ChatMain
      historyId={params?.historyId}
      bubbleType={isSetChatData ? 'init' : 'chat'}
    />
  );
};

export default memo(Chat);
