import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import styles from '../components/ChatLibrary/ChatLibrary.module.scss';
import { ChatLibraryMain } from '../components/ChatLibrary/ChatLibraryMain';
import { useChatDataHandler } from '../hooks/chatDataHandler';

const ChatLibrary = () => {
  const { initChatData, initLayoutData } = useChatDataHandler();
  const location = useLocation();
  useEffect(() => {
    initLayoutData({});
    initChatData();
  }, [location]);

  return (
    <div className={styles.page}>
      <ChatLibraryMain />
    </div>
  );
};

export { ChatLibrary };
