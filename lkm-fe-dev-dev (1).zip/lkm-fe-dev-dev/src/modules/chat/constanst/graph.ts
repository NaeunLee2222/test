import { Edge, Node, Options } from 'vis-network/standalone/esm/vis-network';

export const graphNodeStyle: Partial<Node> = {
  shape: 'dot',
  size: 18,
  borderWidth: 2,
  font: {
    size: 14,
    color: '#ffffff',
    face: 'Helvetica Neue, Arial, sans-serif',
    strokeWidth: 0,
  },
};

export const graphEdgeStyle: Partial<Edge> = {
  width: 1,
  arrows: {
    to: { enabled: true, scaleFactor: 0.7 },
  },
  font: {
    size: 12,
    color: '#d3d3d3',
    align: 'top',
    strokeWidth: 0,
  },
  smooth: {
    enabled: true,
    type: 'cubicBezier',
    roundness: 0.7,
  },
};

export const graphDefaultColors = {
  node: {
    border: '#5D9CEC',
    background: '#5D9CEC',
    font: '#ffffff',
  },
  edge: {
    color: '#666666',
    font: '#d3d3d3',
  },
};

export const graphHighlightColors = {
  node: {
    border: '#F5A623',
    background: '#F5A623',
    font: '#ffffff',
  },
  connectedNode: {
    border: '#5D9CEC',
    background: '#5D9CEC',
    font: '#ffffff',
  },
  edge: {
    color: '#cccccc',
    font: '#ffffff',
  },
};

export const graphDimColors = {
  node: {
    border: 'rgba(93, 156, 236, 0.2)',
    background: 'rgba(93, 156, 236, 0.2)',
    font: 'rgba(255, 255, 255, 0.3)',
  },
  edge: {
    color: 'rgba(102, 102, 102, 0.2)',
    font: 'rgba(211, 211, 211, 0.3)',
  },
};

export const graphOptions: Options = {
  interaction: {
    hover: true,
    dragNodes: true,
    dragView: true,
    zoomView: true,
    tooltipDelay: 200,
  },
  physics: {
    enabled: true,
    solver: 'barnesHut',
    barnesHut: {
      gravitationalConstant: -15000,
      centralGravity: 0.1,
      springLength: 150,
      springConstant: 0.05,
      damping: 0.1,
    },
    stabilization: {
      iterations: 1000,
    },
  },
  nodes: graphNodeStyle,
  edges: graphEdgeStyle,
};
