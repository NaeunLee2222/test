export const MAX_PAGE = 3;
export const ROW_PER_PAGE = 3;
export const MIN_PAGE = 0;
