import { Box } from '@mui/material';
import { ReactNode } from 'react';
import HeaderWorkflowLayout from './HeaderWorkFlow';
import styles from './WorkFlowLayout.module.scss';

type Props = {
  children: ReactNode;
  mode?: string;
  setMode?: React.Dispatch<React.SetStateAction<string>>;
};

const AgentLayout = ({ children, mode, setMode }: Props) => (
  <Box className={styles.layout}>
    <HeaderWorkflowLayout mode={mode} setMode={setMode} />
    {children}
  </Box>
);

export default AgentLayout;
