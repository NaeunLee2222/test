import IconClose from '@/assets/basic-icons/icon-close-01.svg?react';
import ChevronLeftIcon from '@/assets/direction-icons/icon-chevron-left.svg?react';
import { agentDataAtom } from '@/modules/agent/jotai/agent';
import { IPaths, ModeType } from '@/modules/agent/type/agent';
import {
  useAgentDetail,
  useGetGeneralAgent,
} from '@/modules/chat/hooks/useAgents';
import { EChatAgentStatus } from '@/modules/chat/types/agents';
import { RoutesURL } from '@/routers/routes';
import { formatFullSizeDateTime } from '@/utils/agentUtil';
import { Box, Button, Divider, Skeleton, Typography } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { HeaderWorkflowUserInfo } from './UserInfo';
import styles from './index.module.scss';

type Props = {
  paths: IPaths;
  isAgentAdminPage: boolean;
  mode?: ModeType | string;
};

export const HeaderWorkFlowTitle = ({
  paths,
  isAgentAdminPage,
  mode,
}: Props) => {
  const { t } = useTranslation('tax');
  const navigate = useNavigate();

  const [{ data: agentDetail, isFetching }] = useAtom(useAgentDetail);
  const [{ data: generalAgent }] = useAtom(useGetGeneralAgent);
  const [agentData] = useAtom(agentDataAtom);

  const isAgentLKMPage =
    paths.isAgentLKMRegistration || paths.isAgentLKMOperation;

  const renderUserInfo = () => {
    if (isAgentLKMPage && mode === ModeType.DASHBOARD) {
      return (
        <>
          <Divider
            orientation='vertical'
            flexItem
            className={styles['vertical-divider-center']}
          />

          <HeaderWorkflowUserInfo />
        </>
      );
    }
  };

  const renderAgentStatus = () => {
    if (paths.isAgentRegistration || paths.isAgentOperation) {
      return (
        <Typography variant='h5' className={styles['setting-header-title']}>
          {t('agentSettingTitle')}
        </Typography>
      );
    }

    if (isFetching) {
      return (
        <Box>
          <Skeleton variant='rounded' width={60} />
          <Skeleton variant='rounded' width={300} sx={{ mt: '4px' }} />
        </Box>
      );
    }

    const agentUpdatedTime =
      generalAgent?.agent?.updated_at ??
      generalAgent?.data?.agent?.updated_at ??
      generalAgent?.agent?.created_at ??
      generalAgent?.data?.agent?.created_at ??
      agentDetail?.formattedData.updatedAt ??
      agentDetail?.formattedData.createdAt;

    const agentName =
      agentDetail?.formattedData?.name ??
      (agentData?.name !== '' && agentData.name
        ? agentData.name
        : t('agent.createAgentHeaderDefault'));

    return (
      <>
        <Box>
          <Typography variant='h5' className={styles['header-title']}>
            {agentName}
          </Typography>

          <Box className={styles['agent-status-block']}>
            {!isAgentLKMPage ? (
              <>
                <Typography variant='caption' className={styles['text-grey']}>
                  {`${t('save')} ${formatFullSizeDateTime(agentUpdatedTime)}`}
                </Typography>

                <Divider
                  orientation='vertical'
                  flexItem
                  className={styles['vertical-divider']}
                />

                <Box className={styles['agent-status']}>
                  <Box
                    className={cn(
                      styles.dot,
                      agentDetail?.formattedData.reviewStatus ===
                        EChatAgentStatus.TESTING
                        ? styles['dot-red']
                        : styles['dot-yellow']
                    )}
                  />

                  {agentDetail?.formattedData.reviewStatus ===
                  EChatAgentStatus.TESTING ? (
                    <Typography
                      variant='caption'
                      className={cn(styles.text, styles['text-red'])}
                    >
                      {t('agent.status.review')}
                    </Typography>
                  ) : (
                    <Typography
                      variant='caption'
                      className={cn(styles.text, styles['text-yellow'])}
                    >
                      {t('agent.status.processing')}
                    </Typography>
                  )}
                </Box>
              </>
            ) : (
              <Box className={styles['agent-status']}>
                <Box className={cn(styles.dot, styles['dot-gray'])} />
                <Typography
                  variant='caption'
                  className={cn(styles.text, styles['text-gray'])}
                >
                  {t('agent.status.deployed')}
                </Typography>
              </Box>
            )}
          </Box>
        </Box>

        {!paths.isAgentLKMOperation && renderUserInfo()}
      </>
    );
  };

  return (
    <Box
      sx={{ display: 'flex', alignItems: 'center', width: '400px !important' }}
    >
      <Button variant='text' className={styles['button-arrow']}>
        {isAgentAdminPage ? (
          <IconClose
            className='f-24 mr-12 color-red'
            onClick={() => navigate(-1)}
          />
        ) : (
          <ChevronLeftIcon onClick={() => navigate(RoutesURL.AGENT)} />
        )}
      </Button>

      {renderAgentStatus()}
    </Box>
  );
};
