import UserCheckIcon from '@/assets/basic-icons/icon-user-check.svg?react';
import UsersIcon from '@/assets/basic-icons/icon-users.svg?react';
import { UsageScope } from '@/modules/agent/type/agent';
import { EChatAgentStatus } from '@/modules/chat/types/agents';
import {
  confirmDialogDataAtom,
  isModalLoadingAtom,
} from '@/modules/core/jotai/confirm';
import { EButtonType } from '@/types/common';
import { ListItemIcon, Menu, MenuItem } from '@mui/material';
import { useAtom } from 'jotai';
import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

type Props = {
  anchorEl: HTMLButtonElement | null;
  setAnchorEl: (value: HTMLButtonElement | null) => void;
  handleUpsertAgent: (
    reviewStatus?: EChatAgentStatus,
    usageScope?: UsageScope
  ) => void;
};

enum ConfirmType {
  PRO_DEPLOYED,
  GENERAL_PRIVATE,
  GENERAL_SUBMITTED,
}

export const HeaderWorkflowMenu = ({
  anchorEl,
  setAnchorEl,
  handleUpsertAgent,
}: Props) => {
  const { t } = useTranslation('tax');

  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [, setModalLoading] = useAtom(isModalLoadingAtom);

  const handleClose = useCallback(() => {
    setAnchorEl(null);
  }, [setAnchorEl]);

  const handleConfirmSaveToStore = (confirmType: ConfirmType) => {
    setAnchorEl(null);

    let title = '';
    let contentText = '';
    let confirmText = '';
    let targetType: EChatAgentStatus;
    let usageScope: UsageScope;
    switch (confirmType) {
      case ConfirmType.PRO_DEPLOYED:
        title = t('agent.modal.confirmTitle');
        contentText = t('agent.modal.confirmTitle');
        confirmText = t('agent.modal.confirmText');
        break;
      case ConfirmType.GENERAL_SUBMITTED:
        title = t('agent.modal.generalDeployedConfirmTitle');
        contentText = t('agent.modal.generalDeployedContentText');
        confirmText = t('agent.modal.generalDeployedConfirmText');
        targetType = EChatAgentStatus.SUBMITTED;
        break;
      case ConfirmType.GENERAL_PRIVATE:
        title = t('agent.modal.generalPrivateConfirmTitle');
        contentText = t('agent.modal.generalPrivateContentText');
        confirmText = t('agent.modal.generalPrivateConfirmText');
        targetType = EChatAgentStatus.DEPLOYED;
        usageScope = UsageScope.PERSONAL;
        break;
      default:
        targetType = EChatAgentStatus.DEPLOYED;
        break;
    }

    setConfirmDialogData({
      type: EButtonType.DEFAULT,
      open: true,
      title,
      handleCancel: () => setConfirmDialogData({ open: false }),
      handleConfirm: () => {
        setModalLoading(true);
        handleUpsertAgent(targetType, usageScope);
      },
      contentText: (
        <>
          {contentText.split('\n').map((line, index) => (
            <>
              <span key={index} style={{ fontSize: '14px' }}>
                {line}
              </span>
              <br />
            </>
          ))}
        </>
      ),
      confirmText,
    });
  };

  return (
    <Menu
      anchorEl={anchorEl}
      open={Boolean(anchorEl)}
      onClose={handleClose}
      className={styles.menu}
      sx={{
        '& .MuiMenu-paper': {
          boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.2)',
          borderRadius: '8px',
          padding: '4px',
          width: '320px',
          height: '126px',
        },
        '& .MuiMenu-list': {
          padding: 0,
          display: 'flex',
          flexDirection: 'column',
          gap: '4px',
        },
      }}
    >
      <MenuItem
        onClick={() => handleConfirmSaveToStore(ConfirmType.GENERAL_PRIVATE)}
        className={styles.menuItem}
      >
        <ListItemIcon className={styles.menuIcon}>
          <UserCheckIcon />
        </ListItemIcon>

        <div className={styles.buttonTextContainer}>
          <div className={styles.buttonTitle}>
            {t('agent.buttonTitle.privateStorage')}
          </div>
          <div className={styles.buttonDescription}>
            {t('agent.buttonTitle.privateStorageDescription')}
          </div>
        </div>
      </MenuItem>

      <MenuItem
        onClick={() => handleConfirmSaveToStore(ConfirmType.GENERAL_SUBMITTED)}
        className={styles.menuItem}
      >
        <ListItemIcon className={styles.menuIcon}>
          <UsersIcon />
        </ListItemIcon>

        <div className={styles.buttonTextContainer}>
          <div className={styles.buttonTitle}>
            {t('agent.buttonTitle.deployed')}
          </div>

          <div className={styles.buttonDescription}>
            {t('agent.buttonTitle.deployedDescription')}
          </div>
        </div>
      </MenuItem>
    </Menu>
  );
};
