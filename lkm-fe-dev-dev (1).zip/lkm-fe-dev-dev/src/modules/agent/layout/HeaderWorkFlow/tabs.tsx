import { AgentType, ModeType, type IPaths } from '@/modules/agent/type/agent';
import { useAgentDetail } from '@/modules/chat/hooks/useAgents';
import { EChatAgentStatus } from '@/modules/chat/types/agents';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

type Props = {
  isAgentAdminPage: boolean;
  paths: IPaths;
  agentMode: string | null;
  mode?: ModeType | string;
  setMode?: React.Dispatch<React.SetStateAction<string>>;
};

export const HeaderWorkflowTabs = ({
  isAgentAdminPage,
  paths,
  agentMode,
  setMode,
  mode,
}: Props) => {
  const { t } = useTranslation('tax');

  const [{ data: agentDetail }] = useAtom(useAgentDetail);
  const params = new URLSearchParams(location.search);
  const editMode = params.get('action');

  const changeWRMode = useCallback(
    (wrType: string) => {
      if (setMode) {
        setMode(wrType);
      }
    },
    [setMode]
  );

  const setActiveItemCss = useCallback(
    (activeType: string) => (mode === activeType ? styles.active : ''),
    [mode]
  );

  const isTesting =
    agentDetail?.formattedData?.reviewStatus === EChatAgentStatus.TESTING ||
    (agentDetail?.formattedData.reviewStatus === EChatAgentStatus.SAVED &&
      !editMode);

  const renderTestingTabs = () => (
    <Box className={styles.menuContainer}>
      <Box
        className={cn(styles.menuItem, setActiveItemCss(ModeType.DASHBOARD))}
        onClick={() => changeWRMode(ModeType.DASHBOARD)}
      >
        {t(`agent.buttonTitle.workflowBoard`)}
      </Box>

      <Box
        className={cn(styles.menuItem, setActiveItemCss(ModeType.CHAT))}
        onClick={() => changeWRMode(ModeType.CHAT)}
      >
        {t(`agent.buttonTitle.chatAssistant`)}
      </Box>

      {!isAgentAdminPage && (
        <Box
          className={cn(styles.menuItem, setActiveItemCss(ModeType.FEEDBACK))}
          onClick={() => changeWRMode(ModeType.FEEDBACK)}
        >
          {t(`agent.buttonTitle.feedback`)}
        </Box>
      )}
    </Box>
  );

  const renderUserTabs = () => (
    <Box className={styles.menuContainer}>
      <>
        <Box
          className={cn(styles.menuItem, setActiveItemCss(ModeType.DASHBOARD))}
          onClick={() => changeWRMode(ModeType.DASHBOARD)}
        >
          {t(`agent.configuration.header`)}
        </Box>

        <Box
          className={cn(styles.menuItem, setActiveItemCss(ModeType.FEEDBACK))}
          onClick={() => changeWRMode(ModeType.FEEDBACK)}
        >
          {t(`agent.configuration.aiFeedback`)}
        </Box>
      </>
    </Box>
  );

  if (isTesting || paths.isAgentLKMOperation || paths.isAgentLKMRegistration)
    return renderTestingTabs();
  if (
    (!paths.isAgentRegistration &&
      !paths.isAgentOperation &&
      paths.isAgentBasic) ||
    agentMode?.toLowerCase() === AgentType.GENERAL
  )
    return renderUserTabs();

  return null;
};
