import { useCreateAgentHistory } from '@/modules/admin/hooks/useAgentManagement';
import {
  rejectDescriptionAtom,
  skipGetGeneralAgentAtom,
  userEmailQueryAtom,
} from '@/modules/admin/jotai/agent';
import {
  useAgentUpsertMutation,
  useCreateBasicAgentMutation,
} from '@/modules/agent/hooks/useAgent';
import { useConvertNodeData } from '@/modules/agent/hooks/useConvertNodeData';
import {
  agentCreationLoadingAtom,
  agentDataAtom,
  agentIdForUpdating,
  agentReasonChangeAtom,
  alreadyCreatedWorkflowAtom,
  conversationStarterAtom,
  generalAgentIdAtom,
  isTestAgentLoadingAtom,
  nodesAtom,
  selectedAgentToolsAtom,
} from '@/modules/agent/jotai/agent';
import {
  AgentDto,
  AgentType,
  IAgentCreationResponse,
  ModeType,
  UsageScope,
} from '@/modules/agent/type/agent';
import {
  useAgentDetail,
  useGetGeneralAgent,
} from '@/modules/chat/hooks/useAgents';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import { chatDataAtom, messagesAtom } from '@/modules/chat/jotai/chat';
import { canvasAtoms } from '@/modules/chat/jotai/chatprocessing';
import {
  EChatAgentStatus,
  IChatAgentPutRequest,
  IChatAgentResponse,
  IChatStarter,
} from '@/modules/chat/types/agents';
import { USER_ID } from '@/modules/chat/types/user';
import { HttpMethod } from '@/modules/core/constant';
import {
  confirmDialogDataAtom,
  isModalLoadingAtom,
} from '@/modules/core/jotai/confirm';
import { RoutesURL } from '@/routers/routes';
import { agentStepsConverter } from '@/utils/agentUtil';
import { showSnackbar } from '@/utils/snackbarUtil';
import { Box } from '@mui/material';
import { useAtom, useAtomValue, useSetAtom, useStore } from 'jotai';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useCookies } from 'react-cookie';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { HeaderWorkflowButtons } from './buttons';
import styles from './index.module.scss';
import { HeaderWorkflowMenu } from './menu';
import { HeaderWorkflowTabs } from './tabs';
import { HeaderWorkFlowTitle } from './title';

const SNACK_BAR_DURATION = 3;

const HeaderWorkflowLayout = (props: {
  mode?: ModeType | string;
  setMode?: React.Dispatch<React.SetStateAction<string>>;
}) => {
  const { t } = useTranslation('tax');
  const { t: adminTranslation } = useTranslation('admin');
  const [cookies] = useCookies([USER_ID]);
  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const agentMode = params.get('mode');
  const { agentId } = useParams();
  const store = useStore();
  const { mode, setMode } = props;
  const { convertData } = useConvertNodeData();

  const [idForUpdating, setIdForUpdating] = useAtom(agentIdForUpdating);
  const [conversationStarter] = useAtom(conversationStarterAtom);
  const [agentData, updateAgentData] = useAtom(agentDataAtom);
  const [{ mutateAsync: postHistory }] = useAtom(useCreateAgentHistory);
  const [{ data: generalAgent }] = useAtom(useGetGeneralAgent);
  const [{ data: createdAgent, mutateAsync: createAgent }] = useAtom(
    useCreateBasicAgentMutation
  );
  const [{ mutateAsync: mutateAgent }] = useAtom(useAgentUpsertMutation);
  const [nodes] = useAtom(nodesAtom);
  const [{ data: agentDetail, refetch }] = useAtom(useAgentDetail);
  const [, setGeneralAgentId] = useAtom(generalAgentIdAtom);
  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [, setAgentDetailId] = useAtom(agentDetailIdAtom);
  const [, setChatData] = useAtom(chatDataAtom);
  const [, setData] = useAtom(canvasAtoms);
  const updateMessagesData = useSetAtom(messagesAtom);
  const [, setModalLoading] = useAtom(isModalLoadingAtom);
  const [, setUserQuery] = useAtom(userEmailQueryAtom);
  const [, updateAlreadyCreated] = useAtom(alreadyCreatedWorkflowAtom);
  const [selectedTools] = useAtom(selectedAgentToolsAtom);
  const creationLoading = useAtomValue(agentCreationLoadingAtom);
  const [, setIsTestAgentLoading] = useAtom<boolean>(isTestAgentLoadingAtom);

  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [isTempSaveLoading, setIsTempSaveLoading] = useState<boolean>(false);

  const isPro = useMemo(
    () =>
      agentMode?.trim()?.toLowerCase() === AgentType.PRO ||
      location.pathname.includes(RoutesURL.WORKFLOW_REVIEW),
    [agentMode, location.pathname]
  );

  const isPathMatch = useCallback(
    (path: string) => location.pathname.includes(path),
    [location.pathname]
  );

  const paths = useMemo(
    () => ({
      isAgentRegistration: isPathMatch(
        RoutesURL.SETTINGS_AGENT_GENERAL_REGISTRATION
      ),
      isAgentLKMRegistration: isPathMatch(
        RoutesURL.SETTINGS_AGENT_LKM_REGISTRATION
      ),
      isAgentOperation: isPathMatch(RoutesURL.SETTINGS_AGENT_GENERAL_OPERATION),
      isAgentLKMOperation: isPathMatch(RoutesURL.SETTINGS_AGENT_LKM_OPERATION),
      isAgentBasic: isPathMatch(RoutesURL.GENERAL_AGENT),
    }),
    [isPathMatch]
  );

  const isAgentAdminPage =
    paths.isAgentRegistration ||
    paths.isAgentOperation ||
    paths.isAgentLKMRegistration ||
    paths.isAgentLKMOperation;

  // convert data from agent detail to nodes
  useEffect(() => {
    if (agentDetail?.formattedData?.steps?.length === 0) return;

    convertData(agentDetail?.formattedData?.steps);
  }, [agentDetail?.formattedData?.steps]);

  // only get general agent when in LKM registration adm page
  useEffect(() => {
    store.set(skipGetGeneralAgentAtom, paths.isAgentLKMRegistration);
  }, [paths.isAgentLKMRegistration, store]);

  useEffect(() => {
    if (agentDetail && paths.isAgentLKMRegistration) {
      setUserQuery({ id: agentDetail?.rawData?.created_user_id?.toString() });
    }
  }, [agentDetail, paths.isAgentLKMRegistration]);

  useEffect(() => {
    if (agentId) {
      setAgentDetailId(agentId);
    }

    return () => {
      setAgentDetailId('');
    };
  }, []);

  // change type of agent data when in flow page
  useEffect(() => {
    if (mode === ModeType.DASHBOARD) {
      updateAgentData({ type: AgentType.PRO });
    }
  }, [mode]);

  // set data to agent data
  useEffect(() => {
    if (generalAgent || agentDetail) {
      updateAgentData({
        name:
          generalAgent?.data?.agent?.name ??
          generalAgent?.agent?.name ??
          agentDetail?.rawData.name,
        description:
          generalAgent?.data?.agent?.description ??
          generalAgent?.agent?.description ??
          agentDetail?.rawData.description,
        instruction:
          generalAgent?.data?.instruction ?? generalAgent?.instruction ?? '',
      });
    }
  }, [agentDetail, generalAgent]);

  // set id currently
  useEffect(() => {
    if (agentId) {
      updateAgentData({ id: agentId });
      setIdForUpdating(agentId);
    }
  }, [agentId]);

  useEffect(() => {
    const agent = createdAgent?.data?.agent ?? createdAgent?.agent;

    if (agentMode === AgentType.GENERAL && agent) {
      if (agent.agent_type === AgentType.GENERAL) {
        setGeneralAgentId(agent?.id.toString());
      }
    }
  }, [agentMode, createAgent, createdAgent, setGeneralAgentId]);

  const handleUpdateAgent = async (
    selectedToolList: (number | null)[],
    reviewStatus?: EChatAgentStatus,
    usageScope?: UsageScope
  ) => {
    const rejectDescription = store.get(rejectDescriptionAtom);
    const agentReasonChange = store.get(agentReasonChangeAtom);

    const agentType = (): AgentType => {
      const typeFromAPI = agentDetail?.rawData?.agent_type;

      if (typeFromAPI) {
        return typeFromAPI === AgentType.PRO
          ? AgentType.PRO
          : AgentType.GENERAL;
      }

      return isPro ? AgentType.PRO : AgentType.GENERAL;
    };

    const updatedData: IChatAgentPutRequest = {
      agent: {
        name: agentData.name ?? agentDetail?.rawData.name ?? '',
        description:
          agentData.description ?? agentDetail?.rawData.description ?? '',
        review_status: reviewStatus ?? agentDetail?.rawData.review_status,
        reject_description:
          rejectDescription ?? agentDetail?.rawData.reject_description ?? '',
        created_at: agentDetail?.rawData.created_at ?? '',
        created_user_id:
          agentDetail?.rawData?.created_user_id ??
          generalAgent?.data?.agent?.created_user_id ??
          generalAgent?.agent?.created_user_id ??
          1,
        id:
          agentData.id ??
          agentDetail?.rawData?.id ??
          generalAgent?.data?.agent?.id ??
          generalAgent?.agent?.id ??
          idForUpdating,
        agent_type: agentType(),
        category:
          agentDetail?.rawData?.category ??
          generalAgent?.data?.agent?.category ??
          generalAgent?.agent?.category,
        org_id:
          agentDetail?.rawData?.org_id ??
          generalAgent?.data?.agent?.org_id ??
          generalAgent?.agent?.org_id,
        steps: agentStepsConverter(nodes, HttpMethod.PUT),
        team_id:
          agentDetail?.rawData.team_id ??
          generalAgent?.data?.agent?.team_id ??
          generalAgent?.agent?.team_id,
        updated_at: new Date().toISOString(),
        usage_scope:
          usageScope ??
          agentDetail?.rawData.usage_scope ??
          generalAgent?.data?.agent?.usage_scope ??
          generalAgent?.agent?.usage_scope,
        use_count:
          agentDetail?.rawData.use_count ??
          generalAgent?.data?.agent?.use_count ??
          generalAgent?.agent?.use_count,
      },
      general_agent_instruction: {
        instruction:
          agentData.instruction ??
          generalAgent?.data?.instruction ??
          generalAgent?.instruction ??
          '',
        tool_ids: [...selectedToolList],
      },
      chat_starters: [...conversationStarter]
        .filter((item) => !!item)
        .map(
          (item, index) =>
            ({
              id: index + 1,
              starter: item,
            }) as IChatStarter
        ),
    };

    if (
      reviewStatus &&
      [EChatAgentStatus.DEPLOYED, EChatAgentStatus.REJECTED].includes(
        reviewStatus
      )
    ) {
      updatedData.agent.administer_id = cookies.userId ?? 1;
    }

    try {
      await mutateAgent({
        data: updatedData,
        callback: (
          isSuccess: boolean,
          response: {
            data: { message: string; agent: IChatAgentResponse };
            message: string;
            agent: IChatAgentResponse;
          }
        ) => {
          setIsTempSaveLoading(false);
          setIsTestAgentLoading(false);
          setModalLoading(false);
          setConfirmDialogData({ open: false });

          const updated = response?.data?.agent ?? response?.agent;

          if (isSuccess) {
            if (paths.isAgentOperation) {
              postHistory({
                agent_id:
                  agentData.id ??
                  agentDetail?.rawData?.id ??
                  generalAgent?.data?.agent?.id ??
                  generalAgent?.agent?.id ??
                  idForUpdating,
                modified_user_id: cookies.userId ?? 1,
                description: agentReasonChange,
              });
            }

            if (isPro) {
              updateAlreadyCreated({
                name: agentData.name,
                description: agentData.description,
                starter: [...conversationStarter],
              });

              // 에이전트 테스트 버튼을 눌렀을 때 무조건 챗 어시스턴트 페이지로 이동
              if (reviewStatus === EChatAgentStatus.TESTING) {
                navigate(
                  `${RoutesURL.WORKFLOW_REVIEW}/${updated.id}?mode=chat`
                );
              }
            } else {
              setGeneralAgentId(updated.id.toString());
            }
          }

          if (
            reviewStatus === EChatAgentStatus.DEPLOYED ||
            reviewStatus === EChatAgentStatus.PRIVATE ||
            reviewStatus === EChatAgentStatus.SUBMITTED ||
            reviewStatus === EChatAgentStatus.REJECTED ||
            usageScope === UsageScope.PERSONAL
          ) {
            setChatData({});
            setData({});
            updateMessagesData({});

            if (isAgentAdminPage) {
              navigate(-1);
            } else {
              navigate(RoutesURL.AGENT);
            }
          }

          const customMessage =
            reviewStatus === EChatAgentStatus.PRIVATE
              ? t('agent.configuration.message.private')
              : reviewStatus === EChatAgentStatus.SUBMITTED
                ? t('agent.configuration.message.submitted')
                : reviewStatus === EChatAgentStatus.DEPLOYED && isAgentAdminPage
                  ? t('agent.configuration.message.adminDeployed')
                  : reviewStatus === EChatAgentStatus.REJECTED &&
                      isAgentAdminPage
                    ? t('agent.configuration.message.adminRejected')
                    : '';

          showSnackbar(
            customMessage ||
              response?.data?.message ||
              response?.message ||
              adminTranslation('apiErrorResponse.updateAgent'),
            isSuccess ? 'success' : 'error',
            SNACK_BAR_DURATION,
            {
              vertical: 'bottom',
              horizontal: 'center',
            },
            {
              className: styles.successSnackbar,
            }
          );
        },
      });
    } catch {
      setIsTempSaveLoading(false);
      setIsTestAgentLoading(false);
      setModalLoading(false);
      setConfirmDialogData({ open: false });
      showSnackbar(
        adminTranslation('apiErrorResponse.updateAgent'),
        'error',
        SNACK_BAR_DURATION
      );
    }
  };

  const handleCreateAgent = async (
    selectedToolList: (number | null)[],
    reviewStatus?: EChatAgentStatus,
    usageScope?: UsageScope
  ) => {
    const agentDto: AgentDto = {
      steps: agentStepsConverter(nodes),
      document_id: 0,
      general_agent_instruction: {
        instruction: agentData.instruction ?? '',
        tool_ids: [...selectedToolList],
      },
      agent: {
        name: agentData.name ?? agentDetail?.formattedData.name ?? '',
        description:
          agentData.description ?? agentDetail?.formattedData.description ?? '',
        agent_type: isPro ? AgentType.PRO : AgentType.GENERAL,
        category: 'Engineering',
        org_id: 1,
        review_status: reviewStatus ?? EChatAgentStatus.SAVED,
        team_id: 1,
        usage_scope: usageScope ?? UsageScope.PUBLIC,
        use_count: 0,
        steps: agentStepsConverter(nodes),
        created_user_id: cookies.userId ?? 1,
      },
      created_user_id: cookies.userId ?? 1,
      chat_starters: [...conversationStarter].filter((item) => !!item),
    };

    try {
      return await createAgent({
        data: agentDto,
        callback: (isSuccess: boolean, response: IAgentCreationResponse) => {
          setIsTempSaveLoading(false);
          setIsTestAgentLoading(false);
          setModalLoading(false);
          setConfirmDialogData({ open: false });

          const created = response?.data?.agent ?? response?.agent;
          if (isSuccess) {
            if (isPro) {
              updateAlreadyCreated({
                name: agentData.name,
                description: agentData.description,
                starter: [...conversationStarter],
              });

              if (reviewStatus === EChatAgentStatus.TESTING) {
                navigate(
                  `${RoutesURL.WORKFLOW_REVIEW}/${created.id}?mode=chat`
                );
              }
            } else {
              setGeneralAgentId(created.id.toString());
            }
          }

          if (reviewStatus === EChatAgentStatus.DEPLOYED) {
            navigate(-1);
          }

          if (
            reviewStatus === EChatAgentStatus.PRIVATE ||
            reviewStatus === EChatAgentStatus.SUBMITTED
          ) {
            navigate(RoutesURL.AGENT);
          }

          if (reviewStatus === EChatAgentStatus.SAVED) {
            navigate(`${RoutesURL.GENERAL_AGENT}/${created.id}`);
          }

          const customMessage =
            reviewStatus === EChatAgentStatus.PRIVATE
              ? t('agent.configuration.message.private')
              : reviewStatus === EChatAgentStatus.SUBMITTED
                ? t('agent.configuration.message.submitted')
                : '';

          showSnackbar(
            customMessage ||
              (response?.data?.message ?? response?.message) ||
              adminTranslation('apiErrorResponse.createAgent'),
            isSuccess ? 'success' : 'error',
            SNACK_BAR_DURATION,
            {
              vertical: 'bottom',
              horizontal: 'center',
            },
            {
              className: styles.successSnackbar,
            }
          );
        },
      });
    } catch {
      setIsTempSaveLoading(false);
      setIsTestAgentLoading(false);
      setModalLoading(false);
      showSnackbar(
        t('apiErrorResponse.createAgent'),
        'error',
        SNACK_BAR_DURATION
      );
    }
  };

  const handleUpsertAgent = async (
    reviewStatus?: EChatAgentStatus,
    usageScope?: UsageScope
  ) => {
    const isUpdating =
      agentDetail?.rawData?.id ??
      generalAgent?.data?.agent?.id ??
      generalAgent?.agent?.id ??
      idForUpdating;

    if (reviewStatus === EChatAgentStatus.SAVED) {
      setIsTempSaveLoading(true);
    }
    if (reviewStatus === EChatAgentStatus.TESTING) {
      setIsTestAgentLoading(true);
    }

    if (
      !creationLoading &&
      ((!!agentData.name && !!agentData.description) || agentDetail)
    ) {
      const selectedToolList = [...selectedTools.map((item) => item.id)];

      if (isUpdating) {
        await handleUpdateAgent(selectedToolList, reviewStatus, usageScope);
        refetch();
      } else {
        const res = await handleCreateAgent(
          selectedToolList,
          reviewStatus,
          usageScope
        );
        setIdForUpdating(String(res?.data?.agent?.id ?? res?.agent?.id ?? ''));
      }
    }
  };

  const handleOpenMenu = useCallback(
    (event: React.MouseEvent<HTMLButtonElement>) => {
      setAnchorEl(event.currentTarget);
    },
    []
  );

  return (
    <Box className={styles.header}>
      <HeaderWorkFlowTitle
        paths={paths}
        isAgentAdminPage={isAgentAdminPage}
        mode={mode}
      />

      <HeaderWorkflowTabs
        isAgentAdminPage={isAgentAdminPage}
        paths={paths}
        mode={mode}
        agentMode={agentMode}
        setMode={setMode}
      />

      <HeaderWorkflowButtons
        isPro={isPro}
        isTempSaveLoading={isTempSaveLoading}
        paths={paths}
        isAgentAdminPage={isAgentAdminPage}
        handleOpenMenu={handleOpenMenu}
        handleUpsertAgent={handleUpsertAgent}
      />

      <HeaderWorkflowMenu
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        handleUpsertAgent={handleUpsertAgent}
      />
    </Box>
  );
};

export default HeaderWorkflowLayout;
