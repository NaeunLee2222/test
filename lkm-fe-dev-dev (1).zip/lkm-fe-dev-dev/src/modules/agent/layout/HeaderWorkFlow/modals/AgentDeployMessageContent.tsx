import { agentReasonChangeAtom } from '@/modules/agent/jotai/agent';
import { BaseTextField } from '@/modules/core/components/common/BaseTextField';
import { useAtom } from 'jotai';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import styles from '../index.module.scss';

const AgentDeployMessageContent = () => {
  const { t } = useTranslation('tax');
  const [agentReasonChange, setAgentReasonChangeAtom] = useAtom(
    agentReasonChangeAtom
  );

  const handleUpdate = (event: React.ChangeEvent<HTMLInputElement>) => {
    const updated = typeof event === 'string' ? event : event.target.value;

    setAgentReasonChangeAtom(updated);
  };

  useEffect(() => {
    setAgentReasonChangeAtom('');
  }, []);

  return (
    <div className={styles.deployedUpdate}>
      <div className={styles.deployedMessage}>
        {t('changeDeployedAgent.description')}
      </div>
      <div className={styles.textboxContainer}>
        <div className={styles.textLabel}>
          {t('changeDeployedAgent.label')}

          <span>*</span>
        </div>

        <BaseTextField
          className={styles.deployedMessage}
          value={agentReasonChange ?? ''}
          onChange={handleUpdate}
          disabled={false}
          multiline
          fullWidth
          sx={{
            '> *.MuiInputBase-root': {
              'textarea': {
                minHeight: '100px',
                paddingTop: '10px',
                paddingLeft: '8px',
              },
            },
            '& .MuiOutlinedInput-root': {
              '& fieldset': {
                border: 'none',
              },
            },
          }}
          placeholder={t('changeDeployedAgent.placeholder')}
        />
      </div>
    </div>
  );
};

export default AgentDeployMessageContent;
