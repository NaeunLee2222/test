import { selectedUsageScopeAtom } from '@/modules/admin/jotai/agent';
import { UsageScope } from '@/modules/agent/type/agent';
import { Radio, styled } from '@mui/material';
import { useAtom } from 'jotai';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import styles from '../index.module.scss';

const DeployAgentModalBody = () => {
  const { t } = useTranslation('tax');
  const [selectedUsageScope, setSelectedUsageScope] = useAtom(
    selectedUsageScopeAtom
  );

  const options = [
    {
      value: UsageScope.ORG,
      label: t('agent.cardItem.basicAgent'),
    },
    {
      value: UsageScope.PUBLIC,
      label: t('agent.cardItem.proAgent'),
    },
  ];

  useEffect(
    () => () => {
      setSelectedUsageScope(UsageScope.ORG);
    },

    []
  );

  return (
    <div className={styles.deployBody}>
      <div className={styles.deployMessage}>{t('agent.deployDescription')}</div>
      <div className={styles.deploySelection}>
        <div className={styles.selectGallery}>{t('agent.selectGallery')}</div>
        <div className={styles.selection}>
          {options.map((option) => (
            <div key={option.value}>
              <StyledRadio
                value={option.value}
                checked={option.value === selectedUsageScope}
                onChange={(e) => {
                  setSelectedUsageScope(e.target.value as UsageScope);
                }}
              />
              {option.label}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DeployAgentModalBody;

const StyledRadio = styled(Radio)(() => ({
  color: 'var(--gray-300)',
  '&.Mui-checked': {
    color: 'var(--primary-color-800) !important',
  },
}));
