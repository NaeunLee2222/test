import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { EButtonType } from '@/types/common';
import { Box } from '@mui/material';
import { useTranslation } from 'react-i18next';

interface IProp {
  type: EButtonType;
  open: boolean;
  title: string;
  confirmText: string;
  contentChildren: React.ReactNode;
  handleConfirm: () => void;
  handleCancel: () => void;
}

const btnCancel = {
  width: '80px',
  height: '40px',
  fontSize: '14px',
  fontWeight: 500,
  color: 'var(--gray-700)',
  padding: '10px 16px',
  borderRadius: '6px',
  border: '1px solid var(--gray-200)',
  background: 'var(--white)',
  '&:hover': {
    backgroundColor: 'var(--primitives-darkBlue-10)',
  },
};

export const AgentAdminConfirmDialog = ({
  type,
  open = false,
  title,
  confirmText,
  handleConfirm,
  handleCancel,
  contentChildren,
}: IProp) => {
  const { t } = useTranslation('tax');

  return (
    <BaseDialog
      open={open}
      title={title}
      hideCloseButton
      handleClose={handleCancel}
      sx={{
        '& .MuiPaper-root': {
          width: `${type === EButtonType.DEFAULT ? '400px' : '500px'} !important`,
        },
        '& .MuiDialogActions-root': {
          padding: '8px 24px 16px',
        },
        '& .MuiDialogContent-root': {
          padding: '8px 24px 16px',
          overflowY: 'auto',
        },
        '& .MuiDialogTitle-root': {
          padding: '24px 24px 8px',
          'span': {
            fontSize: '18px !important',
            lineHeight: '26.1px !important',
          },
        },
      }}
      contentChildren={
        <Box
          sx={{
            typography: 'body03Regular',
            color: 'var(--gray-700)',
            fontSize: '14px !important',
            lineHeight: '19.6px',
          }}
        >
          {contentChildren}
        </Box>
      }
      actionsChildren={
        <div className='flex' style={{ gap: '10px' }}>
          <BaseButton
            buttonType='outlined'
            sx={btnCancel}
            onClick={handleCancel}
          >
            {t('cancel')}
          </BaseButton>
          <BaseButton
            sx={{
              width: 'auto',
              ...(type === EButtonType.DELETE && {
                backgroundColor: 'var(--primitives-Red-70, #FA5252)',
                ':hover': {
                  backgroundColor: 'var(--primitives-Red-70, #FA5252)',
                },
              }),
            }}
            onClick={handleConfirm}
          >
            {confirmText}
          </BaseButton>
        </div>
      }
    />
  );
};
