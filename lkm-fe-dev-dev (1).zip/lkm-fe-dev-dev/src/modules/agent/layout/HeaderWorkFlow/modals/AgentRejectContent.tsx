import { rejectDescriptionAtom } from '@/modules/admin/jotai/agent';
import { styled, TextField } from '@mui/material';
import { useAtom } from 'jotai';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import styles from '../index.module.scss';

const AgentRejectContent = () => {
  const { t } = useTranslation('tax');
  const [rejectDescription, setRejectDescription] = useAtom(
    rejectDescriptionAtom
  );

  useEffect(
    () => () => {
      setRejectDescription(undefined);
    },

    []
  );

  return (
    <div className={styles.rejectBody}>
      <div className={styles.rejectMessage}>{t('agent.rejectDescription')}</div>
      <CustomInput
        onChange={(e) => setRejectDescription(e.target.value)}
        value={rejectDescription ?? ''}
        fullWidth
        rows={7.2}
        placeholder={t('agent.rejectPlaceholder')}
        multiline
      />
    </div>
  );
};

export default AgentRejectContent;

const CustomInput = styled(TextField)({
  marginTop: '8px',

  '& fieldset': { border: 'none' },

  '.MuiInputBase-root': {
    padding: '12px',
    borderRadius: '6px',
    background: 'var(--gray-50)',
    border: 'none',

    '.MuiInputBase-input': {
      '&::placeholder': {
        color: 'var(--gray-500)',
        fontSize: '14px',
        fontStyle: 'normal',
        fontWeight: '400',
        lineHeight: '19.6px',
      },
    },
  },
});
