import DataFlowIcon from '@/assets/basic-icons/icon-data-flow.svg?react';
import DropdownIcon from '@/assets/basic-icons/icon-dropdown-white.svg?react';
import RefreshIcon from '@/assets/basic-icons/icon-refresh.svg?react';
import TutorialIcon from '@/assets/basic-icons/tutorial-icon.svg?react';
import { selectedUsageScopeAtom } from '@/modules/admin/jotai/agent';
import {
  agentCreationLoadingAtom,
  agentDataAtom,
  agentReasonChangeAtom,
  agentUpsertLoadingAtom,
  isTestAgentLoadingAtom,
  nodesAtom,
  selectedAgentToolsAtom,
} from '@/modules/agent/jotai/agent';
import {
  TutorialMode,
  UsageScope,
  type IPaths,
} from '@/modules/agent/type/agent';
import { useAgentDetail } from '@/modules/chat/hooks/useAgents';
import { EChatAgentStatus } from '@/modules/chat/types/agents';
import { TutorialModal } from '@/modules/report/components/Tutorial/TutorialDialog';
import { EButtonType } from '@/types/common';
import { Box, Button } from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue, useStore } from 'jotai';
import { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';
import { AgentAdminConfirmDialog } from './modals/AgentAdminConfirmDialog';
import AgentDeployMessageContent from './modals/AgentDeployMessageContent';
import AgentRejectContent from './modals/AgentRejectContent';
import DeployAgentModalBody from './modals/DeployAgentModalBody';

type Props = {
  isPro: boolean;
  isTempSaveLoading: boolean;
  isAgentAdminPage: boolean;
  paths: IPaths;
  handleUpsertAgent: (
    reviewStatus?: EChatAgentStatus,
    usageScope?: UsageScope
  ) => void;
  handleOpenMenu: (event: React.MouseEvent<HTMLButtonElement>) => void;
};

export interface AgentModalSettings {
  type: EButtonType;
  open: boolean;
  title: string;
  confirmText: string;
  handleCancel: () => void;
  handleConfirm: () => void;
  contentChildren: React.ReactNode;
}

export const HeaderWorkflowButtons = ({
  isPro,
  isTempSaveLoading,
  isAgentAdminPage,
  paths,
  handleUpsertAgent,
  handleOpenMenu,
}: Props) => {
  const { t } = useTranslation('tax');
  const store = useStore();

  const upsertLoading = useAtomValue(agentUpsertLoadingAtom);
  const [, setAgentReasonChange] = useAtom(agentReasonChangeAtom);
  const [{ data: agentDetail }] = useAtom(useAgentDetail);
  const [isTestAgentLoading] = useAtom(isTestAgentLoadingAtom);
  const [agentData] = useAtom(agentDataAtom);
  const [selectedTools] = useAtom(selectedAgentToolsAtom);
  const params = new URLSearchParams(location.search);
  const editMode = params.get('action');
  const [agentCreationLoading] = useAtom(agentCreationLoadingAtom);
  const [nodes] = useAtom(nodesAtom);

  const [modalSettings, setModalSettings] = useState<AgentModalSettings | null>(
    null
  );
  const [openTutorial, setOpenTutorial] = useState(false);

  const enableSubmit = useMemo(() => {
    const nameDescFulfilled = !!agentData.name && !!agentData.description;

    if (!isPro)
      return (
        nameDescFulfilled &&
        !!agentData.instruction &&
        selectedTools.length > 0 &&
        !upsertLoading
      );

    return nameDescFulfilled && !upsertLoading;
  }, [
    agentData.name,
    agentData.description,
    agentData.instruction,
    isPro,
    selectedTools.length,
    upsertLoading,
  ]);

  const handleConfirmRejection = () => {
    setModalSettings({
      type: EButtonType.DELETE,
      open: true,
      handleCancel: () => setModalSettings(null),
      handleConfirm: () => {
        handleUpsertAgent(EChatAgentStatus.REJECTED);
        setModalSettings(null);
      },
      title: t('agent.rejectTitle'),
      confirmText: t('agent.rejectConfirm'),
      contentChildren: <AgentRejectContent />,
    });
  };

  const handleConfirmUpdateDeployed = () => {
    setAgentReasonChange('');
    setModalSettings({
      type: EButtonType.DEFAULT,
      open: true,
      handleCancel: () => setModalSettings(null),
      handleConfirm: () => {
        handleUpsertAgent(EChatAgentStatus.DEPLOYED);
        setModalSettings(null);
      },
      title: t('changeDeployedAgent.title'),
      confirmText: t('changeDeployedAgent.confirmText'),
      contentChildren: <AgentDeployMessageContent />,
    });
  };

  const handleSettingDeployment = () => {
    setModalSettings({
      type: EButtonType.DEFAULT,
      open: true,
      handleCancel: () => setModalSettings(null),
      handleConfirm: () => {
        const usageScopeStore = store.get(selectedUsageScopeAtom);
        handleUpsertAgent(EChatAgentStatus.DEPLOYED, usageScopeStore);
        setModalSettings(null);
      },
      title: t('agent.buttonTitle.register'),
      confirmText: t('agent.buttonTitle.register2'),
      contentChildren: <DeployAgentModalBody />,
    });
  };

  const renderButtonsLeft = () => {
    if (paths.isAgentRegistration || paths.isAgentLKMRegistration) {
      return (
        <button
          className={styles.tempSaveBtn}
          onClick={() => !isTempSaveLoading && handleConfirmRejection()}
          type='button'
        >
          {isTempSaveLoading && <RefreshIcon className={styles.loadingBtn} />}
          {t(`agent.buttonTitle.companion`)}
        </button>
      );
    }

    if (!isAgentAdminPage) {
      const isDisableSaveBtn =
        !enableSubmit ||
        agentCreationLoading ||
        isTempSaveLoading ||
        isTestAgentLoading ||
        nodes.length === 0;

      return (
        <Button
          variant='text'
          className={cn(
            styles.button,
            isDisableSaveBtn ? styles.disabledSubmit : styles.enabledSubmit
          )}
          disabled={isDisableSaveBtn}
          onClick={() => handleUpsertAgent(EChatAgentStatus.SAVED)}
        >
          {isTempSaveLoading && <RefreshIcon className={styles.loadingBtn} />}
          {t('agent.buttonTitle.tempSave')}
        </Button>
      );
    }
  };

  const renderButtonsRight = () => {
    if (isPro) {
      // testing 상태일 때는 게시하기 버튼
      if (
        (agentDetail?.rawData.review_status === EChatAgentStatus.SAVED &&
          !editMode) ||
        agentDetail?.rawData.review_status === EChatAgentStatus.TESTING
      ) {
        return (
          <button
            className={cn(
              styles.registerBtn,
              enableSubmit ? styles.enabledSubmit : styles.disabledSubmit
            )}
            onClick={(e) => handleOpenMenu(e)}
            disabled={!enableSubmit}
            type='button'
          >
            {t(`agent.buttonTitle.post`)}
            <DropdownIcon />
          </button>
        );
      }

      // 그 외 상태에는 에이전트 테스트 버튼
      const isDisableTestRegisterBtn =
        !enableSubmit ||
        agentCreationLoading ||
        isTestAgentLoading ||
        isTempSaveLoading;

      return (
        <Button
          variant='text'
          className={cn(
            styles.button,
            isDisableTestRegisterBtn
              ? styles.disabledSubmit
              : styles.enabledSubmit
          )}
          disabled={isDisableTestRegisterBtn}
          onClick={() => handleUpsertAgent(EChatAgentStatus.TESTING)}
        >
          {isTestAgentLoading ? (
            <RefreshIcon className={styles.loadingBtn} />
          ) : (
            <DataFlowIcon />
          )}
          {t('agent.buttonTitle.testing')}
        </Button>
      );
    }

    // adm-02#2
    if (paths.isAgentOperation || paths.isAgentLKMOperation) {
      return (
        <button
          className={cn(styles.registerBtn, styles.enabledSubmit)}
          onClick={() => !upsertLoading && handleConfirmUpdateDeployed()}
          type='button'
        >
          {t(`changeDeployedAgent.title`)}
        </button>
      );
    }

    // adm-02#1
    if (paths.isAgentRegistration || paths.isAgentLKMRegistration) {
      return (
        <button
          className={cn(styles.registerBtn, styles.enabledSubmit)}
          onClick={() => !upsertLoading && handleSettingDeployment()}
          type='button'
        >
          {t(`agent.buttonTitle.approvePost`)}
        </button>
      );
    }

    return (
      <button
        className={cn(
          styles.registerBtn,
          enableSubmit ? styles.enabledSubmit : styles.disabledSubmit
        )}
        onClick={(e) => handleOpenMenu(e)}
        disabled={!enableSubmit}
        type='button'
      >
        {t(`agent.buttonTitle.post`)}
        <DropdownIcon />
      </button>
    );
  };

  const handleOpenTutorial = () => {
    setOpenTutorial(true);
  };
  const handleCloseTutorial = () => {
    setOpenTutorial(false);
  };

  return (
    <>
      <Box className={styles.buttonContainer}>
        {!location.pathname.includes('/settings') && (
          <button
            className={styles.tutorialBtn}
            onClick={() => handleOpenTutorial()}
            type='button'
          >
            <TutorialIcon />
            {isPro ? t(`tutorialFM`) : t(`tutorialBM`)}
          </button>
        )}

        {renderButtonsLeft()}

        {!paths.isAgentOperation && !paths.isAgentLKMOperation && (
          <Box className={styles.rectangle} />
        )}

        {renderButtonsRight()}
      </Box>

      {modalSettings && <AgentAdminConfirmDialog {...modalSettings} />}

      {openTutorial && (
        <TutorialModal
          onClose={handleCloseTutorial}
          mode={isPro ? TutorialMode.FLOW : TutorialMode.BASIC}
        />
      )}
    </>
  );
};
