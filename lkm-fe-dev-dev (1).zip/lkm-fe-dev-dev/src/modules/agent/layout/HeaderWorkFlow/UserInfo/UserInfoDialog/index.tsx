import CloseIcon from '@/assets/basic-icons/icon-close.svg?react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Link,
  Table,
  TableBody,
  TableCell,
  TableRow,
} from '@mui/material';
import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

interface UserInfoDialogProps {
  open: boolean;
  onClose: () => void;
  name?: string;
  company?: string;
  email?: string;
}

export const UserInfoDialog: React.FC<UserInfoDialogProps> = ({
  open,
  onClose,
  name = '',
  company = '',
  email = '',
}) => {
  const { t } = useTranslation('tax');

  return (
    <Dialog
      open={open}
      onClose={onClose}
      PaperProps={{
        className: styles.dialog,
      }}
    >
      <DialogTitle className={styles.title}>
        {t('agent.modal.userInfo.title')}
        <IconButton
          onClick={onClose}
          className={styles.closeButton}
          size='small'
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent className={styles.content}>
        <Table className={styles.table}>
          <TableBody>
            <TableRow>
              <TableCell className={styles.tableCellTitle}>
                {t('agent.modal.userInfo.name')}
              </TableCell>
              <TableCell className={styles.tableCellValue}>{name}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className={styles.tableCellTitle}>
                {t('agent.modal.userInfo.company')}
              </TableCell>
              <TableCell className={styles.tableCellValue}>{company}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className={styles.tableCellTitle}>
                {t('agent.modal.userInfo.email')}
              </TableCell>
              <TableCell className={styles.tableCellValue}>
                <Link href={`mailto:${email}`}>{email}</Link>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </DialogContent>

      <DialogActions className={styles.actions}>
        <Button
          onClick={onClose}
          variant='outlined'
          className={styles.buttonSubmit}
        >
          {t('close')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
