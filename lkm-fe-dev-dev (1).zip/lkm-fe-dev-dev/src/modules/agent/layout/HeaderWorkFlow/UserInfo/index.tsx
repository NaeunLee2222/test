import ChevronRightIcon from '@/assets/direction-icons/icon-chevron-right.svg?react';
import { useUserDetailQuery } from '@/modules/core/hooks';
import { Avatar, ButtonBase } from '@mui/material';
import { useAtom } from 'jotai';
import { useState } from 'react';
import styles from '../index.module.scss';
import { UserInfoDialog } from './UserInfoDialog';

export const HeaderWorkflowUserInfo = () => {
  const [{ data }] = useAtom(useUserDetailQuery);

  const [openUserInfoDialog, setOpenUserInfoDialog] = useState<boolean>(false);

  return (
    <>
      <ButtonBase
        className={styles.avatarButton}
        onClick={() => setOpenUserInfoDialog(true)}
      >
        <Avatar className={styles.avatar}>
          {data?.username?.split('')?.[0]}
        </Avatar>
        <span className={styles.name}>by {data?.username}</span>
        <ChevronRightIcon width='20px' height='20px' />
      </ButtonBase>

      <UserInfoDialog
        open={openUserInfoDialog}
        onClose={() => setOpenUserInfoDialog(false)}
        name={data?.username}
        company={data?.company?.name}
        email={data?.email}
      />
    </>
  );
};
