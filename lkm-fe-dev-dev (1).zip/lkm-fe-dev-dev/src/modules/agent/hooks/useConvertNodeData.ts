import {
  edgeType,
  horizontalNodeGap,
  nodeTypeDef,
  verticalNodeGap,
} from '@/modules/agent/constant/agent';
import { edgesAtom, nodesAtom } from '@/modules/agent/jotai/agent';
import { IChatAgentStepActionResponse } from '@/modules/chat/types/agents';
import { getRandomColor } from '@/utils/agentUtil';
import { Node } from '@xyflow/react';
import { useSetAtom } from 'jotai';
import { useCallback } from 'react';
import { v4 as uuid } from 'uuid';

export const useConvertNodeData = () => {
  const setNodes = useSetAtom(nodesAtom);
  const setEdges = useSetAtom(edgesAtom);

  const convertData = useCallback(
    (steps: any) => {
      if (!steps?.length) return [];

      const nodeData: Node[] = steps.map((step: any, index: number) => {
        const newNodeId = uuid();

        return {
          id: step.id ?? newNodeId,
          type: nodeTypeDef,
          data: {
            id: step.id ?? newNodeId,
            name: step.name,
            iconColor: getRandomColor(),
            order: step.order,
            isNew: false,
            description: step.description,
            listItems: step.actions.map(
              (action: IChatAgentStepActionResponse, actionIndex: number) => {
                // 액션에 툴이 존재하면 도구 자동 연동 설정
                let processedTools = action?.tools || [];

                // tool_group_id가 있는 경우 자동으로 도구 연동, MCP 타입은 직접 연동
                if (processedTools.length > 0) {
                  processedTools = processedTools.map((tool: any) => ({
                    ...tool,
                    tool_group_id: tool.tool_group_id || null,
                    // tool_group_id가 있거나 MCP 타입(tool_group_id가 null)인 경우 자동으로 선택
                    selected: tool.tool_group_id !== undefined,
                  }));
                }

                return {
                  ...action,
                  order: actionIndex,
                  id: action.id ?? uuid(),
                  tools: processedTools,
                };
              }
            ),
          },
          position: {
            x: horizontalNodeGap * index,
            y: verticalNodeGap,
          },
        };
      });

      const edgeData = steps.slice(1).map((step: any, index: number) => ({
        id: uuid(),
        source: steps[index].id,
        target: step.id,
        type: edgeType,
      }));

      setNodes(nodeData);
      setEdges(edgeData);

      return nodeData;
    },
    [setNodes, setEdges]
  );

  return { convertData };
};
