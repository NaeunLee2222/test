import DnDContext from '@/modules/agent/contexts/DnD';
import { useContext } from 'react';

export const useDnD = () => useContext(DnDContext);
