import {
  createChatFeedback,
  deleteFeedback,
  getConversationStarter,
  getFeedbacksByChat,
  getToolGroup,
  getToolGroupList,
  postAllStepAction,
} from '@/modules/agent/api/agent';
import {
  AgentDocumentDto,
  AgentDto,
  IActionStepRequest,
  IConversationStarterResponse,
  IFeedbackDto,
  IFeedbackResponse,
  IToolGroup,
  IToolGroupListResponse,
  IToolListResponse,
} from '@/modules/agent/type/agent';
import * as actions from '@/modules/chat/api/agents';
import {
  IChatAgentPutRequest,
  IChatAgentToolResponse,
} from '@/modules/chat/types/agents';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';

export const useAgentUpsertMutation = atomWithMutation((get) => ({
  mutationKey: ['agent'],
  mutationFn: async ({
    data,
    callback,
  }: {
    data: IChatAgentPutRequest;
    callback?: (success: boolean, response: any) => void;
  }) => {
    const response = data.agent.id
      ? await actions.updateAgent(data)
      : await actions.createAgent(data);
    callback?.(response?.data?.success ?? response?.success, response);

    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['agent'] });
  },
}));

export const useCreateBasicAgentMutation = atomWithMutation((get) => ({
  mutationKey: ['agent'],
  mutationFn: async ({
    data,
    callback,
  }: {
    data: AgentDto;
    callback: (success: boolean, response: any) => void;
  }) => {
    const response = await actions.createBasicAgent(data);
    callback(response?.data?.success || response?.success, response);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['agent'] });
  },
  onSuccess: () => {},
}));

export const useAgentDocumentMutation = atomWithMutation((get) => ({
  mutationKey: ['agent', 'document'],
  mutationFn: async ({
    data,
    callback,
  }: {
    data: AgentDocumentDto;
    callback: (success: boolean, response: any) => void;
  }) => {
    const formData = new FormData();
    if (data.uploaded_user_id) {
      formData.append('uploaded_user_id', data.uploaded_user_id.toString());
    }

    formData.append('file', data.file);
    const response = await actions.uploadAgentDocument(data.path, formData);
    callback(response?.data?.success ?? response?.success ?? false, response);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['agent', 'document'] });
  },
}));

export const useToolList = atomWithQuery(() => ({
  queryKey: ['agent', 'tool', 'step'],
  queryFn: async () => actions.getAgentTools(),
  select: (data: IToolListResponse | null) => {
    if (!data?.data?.success && !data?.success) return null;

    const tools: IChatAgentToolResponse[] = (
      data?.data?.tools ||
      data?.tools ||
      []
    ).map((tool) => ({
      id: tool.id,
      name: tool.name,
      description: tool.description,
      type: tool.type,
      config: tool.config,
      created_at: tool.created_at,
      icon_path: tool.icon_path,
    }));
    return [...tools];
  },
}));

export const useToolGroupList = atomWithQuery(() => ({
  queryKey: ['agent', 'tool'],
  queryFn: async () => getToolGroupList(),
  select: (data: IToolGroupListResponse | null) => {
    if (!data?.data?.success && !data?.success) return null;

    const tools: IToolGroup[] = (
      data?.data?.tool_groups ||
      data?.tool_groups ||
      []
    ).map((tool) => ({
      id: tool.id,
      name: tool.name,
      description: tool.description,
      created_at: tool.created_at,
      updated_at: tool.updated_at,
      is_visible: Boolean(tool.is_visible),
      config: tool.config,
      endpoint: tool.endpoint,
      tool_group_id: tool.tool_group_id,
      tool_group_name: tool.tool_group_name,
    }));

    return [...tools];
  },
}));

export const useToolGroupDetail = (id: number | undefined) =>
  atomWithQuery(() => ({
    queryKey: ['agent', 'tool', id],
    queryFn: async ({ queryKey }) => {
      const [, , toolId] = queryKey;
      return getToolGroup(toolId as number);
    },
    select: (data: IToolGroup[]) => {
      if (!data) return null;

      const tools: IToolGroup[] = data.map((tool) => ({
        id: tool.id,
        name: tool.name,
        description: tool.description,
        created_at: tool.created_at,
        updated_at: tool.updated_at,
        is_visible: Boolean(tool.is_visible),
        config: tool.config,
        endpoint: tool.endpoint,
        tool_group_id: tool.tool_group_id,
        tool_group_name: tool.tool_group_name,
      }));

      return [...tools];
    },
    enabled: !!id,
  }));

export const useRecommendStepActionMutation = atomWithMutation((get) => ({
  mutationKey: ['agent'],
  mutationFn: async ({ data }: { data: IActionStepRequest }) => {
    const response = await postAllStepAction(data);

    return response?.data ?? response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['agent'] });
  },
}));

export const useGetConversationStarter = (agent_id: string) =>
  atomWithQuery(() => ({
    queryKey: ['agent', 'conversation_starter', agent_id],
    queryFn: async ({ queryKey }) => {
      const [, , agentId] = queryKey;
      const response = await getConversationStarter(agentId);
      return response;
    },
    select: (data: IConversationStarterResponse | null) => {
      if (!data?.data?.success && !data?.success) return null;
      const response = data?.data?.starter || data?.starter;
      return response;
    },
    enabled: !!agent_id,
  }));

export const useGetFeedback = (id: string) =>
  atomWithQuery(() => ({
    queryKey: ['agent', 'feedback', id],
    queryFn: async ({ queryKey }) => {
      const [, , chatId] = queryKey;
      const data = await getFeedbacksByChat(chatId);
      return data;
    },
    select: (data: IFeedbackResponse | null) => data?.data ?? [],
    enabled: !!id && id !== '-1',
  }));

export const useDeleteFeedback = atomWithMutation((get) => ({
  mutationKey: ['agent', 'feedback', 'delete'],
  mutationFn: async ({
    messageId,
    feedbackId,
  }: {
    messageId: string;
    feedbackId: number;
  }) => {
    const response = await deleteFeedback(messageId, feedbackId);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({
      queryKey: ['agent', 'feedback', 'delete'],
    });
  },
}));

export const useCreateFeedback = atomWithMutation((get) => ({
  mutationKey: ['agent', 'feedback', 'create'],
  mutationFn: async ({
    feedback,
    callback,
  }: {
    feedback: IFeedbackDto;
    callback?: (response: any) => void;
  }) => {
    const response = await createChatFeedback(feedback);
    callback && callback(response);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({
      queryKey: ['agent', 'feedback', 'create'],
    });
  },
}));
