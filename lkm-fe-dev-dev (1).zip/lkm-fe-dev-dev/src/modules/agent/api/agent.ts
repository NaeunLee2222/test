import {
  IActionStepRequest,
  IActionStepResponse,
  IConversationStarterResponse,
  IDeleteAgent,
  IFeedbackDto,
  IFeedbackResponse,
  IListStepActionsResponse,
  IToolGroupListResponse,
  ITools,
  type IToolGroup,
} from '@/modules/agent/type/agent';
import { agentInstance, chatInstance } from '@/modules/core/libs';

const URL_PREFIX_STEP_ACTIONS = '/search_step_name/actions';
const URL_PREFIX_TOOLS = '/search_action_name/tools';
const URL_AGENT_PREFIX = '/agents';
const URL_CHAT_PREFIX = '/chats';
const URL_MESSAGES_PREFIX = '/messages';
const URL_FEEDBACK_PREFIX = '/feedback';
const URL_PREFIX_TOOLS_GROUP = '/tool_groups';
const URL_GET_CHAT_STARTER = '/get_chat_starter';

export const getListStepActions = async (searchText?: string) => {
  const url = searchText
    ? `${URL_PREFIX_STEP_ACTIONS}?search_step_name=${searchText}`
    : `${URL_PREFIX_STEP_ACTIONS}`;
  try {
    const response: IListStepActionsResponse = await agentInstance.get(
      `${url}`
    );
    return response?.steps || [];
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getListTool = async (searchText?: string) => {
  const url = searchText
    ? `${URL_PREFIX_TOOLS}?search_action_name=${searchText}`
    : `${URL_PREFIX_TOOLS}`;
  try {
    const response: ITools = await agentInstance.get(`${url}`);
    return response?.actions || [];
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

/**
 * Uses AI to generate agent's recommended step and action for basic mode
 * @param payload
 * @returns
 */
export const postAllStepAction = async (
  payload: IActionStepRequest
): Promise<IActionStepResponse> => {
  try {
    const response: IActionStepResponse = await agentInstance.post(
      `/recommend_step_action`,
      payload,
      {
        headers: { 'content-type': 'multipart/form-data' },
      }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const deleteAgent = async (agent_id: number | string) => {
  try {
    const response: IDeleteAgent = await agentInstance.delete(
      `${URL_AGENT_PREFIX}/${agent_id}`
    );
    return response.data ?? response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getToolGroupList = async (): Promise<IToolGroupListResponse> => {
  try {
    const response: IToolGroupListResponse = await agentInstance.get(
      URL_PREFIX_TOOLS_GROUP
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getToolGroup = async (id: number): Promise<IToolGroup[]> => {
  try {
    const response: IToolGroup[] = await agentInstance.get(
      `${URL_PREFIX_TOOLS_GROUP}/${id}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getConversationStarter = async (
  agent_id: string
): Promise<IConversationStarterResponse> => {
  try {
    const response: IConversationStarterResponse = await agentInstance.get(
      `${URL_GET_CHAT_STARTER}?agent_id=${agent_id}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const createChatFeedback = async (feedback: IFeedbackDto) => {
  try {
    const response = await chatInstance.post(
      `${URL_CHAT_PREFIX}${URL_MESSAGES_PREFIX}${URL_FEEDBACK_PREFIX}`,
      feedback
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getFeedbacksByChat = async (
  chatId: string
): Promise<IFeedbackResponse> => {
  try {
    const response: IFeedbackResponse = await chatInstance.get(
      `${URL_CHAT_PREFIX}${URL_MESSAGES_PREFIX}${URL_FEEDBACK_PREFIX}/${chatId}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const deleteFeedback = async (messageId: string, feedbackId: number) => {
  try {
    const response = await chatInstance.delete(
      `${URL_CHAT_PREFIX}${URL_MESSAGES_PREFIX}/${messageId}${URL_FEEDBACK_PREFIX}/${feedbackId}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};
