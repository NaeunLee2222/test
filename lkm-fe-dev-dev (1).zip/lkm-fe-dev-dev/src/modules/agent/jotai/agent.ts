import {
  AgentCreationModel,
  AgentType,
  IToolModel,
} from '@/modules/agent/type/agent';
import { Edge, Node } from '@xyflow/react';
import { atom } from 'jotai';
import { ReactNode } from 'react';

// ==============================
// React Flow
// ==============================
export const nodesAtom = atom<Node[]>([]);
export const edgesAtom = atom<Edge[]>([]);

// ==============================
// Canvas State
// ==============================
export const agentCanvasOpenAtom = atom(false);
export const reloadCanvasById = atom(true);

// ==============================
// Agent Info and State
// ==============================
export const agentAtom = atom<AgentCreationModel>({});
export const agentDataAtom = atom(
  (get) => get(agentAtom),
  (get, set, update: Partial<AgentCreationModel>) => {
    set(agentAtom, {
      ...get(agentAtom),
      ...update,
    });
  }
);
export const agentMode = atom<AgentType>(AgentType.GENERAL);
export const agentIdForUpdating = atom<string>('');
export const generalAgentIdAtom = atom('');
export const agentReasonChangeAtom = atom<string>('');
export const agentIdAtom = atom<number | null>(null);

// ==============================
// Agent Tools
// ==============================
export const agentToolListAtom = atom<IToolModel[]>([]);
export const selectedAgentToolsAtom = atom<IToolModel[]>([]);

// ==============================
// Agent Dialog
// ==============================
export const agentCreationDialog = atom<{
  dialogOpen: boolean;
  dialogTitle: string;
  contentChildren?: ReactNode;
  actionsChildren?: ReactNode;
  height?: string;
  width?: string;
  hideClose?: boolean;
}>({
  dialogOpen: false,
  dialogTitle: '',
  contentChildren: null,
  actionsChildren: null,
  height: undefined,
  width: undefined,
  hideClose: undefined,
});

export const agentCreationDialogDataAtom = atom(
  (get) => get(agentCreationDialog),
  (
    get,
    set,
    update: Partial<{
      dialogOpen: boolean;
      dialogTitle: string;
      contentChildren?: ReactNode;
      actionsChildren?: ReactNode;
      height?: string;
      width?: string;
      hideClose?: boolean;
    }>
  ) => {
    set(agentCreationDialog, {
      ...get(agentCreationDialog),
      ...update,
    });
  }
);

// ==============================
// UI State
// ==============================
export const slidePreviewOpenAtom = atom(false);
export const isCanUndoAtom = atom<boolean>(false);
export const isCanRedoAtom = atom<boolean>(false);
export const agentChatOpenAtom = atom(true);
export const agentSettingExpandedAtom = atom<boolean>(false);

// ==============================
// Loading States
// ==============================
export const agentCreationLoadingAtom = atom<boolean>(false);
export const agentUpsertLoadingAtom = atom<boolean>(false);
export const isTestAgentLoadingAtom = atom<boolean>(false);

// ==============================
// Starter / Preset Templates
// ==============================
export const alreadyCreatedWorkflowAtom = atom<{
  name?: string;
  description?: string;
  starter: (string | null)[];
} | null>(null);

// ==============================
// Conversation Starter
// ==============================
export const conversationStarterAtom = atom<string[]>(['']);
export const hasRunChatStarterAtom = atom<boolean>(false);

// ==============================
// Suggestions / UX
// ==============================
export const agentInstructionSuggestionAtom = atom<string>('');
export const actionIdAtom = atom('');
export const showHeaderNodeAtom = atom<boolean>(false);
