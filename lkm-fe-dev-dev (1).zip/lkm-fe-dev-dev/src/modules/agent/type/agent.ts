import { ChatFeedbackType } from '@/modules/chat/components/ChatInput/constants';
import {
  AgentInstructionDto,
  IChatAgentResponse,
  IChatAgentToolResponse,
  type IChatAgentStepResponse,
} from '@/modules/chat/types/agents';

export interface AgentCreationModel {
  id?: any;
  name?: string;
  description?: string;
  type?: AgentType;
  instruction?: string;
  file?: File | null;
  fileId?: number;
  knowledgeFile?: File | null;
  rejectDescription?: string;
  usageScope?: UsageScope;
}

export interface AgentDto {
  agent: SingleAgentDto;
  steps: AgentStepDto[];
  document_id: number;
  general_agent_instruction: AgentInstructionDto;
  created_user_id: number;
  chat_starters?: string[];
}

export interface SingleAgentDto {
  id?: number;
  name: string;
  description: string;
  category: string;
  agent_type: AgentType;
  usage_scope: string;
  use_count?: number;
  org_id: number;
  team_id: number;
  created_user_id: number;
  steps: AgentStepDto[];
  review_status: string;
}

export interface AgentStepDto {
  name: string;
  description: string;
}

export interface AgentDocumentDto {
  path: string;
  file: File;
  uploaded_user_id?: number;
}

export interface IFileResponse {
  data: {
    success: boolean;
    message: string | null;
    original_filename: string;
    file_path: string;
    file_size: number;
    document: IAgentDocument;
  };

  success: boolean;
  message: string | null;
  original_filename: string;
  file_path: string;
  file_size: number;
  document: IAgentDocument;
}

export interface IAgentDocument {
  created_at: string;
  expert_agent_id: number | null;
  file_type: string;
  filename: string;
  id: number;
  original_filename: string;
  status: 'active' | 'inactive';
  updated_at: string | null;
  uploaded_user_id: number;
}

export interface IToolListResponse {
  data: {
    success: boolean;
    message: string;
    tools: IChatAgentToolResponse[];
  };

  success: boolean;
  message: string;
  tools: IChatAgentToolResponse[];
}

export interface IToolGroupListResponse {
  data: {
    success: boolean;
    message: string | null;
    tool_groups: IToolGroup[];
  };

  success: boolean;
  message: string | null;
  tool_groups: IToolGroup[];
}

export interface IToolGroupResponse {
  data: {
    success: boolean;
    message: string | null;
    tools: IToolGroup[];
  };

  success: boolean;
  message: string | null;
  tools: IToolGroup[];
}

export interface IActionStepResponse {
  data: {
    success: boolean;
    message: string;
    steps: IChatAgentStepResponse[];
  };

  success: boolean;
  message: string;
  steps: IChatAgentStepResponse[];
}

export interface IActionStepRequest {
  agent_name: string;
  agent_description: string;
  file?: File | null;
}

export interface IInstructionResponse {
  data: {
    success: boolean;
    message: string;
  };

  success: boolean;
  message: string;
}

export interface IGeneralToolResponse {
  data: {
    success: boolean;
    message: string;
    tools: IChatAgentToolResponse[];
  };

  success: boolean;
  message: string;
  tools: IChatAgentToolResponse[];
}

export interface IUsageResponse {
  id: number;
  user_id: number;
  org_id: number;
  user_limit: number;
  org_limit: number;
  query_text_limit: number;
  answer_token_limit: number;
}

export interface ICreateUsage {
  user_id: number;
  org_id: number;
  user_limit: number;
  org_limit: number;
  query_text_limit: number;
  answer_token_limit: number;
}

export interface IUpdateUsage {
  user_limit: number;
  org_limit: number;
  query_text_limit: number;
  answer_token_limit: number;
}

export interface IToolModel {
  id: number | null;
  name: string;
  description: string;
  type?: string;
  checked?: boolean;
}

export interface IAgentCreationResponse {
  data: {
    success: boolean;
    message: string;
    agent: IChatAgentResponse;
  };

  success: boolean;
  message: string;
  agent: IChatAgentResponse;
}

export interface IAgentGeneralResponse {
  data: {
    success: boolean;
    message: string;
    agent: IChatAgentResponse;
    instruction: string;
    tools: IChatAgentToolResponse[];
  };
  success: boolean;
  message: string;
  agent: IChatAgentResponse;
  instruction: string;
  tools: IChatAgentToolResponse[];
}

export enum AgentType {
  PRO = 'pro',
  GENERAL = 'general',
  MY_AGENT = 'my_agent',
  GENERAL_TEST = 'general_test',
}

export enum TutorialMode {
  BASIC = 'basic',
  FLOW = 'flow',
}

export enum UsageScope {
  PUBLIC = 'public',
  ORG = 'org',
  PERSONAL = 'personal',
}

export enum ModeType {
  DASHBOARD = 'dashboard',
  CHAT = 'chat',
  FEEDBACK = 'ai-feedback',
}

export enum OrderSort {
  NAME_ASC = 'name_asc',
  NAME_DESC = 'name_desc',
  POPULARITY = 'popularity',
  LATEST = 'latest',
  TITLE_ASC = 'title_asc',
  TITLE_DESC = 'title_desc',
}

type ToolLabel = {
  name: string;
  tool_group_id: number;
};

export type Item = {
  id: number | string;
  step_id?: number;
  name: string;
  order: number;
  description: string;
  tools: ToolLabel[];
  isNew?: boolean;
};

type Position = {
  x: number;
  y: number;
};

export interface AgentStepNodeData {
  id: string;
  position?: Position;
  iconColor: string;
  order: number;
  name: string;
  listItems: Item[];
  isNew?: boolean;
  isDragging?: boolean;
}

export interface IListStepActionsResponse {
  'success': true;
  'message': string | null;
  'steps': IStep[];
}

export interface IStep {
  'name': string;
  'iconColor'?: string;
  'description': string;
  'position'?: { x: number; y: number };
  'order': number;
  'id': number;
  'expert_agent_id': number;
  'created_at': string;
  'updated_at': string;
  'actions': IAction[];
}

export interface IAction {
  'name': string;
  'description': string;
  'order': number;
  'id': number | string;
  'step_id'?: number;
  'tools': any[];
}

export interface IToolGroup {
  'id': number;
  'name': string;
  'description': string;
  'created_at': string;
  'updated_at': string | null;
  'is_visible': boolean;
  'config': any;
  'endpoint': string;
  'tool_group_id': number;
  'tool_group_name': string;
}

export interface ITools {
  'success': true;
  'message': string | null;
  'actions': IAction[];
}

export interface IActionPost {
  name: string;
  description: string;
  tool_id: number;
}

export interface IDeleteAgent {
  data: {
    'success': boolean;
    'message': string;
  };
  'success': boolean;
  'message': string;
}

export interface IActionInfoRes {
  data: IActionInfo;
}

export interface IActionInfo {
  description: string;
  id: number;
  name: string;
  step_id: number;
  tools: IChatAgentToolResponse[];
}

export type CustomFile = File | null | undefined;

export interface BasicAgentExpansion {
  information?: boolean;
  recipe?: boolean;
}

export interface IConversationStarterResponse {
  data: {
    success: boolean;
    message: string;
    starter: string[];
  };

  success: boolean;
  message: string;
  starter: string[];
}

export interface IFeedbackResponse {
  data: IFeedbackData[];
}

export interface IFeedbackData {
  id: number;
  chat_message_id: string;
  feedback?: ChatFeedbackType;
  created_at: string;
}

export interface IFeedbackModel extends IFeedbackData {
  questionExpanded?: boolean;
  answerExpanded?: boolean;
  question: string;
  answer: string;
}

export interface IFeedbackDto {
  chat_message_id: string;
  feedback: ChatFeedbackType;
}

export interface IPaths {
  isAgentRegistration: boolean;
  isAgentLKMRegistration: boolean;
  isAgentOperation: boolean;
  isAgentLKMOperation: boolean;
  isAgentBasic: boolean;
}

export interface IAlreadyCreatedAgentGeneral {
  name?: string;
  description?: string;
  instruction?: string;
  tools: (number | null)[];
  starter: (string | null)[];
}
