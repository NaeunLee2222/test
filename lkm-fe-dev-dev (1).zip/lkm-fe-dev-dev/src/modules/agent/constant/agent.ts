export const nodeTypeDef = 'textUpdater'; // must be the same with property of nodeTypes
export const edgeType = 'invisible';

export const iconColors = [
  '#7f7f7f',
  '#40C057',
  '#00CDCC',
  '#4263EB',
  '#FA5252',
];

export const horizontalNodeGap = 300;
export const verticalNodeGap = 100;
export const miniMapGap = 50;

export const reactFlowNodeClass = 'react-flow__node';
export const actionCardClass = 'action-card';
export const stepIdAttribute = 'data-id';

export const fitViewStatistics = {
  padding: 0,
  maxZoom: 1,
  minZoom: 0.5,
};

export const orderRegex = /^order-\d+$/;
