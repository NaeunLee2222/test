import PencilIcon from '@/assets/basic-icons/icon-pencil.svg?react';
import PlusIcon from '@/assets/basic-icons/icon-plus.svg?react';
import TrashIcon from '@/assets/basic-icons/icon-trashcan.svg?react';
import { Button, Divider, IconButton } from '@mui/material';
import React from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

interface AgentStepNode {
  handleAdd: (e: React.MouseEvent) => void;
  handleEdit: (e: React.MouseEvent) => void;
  handleDelete: (e: React.MouseEvent) => void;
}

const AgentStepNodeMenu: React.FC<AgentStepNode> = ({
  handleAdd,
  handleEdit,
  handleDelete,
}) => {
  const { t } = useTranslation();

  return (
    <div className={styles.menu}>
      <Button
        variant='contained'
        color='primary'
        className={styles.addBtn}
        onClick={handleAdd}
        startIcon={
          <PlusIcon width='16' height='16' style={{ fill: 'white' }} />
        }
      >
        {t('agent.addStep')}
      </Button>

      <Divider orientation='vertical' flexItem className={styles.divider} />

      <IconButton
        color='default'
        className={styles.actionBtn}
        onClick={handleDelete}
      >
        <TrashIcon width='24' height='24' />
      </IconButton>

      <IconButton
        color='default'
        className={styles.actionBtn}
        onClick={handleEdit}
      >
        <PencilIcon width='24' height='24' />
      </IconButton>
    </div>
  );
};

export default AgentStepNodeMenu;
