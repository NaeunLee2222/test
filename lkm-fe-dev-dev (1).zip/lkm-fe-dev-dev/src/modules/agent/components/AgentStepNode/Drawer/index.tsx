import ArrowDownIcon from '@/assets/basic-icons/icon-arrow-down.svg?react';
import CloseIcon from '@/assets/basic-icons/icon-close.svg?react';
import ConeIcon from '@/assets/basic-icons/icon-cone.svg?react';
import QuestionIcon from '@/assets/basic-icons/icon-question.svg?react';
import SearchIcon from '@/assets/basic-icons/icon-search.svg?react';
import {
  useToolGroupDetail,
  useToolGroupList,
} from '@/modules/agent/hooks/useAgent';
import { Item } from '@/modules/agent/type/agent';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import {
  Button,
  Card,
  Divider,
  Drawer,
  FormControl,
  FormLabel,
  Grid,
  InputAdornment,
  ListSubheader,
  MenuItem,
  Select,
  TextField,
  Typography,
} from '@mui/material';
import { SelectChangeEvent } from '@mui/material/Select';
import { useReactFlow } from '@xyflow/react';
import { useAtom } from 'jotai';
import React, { useEffect, useMemo, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { v4 as uuid } from 'uuid';
import styles from './index.module.scss';

interface AgentStepDrawerProps {
  open: boolean;
  setOpen: (value: boolean) => void;
  item: Item | null;
  nodeId: string;
  listItems: Item[];
}

interface IFormValues {
  actionName: string;
  actionDetail: string;
  toolGroup: string;
  tool: string;
}

const initialFormState = {
  actionName: '',
  actionDetail: '',
  toolGroup: '',
  tool: '',
};

const AgentStepDrawer: React.FC<AgentStepDrawerProps> = ({
  open,
  setOpen,
  item,
  listItems,
  nodeId,
}) => {
  const { t } = useTranslation('tax');
  const { setNodes } = useReactFlow();
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
    reset,
    control,
    setValue,
    trigger,
  } = useForm<IFormValues>({
    mode: 'onChange',
    defaultValues: initialFormState,
  });

  const [toolGroup, setToolGroup] = useState({ name: '' });
  const [tool, setTool] = useState({ name: '' });
  const [groupToolId, setGroupToolId] = useState<number | undefined>(undefined);
  const [searchKeywordToolGroup, setSearchKeywordToolGroup] = useState('');
  const [searchKeywordTool, setSearchKeywordTool] = useState('');

  const [{ data: groupToolData }] = useAtom(useToolGroupList);
  const [{ data: toolData }] = useAtom(
    useMemo(() => useToolGroupDetail(groupToolId), [groupToolId])
  );

  const toolGroups = useMemo(
    () =>
      groupToolData?.map((i) => ({ value: i.name, label: i.name, id: i.id })) ??
      [],
    [groupToolData]
  );

  const tools = useMemo(
    () => toolData?.map((i) => ({ value: i.name, label: i.name })) ?? [],
    [toolData]
  );

  const filteredToolGroup = useMemo(
    () =>
      toolGroups.filter((z) =>
        z.label.toLowerCase().includes(searchKeywordToolGroup.toLowerCase())
      ),
    [searchKeywordToolGroup, toolGroups]
  );

  const filteredTool = useMemo(
    () =>
      tools.filter((z) =>
        z.label.toLowerCase().includes(searchKeywordTool.toLowerCase())
      ),
    [searchKeywordTool, tools]
  );

  // reset data when close drawer
  useEffect(() => {
    if (!open) {
      resetData();
    }
  }, [open]);

  // set data when get data from api
  useEffect(() => {
    if (item && groupToolData) {
      const firstTool = item?.tools?.[0];

      // tool_group_id가 있는 경우에만 그룹 툴 이름을 찾음
      const groupToolName = firstTool?.tool_group_id
        ? (groupToolData?.find(
            (groupTool) => groupTool?.id === firstTool.tool_group_id
          )?.name ?? '')
        : '';

      reset({
        actionName: item?.name ?? '',
        actionDetail: item?.description ?? '',
        toolGroup: groupToolName ?? '',
        tool: firstTool?.name ?? '',
      });

      setToolGroup({ name: groupToolName ?? '' });
      setTool({
        name: firstTool?.name ?? '',
      });

      // tool_group_id 설정 (null도 유효한 값으로 처리)
      setGroupToolId(firstTool?.tool_group_id ?? undefined);

      // 폼 유효성 검사 트리거
      setTimeout(() => {
        trigger('actionName');
        trigger('actionDetail');
        // tool_group_id가 있는 경우에만 툴 그룹 검증
        if (
          firstTool?.tool_group_id !== null &&
          firstTool?.tool_group_id !== undefined
        ) {
          trigger('toolGroup');
        }
        trigger('tool');
      }, 100);
    } else {
      resetData();
    }
  }, [groupToolData, item, open]);

  // trigger tool when group tool is not empty
  useEffect(() => {
    if (toolGroup.name !== '') {
      trigger('tool');
    }
  }, [toolGroup.name, trigger]);

  // choose first tool after choose group tool
  useEffect(() => {
    if (
      item?.tools?.[0]?.name !== '' &&
      item?.tools?.[0]?.tool_group_id === null &&
      toolData &&
      toolData.length > 0
    ) {
      const firstTool = toolData[0];

      setTool({ name: firstTool.name });
      setValue('tool', firstTool.name);
      trigger('tool');
    } else if (!toolData || toolGroup.name === '') {
      setTool({ name: '' });
      setValue('tool', '');
      trigger('tool');
    }
  }, [toolData, toolGroup.name, trigger]);

  const resetData = () => {
    reset(initialFormState);
    setToolGroup({ name: '' });
    setTool({ name: '' });
    setGroupToolId(undefined);
  };

  const onSubmit = (data: IFormValues) => {
    let toolUpdated: any[];

    // tool_group_id가 null인 경우 (MCP 타입 툴 등) 원래 툴 정보를 사용
    if (item?.tools?.[0]?.tool_group_id === null && tool.name) {
      // MCP 타입 툴의 경우 원래 툴 정보 그대로 사용
      toolUpdated = item.tools
        .filter((t) => t.name === tool.name)
        .map((t) => ({
          ...t,
          selected: true, // 자동으로 선택된 상태로 설정
        }));
    } else if (groupToolId && tool.name) {
      // 일반적인 경우: toolData에서 찾아서 사용
      toolUpdated =
        toolData
          ?.filter((toolItem) => toolItem.name === tool.name)
          .map((toolItem) => ({
            ...toolItem,
            tool_group_id: toolItem.tool_group_id ?? groupToolId,
            selected: true, // 자동으로 선택된 상태로 설정
          })) || [];
    } else {
      // 도구가 선택되지 않은 경우
      toolUpdated = [];
    }

    const lastActionOrder = listItems[listItems.length - 1].order;

    const updatedItem = {
      id: item ? item.id : uuid(),
      name: data.actionName,
      description: data.actionDetail,
      order: lastActionOrder + 1,
      tools: toolUpdated,
      isNew: true,
    };

    const updatedListItems = item
      ? listItems.map((i) => (i.id === item.id ? updatedItem : i))
      : [...listItems, updatedItem];

    setNodes((prevNodes) =>
      prevNodes.map((node) =>
        node.data.id === nodeId
          ? { ...node, data: { ...node.data, listItems: updatedListItems } }
          : node
      )
    );

    setOpen(false);
  };

  const handleDelete = () => {
    if (!item) return;

    const updatedListItems = listItems.filter(
      (action) => action.id !== item.id
    );

    setNodes((prevNodes) =>
      prevNodes.map((node) =>
        node.id === nodeId
          ? { ...node, data: { ...node.data, listItems: updatedListItems } }
          : node
      )
    );

    setOpen(false);
  };

  const handleGroupToolChange = (event: SelectChangeEvent<string>) => {
    const selectedName = event.target.value;
    setToolGroup({ name: selectedName });
    setValue('toolGroup', selectedName);

    const selectedToolGroup = toolGroups.find(
      (group) => group.value === selectedName
    );

    // Only update if the ID actually changed
    if (selectedToolGroup?.id && selectedToolGroup.id !== groupToolId) {
      setGroupToolId(selectedToolGroup.id);
    }
  };

  const closeDrawer = () => {
    setOpen(false);
    setNodes((nodes) => nodes.map((node) => ({ ...node, selected: false })));
  };

  return (
    <Drawer
      anchor='right'
      open={open}
      onClose={() => closeDrawer()}
      className={styles.drawerWrapper}
    >
      <Typography variant='h6' className={styles.drawerHeader}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <ConeIcon />
          {t('action')}
        </div>

        <Button
          variant='text'
          className={styles.closeBtn}
          onClick={() => closeDrawer()}
        >
          <CloseIcon fill='black' width='18' height='18' />
        </Button>
      </Typography>

      <Divider style={{ margin: 0 }} />

      <form
        className={styles.drawerForm}
        onSubmit={handleSubmit(onSubmit)}
        noValidate
      >
        <FormControl fullWidth margin='normal' className={styles.formItem}>
          <FormLabel htmlFor='actionName' className={styles.label}>
            {t('actionForm.actionName')}
            <span className={styles.required}>*</span>
            <QuestionIcon />
          </FormLabel>

          <TextField
            id='actionName'
            {...register('actionName', {
              required: `${t('actionForm.actionName')} ${t('validate.required')}`,
            })}
            placeholder={t('actionForm.actionNamePlaceholder')}
            error={!!errors.actionName}
            helperText={errors.actionName?.message}
            fullWidth
            size='small'
            sx={{
              'input': {
                padding: '10px 12px',
                fontSize: '14px',
              },
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: 'var(--gray-150)',
                },
              },
              '> div': {
                borderRadius: '6px',
              },
            }}
          />
        </FormControl>

        <FormControl
          fullWidth
          margin='normal'
          className={styles.formItem}
          size='small'
        >
          <FormLabel htmlFor='actionDetail' className={styles.label}>
            {t('actionForm.actionFeature')}
            <span className={styles.required}>*</span>
            <QuestionIcon />
          </FormLabel>

          <TextField
            id='actionDetail'
            {...register('actionDetail', {
              required: t('actionForm.actionFeature') + t('validate.required'),
            })}
            placeholder={t('actionForm.actionFeaturePlaceholder')}
            multiline
            rows={4}
            error={!!errors.actionDetail}
            helperText={errors.actionDetail?.message}
            fullWidth
            size='small'
            sx={{
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: 'var(--gray-150)',
                },
              },
              '> div': {
                borderRadius: '8px',
              },
              '> *.MuiInputBase-root': {
                padding: '0px',
                'textarea': {
                  padding: '10px 12px',
                  fontSize: '14px',
                },
              },
            }}
          />
        </FormControl>

        <Divider className={styles.divider} />

        <FormControl
          fullWidth
          size='small'
          className={styles.formItem}
          style={toolGroup.name !== '' ? { marginBottom: '8px' } : {}}
        >
          <FormLabel htmlFor='tool' className={styles.label}>
            {t('actionForm.toolLinkage')}{' '}
            <span className={styles.required}>*</span>
            <QuestionIcon className={styles.questionIcon} />
          </FormLabel>

          <Controller
            name='toolGroup'
            control={control}
            rules={{
              validate: (value) => {
                // tool_group_id가 null인 경우 (MCP 타입 등) 검증 스킵
                if (item?.tools?.[0]?.tool_group_id === null) {
                  return true;
                }
                // 일반적인 경우 필수 검증
                return value
                  ? true
                  : t('actionForm.toolLinkage') + t('validate.required');
              },
            }}
            render={({ field }) => (
              <Select
                {...field}
                labelId='search-select-label'
                id='search-select'
                variant='outlined'
                value={field.value ?? ''}
                onChange={(e) => {
                  field.onChange(e);
                  handleGroupToolChange(e);
                }}
                onClose={() => {
                  setSearchKeywordToolGroup('');
                }}
                displayEmpty
                renderValue={(selected) => {
                  if (selected === '') {
                    return (
                      <span className={styles.toolPlaceholder}>도구 선택</span>
                    );
                  }
                  return selected;
                }}
                IconComponent={ArrowDownIcon}
                MenuProps={{
                  autoFocus: true,
                  PaperProps: {
                    className: 'app-tool-select-dropdown',
                  },
                }}
                sx={{
                  '> div': {
                    padding: '10px 12px',
                    fontSize: '14px',
                  },
                  '& fieldset': {
                    border: '1px solid var(--gray-150)',
                    borderRadius: '6px',
                  },
                  '& .MuiSelect-icon': {
                    right: '12px',
                    top: '11px',
                  },
                }}
              >
                <ListSubheader className={styles.searchTool}>
                  <TextField
                    size='small'
                    autoFocus
                    placeholder={t('actionForm.toolLinkageSearch')}
                    fullWidth
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position='start'>
                          <SearchIcon />
                        </InputAdornment>
                      ),
                    }}
                    onChange={(e) => setSearchKeywordToolGroup(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key !== 'Escape') {
                        e.stopPropagation();
                      }
                    }}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        fontSize: '14px',
                        '& fieldset': {
                          border: '1px solid var(--gray-150)',
                          borderRadius: '6px',
                        },
                      },
                    }}
                  />
                </ListSubheader>
                {filteredToolGroup.map((z) => (
                  <MenuItem
                    key={z.id}
                    value={z.value}
                    className={styles.toolItem}
                  >
                    {z.label}
                  </MenuItem>
                ))}
              </Select>
            )}
          />

          {errors.toolGroup && (
            <Typography
              color='error'
              variant='caption'
              sx={{ marginLeft: '14px' }}
            >
              {errors.toolGroup.message}
            </Typography>
          )}
        </FormControl>

        {(toolGroup.name !== '' ||
          (item?.tools?.[0]?.tool_group_id === null &&
            item?.tools?.[0]?.name)) && (
          <FormControl
            fullWidth
            size='small'
            className={styles.formItem}
            error={!!errors.tool}
          >
            {(toolGroup.name !== '' ||
              (item?.tools?.[0]?.tool_group_id === null &&
                item?.tools?.[0]?.name)) && (
              <Controller
                name='tool'
                control={control}
                rules={{
                  validate: (value) => {
                    // tool_group_id가 null인 경우 (MCP 타입 등) 검증 스킵
                    if (item?.tools?.[0]?.tool_group_id === null) {
                      return true;
                    }
                    // 일반적인 경우 필수 검증
                    return value
                      ? true
                      : t('actionForm.toolLinkage') + t('validate.required');
                  },
                }}
                render={({ field }) => (
                  <Select
                    {...field}
                    labelId='search-select-label2'
                    id='search-select2'
                    value={field.value ?? ''}
                    onChange={(e) => {
                      field.onChange(e);
                      setTool({ name: e.target.value });
                    }}
                    onClose={() => {
                      setSearchKeywordTool('');
                    }}
                    displayEmpty
                    renderValue={(selected) => {
                      if (selected === '') {
                        return (
                          <span className={styles.toolPlaceholder}>
                            도구 선택
                          </span>
                        );
                      }
                      return selected;
                    }}
                    IconComponent={ArrowDownIcon}
                    MenuProps={{
                      autoFocus: false,
                      PaperProps: {
                        className: 'app-tool-select-dropdown',
                      },
                    }}
                    sx={{
                      '> div': {
                        padding: '10px 12px',
                        fontSize: '14px',
                      },
                      '& fieldset': {
                        border: '1px solid var(--gray-150)',
                        borderRadius: '6px',
                      },
                      '& .MuiSelect-icon': {
                        right: '12px',
                        top: '11px',
                      },
                    }}
                    variant='outlined'
                  >
                    <ListSubheader className={styles.searchTool}>
                      <TextField
                        size='small'
                        autoFocus
                        placeholder={t('actionForm.toolLinkageSearch')}
                        fullWidth
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position='start'>
                              <SearchIcon />
                            </InputAdornment>
                          ),
                        }}
                        onChange={(e) => setSearchKeywordTool(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key !== 'Escape') {
                            e.stopPropagation();
                          }
                        }}
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            fontSize: '14px',
                            '& fieldset': {
                              borderColor: 'var(--gray-150)',
                            },
                          },
                        }}
                      />
                    </ListSubheader>

                    {/* tool_group_id가 null인 경우 현재 툴을 직접 표시 */}
                    {item?.tools?.[0]?.tool_group_id === null &&
                    item?.tools?.[0]?.name ? (
                      <MenuItem
                        key={item.tools[0].name}
                        value={item.tools[0].name}
                        className={styles.toolItem}
                      >
                        {item.tools[0].name}
                      </MenuItem>
                    ) : (
                      filteredTool.map((z) => (
                        <MenuItem
                          key={z.label}
                          value={z.value}
                          className={styles.toolItem}
                        >
                          {z.label}
                        </MenuItem>
                      ))
                    )}
                  </Select>
                )}
              />
            )}

            {errors.tool && (
              <Typography
                color='error'
                variant='caption'
                sx={{ marginLeft: '14px' }}
              >
                {errors.tool.message}
              </Typography>
            )}
          </FormControl>
        )}

        <Divider className={styles.divider} />

        <Grid container spacing={1}>
          {item && (
            <Grid size={{ xs: 4 }}>
              <Button
                className={styles.deleteBtn}
                variant='outlined'
                color='error'
                fullWidth
                type='button'
                onClick={handleDelete}
              >
                {t('actionForm.delete')}
              </Button>
            </Grid>
          )}

          <Grid size={{ xs: item ? 8 : 12 }}>
            <BaseButton
              type='submit'
              variant='contained'
              className={styles.actionBtn}
              fullWidth
              disabled={!isValid}
            >
              {t('actionForm.applyBtn')}
            </BaseButton>
          </Grid>
        </Grid>

        <Card className={styles.infoCard}>
          <Typography variant='body2' className={styles.cardNote}>
            {t('actionForm.description')}
          </Typography>
        </Card>
      </form>
    </Drawer>
  );
};

export default AgentStepDrawer;
