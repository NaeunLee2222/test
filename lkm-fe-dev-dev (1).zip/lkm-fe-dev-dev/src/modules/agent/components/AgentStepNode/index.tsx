import MarkIcon from '@/assets/basic-icons/icon-mark.svg?react';
import PlusIcon from '@/assets/basic-icons/icon-plus.svg?react';
import {
  actionCardClass,
  edgeType,
  fitViewStatistics,
  horizontalNodeGap,
  nodeTypeDef,
} from '@/modules/agent/constant/agent';
import { sendDataThroughDnD } from '@/modules/agent/helper/reactflow';
import { useDnD } from '@/modules/agent/hooks/useDnD';
import {
  agentSettingExpandedAtom,
  edgesAtom,
  isTestAgentLoadingAtom,
  nodesAtom,
} from '@/modules/agent/jotai/agent';
import { AgentStepNodeData, IAction, Item } from '@/modules/agent/type/agent';
import { getRandomColor } from '@/utils/agentUtil';
import {
  Box,
  Button,
  Card,
  ClickAwayListener,
  Input,
  Skeleton,
  Typography,
} from '@mui/material';
import { Handle, Node, Position, useReactFlow } from '@xyflow/react';
import { useAtom } from 'jotai';
import React, {
  useCallback,
  useEffect,
  useLayoutEffect,
  useState,
} from 'react';
import { useTranslation } from 'react-i18next';
import { v4 as uuid } from 'uuid';
import AgentStepDrawer from './Drawer';
import styles from './index.module.scss';
import AgentStepNodeMenu from './Menu';

interface AgentStepNodeProps {
  data: AgentStepNodeData;
  selected: boolean;
}

const AgentStepNode: React.FC<AgentStepNodeProps> = ({ data, selected }) => {
  const [, setType] = useDnD();
  const { fitView } = useReactFlow();
  const { t } = useTranslation('tax');
  const [nodes, setNodes] = useAtom(nodesAtom);
  const [edges, setEdges] = useAtom(edgesAtom);
  const params = new URLSearchParams(location.search);
  const editMode = params.get('action');

  const [, setAgentSettingExpanded] = useAtom(agentSettingExpandedAtom);
  const [isLoading, setIsLoading] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<
    null | (typeof data.listItems)[0]
  >(null);
  const [isEditing, setIsEditing] = useState(false);
  const [titleInput, setTitleInput] = useState(data?.name ?? '');
  const [isTestAgentLoading] = useAtom<boolean>(isTestAgentLoadingAtom);
  const [showMenu, setShowMenu] = useState<boolean>(true);

  // fake loading for action data
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);

      if (!editMode) {
        setAgentSettingExpanded(false);
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isTestAgentLoading) {
      setIsLoading(true);
    } else {
      setIsLoading(false);

      if (!editMode) {
        setAgentSettingExpanded(false);
      }
    }
  }, [isTestAgentLoading]);

  const handleAddStep = () => {
    if (!data) return;
    const nodeId = data.id;

    const currentNode = nodes.find((n) => n.data.id === nodeId);

    if (!currentNode) return;

    const outgoingEdge = edges.find((e) => e.source === nodeId);

    // Mark current nodes as not new
    const updatedNodes = nodes.map((n) => ({
      ...n,
      data: { ...n.data, isNew: false },
    }));

    const currentStepOrder = (currentNode?.data as unknown as AgentStepNodeData)
      ?.order;

    const newNodeId = uuid();

    const newNode: Node = {
      id: newNodeId,
      position: {
        x: currentNode.position.x + horizontalNodeGap,
        y: currentNode.position.y,
      },
      type: nodeTypeDef,
      data: {
        id: newNodeId,
        iconColor: getRandomColor(),
        name: t('agent.stepNameDefault'),
        description: '',
        order: currentStepOrder + 1,
        isNew: true,
        listItems: [
          {
            id: uuid(),
            name: '',
            description: '',
            order: 0,
            tools: [],
          },
        ],
      },
      selected: true,
      dragging: false,
    };

    if (outgoingEdge) {
      const updatedEdges = edges.filter((e) => e.id !== outgoingEdge.id);

      setEdges([
        ...updatedEdges,
        {
          id: uuid(),
          source: nodeId,
          target: newNode.id,
          type: edgeType,
        },
        {
          id: uuid(),
          source: newNode.id,
          target: outgoingEdge.target,
          type: edgeType,
        },
      ]);
    } else {
      setEdges((eds) => [
        ...eds,
        {
          id: uuid(),
          source: nodeId,
          target: newNode.id,
          type: edgeType,
        },
      ]);
    }

    const index = updatedNodes.findIndex((n) => n.id === nodeId);
    const inserted = [
      ...updatedNodes.slice(0, index + 1),
      newNode,
      ...updatedNodes.slice(index + 1),
    ];

    setNodes(inserted);
    sortNodes();
    fitView(fitViewStatistics);
  };

  const sortNodes = useCallback(() => {
    setNodes((prevNodes) => {
      const sorted = [...prevNodes].sort((a, b) => a.position.x - b.position.x);
      const firstPos = sorted[0]?.position ?? { x: 0, y: 0 };

      return sorted.map((node, index) => ({
        ...node,
        data: {
          ...node.data,
          order: index + 1,
        },
        position: {
          x: firstPos.x + index * horizontalNodeGap,
          y: firstPos.y,
        },
      }));
    });
  }, [setNodes]);

  const handleDelete = useCallback(() => {
    setNodes((prev) => prev.filter((node) => node.id !== data.id));
    setEdges((prev) =>
      prev.filter((edge) => edge.source !== data.id && edge.target !== data.id)
    );
    sortNodes();
  }, [data.id, setEdges, setNodes, sortNodes]);

  const handleBlur = () => {
    setIsEditing(false);
    setNodes((nds) =>
      nds.map((node) =>
        node.id === data.id
          ? {
              ...node,
              data: { ...node.data, name: titleInput.trim() ?? '' },
            }
          : node
      )
    );
  };

  const handleEdit = () => {
    setTitleInput(data?.name ?? '');
    setIsEditing(true);
  };

  const handleAddAction = () => {
    setNodes((nodes) => nodes.map((node) => ({ ...node, selected: false })));
    setIsDrawerOpen(true);

    if (!data) return;

    const currentNode = nodes.find((n) => n.data.id === data.id);

    const currentActionOrder = (
      currentNode?.data as unknown as AgentStepNodeData
    )?.listItems?.length;

    if (!currentActionOrder) return;

    const newItem = {
      id: uuid(),
      name: '',
      description: '',
      order: currentActionOrder - 1,
      tools: [],
    };

    setNodes((prevNodes) =>
      prevNodes.map((node) =>
        node.data.id === data.id
          ? {
              ...node,
              data: {
                ...node.data,
                listItems: [...(node.data.listItems as Item[]), newItem],
              },
            }
          : node
      )
    );

    setEditingItem(newItem);
    setTitleInput(data?.name ?? '');
  };

  const handleEditItem = (item: (typeof data.listItems)[0]) => {
    setEditingItem(item);
    setNodes((nodes) => nodes.map((node) => ({ ...node, selected: false })));
    setIsDrawerOpen(true);
  };

  const handleClickAwayTool = useCallback(
    (item: Item) => {
      setNodes((nodes) => nodes.map((node) => ({ ...node, selected: false })));
      if (item.isNew) {
        const itemNew = {
          ...item,
          isNew: false,
        };

        const updatedListItems = [...data.listItems].map((i) =>
          i.id === item.id ? itemNew : i
        );

        setNodes((prevNodes) =>
          prevNodes.map((node) =>
            node.id === data.id
              ? { ...node, data: { ...node.data, listItems: updatedListItems } }
              : node
          )
        );
      }
    },
    [data.id, data.listItems, setNodes]
  );

  const onDragStart = (
    event: React.DragEvent,
    nodeType: string,
    action: IAction,
    stepId: string
  ) => {
    const actionData = { ...action, stepId };
    const jsonData = JSON.stringify(actionData);
    setType(nodeType);
    sendDataThroughDnD(event, jsonData);
  };

  const handleToggleStepOutline = () => {
    setShowMenu(true);
    setNodes((prev) =>
      prev.map((node) =>
        node.id === data.id ? { ...node, selected: !node.selected } : node
      )
    );
  };

  useLayoutEffect(() => {
    if (data.isNew) {
      setShowMenu(false);
    }
  }, [nodes.length]);

  return (
    <>
      <Box display='none'>
        <Handle type='target' position={Position.Left} />
      </Box>

      <AgentStepDrawer
        open={isDrawerOpen}
        setOpen={setIsDrawerOpen}
        item={editingItem}
        nodeId={data?.id ?? ''}
        listItems={data.listItems ?? []}
      />

      <ClickAwayListener onClickAway={() => setShowMenu(false)}>
        <Box
          className={`
            ${styles['text-updater-node']}
            ${!data.isDragging && selected ? styles['text-updater-node-active'] : ''}
            ${data.isDragging && selected ? styles['text-updater-node-dragging'] : ''}
            `}
          onClick={handleToggleStepOutline}
        >
          {selected && showMenu && !data.isDragging && (
            <Box className={styles['node-menu']}>
              <AgentStepNodeMenu
                handleAdd={handleAddStep}
                handleEdit={handleEdit}
                handleDelete={handleDelete}
              />
            </Box>
          )}

          <Box>
            <Typography
              variant='h5'
              className={styles['node-title']}
              onDoubleClick={handleEdit}
            >
              <Box className={styles['node-title-icon-wrapper']}>
                <MarkIcon
                  height='20'
                  width='20'
                  style={{ backgroundColor: data?.iconColor }}
                />
              </Box>
              {isEditing ? (
                <Input
                  fullWidth
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  autoFocus
                  onBlur={() => {
                    if (titleInput.trim() !== '') {
                      handleBlur();
                    }
                  }}
                  className={`${styles['node-title-input']} nodrag`}
                  error={titleInput.trim() === ''}
                  placeholder={t('agent.stepNamePlaceholder')}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      if (titleInput.trim() !== '') {
                        handleBlur();
                      }
                    }
                  }}
                />
              ) : (
                <span className={styles['node-title-text']}>
                  {titleInput ?? data?.name ?? t('agent.stepNameDefault')}
                </span>
              )}
            </Typography>

            {data?.listItems?.map((item) => {
              const isActive =
                (isDrawerOpen && item.id === editingItem?.id) || item.isNew;

              return (
                <ClickAwayListener
                  onClickAway={() => handleClickAwayTool(item)}
                  key={uuid()}
                >
                  <Card
                    className={`${selected ? styles['card-list-hover-disabled'] : styles['card-list']} ${isActive && styles.active} ${actionCardClass} nodrag order-${item.order}  `}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditItem(item);
                    }}
                    onDragStart={(event) =>
                      onDragStart(event, nodeTypeDef, item, data.id)
                    }
                    draggable
                  >
                    {isLoading ? (
                      <>
                        <Skeleton variant='rounded' width={78} height={20} />
                        <Skeleton
                          variant='rounded'
                          height={17}
                          style={{ marginTop: '4px' }}
                        />
                      </>
                    ) : (
                      <>
                        <Box className={styles['card-header']}>
                          <Typography fontWeight='bold'>
                            {item?.name !== ''
                              ? item?.name
                              : t('agent.actionTitleDefault')}
                          </Typography>
                        </Box>
                        <Box className={styles['card-description']}>
                          <Typography className={styles['description-text']}>
                            {item?.description !== ''
                              ? item?.description
                              : t('agent.actionDescriptionDefault')}
                          </Typography>
                        </Box>
                      </>
                    )}

                    {item?.tools?.[0]?.name &&
                      (isLoading ? (
                        <Skeleton
                          variant='rounded'
                          width={74}
                          height={20}
                          style={{ marginTop: '4px' }}
                        />
                      ) : (
                        <Box className={styles['tool-container']}>
                          <Typography fontWeight='bold' className={styles.text}>
                            {t('agent.configuration.tool')}
                          </Typography>

                          <Button
                            variant='contained'
                            className={styles['tool-button']}
                            title={
                              item?.tools?.[0]?.tool_group_id === null
                                ? 'MCP Tool'
                                : 'Tool Group Tool'
                            }
                          >
                            {item?.tools?.[0]?.name}
                            {item?.tools?.[0]?.tool_group_id === null && (
                              <span
                                style={{
                                  marginLeft: '4px',
                                  fontSize: '10px',
                                  opacity: 0.7,
                                }}
                              >
                                MCP
                              </span>
                            )}
                          </Button>
                        </Box>
                      ))}
                  </Card>
                </ClickAwayListener>
              );
            })}

            <Box className={styles['add-action-button']}>
              {isLoading ? (
                <Skeleton
                  variant='rounded'
                  width={88}
                  height={28}
                  sx={{
                    marginTop: '12px',
                    backgroundColor: 'var(--primary-color-100)',
                  }}
                />
              ) : (
                <Button
                  variant='contained'
                  className={styles['action-button']}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAddAction();
                  }}
                  startIcon={
                    <PlusIcon
                      width='16'
                      height='16'
                      style={{ fill: '#364fc7' }}
                    />
                  }
                >
                  {t('agent.addAction')}
                </Button>
              )}
            </Box>
          </Box>
        </Box>
      </ClickAwayListener>

      <Box display='none'>
        <Handle
          type='source'
          position={Position.Right}
          style={{ opacity: 0, width: 0, height: 0 }}
        />
      </Box>
    </>
  );
};

export default AgentStepNode;
