import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { agentCreationDialogDataAtom } from '@/modules/agent/jotai/agent';
import { useAtom } from 'jotai';
import { Box } from '@mui/material';
import styles from './index.module.scss';

const AgentDialog = () => {
  const [agentDialog, setAgentDialog] = useAtom(agentCreationDialogDataAtom);

  const handleClose = () => {
    setAgentDialog({ dialogOpen: false });
  };

  return (
    <Box className={styles.agentDialog}>
      <BaseDialog
        open={agentDialog.dialogOpen}
        title={agentDialog.dialogTitle}
        hideCloseButton={agentDialog.hideClose}
        contentClassName={styles.toolContainer}
        actionClassName={styles.actionButton}
        handleClose={handleClose}
        paddingX={24}
        sx={{
          '.MuiPaper-root': {
            minHeight: '560px',
            maxWidth: '800px !important',
          },
          '& .MuiDialogActions-root': {
            height: '64px',
          },
          '& .MuiDialogTitle-root': {
            height: '62px',
          },
        }}
        contentChildren={agentDialog.contentChildren}
        actionsChildren={agentDialog.actionsChildren}
      />
    </Box>
  );
};

export default AgentDialog;
