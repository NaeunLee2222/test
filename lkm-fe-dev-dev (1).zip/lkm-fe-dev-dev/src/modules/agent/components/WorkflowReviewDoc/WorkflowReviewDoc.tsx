import ExpandIcon from '@/assets/basic-icons/icon-expand.svg?react';
import NewTabIcon from '@/assets/basic-icons/icon-open-new-tab.svg?react';
import PPTXIcon from '@/assets/basic-icons/icon-ppt.svg?react';
import IconRFQ from '@/assets/basic-icons/icon-rqs.svg?react';
import styles from '@/modules/agent/components/WorkflowReviewDoc/WorkflowReviewDoc.module.scss';
import { ChatMarkdown } from '@/modules/chat/components/ChatContent/ChatMarkdown';
import {
  canvasAtom,
  canvasAtoms,
  detailCanvas,
  newPlanAtoms,
} from '@/modules/chat/jotai/chatprocessing';
import { Box } from '@mui/material';
import { useAtomValue, useSetAtom } from 'jotai';
import { useCallback, useMemo } from 'react';

import {
  agentCanvasOpenAtom,
  slidePreviewOpenAtom,
} from '@/modules/agent/jotai/agent';

import DocumentIcon from '@/assets/basic-icons/icon-doc.svg?react';
import GraphVisualizer from '@/modules/chat/components/Graph/network';
import SlideCard from '@/modules/chat/components/SlideCard/SlideCard';
import { chatDataAtom } from '@/modules/chat/jotai/chat';
import { graphDataAtom } from '@/modules/chat/jotai/graph';
import { PPTXMode } from '@/modules/chat/types/chat';
import {
  EPlanType,
  EStatus,
  type PlanInfo,
} from '@/modules/chat/types/chatprocessing';
import { isOpenLnbAtom } from '@/modules/core/jotai/layout';
import { RoutesURL } from '@/routers/routes';

const WorkflowReviewDoc = () => {
  const data = useAtomValue(canvasAtom);
  const canvases = useAtomValue(canvasAtoms);
  const allPlans = useAtomValue(newPlanAtoms);
  const chatData = useAtomValue(chatDataAtom);
  const graphData = useAtomValue(graphDataAtom);

  const setAgentCanvasOpen = useSetAtom(agentCanvasOpenAtom);
  const setSlidePreviewOpen = useSetAtom(slidePreviewOpenAtom);
  const setCanvasDetail = useSetAtom(detailCanvas);
  const setIsOpenLnb = useSetAtom(isOpenLnbAtom);

  // 현재 채팅의 모든 plan 데이터 수집
  const currentPlans = useMemo(() => {
    if (!chatData.historyId) return [];

    const plans: PlanInfo[] = [];

    // allPlans에서 현재 채팅의 plan들 수집
    Object.entries(allPlans).forEach(([key, planData]) => {
      if (
        key.includes(chatData.historyId?.toString() || '') &&
        planData.plans
      ) {
        Object.values(planData.plans).forEach((plan) => {
          if (plan && typeof plan === 'object') {
            plans.push(plan);
          }
        });
      }
    });

    // canvases에서도 추가 데이터 확인
    Object.entries(canvases).forEach(([key, canvasData]) => {
      if (key.includes(chatData.historyId?.toString() || '') && canvasData) {
        // canvas 데이터를 plan 형태로 변환
        const canvasPlan: PlanInfo = {
          id: key,
          steps: {},
          canvas: canvasData,
          type: canvasData.canvas
            ? EPlanType.CANVAS
            : canvasData.slide
              ? EPlanType.SLIDE
              : canvasData.sheet
                ? EPlanType.SHEET
                : canvasData.graph
                  ? EPlanType.GRAPH
                  : canvasData.token
                    ? EPlanType.TOKEN
                    : EPlanType.CANVAS,
          status: EStatus.SUCCESS,
        };

        // 토큰 콘텐츠가 있으면 추가
        if (canvasData.token?.tokenContent) {
          canvasPlan.tokenContent = canvasData.token.tokenContent;
        }

        plans.push(canvasPlan);
      }
    });

    return plans;
  }, [allPlans, canvases, chatData.historyId]);

  // 캔버스 열기 핸들러
  const handleOpenCanvas = useCallback(
    (planId: string, canvasData: any) => {
      if (canvasData) {
        setCanvasDetail(planId);
        setAgentCanvasOpen(true);
        setIsOpenLnb(false);
      }
    },
    [setCanvasDetail, setAgentCanvasOpen, setIsOpenLnb]
  );

  // 슬라이드 열기 핸들러
  const handleOpenPresentation = useCallback(
    (planId: string, canvasData: any) => {
      if (canvasData) {
        setCanvasDetail(planId);
        setSlidePreviewOpen(true);
      }
    },
    [setCanvasDetail, setSlidePreviewOpen]
  );

  // 그래프 새 탭에서 열기
  const handleOpenGraphInNewTab = useCallback(async () => {
    window.open(
      `${window.location.origin}${RoutesURL.GRAPH}`,
      '_blank',
      'noopener,noreferrer'
    );
  }, []);

  // 렌더링할 콘텐츠 결정
  const renderContent = useMemo(() => {
    // 1. 현재 plans에서 콘텐츠 확인
    if (currentPlans.length > 0) {
      return currentPlans
        .map((plan, index) => {
          const key = `plan-${plan.id}-${index}`;

          // 토큰 콘텐츠 렌더링
          if (plan.tokenContent) {
            return (
              <div key={`${key}-token`} className={styles.tokenContent}>
                <div className={styles.tokenLabel}>응답 내용</div>
                <div className={styles.contentBody}>
                  <ChatMarkdown message={plan.tokenContent} />
                </div>
              </div>
            );
          }

          // 캔버스 콘텐츠 렌더링
          if (
            plan.type === EPlanType.CANVAS &&
            plan.canvas?.canvas?.htmlContent
          ) {
            return (
              <div key={`${key}-canvas`} className={styles.contentWrapper}>
                <div className={styles.contentHeader}>
                  <div className={styles.contentTitle}>
                    <IconRFQ
                      style={{ marginRight: '8px', verticalAlign: 'middle' }}
                    />
                    {plan.canvas.canvas.title || '캔버스 문서'}
                  </div>
                  <div className={styles.contentMeta}>
                    <span
                      style={{
                        cursor: 'pointer',
                        color: 'var(--primary-color-600)',
                      }}
                      onClick={() => handleOpenCanvas(plan.id, plan.canvas)}
                    >
                      <ExpandIcon
                        style={{ marginRight: '4px', verticalAlign: 'middle' }}
                      />
                      전체 화면으로 보기
                    </span>
                  </div>
                </div>
                <div
                  className={styles.contentBody}
                  dangerouslySetInnerHTML={{
                    __html: plan.canvas.canvas.htmlContent,
                  }}
                />
              </div>
            );
          }

          // 시트 콘텐츠 렌더링 (캔버스와 동일한 처리)
          if (
            plan.type === EPlanType.SHEET &&
            plan.canvas?.sheet?.htmlContent
          ) {
            return (
              <div key={`${key}-sheet`} className={styles.contentWrapper}>
                <div className={styles.contentHeader}>
                  <div className={styles.contentTitle}>
                    <IconRFQ
                      style={{ marginRight: '8px', verticalAlign: 'middle' }}
                    />
                    {plan.canvas.sheet.title || '시트 문서'}
                  </div>
                  <div className={styles.contentMeta}>
                    <span
                      style={{
                        cursor: 'pointer',
                        color: 'var(--primary-color-600)',
                      }}
                      onClick={() => handleOpenCanvas(plan.id, plan.canvas)}
                    >
                      <ExpandIcon
                        style={{ marginRight: '4px', verticalAlign: 'middle' }}
                      />
                      전체 화면으로 보기
                    </span>
                  </div>
                </div>
                <div
                  className={styles.contentBody}
                  dangerouslySetInnerHTML={{
                    __html: plan.canvas.sheet.htmlContent,
                  }}
                />
              </div>
            );
          }

          // 슬라이드 콘텐츠 렌더링
          if (
            plan.type === EPlanType.SLIDE &&
            plan.canvas?.slide?.htmlContent &&
            plan.canvas.slide.htmlContent.length > 0
          ) {
            return (
              <div key={`${key}-slide`} className={styles.contentWrapper}>
                <div className={styles.contentHeader}>
                  <div className={styles.contentTitle}>
                    <PPTXIcon
                      style={{ marginRight: '8px', verticalAlign: 'middle' }}
                    />
                    {plan.canvas?.slide?.title || '프레젠테이션'}
                  </div>
                  <div className={styles.contentMeta}>
                    <span
                      style={{
                        cursor: 'pointer',
                        color: 'var(--primary-color-600)',
                      }}
                      onClick={() =>
                        handleOpenPresentation(plan.id, plan.canvas)
                      }
                    >
                      <ExpandIcon
                        style={{ marginRight: '4px', verticalAlign: 'middle' }}
                      />
                      슬라이드쇼로 보기
                    </span>
                  </div>
                </div>
                <div className={styles.contentBody}>
                  {plan.canvas?.slide?.htmlContent?.map(
                    (html: string, idx: number) => (
                      <SlideCard
                        key={`slide-${idx}`}
                        html={html}
                        mode={PPTXMode.NORMAL}
                        index={idx}
                        total={plan.canvas?.slide?.htmlContent?.length ?? 0}
                      />
                    )
                  )}
                </div>
              </div>
            );
          }

          // 그래프 콘텐츠 렌더링
          if (
            plan.type === EPlanType.GRAPH &&
            plan.canvas?.graph?.title &&
            graphData
          ) {
            return (
              <div key={`${key}-graph`} className={styles.contentWrapper}>
                <div className={styles.contentHeader}>
                  <div className={styles.contentTitle}>
                    {plan.canvas.graph.title || '데이터 시각화'}
                  </div>
                  <div className={styles.contentMeta}>
                    <span
                      style={{
                        cursor: 'pointer',
                        color: 'var(--primary-color-600)',
                      }}
                      onClick={handleOpenGraphInNewTab}
                    >
                      <NewTabIcon
                        style={{ marginRight: '4px', verticalAlign: 'middle' }}
                      />
                      새 창에서 보기
                    </span>
                  </div>
                </div>
                <div className={styles.contentBody}>
                  <GraphVisualizer />
                </div>
              </div>
            );
          }

          return null;
        })
        .filter(Boolean);
    }

    // 2. 기존 canvasAtom 데이터 확인
    if (data?.canvas?.htmlContent) {
      return [
        <div key='legacy-canvas' className={styles.contentWrapper}>
          <div className={styles.contentHeader}>
            <div className={styles.contentTitle}>
              <IconRFQ
                style={{ marginRight: '8px', verticalAlign: 'middle' }}
              />
              {data.canvas.title || '캔버스 문서'}
            </div>
          </div>
          <div
            className={styles.contentBody}
            dangerouslySetInnerHTML={{
              __html: data.canvas.htmlContent,
            }}
          />
        </div>,
      ];
    }

    // 3. 토큰 콘텐츠만 있는 경우
    if (data?.token?.tokenContent) {
      return [
        <div key='legacy-token' className={styles.tokenContent}>
          <div className={styles.tokenLabel}>응답 내용</div>
          <div className={styles.contentBody}>
            <ChatMarkdown message={data.token.tokenContent} />
          </div>
        </div>,
      ];
    }

    // 4. 콘텐츠가 없는 경우
    return null;
  }, [
    currentPlans,
    data,
    graphData,
    handleOpenCanvas,
    handleOpenPresentation,
    handleOpenGraphInNewTab,
  ]);

  return (
    <Box className={styles.workflowReviewDoc}>
      <Box className={styles.wrapper}>
        {renderContent && renderContent.length > 0 ? (
          renderContent
        ) : (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}>
              <DocumentIcon />
            </div>
            <div className={styles.emptyTitle}>생성된 문서가 없습니다</div>
            <div className={styles.emptyDescription}>
              에이전트와 대화를 시작하면 캔버스, 슬라이드, 그래프 등의 생성된
              콘텐츠가 여기에 표시됩니다.
            </div>
          </div>
        )}
      </Box>
    </Box>
  );
};

export { WorkflowReviewDoc };
