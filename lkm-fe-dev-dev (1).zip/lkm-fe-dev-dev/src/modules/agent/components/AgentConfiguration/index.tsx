import CreateAgentHeader from '@/modules/agent/components/CreateAgentForm/Header';
import type { IActionStepRequest } from '@/modules/agent/type/agent';
import { Card } from '@mui/material';
import { Node } from '@xyflow/react';
import AgentConfiguratorContent from './Content';
import styles from './index.module.scss';

interface IProp {
  handleClick: () => void;
  generateWorkFlow: (data: IActionStepRequest) => Promise<Node[]>;
}
const AgentConfigurator = ({ handleClick, generateWorkFlow }: IProp) => (
  <Card
    className={`${styles.transformContainer} ${styles.expanded}`}
    elevation={6}
  >
    <div className={styles.cardContent}>
      <CreateAgentHeader handleClick={handleClick} />
      <AgentConfiguratorContent generateWorkFlow={generateWorkFlow} />
    </div>
  </Card>
);

export default AgentConfigurator;
