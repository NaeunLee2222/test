import styles from '@/modules/agent/components/AgentConfiguration/Content/index.module.scss';
import type { IActionStepRequest } from '@/modules/agent/type/agent';
import { Box } from '@mui/material';
import React from 'react';
import { Node } from '@xyflow/react';
import AgentConfiguratorForm from './AgentConfiguratorForm';

type Props = {
  generateWorkFlow: (data: IActionStepRequest) => Promise<Node[]>;
};

const AgentConfiguratorContent: React.FC<Props> = ({ generateWorkFlow }) => (
  <Box className={styles.workflowConfigurationContent}>
    <AgentConfiguratorForm generateWorkFlow={generateWorkFlow} />
  </Box>
);

export default AgentConfiguratorContent;
