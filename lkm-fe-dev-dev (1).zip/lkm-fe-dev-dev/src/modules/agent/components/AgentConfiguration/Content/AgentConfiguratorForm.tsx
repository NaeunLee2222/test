import CreateAgentForm from '@/modules/agent/components/CreateAgentForm';
import { AgentType, type IActionStepRequest } from '@/modules/agent/type/agent';
import { Node } from '@xyflow/react';

type Props = {
  generateWorkFlow: (data: IActionStepRequest) => Promise<Node[]>;
};

const AgentConfiguratorForm: React.FC<Props> = ({ generateWorkFlow }) => (
  <CreateAgentForm mode={AgentType.PRO} generateWorkFlow={generateWorkFlow} />
);

export default AgentConfiguratorForm;
