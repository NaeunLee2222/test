import { useTranslation } from 'react-i18next';

const AgentConfiguratorHeader = () => {
  const { t } = useTranslation('tax');
  return <span>{t('agent.configuration.header')}</span>;
};

export default AgentConfiguratorHeader;
