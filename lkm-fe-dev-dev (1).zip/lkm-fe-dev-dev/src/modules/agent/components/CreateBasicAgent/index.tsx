import { userEmailQueryAtom } from '@/modules/admin/jotai/agent';
import AgentDialog from '@/modules/agent/components/Dialog';
import { useGetConversationStarter } from '@/modules/agent/hooks/useAgent';
import {
  agentCanvasOpenAtom,
  agentCreationDialogDataAtom,
  agentDataAtom,
  agentToolListAtom,
  alreadyCreatedWorkflowAtom,
  conversationStarterAtom,
  edgesAtom,
  generalAgentIdAtom,
  hasRunChatStarterAtom,
  nodesAtom,
  selectedAgentToolsAtom,
  showHeaderNodeAtom,
} from '@/modules/agent/jotai/agent';
import { AgentType, ModeType } from '@/modules/agent/type/agent';
import { ChatMain } from '@/modules/chat/components/ChatMain/ChatMain';
import { useGetGeneralAgent } from '@/modules/chat/hooks/useAgents';
import { useCreateNewChat } from '@/modules/chat/hooks/useChat';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import {
  chatDataAtom,
  messagesAtom,
  selectedToolAtom,
} from '@/modules/chat/jotai/chat';
import { canvasAtoms } from '@/modules/chat/jotai/chatprocessing';
import { EChatMode, ERole } from '@/modules/chat/types/chat';
import { USER_ID } from '@/modules/chat/types/user';
import { EChatType } from '@/modules/core/types';
import { IInfoMessage } from '@/types/layout';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom, useSetAtom } from 'jotai';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useCookies } from 'react-cookie';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router-dom';
import AIFeedback from './AIFeedback/AIFeedback';
import BasicAgentForm from './Form';
import styles from './index.module.scss';

interface IProps {
  showRecipe?: boolean;
  setShowRecipe?: (show: boolean) => void;
  mode: string;
  headerNode?: React.ReactNode;
}

const CreateBasicAgent = ({
  showRecipe = true,
  setShowRecipe,
  mode,
  headerNode,
}: IProps) => {
  const { t } = useTranslation('tax');

  const [agentData] = useAtom(agentDataAtom);
  const agentName = agentData?.name
    ? `[${agentData?.name}]`
    : t('agent.configuration.previewChatDefault');

  const defaultStartedMsg: IInfoMessage = {
    type: 'info',
    message: t('agent.configuration.previewChat', { agentTitle: agentName }),
    createdAt: new Date().toISOString(),
    role: ERole.ASSISTANT,
  };
  const [, setUserQuery] = useAtom(userEmailQueryAtom);
  const { agentId } = useParams();
  const [infoMessage, setInfoMessage] = useState<IInfoMessage | undefined>(
    undefined
  );
  const hasRunRef = useRef<boolean>(false);
  const [hasRunChatStarter, setHasRunChatStarter] = useAtom(
    hasRunChatStarterAtom
  );

  const [cookies] = useCookies([USER_ID]);
  const MOCK_MODEL = 'chatgpt4.o';
  const [chatData, setChatData] = useAtom(chatDataAtom);
  const [, setGeneralAgentId] = useAtom(generalAgentIdAtom);

  const [{ data: generalAgent }] = useAtom(useGetGeneralAgent);
  const [, setConversationStarter] = useAtom(conversationStarterAtom);

  const [, setAgentDetailId] = useAtom(agentDetailIdAtom);
  const [, updateSelectedTools] = useAtom(selectedAgentToolsAtom);
  const [, updateTools] = useAtom(agentToolListAtom);
  const [showHeaderNode] = useAtom(showHeaderNodeAtom);
  const [, updateAlreadyCreatedWorkflow] = useAtom(alreadyCreatedWorkflowAtom);
  const updateMessagesData = useSetAtom(messagesAtom);
  const [, updateNodes] = useAtom(nodesAtom);
  const [, setEdges] = useAtom(edgesAtom);
  const [, setAgentId] = useAtom(generalAgentIdAtom);
  const [selectedTool, setSelectedTool] = useAtom(selectedToolAtom);
  const [, setAgentDialog] = useAtom(agentCreationDialogDataAtom);
  const [, setAgentCanvasOpen] = useAtom(agentCanvasOpenAtom);
  const [, setData] = useAtom(canvasAtoms);
  const [{ data: conversationStarterData, isFetched }] = useAtom(
    useMemo(() => useGetConversationStarter(agentId ?? ''), [agentId])
  );
  const [{ data: createdChatData, mutateAsync: createNewChatMutation }] =
    useAtom(useCreateNewChat);
  const chatAvailable = useMemo(
    () => !!createdChatData?.id && createdChatData.id.toString() !== '-1',
    [createdChatData]
  );

  useEffect(() => {
    if (agentId) {
      setGeneralAgentId(agentId.toString());
    }

    return () => {
      setSelectedTool({
        isSelectedCanvas: false,
        selectedMode: null,
      });
      updateSelectedTools([]);
      updateAlreadyCreatedWorkflow(null);
      updateTools([]);
      updateMessagesData({});
      updateNodes([]);
      setEdges([]);
      setAgentDetailId('');
      setAgentId('');
      setAgentDialog({
        dialogOpen: false,
      });
      setChatData({});
      setData({});
      setAgentCanvasOpen(false);
      setHasRunChatStarter(false);
    };
  }, []);

  useEffect(() => {
    if (hasRunRef.current) return;
    if (agentId && generalAgent && isFetched) {
      if (showHeaderNode) {
        setUserQuery({
          id: (
            generalAgent?.data?.agent?.created_user_id ??
            generalAgent?.agent?.created_user_id
          )?.toString(),
        });
      }
      (async () => {
        const chat = await createNewChatMutation({
          agentId,
          chatMode: EChatMode.AGENT_CHAT,
          userId: cookies.userId,
          title:
            generalAgent?.data?.agent?.name ?? generalAgent?.agent?.name ?? '',
          model: MOCK_MODEL,
          chatType: EChatType.ExpertAgentChat,
        });
        setChatData({
          historyId: chat.id,
          selectedAgent:
            generalAgent.data?.agent?.id || generalAgent?.agent?.id,
          title: chat.title,
          messages: {},
        });
      })();
      hasRunRef.current = true;
    }
  }, [generalAgent, chatData]);

  useEffect(() => {
    if (hasRunChatStarter) return;

    if (
      conversationStarterData?.some((starter) => !!starter?.trim()) &&
      chatData.historyId &&
      chatData.historyId.toString() !== '-1'
    ) {
      const starter =
        conversationStarterData[
          Math.floor(Math.random() * conversationStarterData.length)
        ];

      setInfoMessage({
        type: 'chat',
        message: starter,
        createdAt: new Date().toISOString(),
        role: ERole.ASSISTANT,
      });

      setHasRunChatStarter(true);
    }

    if (
      isFetched &&
      !conversationStarterData?.some((starter) => !!starter?.trim())
    ) {
      setInfoMessage(defaultStartedMsg);
    }
  }, [chatData, conversationStarterData, selectedTool]);

  useEffect(() => {
    if (conversationStarterData && conversationStarterData?.length > 0) {
      setConversationStarter([...conversationStarterData]);
    } else {
      setConversationStarter(['']);
    }
  }, [conversationStarterData]);

  return (
    <Box className={styles.createBasicAgentContent}>
      <div
        className={cn(
          styles.panels,
          mode !== ModeType.DASHBOARD ? 'hidden' : ''
        )}
      >
        <div className={styles.agentForm}>
          {showHeaderNode && headerNode}
          <BasicAgentForm
            showRecipe={showRecipe}
            setShowRecipe={setShowRecipe}
          />
        </div>
        <div className={cn(styles.chatPanel)}>
          {chatAvailable ? (
            <ChatMain
              historyId={chatData?.historyId?.toString()}
              infoMessage={infoMessage}
              mode={AgentType.GENERAL_TEST}
              disableInputProps={!chatAvailable}
            />
          ) : (
            <ChatMain
              infoMessage={infoMessage}
              mode={AgentType.GENERAL_TEST}
              disableInputProps
            />
          )}
        </div>
      </div>
      {mode === ModeType.FEEDBACK && <AIFeedback />}
      <AgentDialog />
    </Box>
  );
};

export default CreateBasicAgent;
