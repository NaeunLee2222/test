import ArrowUpIcon from '@/assets/direction-icons/icon-chevron-up.svg?react';
import { TypewriterText } from '@/modules/chat/components/ChatContent/TypewriterText';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  styled,
} from '@mui/material';
import styles from './Accordion.module.scss';

interface IProps {
  header: string;
  content: React.ReactNode;
  expand: boolean;
  setExpand: (expanded: boolean) => void;
}

const AgentAccordion = ({ header, content, expand, setExpand }: IProps) => (
  <Box className={styles.AgentAccordion}>
    <Accordion
      className={styles.accordionContainer}
      expanded={expand}
      disableGutters
      onChange={(_: React.SyntheticEvent, expanded: boolean) =>
        setExpand(expanded)
      }
    >
      <BaseAccordionSummary
        expandIcon={
          <Box
            display='block'
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              'svg': {
                width: '24px',
                height: '24px',
              },
            }}
          >
            <ArrowUpIcon />
          </Box>
        }
        id='panel1-header'
      >
        <TypewriterText
          text={header}
          className={styles.title}
          variant='h6'
          animated={false}
        />
      </BaseAccordionSummary>

      <BaseAccordionDetails
        className={styles.accordionDetails}
        sx={{
          '&.MuiAccordionDetails-root': {
            padding: '0px 16px 20px',
          },
        }}
      >
        <Box className={styles.expandContent}>{content}</Box>
      </BaseAccordionDetails>
    </Accordion>
  </Box>
);

export default AgentAccordion;

const BaseAccordionSummary = styled(AccordionSummary)(() => ({
  padding: '16px !important',
  minHeight: 'auto !important',
  '&.Mui-expanded': {
    margin: '0',
    padding: '16px !important',
  },
  '& h6': {
    lineHeight: '0px !important',
  },
}));

const BaseAccordionDetails = styled(AccordionDetails)(() => ({
  '.MuiCollapse-root': {
    width: '100%',
  },
}));
