import IconThumbsDownActive from '@/assets/basic-icons/icon-thumbs-down-red.svg?react';
import IconThumbsDown from '@/assets/basic-icons/icon-thumbs-down.svg?react';
import IconThumbsUpActive from '@/assets/basic-icons/icon-thumbs-up-green.svg?react';
import IconThumbsUp from '@/assets/basic-icons/icon-thumbs-up.svg?react';
import IconTrashCan from '@/assets/basic-icons/icon-trashcan.svg?react';
import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down-blue.svg?react';
import ArrowUpIcon from '@/assets/direction-icons/icon-chevron-up-blue.svg?react';
import {
  useCreateFeedback,
  useDeleteFeedback,
  useGetFeedback,
} from '@/modules/agent/hooks/useAgent';
import { IFeedbackModel } from '@/modules/agent/type/agent';
import { ChatFeedbackType } from '@/modules/chat/components/ChatInput/constants';
import { chatDataAtom } from '@/modules/chat/jotai/chat';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './AIFeedback.module.scss';

const MAX_LINES = 3;
const RADIX = 10;

enum Expanded {
  QuestionExpanded = 'questionExpanded',
  AnswerExpanded = 'answerExpanded',
}

const AIFeedback = () => {
  const hasRunRef = useRef<boolean>(false);
  const questionRef = useRef<(HTMLDivElement | null)[]>([]);
  const answerRef = useRef<(HTMLDivElement | null)[]>([]);
  const { t } = useTranslation('tax');
  const [feedbacks, setFeedbacks] = useState<IFeedbackModel[]>([]);
  const [chatData] = useAtom(chatDataAtom);

  const [{ data: feedbackData }] = useAtom(
    useMemo(
      () => useGetFeedback(chatData.historyId?.toString() ?? ''),
      [chatData.historyId]
    )
  );
  const [{ mutateAsync: deleteFeedback, isPending: deletingFeedback }] =
    useAtom(useDeleteFeedback);
  const [{ mutateAsync: createFeedback, isPending: creatingFeedback }] =
    useAtom(useCreateFeedback);

  useEffect(() => {
    if (hasRunRef.current) return;
    if (chatData) {
      const messages = Object.values(chatData.messages);
      const converted: IFeedbackModel[] = [];
      for (let i = 0; i < messages.length; i += 2) {
        const question = messages[i].content;
        const answer = messages[i + 1].content;
        const fb = feedbackData?.find(
          (item) => item.chat_message_id === messages[i + 1]?.uuid
        );
        converted.push({
          id: fb?.id ?? 0,
          answer,
          question,
          chat_message_id: fb?.chat_message_id ?? messages[i + 1].uuid,
          created_at: '',
          feedback: fb?.feedback ?? undefined,
          questionExpanded: false,
          answerExpanded: false,
        });
      }
      setFeedbacks(converted);
      hasRunRef.current = true;
    }
  }, [chatData, feedbackData]);

  const handleFeedback = useCallback(
    async (targetIndex: number | string, type: ChatFeedbackType) => {
      if (deletingFeedback || creatingFeedback) return;
      const feedback = [...feedbacks].find(
        (fb, index) => targetIndex === index
      );
      if (!feedback) return;
      const feedbackValue = feedback.feedback;
      if (feedbackValue === type) {
        // delete feedback
        setFeedbacks((prev) =>
          prev.map((fb, index) =>
            targetIndex === index
              ? {
                  ...fb,
                  feedback: undefined,
                }
              : fb
          )
        );
        await deleteFeedback({
          messageId: feedback.chat_message_id,
          feedbackId: feedback.id,
        });
      } else {
        // create feedback
        setFeedbacks((prev) =>
          prev.map((fb, index) =>
            targetIndex === index
              ? {
                  ...fb,
                  feedback: type,
                }
              : fb
          )
        );
        await createFeedback({
          feedback: {
            chat_message_id: feedback.chat_message_id,
            feedback: type,
          },
          callback: (response) => {
            setFeedbacks((prev) =>
              prev.map((fb, index) =>
                targetIndex === index
                  ? {
                      ...fb,
                      id: response.id,
                    }
                  : fb
              )
            );
          },
        });
      }
    },
    [
      createFeedback,
      creatingFeedback,
      deleteFeedback,
      deletingFeedback,
      feedbacks,
    ]
  );

  const showExpandButton = useCallback(
    (content: string, currentRef: HTMLDivElement | null) => {
      if (currentRef) {
        const lightHeight = parseInt(
          window.getComputedStyle(currentRef).lineHeight,
          RADIX
        );
        const maxHeight = MAX_LINES * lightHeight;
        return currentRef.scrollHeight > maxHeight;
      }

      return false;
    },
    []
  );

  const handleExpansion = useCallback((targetIndex: number, key: Expanded) => {
    setFeedbacks((prevValue) =>
      prevValue.map((fb, index) =>
        targetIndex === index
          ? {
              ...fb,
              [key]: !(fb[key] || false),
            }
          : fb
      )
    );
  }, []);

  const handleRemove = useCallback((targetIndex: number) => {
    setFeedbacks((prevValue) =>
      prevValue.filter((fb, index) => targetIndex !== index)
    );
  }, []);

  return feedbacks.length > 0 ? (
    <div className={styles.aiFeedback}>
      {feedbacks.map((fb, index) => (
        <div className={styles.feedbackCard} key={index}>
          <div className={styles.chatQuestion}>
            <div className={styles.title}>{t('question')}</div>
            <div
              ref={(el) => {
                questionRef.current[index] = el;
              }}
              className={cn(
                styles.content,
                fb.questionExpanded
                  ? styles.contentExpanded
                  : styles.contentCollapsed
              )}
            >
              {fb.question}
            </div>
            {showExpandButton(fb.question, questionRef.current[index]) && (
              <Box
                className={styles.expandAnswer}
                onClick={() =>
                  handleExpansion(index, Expanded.QuestionExpanded)
                }
              >
                {fb.questionExpanded ? (
                  <>
                    <span>{t('seeLess')}</span>
                    <ArrowUpIcon />
                  </>
                ) : (
                  <>
                    <span>{t('seeMore')}</span>
                    <ArrowDownIcon />
                  </>
                )}
              </Box>
            )}
          </div>
          <div className={styles.chatAnswer}>
            <div className={styles.title}>{t('answer')}</div>
            <div
              ref={(el) => {
                answerRef.current[index] = el;
              }}
              className={cn(
                styles.content,
                fb.answerExpanded
                  ? styles.contentExpanded
                  : styles.contentCollapsed
              )}
            >
              {fb.answer}
            </div>
            {showExpandButton(fb.answer, answerRef.current[index]) && (
              <Box
                className={styles.expandAnswer}
                onClick={() => handleExpansion(index, Expanded.AnswerExpanded)}
              >
                {fb.answerExpanded ? (
                  <>
                    <span>{t('seeLess')}</span>
                    <ArrowUpIcon />
                  </>
                ) : (
                  <>
                    <span>{t('seeMore')}</span>
                    <ArrowDownIcon />
                  </>
                )}
              </Box>
            )}
          </div>
          <div className={styles.chatButton}>
            <div className={styles.thumbs}>
              <Box
                className={styles.thumbsContainer}
                onClick={() => handleFeedback(index, ChatFeedbackType.LIKE)}
              >
                {fb.feedback === ChatFeedbackType.LIKE ? (
                  <IconThumbsUpActive />
                ) : (
                  <IconThumbsUp />
                )}
              </Box>
              <Box
                className={styles.thumbsContainer}
                onClick={() => handleFeedback(index, ChatFeedbackType.DISLIKE)}
              >
                {fb.feedback === ChatFeedbackType.DISLIKE ? (
                  <IconThumbsDownActive />
                ) : (
                  <IconThumbsDown />
                )}
              </Box>
            </div>
            <Box className={styles.trash} onClick={() => handleRemove(index)}>
              <IconTrashCan />
            </Box>
          </div>
        </div>
      ))}
    </div>
  ) : (
    <Box className={styles.noFeedback}>{t('noFeedback')}</Box>
  );
};

export default AIFeedback;
