import CreateAgentForm from '@/modules/agent/components/CreateAgentForm';
import { AgentType } from '@/modules/agent/type/agent';
import { Box } from '@mui/material';
import styles from './index.module.scss';

interface IProps {
  showRecipe?: boolean;
  setShowRecipe?: (show: boolean) => void;
}

const BasicAgentForm = ({ showRecipe = true, setShowRecipe }: IProps) => (
  <Box className={styles.content}>
    <CreateAgentForm
      mode={AgentType.GENERAL}
      showRecipe={showRecipe}
      setShowRecipe={setShowRecipe}
    />
  </Box>
);

export default BasicAgentForm;
