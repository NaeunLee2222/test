import MinimizeIcon from '@/assets/basic-icons/icon-minimize.svg?react';
import WorkflowConfiguratorContent from '@/modules/agent/components/WorkFlowConfiguration/Content';
import WorkflowConfiguratorHeader from '@/modules/agent/components/WorkFlowConfiguration/Header';
import { Card, IconButton } from '@mui/material';
import styles from './card.module.scss';

interface WorkflowDiscoveryCardProps {
  handleClick: () => void;
}
const DiscoveryCard = ({ handleClick }: WorkflowDiscoveryCardProps) => (
  <Card
    className={`${styles.transformContainer} ${styles.expanded}`}
    elevation={6}
  >
    <div className={styles.cardContent}>
      <div className={styles.header}>
        <WorkflowConfiguratorHeader />
        <IconButton
          size='small'
          className={styles.shrinkButton}
          onClick={handleClick}
        >
          <MinimizeIcon fontSize='small' />
        </IconButton>
      </div>
      <WorkflowConfiguratorContent />
    </div>
  </Card>
);

export default DiscoveryCard;
