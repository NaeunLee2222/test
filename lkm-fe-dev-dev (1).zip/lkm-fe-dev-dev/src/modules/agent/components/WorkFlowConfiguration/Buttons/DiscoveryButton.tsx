import PlusIcon from '@/assets/basic-icons/icon-plus.svg?react';
import { Button } from '@mui/material';
import { useTranslation } from 'react-i18next';
import styles from './button.module.scss';

interface WorkflowDiscoveryButtonProps {
  handleClick: () => void;
}
const DiscoveryButton = ({ handleClick }: WorkflowDiscoveryButtonProps) => {
  const { t } = useTranslation('tax');

  return (
    <Button
      startIcon={<PlusIcon width={20} height={20} style={{ fill: 'white' }} />}
      className={styles.wdBtn}
      onClick={handleClick}
    >
      {t('agent.configuration.navigateWorkFlow')}
    </Button>
  );
};

export default DiscoveryButton;
