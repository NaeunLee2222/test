import { Button } from '@mui/material';
import AgentIcon from '@/assets/basic-icons/icon-agent-black.svg?react';
import { useTranslation } from 'react-i18next';
import styles from './button.module.scss';

interface IProps {
  handleClick: () => void;
}

const AgentSettingButton = ({ handleClick }: IProps) => {
  const { t } = useTranslation('tax');
  return (
    <Button
      startIcon={<AgentIcon width={20} height={20} />}
      className={styles.agentBtn}
      sx={{}}
      onClick={handleClick}
    >
      {t('agent.configuration.header')}
    </Button>
  );
};

export default AgentSettingButton;
