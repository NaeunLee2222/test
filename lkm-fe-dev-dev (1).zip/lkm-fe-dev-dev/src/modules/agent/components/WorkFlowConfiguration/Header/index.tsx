import GenAIIcon from '@/assets/basic-icons/icon-gen-ai.svg?react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

const WorkflowConfiguratorHeader = () => {
  const { t } = useTranslation('tax');
  return (
    <div className={styles.workflowConfigurationHeader}>
      <GenAIIcon width='20' height='20' />
      <span>{t('agent.configuration.navigateWorkFlow')}</span>
    </div>
  );
};

export default WorkflowConfiguratorHeader;
