import AgentConfigurator from '@/modules/agent/components/AgentConfiguration/';
import AgentSettingButton from '@/modules/agent/components/WorkFlowConfiguration/Buttons/AgentSettingButton';
import DiscoveryButton from '@/modules/agent/components/WorkFlowConfiguration/Buttons/DiscoveryButton';
import DiscoveryCard from '@/modules/agent/components/WorkFlowConfiguration/Cards/DiscoveryCard';
import { agentSettingExpandedAtom } from '@/modules/agent/jotai/agent';
import type { IActionStepRequest } from '@/modules/agent/type/agent';
import { Node } from '@xyflow/react';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import styles from './index.module.scss';

type Props = {
  generateWorkFlow: (data: IActionStepRequest) => Promise<Node[]>;
};

const WorkflowConfigurator: React.FC<Props> = ({ generateWorkFlow }) => {
  const [searchParams] = useSearchParams();
  const initMode = searchParams.get('action');

  useEffect(() => {
    if (initMode) {
      setAgentSettingExpanded(true);
    }
  }, [initMode]);

  const [expanded, setExpanded] = useState(false);
  const [agentExpanded, setAgentSettingExpanded] = useAtom(
    agentSettingExpandedAtom
  );

  const handleCardClick = () => {
    if (!expanded) {
      setExpanded(true);
      setAgentSettingExpanded(false);
    }
  };

  const handleAgentSettingClick = () => {
    if (!agentExpanded) {
      setAgentSettingExpanded(true);
      setExpanded(false);
    }
  };

  const handleMinimizeClick = () => {
    setAgentSettingExpanded(false);
  };

  const handleShrinkClick = () => {
    setExpanded(false);
  };

  return (
    <div className={styles.workflowConfigurator}>
      {expanded && <DiscoveryCard handleClick={handleShrinkClick} />}
      {agentExpanded && (
        <AgentConfigurator
          handleClick={handleMinimizeClick}
          generateWorkFlow={generateWorkFlow}
        />
      )}
      <div
        className={cn(
          styles.btn,
          agentExpanded && !expanded && styles.btnBottom
        )}
      >
        {!agentExpanded && (
          <AgentSettingButton handleClick={handleAgentSettingClick} />
        )}
        {!expanded && <DiscoveryButton handleClick={handleCardClick} />}
      </div>
    </div>
  );
};

export default WorkflowConfigurator;
