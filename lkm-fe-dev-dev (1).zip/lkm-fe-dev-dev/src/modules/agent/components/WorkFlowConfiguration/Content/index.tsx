import { Box, Tab, Tabs } from '@mui/material';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import WorkFlowConfigurationActionTab from './Tab/Action';
import WorkFlowConfigurationStepTab from './Tab/Step';
import styles from './index.module.scss';

const WorkflowConfiguratorContent: React.FC = () => {
  const [t] = useTranslation();

  const [value, setValue] = useState(0);

  const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
    _event.stopPropagation();
    setValue(newValue);
  };

  return (
    <Box className={styles.workflowConfigurationContent}>
      <Box
        sx={{ borderBottom: 1, borderColor: 'divider', marginBottom: '16px' }}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          className={styles.tabsRoot}
          indicatorColor='primary'
          textColor='primary'
        >
          <Tab label={t('agent.configuration.step')} />
          <Tab label={t('agent.configuration.action')} />
        </Tabs>
      </Box>
      <Box className={styles.tabPanel}>
        {value === 0 && <WorkFlowConfigurationStepTab />}
        {value === 1 && <WorkFlowConfigurationActionTab />}
      </Box>
    </Box>
  );
};

export default WorkflowConfiguratorContent;
