import IconEmptyState from '@/assets/basic-icons/icon-empty-state.svg?react';
import SearchIcon from '@/assets/basic-icons/icon-search.svg?react';
import loadingIcon from '@/assets/lotties/loading-icon.json';
import { getListTool } from '@/modules/agent/api/agent';
import { nodeTypeDef } from '@/modules/agent/constant/agent';
import { sendDataThroughDnD } from '@/modules/agent/helper/reactflow';
import { useDnD } from '@/modules/agent/hooks/useDnD';
import { IAction } from '@/modules/agent/type/agent';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { Box, Button, Card, InputBase, Typography } from '@mui/material';
import { debounce } from 'lodash';
import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

const WorkFlowConfigurationActionTab: React.FC = () => {
  const [, setType] = useDnD();
  const { t } = useTranslation('tax');

  const [tools, setTools] = useState<IAction[] | null>([]);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 10;
  const [visibleTools, setVisibleTools] = useState<IAction[] | null>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const debounceFn = useCallback(
    debounce((text?: string) => {
      getListTool(text)
        .then((response) => {
          if (response) {
            setTools(response);
            setVisibleTools(response.slice(0, 10)); // Firt 10 items
            setPage(1);
          }
          setLoading(false);
        })
        .catch((error) => {
          setLoading(false);
          setTools([]);
          setVisibleTools([]);
          console.error('Error fetching data:', error);
          throw error;
        });
    }, 500),
    []
  );
  const loadMore = () => {
    const nextPage = page + 1;
    const nextSlice = tools ? tools.slice(0, nextPage * PAGE_SIZE) : [];
    setVisibleTools(nextSlice);
    setPage(nextPage);
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (!visibleTools) return;
    const target = e.currentTarget;

    const { scrollTop, scrollHeight, clientHeight } = target;
    if (
      scrollTop + clientHeight >= scrollHeight - 10 &&
      visibleTools &&
      tools &&
      visibleTools.length < tools.length
    ) {
      loadMore();
    }
  };

  useEffect(() => {
    setLoading(true);
    debounceFn();
  }, [debounceFn]);

  const onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setLoading(true);
    const searchValue = event.target.value;
    const searchValueLowerCase = searchValue.toLowerCase();
    debounceFn(searchValueLowerCase);
  };

  const onDragStart = (
    event: React.DragEvent,
    nodeType: string,
    action: IAction
  ) => {
    // 액션에 툴이 존재하면 도구 자동 연동 설정
    let processedAction = { ...action };
    if (action.tools && action.tools.length > 0) {
      // tool_group_id가 있는 경우 자동으로 도구 연동, MCP 타입은 직접 연동
      const processedTools = action.tools.map((tool) => ({
        ...tool,
        tool_group_id: tool.tool_group_id || null,
        // tool_group_id가 있거나 MCP 타입(tool_group_id가 null)인 경우 자동으로 선택
        selected: tool.tool_group_id !== undefined,
      }));

      processedAction = {
        ...action,
        tools: processedTools,
      };
    }

    const jsonData = JSON.stringify(processedAction);
    setType(nodeType);
    sendDataThroughDnD(event, jsonData);
  };

  return (
    <Box className={styles.workflowConfigurationActionTab}>
      <Box className={styles.inputWrapper}>
        <InputBase
          placeholder={t('agent.configuration.searchActionPlaceholder')}
          className={styles.searchInput}
          fullWidth
          onChange={onChange}
        />
        <SearchIcon className={styles.searchIcon} />
      </Box>

      <Typography className={styles.tabText}>
        {t('agent.configuration.contentActionTitle')}
      </Typography>

      {loading ? (
        <div className={styles.loading}>
          <LottiePlayer
            options={{
              renderer: 'svg',
              loop: true,
              autoplay: true,
              animationData: loadingIcon,
            }}
            width={100}
            height={100}
          />
        </div>
      ) : (
        <>
          <div className={styles.scrollOverview} onScroll={handleScroll}>
            {visibleTools?.map((tool) => (
              <Card
                key={tool.id}
                className={styles.actionTabItem}
                onDragStart={(event) => onDragStart(event, nodeTypeDef, tool)}
                draggable
              >
                <Box className={styles.cardHeader}>
                  <Typography fontWeight={600} fontSize={14}>
                    {tool.name}
                  </Typography>
                </Box>

                <Box className={styles.cardDescription}>
                  <Typography className={styles.descriptionText}>
                    {tool.description}
                  </Typography>
                </Box>

                {tool?.tools?.length > 0 && (
                  <Box className={styles.toolContainer}>
                    <Typography fontWeight='bold' className={styles.text}>
                      {t('agent.configuration.tool')}
                    </Typography>

                    {tool.tools.map((toolItem) => (
                      <Button
                        key={toolItem.id}
                        variant='contained'
                        className={styles.fileUploaderButton}
                      >
                        {toolItem.name}
                      </Button>
                    ))}
                  </Box>
                )}
              </Card>
            ))}
          </div>

          {visibleTools?.length === 0 && (
            <Box className={styles.empty}>
              <IconEmptyState />
              <span>{t('report.list.empty')}</span>
            </Box>
          )}
        </>
      )}
    </Box>
  );
};

export default WorkFlowConfigurationActionTab;
