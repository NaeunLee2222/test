import IconEmptyState from '@/assets/basic-icons/icon-empty-state.svg?react';
import MarkIcon from '@/assets/basic-icons/icon-mark.svg?react';
import SearchIcon from '@/assets/basic-icons/icon-search.svg?react';
import IconDown from '@/assets/direction-icons/icon-chevron-down.svg?react';
import IconUp from '@/assets/direction-icons/icon-chevron-up.svg?react';
import loadingIcon from '@/assets/lotties/loading-icon.json';
import { getListStepActions } from '@/modules/agent/api/agent';
import { nodeTypeDef } from '@/modules/agent/constant/agent';
import { sendDataThroughDnD } from '@/modules/agent/helper/reactflow';
import { useDnD } from '@/modules/agent/hooks/useDnD';
import { IStep } from '@/modules/agent/type/agent';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { getRandomColor } from '@/utils/agentUtil';
import { Box, Card, Collapse, InputBase, Typography } from '@mui/material';
import { debounce } from 'lodash';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

const WorkFlowConfigurationStepTab: React.FC = () => {
  const [, setType] = useDnD();
  const { t } = useTranslation('tax');

  const [openId, setOpenId] = useState<string | number | null>(null);
  const [stepActions, setStepActions] = useState<IStep[] | null>([]);
  const PAGE_SIZE = 10;
  const [visibleSteps, setVisibleSteps] = useState<IStep[] | null>([]); // Displaying data
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState<boolean>(false);

  const handleToggle = (id: string | number) => {
    setOpenId(openId === id ? null : id);
  };

  const debounceFn = useCallback(
    debounce((text?: string) => {
      getListStepActions(text)
        .then((response) => {
          if (response) {
            const temps = response.map((item: IStep) => ({
              ...item,
              iconColor: getRandomColor(),
            }));
            setStepActions(temps);
            setVisibleSteps(temps.slice(0, 10)); // Firt 10 items
            setPage(1);
          }
          setLoading(false);
        })
        .catch((error) => {
          setLoading(false);
          setStepActions([]);
          setVisibleSteps([]);
          console.error('Error fetching data:', error);
          throw error;
        });
    }, 500),
    []
  );

  const loadMore = () => {
    const nextPage = page + 1;
    const nextSlice = stepActions
      ? stepActions.slice(0, nextPage * PAGE_SIZE)
      : [];
    setVisibleSteps(nextSlice);
    setPage(nextPage);
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (!visibleSteps) return;
    const target = e.currentTarget;

    const { scrollTop, scrollHeight, clientHeight } = target;
    if (
      scrollTop + clientHeight >= scrollHeight - 10 &&
      visibleSteps &&
      stepActions &&
      visibleSteps.length < stepActions.length
    ) {
      loadMore();
    }
  };

  useEffect(() => {
    setLoading(true);
    debounceFn();
  }, [debounceFn]);

  const onDragStart = (
    event: React.DragEvent,
    nodeType: string,
    step: IStep,
    iconColor: string
  ) => {
    // 스텝의 각 액션에 대해 툴이 존재하면 tool_group_id를 포함하여 자동으로 도구 연동
    const processedStep = {
      ...step,
      iconColor,
      actions:
        step.actions?.map((action) => {
          if (action.tools && action.tools.length > 0) {
            // 각 액션의 툴에 대해 tool_group_id가 있으면 그대로 유지하고, 첫 번째 툴을 선택된 상태로 설정
            const processedTools = action.tools.map((tool) => ({
              ...tool,
              tool_group_id: tool.tool_group_id || null,
            }));

            return {
              ...action,
              tools: processedTools,
            };
          }
          return action;
        }) || [],
    };

    const jsonData = JSON.stringify(processedStep);
    setType(nodeType);
    sendDataThroughDnD(event, jsonData);
  };

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLoading(true);
    const searchValue = e.target.value;
    debounceFn(searchValue);
  };

  return (
    <Box className={styles.workflowConfigurationStepTab}>
      <Box className={styles.inputWrapper}>
        <InputBase
          size='small'
          onChange={onChange}
          placeholder={t('agent.configuration.searchStepPlaceholder')}
          fullWidth
          className={styles.searchInput}
        />
        <SearchIcon className={styles.searchIcon} />
      </Box>

      <Typography className={styles.tabText}>
        {t('agent.configuration.contentStepTitle')}
      </Typography>

      {loading ? (
        <div className={styles.loading}>
          <LottiePlayer
            options={{
              renderer: 'svg',
              loop: true,
              autoplay: true,
              animationData: loadingIcon,
            }}
            width={100}
            height={100}
          />
        </div>
      ) : (
        <>
          <div className={styles.scrollOverview} onScroll={handleScroll}>
            {visibleSteps?.map((step) => (
              <Card
                key={step.id}
                className={styles.stepTabItem}
                onDragStart={(event) =>
                  onDragStart(event, nodeTypeDef, step, step.iconColor ?? '')
                }
                draggable
              >
                <Typography variant='h6' className={styles.nodeTitle}>
                  <Box className={styles['node-title-icon-wrapper']}>
                    <MarkIcon
                      height='20'
                      width='20'
                      style={{ backgroundColor: step.iconColor ?? '' }}
                    />
                  </Box>
                  <span>{step.name}</span>
                </Typography>

                {step.actions?.map((item) => {
                  const { description, id, name } = item;
                  const isOpen = openId === id;
                  return (
                    <Box
                      key={id}
                      className={styles.stepTabChildren}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggle(id);
                      }}
                    >
                      <Box className={styles.stepTabChildrenHeader}>
                        <Typography
                          className={styles.stepTabChildrenHeaderText}
                        >
                          {name}
                        </Typography>
                        {isOpen ? <IconUp /> : <IconDown />}
                      </Box>
                      <Collapse in={isOpen} timeout='auto' unmountOnExit>
                        <Typography
                          className={styles.stepTabChildrenDescription}
                        >
                          {description}
                        </Typography>
                      </Collapse>
                    </Box>
                  );
                })}
              </Card>
            ))}
          </div>

          {stepActions?.length === 0 && !loading && (
            <Box className={styles.empty}>
              <IconEmptyState />
              <span>{t('report.list.empty')}</span>
            </Box>
          )}
        </>
      )}
    </Box>
  );
};

export default WorkFlowConfigurationStepTab;
