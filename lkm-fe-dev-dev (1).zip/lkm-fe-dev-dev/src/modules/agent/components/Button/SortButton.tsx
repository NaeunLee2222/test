import FilterIcon from '@/assets/basic-icons/icon-filter.svg?react';
import { Menu, MenuItem } from '@mui/material';
import React, { useState } from 'react';
import styles from './Button.module.scss';

type SortMenuProps = {
  sortList: { label: string; value: string }[];
  handleSort: (option: string) => void;
};

export const SortButton: React.FC<SortMenuProps> = ({
  sortList,
  handleSort,
}: SortMenuProps) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleSelect = (option: string) => {
    handleSort(option);
    setAnchorEl(null);
  };

  return (
    <div>
      <div className={styles.sort}>
        <FilterIcon onClick={handleClick} />
      </div>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
        className={styles.menuDropdown}
      >
        {sortList.map((item) => (
          <MenuItem
            key={item.value + item.label}
            onClick={() => handleSelect(item.value)}
          >
            {item.label}
            {}
          </MenuItem>
        ))}
      </Menu>
    </div>
  );
};
