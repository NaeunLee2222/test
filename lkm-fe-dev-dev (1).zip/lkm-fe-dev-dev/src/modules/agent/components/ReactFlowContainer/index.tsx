import WorkflowConfigurator from '@/modules/agent/components/WorkFlowConfiguration';
import {
  actionCardClass,
  fitViewStatistics,
  horizontalNodeGap,
  miniMapGap,
  nodeTypeDef,
  reactFlowNodeClass,
  stepIdAttribute,
} from '@/modules/agent/constant/agent';
import { DnDProvider } from '@/modules/agent/contexts/DnD';
import {
  findElementAtPoint,
  getOrderFromClass,
  swapAndReorderList,
} from '@/modules/agent/helper/reactflow';
import { useRecommendStepActionMutation } from '@/modules/agent/hooks/useAgent';
import { useConvertNodeData } from '@/modules/agent/hooks/useConvertNodeData';
import {
  agentCreationLoadingAtom,
  agentSettingExpandedAtom,
  alreadyCreatedWorkflowAtom,
  edgesAtom,
  nodesAtom,
} from '@/modules/agent/jotai/agent';
import type {
  AgentStepNodeData,
  IActionStepRequest,
} from '@/modules/agent/type/agent';
import { useAgentDetail } from '@/modules/chat/hooks/useAgents';
import { RoutesURL } from '@/routers/routes';
import { getRandomColor } from '@/utils/agentUtil';
import { Box } from '@mui/material';
import {
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  Background,
  Edge,
  EdgeChange,
  MiniMap,
  Node,
  NodeChange,
  OnConnect,
  ReactFlow,
  ReactFlowProvider,
  useReactFlow,
  Viewport,
  XYPosition,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { useAtom } from 'jotai';
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import { v4 as uuid } from 'uuid';
import AgentStepNode from '../AgentStepNode';
import ReactFlowControl from './Control';
import styles from './index.module.scss';

const proOptions = { hideAttribution: true };
const nodeTypes = { textUpdater: AgentStepNode };

const Flow = () => {
  const {
    setCenter,
    getZoom,
    screenToFlowPosition,
    fitView,
    getNodes,
    setViewport,
  } = useReactFlow();
  const { t } = useTranslation('tax');

  const [originalPosition, setOriginalPosition] = useState<{
    [id: string]: XYPosition;
  }>({});

  const reactFlowWrapper = useRef<HTMLDivElement | null>(null);
  const location = useLocation();
  const { convertData } = useConvertNodeData();

  const [{ data }] = useAtom(useAgentDetail);
  const [nodes, setNodes] = useAtom(nodesAtom);
  const [edges, setEdges] = useAtom(edgesAtom);
  const [, updateCreationLoading] = useAtom(agentCreationLoadingAtom);
  const [, setAgentSettingExpanded] = useAtom(agentSettingExpandedAtom);
  const [, updateAlreadyCreated] = useAtom(alreadyCreatedWorkflowAtom);
  const [mutation] = useAtom(useRecommendStepActionMutation);
  const [zoom, setZoom] = useState(Math.round(getZoom() * 100));
  const boundsRef = useRef<{
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
  } | null>(null);

  const onNodesChange = useCallback(
    (changes: NodeChange<Node>[]) =>
      setNodes((nds) => applyNodeChanges(changes, nds)),
    [setNodes]
  );

  const onEdgesChange = useCallback(
    (changes: EdgeChange<Edge>[]) =>
      setEdges((eds) => applyEdgeChanges(changes, eds)),
    [setEdges]
  );

  const isAgentLKMSettings = useMemo(
    () => location.pathname.includes(RoutesURL.SETTINGS_AGENT_LKM_REGISTRATION),
    [location.pathname]
  );

  // reset node when unmount
  useEffect(
    () => () => {
      setNodes([]);
      setEdges([]);
    },

    []
  );

  // convert data from agent detail to nodes
  useEffect(() => {
    if (data?.formattedData?.steps?.length === 0) return;

    convertData(data?.formattedData?.steps);
  }, [data?.formattedData?.steps]);

  useEffect(() => {
    fitView(fitViewStatistics);
  }, [fitView]);

  useEffect(() => {
    const currentNodes = getNodes();
    if (!currentNodes.length) return;

    const minX =
      Math.min(...currentNodes.map((n) => n.position.x)) + miniMapGap;
    const minY =
      Math.max(...currentNodes.map((n) => n.position.y)) + miniMapGap;
    const maxX =
      Math.max(
        ...currentNodes.map(
          (n) => n.position.x + (n.measured?.width ?? miniMapGap)
        )
      ) - miniMapGap;
    const maxY =
      Math.max(
        ...currentNodes.map(
          (n) => n.position.y + (n.measured?.height ?? miniMapGap)
        )
      ) - miniMapGap;

    boundsRef.current = { minX, minY, maxX, maxY };
  }, [fitView, getNodes, nodes, edges, zoom]);

  const onConnect: OnConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const addActionFromGenerate = (dropData: any, event: React.DragEvent) => {
    const dropX = event.clientX;
    const dropY = event.clientY;

    const targetActionEl = findElementAtPoint(dropX, dropY, reactFlowNodeClass);

    if (!targetActionEl) return;

    const targetNodeId = targetActionEl.getAttribute(stepIdAttribute);
    if (!targetNodeId) return;

    setNodes((prevNodes) =>
      prevNodes.map((node) => {
        if (node.id !== targetNodeId) return node;

        const oldList = Array.isArray(node.data.listItems)
          ? node.data.listItems
          : [];

        // 액션에 툴이 존재하면 도구 자동 연동 설정
        let processedTools = dropData?.tools || [];

        // tool_group_id가 있는 경우 자동으로 도구 연동, MCP 타입은 직접 연동
        if (processedTools.length > 0) {
          processedTools = processedTools.map((tool: any) => ({
            ...tool,
            tool_group_id: tool.tool_group_id || null,
            // tool_group_id가 있거나 MCP 타입(tool_group_id가 null)인 경우 자동으로 선택
            selected: tool.tool_group_id !== undefined,
          }));
        }

        const updatedItem = {
          id: uuid(),
          name: dropData?.name,
          description: dropData?.description,
          tools: processedTools,
          order: oldList?.length,
          isNew: true,
        };

        return {
          ...node,
          data: {
            ...node.data,
            listItems: [...oldList, updatedItem],
          },
        };
      })
    );
  };

  const addStepFromGenerate = (dropData: any, event: React.DragEvent) => {
    const { clientX, clientY } = event;
    const { x: dropX, y: dropY } = screenToFlowPosition({
      x: clientX,
      y: clientY,
    });

    const newNodeId = uuid();

    const newNode: Node = {
      id: newNodeId,
      type: nodeTypeDef,
      position: { x: dropX, y: dropY },
      data: {
        id: newNodeId,
        iconColor: dropData?.iconColor,
        name: dropData?.name ?? t('agent.stepNameDefault'),
        order: dropData?.order ?? 0,
        isNew: true,
        listItems: dropData?.actions.map((action: any, index: number) => {
          // 액션에 툴이 존재하면 도구 자동 연동 설정
          let processedTools = action?.tools || [];

          // tool_group_id가 있는 경우 자동으로 도구 연동, MCP 타입은 직접 연동
          if (processedTools.length > 0) {
            processedTools = processedTools.map((tool: any) => ({
              ...tool,
              tool_group_id: tool.tool_group_id || null,
              // tool_group_id가 있거나 MCP 타입(tool_group_id가 null)인 경우 자동으로 선택
              selected: tool.tool_group_id !== undefined,
            }));
          }

          return {
            ...action,
            id: uuid(),
            order: index ?? 0,
            tools: processedTools,
          };
        }),
      },
      selected: true,
    };

    const resetSelectedNode = nodes.map((node) => ({
      ...node,
      selected: false,
    }));
    const resetIsNewNode = resetSelectedNode.map((node) => ({
      ...node,
      data: { ...node.data, isNew: false },
    }));

    const updatedNodes = [...resetIsNewNode, newNode];

    const sortedNodes = updatedNodes.toSorted(
      (a, b) => a.position.x - b.position.x
    );

    const startY = sortedNodes[0].position.y;
    const startX = sortedNodes[0].position.x;

    const spacedNodes = sortedNodes.map((node, index) => ({
      ...node,
      position: {
        x: startX + index * horizontalNodeGap,
        y: startY,
      },
    }));

    setNodes(spacedNodes);

    const lastNode = nodes[nodes.length - 1];
    if (lastNode) {
      const newEdge: Edge = {
        id: uuid(),
        source: lastNode.id,
        target: uuid(),
        animated: true,
      };
      setEdges((eds) => [...eds, newEdge]);
    }
  };

  // Handle reordering inside the same step
  const reorderWithinSameStep = (
    stepId: string,
    fromOrder: number,
    toOrder: number
  ) => {
    setNodes((prevNodes) =>
      prevNodes.map((node) => {
        if (node.id !== stepId) return node;

        const oldList = Array.isArray(node.data.listItems)
          ? [...node.data.listItems]
          : [];
        const updatedList = swapAndReorderList(oldList, fromOrder, toOrder);

        return {
          ...node,
          data: {
            ...node.data,
            listItems: updatedList,
          },
        };
      })
    );
  };

  // Handle moving action between different steps
  const moveActionToStep = (
    dropData: any,
    fromStepId: string,
    toStepId: string,
    insertOrder?: number
  ) => {
    setNodes((prevNodes) =>
      prevNodes.map((node) => {
        if (node.id === fromStepId) {
          const oldList = Array.isArray(node.data.listItems)
            ? [...node.data.listItems]
            : [];
          const updatedList = oldList

            .filter((item) => item.id !== dropData.id)
            .map((item, index) => ({
              ...item,
              order: index,
            }));

          return {
            ...node,
            data: {
              ...node.data,
              listItems: updatedList,
            },
          };
        }

        if (node.id === toStepId) {
          const oldList = Array.isArray(node.data.listItems)
            ? [...node.data.listItems]
            : [];

          // Remove existing instance of dropData if somehow already present
          const cleanedList = oldList.filter((item) => item.id !== dropData.id);

          if (typeof insertOrder === 'number') {
            cleanedList.splice(insertOrder, 0, dropData);
          } else {
            cleanedList.push(dropData);
          }

          const updatedList = cleanedList.map((item, index) => ({
            ...item,
            order: index,
          }));

          return {
            ...node,
            data: {
              ...node.data,
              listItems: updatedList,
            },
          };
        }

        return node;
      })
    );
  };

  const handleArrangeAction = (dropData: any, event: React.DragEvent) => {
    const dropX = event.clientX;
    const dropY = event.clientY;

    const targetStepEl = findElementAtPoint(dropX, dropY, reactFlowNodeClass);
    if (!targetStepEl) return;

    const targetStepId = targetStepEl.getAttribute(stepIdAttribute);
    if (!targetStepId) return;

    const targetActionEl = findElementAtPoint(dropX, dropY, actionCardClass);

    if (!targetActionEl) {
      moveActionToStep(dropData, dropData.stepId, targetStepId);
    } else {
      const targetActionOrder = getOrderFromClass(targetActionEl);
      if (targetActionOrder === null) return;

      const dragActionOrder = dropData.order;

      if (targetStepId === dropData.stepId) {
        reorderWithinSameStep(targetStepId, dragActionOrder, targetActionOrder);
      } else {
        moveActionToStep(
          dropData,
          dropData.stepId,
          targetStepId,
          targetActionOrder
        );
      }
    }
  };

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const raw = event.dataTransfer.getData('application/reactflow');
      const dropData = JSON.parse(raw);

      if (dropData?.stepId) {
        handleArrangeAction(dropData, event);
      } else if (!dropData?.iconColor) {
        addActionFromGenerate(dropData, event);
      } else {
        addStepFromGenerate(dropData, event);
      }

      fitView(fitViewStatistics);
    },
    [addActionFromGenerate, addStepFromGenerate, fitView, handleArrangeAction]
  );

  const onAddStep = useCallback(() => {
    const rightMostNode = nodes.reduce<Node | null>(
      (maxNode, current) =>
        !maxNode || current.position.x > maxNode.position.x ? current : maxNode,
      null
    );

    const newPosition = rightMostNode
      ? {
          x: rightMostNode.position.x + horizontalNodeGap,
          y: rightMostNode.position.y,
        }
      : { x: 0, y: 0 }; // fallback if no nodes

    // Mark current nodes as not new
    const updatedNodes = nodes.map((n) => ({
      ...n,
      selected: false,
      data: { ...n.data, isNew: false },
    }));

    const lastStepOrder =
      (rightMostNode?.data as unknown as AgentStepNodeData)?.order ?? 1;

    const newNodeId = uuid();

    const newNode: Node = {
      id: newNodeId,
      type: nodeTypeDef,
      position: newPosition,
      data: {
        id: newNodeId,
        iconColor: getRandomColor(),
        order: lastStepOrder + 1,
        name: t('agent.stepNameDefault'),
        description: '',
        isNew: true,
        listItems: [
          {
            id: uuid(),
            name: '',
            order: 0,
            description: '',
            tools: [],
          },
        ],
      },
      selected: true,
    };

    setNodes([...updatedNodes, newNode]);

    setCenter(newNode.position.x, newNode.position.y, { zoom: getZoom() });
  }, [nodes, setNodes, t, getZoom, setCenter]);

  const handleNodeDragStart = (_: any, node: Node) => {
    setOriginalPosition((prev) => ({
      ...prev,
      [node.id]: node.position,
    }));

    setNodes((nds) =>
      nds.map((n) => ({
        ...n,
        data: {
          ...n.data,
          isDragging: n.id === node.id,
        },
      }))
    );
  };

  const handleNodeDragStop = (event: any, draggedNode: Node) => {
    const nodeWidth = draggedNode.measured?.width ?? 150;
    const nodeHeight = draggedNode.measured?.height ?? 50;

    const draggedBox = {
      x: draggedNode.position.x,
      y: draggedNode.position.y,
      width: nodeWidth,
      height: nodeHeight,
    };

    const draggedCenterX = draggedBox.x + nodeWidth / 2;

    const otherNodes = nodes.filter((node) => node.id !== draggedNode.id);

    // Sort nodes left to right
    const sortedNodes = [...otherNodes].sort(
      (a, b) => a.position.x - b.position.x
    );

    // Find new insert index based on dragged center
    let insertIndex = sortedNodes.findIndex((node) => {
      const nodeCenterX =
        node.position.x + (node.measured?.width ?? nodeWidth) / 2;
      return draggedCenterX < nodeCenterX;
    });

    if (insertIndex === -1) insertIndex = sortedNodes.length;

    // Rebuild order with dragged node inserted
    const newOrder = [
      ...sortedNodes.slice(0, insertIndex),
      draggedNode,
      ...sortedNodes.slice(insertIndex),
    ];

    // Reposition nodes horizontally with same Y
    const updatedNodes = newOrder.map((node, index) => ({
      ...node,
      position: {
        x: index * horizontalNodeGap,
        y:
          node.id === draggedNode.id
            ? originalPosition[draggedNode.id].y
            : node.position.y, // draggedNode keeps Y
      },
    }));

    // Reset isDragging attribute after done dragging
    const resetDraggingNodes = updatedNodes.map((node) => ({
      ...node,
      data: { ...node.data, isDragging: false },
    }));

    setNodes(resetDraggingNodes);

    // Clean up
    setOriginalPosition((prev) => {
      const { [draggedNode.id]: _, ...rest } = prev;
      return rest;
    });
  };

  const handleFlowMove = (
    _event: MouseEvent | TouchEvent | null,
    viewport: Viewport
  ) => {
    const bounds = boundsRef.current;
    if (!bounds) return;

    const { minX, minY, maxX, maxY } = bounds;

    const { x, y, zoom } = viewport;

    const viewWidth = window.innerWidth / zoom;
    const viewHeight = window.innerHeight / zoom;

    const minPanX = -maxX;
    const maxPanX = -(minX - viewWidth);

    const minPanY = -maxY;
    const maxPanY = -(minY - viewHeight);

    const clampedX = Math.min(Math.max(x, minPanX * zoom), maxPanX * zoom);
    const clampedY = Math.min(Math.max(y, minPanY * zoom), maxPanY * zoom);

    if (x !== clampedX || y !== clampedY) {
      setViewport({ x: clampedX, y: clampedY, zoom });
    }
  };

  const generateWorkFlow = useCallback(
    async (payload: IActionStepRequest): Promise<Node[]> => {
      updateCreationLoading(true);
      updateAlreadyCreated(null);

      const generateWorkFlowData: IActionStepRequest = {
        agent_name: payload.agent_name,
        agent_description: payload.agent_description,
        file: payload.file,
      };

      try {
        const res = await mutation.mutateAsync({ data: generateWorkFlowData });

        if (res?.steps) {
          return convertData(res?.steps);
        }
        setTimeout(() => {
          setAgentSettingExpanded(false);
        }, 1000);
        return [];
      } catch {
        updateCreationLoading(false);
      } finally {
        setTimeout(() => {
          updateCreationLoading(false);
        }, 1000);
      }
      return [];
    },
    [
      convertData,
      mutation,
      setAgentSettingExpanded,
      updateAlreadyCreated,
      updateCreationLoading,
    ]
  );

  return (
    <Box className={styles['react-flow-container']}>
      <Box ref={reactFlowWrapper} sx={{ height: '100vh', width: '100vw' }}>
        <ReactFlow
          minZoom={0.5}
          maxZoom={1.5}
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onNodeDragStop={handleNodeDragStop}
          onNodeDragStart={handleNodeDragStart}
          nodeTypes={nodeTypes}
          edgeTypes={{
            invisible: () => null,
          }}
          proOptions={proOptions}
          className={styles['react-flow']}
          onMove={handleFlowMove}
          nodesConnectable={false}
          fitView
          panOnScroll
          zoomOnScroll
          zoomOnPinch
        >
          <Background size={1.5} />
          <MiniMap
            className={styles.customMiniMap}
            pannable
            zoomable
            maskColor='var(--black-90)'
            zoomStep={1}
          />
        </ReactFlow>
      </Box>

      <ReactFlowControl onAddStep={onAddStep} zoom={zoom} setZoom={setZoom} />

      {!isAgentLKMSettings && (
        <WorkflowConfigurator generateWorkFlow={generateWorkFlow} />
      )}
    </Box>
  );
};

const ReactFlowContainer = () => (
  <ReactFlowProvider>
    <DnDProvider>
      <Flow />
    </DnDProvider>
  </ReactFlowProvider>
);

export default ReactFlowContainer;
