import DropdownIcon from '@/assets/basic-icons/icon-dropdown.svg?react';
import FitIcon from '@/assets/basic-icons/icon-fit.svg?react';
import PlusIcon from '@/assets/basic-icons/icon-plus.svg?react';
import ZoomInIconDisable from '@/assets/basic-icons/icon-zoom-in-disable.svg?react';
import ZoomInIcon from '@/assets/basic-icons/icon-zoom-in.svg?react';
import ZoomOutIconDisable from '@/assets/basic-icons/icon-zoom-out-disable.svg?react';
import ZoomOutIcon from '@/assets/basic-icons/icon-zoom-out.svg?react';
import { fitViewStatistics } from '@/modules/agent/constant/agent';
import { Box, Button, Divider, MenuItem, Select } from '@mui/material';
import { useReactFlow } from '@xyflow/react';
import { useCallback, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

type Props = {
  onAddStep: () => void;
  setZoom: (value: number) => void;
  zoom: number;
};

const ReactFlowControl: React.FC<Props> = ({ onAddStep, setZoom, zoom }) => {
  const { t } = useTranslation();

  const ZOOM_OPTIONS = useMemo(() => [50, 65, 75, 85, 100, 125, 150], []);
  const { zoomIn, zoomOut, fitView, getZoom, getViewport, setViewport } =
    useReactFlow();

  const roundToNearestOption = useCallback(
    (value: number): number => {
      const newZoom = ZOOM_OPTIONS.reduce((prev, curr) =>
        Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev
      );

      return newZoom;
    },
    [ZOOM_OPTIONS]
  );

  useEffect(() => {
    setZoom(roundToNearestOption(zoom));
  }, [zoom, roundToNearestOption, setZoom]);

  const handleFitView = () => {
    fitView(fitViewStatistics);

    setTimeout(() => {
      const newZoom = Math.round(getZoom() * 100);
      setZoom(roundToNearestOption(newZoom));
    }, 100);
  };

  const handleAddStepView = () => {
    fitView(fitViewStatistics);

    onAddStep();

    setTimeout(() => {
      const newZoom = Math.round(getZoom() * 100);
      setZoom(roundToNearestOption(newZoom));
      const { x, y } = getViewport();
      setViewport({ zoom: newZoom / 100, x, y });
    }, 100);
  };

  const handleZoomIn = () => {
    zoomIn();
    const newZoom = Math.round(getZoom() * 100);
    setZoom(roundToNearestOption(newZoom));
  };

  const handleZoomOut = () => {
    zoomOut();
    const newZoom = Math.round(getZoom() * 100);
    setZoom(roundToNearestOption(newZoom));
  };

  const handleZoomChange = (event: any) => {
    const { value } = event.target;
    const zoomInd = ZOOM_OPTIONS.findIndex((option) => option === zoom);
    const valueInd = ZOOM_OPTIONS.findIndex((option) => option === value);
    const zoomTime = Math.abs(zoomInd - valueInd);
    for (let index = 0; index < zoomTime; index++) {
      if (valueInd > zoomInd) {
        zoomIn();
      } else {
        zoomOut();
      }
    }

    setZoom(value);
  };

  const isDisableZoomIn = useMemo(
    () => zoom === ZOOM_OPTIONS[ZOOM_OPTIONS.length - 1],
    [zoom, ZOOM_OPTIONS]
  );

  const isDisableZoomOut = useMemo(
    () => zoom === ZOOM_OPTIONS[0],
    [zoom, ZOOM_OPTIONS]
  );

  return (
    <Box className={styles.reactFlowControl}>
      <Button
        variant='contained'
        onClick={handleAddStepView}
        startIcon={
          <PlusIcon width={16} height={16} style={{ fill: 'white' }} />
        }
        sx={{
          '& .MuiButton-startIcon': {
            marginRight: '0px',
          },
        }}
        className={styles.addButton}
      >
        {t('agent.addStep')}
      </Button>

      <Divider orientation='vertical' className={styles.divider} />

      <Select
        value={zoom}
        onChange={handleZoomChange}
        className={styles.scaleBtn}
        size='small'
        IconComponent={DropdownIcon}
        displayEmpty
        MenuProps={{
          anchorOrigin: {
            vertical: 'top',
            horizontal: 'left',
          },
          transformOrigin: {
            vertical: 'bottom',
            horizontal: 'left',
          },
          sx: {
            transform: 'translateY(-5px)',
          },
          PaperProps: {
            sx: {
              borderRadius: '6px',
              height: 'fit-content',
              background: 'var(--white)',
              boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.20)',
              padding: '4px',

              'ul': {
                padding: 0,
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
                'li': {
                  fontSize: '14px',
                  padding: '4px',
                  borderRadius: '6px',
                },
                'li::after': {
                  right: '4px !important',
                  width: '12px !important',
                  height: '12px',
                },
              },
            },
          },
        }}
        sx={{
          maxWidth: '65px',
          fontSize: '14px',
          fontWeight: 500,
          lineHeight: '140%',
          '& .MuiSelect-select': {
            padding: '4px',
            fontSize: '14px',
            width: '37px',
            overflow: 'visible',
          },
          '& .MuiSelect-icon': {
            right: '6px',
            top: '50%',
            transform: 'translateY(-50%)',
            transition: 'transform 0.3s ease',
          },
          '& .MuiSelect-iconOpen': {
            transform: 'translateY(-50%) rotate(180deg)',
          },
          '& .MuiOutlinedInput-input': {
            paddingRight: '22px !important',
          },
        }}
      >
        {ZOOM_OPTIONS.map((value) => (
          <MenuItem key={value} value={value}>
            {value}%
          </MenuItem>
        ))}
      </Select>

      <Button
        variant='text'
        disabled={isDisableZoomIn}
        onClick={handleZoomIn}
        className={styles.actionBtn}
      >
        {isDisableZoomIn ? (
          <ZoomInIconDisable width='24' height='24' />
        ) : (
          <ZoomInIcon width='24' height='24' />
        )}
      </Button>

      <Button
        variant='text'
        disabled={isDisableZoomOut}
        onClick={handleZoomOut}
        className={styles.actionBtn}
      >
        {isDisableZoomOut ? (
          <ZoomOutIconDisable width='24' height='24' />
        ) : (
          <ZoomOutIcon width='24' height='24' />
        )}
      </Button>

      <Button
        variant='text'
        onClick={handleFitView}
        className={styles.actionBtn}
      >
        <FitIcon width='24' height='24' />
      </Button>
    </Box>
  );
};

export default ReactFlowControl;
