import ReactFlowContainer from '@/modules/agent/components/ReactFlowContainer';
import styles from '@/modules/agent/components/WorkflowReview/WorkflowReview.module.scss';
import { WorkflowReviewDoc } from '@/modules/agent/components/WorkflowReviewDoc/WorkflowReviewDoc';
import { useGetConversationStarter } from '@/modules/agent/hooks/useAgent';
import { AgentType, ModeType } from '@/modules/agent/type/agent';
import { getChatMsgById } from '@/modules/chat/api/chat';
import { ChatMain } from '@/modules/chat/components/ChatMain/ChatMain';
import { useChatDataHandler } from '@/modules/chat/hooks/chatDataHandler';
import { useAgentDetail } from '@/modules/chat/hooks/useAgents';
import { useCreateNewChat } from '@/modules/chat/hooks/useChat';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import {
  chatDataAtom,
  isCreatingChatAtom,
  isGeneratingAtom,
  isSecretModeAtom,
  selectedToolAtom,
  showWorkflowReviewDocAtom,
} from '@/modules/chat/jotai/chat';
import {
  EChatMode,
  ERole,
  type IChatResponse,
} from '@/modules/chat/types/chat';
import { IMessage } from '@/modules/chat/types/message';
import { USER_ID } from '@/modules/chat/types/user';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { EChatType } from '@/modules/core/types';
import { EStreamType, IInfoMessage } from '@/types/layout';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom, useSetAtom } from 'jotai';
import { Resizable } from 're-resizable';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useCookies } from 'react-cookie';
import { useTranslation } from 'react-i18next';
import { useParams, useSearchParams } from 'react-router-dom';
import AIFeedback from '../CreateBasicAgent/AIFeedback/AIFeedback';

interface Props {
  mode: string;
}

// Replace with actual model data
const MOCK_MODEL = 'chatgpt4.o';

const WorkflowReviewMain = ({ mode }: Props) => {
  const { agentId } = useParams();
  const [cookies] = useCookies([USER_ID]);
  const { t } = useTranslation('tax');
  const params = useParams();
  const [searchParams] = useSearchParams();
  const { initLayoutData } = useChatDataHandler();
  const { setChatDataByHistoryCallback } = useMainContext();

  const [infoMessage, setInfoMessage] = useState<IInfoMessage | undefined>(
    undefined
  );
  const [hasRunChatStarter, setHasRunChatStarter] = useState<boolean>(false);
  const [newChat, setNewChat] = useState<IChatResponse>();

  const hasRunRef = useRef<boolean>(false);
  const currentHistoryIdRef = useRef<number>(-1);
  const resizableRef = useRef<Resizable>(null);

  const [{ data: agentDetailData }] = useAtom(useAgentDetail);
  const [showDoc] = useAtom(showWorkflowReviewDocAtom);
  const [{ mutateAsync: createNewChatMutation }] = useAtom(useCreateNewChat);
  const [, setAgentDetailId] = useAtom(agentDetailIdAtom);
  const [, setChatData] = useAtom(chatDataAtom);
  const setIsCreatingChat = useSetAtom(isCreatingChatAtom);
  const [, setIsSecretMode] = useAtom(isSecretModeAtom);
  const [isGenerating] = useAtom(isGeneratingAtom);
  const setShowDoc = useSetAtom(showWorkflowReviewDocAtom);
  const [, setSelectedTool] = useAtom(selectedToolAtom);
  const [{ data: conversationStarterData, isFetched }] = useAtom(
    useMemo(() => useGetConversationStarter(agentId ?? ''), [agentId])
  );

  useEffect(() => {
    if (hasRunRef.current) return;
    hasRunRef.current = true;
    setShowDoc(false);

    if (agentId) {
      setAgentDetailId(agentId);
      setIsCreatingChat({
        isCreating: true,
        updated: Date.now(),
      });

      (async () => {
        const result = await createNewChatMutation({
          agentId: agentId ?? '',
          chatMode: EChatMode.WORKFLOW_STUDIO,
          userId: cookies.userId,
          title: '',
          model: MOCK_MODEL,
          chatType: EChatType.ExpertAgentChat,
        });

        if (result) {
          setNewChat(result);
        }
        setIsCreatingChat({
          isCreating: false,
          updated: Date.now(),
        });
      })();
    }
  }, [agentId]);

  useEffect(
    () => () => {
      setNewChat(undefined);
      setAgentDetailId('');
      setHasRunChatStarter(false);
    },
    []
  );

  useEffect(() => {
    if (hasRunChatStarter) return;

    if (conversationStarterData?.some((starter) => !!starter?.trim())) {
      const starter =
        conversationStarterData[
          Math.floor(Math.random() * conversationStarterData.length)
        ];

      setInfoMessage({
        type: 'chat',
        message: starter,
        createdAt: new Date().toISOString(),
        role: ERole.ASSISTANT,
      });

      setHasRunChatStarter(true);
    }

    if (
      isFetched &&
      !conversationStarterData?.some((starter) => !!starter?.trim())
    ) {
      setInfoMessage(undefined);
    }
  }, [conversationStarterData]);

  useEffect(() => {
    (async () => {
      if (newChat) {
        const messagesData = await getChatMsgById(newChat.id.toString());

        const messages: {
          [key: string]: IMessage;
        } = {};
        messagesData.forEach((item) => {
          messages[item.uuid] = item;
        });

        setChatData({
          title: newChat.title,
          historyId: newChat.id,
          messages,
          selectedAgent: newChat.agent_id ?? undefined,
        });
      }
    })();
  }, [newChat, setChatData]);

  useEffect(() => {
    if (showDoc && resizableRef.current) {
      resizableRef.current.updateSize({ width: '50vw' });
    }
  }, [showDoc]);

  useEffect(
    () => () => {
      setSelectedTool({
        isSelectedCanvas: false,
        selectedMode: null,
      });
    },
    []
  );

  useEffect(() => {
    const isSecretMode = searchParams.get('secret-chat') === 'true';
    setIsSecretMode(isSecretMode);

    /** route 파라미터에 따른 채팅 데이터 초기화 */
    const currentHistoryId = params?.historyId ? Number(params.historyId) : -1;
    const isNewChatGenerating =
      currentHistoryIdRef.current === -1 && isGenerating;

    /** 비밀 모드 설정 */
    if (isSecretMode) {
      initLayoutData({
        isSecretMode,
      });
    } else if (
      /** 기존 채팅 불러오는 경우 */
      (!isNewChatGenerating || currentHistoryIdRef.current !== -1) &&
      currentHistoryIdRef.current !== currentHistoryId
    ) {
      setChatDataByHistoryCallback(currentHistoryId).then(() => {
        initLayoutData({});
      });
    } else if (currentHistoryId === -1) {
      /** 새로운 채팅 생성 경우 */
      initLayoutData({});
    }
    currentHistoryIdRef.current = currentHistoryId;
  }, [params, searchParams]);

  const getMode = useMemo(() => {
    if (agentDetailData?.formattedData?.mode === AgentType.PRO) {
      return AgentType.PRO;
    }
    return AgentType.GENERAL;
  }, [agentDetailData]);

  return (
    <>
      <div
        className={`${styles.workflowReviewMain} ${mode === ModeType.CHAT ? '' : `hidden`}`}
      >
        <Resizable
          ref={resizableRef}
          className={cn(
            styles.chatPanelContainerResizable,
            showDoc ? styles.halfWidth : styles.fullWidth
          )}
          defaultSize={{
            width: showDoc ? '50vw' : '100vw',
          }}
          minWidth={410}
          maxWidth={showDoc ? '70vw' : '100vw'}
          enable={{ right: true }}
        >
          <Box className={styles.chatPanelContainer}>
            <ChatMain
              mode={getMode}
              historyId={newChat?.id.toString()}
              streamType={EStreamType.WORKFLOW_REPORT}
              infoMessage={{
                type: 'info',
                message:
                  infoMessage?.message ??
                  `[${agentDetailData?.formattedData.name ?? t('chat.agentTitle')}]${t('report.workflowReviewInfoMsg')}`,
                createdAt: new Date()?.toString(),
                role: ERole.AI,
              }}
            />
          </Box>
        </Resizable>
        {showDoc && <WorkflowReviewDoc />}
      </div>
      {mode === ModeType.DASHBOARD ? (
        <ReactFlowContainer />
      ) : mode === ModeType.FEEDBACK ? (
        <AIFeedback />
      ) : (
        <></>
      )}
    </>
  );
};

export { WorkflowReviewMain };
