import AttachmentIcon from '@/assets/basic-icons/icon-attachment-blue.svg?react';
import IconClose from '@/assets/basic-icons/icon-close-01.svg?react';
import IconExpand from '@/assets/basic-icons/icon-expand-gray.svg?react';
import InfoIcon from '@/assets/basic-icons/icon-info.svg?react';
import IconMagic from '@/assets/basic-icons/icon-magic-tool.svg?react';
import IconPlusCircle from '@/assets/basic-icons/icon-plus-circle.svg?react';
import IconPlus from '@/assets/basic-icons/icon-plus.svg?react';
import RefreshIcon from '@/assets/basic-icons/icon-refresh.svg?react';
import IconDelete from '@/assets/basic-icons/icon-trash-gray.svg?react';
import UploadIcon from '@/assets/basic-icons/icon-upload.svg?react';
import IconDoc from '@/assets/file-icons/icon-doc.svg?react';
import IconJpg from '@/assets/file-icons/icon-jpg.svg?react';
import IconPdf from '@/assets/file-icons/icon-pdf.svg?react';
import IconPng from '@/assets/file-icons/icon-png.svg?react';
import IconPpt from '@/assets/file-icons/icon-ppt.svg?react';
import IconPptx from '@/assets/file-icons/icon-pptx.svg?react';
import IconXls from '@/assets/file-icons/icon-xls.svg?react';
import IconXlsx from '@/assets/file-icons/icon-xlsx.svg?react';
import { useCreateAgentHistory } from '@/modules/admin/hooks/useAgentManagement';
import AgentTool from '@/modules/agent/components/CreateAgentForm/AgentTool';
import AgentDialogFooter from '@/modules/agent/components/CreateAgentForm/Dialog/DialogFooter';
import ToolContentChildren from '@/modules/agent/components/CreateAgentForm/Dialog/Tool';
import {
  useAgentDocumentMutation,
  useAgentUpsertMutation,
  useCreateBasicAgentMutation,
} from '@/modules/agent/hooks/useAgent';
import {
  agentCreationDialogDataAtom,
  agentCreationLoadingAtom,
  agentDataAtom,
  agentIdForUpdating,
  agentReasonChangeAtom,
  agentUpsertLoadingAtom,
  alreadyCreatedWorkflowAtom,
  conversationStarterAtom,
  generalAgentIdAtom,
  hasRunChatStarterAtom,
  selectedAgentToolsAtom,
} from '@/modules/agent/jotai/agent';
import { AgentModalSettings } from '@/modules/agent/layout/HeaderWorkFlow/buttons';
import { AgentAdminConfirmDialog } from '@/modules/agent/layout/HeaderWorkFlow/modals/AgentAdminConfirmDialog';
import AgentDeployMessageContent from '@/modules/agent/layout/HeaderWorkFlow/modals/AgentDeployMessageContent';
import {
  AgentDto,
  AgentType,
  BasicAgentExpansion,
  CustomFile,
  IAgentCreationResponse,
  IAlreadyCreatedAgentGeneral,
  IToolModel,
  type IActionStepRequest,
} from '@/modules/agent/type/agent';
import {
  generateInstructionMutation,
  generateRecommendedToolsMutation,
  useAgentDetail,
  useGetAllTools,
  useGetGeneralAgent,
} from '@/modules/chat/hooks/useAgents';
import { useCreateNewChat } from '@/modules/chat/hooks/useChat';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import { chatDataAtom } from '@/modules/chat/jotai/chat';
import {
  EChatAgentStatus,
  IChatAgentPutRequest,
  IChatAgentResponse,
  IChatStarter,
} from '@/modules/chat/types/agents';
import { EChatMode } from '@/modules/chat/types/chat';
import { USER_ID } from '@/modules/chat/types/user';
import { BaseTextField } from '@/modules/core/components/common/BaseTextField';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { HttpMethod } from '@/modules/core/constant';
import { EChatType } from '@/modules/core/types';
import { RoutesURL } from '@/routers/routes';
import { EButtonType } from '@/types/common';
import { deepEqual, distinctByKey } from '@/utils';
import { agentStepsConverter } from '@/utils/agentUtil';
import { showSnackbar } from '@/utils/snackbarUtil';
import {
  Box,
  Button,
  Skeleton,
  TextField,
  tooltipClasses,
} from '@mui/material';
import { Node } from '@xyflow/react';
import cn from 'classnames';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import React, {
  RefObject,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useCookies } from 'react-cookie';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import AgentAccordion from '../CreateBasicAgent/Accordions/Accordion';
import InstructionContentChildren from './Dialog/Instruction';
import styles from './index.module.scss';

interface IProps {
  mode: AgentType;
  generateWorkFlow?: (data: IActionStepRequest) => Promise<Node[]>;
  showRecipe?: boolean;
  setShowRecipe?: (show: boolean) => void;
}

enum AgentDialogType {
  Instruction,
  Tool,
}

const fileApiPath = {
  document: '/documents',
  knowledge: '/upload_knowledge_document',
};

const SNACK_BAR_DURATION = 3;
const MOCK_MODEL = 'chatgpt4.o';
const [nameMaxLength, descMaxLength, instructionMaxLength] = [50, 1000, 3000];
const [digits, oneKilobyte] = [2, 1024];
const MAX_TOOL = 4;

const CreateAgentForm = ({
  mode,
  generateWorkFlow,
  showRecipe = true,
  setShowRecipe,
}: IProps) => {
  const [cookies] = useCookies([USER_ID]);
  const { agentId } = useParams();
  const { t: taxTranslation } = useTranslation('tax');
  const { t } = useTranslation('admin');
  const navigate = useNavigate();
  const location = useLocation();

  const [modalSettings, setModalSettings] = useState<AgentModalSettings | null>(
    null
  );
  const [alreadyCreatedGeneral, setAlreadyCreatedGeneral] =
    useState<IAlreadyCreatedAgentGeneral | null>(null);
  const [expand, setExpand] = useState<BasicAgentExpansion>({
    information: !agentId,
    recipe: !!agentId,
  });
  const [applyingAgent, setApplyingAgent] = useState(false);
  const [isChanged, setIsChanged] = useState(false);
  const [isEditAdmin, setIsEditAdmin] = useState<boolean>(
    !location.pathname.includes('/settings')
  );

  const fileInputRef = useRef<HTMLInputElement>(null);
  const knowledgeFileInputRef = useRef<HTMLInputElement>(null);

  const [idForUpdating, setIdForUpdating] = useAtom(agentIdForUpdating);
  const [agentData, updateAgentData] = useAtom(agentDataAtom);
  const [{ mutate: reGenerate }] = useAtom(generateInstructionMutation);
  const [{ mutateAsync: createNewChatMutation, data: newChat }] =
    useAtom(useCreateNewChat);
  const [, setHasRunChatStarter] = useAtom(hasRunChatStarterAtom);
  const [, setAgentDetailId] = useAtom(agentDetailIdAtom);
  const [{ data: generalAgent }] = useAtom(useGetGeneralAgent);
  const [, setGeneralAgentId] = useAtom(generalAgentIdAtom);
  const [{ data: agentDetail }] = useAtom(useAgentDetail);
  const [
    { mutateAsync: generateInstruction, isPending: generatingInstruction },
  ] = useAtom(generateInstructionMutation);
  const [conversationStarter, setConversationStarter] = useAtom(
    conversationStarterAtom
  );
  const [, setChatData] = useAtom(chatDataAtom);
  const creationLoading = useAtomValue(agentCreationLoadingAtom);
  const [upsertLoading, updateUpsertLoading] = useAtom(agentUpsertLoadingAtom);
  const updateAlreadyCreated = useSetAtom(alreadyCreatedWorkflowAtom);
  const [selectedTools, updateSelectedTools] = useAtom(selectedAgentToolsAtom);
  const [, setAgentDialog] = useAtom(agentCreationDialogDataAtom);
  const [{ mutateAsync: uploadFile }] = useAtom(useAgentDocumentMutation);
  const [
    {
      data: recommendedTools,
      isPending: recommendedToolsLoading,
      mutateAsync: generateTools,
    },
  ] = useAtom(generateRecommendedToolsMutation);
  const [agentReasonChange] = useAtom(agentReasonChangeAtom);
  const [{ refetch: getAllTools }] = useAtom(useGetAllTools);
  const [{ mutateAsync: createAgent, isPending: creatingAgent }] = useAtom(
    useCreateBasicAgentMutation
  );
  const [{ mutateAsync: mutateAgent, isPending: updatingAgent }] = useAtom(
    useAgentUpsertMutation
  );
  const [{ mutateAsync: postHistory }] = useAtom(useCreateAgentHistory);

  const fileSize = useCallback((file: CustomFile) => {
    if (!file) {
      return '';
    }
    const oneMegabyte = oneKilobyte ** 2;
    if (file.size < oneMegabyte) {
      return `${(file.size / oneKilobyte).toFixed(digits)} KB`;
    }

    return `${(file.size / oneMegabyte).toFixed(digits)} MB`;
  }, []);

  const isAgentOperationSettings = useMemo(
    () =>
      location.pathname.includes(RoutesURL.SETTINGS_AGENT_GENERAL_OPERATION),
    [location.pathname]
  );

  const nameCounter = useMemo(
    () => `${agentData.name?.length ?? 0}/${nameMaxLength}`,
    [agentData.name]
  );
  const descriptionCounter = useMemo(
    () => `${agentData.description?.length ?? 0}/${descMaxLength}`,
    [agentData.description]
  );
  const instructionCounter = useMemo(
    () => `${agentData.instruction?.length ?? 0}/${instructionMaxLength}`,
    [agentData.instruction]
  );

  const alreadyCreateBasic = useMemo(
    () =>
      Boolean(alreadyCreatedGeneral) &&
      alreadyCreatedGeneral?.name === agentData.name &&
      alreadyCreatedGeneral?.description === agentData.description &&
      alreadyCreatedGeneral?.instruction === agentData.instruction &&
      deepEqual(
        selectedTools.map((tool) => tool.id).sort((a: any, b: any) => a - b),
        alreadyCreatedGeneral?.tools?.sort()
      ) &&
      deepEqual(
        conversationStarter.toSorted((a: any, b: any) => a - b),
        alreadyCreatedGeneral?.starter?.sort((a: any, b: any) => a - b)
      ),
    [
      alreadyCreatedGeneral,
      agentData.name,
      agentData.description,
      agentData.instruction,
      selectedTools,
      conversationStarter,
    ]
  );
  const alreadyCreatedPro = useMemo(() => !!agentId, [agentId]);

  const isPro = useMemo(() => mode?.toLowerCase() === AgentType.PRO, [mode]);
  const enabledGenRecipe = useMemo(
    () =>
      agentData.name &&
      agentData.description &&
      !(
        alreadyCreatedGeneral?.name === agentData.name &&
        alreadyCreatedGeneral?.description === agentData.description
      ),
    [agentData.description, agentData.name, alreadyCreatedGeneral]
  );
  const [isGenerateTool, setIsGenerateTool] = useState<boolean>(false);

  const isEnableSubmit = useMemo(() => {
    if (!!agentId && isChanged) return true;

    if (isPro) {
      return isChanged;
    }

    return isChanged && isGenerateTool;
  }, [isPro, agentId, isChanged, isGenerateTool]);

  useEffect(() => {
    if (newChat) {
      setChatData({
        historyId: newChat.id.toString(),
        selectedAgent: newChat.agent_id,
        title: newChat.title,
      });
    }
  }, [newChat]);

  useEffect(() => {
    if (recommendedTools?.data?.tools || recommendedTools?.tools) {
      const newSelectedTools = distinctByKey(
        [...(recommendedTools?.data?.tools || recommendedTools?.tools || [])],
        'id'
      ).map(
        (item) =>
          ({
            id: item.id,
            name: item.name,
            description: item.description,
            checked: true,
            type: item.type,
          }) as IToolModel
      );
      updateSelectedTools(newSelectedTools);
    }
  }, [recommendedTools]);

  // reset agent data when change route
  useEffect(() => {
    updateAgentData({
      name: '',
      instruction: '',
      description: '',
      id: '',
      type: undefined,
    });
  }, [location.pathname]);

  useEffect(() => {
    if (generalAgent || agentDetail) {
      updateAgentData({
        name:
          generalAgent?.data?.agent?.name ??
          generalAgent?.agent?.name ??
          agentDetail?.rawData.name,
        description:
          generalAgent?.data?.agent?.description ??
          generalAgent?.agent?.description ??
          agentDetail?.rawData.description,
        instruction:
          generalAgent?.data?.instruction ?? generalAgent?.instruction ?? '',
      });

      updateSelectedTools(
        distinctByKey(
          generalAgent?.data?.tools ?? generalAgent?.tools ?? [],
          'id'
        ).map(
          (item) =>
            ({
              id: item.id,
              name: item.name,
              description: item.description,
              checked: true,
              type: item.type,
            }) as IToolModel
        )
      );

      if (!isPro && agentId) {
        setAlreadyCreatedGeneral({
          name: generalAgent?.data?.agent?.name ?? generalAgent?.agent?.name,
          description:
            generalAgent?.data?.agent?.description ??
            generalAgent?.agent?.description,
          instruction:
            generalAgent?.data?.instruction ?? generalAgent?.instruction,
          tools:
            (generalAgent?.data?.tools || generalAgent?.tools)
              ?.map((item) => item.id)
              .filter((id): id is number => typeof id === 'number') ?? [],
          starter: [...conversationStarter],
        });
      }
    }
  }, [generalAgent, agentDetail]);

  const handleChangeName = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      if (creationLoading) {
        return;
      }

      setIsChanged(true);
      updateAgentData({ name: event.target.value });
    },
    [creationLoading, updateAgentData]
  );

  const handleOnKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
    }
  };

  const handleChangeDescription = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      if (creationLoading) {
        return;
      }

      updateAgentData({ description: event.target.value });
      setIsChanged(true);
    },
    [creationLoading, updateAgentData]
  );

  const handleChangeInstruction = (
    event: React.ChangeEvent<HTMLInputElement> | string
  ) => {
    const updated = typeof event === 'string' ? event : event.target.value;
    updateAgentData({ instruction: updated });
    setIsChanged(true);
    if (!updated) {
      updateSelectedTools([]);
    }
  };

  const handleGenerateWorkflow = useCallback(async () => {
    const data = {
      agent_name: agentData?.name ?? '',
      agent_description: agentData.description ?? '',
      file: agentData.file ?? null,
    };

    if (generateWorkFlow) {
      return generateWorkFlow(data);
    }

    return [];
  }, [agentData.description, agentData.file, agentData.name, generateWorkFlow]);

  const handleFileChange = useCallback(
    async (event: React.ChangeEvent<HTMLInputElement>, isKnowledge = false) => {
      const path = isKnowledge ? fileApiPath.knowledge : fileApiPath.document;
      const file = event.target.files?.[0];
      if (file) {
        updateAgentData(isKnowledge ? { knowledgeFile: file } : { file });
      }
      if (!creationLoading && !isEditAdmin) {
        await uploadFile(
          {
            data: {
              path,
              file: event.target.files![0],
              uploaded_user_id: cookies.userId ?? 1,
            },
            callback: (
              isSuccess: boolean,
              response: {
                data: { message: string; document: any };
                document: any;
                message: string;
              }
            ) => {
              updateAgentData({
                fileId: response?.data?.document?.id ?? response?.document?.id,
              });
              showSnackbar(
                response?.data?.message ||
                  response?.message ||
                  t('apiErrorResponse.uploadAgentFile'),
                isSuccess ? 'success' : 'error',
                SNACK_BAR_DURATION,
                undefined,
                {
                  SnackbarProps: {
                    style: {
                      top: '40px',
                    },
                  },
                }
              );
            },
          },
          {
            onError: () => {
              updateAgentData(
                isKnowledge
                  ? { knowledgeFile: undefined }
                  : { file: undefined, fileId: undefined }
              );
            },
          }
        );
      }
      event.target.value = '';
    },
    [
      cookies.userId,
      creationLoading,
      isEditAdmin,
      t,
      updateAgentData,
      uploadFile,
    ]
  );

  const handleUploadFileClick = useCallback(
    (ref: RefObject<HTMLInputElement | null>) => {
      if (!isEditAdmin) return;

      if (!creationLoading) {
        ref.current?.click();
      }
    },
    [creationLoading, isEditAdmin]
  );

  const handleRemoveFile = useCallback(
    (isKnowledge?: boolean) => {
      const file: CustomFile = undefined;
      if (creationLoading) return;
      updateAgentData(
        isKnowledge ? { knowledgeFile: file } : { file, fileId: undefined }
      );
    },
    [creationLoading, updateAgentData]
  );

  const reGenerateInstruction = useCallback(async () => {
    reGenerate();
  }, [reGenerate]);

  const applyInstruction = useCallback(
    (value: string) => {
      updateAgentData({ instruction: value });

      generateTools();

      setAgentDialog({
        dialogOpen: false,
      });
    },
    [updateAgentData, generateTools, setAgentDialog]
  );

  const applyTools = useCallback(
    (targetTools: IToolModel[]) => {
      updateSelectedTools(distinctByKey(targetTools, 'id'));

      setAgentDialog({
        dialogOpen: false,
      });
    },
    [setAgentDialog, updateSelectedTools]
  );

  const aiGenTool = useCallback(() => {
    if (creationLoading) return;
    agentData.instruction &&
      agentData.description &&
      agentData.name &&
      generateTools();
  }, [
    agentData.description,
    agentData.instruction,
    agentData.name,
    creationLoading,
    generateTools,
  ]);

  const removeTool = useCallback(
    (toolId: number | null) => {
      if (creationLoading) return;
      const newSelectedTools = [...selectedTools].filter(
        ({ id }) => toolId !== id
      );
      updateSelectedTools(distinctByKey(newSelectedTools, 'id'));
    },
    [creationLoading, selectedTools, updateSelectedTools]
  );

  const openAgentDialog = useCallback(
    (type: AgentDialogType) => {
      if (creationLoading) return;
      let contentChildren = <></>;
      let actionsChildren = (
        <AgentDialogFooter
          showReGenerate
          reGenerate={reGenerateInstruction}
          applyInstruction={(instruction) => applyInstruction(instruction)}
        />
      );
      let dialogTitle = '';
      switch (type) {
        case AgentDialogType.Instruction:
          contentChildren = <InstructionContentChildren />;
          dialogTitle = taxTranslation('agent.configuration.instruction');
          break;
        case AgentDialogType.Tool:
          actionsChildren = (
            <AgentDialogFooter
              applyTools={(selected) =>
                applyTools(distinctByKey(selected, 'id'))
              }
            />
          );
          contentChildren = <ToolContentChildren />;
          dialogTitle = taxTranslation('agent.configuration.tool');
          break;
        default:
          break;
      }

      setAgentDialog({
        dialogOpen: true,
        contentChildren,
        actionsChildren,
        dialogTitle,
      });
    },
    [
      creationLoading,
      reGenerateInstruction,
      setAgentDialog,
      applyInstruction,
      taxTranslation,
      applyTools,
    ]
  );

  const expandInstruction = useCallback(() => {
    agentData.name &&
      agentData.description &&
      openAgentDialog(AgentDialogType.Instruction);
    generateInstruction();
  }, [
    agentData.description,
    agentData.name,
    openAgentDialog,
    generateInstruction,
  ]);

  const handleInstructionDialogOpen = useCallback(() => {
    agentData.name &&
      agentData.description &&
      openAgentDialog(AgentDialogType.Instruction);
    generateInstruction();
  }, [
    agentData.description,
    agentData.name,
    openAgentDialog,
    generateInstruction,
  ]);

  const handleToolDialogOpen = useCallback(() => {
    openAgentDialog(AgentDialogType.Tool);
    getAllTools();
  }, [creationLoading, openAgentDialog, getAllTools]);

  const cancelEditing = useCallback(() => {
    updateAgentData({
      description: alreadyCreatedGeneral?.description,
      name: alreadyCreatedGeneral?.name,
      instruction: alreadyCreatedGeneral?.instruction,
    });
    setIsChanged(false);
    setIsEditAdmin(false);
  }, [alreadyCreatedGeneral, updateAgentData]);

  const handleCreateAgent = useCallback(
    async (
      reviewStatus: EChatAgentStatus,
      selectedToolList: (number | null)[],
      generatedNodes: Node[]
    ) => {
      const agentDto: AgentDto = {
        steps: agentStepsConverter(generatedNodes),
        document_id: agentData.fileId ?? 0,
        general_agent_instruction: {
          instruction: agentData.instruction ?? '',
          tool_ids: [...selectedToolList],
        },
        agent: {
          name: agentData.name!,
          description: agentData.description!,
          agent_type: isPro ? AgentType.PRO : AgentType.GENERAL,
          category: 'Engineering',
          org_id: 1,
          review_status: reviewStatus,
          team_id: 1,
          usage_scope: 'public',
          use_count: 0,
          steps: agentStepsConverter(generatedNodes),
          created_user_id: cookies.userId ?? 1,
        },
        created_user_id: cookies.userId ?? 1,
        chat_starters: [...conversationStarter].filter((item) => !!item),
      };

      try {
        return await createAgent({
          data: agentDto,
          callback: (isSuccess: boolean, response: IAgentCreationResponse) => {
            const created = response?.data?.agent ?? response.agent;
            if (isSuccess) {
              updateAgentData({ id: created.id });

              if (isPro) {
                updateAlreadyCreated({
                  name: agentData.name,
                  description: agentData.description,
                  starter: [...conversationStarter],
                });
              } else {
                setAlreadyCreatedGeneral({
                  ...agentData,
                  tools: [...selectedToolList],
                  starter: [...conversationStarter],
                });
                navigate(`${RoutesURL.GENERAL_AGENT}/${created.id}`);

                // call API to post starter chat

                setGeneralAgentId(created.id.toString());
              }
              showSnackbar(
                (response?.data?.message ?? response.message) ||
                  t('apiErrorResponse.createAgent'),
                isSuccess ? 'success' : 'error',
                SNACK_BAR_DURATION,
                undefined,
                {
                  SnackbarProps: {
                    style: {
                      top: '40px',
                    },
                  },
                }
              );
            }
          },
        });
      } catch {
        showSnackbar(
          t('apiErrorResponse.createAgent'),
          'error',
          SNACK_BAR_DURATION,
          undefined,
          {
            SnackbarProps: {
              style: {
                top: '40px',
              },
            },
          }
        );
      }
    },
    [
      agentData,
      conversationStarter,
      cookies.userId,
      createAgent,
      isPro,
      navigate,
      setGeneralAgentId,
      t,
      updateAgentData,
      updateAlreadyCreated,
      setAlreadyCreatedGeneral,
    ]
  );

  const handleUpdateAgent = useCallback(
    async (
      selectedToolList: (number | null)[],
      generatedNodes: Node[],
      reviewStatus?: EChatAgentStatus
    ) => {
      const updatedData: IChatAgentPutRequest = {
        agent: {
          name: agentData.name ?? agentDetail?.rawData.name ?? '',
          description:
            agentData.description ?? agentDetail?.rawData.description ?? '',
          reject_description:
            agentData.rejectDescription ??
            agentDetail?.rawData.reject_description ??
            '',
          review_status:
            reviewStatus ??
            agentDetail?.rawData?.review_status ??
            generalAgent?.data?.agent?.review_status ??
            generalAgent?.agent?.review_status,
          created_at: agentDetail?.rawData.created_at ?? '',
          created_user_id:
            agentDetail?.rawData?.created_user_id ??
            generalAgent?.data?.agent?.created_user_id ??
            generalAgent?.agent?.created_user_id ??
            1,
          id:
            agentData.id ??
            agentDetail?.rawData?.id ??
            generalAgent?.data?.agent?.id ??
            generalAgent?.agent?.id,
          agent_type: isPro ? AgentType.PRO : AgentType.GENERAL,
          category:
            agentDetail?.rawData?.category ??
            generalAgent?.data?.agent?.category ??
            generalAgent?.agent?.category,
          org_id:
            agentDetail?.rawData?.org_id ??
            generalAgent?.data?.agent?.org_id ??
            generalAgent?.agent?.org_id,
          steps: agentStepsConverter(generatedNodes, HttpMethod.PUT),
          team_id:
            agentDetail?.rawData.team_id ??
            generalAgent?.data?.agent?.team_id ??
            generalAgent?.agent?.team_id,
          updated_at: new Date().toISOString(),
          usage_scope:
            agentDetail?.rawData.usage_scope ??
            generalAgent?.data?.agent?.usage_scope ??
            generalAgent?.agent?.usage_scope,
          use_count:
            agentDetail?.rawData.use_count ??
            generalAgent?.data?.agent?.use_count ??
            generalAgent?.agent?.use_count,
        },
        general_agent_instruction: {
          instruction:
            agentData.instruction ??
            generalAgent?.data?.instruction ??
            generalAgent?.instruction ??
            '',
          tool_ids: [...selectedToolList],
        },
        chat_starters: [...conversationStarter]
          .filter((item) => !!item)
          .map(
            (item, index) =>
              ({
                id: index + 1,
                starter: item,
              }) as IChatStarter
          ),
      };
      try {
        await mutateAgent({
          data: updatedData,
          callback: async (
            isSuccess: boolean,
            response: {
              data: { message: string; agent: IChatAgentResponse };
              message: string;
              agent: IChatAgentResponse;
            }
          ) => {
            const updated = response?.data?.agent ?? response?.agent;
            if (isSuccess) {
              if (isAgentOperationSettings) {
                postHistory({
                  agent_id:
                    agentData.id ??
                    agentDetail?.rawData?.id ??
                    generalAgent?.data?.agent?.id ??
                    generalAgent?.agent?.id ??
                    idForUpdating,
                  modified_user_id: cookies.userId ?? 1,
                  description: agentReasonChange,
                });
              }
              if (isPro) {
                updateAlreadyCreated({
                  name: agentData.name,
                  description: agentData.description,
                  starter: [...conversationStarter],
                });
              } else {
                setAlreadyCreatedGeneral({
                  ...agentData,
                  tools: [...selectedToolList],
                  starter: [...conversationStarter],
                });

                const chat = await createNewChatMutation({
                  agentId: updated.id,
                  chatMode: EChatMode.AGENT_CHAT,
                  userId: cookies.userId,
                  title:
                    generalAgent?.data?.agent?.name ??
                    generalAgent?.agent?.name ??
                    '',
                  model: MOCK_MODEL,
                  chatType: EChatType.ExpertAgentChat,
                });
                setHasRunChatStarter(false);
                setChatData({
                  historyId: chat?.historyId?.toString(),
                  messages: {},
                });
                setAgentDetailId(updated.id.toString());
              }
            }
            showSnackbar(
              response?.data?.message ||
                response.message ||
                t('apiErrorResponse.updateAgent'),
              isSuccess ? 'success' : 'error',
              SNACK_BAR_DURATION,
              undefined,
              {
                SnackbarProps: {
                  style: {
                    top: '40px',
                  },
                },
              }
            );
          },
        });
      } catch {
        showSnackbar(
          t('apiErrorResponse.updateAgent'),
          'error',
          SNACK_BAR_DURATION,
          undefined,
          {
            SnackbarProps: {
              style: {
                top: '40px',
              },
            },
          }
        );
      }
    },
    [
      agentData,
      agentDetail?.rawData.name,
      agentDetail?.rawData.description,
      agentDetail?.rawData.reject_description,
      agentDetail?.rawData?.review_status,
      agentDetail?.rawData.created_at,
      agentDetail?.rawData?.created_user_id,
      agentDetail?.rawData?.id,
      agentDetail?.rawData?.category,
      agentDetail?.rawData?.org_id,
      agentDetail?.rawData.team_id,
      agentDetail?.rawData.usage_scope,
      agentDetail?.rawData.use_count,
      generalAgent?.data?.agent?.review_status,
      generalAgent?.data?.agent?.created_user_id,
      generalAgent?.data?.agent?.id,
      generalAgent?.data?.agent?.category,
      generalAgent?.data?.agent?.org_id,
      generalAgent?.data?.agent?.team_id,
      generalAgent?.data?.agent?.usage_scope,
      generalAgent?.data?.agent?.use_count,
      generalAgent?.data?.agent?.name,
      generalAgent?.data?.instruction,
      generalAgent?.agent?.review_status,
      generalAgent?.agent?.created_user_id,
      generalAgent?.agent?.id,
      generalAgent?.agent?.category,
      generalAgent?.agent?.org_id,
      generalAgent?.agent?.team_id,
      generalAgent?.agent?.usage_scope,
      generalAgent?.agent?.use_count,
      generalAgent?.agent?.name,
      generalAgent?.instruction,
      isPro,
      conversationStarter,
      mutateAgent,
      t,
      isAgentOperationSettings,
      postHistory,
      idForUpdating,
      cookies.userId,
      agentReasonChange,
      updateAlreadyCreated,
      setAlreadyCreatedGeneral,
      createNewChatMutation,
      setHasRunChatStarter,
      setChatData,
      setAgentDetailId,
    ]
  );

  const handleApplyAgent = useCallback(
    async (reviewStatus?: EChatAgentStatus) => {
      const isUpdating =
        !agentDetail?.rawData.id &&
        !generalAgent?.data?.agent?.id &&
        !generalAgent?.agent?.id &&
        !idForUpdating;

      setApplyingAgent(true);
      const generatedNodes = await handleGenerateWorkflow();
      const selectedToolList = [...selectedTools.map((item) => item.id)];

      updateUpsertLoading(true);
      if (isUpdating) {
        const res = await handleCreateAgent(
          reviewStatus ?? EChatAgentStatus.SAVED,
          selectedToolList,
          generatedNodes
        );

        setIdForUpdating(String(res?.data?.agent?.id ?? res?.agent?.id ?? ''));
      } else {
        await handleUpdateAgent(selectedToolList, generatedNodes, reviewStatus);
      }

      updateUpsertLoading(false);
      setApplyingAgent(false);
      setIsChanged(false);
      setIsGenerateTool(false);
    },
    [
      agentDetail?.rawData.id,
      generalAgent?.data?.agent?.id,
      generalAgent?.agent?.id,
      idForUpdating,
      creationLoading,
      creatingAgent,
      updatingAgent,
      isPro,
      alreadyCreatedPro,
      alreadyCreateBasic,
      isAgentOperationSettings,
      agentData.name,
      agentData.description,
      handleGenerateWorkflow,
      selectedTools,
      updateUpsertLoading,
      handleCreateAgent,
      setIdForUpdating,
      handleUpdateAgent,
      setIsChanged,
      setIsGenerateTool,
    ]
  );

  const handleConfirmUpdateDeployed = useCallback(() => {
    setModalSettings({
      type: EButtonType.DEFAULT,
      open: true,
      handleCancel: () => setModalSettings(null),
      handleConfirm: () => {
        handleApplyAgent(EChatAgentStatus.DEPLOYED);
        setModalSettings(null);
      },
      title: taxTranslation('changeDeployedAgent.title'),
      confirmText: taxTranslation('changeDeployedAgent.confirmText'),
      contentChildren: <AgentDeployMessageContent />,
    });
  }, [handleApplyAgent, taxTranslation]);

  const handleAdminSaveAgent = useCallback(() => {
    if (isAgentOperationSettings) {
      handleConfirmUpdateDeployed();
    } else {
      handleApplyAgent();
    }
    setIsEditAdmin(false);
    setIsChanged(false);
    setIsChanged(false);
    setIsGenerateTool(false);
  }, [
    setIsEditAdmin,
    handleApplyAgent,
    handleConfirmUpdateDeployed,
    setIsGenerateTool,
    isAgentOperationSettings,
  ]);

  const handleGenerateRecipesTools = useCallback(async () => {
    updateUpsertLoading(true);
    const variables = () => {};
    const instruction = await generateInstruction(variables(), {
      onError: () => {
        updateUpsertLoading(false);
      },
    });
    updateAgentData({
      instruction: instruction.message,
    });
    await generateTools(variables(), {
      onError: () => {
        updateUpsertLoading(false);
      },
    });
    updateUpsertLoading(false);
    setShowRecipe && setShowRecipe(true);
    setExpand({ recipe: true, information: false });
    setConversationStarter(['']);
    setIsGenerateTool(true);
  }, [
    generateInstruction,
    generateTools,
    setConversationStarter,
    setShowRecipe,
    updateAgentData,
    updateUpsertLoading,
    setIsGenerateTool,
  ]);

  const handleRemoveConversationStarter = useCallback(
    (targetIndex: number) => {
      if (creationLoading) return;
      if (conversationStarter.length < 2) {
        setConversationStarter(['']);
        return;
      }
      setConversationStarter((prev) =>
        prev.filter((_, index) => targetIndex !== index)
      );
    },
    [conversationStarter.length, creationLoading, setConversationStarter]
  );

  const handleConversationStarterChange = useCallback(
    (
      targetIndex: number,
      event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    ) => {
      setConversationStarter((prev) =>
        prev.map((item, index) => {
          if (index === targetIndex) {
            return event.target.value;
          }
          return item;
        })
      );

      setIsChanged(true);
    },
    [setConversationStarter, setIsChanged]
  );

  const handleAddConversationStarter = useCallback(() => {
    if (creationLoading) return;
    setConversationStarter((prev) =>
      prev.length < MAX_TOOL ? [...prev, ''] : prev
    );
  }, [creationLoading, setConversationStarter]);

  const handleFileIcon = (fileName: string) => {
    const fileType = fileName.split('.')[fileName.split('.').length - 1];
    switch (fileType) {
      case 'xls':
        return <IconXls />;
      case 'xlsx':
        return <IconXlsx />;
      case 'pdf':
        return <IconPdf />;
      case 'png':
        return <IconPng />;
      case 'jpg':
        return <IconJpg />;
      case 'doc':
        return <IconDoc />;
      case 'ppt':
        return <IconPpt />;
      case 'pptx':
        return <IconPptx />;
      default:
        return <AttachmentIcon />;
    }
  };

  return (
    <Box
      className={cn(
        styles.createAgent,
        mode === AgentType.PRO ? styles.proAgent : styles.generalAgent
      )}
    >
      {mode === AgentType.PRO && (
        <>
          <div
            className={cn(styles.inputWrap, creationLoading && styles.disabled)}
          >
            <div className={styles.inputLabel}>
              <span>{taxTranslation('agent.configuration.agentName')}</span>
              <span style={{ color: '#F03E3E', marginLeft: '1px' }}>*</span>
            </div>
            <TextField
              id='search'
              fullWidth
              placeholder={taxTranslation(
                'agent.configuration.agentNamePlaceHolder'
              )}
              value={agentData.name ?? ''}
              onChange={handleChangeName}
              className={styles.textField}
              inputProps={{
                maxLength: nameMaxLength,
              }}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: 'var(--gray-150)',
                  },
                },
              }}
              InputProps={{
                endAdornment: (
                  <div className={styles.textCounter}>{nameCounter}</div>
                ),
              }}
            />
          </div>

          <div
            className={cn(styles.inputWrap, creationLoading && styles.disabled)}
          >
            <div className={styles.inputLabel}>
              <span>
                {taxTranslation('agent.configuration.agentDescription')}
              </span>
              <span style={{ color: '#F03E3E', marginLeft: '1px' }}>*</span>
            </div>
            <div className={cn(styles.textAreaInput)}>
              <BaseTextField
                className={cn(
                  'app-input',
                  styles.input,
                  styles.textFieldTextarea
                )}
                disabled={false}
                sx={{
                  '> *.MuiInputBase-root': {
                    'textarea': {
                      minHeight: '144px',
                      padding: '10px 12px',
                    },
                  },
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: 'var(--gray-150)',
                    },
                  },
                }}
                multiline
                fullWidth
                value={agentData.description ?? ''}
                onChange={handleChangeDescription}
                inputProps={{
                  maxLength: descMaxLength,
                }}
                placeholder={taxTranslation(
                  'agent.configuration.agentDescriptionPlaceHolder'
                )}
                InputProps={{
                  endAdornment: (
                    <div className={styles.descriptionCounter}>
                      {descriptionCounter}
                    </div>
                  ),
                }}
              />
            </div>
          </div>

          <div
            className={cn(
              styles.uploadFileArea,
              creationLoading && styles.disabled
            )}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'flex-start',
                gap: '2px',
                alignItems: 'center',
              }}
            >
              <div className={styles.inputLabel}>
                {taxTranslation('agent.configuration.uploadBusinessProcedures')}
              </div>

              <BaseTooltip
                title={taxTranslation('agent.configuration.knowledgeTooltip')}
                placement='bottom-start'
                slotProps={{
                  popper: {
                    sx: {
                      [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
                        {
                          padding: '4px 8px',
                          fontSize: '13px',
                          fontWeight: '400',
                          lineHeight: '145%',
                          letterSpacing: '0.026px',
                          textAlign: 'start',
                          marginTop: '1px',
                        },
                    },
                  },
                }}
              >
                <div className={styles.tooltip}>
                  <InfoIcon />
                </div>
              </BaseTooltip>
            </div>

            <input
              hidden
              type='file'
              ref={fileInputRef}
              name='fileUpload'
              onChange={handleFileChange}
            />

            {!agentData.file ? (
              <Button
                className={styles.uploadButton}
                onClick={() => handleUploadFileClick(fileInputRef)}
              >
                <span className={styles.icon}>
                  <UploadIcon />
                </span>
                <span className={styles.uploadText}>{t('uploadFile')}</span>
              </Button>
            ) : (
              <Box className={cn(styles.uploadedFile, styles.w100)}>
                <Box
                  onClick={() => handleUploadFileClick(fileInputRef)}
                  className={styles.uploadedFileContent}
                >
                  <AttachmentIcon />
                  <div>
                    <div className={styles.fileTitle}>
                      {agentData.file?.name}
                    </div>
                    <div className={styles.fileInfo}>
                      {t('document')} · {fileSize(agentData.file)}
                    </div>
                  </div>
                </Box>
                <Box
                  onClick={() => handleRemoveFile()}
                  className={styles.deleteIcon}
                >
                  <IconClose />
                </Box>
              </Box>
            )}
          </div>
          <div className={styles.divider} />
          <div
            className={cn(
              styles.conversationStarterWrap,
              creationLoading && styles.disabled
            )}
          >
            <div className={styles.inputLabel}>
              <span>
                {taxTranslation('agent.configuration.conversationStarter')}
              </span>
            </div>
            <div className={styles.conversationInputs}>
              {conversationStarter.map((item, index) => (
                <TextField
                  key={index}
                  fullWidth
                  placeholder={taxTranslation(
                    'agent.configuration.conversationStarterPlaceholder'
                  )}
                  onKeyDown={handleOnKeyDown}
                  onChange={(e) => handleConversationStarterChange(index, e)}
                  className={cn(styles.textField)}
                  value={item ?? ''}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      paddingRight: '0 !important',
                      '& fieldset': {
                        borderColor: 'var(--gray-150)',
                      },
                      '&.Mui-focused fieldset': {
                        border: !isEditAdmin
                          ? '1px solid var(--gray-150)'
                          : '1px solid var(--primary-color-800)',
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: !isEditAdmin
                          ? 'var(--gray-150) !important'
                          : 'var(--primary-color-600) !important',
                      },
                    },
                  }}
                  InputProps={{
                    endAdornment: !isEditAdmin ? (
                      <></>
                    ) : (
                      <Box
                        className={cn(styles.textRemove)}
                        onClick={() => handleRemoveConversationStarter(index)}
                      >
                        <IconClose />
                      </Box>
                    ),
                  }}
                />
              ))}
            </div>
            {conversationStarter.length < MAX_TOOL && isEditAdmin && (
              <div
                className={styles.addNew}
                style={{ justifyContent: 'flex-start' }}
              >
                <Button onClick={handleAddConversationStarter}>
                  <span className={styles.icon}>
                    <IconPlus />
                  </span>
                  <span className={styles.uploadText}>
                    {taxTranslation('agent.configuration.addTool')}
                  </span>
                </Button>
              </div>
            )}
          </div>
          <div
            className={cn(
              styles.uploadFileArea,
              creationLoading && styles.disabled,
              styles.mb30
            )}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'flex-start',
                gap: '2px',
                alignItems: 'center',
              }}
            >
              <div className={styles.inputLabel}>
                {taxTranslation('agent.configuration.knowledge')}
              </div>
              <BaseTooltip
                title={taxTranslation('agent.configuration.descriptionTooltip')}
                placement='bottom-start'
                slotProps={{
                  popper: {
                    sx: {
                      [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
                        {
                          padding: '4px 8px',
                          fontSize: '13px',
                          fontWeight: '400',
                          lineHeight: '145%',
                          letterSpacing: '0.026px',
                          textAlign: 'start',
                          marginTop: '1px',
                        },
                    },
                  },
                }}
              >
                <div className={styles.tooltip}>
                  <InfoIcon />
                </div>
              </BaseTooltip>
            </div>
            <input
              hidden
              type='file'
              ref={knowledgeFileInputRef}
              name='fileUpload'
              onChange={(e) => handleFileChange(e, true)}
            />

            {!agentData.knowledgeFile ? (
              <Button
                className={cn(styles.uploadButton)}
                onClick={() => handleUploadFileClick(knowledgeFileInputRef)}
              >
                <span className={styles.icon}>
                  <UploadIcon />
                </span>
                <span className={styles.uploadText}>{t('uploadFile')}</span>
              </Button>
            ) : (
              <Box className={cn(styles.uploadedFile, styles.w100)}>
                <Box
                  onClick={() => handleUploadFileClick(knowledgeFileInputRef)}
                  className={styles.uploadedFileContent}
                >
                  <AttachmentIcon />
                  <div>
                    <div className={styles.fileTitle}>
                      {agentData.knowledgeFile?.name}
                    </div>
                    <div className={styles.fileInfo}>
                      {t('document')} · {fileSize(agentData.knowledgeFile)}
                    </div>
                  </div>
                </Box>
                <Box
                  onClick={() => handleRemoveFile(true)}
                  className={styles.deleteIcon}
                >
                  <IconClose />
                </Box>
              </Box>
            )}
          </div>
          <div className={styles.fixedProButton}>
            <button
              type='button'
              className={cn(
                isEnableSubmit
                  ? styles.enabledSubmit
                  : styles.disabledSubmitPro,
                styles.applyButton
              )}
              style={{
                width: '100%',
                cursor:
                  !!agentData.name && !!agentData.description
                    ? 'pointer'
                    : 'not-allowed',
              }}
              onClick={() =>
                !applyingAgent && handleApplyAgent(EChatAgentStatus.SAVED)
              }
            >
              <div className={styles.buttonContent}>
                {applyingAgent && (
                  <RefreshIcon className={styles.iconSpinBlue} />
                )}
                <span>
                  {taxTranslation('agent.configuration.applyConfiguration')}
                </span>
              </div>
            </button>
          </div>
        </>
      )}

      {mode === AgentType.GENERAL && (
        <>
          {/* Agent Information */}
          <AgentAccordion
            expand={expand.information ?? false}
            setExpand={(expanded) =>
              setExpand({ information: expanded, recipe: !expanded })
            }
            header={taxTranslation('agent.informationTitle')}
            content={
              <>
                <div
                  className={cn(
                    styles.inputWrap,
                    creationLoading && styles.disabled
                  )}
                >
                  <div className={styles.inputLabel}>
                    <span>
                      {taxTranslation('agent.configuration.agentName')}
                    </span>
                    <span style={{ color: '#F03E3E', marginLeft: '1px' }}>
                      *
                    </span>
                  </div>
                  <TextField
                    variant='outlined'
                    id='search'
                    fullWidth
                    placeholder={taxTranslation(
                      'agent.configuration.agentNamePlaceHolder'
                    )}
                    value={agentData.name ?? ''}
                    disabled={!isEditAdmin}
                    onKeyDown={handleOnKeyDown}
                    onChange={handleChangeName}
                    className={cn(styles.textField)}
                    inputProps={{
                      maxLength: nameMaxLength,
                      sx: {
                        '&::placeholder': {
                          color: 'var(--gray-500)  !important',
                          opacity: 1,
                        },
                      },
                      endadornment: (
                        <div className={styles.textCounter}>{nameCounter}</div>
                      ),
                    }}
                    sx={{
                      '& .MuiInputBase-root': {
                        border: 'none',
                      },
                      '& .MuiOutlinedInput-root': {
                        '&:hover': {
                          border: 'none',
                        },
                        '& fieldset': {
                          border: !isEditAdmin
                            ? 'none'
                            : '1px solid var(--gray-150)',
                        },
                        '&.Mui-focused fieldset': {
                          border: !isEditAdmin
                            ? '0px solid var(--primary-color-800)'
                            : '0.5px solid var(--primary-color-800)',
                        },
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: !isEditAdmin
                            ? 'var(--gray-150) !important'
                            : 'var(--primary-color-600) !important',
                        },
                        backgroundColor: !isEditAdmin ? 'var(--gray-100)' : '',
                      },
                    }}
                  />
                </div>
                <div
                  className={cn(
                    styles.inputWrap,
                    creationLoading && styles.disabled
                  )}
                >
                  <div className={styles.inputLabel}>
                    <span>
                      {taxTranslation('agent.configuration.agentDescription')}
                    </span>
                    <span style={{ color: '#F03E3E', marginLeft: '1px' }}>
                      *
                    </span>
                  </div>
                  <div className={cn(styles.textAreaInput)}>
                    <BaseTextField
                      className={cn(
                        'app-input',
                        styles.input,
                        styles.textFieldTextarea
                      )}
                      sx={{
                        '> *.MuiInputBase-root': {
                          'textarea': {
                            minHeight:
                              mode === AgentType.GENERAL ? '60px' : '144px',
                            padding: '10px 12px',
                          },
                        },
                      }}
                      multiline
                      fullWidth
                      disabled={!isEditAdmin}
                      value={agentData.description ?? ''}
                      onChange={handleChangeDescription}
                      inputProps={{
                        maxLength: descMaxLength,
                      }}
                      placeholder={taxTranslation(
                        'agent.configuration.agentDescriptionPlaceHolder'
                      )}
                      InputProps={{
                        endAdornment: (
                          <div className={styles.descriptionCounter}>
                            {descriptionCounter}
                          </div>
                        ),
                      }}
                    />
                  </div>
                </div>
                <div
                  className={cn(
                    styles.uploadFileArea,
                    creationLoading && styles.disabled
                  )}
                >
                  <div className={styles.uploadFileWrapper}>
                    <div>
                      <div className={styles.inputLabel}>
                        {taxTranslation(
                          'agent.configuration.uploadBusinessProcedures'
                        )}
                        <BaseTooltip
                          title={taxTranslation(
                            'agent.configuration.uploadBusinessProceduresDescription'
                          )}
                          placement='bottom-start'
                          slotProps={{
                            popper: {
                              sx: {
                                [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
                                  {
                                    padding: '4px 8px',
                                    fontSize: '13px',
                                    fontWeight: '400',
                                    lineHeight: '145%',
                                    letterSpacing: '0.026px',
                                    textAlign: 'start',
                                    marginTop: '1px',
                                  },
                              },
                            },
                          }}
                        >
                          <div className={styles.tooltip}>
                            <InfoIcon />
                          </div>
                        </BaseTooltip>
                      </div>
                    </div>

                    <input
                      hidden
                      type='file'
                      ref={fileInputRef}
                      name='fileUpload'
                      onChange={handleFileChange}
                    />

                    {!agentData.file ? (
                      <Button
                        className={cn(
                          styles.uploadButton,
                          !isEditAdmin && styles.disabled
                        )}
                        disabled={!isEditAdmin}
                        onClick={() => handleUploadFileClick(fileInputRef)}
                      >
                        <span className={styles.icon}>
                          <UploadIcon />
                        </span>
                        <span className={styles.uploadText}>
                          {t('uploadFile')}
                        </span>
                      </Button>
                    ) : (
                      <Box className={styles.uploadedFile}>
                        <Box className={styles.uploadedFileContent}>
                          <div className={styles.uploadedFileIcon}>
                            {handleFileIcon(agentData.file?.name)}
                          </div>
                          <div>
                            <div className={styles.fileTitle}>
                              {agentData.file?.name}
                            </div>
                            <div className={styles.fileInfo}>
                              {t('document')} · {fileSize(agentData.file)}
                            </div>
                          </div>
                        </Box>
                        <Box
                          onClick={() => handleRemoveFile()}
                          className={styles.deleteIcon}
                        >
                          <IconClose />
                        </Box>
                      </Box>
                    )}
                  </div>
                  <button
                    type='button'
                    className={cn(
                      enabledGenRecipe
                        ? styles.enabledSubmit
                        : styles.disabledSubmitPro,
                      styles.applyButton
                    )}
                    style={{
                      cursor:
                        !!agentData.name && !!agentData.description
                          ? 'pointer'
                          : 'not-allowed',
                    }}
                    onClick={() =>
                      enabledGenRecipe &&
                      !upsertLoading &&
                      !generatingInstruction &&
                      !recommendedToolsLoading &&
                      handleGenerateRecipesTools()
                    }
                  >
                    <div className={styles.buttonContent}>
                      {(generatingInstruction || recommendedToolsLoading) && (
                        <RefreshIcon className={styles.iconSpinBlue} />
                      )}
                      <span>
                        {taxTranslation(
                          'agent.configuration.createRecipesTools'
                        )}
                      </span>
                    </div>
                  </button>
                </div>
              </>
            }
          />
          {/* Instruction/Recipe and Tools */}
          {showRecipe && (
            <AgentAccordion
              expand={expand.recipe ?? false}
              setExpand={(expanded) =>
                setExpand({ recipe: expanded, information: !expanded })
              }
              header={taxTranslation('agent.recipeToolTitle')}
              content={
                <>
                  <div className={cn(styles.inputWrap, styles.inputCustomWrap)}>
                    <div className={styles.instructionHeader}>
                      <div>
                        <div className={styles.instructionLabel}>
                          <div>
                            <span>
                              {taxTranslation(
                                'agent.configuration.instruction'
                              )}
                            </span>
                            <span style={{ color: '#F03E3E' }}>*</span>
                          </div>
                          <BaseTooltip
                            title={taxTranslation(
                              'agent.configuration.instructionTooltip'
                            )}
                            placement='bottom-start'
                            slotProps={{
                              popper: {
                                sx: {
                                  [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
                                    {
                                      padding: '4px 8px',
                                      fontSize: '13px',
                                      fontWeight: '400',
                                      lineHeight: '145%',
                                      letterSpacing: '0.026px',
                                      textAlign: 'start',
                                      marginTop: '1px',
                                    },
                                },
                              },
                            }}
                          >
                            <div className={styles.tooltip}>
                              <InfoIcon />
                            </div>
                          </BaseTooltip>
                        </div>
                      </div>

                      <Box
                        className={
                          agentData.name && agentData.description && isEditAdmin
                            ? styles.aiOptimize
                            : styles.aiOptimizeDisabled
                        }
                        onClick={() =>
                          !generatingInstruction &&
                          handleInstructionDialogOpen()
                        }
                      >
                        <IconMagic />
                        {taxTranslation(
                          'agent.configuration.AIGuidelineGeneration'
                        )}
                      </Box>
                    </div>

                    <div className={styles.textAreaInput}>
                      <BaseTextField
                        className={cn(
                          'app-input',
                          styles.input,
                          styles.textFieldTextarea,
                          !isEditAdmin && styles.inputDisabled
                        )}
                        disabled={!isEditAdmin}
                        multiline
                        fullWidth
                        value={agentData.instruction ?? ''}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          handleChangeInstruction(e)
                        }
                        sx={{
                          '> *.MuiInputBase-root': {
                            'textarea': {
                              minHeight: '144px',
                              padding: '10px 12px',
                            },
                          },
                        }}
                        inputProps={{
                          maxLength: instructionMaxLength,
                        }}
                        placeholder={taxTranslation(
                          'agent.configuration.instructionPlaceHolder'
                        )}
                        InputProps={{
                          endAdornment: isEditAdmin ? (
                            <></>
                          ) : (
                            <div className={styles.instructionCounter}>
                              <div>{instructionCounter}</div>
                              <IconDelete
                                style={{ cursor: 'pointer' }}
                                onClick={() => handleChangeInstruction('')}
                              />

                              <IconExpand
                                onClick={() =>
                                  !generatingInstruction && expandInstruction()
                                }
                                style={{ cursor: 'pointer' }}
                              />
                            </div>
                          ),
                        }}
                      />
                    </div>
                  </div>
                  <div className={cn(styles.toolWrap)}>
                    <div className={styles.instructionHeader}>
                      <div>
                        <div className={styles.instructionLabel}>
                          <div>
                            <span>
                              {taxTranslation('agent.configuration.tool')}
                            </span>
                            <span style={{ color: '#F03E3E' }}>*</span>
                          </div>
                          <BaseTooltip
                            title={taxTranslation(
                              'agent.configuration.toolTooltip'
                            )}
                            placement='bottom-start'
                            slotProps={{
                              popper: {
                                sx: {
                                  [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
                                    {
                                      padding: '4px 8px',
                                      fontSize: '13px',
                                      fontWeight: '400',
                                      lineHeight: '145%',
                                      letterSpacing: '0.026px',
                                      textAlign: 'start',
                                      marginTop: '1px',
                                    },
                                },
                              },
                            }}
                          >
                            <div className={styles.tooltip}>
                              <InfoIcon />
                            </div>
                          </BaseTooltip>
                        </div>
                      </div>
                      <Box
                        className={
                          agentData.instruction &&
                          agentData.name &&
                          agentData.description &&
                          isEditAdmin
                            ? styles.aiOptimize
                            : styles.aiOptimizeDisabled
                        }
                        onClick={() => !recommendedToolsLoading && aiGenTool()}
                      >
                        <IconMagic />
                        {taxTranslation(
                          'agent.configuration.AIToolRecommendation'
                        )}
                      </Box>
                    </div>

                    <Box
                      onClick={() =>
                        !recommendedToolsLoading && handleToolDialogOpen()
                      }
                      className={cn(
                        styles.addTool,
                        !isEditAdmin && styles.disabled
                      )}
                    >
                      <IconPlusCircle />{' '}
                      {taxTranslation('agent.configuration.addTool')}
                    </Box>
                    {(!!selectedTools.length || recommendedToolsLoading) && (
                      <div className={styles.toolContainer}>
                        {recommendedToolsLoading ? (
                          <>
                            <Skeleton
                              variant='rectangular'
                              sx={{ width: '100%' }}
                            />
                            <Skeleton
                              variant='rectangular'
                              sx={{ width: '100%' }}
                            />
                            <Skeleton
                              variant='rectangular'
                              sx={{ width: '60%' }}
                            />
                          </>
                        ) : (
                          selectedTools.map((tool) => (
                            <AgentTool
                              key={tool.id}
                              name={tool.name}
                              description={tool.description}
                              readonly
                              onRemove={
                                !isEditAdmin
                                  ? undefined
                                  : () => removeTool(tool.id)
                              }
                            />
                          ))
                        )}
                      </div>
                    )}
                  </div>
                  <div className={styles.divider} />
                  <div
                    className={cn(
                      styles.conversationStarterWrap,
                      creationLoading && styles.disabled
                    )}
                  >
                    <div className={styles.inputLabel}>
                      <span>
                        {taxTranslation(
                          'agent.configuration.conversationStarter'
                        )}
                      </span>
                    </div>
                    <div className={styles.conversationInputs}>
                      {conversationStarter.map((item, index) => (
                        <TextField
                          key={index}
                          fullWidth
                          placeholder={taxTranslation(
                            'agent.configuration.conversationStarterPlaceholder'
                          )}
                          onKeyDown={handleOnKeyDown}
                          onChange={(e) =>
                            handleConversationStarterChange(index, e)
                          }
                          className={cn(
                            styles.textField,
                            !isEditAdmin && styles.inputDisabled
                          )}
                          value={item ?? ''}
                          sx={{
                            '& .MuiOutlinedInput-root': {
                              paddingRight: '0 !important',
                              '& fieldset': {
                                borderColor: 'var(--gray-150)',
                              },
                              '&.Mui-focused fieldset': {
                                border: !isEditAdmin
                                  ? '1px solid var(--gray-150)'
                                  : '1px solid var(--primary-color-800)',
                              },
                              '&:hover .MuiOutlinedInput-notchedOutline': {
                                borderColor: !isEditAdmin
                                  ? 'var(--gray-150) !important'
                                  : 'var(--primary-color-600) !important',
                              },
                            },
                          }}
                          InputProps={{
                            endAdornment: !isEditAdmin ? (
                              <Box
                                className={cn(
                                  styles.textRemove,
                                  styles.grayDisabled
                                )}
                              >
                                <IconClose />
                              </Box>
                            ) : (
                              <Box
                                className={cn(styles.textRemove)}
                                onClick={() =>
                                  handleRemoveConversationStarter(index)
                                }
                              >
                                <IconClose />
                              </Box>
                            ),
                          }}
                        />
                      ))}
                    </div>
                    {conversationStarter.length < MAX_TOOL && isEditAdmin && (
                      <div className={styles.addNew}>
                        <Button onClick={handleAddConversationStarter}>
                          <span className={styles.icon}>
                            <IconPlus />
                          </span>
                          <span className={styles.uploadText}>
                            {taxTranslation('agent.configuration.addTool')}
                          </span>
                        </Button>
                      </div>
                    )}
                  </div>
                  <div
                    className={cn(
                      styles.uploadFileArea,
                      creationLoading && styles.disabled
                    )}
                  >
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'flex-start',
                        gap: '2px',
                        alignItems: 'center',
                      }}
                    >
                      <div className={styles.inputLabel}>
                        {taxTranslation('agent.configuration.knowledge')}
                      </div>
                      <BaseTooltip
                        title={taxTranslation(
                          'agent.configuration.knowledgeTooltip'
                        )}
                        placement='bottom-start'
                        slotProps={{
                          popper: {
                            sx: {
                              [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
                                {
                                  padding: '4px 8px',
                                  fontSize: '13px',
                                  fontWeight: '400',
                                  lineHeight: '145%',
                                  letterSpacing: '0.026px',
                                  textAlign: 'start',
                                  marginTop: '1px',
                                },
                            },
                          },
                        }}
                      >
                        <div className={styles.tooltip}>
                          <InfoIcon />
                        </div>
                      </BaseTooltip>
                    </div>
                    <input
                      hidden
                      type='file'
                      ref={knowledgeFileInputRef}
                      name='fileUpload'
                      onChange={(e) => handleFileChange(e, true)}
                    />

                    {!agentData.knowledgeFile ? (
                      <Button
                        className={cn(
                          styles.uploadButton,
                          !isEditAdmin && styles.disabled
                        )}
                        disabled={!isEditAdmin}
                        onClick={() =>
                          handleUploadFileClick(knowledgeFileInputRef)
                        }
                      >
                        <span className={styles.icon}>
                          <UploadIcon />
                        </span>
                        <span className={styles.uploadText}>
                          {t('uploadFile')}
                        </span>
                      </Button>
                    ) : (
                      <Box className={styles.uploadedFile}>
                        <Box
                          onClick={() =>
                            handleUploadFileClick(knowledgeFileInputRef)
                          }
                          className={styles.uploadedFileContent}
                        >
                          <AttachmentIcon />
                          <div>
                            <div className={styles.fileTitle}>
                              {agentData.knowledgeFile?.name}
                            </div>
                            <div className={styles.fileInfo}>
                              {t('document')} ·{' '}
                              {fileSize(agentData.knowledgeFile)}
                            </div>
                          </div>
                        </Box>
                        <Box
                          onClick={() => handleRemoveFile(true)}
                          className={styles.deleteIcon}
                        >
                          <IconClose />
                        </Box>
                      </Box>
                    )}
                  </div>
                </>
              }
            />
          )}
          <div className={cn(styles.submitButton, styles.fixedSubmitButton)}>
            {location.pathname.includes('/settings') ? (
              <div className={styles.buttonGroup}>
                {!isEditAdmin ? (
                  <button
                    type='button'
                    className={styles.btnWhite}
                    onClick={() => setIsEditAdmin(true)}
                  >
                    <span>{taxTranslation('editChat')}</span>
                  </button>
                ) : (
                  <>
                    <button
                      type='button'
                      className={
                        isEnableSubmit
                          ? styles.enabledSubmit
                          : styles.disabledSubmit
                      }
                      onClick={() =>
                        !upsertLoading &&
                        !applyingAgent &&
                        handleAdminSaveAgent()
                      }
                    >
                      {applyingAgent && (
                        <RefreshIcon className={styles.iconSpin} />
                      )}
                      <span>{t('save')}</span>
                    </button>
                    <button
                      type='button'
                      className={styles.btnWhite}
                      onClick={cancelEditing}
                    >
                      <span>{taxTranslation('cancel')}</span>
                    </button>
                  </>
                )}
              </div>
            ) : (
              <button
                type='button'
                className={
                  isEnableSubmit ? styles.enabledSubmit : styles.disabledSubmit
                }
                onClick={() =>
                  !upsertLoading &&
                  !applyingAgent &&
                  handleApplyAgent(EChatAgentStatus.SAVED)
                }
              >
                {applyingAgent && <RefreshIcon className={styles.iconSpin} />}
                <span>
                  {taxTranslation('agent.configuration.applyConfiguration')}
                </span>
              </button>
            )}
          </div>
        </>
      )}
      {modalSettings && <AgentAdminConfirmDialog {...modalSettings} />}
    </Box>
  );
};

export default CreateAgentForm;
