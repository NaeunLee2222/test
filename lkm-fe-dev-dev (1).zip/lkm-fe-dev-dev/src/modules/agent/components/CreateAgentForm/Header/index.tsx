import MinimizeIcon from '@/assets/basic-icons/icon-minimize.svg?react';
import AgentConfiguratorHeader from '@/modules/agent/components/AgentConfiguration/Header';
import styles from '@/modules/agent/components/CreateAgentForm/Header/index.module.scss';
import { Box, IconButton } from '@mui/material';

interface IProp {
  handleClick?: () => void;
}

const CreateAgentHeader = ({ handleClick }: IProp) => {
  return (
    <div className={styles.header}>
      <Box onClick={handleClick}>
        <AgentConfiguratorHeader />
      </Box>

      <IconButton
        size='small'
        className={styles.shrinkButton}
        onClick={handleClick}
      >
        <MinimizeIcon fontSize='small' />
      </IconButton>
    </div>
  );
};

export default CreateAgentHeader;
