import { Box } from '@mui/material';
import { useTranslation } from 'react-i18next';
import IconRegenerate from '@/assets/basic-icons/icon-regenerate-blue-16.svg?react';
import {
  agentCreationDialogDataAtom,
  agentInstructionSuggestionAtom,
  agentToolListAtom,
} from '@/modules/agent/jotai/agent';
import { useAtom } from 'jotai';
import { useCallback, useMemo } from 'react';
import cn from 'classnames';
import { IToolModel } from '@/modules/agent/type/agent';
import {
  generateInstructionMutation,
  generateRecommendedToolsMutation,
} from '@/modules/chat/hooks/useAgents';
import styles from './index.module.scss';

interface IProps {
  showReGenerate?: boolean;
  reGenerate?: () => void;
  applyInstruction?: (instruction: string) => void;
  applyTools?: (tool: IToolModel[]) => void;
}

const AgentDialogFooter = ({
  showReGenerate,
  reGenerate,
  applyInstruction,
  applyTools,
}: IProps) => {
  const { t } = useTranslation('admin');
  const { t: taxTranslation } = useTranslation('tax');
  const [, setAgentDialog] = useAtom(agentCreationDialogDataAtom);

  const [{ isPending: suggestedInstructionLoading }] = useAtom(
    generateInstructionMutation
  );

  const [{ isPending: recommendedToolsLoading }] = useAtom(
    generateRecommendedToolsMutation
  );

  const [suggestedInstructionData] = useAtom(agentInstructionSuggestionAtom);

  const [agentToolList] = useAtom(agentToolListAtom);

  const disabledButtons = useMemo(
    () =>
      (showReGenerate && suggestedInstructionLoading) ||
      (!showReGenerate && recommendedToolsLoading),
    [recommendedToolsLoading, showReGenerate, suggestedInstructionLoading]
  );

  const disabledApply = useMemo(
    () =>
      (showReGenerate && !suggestedInstructionData) ||
      (!showReGenerate &&
        (recommendedToolsLoading ||
          agentToolList.length === 0 ||
          agentToolList.every((tool) => !tool.checked))),
    [
      showReGenerate,
      suggestedInstructionData,
      recommendedToolsLoading,
      agentToolList,
    ]
  );

  const onCancel = useCallback(() => {
    if (disabledButtons) return;
    setAgentDialog({ dialogOpen: false });
  }, [disabledButtons, setAgentDialog]);

  return (
    <Box className={styles.footerContainer}>
      {showReGenerate ? (
        <Box
          className={cn(styles.reGenerate, disabledButtons && styles.disabled)}
          onClick={reGenerate}
        >
          <IconRegenerate />
          <span>{taxTranslation('agent.configuration.regenerate')}</span>
        </Box>
      ) : (
        <Box />
      )}
      <Box className={styles.actionButton}>
        <button
          type='button'
          className={cn(styles.cancelBtn, disabledButtons && styles.disabled)}
          onClick={onCancel}
        >
          <span>{t('cancel')}</span>
        </button>
        {showReGenerate ? (
          <button
            type='button'
            className={cn(styles.applyBtn, disabledButtons && styles.disabled)}
            onClick={() => {
              !disabledApply &&
                applyInstruction &&
                suggestedInstructionData &&
                applyInstruction(suggestedInstructionData);
            }}
          >
            <span> {t('use')}</span>
          </button>
        ) : (
          <button
            type='button'
            className={cn(styles.applyBtn, disabledButtons && styles.disabled)}
            onClick={() => {
              !disabledApply &&
                applyTools &&
                applyTools(agentToolList.filter((item) => item.checked));
            }}
          >
            <span> {t('use')}</span>
          </button>
        )}
      </Box>
    </Box>
  );
};

export default AgentDialogFooter;
