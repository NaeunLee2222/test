import loadingIcon from '@/assets/lotties/loading-icon.json';
import SearchInput from '@/modules/admin/components/Search/Input';
import AgentTool from '@/modules/agent/components/CreateAgentForm/AgentTool';
import {
  agentToolListAtom,
  selectedAgentToolsAtom,
} from '@/modules/agent/jotai/agent';
import { IToolModel } from '@/modules/agent/type/agent';
import { useGetAllTools } from '@/modules/chat/hooks/useAgents';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import { Box } from '@mui/material';
import { useAtom, useAtomValue } from 'jotai';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

const ToolContentChildren = () => {
  const { t } = useTranslation('tax');

  const [tools, updateTools] = useAtom(agentToolListAtom);
  const [{ data: toolList, isRefetching: toolLoading }] =
    useAtom(useGetAllTools);
  const selectedAgentTool = useAtomValue(selectedAgentToolsAtom);
  const [search, setSearch] = useState('');

  const handleKeyUp = (e: React.KeyboardEvent<HTMLDivElement>) => {
    setSearch((e.target as HTMLInputElement).value);
  };

  useEffect(() => {
    const selectedToolIds = selectedAgentTool;
    if (toolList?.data?.tools || toolList?.tools || [])
      updateTools(
        [...(toolList?.data?.tools || toolList?.tools || [])].map(
          (item) =>
            ({
              id: item.id,
              name: item.name,
              checked: selectedToolIds.some(
                (tool) => tool.id === item.id || tool.name === item.name
              ),
              description: item.description,
              type: item.type,
            }) as IToolModel
        )
      );
  }, [toolList, selectedAgentTool]);

  const toggleToolSelection = useCallback(
    (toolId: number) => {
      const updated = tools.map((tool) => {
        if (tool.id === toolId) {
          return { ...tool, checked: !(tool.checked || false) };
        }
        return tool;
      });

      updateTools(updated);
    },
    [tools, updateTools]
  );

  const availableTools = useMemo(
    () =>
      tools.filter(
        (tool) =>
          !search ||
          tool.name.toLowerCase().includes(search.trim().toLowerCase())
      ),
    [search, tools]
  );

  return (
    <Box className={styles.toolContainer}>
      <div className={styles.container}>
        {toolLoading ? (
          <Box className={styles.loading}>
            <LottiePlayer
              options={{
                renderer: 'svg',
                loop: true,
                autoplay: true,
                animationData: loadingIcon,
              }}
              width={100}
              height={100}
            />
          </Box>
        ) : (
          <>
            <div className={styles.toolSearch}>
              <SearchInput
                onKeyUp={handleKeyUp}
                setSearch={setSearch}
                placeholder={t('agent.configuration.searchByToolName')}
                search={search}
              />
            </div>
            <div className={styles.holder}>
              {(availableTools || []).map((tool) => (
                <AgentTool
                  key={tool.id}
                  name={tool.name}
                  description={tool.description}
                  checked={tool.checked || false}
                  onCheck={() => (tool.id ? toggleToolSelection(tool.id) : {})}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </Box>
  );
};

export default ToolContentChildren;
