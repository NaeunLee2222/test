import IconDelete from '@/assets/basic-icons/icon-trash-gray.svg?react';
import loadingIcon from '@/assets/lotties/loading-icon.json';
import { agentInstructionSuggestionAtom } from '@/modules/agent/jotai/agent';
import { generateInstructionMutation } from '@/modules/chat/hooks/useAgents';
import LottiePlayer from '@/modules/core/components/common/LottiePlayer/LottiePlayer';
import {
  codeBlockPlugin,
  frontmatterPlugin,
  headingsPlugin,
  imagePlugin,
  jsxPlugin,
  linkDialogPlugin,
  linkPlugin,
  listsPlugin,
  markdownShortcutPlugin,
  MDXEditor,
  MDXEditorMethods,
  quotePlugin,
  tablePlugin,
  thematicBreakPlugin,
} from '@mdxeditor/editor';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import React, { useCallback, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './index.module.scss';

const InstructionContentChildren = () => {
  const { t } = useTranslation('tax');

  const instructionLimit = 3000;
  const [suggestedInstructionData, updateSuggestedInstruction] = useAtom(
    agentInstructionSuggestionAtom
  );
  const mdxEditorRef = React.useRef<MDXEditorMethods>(null);

  const [{ data: suggestedInstruction, isPending: instructionLoading }] =
    useAtom(generateInstructionMutation);

  const clearInstruction = useCallback(() => {
    mdxEditorRef!.current?.setMarkdown('');
    updateSuggestedInstruction('');
  }, [updateSuggestedInstruction]);

  useEffect(() => {
    if (suggestedInstruction?.data?.message ?? suggestedInstruction?.message) {
      const message =
        suggestedInstruction?.data?.message ?? suggestedInstruction?.message;
      updateSuggestedInstruction(message);
      mdxEditorRef!.current?.setMarkdown(message);
    }
  }, [suggestedInstruction]);

  const instructionCounter = useMemo(
    () => `${suggestedInstructionData.length}/${instructionLimit}`,
    [suggestedInstructionData, instructionLimit]
  );

  return (
    <Box className={styles.instructionContainer}>
      <div className={styles.textContainer}>
        {instructionLoading ? (
          <Box className={styles.loading}>
            <LottiePlayer
              options={{
                renderer: 'svg',
                loop: true,
                autoplay: true,
                animationData: loadingIcon,
              }}
              width={100}
              height={100}
            />
          </Box>
        ) : (
          <>
            <div className={styles.textHolder}>
              <div
                className={
                  suggestedInstructionData
                    ? styles.textViewer
                    : styles.placeholder
                }
              >
                <MDXEditor
                  ref={mdxEditorRef}
                  className={styles.mdxEditor}
                  placeholder={t('agent.configuration.instructionPlaceHolder')}
                  markdown={suggestedInstructionData}
                  contentEditableClassName={styles.contentEditable}
                  readOnly
                  plugins={[
                    headingsPlugin(),
                    listsPlugin(),
                    quotePlugin(),
                    thematicBreakPlugin(),
                    markdownShortcutPlugin(),
                    linkPlugin(),
                    linkDialogPlugin(),
                    imagePlugin(),
                    jsxPlugin(),
                    tablePlugin(),
                    frontmatterPlugin(),
                    codeBlockPlugin(),
                  ]}
                />
              </div>
            </div>
            <div
              className={cn(
                styles.textCounter,
                !suggestedInstruction && styles.disabled
              )}
            >
              <div>{instructionCounter}</div>
              <IconDelete
                style={{ cursor: 'pointer' }}
                onClick={clearInstruction}
              />
            </div>
          </>
        )}
      </div>
    </Box>
  );
};

export default InstructionContentChildren;
