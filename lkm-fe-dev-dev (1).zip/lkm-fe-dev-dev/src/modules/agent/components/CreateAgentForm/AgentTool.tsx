import IconCheckbox from '@/assets/basic-icons/icon-checkbox-24.svg?react';
import IconCheckboxChecked from '@/assets/basic-icons/icon-checkbox-checked-24.svg?react';
import CloseIcon from '@/assets/basic-icons/icon-close-01.svg?react';
import IconToolActive from '@/assets/basic-icons/icon-tool-active.svg?react';
import IconTool from '@/assets/basic-icons/icon-tool.svg?react';
import cn from 'classnames';
import styles from './AgentTool.module.scss';

interface IProps {
  name: string;
  checked?: boolean;
  description?: string;
  readonly?: boolean;
  onCheck?: () => void;
  onRemove?: () => void;
}

const AgentTool = ({
  name,
  checked,
  description,
  readonly,
  onCheck,
  onRemove,
}: IProps) => {
  return readonly ? (
    <div className={cn(styles.readonlyToolContainer)}>
      <IconTool />
      <div className={styles.content}>
        <div className={styles.name}>{name}</div>
      </div>
      {onRemove && (
        <div className={styles.deleteIcon}>
          <CloseIcon
            style={{ cursor: 'pointer', Height: '16px', width: '16px' }}
            onClick={onRemove}
          />
        </div>
      )}
    </div>
  ) : (
    <div className={cn(styles.toolContainer, checked && styles.selected)}>
      {checked ? (
        <IconCheckboxChecked style={{ cursor: 'pointer' }} onClick={onCheck} />
      ) : (
        <IconCheckbox style={{ cursor: 'pointer' }} onClick={onCheck} />
      )}
      <div className={styles.icon}>
        {checked ? <IconToolActive /> : <IconTool />}
      </div>
      <div className={styles.content}>
        <div className={styles.name}>{name}</div>
        <div className={styles.description}>{description}</div>
      </div>
    </div>
  );
};

export default AgentTool;
