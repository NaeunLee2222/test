import styles from '@/modules/agent/components/CardList/AgentDetailDialog.module.scss';
import {
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from '@mui/material';
import { useTranslation } from 'react-i18next';

export interface AgentDetailDialogProps {
  rejectDescription: string | undefined;
  open: boolean;
  onClose: () => void;
}

const AgentDetailDialog = ({
  rejectDescription,
  open,
  onClose,
}: AgentDetailDialogProps) => {
  const { t } = useTranslation('tax');

  return (
    <Dialog
      open={open}
      onClose={onClose}
      disableEnforceFocus
      PaperProps={{
        sx: {
          width: '400px',
          height: '300px',
          borderRadius: '12px',
          boxShadow: '0px 0px 15px 0px rgba(0, 0, 0, 0.15)',
        },
      }}
    >
      <DialogTitle className={styles.dialogTitle}>
        {t('agent.rejectTitle')}
      </DialogTitle>

      <DialogContent
        className={styles.dialogContent}
        sx={{ padding: '8px 24px !important' }}
      >
        <Box className={styles.boxContent}>{rejectDescription}</Box>
      </DialogContent>

      <DialogActions className={styles.dialogActions}>
        <Box className={styles.actionButton}>
          <button type='button' className={styles.cancelBtn} onClick={onClose}>
            <span>{t('confirm')}</span>
          </button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default AgentDetailDialog;
