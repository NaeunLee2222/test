import AgentIconBasic from '@/assets/basic-icons/icon-agent-basic.svg?react';
import AgentIconMyAgent from '@/assets/basic-icons/icon-agent-my-agent.svg?react';
import AgentIconPro from '@/assets/basic-icons/icon-agent-pro.svg?react';
import IconEdit from '@/assets/basic-icons/icon-edit-gray.svg?react';
import IconEllipsis from '@/assets/basic-icons/icon-ellipsis.svg?react';
import IconTrash from '@/assets/basic-icons/icon-trash-red.svg?react';
import IconInformationWarning from '@/assets/basic-icons/information-warning.svg?react';
import IconInformation from '@/assets/basic-icons/information.svg?react';
import { deleteAgent } from '@/modules/agent/api/agent';
import AgentDetailDialog from '@/modules/agent/components/CardList/AgentDetailDialog';
import styles from '@/modules/agent/components/CardList/CardItem.module.scss';
import { agentDataAtom, agentMode } from '@/modules/agent/jotai/agent';
import { AgentType, UsageScope } from '@/modules/agent/type/agent';
import { AgentDetailModal } from '@/modules/chat/components/ChatInitial/AgentDetailModal';
import { useDisabledAgentsData } from '@/modules/chat/hooks/useAgents';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import { selectedToolAtom } from '@/modules/chat/jotai/chat';
import { EChatAgentStatus, IChatAgent } from '@/modules/chat/types/agents';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { RoutesURL } from '@/routers/routes';
import { showError } from '@/utils/errorUtil';
import { showSnackbar } from '@/utils/snackbarUtil';
import { Box, Popover, tooltipClasses, Typography } from '@mui/material';
import cn from 'classnames';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { useCallback, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

interface CardItemProps {
  item: IChatAgent;
  curTab: string;
}

export const CardItem: React.FC<CardItemProps> = ({ item, curTab }) => {
  const { t } = useTranslation('tax');
  const navigate = useNavigate();

  const [anchorEl, setAnchorEl] = useState<HTMLDivElement | null>(null);
  const { refetch } = useAtomValue(useDisabledAgentsData);
  const [isOpenConfirmDialog, setIsOpenConfirmDialog] =
    useState<boolean>(false);
  const [isOpenAgentDetail, setIsOpenAgentDetail] = useState<boolean>(false);
  const [rejectDescription, setRejectDescription] = useState<
    string | undefined
  >();
  const setAgentDetailId = useSetAtom(agentDetailIdAtom);
  const [, updateAgentData] = useAtom(agentDataAtom);
  const [, setSelectedTool] = useAtom(selectedToolAtom);
  const setAgentMode = useSetAtom(agentMode);
  const [dialogOpen, setOpenDialog] = useState(false);
  const handleCloseModal = () => {
    setOpenDialog(false);
  };

  const Icon = useMemo(() => {
    if (curTab === AgentType.PRO) {
      return <AgentIconPro width='16' height='16' />;
    }

    if (curTab === AgentType.GENERAL) {
      return <AgentIconBasic width='16' height='16' />;
    }

    if (curTab === AgentType.MY_AGENT) {
      if (
        item.usageScope === UsageScope.PERSONAL ||
        (item.reviewStatus &&
          [
            EChatAgentStatus.DEPLOYED,
            EChatAgentStatus.REJECTED,
            EChatAgentStatus.SUBMITTED,
          ].includes(item.reviewStatus))
      ) {
        return (
          <div className={styles.iconMyAgent}>
            <AgentIconMyAgent width='16' height='16' />
          </div>
        );
      }

      if (
        item.reviewStatus === EChatAgentStatus.PENDING ||
        item.reviewStatus === EChatAgentStatus.SAVED ||
        item.reviewStatus === EChatAgentStatus.TESTING
      ) {
        return null;
      }
    }
  }, [curTab, item.reviewStatus, item.usageScope]);

  const CardLabel = useMemo(() => {
    if (!item.reviewStatus) return null;

    // 1st Tab: LKM Agents
    if (curTab === AgentType.PRO) {
      return t('agent.cardItem.proAgent');
    }

    // 2nd Tab: Standard Agents
    if (curTab === AgentType.GENERAL) {
      return t('agent.cardItem.basicAgent');
    }

    // 3rd Tab: 나의 에이전트 (My Agents)
    if (curTab === AgentType.MY_AGENT) {
      if (
        item.usageScope === UsageScope.PERSONAL ||
        (item.reviewStatus &&
          [
            EChatAgentStatus.DEPLOYED,
            EChatAgentStatus.REJECTED,
            EChatAgentStatus.SUBMITTED,
          ].includes(item.reviewStatus))
      ) {
        return t('agent.cardItem.myCreateAgent');
      }

      if (
        [
          EChatAgentStatus.PENDING,
          EChatAgentStatus.SAVED,
          EChatAgentStatus.TESTING,
        ].includes(item.reviewStatus)
      ) {
        if (item.agentType === AgentType.PRO) {
          return t('agent.cardItem.deployAndPro');
        }

        if (item.agentType === AgentType.GENERAL) {
          return t('agent.cardItem.deployAndGeneral');
        }
      }
    }
  }, [item.reviewStatus, item.agentType, item.usageScope, curTab, t]);

  const getCardStyle = (agent: IChatAgent): string => {
    if (curTab === AgentType.PRO) {
      return styles.backgroundBlue;
    }

    if (curTab === AgentType.GENERAL) {
      return styles.backgroundGray;
    }

    if (curTab === AgentType.MY_AGENT) {
      if (
        item.usageScope === UsageScope.PERSONAL ||
        (item.reviewStatus &&
          [
            EChatAgentStatus.DEPLOYED,
            EChatAgentStatus.REJECTED,
            EChatAgentStatus.SUBMITTED,
          ].includes(item.reviewStatus))
      ) {
        return styles.backgroundBlue;
      }

      if (
        agent.reviewStatus &&
        [
          EChatAgentStatus.PENDING,
          EChatAgentStatus.SAVED,
          EChatAgentStatus.TESTING,
        ].includes(agent.reviewStatus)
      ) {
        return styles.borderButton;
      }
    }

    return styles.borderButton;
  };

  const redirectToDetail = (
    agentId: number | string,
    agentType: string | undefined
  ) => {
    switch (agentType?.trim()?.toLowerCase()) {
      case AgentType.GENERAL:
        navigate(`${RoutesURL.GENERAL_AGENT}/${agentId}`);
        setSelectedTool({
          isSelectedCanvas: false,
          selectedMode: null,
        });
        break;
      case AgentType.PRO:
        if (item.reviewStatus === EChatAgentStatus.TESTING) {
          navigate(`${RoutesURL.WORKFLOW_REVIEW}/${agentId}`);
        } else {
          navigate(`${RoutesURL.WORKFLOW_REVIEW}/${agentId}?action=edit`);
        }
        break;
      default:
        break;
    }
  };

  const redirectToChat = (
    agentId: string,
    agentName: string,
    usageScope: UsageScope
  ) => {
    setOpenDialog(true);
    setAgentDetailId(agentId.toString());
    updateAgentData({ name: agentName, usageScope });
  };

  const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    event.stopPropagation();
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleDelete = useCallback(() => {
    deleteAgent(item.id)
      .then((res) => {
        if (res.success) {
          refetch();
          setIsOpenConfirmDialog(false);
          showSnackbar(t('success.deleteAgent'), 'success', 3);
        }
      })
      .catch((error) => {
        setIsOpenConfirmDialog(false);
        showError(error.response.data.code);
        throw error;
      });
  }, [item.id, refetch, t]);

  const handleOpenDeleteDialog = () => {
    handleClose();
    setIsOpenConfirmDialog(true);
  };

  const handleOpenAgentDetail = (rejectDesc: string | undefined) => {
    setIsOpenAgentDetail(true);
    setRejectDescription(rejectDesc);
  };

  const handleEditAgent = (agentItem: IChatAgent) => {
    switch (agentItem.agentType?.trim()?.toLowerCase()) {
      case AgentType.GENERAL:
        navigate(`${RoutesURL.GENERAL_AGENT}/${agentItem.id}`);
        break;
      case AgentType.PRO:
        setAgentMode(AgentType.PRO);
        navigate(`${RoutesURL.WORKFLOW_REVIEW}/${agentItem.id}?action=edit`);
        break;
      default:
        break;
    }
  };

  const renderButton = useCallback(
    () => (
      <span className={styles.dialogActionContainer}>
        <BaseButton
          buttonType='outlined'
          className={styles.btnStyles}
          onClick={() => {
            setIsOpenConfirmDialog(false);
          }}
        >
          <span>{t('cancel')}</span>
        </BaseButton>
        <BaseButton
          autoFocus
          className={styles.btnDeleteStyles}
          onClick={handleDelete}
          color='error'
        >
          <span>{t('delete')}</span>
        </BaseButton>
      </span>
    ),
    [handleDelete, t]
  );

  const isShowIconDeployed = useMemo(
    () =>
      (item.reviewStatus &&
        [
          EChatAgentStatus.PRIVATE,
          EChatAgentStatus.DEPLOYED,
          EChatAgentStatus.SUBMITTED,
          EChatAgentStatus.REJECTED,
        ].includes(item.reviewStatus)) ||
      item.usageScope === UsageScope.PERSONAL,
    [item]
  );

  return (
    <Box className={styles.item}>
      <div className={styles.cardContainer}>
        <div className={styles.cardHeader}>
          <div className={styles.cardLabel}>
            <div className={getCardStyle(item)}>
              {isShowIconDeployed && Icon}
              <Typography className={styles.label}>{CardLabel}</Typography>
            </div>

            {curTab === AgentType.MY_AGENT &&
              item.reviewStatus &&
              [EChatAgentStatus.REJECTED, EChatAgentStatus.SUBMITTED].includes(
                item.reviewStatus
              ) && (
                <Box className={styles.information}>
                  {item.reviewStatus === EChatAgentStatus.REJECTED ? (
                    <IconInformationWarning
                      onClick={() =>
                        handleOpenAgentDetail(item.rejectDescription)
                      }
                    />
                  ) : (
                    <BaseTooltip
                      title={t('agent.cardItem.Submitted')}
                      placement='bottom-start'
                      slotProps={{
                        popper: {
                          sx: {
                            [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
                              {
                                marginTop: '3px',
                                marginLeft: '-4px',
                                width: '140px',
                                height: '42px',
                                padding: '4px 4px 4px 8px',
                                fontSize: '12px',
                                fontWeight: '400',
                                lineHeight: '145%',
                                textAlign: 'start',
                              },
                          },
                        },
                      }}
                    >
                      <div className={styles.iconInformation}>
                        <IconInformation />
                      </div>
                    </BaseTooltip>
                  )}
                  {item.reviewStatus === EChatAgentStatus.REJECTED && (
                    <p
                      className={styles.warning}
                      onClick={() =>
                        handleOpenAgentDetail(item.rejectDescription)
                      }
                    >
                      {t('agent.cardItem.Companion')}
                    </p>
                  )}
                </Box>
              )}
          </div>
          {curTab === AgentType.MY_AGENT && (
            <Box className={styles.icon} onClick={handleClick}>
              <IconEllipsis />
            </Box>
          )}
        </div>
        <Typography className={styles.title}>{item.name}</Typography>
        <Typography className={styles.detail}>{item.description}</Typography>
      </div>

      {(curTab === AgentType.PRO ||
        curTab === AgentType.GENERAL ||
        (curTab === AgentType.MY_AGENT &&
          (item.usageScope === UsageScope.PERSONAL ||
            (item.reviewStatus &&
              [
                EChatAgentStatus.DEPLOYED,
                EChatAgentStatus.REJECTED,
                EChatAgentStatus.SUBMITTED,
              ].includes(item.reviewStatus))))) && (
        <>
          <Typography className={styles.statusText}>
            <span className={styles.statusNumber}>{item.useCount}</span>
            {t('agent.cardItem.used')}
          </Typography>
          <BaseButton
            className={styles.btn}
            onClick={() =>
              redirectToChat(
                item.id,
                item.name ?? '',
                item.usageScope as UsageScope
              )
            }
          >
            {t('agent.cardItem.btn')}
          </BaseButton>
        </>
      )}

      {curTab === AgentType.MY_AGENT &&
        item.reviewStatus &&
        [
          EChatAgentStatus.PENDING,
          EChatAgentStatus.SAVED,
          EChatAgentStatus.TESTING,
        ].includes(item.reviewStatus) &&
        item.agentType &&
        [AgentType.PRO, AgentType.GENERAL].includes(
          item.agentType as AgentType
        ) &&
        item.usageScope !== UsageScope.PERSONAL && (
          <>
            <Typography className={styles.statusTextProcessing}>
              <span className={styles.dot} />
              {t('agent.cardItem.statusProcessing')}
            </Typography>
            <BaseButton
              className={cn(styles.btn, styles.btnProcessing)}
              onClick={() => redirectToDetail(item.id, item.agentType)}
            >
              {t('agent.cardItem.btnProcessing')}
            </BaseButton>
          </>
        )}

      {dialogOpen && (
        <AgentDetailModal onOpen={dialogOpen} onClose={handleCloseModal} />
      )}

      <Popover
        id={anchorEl ? 'simple-popover' : undefined}
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        PaperProps={{
          sx: {
            ml: '14px',
            gap: '4px',
          },
          className: styles.actionPopover,
        }}
        classes={{ paper: styles.actionPopover }}
      >
        <Box
          className={`${styles.action} ${styles.editAction}`}
          onClick={() => handleEditAgent(item)}
        >
          <IconEdit />
          <Typography className={`${styles.title} ${styles.edit}`}>
            {t('agent.cardItem.editAgent')}
          </Typography>
        </Box>
        <Box className={styles.action} onClick={handleOpenDeleteDialog}>
          <IconTrash />
          <Typography className={`${styles.title} ${styles.delete}`}>
            {t('agent.cardItem.deleteAgent')}
          </Typography>
        </Box>
      </Popover>

      <BaseDialog
        open={isOpenConfirmDialog}
        paddingX={24}
        actionClassName={styles.modalAction}
        contentClassName={styles.modalContent}
        hideCloseButton
        sx={{
          '& .MuiPaper-root': {
            maxWidth: 360,
            width: '312px',
          },
          '& .MuiDialog-paper.MuiPaper-root': {
            boxShadow: '0px 0px 15px 0px var(--black-15) !important',
          },
        }}
        dialogTitleClassName={styles.dialogTitle}
        title={
          <Box className={styles.agentDialogTitle}>
            {t('agent.cardItem.deleteAgent')}
          </Box>
        }
        handleClose={() => {
          setIsOpenConfirmDialog(false);
        }}
        contentChildren={
          <p
            className={styles.agentDescriptionLabel}
            dangerouslySetInnerHTML={{
              __html: t('agent.cardItem.confirmMessage'),
            }}
          />
        }
        actionsChildren={renderButton()}
      />

      <AgentDetailDialog
        rejectDescription={rejectDescription}
        open={isOpenAgentDetail}
        onClose={() => setIsOpenAgentDetail(false)}
      />
    </Box>
  );
};
