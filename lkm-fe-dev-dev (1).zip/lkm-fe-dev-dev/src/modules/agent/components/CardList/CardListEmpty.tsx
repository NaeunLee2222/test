import emptyFolder from '@/assets/images/empty-folder.png';
import cn from 'classnames';
import { useTranslation } from 'react-i18next';
import styles from './CardList.module.scss';

export const CardListEmpty = ({ text }: { text?: string }) => {
  const { t } = useTranslation('tax');

  return (
    <div className={cn(styles.noData, styles.container)}>
      <div className={cn(styles.noDataIconWrap)}>
        <img
          src={emptyFolder}
          alt='no report data'
          width={80}
          height={80}
          draggable='false'
        />
        <span className={styles.text}>{text ?? t('agent.empty')}</span>
      </div>
    </div>
  );
};
