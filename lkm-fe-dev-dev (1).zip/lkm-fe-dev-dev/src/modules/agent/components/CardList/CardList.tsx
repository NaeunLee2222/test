import { CardItem } from '@/modules/agent/components/CardList/CardItem';
import styles from '@/modules/agent/components/CardList/CardList.module.scss';
import { IChatAgent } from '@/modules/chat/types/agents';
import cn from 'classnames';

type PropsType = {
  listItems: IChatAgent[];
  curTab: string;
};
export const CardList = (prop: PropsType) => (
  <div className={cn(styles.filterContainer, styles.container)}>
    {prop.listItems.map((item) => (
      <CardItem curTab={prop.curTab} key={item.id + item.name} item={item} />
    ))}
  </div>
);
