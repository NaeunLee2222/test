import { CardList } from '@/modules/agent/components/CardList/CardList';
import styles from '@/modules/agent/components/CardList/CardList.module.scss';
import { CardListEmpty } from '@/modules/agent/components/CardList/CardListEmpty';
import { IChatAgent } from '@/modules/chat/types/agents';
import { useEffect, useState } from 'react';

type PropsType = {
  listItems: IChatAgent[];
  curTab: string;
};

export const CardMain = (prop: PropsType) => {
  const [data, setData] = useState<IChatAgent[]>([]);

  useEffect(() => {
    if (prop.listItems.length) {
      setData([...data, ...prop.listItems]);
    }
  }, [JSON.stringify(prop.listItems)]);

  return (
    <div className={styles.agentMain}>
      {data && data.length > 0 ? (
        <CardList listItems={data} curTab={prop.curTab} />
      ) : (
        <CardListEmpty />
      )}
    </div>
  );
};
