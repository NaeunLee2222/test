import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useMemo,
  useState,
} from 'react';

type DnDContextType = [string | null, Dispatch<SetStateAction<string | null>>];

const defaultSetType: Dispatch<SetStateAction<string | null>> = () => {
  throw new Error('setType was called outside of DnDProvider');
};

const DnDContext = createContext<DnDContextType>([null, defaultSetType]);

export const DnDProvider = ({ children }: { children: ReactNode }) => {
  const [type, setType] = useState<string | null>(null);

  const value = useMemo(
    () => [type, setType] as DnDContextType,
    [type, setType]
  );

  return <DnDContext.Provider value={value}>{children}</DnDContext.Provider>;
};

export default DnDContext;
