import { orderRegex } from '../constant/agent';

// Helper to find a DOM element with class from a point
export const findElementAtPoint = (
  x: number,
  y: number,
  className: string
): HTMLElement | null =>
  document
    .elementsFromPoint(x, y)
    .find((el) => el.classList.contains(className)) as HTMLElement | null;

// Helper to extract order from element class
export const getOrderFromClass = (el: HTMLElement): number | null => {
  const classList = Array.from(el.classList);
  const orderClass = classList.find((cls) => orderRegex.test(cls));
  if (!orderClass) return null;
  return parseInt(orderClass.split('-')[1], 10);
};

// Helper to swap items within a list
export const swapAndReorderList = (
  list: any[],
  fromIndex: number,
  toIndex: number
) => {
  const newList = [...list];
  const temp = newList[toIndex];
  newList[toIndex] = newList[fromIndex];
  newList[fromIndex] = temp;

  return newList.map((item, index) => ({
    ...item,
    order: index,
  }));
};

// Helper to send data through drag and drop
export const sendDataThroughDnD = (
  event: React.DragEvent,
  jsonData: string
) => {
  event.dataTransfer.setData('application/reactflow', jsonData);
  event.dataTransfer.effectAllowed = 'move';
};
