import { WorkflowReviewMain } from '@/modules/agent/components/WorkflowReview/WorkflowReviewMain';
import AgentLayout from '@/modules/agent/layout/WorkFlowLayout';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ModeType } from '../type/agent';

const WorkflowReview = () => {
  const [searchParams] = useSearchParams();
  const initMode = searchParams.get('action');
  const modeParam = searchParams.get('mode');

  const [mode, setMode] = useState<ModeType | string>(ModeType.CHAT);

  useEffect(() => {
    if (initMode) {
      setMode(ModeType.DASHBOARD);
    } else if (modeParam === 'chat') {
      setMode(ModeType.CHAT);
    }
  }, [initMode, modeParam]);

  return (
    <AgentLayout mode={mode} setMode={setMode}>
      <WorkflowReviewMain mode={mode} />
    </AgentLayout>
  );
};

export { WorkflowReview };
