import CreateBasicAgent from '@/modules/agent/components/CreateBasicAgent';
import {
  agentCanvasOpenAtom,
  agentDataAtom,
  agentIdForUpdating,
  agentToolListAtom,
  conversationStarterAtom,
  generalAgentIdAtom,
  selectedAgentToolsAtom,
} from '@/modules/agent/jotai/agent';
import AgentLayout from '@/modules/agent/layout/WorkFlowLayout';
import { ModeType } from '@/modules/agent/type/agent';
import Canvas from '@/modules/chat/components/Canvas/Canvas';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import React, { useEffect, useState } from 'react';
import styles from './CreateAgent.module.scss';

interface IProps {
  headerNode?: React.ReactNode;
}

const GeneralAgentReview = ({ headerNode }: IProps) => {
  const [agentCanvasOpen, setAgentCanvasOpen] = useAtom(agentCanvasOpenAtom);
  const [, updateAgentData] = useAtom(agentDataAtom);
  const [mode, setMode] = useState<ModeType | string>(ModeType.DASHBOARD);
  const [, updateSelectedTools] = useAtom(selectedAgentToolsAtom);
  const [, updateTools] = useAtom(agentToolListAtom);
  const [, setConversationStarter] = useAtom(conversationStarterAtom);
  const [, setAgentDetailId] = useAtom(agentDetailIdAtom);
  const [, setAgentId] = useAtom(generalAgentIdAtom);
  const [, setIdForUpdating] = useAtom(agentIdForUpdating);
  useEffect(
    () => () => {
      setAgentCanvasOpen(false);
      updateAgentData({
        name: undefined,
        description: undefined,
        file: undefined,
        id: undefined,
        instruction: undefined,
        type: undefined,
      });
      updateSelectedTools([]);
      updateTools([]);
      setConversationStarter(['']);
      setAgentDetailId('');
      setAgentId('');
      setIdForUpdating('');
    },

    []
  );

  return (
    <>
      <Box className={cn(agentCanvasOpen && styles.hide)}>
        <AgentLayout mode={mode} setMode={setMode}>
          <Box className={styles.basicContent}>
            <CreateBasicAgent headerNode={headerNode} mode={mode} />
          </Box>
        </AgentLayout>
      </Box>
      <Box className={cn(!agentCanvasOpen && styles.hide)}>
        <Canvas />
      </Box>
    </>
  );
};

export default GeneralAgentReview;
