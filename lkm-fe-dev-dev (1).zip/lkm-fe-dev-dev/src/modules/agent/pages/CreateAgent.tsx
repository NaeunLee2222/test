import CreateBasicAgent from '@/modules/agent/components/CreateBasicAgent';
import ReactFlowContainer from '@/modules/agent/components/ReactFlowContainer';
import {
  agentDataAtom,
  agentIdForUpdating,
  agentMode,
  agentToolListAtom,
  alreadyCreatedWorkflowAtom,
  conversationStarterAtom,
  edgesAtom,
  generalAgentIdAtom,
  nodesAtom,
  selectedAgentToolsAtom,
} from '@/modules/agent/jotai/agent';
import AgentLayout from '@/modules/agent/layout/WorkFlowLayout';
import { AgentType, ModeType } from '@/modules/agent/type/agent';
import { agentDetailIdAtom } from '@/modules/chat/jotai/agents';
import { messagesAtom } from '@/modules/chat/jotai/chat';
import { Box } from '@mui/material';
import { useAtom, useSetAtom } from 'jotai';
import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import styles from './CreateAgent.module.scss';

const CreateAgent: React.FC = () => {
  const [showRecipe, setShowRecipe] = useState<boolean>(false);
  const [mode, setMode] = useState<ModeType | string>(ModeType.DASHBOARD);

  const [, setAgentMode] = useAtom(agentMode);
  const [, updateAgentData] = useAtom(agentDataAtom);
  const [, updateSelectedTools] = useAtom(selectedAgentToolsAtom);
  const [, updateTools] = useAtom(agentToolListAtom);
  const [, updateAlreadyCreatedWorkflow] = useAtom(alreadyCreatedWorkflowAtom);
  const updateMessagesData = useSetAtom(messagesAtom);
  const [, updateNodes] = useAtom(nodesAtom);
  const [, setEdges] = useAtom(edgesAtom);
  const [, setAgentDetailId] = useAtom(agentDetailIdAtom);
  const [, setAgentId] = useAtom(generalAgentIdAtom);
  const [, setIdForUpdating] = useAtom(agentIdForUpdating);
  const [, setConversationStarter] = useAtom(conversationStarterAtom);

  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const modeUrl = params.get('mode');
  const isPro = useMemo(
    () => modeUrl?.trim()?.toLowerCase() === AgentType.PRO.toLowerCase(),
    [modeUrl]
  );

  useEffect(() => {
    if (mode?.trim()?.toLowerCase() === AgentType.PRO.toLowerCase()) {
      setAgentMode(AgentType.PRO);
      updateAgentData({ type: AgentType.PRO });
    } else {
      setAgentMode(AgentType.GENERAL);
      updateAgentData({ type: AgentType.GENERAL });
    }
  }, [mode, setAgentMode, isPro]);

  useEffect(() => {
    updateAgentData({
      name: undefined,
      description: undefined,
      file: undefined,
      id: undefined,
      instruction: undefined,
      type: undefined,
    });
    updateSelectedTools([]);
    updateAlreadyCreatedWorkflow(null);
    updateTools([]);
    updateMessagesData({});
    updateNodes([]);
    setEdges([]);
    setAgentDetailId('');
    setAgentId('');
    setIdForUpdating('');
    setShowRecipe(false);
    setConversationStarter(['']);
  }, []);

  return (
    <AgentLayout mode={mode} setMode={setMode}>
      <Box className={!isPro ? styles.basicContent : styles.content}>
        {!isPro && (
          <CreateBasicAgent
            mode={mode}
            showRecipe={showRecipe}
            setShowRecipe={setShowRecipe}
          />
        )}
        {isPro && <ReactFlowContainer />}
      </Box>
    </AgentLayout>
  );
};

export default CreateAgent;
