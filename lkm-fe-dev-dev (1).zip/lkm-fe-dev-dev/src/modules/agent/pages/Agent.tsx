import IconPlus from '@/assets/basic-icons/icon-plus.svg?react';
import { CardMain } from '@/modules/agent/components/CardList/CardMain';
import { AgentType, OrderSort } from '@/modules/agent/type/agent';
import { DEFAULT_SKIP } from '@/modules/chat/components/ChatInput/constants';
import { useDisabledAgentsData } from '@/modules/chat/hooks/useAgents';
import { listAgentPaginationAtom } from '@/modules/chat/jotai/agents';
import {
  AGENT_TAB_KEY,
  EChatAgentStatus,
  EUsageScope,
} from '@/modules/chat/types/agents';
import { ContainerLayout } from '@/modules/core/components/common/ContainerLayout/ContainerLayout';
import TabContent, {
  TabListProps,
} from '@/modules/core/components/common/TabContent/TabContent';
import { RoutesURL } from '@/routers/routes';
import { useAtom, useAtomValue } from 'jotai';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { agentSettingExpandedAtom } from '../jotai/agent';

export const Agent = () => {
  const { t } = useTranslation('tax');
  const navigate = useNavigate();

  const [updatedTime, setUpdatedTime] = useState(0);
  const [curTab, setCurTab] = useState<AgentType>(
    (window.sessionStorage.getItem(AGENT_TAB_KEY) as AgentType) ?? AgentType.PRO
  );
  const [curSort, setCurSort] = useState<OrderSort>(OrderSort.LATEST);
  const [filterText, setFilterText] = useState<string>('');
  const [isPagination, setIsPagination] = useState<boolean>(false);

  const [pagination, setPagination] = useAtom(listAgentPaginationAtom);
  const [, setAgentSettingExpanded] = useAtom(agentSettingExpandedAtom);

  const {
    data: agentsList,
    refetch,
    isSuccess,
    dataUpdatedAt,
    isFetching,
  } = useAtomValue(useDisabledAgentsData);

  useEffect(() => {
    if (updatedTime !== dataUpdatedAt && isSuccess) {
      setUpdatedTime(dataUpdatedAt);
    }
  }, [dataUpdatedAt, isSuccess]);

  useEffect(() => {
    setPagination((prev) => ({
      ...prev,
      limit: 40,
      reviewStatus:
        curTab === AgentType.MY_AGENT
          ? ('' as EChatAgentStatus)
          : EChatAgentStatus.DEPLOYED,
      agentType: curTab,
      order: OrderSort.LATEST,
      isMyAgent: curTab === AgentType.MY_AGENT,
      updated: Date.now(),
      usageScope:
        curTab === AgentType.GENERAL ? EUsageScope.ORG : EUsageScope.PUBLIC,
    }));

    refetch();
  }, []);

  const onChangeTextFilter = (text: string) => {
    setFilterText(text);
    setPagination({
      skip: 0,
      limit: 40,
      category: '',
      usageScope:
        curTab === AgentType.GENERAL ? EUsageScope.ORG : EUsageScope.PUBLIC,
      reviewStatus:
        curTab === AgentType.MY_AGENT
          ? ('' as EChatAgentStatus)
          : EChatAgentStatus.DEPLOYED,
      agentType: curTab,
      order: curSort,
      name: text,
      isMyAgent: curTab === AgentType.MY_AGENT,
      updated: Date.now(),
    });
    refetch();
  };

  const onChangeTab = (tab: string) => {
    window.sessionStorage.setItem(AGENT_TAB_KEY, tab);
    setCurTab(tab as AgentType);
    setPagination({
      skip: 0,
      limit: 40,
      category: '',
      usageScope:
        tab === AgentType.GENERAL ? EUsageScope.ORG : EUsageScope.PUBLIC,
      reviewStatus:
        tab === AgentType.MY_AGENT
          ? ('' as EChatAgentStatus)
          : EChatAgentStatus.DEPLOYED,
      agentType: tab as AgentType,
      order: curSort,
      name: filterText,
      isMyAgent: tab === AgentType.MY_AGENT,
      updated: Date.now(),
    });
    setIsPagination(false);
    refetch();
  };

  const onChangeSort = (option: string) => {
    setCurSort(option as OrderSort);
    setPagination({
      skip: 0,
      limit: 40,
      category: '',
      usageScope:
        curTab === AgentType.GENERAL ? EUsageScope.ORG : EUsageScope.PUBLIC,
      reviewStatus:
        curTab === AgentType.MY_AGENT
          ? ('' as EChatAgentStatus)
          : EChatAgentStatus.DEPLOYED,
      agentType: curTab,
      order: option as OrderSort,
      name: filterText,
      isMyAgent: curTab === AgentType.MY_AGENT,
      updated: Date.now(),
    });
    refetch();
  };

  const listTab: TabListProps[] = useMemo(
    () => [
      {
        label: t('agent.cardItem.proAgent'),
        value: AgentType.PRO,
        tabContent: (
          <CardMain
            // check type of tab to avoid content flickering of list agent chat from chat initial
            listItems={
              pagination.agentType === AgentType.PRO && agentsList?.agents
                ? agentsList?.agents
                : []
            }
            curTab={AgentType.PRO}
          />
        ),
      },
      {
        label: t('agent.cardItem.basicAgent'),
        value: AgentType.GENERAL,
        tabContent: (
          <CardMain
            // check type of tab to avoid content flickering of list agent chat from chat initial
            listItems={
              pagination.agentType === AgentType.GENERAL && agentsList?.agents
                ? agentsList?.agents
                : []
            }
            curTab={AgentType.GENERAL}
          />
        ),
      },
      {
        label: t('agent.cardItem.myCreateAgent'),
        value: AgentType.MY_AGENT,
        tabContent: (
          <CardMain
            // check type of tab to avoid content flickering of list agent chat from chat initial
            listItems={
              pagination.agentType === AgentType.MY_AGENT && agentsList?.agents
                ? agentsList?.agents
                : []
            }
            curTab={AgentType.MY_AGENT}
          />
        ),
      },
    ],

    [agentsList?.agents, updatedTime, isPagination]
  );

  const sortList = useMemo(
    () => [
      {
        label: t('agent.sort.name'),
        value: OrderSort.NAME_ASC,
      },
      {
        label: t('agent.sort.increase'),
        value: OrderSort.NAME_DESC,
      },
      {
        label: t('agent.sort.used'),
        value: OrderSort.POPULARITY,
      },
    ],
    [t]
  );

  const handleRedirectCreateAgent = (mode: string) => {
    if (mode === AgentType.PRO) {
      setAgentSettingExpanded(true);
    }

    navigate(`${RoutesURL.AGENT_CREATE}?mode=${mode}`);
  };

  const handlePagination = useCallback(() => {
    if (agentsList?.agents) {
      if (agentsList?.isEnd) {
        return;
      }
      setPagination((prev) => {
        const nextSkip = prev.skip + prev.limit;
        const newPagination = {
          ...prev,
          skip: nextSkip ?? DEFAULT_SKIP,
          limit: 40,
        };
        return newPagination;
      });

      setIsPagination(true);
      refetch();
    }
  }, [agentsList, refetch, setPagination]);

  return (
    <ContainerLayout
      title={t('agent.headerTitleGallery')}
      description={t('agent.headerDescription')}
      buttonAction={handleRedirectCreateAgent}
      buttonLabel={t('agent.create')}
      iconButton={
        <IconPlus
          width='16'
          height='16'
          fill='var(--gray-50)'
          style={{ marginRight: '7px' }}
        />
      }
      sx={{
        overflow: 'auto',
        height: '100%',
      }}
      onPaging={handlePagination}
    >
      <TabContent
        listTab={listTab}
        onChangeFilter={onChangeTextFilter}
        onChangeTab={onChangeTab}
        onChangeSort={onChangeSort}
        curTab={curTab}
        isFetching={isFetching && !isPagination}
        sortList={sortList}
      />
    </ContainerLayout>
  );
};
