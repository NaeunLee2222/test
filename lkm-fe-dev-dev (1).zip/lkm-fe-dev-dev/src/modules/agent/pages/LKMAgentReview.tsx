import { WorkflowReviewMain } from '@/modules/agent/components/WorkflowReview/WorkflowReviewMain';
import AgentLayout from '@/modules/agent/layout/WorkFlowLayout';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ModeType } from '../type/agent';

const LKMAgentReview = () => {
  const [searchParams] = useSearchParams();
  const initMode = searchParams.get('action');

  const [mode, setMode] = useState<ModeType | string>(ModeType.DASHBOARD);

  useEffect(() => {
    if (initMode) {
      setMode(ModeType.CHAT);
    }
  }, [initMode]);

  return (
    <AgentLayout mode={mode} setMode={setMode}>
      <WorkflowReviewMain mode={mode} />
    </AgentLayout>
  );
};

export { LKMAgentReview };
