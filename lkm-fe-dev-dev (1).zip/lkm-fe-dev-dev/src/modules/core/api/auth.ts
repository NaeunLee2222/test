import { axiosInstance, chatInstance } from '@/modules/core/libs';
import { IUserLogin, IUserMe } from '@/types/user';
import {
  clearLocalStorageWithoutNecessary,
  getUserIdFromCookie,
} from '@/utils';

const URL_BASE_AUTH = '/auth';

export async function fetchCompanyList() {
  return axiosInstance.get(`${URL_BASE_AUTH}/company`);
}

export async function fetchLogin(userInfo: IUserLogin): Promise<any> {
  // Mock user credentials
  const MOCK_USER = {
    user_id: 'test',
    password: 'test123!',
  };

  let payload: any = {};
  switch (userInfo.type) {
    case 'okta':
      payload = {
        type: userInfo.type,
        email: userInfo.email,
        username: userInfo.name,
        exp: userInfo.exp,
        iat: userInfo.iat,
        user_id: userInfo.email!.split('@')[0],
        company: userInfo.company,
      };
      break;
    case 'basic':
    default:
      // Check mock user credentials
      if (
        userInfo.userId === MOCK_USER.user_id &&
        userInfo.password === MOCK_USER.password
      ) {
        // Return mock response
        const mockResponse = {
          access_token: 'mock_token_12345',
          user: {
            user_id: MOCK_USER.user_id,
            name: 'Test User',
            email: 'test@example.com',
            company: userInfo.company,
            role: ['admin'],
          },
        };
        localStorage.setItem('token', mockResponse.access_token);
        return mockResponse;
      }

      payload = {
        email: userInfo.userId,
        password: userInfo.password,
      };
      break;
  }

  // Only make API call if not using mock user
  if (
    !(
      userInfo.userId === MOCK_USER.user_id &&
      userInfo.password === MOCK_USER.password
    )
  ) {
    const response: any = await chatInstance.post(
      `${URL_BASE_AUTH}/login`,
      JSON.stringify(payload)
    );
    clearLocalStorageWithoutNecessary();
    localStorage.setItem('token', response?.access_token ?? '');
    return response;
  }
}

export async function fetchLogout() {
  const response = await chatInstance.post(`${URL_BASE_AUTH}/logout`);
  clearLocalStorageWithoutNecessary();
  return response;
}

export const fetchUserMe = async (): Promise<IUserMe> => {
  const userId = getUserIdFromCookie();

  // TODO: remove this after user/me API is available
  if (!userId) {
    return {
      user_id: 'test',
      username: 'test',
      email: 'test@example.com',
      cost: 0,
      roles: [],
    };
  }
  const response = await chatInstance.get(`/user/?id=${userId}`);
  return response.data;
};
