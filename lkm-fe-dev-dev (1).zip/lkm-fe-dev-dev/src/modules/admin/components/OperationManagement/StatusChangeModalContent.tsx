import IconArrowRight from '@/assets/direction-icons/icon-arrow-right.svg?react';
import cn from 'classnames';
import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import styles from './OperationManagement.module.scss';

interface IProps {
  currentStatus: string;
  targetStatus: string;
}

const StatusChangeModalContent = ({ currentStatus, targetStatus }: IProps) => {
  const { t } = useTranslation('admin');
  const content =
    currentStatus === t('tableStatus.inactive')
      ? t('agentStatusModal.inactiveContent')
      : t('agentStatusModal.content');

  const getClass = useCallback(
    (status: string) => {
      switch (status) {
        case t('tableStatus.inactive'):
          return styles.inactivated;
        case t('tableStatus.active'):
          return styles.activated;
        default:
          return '';
      }
    },
    [t]
  );

  return (
    <div className={styles.changeStatusContent}>
      <div className={styles.statusFlow}>
        <div className={cn(styles.statusItem, getClass(currentStatus))}>
          <div className={cn(styles.statusText, getClass(currentStatus))}>
            {currentStatus}
          </div>
        </div>
        <IconArrowRight />
        <div className={cn(styles.statusItem, getClass(targetStatus))}>
          <div className={cn(styles.statusText, getClass(targetStatus))}>
            {targetStatus}
          </div>
        </div>
      </div>
      <div className={styles.description}>{content}</div>
    </div>
  );
};

export default StatusChangeModalContent;
