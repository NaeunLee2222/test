import styles from '@/modules/admin/components/OperationManagement/OperationManagement.module.scss';
import { OperationSearch } from '@/modules/admin/components/OperationManagement/OperationSearch';
import { OperationTable } from '@/modules/admin/components/OperationManagement/OperationTable';
import { EAgentManagementTabMode } from '@/types/common';
import { Box } from '@mui/material';

const OperationManagementTab = ({
  type,
}: {
  type: EAgentManagementTabMode;
}) => (
  <Box className={styles.agentManagementTab}>
    <Box className={styles.formSearch} data-testid='search-container'>
      <OperationSearch />
    </Box>
    <Box className={styles.tableWrapper}>
      <OperationTable type={type} />
    </Box>
  </Box>
);

export { OperationManagementTab };
