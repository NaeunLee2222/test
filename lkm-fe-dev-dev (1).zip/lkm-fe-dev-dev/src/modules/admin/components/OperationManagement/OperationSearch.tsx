import Calendar from '@/assets/basic-icons/icon-calendar2.svg?react';
import styles from '@/modules/admin/components/OperationManagement/OperationManagement.module.scss';
import SearchSelect from '@/modules/admin/components/Search/Select';
import {
  defaultDeployedAgentFilterValue,
  listDeployedAgentPaginationAtom,
} from '@/modules/admin/jotai/agent';
import { AgentType } from '@/modules/agent/type/agent';
import { DateTimeAdminTableFormat } from '@/types/common';
import { formatDateToKst } from '@/utils';
import { Button, TextField } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { DatePicker } from 'rsuite';
import 'rsuite/DateRangePicker/styles/index.css';

export const OperationSearch = () => {
  const { t } = useTranslation('admin');
  const isActivatedOptions = [
    { value: '', label: t('operationManagement.form.mode.option.option_1') },
    {
      value: 'true',
      label: t('operationManagement.form.mode.option.option_2'),
    },
    {
      value: 'false',
      label: t('operationManagement.form.mode.option.option_3'),
    },
  ];
  const agentTypeOptions = [
    {
      value: '',
      label: t('operationManagement.form.situation.option.option_1'),
    },
    {
      value: AgentType.GENERAL,
      label: t('operationManagement.form.situation.option.option_2'),
    },
    {
      value: AgentType.PRO,
      label: t('operationManagement.form.situation.option.option_3'),
    },
  ];
  const [search, setSearch] = useState('');
  const [startDate, setStartDate] = useState<Date | null>();
  const [endDate, setEndDate] = useState<Date | null>();
  const [agentType, setAgentType] = useState('');
  const [isActivated, setIsActivated] = useState<string>('');
  const [, setListDeployedAgentPagination] = useAtom(
    listDeployedAgentPaginationAtom
  );

  const handleSearch = useCallback(() => {
    setListDeployedAgentPagination((prev) => ({
      page: 0,
      rowsPerPage: prev.rowsPerPage || 10,
      agent_type: agentType || undefined,
      is_activated: isActivated,
      end_date: endDate
        ? formatDateToKst(endDate.toISOString(), 'YYYY-MM-DD')
        : undefined,
      start_date: startDate
        ? formatDateToKst(startDate.toISOString(), 'YYYY-MM-DD')
        : undefined,
      review_status: agentType || undefined,
      usage_scope: prev.usage_scope,
      search: search || undefined,
      sortDetail: prev.sortDetail || undefined,
    }));
  }, [
    setListDeployedAgentPagination,
    agentType,
    isActivated,
    endDate,
    startDate,
    search,
  ]);

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      setSearch((e.target as HTMLInputElement).value);
      handleSearch();
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  useEffect(() => {
    handleSearch();
  }, [isActivated, endDate, agentType, startDate]);

  const setAgentTypeAndSearch = useCallback(
    (value: string) => {
      setAgentType(value);
      setListDeployedAgentPagination((prev) => ({
        ...prev,
        review_status: value,
      }));
    },
    [setListDeployedAgentPagination]
  );

  const setStartDateAndSearch = useCallback(
    (value: Date | null) => {
      setStartDate(value);
      setListDeployedAgentPagination((prev) => ({
        ...prev,
        start_date: value
          ? formatDateToKst(value.toISOString(), 'YYYY-MM-DD')
          : undefined,
      }));
    },
    [setListDeployedAgentPagination]
  );

  const setEndDateAndSearch = useCallback(
    (value: Date | null) => {
      setEndDate(value);
      setListDeployedAgentPagination((prev) => ({
        ...prev,
        end_date: value
          ? formatDateToKst(value.toISOString(), 'YYYY-MM-DD')
          : undefined,
      }));
    },
    [setListDeployedAgentPagination]
  );

  const setIsActivatedAndSearch = useCallback(
    (value: string) => {
      setIsActivated(value);
      setListDeployedAgentPagination((prev) => ({ ...prev, date_type: value }));
    },
    [setListDeployedAgentPagination]
  );

  const handleClear = useCallback(() => {
    setAgentType('');
    setIsActivated('');
    setStartDate(null);
    setEndDate(null);
    setSearch('');
    setListDeployedAgentPagination((prev) => ({
      ...defaultDeployedAgentFilterValue,
      usage_scope: prev.usage_scope,
    }));
  }, [setListDeployedAgentPagination]);

  return (
    <div className={styles.searchContainer}>
      <div className={styles.selectContainer}>
        <div className={styles.dateSelectField}>
          <div
            className={styles.label}
          >{`${t('agentManagement.form.period.title')}`}</div>
          <div className={styles.dateSelectText}>
            <DatePicker
              className={cn(styles.datePickerField, 'custom-date-picker')}
              oneTap
              editable={false}
              format={DateTimeAdminTableFormat.yyyyMMdd}
              placeholder={t('agentDatePlaceholder')}
              value={startDate}
              onChange={(value: Date | null) => setStartDateAndSearch(value)}
              caretAs={Calendar}
            />
            <div className={styles.tilde}>~</div>
            <DatePicker
              className={cn(styles.datePickerField, 'custom-date-picker')}
              oneTap
              editable={false}
              format={DateTimeAdminTableFormat.yyyyMMdd}
              placeholder={t('agentDatePlaceholder')}
              value={endDate}
              onChange={(value: Date | null) => setEndDateAndSearch(value)}
              caretAs={Calendar}
            />
          </div>
        </div>
        <div className={styles.selectField}>
          <div
            className={styles.label}
          >{`${t('operationManagement.form.situation.title')}`}</div>
          <SearchSelect
            options={agentTypeOptions}
            defaultValue=''
            value={agentType}
            handleChange={setAgentTypeAndSearch}
            height='32px'
          />
        </div>
        <div className={styles.selectField}>
          <div
            className={styles.label}
          >{`${t('operationManagement.form.mode.title')}`}</div>
          <SearchSelect
            options={isActivatedOptions}
            defaultValue=''
            value={isActivated}
            handleChange={setIsActivatedAndSearch}
            height='32px'
          />
        </div>
      </div>

      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}`}</div>
        <TextField
          value={search}
          onKeyUp={handleOnKeyUpToSend}
          onChange={(e) => setSearch(e?.target?.value)}
          placeholder={t('operationManagement.form.searchPlaceholder')}
          className={styles.textField}
          sx={{
            '& fieldset': {
              border: '1px solid var(--gray-150)',
            },
            '&:hover': {
              '&& fieldset': {
                border: '1px solid var(--primary-color-600)',
              },
            },
          }}
        />
      </div>
      <div className={styles.searchAction}>
        <Button
          variant='outlined'
          className={styles.clear}
          onClick={handleClear}
          type='button'
          tabIndex={0}
          size='small'
        >
          {t('reset')}
        </Button>
        <Button
          size='small'
          variant='contained'
          className={styles.search}
          onClick={handleSearch}
          type='button'
          tabIndex={0}
          sx={{ boxShadow: 'none' }}
        >
          {t('check')}
        </Button>
      </div>
    </div>
  );
};
