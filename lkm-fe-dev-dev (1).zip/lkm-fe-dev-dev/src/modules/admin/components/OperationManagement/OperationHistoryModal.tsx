import { BaseTable } from '@/modules/admin/components/Table/BaseTable';
import { useGetAgentHistory } from '@/modules/admin/hooks/useAgentManagement';
import { listAgentHistoryAtom } from '@/modules/admin/jotai/agent';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { formatDateToKst } from '@/utils';
import { useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';

interface IProps {
  open: boolean;
  handleClose: () => void;
}
export const OperationHistoryModal = ({ open, handleClose }: IProps) => {
  const { t } = useTranslation('admin');
  const renderButtons = useCallback(
    () => (
      <div className='flexEnd'>
        <span
          className='flex'
          style={{ gap: '8px', marginRight: '16px', marginBottom: '8px' }}
        >
          <BaseButton buttonType='filled' onClick={handleClose}>
            <span>{t('operationManagement.history.confirm')}</span>
          </BaseButton>
        </span>
      </div>
    ),
    [handleClose, t]
  );

  const columns = useMemo(
    () => [
      {
        name: 'expert_agent_id',
        label: t('operationManagement.history.table.number'),
        width: '6%',
        sortable: true,
      },
      {
        name: 'modified_user_name',
        label: t('operationManagement.history.table.subject'),
        width: '15%',
      },
      {
        name: 'description',
        label: t('operationManagement.history.table.reason'),
        sortable: true,
      },
      {
        name: 'created_at',
        label: t('operationManagement.history.table.date'),
        width: '15%',
        sortable: true,
        format: (value: any) =>
          formatDateToKst(new Date(value).toISOString(), 'YYYY.MM.DD'),
      },
    ],
    [t]
  );

  const renderContents = useCallback(
    () => (
      <BaseTable
        columns={columns}
        keyField='id'
        showTotalRecords={false}
        showSelected={false}
        showCountStatus={false}
        showDesc={false}
        showSelectPagination={false}
        paginationSettingAtom={listAgentHistoryAtom}
        getData={useGetAgentHistory}
      />
    ),
    [columns]
  );

  return (
    <BaseDialog
      sx={{
        '.MuiPaper-root': {
          maxWidth: '768px',
        },
        '.MuiDialogContent-root': {
          maxHeight: '768px',
          overflow: 'auto',
        },
      }}
      open={open}
      handleClose={handleClose}
      title={t('operationManagement.history.title')}
      contentChildren={renderContents()}
      actionsChildren={renderButtons()}
    />
  );
};
