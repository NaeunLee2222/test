import styles from '@/modules/admin/components/OperationManagement/OperationManagement.module.scss';
import { CustomTabPanel } from '@/modules/admin/components/TabProps';
import { useDeployedAgentManagement } from '@/modules/admin/hooks/useAgentManagement';
import { listDeployedAgentPaginationAtom } from '@/modules/admin/jotai/agent';
import { UsageScope } from '@/modules/agent/type/agent';
import { EAgentManagementTabMode } from '@/types/common';
import { Box, Tab, Tabs } from '@mui/material';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { OperationManagementTab } from './OperationManagementTab';

export const OperationManagement = () => {
  const { t } = useTranslation('admin');

  const [tabIndex, setTabIndex] = useState(0);
  const [{ data }] = useAtom(useDeployedAgentManagement);
  const [, setListDeployedAgentPagination] = useAtom(
    listDeployedAgentPaginationAtom
  );

  useEffect(() => {
    setListDeployedAgentPagination((prev) => ({
      page: 0,
      rowsPerPage: prev.rowsPerPage || 10,
      agent_type: undefined,
      is_activated: undefined,
      end_date: undefined,
      start_date: undefined,
      review_status: undefined,
      usage_scope: tabIndex === 0 ? UsageScope.ORG : UsageScope.PUBLIC,
      search: undefined,
      sortDetail: undefined,
    }));
  }, []);

  const handleChange = (_event: React.SyntheticEvent, newTabIndex: number) => {
    setTabIndex(newTabIndex);

    let usageScope = UsageScope.ORG;

    // The index = 1 is for Pro agent
    if (newTabIndex === 1) {
      usageScope = UsageScope.PUBLIC;
    }

    setListDeployedAgentPagination((prev) => ({
      page: 0,
      rowsPerPage: prev.rowsPerPage || 10,
      agent_type: undefined,
      is_activated: undefined,
      end_date: undefined,
      start_date: undefined,
      review_status: undefined,
      usage_scope: usageScope,
      search: undefined,
      sortDetail: undefined,
    }));
  };

  const displayedTotal = useCallback(
    (isCurrentTab: boolean) => {
      if (data) {
        if (isCurrentTab) {
          return data.total_count;
        }

        return data.alter_total ?? 0;
      }

      return '';
    },
    [data]
  );

  return (
    <Box className={styles.adminMain}>
      <h1 className={styles.pageTitle}>{t('operationManagement.title')}</h1>
      <div className={styles.content}>
        <Box className={styles.tabsContainer}>
          <Tabs
            tabIndex={tabIndex}
            onChange={handleChange}
            className={styles.tabs}
          >
            <Tab
              label={`${t('operationManagement.tab.normal')} ${displayedTotal(tabIndex === 0)}`}
              className={styles.tab}
            />
            <Tab
              label={`${t('operationManagement.tab.flow')} ${displayedTotal(tabIndex === 1)}`}
              className={styles.tab}
            />
          </Tabs>
        </Box>

        <Box>
          <CustomTabPanel
            value={tabIndex}
            index={0}
            sx={{ padding: 0, paddingTop: '32px' }}
          >
            <OperationManagementTab type={EAgentManagementTabMode.NORMAL} />
          </CustomTabPanel>

          <CustomTabPanel
            value={tabIndex}
            index={1}
            sx={{ padding: 0, paddingTop: '32px' }}
          >
            <OperationManagementTab type={EAgentManagementTabMode.FLOW} />
          </CustomTabPanel>
        </Box>
      </div>
    </Box>
  );
};
