import HistoryIcon from '@/assets/basic-icons/icon-admin-operation-history.svg?react';
import { OperationHistoryModal } from '@/modules/admin/components/OperationManagement/OperationHistoryModal';
import styles from '@/modules/admin/components/OperationManagement/OperationManagement.module.scss';
import { BaseTable } from '@/modules/admin/components/Table/BaseTable';
import {
  useDeployedAgentManagement,
  usePatchAgentActivation,
} from '@/modules/admin/hooks/useAgentManagement';
import {
  listAgentHistoryAtom,
  listDeployedAgentPaginationAtom,
} from '@/modules/admin/jotai/agent';
import { showHeaderNodeAtom } from '@/modules/agent/jotai/agent';
import { AgentType } from '@/modules/agent/type/agent';
import { listAgentPaginationAtom } from '@/modules/chat/jotai/agents';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { RoutesURL } from '@/routers/routes';
import {
  EAgentManagementTabMode,
  EmptyString,
  EOperationTableStatus,
  SNACK_BAR_DURATION,
} from '@/types/common';
import { formatDateToKst } from '@/utils';
import { showSnackbar } from '@/utils/snackbarUtil';
import { Box, IconButton } from '@mui/material';
import { useAtom, useSetAtom } from 'jotai';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import SelectTooltip from './SelectTooltip';
import StatusChangeModalContent from './StatusChangeModalContent';

interface IProps {
  type: EAgentManagementTabMode;
}

const OperationTable = ({ type }: IProps) => {
  const { t } = useTranslation('admin');
  const navigate = useNavigate();

  const setPagination = useSetAtom(listAgentPaginationAtom);
  const [, setConfirmData] = useAtom(confirmDialogDataAtom);
  const [{ mutateAsync: agentActivation }] = useAtom(usePatchAgentActivation);
  const [{ refetch }] = useAtom(useDeployedAgentManagement);
  const [, setShowHeaderNode] = useAtom(showHeaderNodeAtom);
  const [, setListAgentHistory] = useAtom(listAgentHistoryAtom);

  const [openHistory, setOpenHistory] = useState(false);

  const statusList = useMemo(
    () => [
      {
        value: 'true',
        label: t('tableStatus.active'),
      },
      {
        value: 'false',
        label: t('tableStatus.inactive'),
      },
    ],
    [t]
  );

  useEffect(() => {
    setPagination((prev) => ({ ...prev, limit: 10 }));
  }, []);

  const columns = useMemo(
    () => [
      {
        name: 'id',
        label: t('operationManagement.table.number'),
        width: '80px',
        sortable: true,
      },
      {
        name: 'agent_type',
        label: t('operationManagement.table.modeDistinction'),
        width: '120px',
        format: (value: any, _row: any) => {
          switch (value) {
            case AgentType.GENERAL:
              return t('agentManagement.tab.normal');
            case AgentType.PRO:
              return t('agentManagement.tab.flow');
            default:
              return value;
          }
        },
      },
      {
        name: 'name',
        label: t('operationManagement.table.agentName'),
        sortable: true,
        format: (value: any, row: any) => (
          <Box
            className={styles.tableLink}
            onClick={(e) => handleNavigate(e, row)}
          >
            {value}
          </Box>
        ),
      },
      {
        name: 'is_activated',
        label: t('operationManagement.table.situation'),
        width: '100px',
        format: (value: any, row: any) => genStatusCell(row, value),
        contentAlign: 'center',
      },
      {
        name: 'user_name',
        label: t('operationManagement.table.proposer'),
        width: '120px',
        sortable: true,
      },
      {
        name: 'admin_name',
        label: t('operationManagement.table.manager'),
        width: '120px',
        sortable: true,
      },
      {
        name: 'registered_at',
        label: t('operationManagement.table.startDate'),
        width: '120px',
        sortable: true,
        format: (value: any, _row: any) => (
          <span>
            {value
              ? formatDateToKst(new Date(value).toISOString(), 'YYYY.MM.DD')
              : EmptyString}
          </span>
        ),
      },
      {
        name: 'record',
        label: t('operationManagement.table.record'),
        width: '60px',
        format: (_value: any, row: any) => (
          <Box
            sx={{
              width: '100%',
              textAlign: 'center',
            }}
          >
            <IconButton
              sx={{
                padding: 0,
                textAlign: 'center',
                '&:hover': {
                  backgroundColor: 'transparent',
                },
              }}
              onClick={() => handleOpenHistory(row.id)}
            >
              <HistoryIcon />
            </IconButton>
          </Box>
        ),
        contentAlign: 'center',
      },
    ],

    [t]
  );

  const setStatusCss = (status: string) => {
    switch (status) {
      case EOperationTableStatus.INACTIVE:
        return styles.inactive;
      case EOperationTableStatus.ACTIVE:
        return styles.active;
      default:
        return '';
    }
  };

  const calculateStatusText = useCallback(
    (value: string | boolean) =>
      statusList.find((item) => item.value === (value.toString() ?? 'false'))
        ?.label || t('tableStatus.inactive'),
    [statusList, t]
  );

  const changeStatus = useCallback(
    (id: number | string, status: string) => {
      agentActivation({
        agent_id: id,
        is_activated: status,
        callback: (response: any) => {
          if (response.success || response.data.message) {
            showSnackbar(
              t('agentStatusModal.successMessage'),
              'success',
              SNACK_BAR_DURATION,
              {
                vertical: 'bottom',
                horizontal: 'center',
              },
              {
                className: styles.successSnackbar,
              }
            );
          }
          refetch();
        },
      });
    },
    [agentActivation, refetch, t]
  );

  const handleSetStatus = useCallback(
    (row: any, value: string) => {
      const currentStatus = calculateStatusText(row.is_activated || '');
      const targetStatus = calculateStatusText(value);
      if (currentStatus === targetStatus) return;
      setConfirmData({
        open: true,
        title: t('agentStatusModal.title'),
        confirmText: t('agentStatusModal.change'),
        contentText: (
          <StatusChangeModalContent
            targetStatus={targetStatus}
            currentStatus={currentStatus}
          />
        ),
        handleCancel: () => {
          setConfirmData({ open: false });
        },
        handleConfirm: () => {
          changeStatus(row.id, value);
          setConfirmData({ open: false });
        },
      });
    },
    [calculateStatusText, changeStatus, setConfirmData, t]
  );

  const genStatusCell = (row: any, value: string) => (
    <SelectTooltip
      row={row}
      value={value}
      setStatusCss={setStatusCss}
      handleSetStatus={handleSetStatus}
    />
  );
  const handleNavigate = (e: React.MouseEvent<HTMLDivElement>, row: any) => {
    e.stopPropagation();
    e.preventDefault();
    setShowHeaderNode(false);

    navigate(
      row.agent_type === AgentType.GENERAL
        ? `${RoutesURL.SETTINGS_AGENT_GENERAL_OPERATION}/${row.id}`
        : `${RoutesURL.SETTINGS_AGENT_LKM_OPERATION}/${row.id}`
    );
  };

  const handleCloseHistory = () => {
    setOpenHistory(false);
  };

  const handleOpenHistory = (rowId: string | number) => {
    setOpenHistory(true);
    setListAgentHistory((prev) => ({ ...prev, agent_id: rowId.toString() }));
  };

  return (
    <>
      <OperationHistoryModal
        open={openHistory}
        handleClose={handleCloseHistory}
      />
      <BaseTable
        columns={columns}
        paginationSettingAtom={listDeployedAgentPaginationAtom}
        getData={useDeployedAgentManagement}
        keyField='id'
        showSelected={false}
        showCountStatus
        unit={t('piece')}
      />
    </>
  );
};

export { OperationTable };
