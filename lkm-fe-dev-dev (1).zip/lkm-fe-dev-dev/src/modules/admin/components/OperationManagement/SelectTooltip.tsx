import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import styles from '@/modules/admin/components/OperationManagement/OperationManagement.module.scss';
import { BaseMenuSx } from '@/modules/core/components/common/BaseMenu';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { EOperationTableStatus } from '@/types/common';
import { MenuItem, Select, tooltipClasses } from '@mui/material';
import cn from 'classnames';
import { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface IProps {
  row: any;
  value: string;
  setStatusCss: (status: string) => string;
  handleSetStatus: (row: any, value: string) => void;
}

const SelectTooltip = ({
  row,
  value,
  setStatusCss,
  handleSetStatus,
}: IProps) => {
  const { t } = useTranslation('admin');
  const [tooltipOpen, setTooltipOpen] = useState(false);
  const [selectOpen, setSelectOpen] = useState(false);
  const statusList = useMemo(
    () => [
      {
        value: 'true',
        label: t('tableStatus.active'),
      },
      {
        value: 'false',
        label: t('tableStatus.inactive'),
      },
    ],
    [t]
  );
  return (
    <BaseTooltip
      title={t('changeStatus')}
      open={tooltipOpen && !selectOpen}
      placement='bottom-end'
      slotProps={{
        popper: {
          sx: {
            [`&.${tooltipClasses.popper}[data-popper-placement*="bottom"] .${tooltipClasses.tooltip}`]:
              {
                padding: '4px 8px',
                fontSize: '13px',
                fontWeight: '400',
                lineHeight: '145%',
                letterSpacing: '0.026px',
                textAlign: 'start',
                marginTop: '4px',
                height: '30px',
              },
          },
        },
      }}
    >
      <Select
        onOpen={() => setSelectOpen(true)}
        onClose={() => setSelectOpen(false)}
        onMouseEnter={() => setTooltipOpen(true)}
        onMouseLeave={() => setTooltipOpen(false)}
        onClick={() => setTooltipOpen(false)}
        onChange={(e) => handleSetStatus(row, e.target.value)}
        className={cn(
          styles.statusSelect,
          setStatusCss(value ? 'active' : 'inactive')
        )}
        IconComponent={ArrowDownIcon}
        value={value ?? 'false'}
        sx={{
          '& .MuiOutlinedInput-notchedOutline': {
            border: 'none',
          },
          '& .MuiSelect-select': {
            padding: '0',
            textAlign: 'left',
          },
          '& .MuiSelect-icon': {
            width: '16px',
            height: '16px',

            '& path': {
              fill:
                value === EOperationTableStatus.ACTIVE
                  ? 'var(--primitives-green-80)'
                  : 'var(--primitives-darkBlue-80)',
            },
          },
        }}
        MenuProps={{
          sx: {
            ...BaseMenuSx,
            '& .MuiButtonBase-root.MuiMenuItem-root': {
              borderRadius: '8px',
              padding: '4px 12px',
              fontSize: '13px',
              fontWeight: '500',
              lineHeight: '145%',
            },
            '& .MuiButtonBase-root.MuiMenuItem-root.Mui-selected': {
              backgroundColor: 'var(--gray-50) !important',
              '&::after': {
                display: 'none',
              },
            },
            '& .MuiMenu-list': {
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              padding: 0,
            },
          },
          PaperProps: {
            sx: {
              boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.2)',
              borderRadius: '8px',
              padding: '4px 2px',
              width: '76px',
            },
          },
        }}
      >
        {statusList.map((item, index) => (
          <MenuItem value={item.value} key={index}>
            {item.label}
          </MenuItem>
        ))}
      </Select>
    </BaseTooltip>
  );
};

export default SelectTooltip;
