import { RangeDatePicker } from '@/modules/core/components/common/DatePicker/RangeDatePicker';
import { useCompanyList } from '@/modules/core/hooks';
import { getKstTimestampBySelectedDate } from '@/utils';
import dayjs from 'dayjs';
import localeData from 'dayjs/plugin/localeData';
import weekday from 'dayjs/plugin/weekday';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import {
  fewShotDetailCompanyAtom,
  fewShotDetailDateAtom,
  fewShotDetailSearchAtom,
  fewShotDetailStatusAtom,
  listPaginationAtom,
  useFewShotSettings,
} from '../../hooks/useFewShotSettings';
import styles from '../../styles/AdminMain.module.scss';
import SearchInput from '../Search/Input';
import SearchSelect from '../Search/Select';

dayjs.extend(weekday);
dayjs.extend(localeData);

export const FormSearch = () => {
  const { t } = useTranslation('admin');
  const [searchParams] = useSearchParams();
  const now = dayjs();
  const last7Days = dayjs().subtract(6, 'day');
  const [selectedDate, setSelectedDate] = useAtom(fewShotDetailDateAtom);
  const [status, setStatus] = useAtom(fewShotDetailStatusAtom);
  const [search, setSearch] = useAtom(fewShotDetailSearchAtom);

  const [company, setFewShotDetailCompany] = useAtom(fewShotDetailCompanyAtom);
  const [, setPage] = useAtom(listPaginationAtom);
  const [{ refetch }] = useAtom(useFewShotSettings);

  const [{ data: companyList }] = useAtom(useCompanyList);

  const companyOptions = useMemo(
    () => [
      { value: 'COMMON', label: 'COMMON' },
      ...(companyList?.map((c) => ({
        value: c.name,
        label: c.name,
      })) || []),
    ],

    [companyList]
  );

  const handleSearch = ({
    currentDateValue,
    currentStatus,
    currentCompany,
    currentSearchValue,
    isEventDriven,
  }: {
    currentDateValue: dayjs.Dayjs[];
    currentStatus: string;
    currentCompany: string;
    currentSearchValue?: string;
    isEventDriven?: boolean;
  }) => {
    let params = '';
    if (currentSearchValue) {
      params = `&search=${currentSearchValue}`;
    }
    if (currentStatus) {
      params = `${params}&status=${currentStatus}`;
    }
    if (currentCompany) {
      params = `${params}&company=${currentCompany}`;
    }
    const dateStr = getKstTimestampBySelectedDate(currentDateValue);
    if (dateStr) {
      params = `${params}&${dateStr}`;
    }

    setPage((prev) => ({ ...prev, page: 0, search: params }));
    if (isEventDriven) refetch();
  };

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch({
        currentDateValue: selectedDate,
        currentStatus: status,
        currentCompany: company,
        currentSearchValue: (e.target as HTMLInputElement).value,
        isEventDriven: true,
      });
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleChangeDate = (date: any) => {
    if (date && _.size(date) > 1) {
      const startDate = date[0] || '';
      const endDate = date[1] || '';
      setSelectedDate([dayjs(startDate), dayjs(endDate)]);
      handleSearch({
        currentDateValue: [dayjs(startDate), dayjs(endDate)],
        currentStatus: status,
        currentCompany: company,
        currentSearchValue: search,
        isEventDriven: true,
      });
    }
  };

  const handleSelectStatusType = (value: string) => {
    setStatus(value);
    handleSearch({
      currentDateValue: selectedDate,
      currentStatus: value,
      currentCompany: company,
      currentSearchValue: search,
      isEventDriven: true,
    });
  };

  const handleSelectCompany = (value: string) => {
    setFewShotDetailCompany(value);
    handleSearch({
      currentDateValue: selectedDate,
      currentStatus: status,
      currentCompany: value,
      currentSearchValue: search,
      isEventDriven: true,
    });
  };

  useEffect(() => {
    const startDateParam = searchParams.get('startDate');
    const endDateParam = searchParams.get('endDate');
    const formattedDate = [dayjs(startDateParam), dayjs(endDateParam)];
    const statusParam = searchParams.get('status');

    if (statusParam) {
      setStatus(statusParam);
    }

    if (startDateParam && endDateParam) {
      setSelectedDate(formattedDate as [dayjs.Dayjs, dayjs.Dayjs]);
    }

    const isValidDate = formattedDate.every((date) => date.isValid());

    handleSearch({
      currentDateValue: isValidDate ? formattedDate : [last7Days, now],
      currentStatus: statusParam || '',
      currentCompany: company,
    });
  }, [searchParams]);

  useEffect(() => {
    if (company === '' && companyOptions.length > 1)
      setFewShotDetailCompany('SKCC');
  }, [companyOptions]);

  return (
    <div className={styles.formSearch}>
      <div className={styles.inputDate}>
        <div className={styles.label}>{`${t('date')}:`}</div>
        <RangeDatePicker
          className={styles.dateRangePicker}
          onConfirm={(date: any) => handleChangeDate(date)}
          defaultValue={selectedDate}
        />
      </div>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('company')}:`}</div>
        <SearchSelect
          options={companyOptions}
          value={company}
          handleChange={handleSelectCompany}
        />
      </div>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('fewShot.situation')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: 'ALL' },
            { value: 'FAILED', label: 'FAILED' },
            { value: 'SUCCEEDED', label: 'SUCCEEDED' },
            { value: 'GENERATED', label: 'INPROGRESS' },
          ]}
          defaultValue=''
          handleChange={handleSelectStatusType}
        />
      </div>
      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('fewShot.searchPlaceHolder')}
          search={search}
        />
      </div>
    </div>
  );
};
