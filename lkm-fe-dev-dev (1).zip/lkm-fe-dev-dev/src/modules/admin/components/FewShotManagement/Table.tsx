import DislikeIcon from '@/assets/basic-icons/icon-dislike.svg?react';
import LikeIcon from '@/assets/basic-icons/icon-like.svg?react';
import { formatDateToKst } from '@/utils';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
  fewShotDetailCompanyAtom,
  listPaginationAtom,
  useFewShotSettings,
} from '../../hooks/useFewShotSettings';
import { BaseTable } from '../Table/BaseTable';

export const Table = () => {
  const { t } = useTranslation('admin');
  const navigate = useNavigate();
  const [, setFewShotDetailCompany] = useAtom(fewShotDetailCompanyAtom);
  const columns = useMemo(
    () => [
      {
        name: 'input',
        label: t('Input'),
        width: '10%',
      },
      {
        name: 'output',
        label: t('Output'),
        width: '10%',
      },
      {
        name: 'law_info',
        label: t('Law_info'),
        width: '10%',
      },
      { name: 'node_key', label: t('Node_key'), width: '8%' },
      {
        name: 'flag',
        label: t('Flag'),
        width: '5%',
        format: (value: string) =>
          _.isEqual(value, 1) ? <LikeIcon /> : <DislikeIcon />,
      },
      {
        name: 'status',
        label: 'Status',
        width: '10%',
      },
      {
        name: 'update_dt',
        label: t('Update_dt'),
        width: '15%',
        format: (value: string) =>
          formatDateToKst(value, 'YYYY-MM-DD, HH:mm:ss'),
        sortable: true,
      },
    ],
    [t]
  );

  const handleClickAdd = () => {
    navigate(`/settings/few-shot/add`);
  };

  const handleClickRow = (row: any) => {
    setFewShotDetailCompany(row.company);
    navigate(`/settings/few-shot/${row.id}`, { state: { isView: true } });
  };

  return (
    <BaseTable
      columns={columns}
      paginationSettingAtom={listPaginationAtom}
      getData={useFewShotSettings}
      hasAddBtn
      customClickAdd={handleClickAdd}
      handleClickRowAction={handleClickRow}
      addBtnLabel={t('fewShot.addBtnLabel')}
      popupConfirmTitle={t('fewShot.title')}
      popupConfirmContent={t('fewShot.confirmDeleteMessage')}
    />
  );
};
