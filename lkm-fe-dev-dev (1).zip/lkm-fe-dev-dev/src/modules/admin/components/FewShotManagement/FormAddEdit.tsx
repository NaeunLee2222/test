import IconArrowRight from '@/assets/direction-icons/icon-arrow-right.svg?react';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { useCompanyList } from '@/modules/core/hooks';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { RoutesURL } from '@/routers/routes';
import { showSnackbar } from '@/utils/snackbarUtil';
import { CircularProgress } from '@mui/material';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  fewShotDetailCompanyAtom,
  fewShotDetailIdAtom,
  getDetailMutation,
  useDeleteMutation,
  useFewShotMutation,
} from '../../hooks/useFewShotSettings';
import styles from '../../styles/AdminMain.module.scss';
import type { IFewShot } from '../../types/fewShot';
import BaseInput from '../Form/Inputs/BaseInput';
import BaseRadioGroup from '../Form/Radios/BaseRadioGroup';
import BaseSelect from '../Form/Selects/BaseSelect';
import { FormView } from './FormView';

const viewStates = {
  view: 'view',
  edit: 'edit',
  add: 'add',
};

export const FormAddEdit = () => {
  const { t } = useTranslation('admin');
  const methods = useForm();
  const params = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [formState, setFormState] = useState(viewStates.view);
  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [{ mutateAsync: mutateFewShot }] = useAtom(useFewShotMutation);
  const [{ data: fewShotData }] = useAtom(getDetailMutation);
  const [isLoading, setIsLoading] = useState(false);
  const [, setFewShotId] = useAtom(fewShotDetailIdAtom);
  const [{ data: companyList }] = useAtom(useCompanyList);
  const [company] = useAtom(fewShotDetailCompanyAtom);

  const companyOptions = useMemo(
    () => ['COMMON', ...(companyList?.map((c) => c.name) || [''])],
    [companyList]
  );
  const flag = [
    { label: t('like'), value: '1' },
    { label: t('dislike'), value: '-1' },
  ];

  const handleConfirm = useCallback(async () => {
    const finalData: IFewShot = fewShotData
      ? {
          ...fewShotData,
          ...methods.getValues(),
        }
      : (methods.getValues() as IFewShot);

    setIsLoading(true);
    try {
      await mutateFewShot({
        data: finalData,
        company: methods.getValues().company,
      });
      const message = finalData.id
        ? t('fewShot.fewShotHasBeenUpdated')
        : t('fewShot.fewShotHasBeenCreated');
      showSnackbar(message, 'success', 3);
      params.id
        ? setFormState(viewStates.view)
        : navigate(RoutesURL.SETTINGS_FEW_SHOT);
    } catch {
      showSnackbar(t('errors.fewShotCreateFailed'), 'error', 3);
    } finally {
      setIsLoading(false);
    }
  }, [fewShotData, methods, params.id, navigate, mutateFewShot, t]);

  const [{ mutateAsync: mutateDeleteQuestion }] = useAtom(useDeleteMutation);

  const handleDelete = useCallback(async () => {
    setConfirmDialogData({ open: false });
    if (!params.id) return;
    try {
      await mutateDeleteQuestion({
        id: params.id,
        company: fewShotData?.company,
      });
      setFewShotId(null);
      showSnackbar(t('fewShot.fewShotHasBeenDeleted'), 'success', 3);
      navigate(RoutesURL.SETTINGS_FEW_SHOT);
    } catch {
      setFewShotId(Number(params.id));
      showSnackbar(t('fewShot.fewShotHasDeleteFailed'), 'error', 3);
    }
  }, [
    setConfirmDialogData,
    params.id,
    mutateDeleteQuestion,
    fewShotData?.company,
    setFewShotId,
    t,
    navigate,
  ]);

  const openConfirmDelete = () => {
    setConfirmDialogData({
      open: true,
      title: t('fewShot.deleteTitle'),
      contentText: t('fewShot.deleteMessage'),
      confirmText: t('delete'),
      handleConfirm: handleDelete,
      handleCancel: () => {
        setConfirmDialogData({
          open: false,
        });
      },
    });
  };

  const handleCancel = () => {
    setFormState(viewStates.view);
  };

  const renderTitle = () => {
    switch (formState) {
      case viewStates.view:
      case viewStates.edit:
        return t('fewShot.detailTitle');
      case viewStates.add:
        return t('fewShot.addBtnLabel');
      default:
        return '';
    }
  };

  useEffect(() => {
    params.id && setFewShotId(Number(params.id));
    if (location.state?.isView) {
      setFormState(viewStates.view);
      return;
    }
    if (params.id) {
      setFormState(viewStates.edit);
    } else {
      setFormState(viewStates.add);
      setFewShotId(null);
    }
  }, [params.id, location.state?.isView, setFewShotId]);

  useEffect(() => {
    () => {
      setFewShotId(null);
    };
  }, []);

  return (
    <div className={styles.adminMain}>
      <div className={styles.titleWithBackButtonLayout}>
        <button
          type='button'
          className={styles.backButton}
          onClick={() => {
            setFewShotId(null);
            navigate(-1);
          }}
          aria-label={t('back')}
        >
          <IconArrowRight
            style={{ transform: 'rotate(180deg)' }}
            fill='var(--gray-600)'
            width='24'
            height='24'
          />
        </button>
        <h1 className={styles.pageTitle}>
          <span className={styles.truncate}>{renderTitle()}</span>
        </h1>
      </div>
      <div className={styles.content}>
        {formState === viewStates.view ? (
          <FormView data={fewShotData} />
        ) : (
          <>
            <div className={styles.form}>
              <BaseInput
                {...methods}
                name='input'
                rows={5}
                maxLength={50}
                label={t('Input')}
                defaultValue={fewShotData?.input}
                placeholder={t('fewShot.pleaseEnterQuestion')}
                rules={{
                  required: { value: true, message: t('errors.required') },
                }}
              />
              <BaseInput
                {...methods}
                name='output'
                rows={5}
                maxLength={50}
                label={t('Output')}
                defaultValue={fewShotData?.output}
                placeholder={t('fewShot.pleaseEnterResult')}
                rules={{
                  required: { value: true, message: t('errors.required') },
                }}
              />
              <BaseInput
                {...methods}
                name='law_info'
                maxLength={50}
                rows={4}
                label={t('Law_info')}
                defaultValue={fewShotData?.law_info}
                placeholder={t('fewShot.pleaseEnterLawInfo')}
              />
              <BaseInput
                {...methods}
                name='law_class'
                maxLength={50}
                rows={4}
                label={t('Law_class')}
                defaultValue={fewShotData?.law_class}
                placeholder={t('fewShot.pleaseEnterLawClass')}
              />
            </div>

            <div className={styles.form}>
              <BaseSelect
                {...methods}
                data={companyOptions}
                name='company'
                label={t('company')}
                defaultValue={fewShotData?.company ?? company}
                placeholder={t('select')}
                rules={{
                  required: { value: true, message: t('errors.required') },
                }}
              />
              <BaseInput
                {...methods}
                name='node_key'
                maxLength={50}
                label={t('Node_key')}
                defaultValue={fewShotData?.node_key}
                placeholder={t('fewShot.pleaseEnterNodeKey')}
              />

              <BaseRadioGroup
                {...methods}
                name='flag'
                label={t('Flag')}
                options={flag}
                defaultValue={
                  fewShotData?.flag ? fewShotData?.flag?.toString() : '좋아요'
                }
                rules={{
                  required: { value: true, message: t('errors.required') },
                }}
              />
            </div>
          </>
        )}

        {formState === viewStates.add ? (
          <div className={styles.btnGroup}>
            <div className={styles.primaryButton}>
              <BaseButton
                className={styles.button}
                onClick={methods.handleSubmit(handleConfirm)}
                disabled={isLoading || !methods.formState.isValid}
              >
                {isLoading ? (
                  <CircularProgress color='inherit' size={20} />
                ) : (
                  t('submit')
                )}
              </BaseButton>
            </div>
          </div>
        ) : formState === viewStates.edit ? (
          <div className={styles.btnGroup}>
            <div className={styles.secondaryButton}>
              <BaseButton
                buttonType='outlined'
                className={styles.button}
                onClick={handleCancel}
                disabled={isLoading}
              >
                {t('cancel')}
              </BaseButton>
            </div>
            <div className={styles.primaryButton}>
              <BaseButton
                className={styles.button}
                onClick={methods.handleSubmit(handleConfirm)}
                disabled={isLoading || !methods.formState.isValid}
              >
                {isLoading ? (
                  <CircularProgress color='inherit' size={20} />
                ) : (
                  t('save')
                )}
              </BaseButton>
            </div>
          </div>
        ) : (
          <div className='flexBetween'>
            <BaseButton buttonType='redLinked' onClick={openConfirmDelete}>
              <span>{t('delete')}</span>
            </BaseButton>
            <div className={styles.secondaryButton}>
              <BaseButton
                buttonType='outlined'
                className={styles.button}
                onClick={() => setFormState(viewStates.edit)}
              >
                {t('edit')}
              </BaseButton>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
