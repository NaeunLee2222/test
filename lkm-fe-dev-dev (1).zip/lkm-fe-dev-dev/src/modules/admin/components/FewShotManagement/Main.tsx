import { useTranslation } from 'react-i18next';
import styles from '../../styles/AdminMain.module.scss';
import { FormSearch } from './FormSearch';
import { Table } from './Table';

export const FewShotMain = () => {
  const { t } = useTranslation('admin');

  return (
    <div className={styles.adminMain} data-testid='few-shot-main'>
      <h1 className={styles.pageTitle}>{t('fewShot.title')}</h1>
      <div className={styles.content} data-testid='content-container'>
        <FormSearch />
        <Table />
      </div>
    </div>
  );
};
