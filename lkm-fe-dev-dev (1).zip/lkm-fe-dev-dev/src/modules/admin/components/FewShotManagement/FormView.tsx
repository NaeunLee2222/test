import { useTranslation } from 'react-i18next';
import cn from 'classnames';
import dayjs from 'dayjs';
import BaseDetailsText from '../Form/DetailsText/BaseDetailsText';
import detailsTextStyles from '../Form/DetailsText/DetailsText.module.scss';
import adminMainStyles from '../../styles/AdminMain.module.scss';
import styles from './FewShot.module.scss';

export const FormView = ({ data }: any) => {
  const { t } = useTranslation('admin');

  return (
    <div className={styles.formView}>
      <div className={adminMainStyles.form}>
        <div className={styles.group}>
          <BaseDetailsText
            label={t('Update_dt')}
            content={dayjs(data?.update_dt).format('YYYY-MM-DD, HH:mm:ss')}
          />
          <BaseDetailsText label={t('Input')} content={data?.input} />
          <BaseDetailsText label={t('Output')} content={data?.output || ''} />
          <BaseDetailsText
            label={t('Law_info')}
            content={data?.law_info || '-'}
          />
          <BaseDetailsText
            label={t('Law_class')}
            content={data?.law_class || '-'}
          />
        </div>
      </div>
      <div className={adminMainStyles.form}>
        <div
          className={cn(
            styles.group,
            styles.twoCols,
            detailsTextStyles.twoCols
          )}
        >
          <div style={{ gridColumn: '1 / span 2' }}>
            <BaseDetailsText
              label={t('company')}
              content={(data?.company || '').toUpperCase()}
            />
          </div>
          <BaseDetailsText
            label={t('Node_key')}
            propsClassName={detailsTextStyles.leftTop}
            content={data?.node_key || ''}
          />
          <BaseDetailsText
            label={t('Feedback_id')}
            content={data?.feedback_id || '-'}
            propsClassName={detailsTextStyles.rightTop}
          />
          <BaseDetailsText
            label={t('Flag')}
            content=''
            contentStyle={{ display: 'flex', gap: '8px' }}
            propsClassName={detailsTextStyles.leftBottom}
            extraContent={
              <div>
                {data?.flag === 1 ? (
                  <div className={cn(styles.like, styles.badge)}>
                    {t('like')}
                  </div>
                ) : (
                  <div className={cn(styles.dislike, styles.badge)}>
                    {t('dislike')}
                  </div>
                )}
              </div>
            }
          />
          <BaseDetailsText
            label={t('Status')}
            content={data?.status}
            propsClassName={detailsTextStyles.rightBottom}
          />
        </div>
      </div>
    </div>
  );
};
