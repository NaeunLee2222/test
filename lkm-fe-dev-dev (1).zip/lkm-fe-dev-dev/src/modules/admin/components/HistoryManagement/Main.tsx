import { ChatBubbles } from '@/modules/chat/components/ChatContent/ChatBubbles';
import stylesChat from '@/modules/chat/components/ChatMain/ChatMain.module.scss';
import { useChatDataHandler } from '@/modules/chat/hooks/chatDataHandler';
import { chatDataAtom, currentMessagesAtom } from '@/modules/chat/jotai/chat';
import { useMainContext } from '@/modules/core/contexts/ContextProvider';
import { layoutDataAtom } from '@/modules/core/jotai/layout';
import { screenLoaderDataAtom } from '@/modules/core/jotai/loader';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import cn from 'classnames';
import dayjs from 'dayjs';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import styles from '../../styles/AdminMain.module.scss';
import { FormSearch } from './FormSearch';
import { HistoryTable } from './Table';

export const HistoryMain = () => {
  const { t } = useTranslation('admin');
  const [searchParams, setSearchParams] = useSearchParams();
  const currentHistoryIdRef = useRef<number>(-1);
  const [currentHistoryId, setCurrentHistoryId] = useState(-1);

  const [, setScreenLoaderAtom] = useAtom(screenLoaderDataAtom);
  const [, setLayoutData] = useAtom(layoutDataAtom);
  const { isSetChatData } = useChatDataHandler();
  const { setChatDataByHistoryCallback } = useMainContext();
  const messagesData = useAtomValue(chatDataAtom);

  const [selectedDate, setSelectedDate] = useState<[dayjs.Dayjs, dayjs.Dayjs]>([
    dayjs().subtract(6, 'day'),
    dayjs(),
  ]);
  const [selectedCompany, setSelectedCompany] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedSearch, setSelectedSearch] = useState('');

  useEffect(() => {
    const paramHistoryId = searchParams.get('historyId')
      ? Number(searchParams.get('historyId'))
      : -1;

    if (currentHistoryIdRef.current !== paramHistoryId) {
      setChatDataByHistoryCallback(paramHistoryId).then(() => {
        setLayoutData({ type: 'master' });
      });
    }
    if (paramHistoryId === -1) {
      setLayoutData({ type: 'master' });
    }
    setCurrentHistoryId(paramHistoryId);
    currentHistoryIdRef.current = paramHistoryId;
  }, [searchParams]);

  const handleClickRowAction = (row: any) => {
    if (row?.id) {
      setSearchParams(
        `?historyId=${row.id}&company=${row.company}&historyType=${row.history_type}`
      );
    }
  };

  // 날짜 변경 핸들러
  const handleDateChange = (dates: [dayjs.Dayjs, dayjs.Dayjs]) => {
    setSelectedDate(dates); // 날짜 사용 예시
  };

  const handleCompanyChange = (company: string) => {
    setSelectedCompany(company);
  };
  const handleTypeChange = (type: string) => {
    setSelectedType(type);
  };
  const handleSearchChange = (search: string) => {
    setSelectedSearch(search);
  };

  const handleClickBack = () => {
    setSearchParams('');
    setCurrentHistoryId(-1);
    setLayoutData({ type: 'master' });
  };

  const isMainScreen = useMemo(
    () => currentHistoryId === -1,
    [currentHistoryId]
  );

  const setCurrentMessagesAtom = useSetAtom(currentMessagesAtom);

  useEffect(() => {
    setScreenLoaderAtom({
      key: 'admin.history',
      loading: isSetChatData,
    });
  }, [isSetChatData, setScreenLoaderAtom]);

  useEffect(() => {
    setCurrentMessagesAtom([]);
    return () => {
      setLayoutData({ type: 'master' });
      setScreenLoaderAtom({
        key: 'admin.history',
        loading: false,
      });
    };
  }, []);

  return (
    <div className={styles.adminMain}>
      {isMainScreen ? (
        <h1 className={styles.pageTitle}>{t('chatHistory')}</h1>
      ) : (
        <h1
          className={styles.pageTitle}
          style={{
            padding: '16px 24px 16px',
          }}
        >
          <ArrowBackIcon
            className={styles.iconBack}
            onClick={handleClickBack}
            data-testid='back-button'
          />
          <span
            className={styles.chatHistoryTitle}
            style={{
              fontSize: '16px',
              fontWeight: '500',
              marginTop: '3px',
            }}
          >
            {messagesData?.title ?? ''}
          </span>
        </h1>
      )}
      <div className={styles.content}>
        {isMainScreen ? (
          <div
            style={{
              width: '100%',
              display: 'contents',
            }}
          >
            <FormSearch
              initialCompany={selectedCompany}
              initialType={selectedType}
              initialSearch={selectedSearch}
              initialDateRange={selectedDate}
              onDateChange={handleDateChange}
              onCompanyChange={handleCompanyChange}
              onTypeChange={handleTypeChange}
              onSearchChange={handleSearchChange}
            />
            <HistoryTable
              setOpenDialog={() => {}}
              handleClickRowAction={(row) => handleClickRowAction(row)}
            />
          </div>
        ) : (
          <div className={cn(stylesChat.chatMain, styles.chatView)}>
            <ChatBubbles type='view' />
          </div>
        )}
      </div>
    </div>
  );
};
