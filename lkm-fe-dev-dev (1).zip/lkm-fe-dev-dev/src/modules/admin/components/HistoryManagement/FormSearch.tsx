import { RangeDatePicker } from '@/modules/core/components/common/DatePicker/RangeDatePicker';
import { useCompanyList, useUserMe } from '@/modules/core/hooks';
import { getKstTimestampBySelectedDate } from '@/utils';
import dayjs from 'dayjs';
import localeData from 'dayjs/plugin/localeData';
import weekday from 'dayjs/plugin/weekday';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { getData, paginationSettingAtom } from '../../hooks/useChatHistories';
import styles from '../../styles/AdminMain.module.scss';
import SearchInput from '../Search/Input';
import SearchSelect from '../Search/Select';

dayjs.extend(weekday);
dayjs.extend(localeData);

// props 타입 정의
interface FormSearchProps {
  initialCompany?: string;
  initialType?: string;
  initialSearch?: string;
  initialDateRange?: [dayjs.Dayjs, dayjs.Dayjs];
  onDateChange?: (dates: [dayjs.Dayjs, dayjs.Dayjs]) => void;
  onCompanyChange?: (company: string) => void;
  onTypeChange?: (type: string) => void;
  onSearchChange?: (search: string) => void;
}

// 기본 props 설정
export const FormSearch = ({
  initialCompany = '',
  initialType = '',
  initialSearch = '',
  initialDateRange = [dayjs().subtract(6, 'day'), dayjs()],
  onDateChange,
  onCompanyChange,
  onTypeChange,
  onSearchChange,
}: FormSearchProps = {}) => {
  const [{ data: userData }] = useAtom(useUserMe);
  const isSuperAdmin = userData?.role?.includes('superadmin');

  const { t } = useTranslation('admin');
  const now = dayjs();
  const last7Days = dayjs().subtract(6, 'day');
  const [type, setType] = useState(initialType || '');
  const [search, setSearch] = useState(initialSearch || '');
  const [company, setCompany] = useState(initialCompany || '');
  const [selectedDate, setSelectedDate] = useState<[dayjs.Dayjs, dayjs.Dayjs]>(
    initialDateRange || [dayjs().subtract(6, 'day'), dayjs()]
  );
  const [, setPage] = useAtom(paginationSettingAtom);
  const [{ refetch }] = useAtom(getData);
  const [{ data: companyList }] = useAtom(useCompanyList);

  const companyOptions = useMemo(
    () =>
      companyList?.map((c) => ({
        value: c.name,
        label: c.name,
      })) || [],
    [companyList]
  );

  const handleSearch = ({
    currentDateValue,
    currentTypeValue,
    currentSearchValue,
    currentCompany,
    isEventDriven,
  }: {
    currentDateValue: [dayjs.Dayjs, dayjs.Dayjs];
    currentTypeValue: string;
    currentSearchValue?: string;
    currentCompany: string;
    isEventDriven?: boolean;
  }) => {
    let params = '';
    if (currentSearchValue) {
      params = `&search=${currentSearchValue}`;
    }
    if (currentTypeValue) {
      params = `${params}&historyType=${currentTypeValue}`;
    }
    if (currentCompany) {
      params = `${params}&company=${company}`;
    }

    const dateStr = getKstTimestampBySelectedDate(currentDateValue);
    if (dateStr) {
      params = `${params}&${dateStr}`;
    }
    setPage((prev) => ({ ...prev, page: 0, search: params }));
    if (isEventDriven) refetch();
  };

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      if (onSearchChange) {
        onSearchChange((e.target as HTMLInputElement).value);
      }
      handleSearch({
        currentDateValue: selectedDate,
        currentTypeValue: type,
        currentSearchValue: (e.target as HTMLInputElement).value,
        currentCompany: company,
        isEventDriven: true,
      });
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleChangeDate = (date: any) => {
    if (date && _.size(date) > 1) {
      const startDate = date[0] || '';
      const endDate = date[1] || '';
      const newDates: [dayjs.Dayjs, dayjs.Dayjs] = [
        dayjs(startDate),
        dayjs(endDate),
      ];

      setSelectedDate(newDates);

      // 부모 컴포넌트에 날짜 변경 알림
      if (onDateChange) {
        onDateChange(newDates);
      }

      handleSearch({
        currentDateValue: newDates,
        currentTypeValue: type,
        currentSearchValue: search,
        currentCompany: company,
        isEventDriven: true,
      });
    }
  };

  const handleSelectCompany = (value: string) => {
    setCompany(value);
    if (onCompanyChange) {
      onCompanyChange(value);
    }
    setPage((prev) => ({ ...prev, page: 0, company: value }));
  };

  const handleSelectType = (value: string) => {
    setType(value);
    if (onTypeChange) {
      onTypeChange(value);
    }
    handleSearch({
      currentDateValue: selectedDate,
      currentTypeValue: value,
      currentSearchValue: search,
      currentCompany: company,
      isEventDriven: true,
    });
  };

  useEffect(() => {
    handleSearch({
      currentDateValue: initialDateRange || [last7Days, now],
      currentTypeValue: initialType || '',
      currentSearchValue: initialSearch || '',
      currentCompany: initialCompany || company,
    });
  }, [company]);

  useEffect(() => {
    if (!initialCompany && companyList) {
      const defaultCompany = companyList?.find(
        (c) => c.name === userData?.company
      );
      setCompany(defaultCompany?.name || '');
      setPage((prev) => ({
        ...prev,
        page: 0,
        company: defaultCompany?.name || '',
      }));
    }
  }, [companyList, setPage, initialCompany]);

  const typeList = [
    { value: '', label: t('all') },
    {
      label: t('advisory'),
      value: 'advisory',
    },
    {
      label: t('dashboard.report'),
      value: 'report',
    },
  ];

  return (
    <div className={styles.formSearch}>
      <div className={styles.inputDate}>
        <div className={styles.label}>{`${t('date')}:`}</div>
        <RangeDatePicker
          className={styles.dateRangePicker}
          onConfirm={(date: any) => handleChangeDate(date)}
          defaultValue={selectedDate}
        />
      </div>
      {isSuperAdmin && (
        <div className={styles.selectField}>
          <div className={styles.label}>{`${t('company')}:`}</div>
          <SearchSelect
            options={companyOptions}
            // defaultValue={company}
            value={company}
            handleChange={handleSelectCompany}
          />
        </div>
      )}
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('type')}:`}</div>
        <SearchSelect
          options={typeList}
          value={type}
          handleChange={handleSelectType}
        />
      </div>
      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('searchByNameOrContent')}
          search={search}
        />
      </div>
    </div>
  );
};
