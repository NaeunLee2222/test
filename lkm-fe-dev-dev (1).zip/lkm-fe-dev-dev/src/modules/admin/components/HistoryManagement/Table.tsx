import { Dispatch, SetStateAction, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { formatDateToKst } from '../../../../utils/convertString';
import {
  downloadExcelMutation,
  fieldSettingAtom,
  getData,
  paginationSettingAtom,
} from '../../hooks/useChatHistories';
import { BaseTable } from '../Table/BaseTable';

interface IFeedbackTable {
  setOpenDialog: Dispatch<SetStateAction<boolean>>;
  handleClickRowAction?: Dispatch<SetStateAction<object>>;
}

export const HistoryTable = ({
  setOpenDialog,
  handleClickRowAction,
}: IFeedbackTable) => {
  const { t } = useTranslation('admin');

  const columns = useMemo(
    () => [
      {
        name: 'create_dt',
        label: t('date'),
        width: '15%',
        sortable: true,
        format: (value: string) => formatDateToKst(value, 'YYYY-MM-DD'),
      },
      {
        name: 'history_type',
        label: t('type'),
        width: '10%',
        format: (value: string) => {
          if (value === 'advisory') {
            return t('advisory');
          }
          if (value === 'report') {
            return t('dashboard.report');
          }
          return '';
        },
      },
      { name: 'user_name', label: t('name'), width: '10%' },
      { name: 'title', label: t('chatting'), width: '50%' },
    ],
    [t]
  );

  return (
    <BaseTable
      setOpenDialog={setOpenDialog}
      handleClickRowAction={handleClickRowAction}
      columns={columns}
      paginationSettingAtom={paginationSettingAtom}
      fieldSettingAtom={fieldSettingAtom}
      getData={getData}
      downloadExcelMutation={downloadExcelMutation}
      hasCheckbox
    />
  );
};
