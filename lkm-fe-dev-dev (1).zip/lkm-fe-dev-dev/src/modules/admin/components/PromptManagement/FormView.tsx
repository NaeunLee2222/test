import { formatDateToKst } from '@/utils';
import { useTranslation } from 'react-i18next';
import BaseDetailsText from '../Form/DetailsText/BaseDetailsText';
import styles from './Dialog.module.scss';

export const FormView = ({ data }: any) => {
  const { t } = useTranslation('admin');

  return (
    <div className={styles.baseDialog}>
      <div className={styles.group}>
        <BaseDetailsText label={t('Key')} content={data?.key} />
        <BaseDetailsText label={t('Value')} content={data?.value || ''} />
        <BaseDetailsText
          label={t('Description')}
          content={data?.description || ''}
        />
        <BaseDetailsText
          label={t('Creator')}
          content={data?.creator_id || ''}
        />
        <BaseDetailsText
          label={t('Create_dt')}
          content={
            data?.create_dt ? formatDateToKst(data.create_dt, 'YYYY-MM-DD') : ''
          }
        />
      </div>
    </div>
  );
};
