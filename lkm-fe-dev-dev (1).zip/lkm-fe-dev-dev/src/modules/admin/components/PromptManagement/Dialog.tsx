import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { showSnackbar } from '@/utils/snackbarUtil';
import { useAtom } from 'jotai';
import { useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import {
  promptSettingAtom,
  useDeleteMutation,
  usePromptMutation,
} from '../../hooks/usePromptSettings';
import styles from '../../styles/AdminMain.module.scss';
import type { IPrompt } from '../../types/prompt';
import type { IDialog } from '../../types/user';
import BaseInput from '../Form/Inputs/BaseInput';
import { FormView } from './FormView';

interface IProps {
  dialogState: IDialog;
  setDialogState: ({ open, type }: IDialog) => void;
}

const viewStates = {
  view: 'view',
  add: 'add',
};

export const DialogForm = ({ dialogState, setDialogState }: IProps) => {
  const { t } = useTranslation('admin');
  const methods = useForm();
  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [promptSettingData, setPromptSettingData] = useAtom(promptSettingAtom);
  const [{ mutate: mutatePrompt }] = useAtom(usePromptMutation);

  const handleClose = useCallback(() => {
    setDialogState({ ...dialogState, open: false });
    methods.reset();
  }, [setDialogState, methods, dialogState]);

  const handleConfirm = useCallback(() => {
    const finalData = {
      ...promptSettingData,
      ...methods.getValues(),
    };
    setPromptSettingData(finalData as IPrompt);

    mutatePrompt({
      callback: (
        isSuccess: boolean,
        response: {
          message?: string;
        }
      ) => {
        const message = isSuccess
          ? finalData.id
            ? t('prompt.promptHasBeenUpdated')
            : t('prompt.promptHasBeenCreated')
          : response?.message || '';
        showSnackbar(message, isSuccess ? 'success' : 'error', 3);
      },
    });
    handleClose();
  }, [
    promptSettingData,
    methods,
    setPromptSettingData,
    mutatePrompt,
    handleClose,
    t,
  ]);

  const [{ mutate: mutateDeleteQuestion }] = useAtom(useDeleteMutation);

  const handleDelete = useCallback(() => {
    setConfirmDialogData({ open: false });
    if (!promptSettingData?.id) return;
    mutateDeleteQuestion({
      id: promptSettingData.id,
      callback: (isSuccess: boolean, response: { message?: string }) => {
        const message = isSuccess
          ? t('prompt.promptHasBeenDeleted')
          : response?.message || '';
        showSnackbar(message, isSuccess ? 'success' : 'error', 3);
      },
    });
    handleClose();
  }, [
    setConfirmDialogData,
    promptSettingData.id,
    mutateDeleteQuestion,
    handleClose,
    t,
  ]);

  const openConfirmDelete = () => {
    setConfirmDialogData({
      open: true,
      title: t('prompt.deleteTitle'),
      contentText: t('prompt.deleteMessage'),
      confirmText: t('delete'),
      handleConfirm: handleDelete,
      handleCancel: () => {
        setConfirmDialogData({
          open: false,
        });
      },
    });
  };

  const renderTitle = () => {
    switch (dialogState.type) {
      case viewStates.view:
      case viewStates.add:
        return t('Prompt');
      default:
        return '';
    }
  };

  const renderButtons = () => {
    switch (dialogState.type) {
      case viewStates.view:
        return (
          <div className='flexBetween'>
            <BaseButton buttonType='redLinked' onClick={openConfirmDelete}>
              <span>{t('delete')}</span>
            </BaseButton>
          </div>
        );
      case viewStates.add:
        return (
          <div className='flexBetween'>
            <span />
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={styles.btnStyles}
                onClick={handleClose}
              >
                <span>{t('cancel')}</span>
              </BaseButton>
              <BaseButton
                autoFocus
                className={styles.btnStyles}
                onClick={methods.handleSubmit(handleConfirm)}
                color='primary'
                disabled={!methods.formState.isValid}
              >
                <span>{t('registration')}</span>
              </BaseButton>
            </span>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <BaseDialog
        open={dialogState.open}
        title={renderTitle()}
        handleClose={handleClose}
        sx={{
          '.MuiPaper-root': {
            maxWidth: '600px',
          },
        }}
        contentChildren={
          <>
            {dialogState.type === viewStates.view ? (
              <FormView data={promptSettingData} />
            ) : (
              <div
                className='flexColumn'
                style={{
                  gap: '16px',
                }}
              >
                <BaseInput
                  {...methods}
                  name='key'
                  maxLength={50}
                  label={t('Key')}
                  defaultValue={promptSettingData?.key}
                  placeholder={t('prompt.pleaseEnterKey')}
                  rules={{
                    required: { value: true, message: t('errors.required') },
                  }}
                />

                <BaseInput
                  {...methods}
                  name='value'
                  rows={8}
                  maxLength={50}
                  label={t('Value')}
                  defaultValue={promptSettingData?.value}
                  placeholder={t('prompt.pleaseEnterValue')}
                  rules={{
                    required: { value: true, message: t('errors.required') },
                  }}
                />

                <BaseInput
                  {...methods}
                  name='description'
                  maxLength={50}
                  label={t('Description')}
                  defaultValue={promptSettingData?.description}
                  placeholder={t('prompt.pleaseEnterDescription')}
                />
              </div>
            )}
          </>
        }
        actionsChildren={renderButtons()}
      />
    </>
  );
};
