import { formatDateToKst } from '@/utils';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
  listPaginationAtom,
  promptSettingAtom,
  usePromptSettings,
} from '../../hooks/usePromptSettings';
import type { IDialog } from '../../types/user';
import { BaseTable } from '../Table/BaseTable';

interface IProps {
  setOpenDialog: ({ open, type }: IDialog) => void;
}

export const Table = ({ setOpenDialog }: IProps) => {
  const { t } = useTranslation('admin');

  const columns = useMemo(
    () => [
      {
        name: 'key',
        label: t('Key'),
        width: '10%',
      },
      {
        name: 'value',
        label: t('Value'),
        width: '18%',
      },
      {
        name: 'description',
        label: t('Description'),
        width: '40%',
      },
      { name: 'creator_id', label: t('Creator'), width: '10%' },
      {
        name: 'create_dt',
        label: t('Create_dt'),
        width: '12%',
        format: (value: string) =>
          formatDateToKst(value, 'YYYY-MM-DD, HH:mm:ss'),
        sortable: true,
      },
    ],
    [t]
  );

  return (
    <BaseTable
      setOpenDynamicDialog={setOpenDialog}
      columns={columns}
      paginationSettingAtom={listPaginationAtom}
      fieldSettingAtom={promptSettingAtom}
      getData={usePromptSettings}
      hasAddBtn
      addBtnLabel={t('prompt.addBtnLabel')}
      popupConfirmTitle={t('prompt.title')}
      popupConfirmContent={t('prompt.confirmDeleteMessage')}
    />
  );
};
