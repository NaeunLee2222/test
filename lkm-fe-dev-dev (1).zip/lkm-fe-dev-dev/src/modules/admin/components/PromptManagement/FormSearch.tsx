import { RangeDatePicker } from '@/modules/core/components/common/DatePicker/RangeDatePicker';
import { getKstTimestampBySelectedDate } from '@/utils';
import dayjs from 'dayjs';
import localeData from 'dayjs/plugin/localeData';
import weekday from 'dayjs/plugin/weekday';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import {
  listPaginationAtom,
  usePromptSettings,
} from '../../hooks/usePromptSettings';
import styles from '../../styles/AdminMain.module.scss';
import SearchInput from '../Search/Input';

dayjs.extend(weekday);
dayjs.extend(localeData);

export const FormSearch = () => {
  const { t } = useTranslation('admin');
  const [searchParams] = useSearchParams();
  const now = dayjs();
  const last7Days = dayjs().subtract(6, 'day');
  const [selectedDate, setSelectedDate] = useState([last7Days, now]);
  const [search, setSearch] = useState('');
  const [, setPage] = useAtom(listPaginationAtom);
  const [{ refetch }] = useAtom(usePromptSettings);

  const handleSearch = ({
    currentDateValue,
    currentSearchValue,
    isEventDriven,
  }: {
    currentDateValue: dayjs.Dayjs[];
    currentSearchValue?: string;
    isEventDriven?: boolean;
  }) => {
    let params = '';
    if (currentSearchValue) {
      params = `&search=${currentSearchValue}`;
    }
    const dateStr = getKstTimestampBySelectedDate(currentDateValue);
    if (dateStr) {
      params = `${params}&${dateStr}`;
    }

    setPage((prev) => ({ ...prev, page: 0, search: params }));
    if (isEventDriven) refetch();
  };

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch({
        currentDateValue: selectedDate,
        currentSearchValue: (e.target as HTMLInputElement).value,
        isEventDriven: true,
      });
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleChangeDate = (date: any) => {
    if (date && _.size(date) > 1) {
      const startDate = date[0] || '';
      const endDate = date[1] || '';
      setSelectedDate([dayjs(startDate), dayjs(endDate)]);
      handleSearch({
        currentDateValue: [dayjs(startDate), dayjs(endDate)],
        currentSearchValue: search,
        isEventDriven: true,
      });
    }
  };

  useEffect(() => {
    const startDateParam = searchParams.get('startDate');
    const endDateParam = searchParams.get('endDate');
    const formattedDate = [dayjs(startDateParam), dayjs(endDateParam)];

    if (startDateParam && endDateParam) {
      setSelectedDate(formattedDate);
    }

    const isValidDate = formattedDate.every((date) => date.isValid());

    handleSearch({
      currentDateValue: isValidDate ? formattedDate : [last7Days, now],
    });
  }, [searchParams]);

  return (
    <div className={styles.formSearch}>
      <div className={styles.inputDate}>
        <div className={styles.label}>{`${t('date')}:`}</div>
        <RangeDatePicker
          className={styles.dateRangePicker}
          onConfirm={(date: any) => handleChangeDate(date)}
          defaultValue={selectedDate}
        />
      </div>
      <div className={styles.inputText} style={{ width: '70%' }}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('Value')}
          search={search}
        />
      </div>
    </div>
  );
};
