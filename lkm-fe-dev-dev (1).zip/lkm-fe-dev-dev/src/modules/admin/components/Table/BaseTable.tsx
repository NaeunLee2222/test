import BtnTableIcon from '@/assets/basic-icons/icon-btn-table.svg?react';
import DotDivider from '@/assets/basic-icons/icon-dot-divider.svg?react';
import IconDownload from '@/assets/basic-icons/icon-download.svg?react';
import MultipleDeleteIcon from '@/assets/basic-icons/icon-multiple-delete.svg?react';
import SortIcon from '@/assets/direction-icons/icon-sort.svg?react';
import styles from '@/modules/admin/components/Table/Table.module.scss';
import { useToolSettings } from '@/modules/admin/hooks/useToolSettings';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { EButtonType } from '@/types/common';
import { showSnackbar } from '@/utils/snackbarUtil';
import {
  Box,
  IconButton,
  Skeleton,
  styled,
  Table,
  TableBody,
  TableCell,
  tableCellClasses,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  Tooltip,
} from '@mui/material';
import Button from '@mui/material/Button';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Popover from '@mui/material/Popover';
import { atom, Atom, PrimitiveAtom, useAtom, useSetAtom } from 'jotai';
import { AtomWithQueryResult } from 'jotai-tanstack-query';
import _ from 'lodash';
import { ChangeEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { IDialog } from '../../types/user';
import BaseCheckBox from '../Form/Checkboxes/BaseCheckBox';
import CustomPagination from './CustomPagination';

interface Column {
  name: string;
  label: string;
  width?: number | string;
  align?: 'right';
  sortable?: boolean;
  stable?: boolean;
  isDefault?: boolean;
  format?: (value: any, row: any) => string | React.ReactElement;
  hasTooltip?: boolean;
  link?: string;
  contentAlign?: string;
}

interface IProps {
  setOpenDialog?: (open: boolean) => void;
  setOpenDynamicDialog?: ({ open, type }: IDialog) => void;
  handleClickRowAction?: (row: object) => void;
  columns: Column[];
  paginationSettingAtom: PrimitiveAtom<any>;
  fieldSettingAtom?: PrimitiveAtom<any> | null;
  getData: Atom<AtomWithQueryResult<any, Error>>;
  downloadExcelMutation?: Atom<any>;
  showTotalRecords?: boolean;
  hasCheckbox?: boolean;
  handleDeleteMultiple?: Atom<any>;
  keyField?: string;
  hasAddBtn?: boolean;
  customClickAdd?: () => void;
  addBtnLabel?: string;
  customColumnDisplay?: boolean;
  popupConfirmTitle?: string;
  popupConfirmContent?: string;
  rowCursor?: string;
  unit?: string;
  deleteToastContent?: string;
  showCountStatus?: boolean;
  showSelected?: boolean;
  showDesc?: boolean;
  showSelectPagination?: boolean;
}

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: '#F5F5F5',
    fontSize: '14px',
    fontWeight: 500,
    padding: '8px',
    paddingRight: '0',
    borderColor: 'var(--gray-100)',
    height: '36px !important',
    lineHeight: '19px',
    boxSizing: 'border-box',
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: '14px',
    padding: '12px 8px',
    height: '40px !important',
    lineHeight: '19px',
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '& td': {
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    fontSize: '14px',
    padding: '12px 0 12px 8px',
    borderBottom: '1px solid var(--gray-100)',
    color: 'var(--gray-900)',
  },
}));

const EMPTY_COUNT = 0;

export const BaseTable = ({
  setOpenDialog,
  setOpenDynamicDialog,
  handleClickRowAction,
  columns,
  paginationSettingAtom,
  fieldSettingAtom = null,
  getData,
  downloadExcelMutation,
  showTotalRecords = true,
  hasCheckbox = false,
  hasAddBtn = false,
  customClickAdd,
  handleDeleteMultiple,
  keyField = 'id',
  addBtnLabel = 'add',
  customColumnDisplay = false,
  popupConfirmTitle,
  popupConfirmContent,
  rowCursor = 'pointer',
  unit = '',
  deleteToastContent = '',
  showCountStatus = false,
  showSelected = true,
  showDesc = true,
  showSelectPagination = true,
}: IProps) => {
  const { t } = useTranslation('admin');

  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [{ page, rowsPerPage }, setPage] = useAtom(paginationSettingAtom);
  const [{ refetch: getTools }] = useAtom(useToolSettings);
  const [{ data, isLoading, isFetching }] = useAtom(getData);

  const [mutateDownloadExcel] = downloadExcelMutation
    ? useAtom(downloadExcelMutation)
    : [];

  const [mutateDeleteMultiple] = handleDeleteMultiple
    ? useAtom(handleDeleteMultiple)
    : [];

  const [orderBy, setOrderBy] = useState<string>('');
  const [orderDirection, setOrderDirection] = useState<'asc' | 'desc'>('asc');
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [total, setTotal] = useState(0);
  const [isAllSelected, setIsAllSelected] = useState(false);
  // State of popover select field
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [checkedField, setCheckedField] = useState(
    columns.filter((i) => i.name && i.isDefault).map((i) => i.name) || []
  );

  const handleClickPopover = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClosePopover = () => {
    setAnchorEl(null);
  };

  const openPopover = Boolean(anchorEl);
  const idPopover = openPopover ? 'simple-popover' : undefined;

  const handleTogglePopover = (value: string) => () => {
    const currentIndex = checkedField.indexOf(value);
    const newChecked = [...checkedField];
    if (currentIndex === -1) {
      newChecked.push(value);
    } else {
      newChecked.splice(currentIndex, 1);
    }
    setCheckedField(newChecked);
  };

  const rows = useMemo(() => data?.data_list?.flat() ?? [], [data?.data_list]);

  const handleChangePage = useCallback(
    (event: unknown, newPage: number) => {
      setPage((prev: any) => ({ ...prev, page: newPage - 1 }));
    },
    [setPage]
  );

  const handleChangeRowsPerPage = useCallback(
    (value: string | number) => {
      const newRowsPerPage = parseInt(value as string, 10);
      setPage((prev: any) => ({
        ...prev,
        page: 0,
        rowsPerPage: newRowsPerPage,
      }));
    },
    [setPage]
  );

  const setSettingData = useSetAtom(fieldSettingAtom || atom({}));
  const handleClickRow = useCallback(
    (row: any) => {
      fieldSettingAtom && setSettingData(row);
      if (handleClickRowAction) {
        handleClickRowAction(row);
      }
      if (hasAddBtn && setOpenDynamicDialog) {
        setOpenDynamicDialog({ open: true, type: 'view' });
      } else if (setOpenDialog) {
        setOpenDialog(true);
      }
    },
    [
      fieldSettingAtom,
      setSettingData,
      handleClickRowAction,
      hasAddBtn,
      setOpenDynamicDialog,
      setOpenDialog,
    ]
  );

  const handleClickAdd = () => {
    fieldSettingAtom && setSettingData({});
    if (customClickAdd) {
      customClickAdd();
      return;
    }
    setOpenDynamicDialog && setOpenDynamicDialog({ open: true, type: 'add' });
  };

  const handleSort = useCallback(
    (columnName: string) => {
      const isAsc = orderBy === columnName && orderDirection === 'asc';
      const newOrderDirection = isAsc ? 'desc' : 'asc';
      setPage((prev: any) => ({
        ...prev,
        sortBy: `${columnName}_${newOrderDirection}`,
        sortDetail: {
          order: newOrderDirection,
          sort: columnName,
        },
      }));
      setOrderDirection(newOrderDirection);
      setOrderBy(columnName);
    },
    [orderBy, orderDirection, setPage, setOrderDirection, setOrderBy]
  );

  const handleDownloadExcel = useCallback(() => {
    mutateDownloadExcel?.mutate({ selectedRows });
  }, [mutateDownloadExcel, selectedRows]);

  const handleRowCheckboxChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>, rowKeySelected: number) => {
      if (event.target instanceof HTMLInputElement) {
        if (event.target.checked) {
          setSelectedRows([...selectedRows, rowKeySelected]);
        } else {
          setSelectedRows(
            selectedRows.filter((item) => item !== rowKeySelected)
          );
        }
      }
    },
    [selectedRows]
  );

  const handleSelectAllCheckboxChange = () => {
    if (isAllSelected) {
      setSelectedRows([]);
    } else {
      setSelectedRows(rows.map((row: any) => row[keyField]));
    }
    setIsAllSelected(!isAllSelected);
  };

  const handleConfirmDelete = useCallback(() => {
    mutateDeleteMultiple?.mutate({
      selectedRows,
      callback: async (
        isSuccess: boolean,
        response: {
          message?: string;
        }
      ) => {
        try {
          const message = isSuccess
            ? (deleteToastContent ?? t('user.userHasBeenDeleted'))
            : (response?.message ?? '');
          showSnackbar(
            message,
            isSuccess ? 'success' : 'error',
            5,
            {
              vertical: 'bottom',
              horizontal: 'center',
            },
            {
              disableWindowBlurListener: true,
              action: null,
              className: styles.successSnackbar,
            }
          );
          setConfirmDialogData({
            open: false,
          });
          await getTools();
          setSelectedRows([]);
        } catch {
          throw new Error('');
        }
      },
    });
  }, [
    mutateDeleteMultiple,
    selectedRows,
    deleteToastContent,
    t,
    setConfirmDialogData,
    getTools,
  ]);

  const openConfirmDelete = () => {
    setConfirmDialogData({
      open: true,
      title: popupConfirmTitle,
      contentText: popupConfirmContent,
      confirmText: t('userDelete.confirmText'),
      handleConfirm: handleConfirmDelete,
      handleCancel: () => {
        setConfirmDialogData({
          open: false,
        });
      },
      type: EButtonType.DELETE,
    });
  };

  const enableBtnAction =
    _.size(rows) === 0 || (hasCheckbox && selectedRows.length === 0);

  const currentColumns =
    customColumnDisplay && _.size(columns) > 0
      ? columns.filter(
          (item) => checkedField.includes(item.name) || item.name === ''
        )
      : columns;

  const SortIconButton = useCallback(
    () => (
      <span
        style={{
          display: 'flex',
          flexDirection: 'column',
          color: 'var(--gray-500)',
        }}
      >
        <SortIcon />
      </span>
    ),
    []
  );

  const emptyTable = useCallback(
    () => (
      <TableRow>
        <TableCell
          colSpan={
            hasCheckbox ? currentColumns.length + 1 : currentColumns.length
          }
          sx={{
            textAlign: 'center',
          }}
        >
          {t('noData')}
        </TableCell>
      </TableRow>
    ),
    [currentColumns.length, hasCheckbox, t]
  );

  const formatTooltip = (value: any) =>
    value
      .filter((item: any, i: number) => i > 0)
      .map((item: any) => `${item}\n`);

  const renderRows = useCallback(
    () =>
      rows?.length !== 0
        ? rows?.map((row: any, index: number) => (
            <StyledTableRow
              hover
              tabIndex={-1}
              key={`${row.id}-${keyField}-${index}`}
              onClick={() => handleClickRow(row)}
              sx={{
                cursor: `${rowCursor} !important`,
                backgroundColor: selectedRows.includes(row[keyField])
                  ? 'var(--primary-color-100)'
                  : 'var(--white)',
              }}
            >
              {hasCheckbox && (
                <TableCell
                  key='checkbox'
                  padding='checkbox'
                  style={{
                    width: 'fit-content',
                    padding: 0,
                  }}
                >
                  <Box className={styles.checkboxCell}>
                    <Box className={styles.checkboxContainer}>
                      <BaseCheckBox
                        className={styles.baseCheckBox}
                        checked={selectedRows.includes(row[keyField])}
                        onChange={(e: ChangeEvent<HTMLInputElement>) =>
                          handleRowCheckboxChange(e, row[keyField])
                        }
                        onClick={(e: { stopPropagation: () => any }) =>
                          e.stopPropagation()
                        }
                      />
                    </Box>
                  </Box>
                </TableCell>
              )}
              {currentColumns.map((column, rowIndex) => {
                const value = row[column.name];

                const rowContent = column.hasTooltip ? value[0] : value;
                const rowFormattedContent = column.format
                  ? column.format(rowContent, row)
                  : `${rowContent ?? ''}`;

                return (
                  <StyledTableCell
                    key={column.name}
                    align={column.align}
                    width={column.width}
                    sx={{
                      maxWidth: '200px',
                      width: column.width,
                      padding: '10px 0px 10px 12px !important',
                    }}
                  >
                    <Box
                      sx={{
                        borderRight:
                          rowIndex !== currentColumns.length - 1
                            ? '0.5px solid #D9D9D9'
                            : 'none',
                      }}
                      className={styles.rowContentBox}
                    >
                      <div
                        className={styles.rowContent}
                        style={
                          column.contentAlign === 'center'
                            ? { width: '100%' }
                            : {}
                        }
                      >
                        {rowFormattedContent}
                      </div>

                      {column.hasTooltip && value.length > 1 && (
                        <Tooltip
                          disableFocusListener
                          disableTouchListener
                          className={styles.tableTooltip}
                          title={
                            <span
                              style={{
                                whiteSpace: 'pre-line',
                              }}
                            >
                              {formatTooltip(value)}
                            </span>
                          }
                          placement='bottom-start'
                          componentsProps={{
                            tooltip: {
                              className: styles.tableTooltipPopup,
                            },
                          }}
                        >
                          <span>{`+${value.length - 1}`}</span>
                        </Tooltip>
                      )}
                    </Box>
                  </StyledTableCell>
                );
              })}
            </StyledTableRow>
          ))
        : emptyTable(),
    [
      currentColumns,
      emptyTable,
      handleClickRow,
      handleRowCheckboxChange,
      hasCheckbox,
      keyField,
      rowCursor,
      rows,
      selectedRows,
    ]
  );

  useEffect(() => {
    if (!isNaN(data?.total_count)) {
      setTotal(data?.total_count);
    }
  }, [data?.total_count]);

  return (
    <div className={styles.tableContentWrap}>
      {showDesc && (
        <div className={styles.tableDescWrap}>
          <div className={styles.counting}>
            <div className={styles.total}>
              {showTotalRecords && `${t('total')}`}{' '}
              <span
                className={styles.piece}
              >{` ${data?.total_count ?? EMPTY_COUNT} ${unit}`}</span>
            </div>
            {showSelected && (
              <>
                <div className={styles.divider}>
                  <DotDivider />
                </div>
                <div className={styles.selected}>
                  {`${t('select')}`}{' '}
                  <span
                    className={styles.piece}
                  >{` ${selectedRows.length ?? EMPTY_COUNT} ${unit}`}</span>
                </div>
              </>
            )}
          </div>
          <div className={styles.actionGroup}>
            {mutateDownloadExcel && (
              <BaseButton
                buttonType='outlined'
                startIcon={
                  <IconDownload
                    fill={enableBtnAction ? '#a7a7a7' : '#555555'}
                  />
                }
                onClick={() => handleDownloadExcel()}
                disabled={enableBtnAction}
                disableRipple
              >
                {t('downloadExcel')}
              </BaseButton>
            )}
            {hasAddBtn && (
              <Button
                size='small'
                variant='contained'
                className={styles.addBtn}
                onClick={handleClickAdd}
                type='button'
                tabIndex={0}
              >
                {addBtnLabel}
              </Button>
            )}
            {customColumnDisplay && (
              <>
                <Button
                  className={styles.buttonPopover}
                  aria-describedby={idPopover}
                  onClick={handleClickPopover}
                >
                  <BtnTableIcon />
                </Button>
                <Popover
                  id={idPopover}
                  open={openPopover}
                  anchorEl={anchorEl}
                  onClose={handleClosePopover}
                  className='popoverStyle'
                  anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                  }}
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                >
                  <List sx={{ pt: 1 }}>
                    <ListItemText className='header' primary={t('custom')} />
                    <div className='listItem'>
                      {columns
                        .filter((item) => item.name)
                        .map((item) => (
                          <ListItem key={item.name}>
                            <ListItemIcon>
                              <BaseCheckBox
                                checked={checkedField.indexOf(item.name) !== -1}
                                onChange={handleTogglePopover(item.name)}
                                disabled={item.stable}
                              />
                            </ListItemIcon>
                            <ListItemText primary={item.label} />
                          </ListItem>
                        ))}
                    </div>
                  </List>
                </Popover>
              </>
            )}
            {showCountStatus && (
              <div className={styles.counting}>
                <div className={styles.selected}>
                  {`${t('tableStatus.submit')} `}
                  <span
                    className={styles.piece}
                  >{` ${data?.total_submit ?? EMPTY_COUNT} ${unit}`}</span>
                </div>
                <div className={styles.divider}>
                  <DotDivider />
                </div>
                <div className={styles.selected}>
                  {`${t('tableStatus.approval')} `}
                  <span
                    className={styles.piece}
                  >{` ${data?.total_approval ?? EMPTY_COUNT} ${unit}`}</span>
                </div>
                <div className={styles.divider}>
                  <DotDivider />
                </div>
                <div className={styles.selected}>
                  {`${t('tableStatus.rejection')}`}
                  <span
                    className={styles.piece}
                  >{` ${data?.total_rejection ?? EMPTY_COUNT} ${unit}`}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <div className={styles.tableWrap}>
        <TableContainer
          sx={{ overflowX: 'auto' }}
          className={styles.tableScroll}
        >
          <Table aria-label='sticky table'>
            <TableHead>
              <TableRow>
                {hasCheckbox && (
                  <StyledTableCell
                    key='checkbox'
                    style={{
                      width: 'fit-content',
                      padding: 0,
                    }}
                  >
                    <Box className={styles.checkboxCell}>
                      <Box className={styles.checkboxContainer}>
                        <BaseCheckBox
                          className={styles.baseCheckBox}
                          checked={isAllSelected}
                          onChange={handleSelectAllCheckboxChange}
                        />
                      </Box>
                    </Box>
                  </StyledTableCell>
                )}
                {currentColumns.map((column, index) => (
                  <StyledTableCell
                    key={column.name + index}
                    align={column.align}
                    style={{
                      width: column.width,
                      padding: '10px 0px 10px 12px',
                    }}
                    sortDirection={
                      orderBy === column.name ? orderDirection : false
                    }
                  >
                    <Box
                      sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        fontWeight: 500,
                        borderRight:
                          index !== currentColumns.length - 1
                            ? '0.5px solid #D9D9D9'
                            : 'none',
                        paddingRight: '12px',
                      }}
                    >
                      <span className={styles.ellipsisText}>
                        {column.label}
                      </span>
                      {column.sortable && (
                        <TableSortLabel
                          data-testid='sort-button-name'
                          active={orderBy === column.name}
                          direction={
                            orderBy === column.name ? orderDirection : 'asc'
                          }
                          onClick={() => handleSort(column.name)}
                          IconComponent={SortIconButton}
                        />
                      )}
                    </Box>
                  </StyledTableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {isLoading || isFetching
                ? Array.from({ length: rowsPerPage }).map((item, i) => (
                    <TableRow key={`${i}-${i}`}>
                      {hasCheckbox && (
                        <StyledTableCell key='checkbox'>
                          <Skeleton
                            variant='rectangular'
                            style={{
                              width: '16px',
                              height: '19px',
                              borderRadius: '6px',
                            }}
                          />
                        </StyledTableCell>
                      )}
                      {currentColumns.map((column, index) => (
                        <StyledTableCell
                          key={column.name + index}
                          align={column.align}
                          width={column.width}
                          style={{
                            padding: '4px 8px',
                          }}
                        >
                          <Skeleton
                            variant='text'
                            className={styles.customSkeleton}
                          />
                        </StyledTableCell>
                      ))}
                    </TableRow>
                  ))
                : renderRows()}
            </TableBody>
          </Table>
        </TableContainer>
      </div>

      <div className={styles.paginationWrap}>
        {handleDeleteMultiple && (
          <IconButton
            className={styles.btnDelete}
            aria-label='delete'
            onClick={() => openConfirmDelete()}
            disabled={enableBtnAction}
          >
            <MultipleDeleteIcon
              fill={enableBtnAction ? '#BFBFBF' : '#FF4D4F'}
            />
          </IconButton>
        )}

        {!handleDeleteMultiple && <div />}
        {rows.length > 0 && (
          <CustomPagination
            totalCount={total ?? rowsPerPage}
            pageSize={rowsPerPage}
            page={page}
            defaultRowsPerPage={rowsPerPage}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            disabled={isLoading || isFetching}
            showSelectPagination={showSelectPagination}
          />
        )}
      </div>
    </div>
  );
};
