import PreviousIcon from '@/assets/direction-icons/icon-chevron-left.svg?react';
import NextIcon from '@/assets/direction-icons/icon-chevron-right.svg?react';
import {
  KeyboardDoubleArrowLeft,
  KeyboardDoubleArrowRight,
} from '@mui/icons-material';
import { Pagination, PaginationItem, styled } from '@mui/material';
import { useCallback } from 'react';
import styles from '../../styles/AdminMain.module.scss';
import SearchSelect from '../Search/Select';
import paginationStyles from './CustomPagination.module.scss';

const StyledPaginationItem = styled(PaginationItem)(({ theme }) => ({
  '&.Mui-selected': {
    backgroundColor: 'var(--primary-color-100)',
    color: 'var(--primary-color-800)',
  },
  '& .MuiPaginationItem-icon': {
    fontSize: '1rem',
  },
  '&:hover': {
    backgroundColor: '#EBEBEB',
  },
  fontSize: '14px',
  fontStyle: 'normal',
  fontWeight: 500,
  lineHeight: '140%',
  borderRadius: '6px',
  padding: '0',
  margin: '0',
  color: '#1a1a1a',
}));

interface ICustomPagination {
  totalCount: number;
  pageSize: number;
  page: number;
  defaultRowsPerPage?: number;
  disabled?: boolean;
  onPageChange: (e: unknown, page: number) => void;
  onRowsPerPageChange: (value: number | string) => void;
  showSelectPagination?: boolean;
}

const CustomPagination = ({
  totalCount,
  pageSize,
  page,
  defaultRowsPerPage = 10,
  disabled,
  onPageChange,
  onRowsPerPageChange,
  showSelectPagination,
}: ICustomPagination) => {
  const pageCount = Math.ceil(totalCount / pageSize);

  const PreviousButton = useCallback(
    () => (
      <span className={styles.center}>
        <PreviousIcon style={{ color: '#555555', width: 16, height: 16 }} />
      </span>
    ),
    []
  );

  const NextButton = useCallback(
    () => (
      <span className={styles.center}>
        <NextIcon style={{ color: '#555555', width: 16, height: 16 }} />
      </span>
    ),
    []
  );

  const FirstButton = useCallback(
    () => (
      <span className={styles.center}>
        <KeyboardDoubleArrowLeft
          style={{ color: '#555555', width: 16, height: 16 }}
        />
      </span>
    ),
    []
  );

  const LastButton = useCallback(
    () => (
      <span className={styles.center}>
        <KeyboardDoubleArrowRight
          style={{ color: '#555555', width: 16, height: 16 }}
        />
      </span>
    ),
    []
  );

  return (
    <div
      className={paginationStyles.layout}
      style={showSelectPagination ? {} : { justifyContent: 'center' }}
    >
      <div />
      <Pagination
        disabled={disabled}
        count={pageCount}
        page={page + 1}
        onChange={onPageChange}
        sx={{
          '& .MuiPagination-ul': {
            gap: '4px',
          },
        }}
        classes={{
          root: styles.pagination,
        }}
        showFirstButton
        showLastButton
        renderItem={(item) => (
          <StyledPaginationItem
            {...item}
            components={{
              previous: PreviousButton,
              next: NextButton,
              first: FirstButton,
              last: LastButton,
            }}
          />
        )}
      />

      {showSelectPagination && (
        <div style={{ height: '32px', width: '89px' }}>
          <SearchSelect
            options={[
              { label: '10개씩', value: 10 },
              { label: '25개씩', value: 25 },
              { label: '50개씩', value: 50 },
              { label: '100개씩', value: 100 },
            ]}
            height='32px'
            handleChange={onRowsPerPageChange}
            defaultValue={defaultRowsPerPage}
            sx={{
              '&.MuiInputBase-root.MuiOutlinedInput-root': {
                'div': {
                  fontSize: '13px',
                  fontWeight: 500,
                  lineHeight: '145%',
                  padding: '6.5px 10px',
                  paddingRight: '30px',
                  height: '100%',
                  boxSizing: 'border-box',
                  display: 'flex',
                  alignItems: 'center',
                  width: '100%',
                },
                svg: {
                  width: 16,
                  height: 16,
                  path: {
                    fill: 'var(--gray-700) !important',
                  },
                },
              },
            }}
          />
        </div>
      )}
    </div>
  );
};

export default CustomPagination;
