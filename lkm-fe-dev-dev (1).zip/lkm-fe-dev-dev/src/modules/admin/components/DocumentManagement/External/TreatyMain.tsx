import { Table } from './TreatyTable';
import { FormSearch } from './TreatyFormSearch';

export const TreatyMain = () => (
  <div style={{ display: 'grid', gap: '24px' }}>
    <FormSearch />
    <Table />
  </div>
);
