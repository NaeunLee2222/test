import { refetchDocumentsAtom } from '@/modules/admin/jotai/document';
import { formatDateString, formatDateToKst, openNewTab } from '@/utils';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useCallback, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
  fieldSettingAtom,
  getData,
  mutationLawData,
  paginationSettingAtom,
} from '../../../hooks/useDocumentExternalSettings';
import { FormatDocumentStatus } from '../../FormatDocumentStatus/FormatDocumentStatus';
import { PopoverCustom } from '../../PopoverCustom';
import { BaseTable } from '../../Table/BaseTable';

export const Table = () => {
  const { t } = useTranslation('admin');
  const [{ data }] = useAtom(getData);
  const [, setRefetchDocuments] = useAtom(refetchDocumentsAtom);
  const [{ mutate: mutateRetry }] = useAtom(mutationLawData);

  const handleClickRetry = useCallback(
    (row: any) => {
      mutateRetry(row);
    },
    [mutateRetry]
  );

  useEffect(() => {
    if (
      data?.data_list &&
      _.size(data.data_list) > 0 &&
      data.data_list.find((i) =>
        ['DOWNLOADED', 'PREPRARING'].includes(i.status)
      )
    ) {
      setRefetchDocuments(30 * 1000); // 30s
    } else {
      setRefetchDocuments(false);
    }
  }, [data?.data_list, setRefetchDocuments]);

  const columns = useMemo(
    () => [
      {
        name: 'title',
        label: t('categoryName'),
        width: '26%',
        stable: true,
        isDefault: true,
        format: (value: string, row: any) => {
          const isLastest = row?.is_latest === 1;
          return isLastest ? (
            <div
              style={{
                display: 'flex',
                gap: '12px',
                alignItems: 'center',
                width: '100%',
              }}
            >
              <span
                className='caption02Medium'
                style={{
                  width: '20px',
                  minWidth: '20px',
                  backgroundColor: 'rgba(250, 82, 82, 0.1)',
                  color: 'var(--primitives-red-80)',
                  display: 'block',
                  textAlign: 'center',
                  alignContent: 'center',
                  lineHeight: '20px',
                  height: '20px',
                }}
              >
                {t('shortenLatest')}
              </span>
              <span
                style={{
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                {value}
              </span>
            </div>
          ) : (
            value
          );
        },
      },
      {
        name: 'department',
        label: t('ministryInCharge'),
        width: '8%',
        isDefault: true,
      },
      {
        name: 'classification',
        label: t('classification'),
        width: '8%',
      },
      {
        name: 'law_kind',
        label: t('typeOfLaw'),
        width: '8%',
        stable: true,
        isDefault: true,
      },
      {
        name: 'promulgation_number',
        label: t('horrorNumber'),
        width: '8%',
        isDefault: true,
      },
      {
        name: 'promulgation_date',
        label: t('dateOfPromulgation'),
        width: '6%',
        isDefault: true,
        format: (value: string) => formatDateString(value),
      },
      {
        name: 'effective_date',
        label: t('effectiveDate'),
        width: '6%',
        sortable: true,
        stable: true,
        isDefault: true,
        format: (value: string) => formatDateString(value),
      },
      {
        name: 'history',
        label: t('history'),
        width: '8%',
      },
      {
        name: 'law_serial_number',
        label: t('lawSerialNumber'),
        width: '8%',
      },
      {
        name: 'update_dt',
        label: t('updateDate'),
        width: '6%',
        format: (value: string) => formatDateToKst(value, 'YYYY-MM-DD'),
        sortable: true,
        isDefault: true,
      },
      {
        name: 'status',
        label: t('status'),
        width: '7%',
        stable: true,
        isDefault: true,
        format: (value: string, row: any) => (
          <FormatDocumentStatus
            value={value}
            action={() => handleClickRetry(row)}
            t={t}
          />
        ),
      },
      {
        name: '',
        label: '',
        width: '1%',
        format: (
          _value: string,
          row: {
            pdf_url: string;
            original_url: string;
          }
        ) => (
          <PopoverCustom>
            <div role='presentation' onClick={() => openNewTab(row?.pdf_url)}>
              {t('pdfDownload')}
            </div>
            <div
              role='presentation'
              onClick={() => openNewTab(row?.original_url)}
            >
              {t('openInNewWindow')}
            </div>
          </PopoverCustom>
        ),
      },
    ],
    [handleClickRetry, t]
  );

  return (
    <BaseTable
      setOpenDialog={() => {}}
      columns={columns}
      paginationSettingAtom={paginationSettingAtom}
      fieldSettingAtom={fieldSettingAtom}
      getData={getData}
      customColumnDisplay
      rowCursor='default'
    />
  );
};
