import { Table } from './JudicialPrecedentTable';
import { FormSearch } from './JudicialPrecedentFormSearch';

export const JudicialPrecedentMain = () => (
  <div style={{ display: 'grid', gap: '24px' }}>
    <FormSearch />
    <Table />
  </div>
);
