import { Table } from './LegalInterpretationTable';
import { FormSearch } from './LegalInterpretationFormSearch';

export const LegalInterpretationMain = () => (
  <div style={{ display: 'grid', gap: '24px' }}>
    <FormSearch />
    <Table />
  </div>
);
