import { useTranslation } from 'react-i18next';
import { useMemo, useEffect, useCallback } from 'react';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { formatDateToKst, openNewTab } from '@/utils';
import { refetchDocumentsAtom } from '@/modules/admin/jotai/document';
import { FormatDocumentStatus } from '../../FormatDocumentStatus/FormatDocumentStatus';
import { PopoverCustom } from '../../PopoverCustom';
import { BaseTable } from '../../Table/BaseTable';
import {
  paginationTreatySettingAtom,
  fieldTreatySettingAtom,
  getTreatyData,
  mutationTreatyData,
} from '../../../hooks/useDocumentExternalSettings';

export const Table = () => {
  const { t } = useTranslation('admin');
  const [{ data }] = useAtom(getTreatyData);
  const [, setRefetchDocuments] = useAtom(refetchDocumentsAtom);
  const [{ mutate: mutateRetry }] = useAtom(mutationTreatyData);

  const handleClickRetry = useCallback(
    (row: any) => {
      mutateRetry(row);
    },
    [mutateRetry]
  );

  useEffect(() => {
    if (
      data?.data_list &&
      _.size(data.data_list) > 0 &&
      data.data_list.find((i) =>
        ['DOWNLOADED', 'PREPRARING'].includes(i.status)
      )
    ) {
      setRefetchDocuments(30 * 1000); // 30s
    } else {
      setRefetchDocuments(false);
    }
  }, [data?.data_list, setRefetchDocuments]);

  const columns = useMemo(
    () => [
      {
        name: 'treaty_type',
        label: t('type1'),
        width: '30%',
      },
      {
        name: 'country',
        label: t('country'),
        width: '30%',
      },
      {
        name: 'update_dt',
        label: t('updateDate'),
        width: '30%',
        format: (value: string) => formatDateToKst(value, 'YYYY-MM-DD'),
        sortable: true,
      },
      {
        name: 'status',
        label: t('status'),
        width: '9%',
        format: (value: string, row: any) => (
          <FormatDocumentStatus
            value={value}
            action={() => handleClickRetry(row)}
            t={t}
          />
        ),
      },
      {
        name: '',
        label: '',
        width: '1%',
        format: (
          _value: string,
          row: {
            pdf_url: string;
            original_url: string;
          }
        ) => (
          <PopoverCustom>
            <div
              role='presentation'
              onClick={() => openNewTab(row?.original_url)}
            >
              {t('openInNewWindow')}
            </div>
          </PopoverCustom>
        ),
      },
    ],
    [handleClickRetry, t]
  );

  return (
    <BaseTable
      setOpenDialog={() => {}}
      columns={columns}
      paginationSettingAtom={paginationTreatySettingAtom}
      fieldSettingAtom={fieldTreatySettingAtom}
      getData={getTreatyData}
      rowCursor='default'
    />
  );
};
