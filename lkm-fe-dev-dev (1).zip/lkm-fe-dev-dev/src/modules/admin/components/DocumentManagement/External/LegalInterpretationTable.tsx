import { useTranslation } from 'react-i18next';
import { useMemo, useEffect, useCallback } from 'react';
import { useAtom } from 'jotai';
import _ from 'lodash';
import cn from 'classnames';
import { formatDateToKst, openNewTab } from '@/utils';
import { refetchDocumentsAtom } from '@/modules/admin/jotai/document';
import { FormatDocumentStatus } from '../../FormatDocumentStatus/FormatDocumentStatus';
import { PopoverCustom } from '../../PopoverCustom';
import styles from '../../../styles/AdminMain.module.scss';
import { BaseTable } from '../../Table/BaseTable';
import {
  paginationLegalInterpretationSettingAtom,
  fieldLegalInterpretationSettingAtom,
  getLegalInterpretationData,
  chip2,
  Chip,
  mutationLegalInterpretationData,
} from '../../../hooks/useDocumentExternalSettings';

const chip1: Chip = {
  '사전답변': '사전',
  '질의회신': '질의',
  '과세기준자문': '기준',
  '고시서면질의': '고시',
};

export const Table = () => {
  const { t } = useTranslation('admin');
  const [{ data }] = useAtom(getLegalInterpretationData);
  const [, setRefetchDocuments] = useAtom(refetchDocumentsAtom);
  const [{ mutate: mutateRetry }] = useAtom(mutationLegalInterpretationData);

  const handleClickRetry = useCallback(
    (row: any) => {
      mutateRetry(row);
    },
    [mutateRetry]
  );

  useEffect(() => {
    if (
      data?.data_list &&
      _.size(data.data_list) > 0 &&
      data.data_list.find((i) =>
        ['DOWNLOADED', 'PREPRARING'].includes(i.status)
      )
    ) {
      setRefetchDocuments(30 * 1000); // 30s
    } else {
      setRefetchDocuments(false);
    }
  }, [data?.data_list, setRefetchDocuments]);

  const columns = useMemo(
    () => [
      {
        name: 'title',
        label: t('chatting'),
        width: '57%',
        format: (
          value: string,
          row: {
            type: string;
            law_class: string;
          }
        ) => (
          <div className={styles.displayChip}>
            <div className={styles.chipWrap}>
              {row?.type && chip1[row?.type] && (
                <span className={styles.chip1}>{chip1[row?.type]}</span>
              )}
              {row?.law_class && chip2[row?.law_class] && (
                <span className={styles.chip2}>{chip2[row?.law_class]}</span>
              )}
            </div>
            <span className={cn(styles.chipText, 'text-ellipsis')}>
              {value}
            </span>
          </div>
        ),
      },
      {
        name: 'case_number',
        label: t('caseNumber2'),
        width: '18%',
      },
      {
        name: 'sentencing_date',
        label: t('sentencingDate'),
        width: '6%',
        sortable: true,
      },
      {
        name: 'registration_date',
        label: t('registerDate1'),
        width: '6%',
        sortable: true,
      },
      {
        name: 'update_dt',
        label: t('updateDate'),
        width: '6%',
        format: (value: string) => formatDateToKst(value, 'YYYY-MM-DD'),
        sortable: true,
      },
      {
        name: 'status',
        label: t('status'),
        width: '6%',
        format: (value: string, row: any) => (
          <FormatDocumentStatus
            value={value}
            action={() => handleClickRetry(row)}
            t={t}
          />
        ),
      },
      {
        name: '',
        label: '',
        width: '1%',
        format: (
          _value: string,
          row: {
            pdf_url: string;
            original_url: string;
          }
        ) => (
          <PopoverCustom>
            <div
              role='presentation'
              onClick={() => openNewTab(row?.original_url)}
            >
              {t('openInNewWindow')}
            </div>
          </PopoverCustom>
        ),
      },
    ],
    [handleClickRetry, t]
  );

  return (
    <BaseTable
      setOpenDialog={() => {}}
      columns={columns}
      paginationSettingAtom={paginationLegalInterpretationSettingAtom}
      fieldSettingAtom={fieldLegalInterpretationSettingAtom}
      getData={getLegalInterpretationData}
      rowCursor='default'
    />
  );
};
