import { RangeDatePicker } from '@/modules/core/components/common/DatePicker/RangeDatePicker';
import { getKstTimestampBySelectedDate } from '@/utils';
import dayjs from 'dayjs';
import localeData from 'dayjs/plugin/localeData';
import weekday from 'dayjs/plugin/weekday';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import {
  getLegalInterpretationData,
  paginationLegalInterpretationSettingAtom,
} from '../../../hooks/useDocumentExternalSettings';
import styles from '../../../styles/AdminMain.module.scss';
import SearchInput from '../../Search/Input';
import SearchSelect from '../../Search/Select';

dayjs.extend(weekday);
dayjs.extend(localeData);

export const FormSearch = () => {
  const { t } = useTranslation('admin');
  const [searchParams] = useSearchParams();
  const now = dayjs();
  const last1Month = dayjs().subtract(1, 'month');
  const [selectedDate, setSelectedDate] = useState([last1Month, now]);
  const [selectType, setSelectType] = useState('');
  const [search, setSearch] = useState('');
  const [, setPage] = useAtom(paginationLegalInterpretationSettingAtom);
  const [{ refetch }] = useAtom(getLegalInterpretationData);

  const handleSearch = ({
    currentDateValue,
    currentTypeValue,
    currentSearchValue,
    isEventDriven,
  }: {
    currentDateValue: dayjs.Dayjs[];
    currentTypeValue: string;
    currentSearchValue?: string;
    isEventDriven?: boolean;
  }) => {
    let params = '';
    if (currentSearchValue) {
      params = `&search=${currentSearchValue}`;
    }
    if (currentTypeValue) {
      params = `${params}&status=${currentTypeValue}`;
    }
    const dateStr = getKstTimestampBySelectedDate(currentDateValue);
    if (dateStr) {
      params = `${params}&${dateStr}`;
    }
    setPage((prev) => ({ ...prev, page: 0, search: params }));
    if (isEventDriven) refetch();
  };

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch({
        currentDateValue: selectedDate,
        currentTypeValue: selectType,
        currentSearchValue: (e.target as HTMLInputElement).value,
        isEventDriven: true,
      });
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleChangeDate = (date: any) => {
    if (date && _.size(date) > 1) {
      const startDate = date[0] || '';
      const endDate = date[1] || '';
      setSelectedDate([dayjs(startDate), dayjs(endDate)]);
      handleSearch({
        currentDateValue: [dayjs(startDate), dayjs(endDate)],
        currentTypeValue: selectType,
        currentSearchValue: search,
        isEventDriven: true,
      });
    }
  };

  const handleSelectType = (value: string) => {
    setSelectType(value);
    handleSearch({
      currentDateValue: selectedDate,
      currentTypeValue: value,
      currentSearchValue: search,
      isEventDriven: true,
    });
  };

  useEffect(() => {
    const startDateParam = searchParams.get('startDate');
    const endDateParam = searchParams.get('endDate');
    const formattedDate = [dayjs(startDateParam), dayjs(endDateParam)];
    const typeParam = searchParams.get('type');

    if (typeParam) {
      setSelectType(typeParam);
    }

    if (startDateParam && endDateParam) {
      setSelectedDate(formattedDate);
    }

    const isValidDate = formattedDate.every((date) => date.isValid());

    handleSearch({
      currentDateValue: isValidDate ? formattedDate : [last1Month, now],
      currentTypeValue: typeParam || '',
    });
  }, [searchParams]);

  return (
    <div className={styles.formSearch}>
      <div className={styles.inputDate}>
        <div className={styles.label}>{`${t('registerDate')}:`}</div>
        <RangeDatePicker
          className={styles.dateRangePicker}
          onConfirm={(date: any) => handleChangeDate(date)}
          defaultValue={selectedDate}
        />
      </div>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('status')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: t('all') },
            { value: 'succeeded', label: t('succeeded') },
            { value: 'other', label: t('inprogress') },
            { value: 'failed', label: t('failure') },
          ]}
          defaultValue=''
          handleChange={handleSelectType}
        />
      </div>
      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('searchByTitle')}
          search={search}
        />
      </div>
    </div>
  );
};
