import { useAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import styles from '../../../styles/AdminMain.module.scss';
import {
  getTreatyData,
  paginationTreatySettingAtom,
} from '../../../hooks/useDocumentExternalSettings';
import SearchSelect from '../../Search/Select';
import SearchInput from '../../Search/Input';

export const FormSearch = () => {
  const { t } = useTranslation('admin');
  const [searchParams] = useSearchParams();
  const [selectType, setSelectType] = useState('');
  const [selectStatus, setSelectStatus] = useState('');
  const [search, setSearch] = useState('');
  const [, setPage] = useAtom(paginationTreatySettingAtom);
  const [{ refetch }] = useAtom(getTreatyData);

  const handleSearch = (currentType?: string, currentStatus?: string) => {
    let params = '';
    if (search) {
      params = `&search=${search}`;
    }
    if (currentType || selectType) {
      params = `${params}&type=${currentType || selectType}`;
    }
    if (currentStatus || selectStatus) {
      params = `${params}&status=${currentStatus || selectStatus}`;
    }
    setPage((prev) => ({ ...prev, page: 0, search: params }));
    refetch();
  };

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch();
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleSelectType = (value: string) => {
    setSelectType(value);
    handleSearch(value);
  };

  const handleSelectStatus = (value: string) => {
    setSelectStatus(value);
    handleSearch('', value);
  };

  useEffect(() => {
    const typeParam = searchParams.get('type');
    const statusParam = searchParams.get('status');

    if (statusParam) {
      setSelectStatus(statusParam);
    }

    if (typeParam) {
      setSelectType(typeParam);
    }
  }, [searchParams]);

  return (
    <div className={styles.formSearch}>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('type1')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: t('all') },
            { value: 'dta', label: t('dtaType') },
            { value: 'beps', label: t('bepsType') },
          ]}
          defaultValue=''
          handleChange={handleSelectType}
        />
      </div>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('status')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: t('all') },
            { value: 'succeeded', label: t('succeeded') },
            { value: 'other', label: t('inprogress') },
            { value: 'failed', label: t('failure') },
          ]}
          defaultValue=''
          handleChange={handleSelectStatus}
        />
      </div>
      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('searchByCountry')}
          search={search}
        />
      </div>
    </div>
  );
};
