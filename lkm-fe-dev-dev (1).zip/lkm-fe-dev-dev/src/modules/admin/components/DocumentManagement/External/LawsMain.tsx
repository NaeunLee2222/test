import { Table } from './LawsTable';
import { FormSearch } from './LawsFormSearch';

export const LawsMain = () => (
  <div style={{ display: 'grid', gap: '24px' }}>
    <FormSearch />
    <Table />
  </div>
);
