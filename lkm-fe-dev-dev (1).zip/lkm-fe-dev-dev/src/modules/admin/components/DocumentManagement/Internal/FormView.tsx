import { useTranslation } from 'react-i18next';
import BaseDetailsText from '../../Form/DetailsText/BaseDetailsText';
import styles from '../../QuestionManagement/Dialog.module.scss';

export const FormView = ({ data }: any) => {
  const { t } = useTranslation('admin');
  return (
    <div className={styles.baseDialog}>
      <div className={styles.group}>
        <BaseDetailsText label={t('type')} content={data?.data_type || ''} />
        <BaseDetailsText
          label={t('dataName')}
          content={data?.data_name || ''}
        />
        <BaseDetailsText
          label={t('file')}
          content={data?.filename || ''}
          contentStyle={{
            color: 'var(--primary-color-600)',
          }}
        />
      </div>
    </div>
  );
};
