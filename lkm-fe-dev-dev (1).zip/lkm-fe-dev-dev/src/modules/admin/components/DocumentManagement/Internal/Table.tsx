import IconEllipsis from '@/assets/basic-icons/icon-ellipsis.svg?react';
import { refetchDocumentsAtom } from '@/modules/admin/jotai/document';
import type { IDialog } from '@/modules/admin/types/user';
import { formatDateToKst, getStatusText } from '@/utils';
import Button from '@mui/material/Button';
import Popover from '@mui/material/Popover';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  fieldSettingAtom,
  getData,
  paginationSettingAtom,
} from '../../../hooks/useDocumentInternalSettings';
import { BaseTable } from '../../Table/BaseTable';

interface IProps {
  setOpenDialog: ({ open, type }: IDialog) => void;
}

export const Table = ({ setOpenDialog }: IProps) => {
  const { t } = useTranslation('admin');
  const [{ data }] = useAtom(getData);
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  const [, setRefetchDocuments] = useAtom(refetchDocumentsAtom);

  useEffect(() => {
    if (
      data?.data_list &&
      _.size(data.data_list) > 0 &&
      data.data_list.find((i) =>
        ['DOWNLOADED', 'PREPRARING'].includes(i.status)
      )
    ) {
      setRefetchDocuments(30 * 1000); // 30s
    } else {
      setRefetchDocuments(false);
    }
  }, [data?.data_list, setRefetchDocuments]);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    setAnchorEl(event.currentTarget);
  };
  const handleClose = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    setAnchorEl(null);
  };
  const columns = useMemo(
    () => [
      {
        name: 'data_type',
        label: t('type'),
        width: '15%',
      },
      {
        name: 'data_name',
        label: t('dataName'),
        width: '35%',
      },
      {
        name: 'status',
        label: t('status'),
        width: '12%',
        format: (value: string) => {
          const result = getStatusText(value, t, true);
          const isFailure = value === 'FAILED';
          return isFailure ? (
            <div style={{ display: 'flex', color: '#F5222D', lineHeight: 1 }}>
              <span style={{ marginTop: '3px' }}>{result}</span>
            </div>
          ) : (
            result
          );
        },
      },
      {
        name: 'update_dt',
        label: t('updateDate'),
        width: '15%',
        format: (value: string) => formatDateToKst(value, 'YYYY-MM-DD'),
        sortable: true,
      },
      {
        name: 'username',
        label: t('author'),
        width: '22%',
      },
      {
        name: '',
        label: '',
        width: '1%',
        format: (
          _value: string,
          _row: {
            pdf_url: string;
            original_url: string;
          }
        ) => (
          <div>
            <Button
              aria-describedby={id}
              size='small'
              variant='text'
              onClick={handleClick}
              sx={{
                height: '20px',
                width: '20px',
                minWidth: '20px',
                '&:hover': {
                  backgroundColor: 'var(--gray-100)',
                },
                '&:active': {
                  backgroundColor: 'var(--gray-200)',
                },
              }}
            >
              <IconEllipsis />
            </Button>
            <Popover
              id={id}
              open={open}
              anchorEl={anchorEl}
              onClose={handleClose}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'right',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
              className='popoverStyle popoverCustom'
              sx={{
                '.MuiPopover-paper': {
                  minWidth: '100px',
                  border: '1px solid #0000000D',
                  boxShadow: 'none',
                  '&:hover': {
                    '.MuiTypography-root': {
                      backgroundColor: 'var(--gray-100)',
                    },
                  },
                },
              }}
            >
              <div
                role='presentation'
                onClick={(event: any) => {
                  event.stopPropagation();
                }}
              >
                {t('pdfDownload')}
              </div>
            </Popover>
          </div>
        ),
      },
    ],
    [anchorEl, id, open, t]
  );

  return (
    <BaseTable
      setOpenDynamicDialog={setOpenDialog}
      columns={columns}
      paginationSettingAtom={paginationSettingAtom}
      fieldSettingAtom={fieldSettingAtom}
      getData={getData}
      hasAddBtn
      addBtnLabel={t('addData')}
    />
  );
};
