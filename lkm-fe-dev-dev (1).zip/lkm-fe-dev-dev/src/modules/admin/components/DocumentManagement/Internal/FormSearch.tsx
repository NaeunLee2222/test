import { useCompanyList, useUserMe } from '@/modules/core/hooks';
import { useAtom } from 'jotai';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  getData,
  paginationSettingAtom,
} from '../../../hooks/useDocumentInternalSettings';
import styles from '../../../styles/AdminMain.module.scss';
import SearchInput from '../../Search/Input';
import SearchSelect from '../../Search/Select';

export const FormSearch = () => {
  const { t } = useTranslation('admin');
  const [type, setType] = useState('');
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [company, setCompany] = useState('');

  const [, setPage] = useAtom(paginationSettingAtom);
  const [{ refetch }] = useAtom(getData);

  const [{ data: userData }] = useAtom(useUserMe);
  const isSuperAdmin = userData?.role?.includes('superadmin');
  const [{ data: companyList }] = useAtom(useCompanyList);

  const companyOptions = useMemo(
    () =>
      companyList?.map((c) => ({
        value: c.name,
        label: c.name,
      })) || [],
    [companyList]
  );

  const handleSearch = (currentType?: string, currentStatus?: string) => {
    let params = '';
    if (search) {
      params = `&search=${search}`;
    }
    if (currentType || type) {
      params = `${params}&dataType=${currentType || type}`;
    }
    if (currentStatus || status) {
      params = `${params}&status=${currentStatus || status}`;
    }
    setPage((prev) => ({ ...prev, page: 0, search: params }));
    refetch();
  };

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch();
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleSelectCompany = (value: string) => {
    setCompany(value);
    setPage((prev) => ({ ...prev, page: 0, company: value }));
  };

  const handleSelectType = (value: string) => {
    setType(value);
    handleSearch(value);
  };

  const handleSelectStatus = (value: string) => {
    setStatus(value);
    handleSearch('', value);
  };

  useEffect(() => {
    if (companyList) {
      const defaultCompany = companyList?.find(
        (c) => c.name === userData?.company
      );
      setCompany(defaultCompany?.name || '');
      setPage((prev) => ({
        ...prev,
        page: 0,
        company: defaultCompany?.name || '',
      }));
    }
  }, [companyList, setPage]);

  return (
    <>
      {isSuperAdmin && (
        <div className={styles.selectField}>
          <div className={styles.label}>{`${t('company')}:`}</div>
          <SearchSelect
            options={companyOptions}
            // defaultValue={company}
            value={company}
            handleChange={handleSelectCompany}
          />
        </div>
      )}
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('type')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: t('all') },
            { value: '매뉴얼', label: t('manual') },
            { value: '과거자문이력', label: t('pastConsultingHistory') },
          ]}
          defaultValue=''
          handleChange={handleSelectType}
        />
      </div>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('status')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: t('all') },
            { value: 'succeeded', label: t('succeeded') },
            { value: 'other', label: t('uploading') },
            { value: 'failed', label: t('failure') },
          ]}
          defaultValue=''
          handleChange={handleSelectStatus}
        />
      </div>
      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('searchByDataName')}
          search={search}
        />
      </div>
    </>
  );
};
