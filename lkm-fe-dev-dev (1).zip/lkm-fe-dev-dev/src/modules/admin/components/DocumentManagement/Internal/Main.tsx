import { IDialog } from '@/modules/admin/types/user';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from '../../../styles/AdminMain.module.scss';
import { DialogForm } from './Dialog';
import { FormSearch } from './FormSearch';
import { Table } from './Table';

export const Main = () => {
  const { t } = useTranslation('admin');

  const [dialogOpen, setOpenDialog] = useState<IDialog>({
    open: false,
    type: 'view',
  });

  return (
    <div className={styles.adminMain} data-testid='internal-main'>
      <h1 className={styles.pageTitle}>{t('internalDocument')}</h1>
      <div className={styles.content}>
        <div className={styles.formSearch}>
          <FormSearch />
        </div>
        <Table setOpenDialog={setOpenDialog} />
        <DialogForm dialogState={dialogOpen} setDialogState={setOpenDialog} />
      </div>
    </div>
  );
};
