import { IDialog } from '@/modules/admin/types/user';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { showSnackbar } from '@/utils/snackbarUtil';
import { useAtom } from 'jotai';
import { useCallback, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import {
  fieldSettingAtom,
  getData,
  useDeleteMutation,
  useSubmitMutation,
} from '../../../hooks/useDocumentInternalSettings';
import styles from '../../../styles/AdminMain.module.scss';
import BaseUploadFile from '../../Form/BaseUploadFile';
import BaseInput from '../../Form/Inputs/BaseInput';
import BaseSelect from '../../Form/Selects/BaseSelect';
import { FormView } from './FormView';

interface IProps {
  dialogState: IDialog;
  setDialogState: ({ open, type }: IDialog) => void;
}

const viewStates = {
  view: 'view',
  add: 'add',
};

export const DialogForm = ({ dialogState, setDialogState }: IProps) => {
  const { t } = useTranslation('admin');
  const [{ refetch }] = useAtom(getData);
  const methods = useForm();
  const { formState } = methods;

  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [settingData] = useAtom(fieldSettingAtom);
  const [{ mutate: mutateSubmit }] = useAtom(useSubmitMutation);
  const [defaultType, setDefaultType] = useState('');
  const [selectedFile, handleSelectedFile] = useState(null);
  const type = [t('manual'), t('pastConsultingHistory')];

  const handleClose = useCallback(() => {
    setDialogState({ ...dialogState, open: false });
    methods.reset();
    setDefaultType('');
  }, [setDialogState, methods, dialogState]);

  const handleConfirm = useCallback(() => {
    if (!selectedFile) {
      return;
    }

    const data = methods.getValues();
    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('data_type', data.data_type);
    formData.append('data_name', data.data_name);

    mutateSubmit({
      formData,
      callback: (
        isSuccess: boolean,
        response: {
          message?: string;
        }
      ) => {
        const message = isSuccess
          ? t('createDataSuccessfully')
          : response?.message || '';
        showSnackbar(message, isSuccess ? 'success' : 'error', 3);
      },
    });
    handleClose();
  }, [selectedFile, methods, mutateSubmit, handleClose, t]);

  const [{ mutate: mutateDelete }] = useAtom(useDeleteMutation);

  const handleDelete = useCallback(() => {
    setConfirmDialogData({ open: false });
    if (!settingData?.id) return;
    mutateDelete({
      id: settingData.id,
      callback: (isSuccess: boolean, response: { message?: string }) => {
        const message = isSuccess
          ? t('deleteDataSuccessfully')
          : response?.message || '';
        showSnackbar(message, isSuccess ? 'success' : 'error', 3);
        refetch();
      },
    });
    handleClose();
  }, [
    setConfirmDialogData,
    settingData.id,
    mutateDelete,
    handleClose,
    t,
    refetch,
  ]);

  const openConfirmDelete = useCallback(() => {
    setConfirmDialogData({
      open: true,
      title: t('internalDocumentDeleteTitle'),
      contentText: t('internalDocumentDeleteMessage'),
      confirmText: t('delete'),
      handleConfirm: handleDelete,
      handleCancel: () => {
        setConfirmDialogData({
          open: false,
        });
      },
    });
  }, [handleDelete, setConfirmDialogData, t]);

  const renderedButtons = useMemo(() => {
    const isFormValid = formState.isValid && formState.isDirty;
    switch (dialogState.type) {
      case viewStates.view:
        return (
          <div className='flexBetween'>
            <BaseButton buttonType='redLinked' onClick={openConfirmDelete}>
              <span>{t('delete')}</span>
            </BaseButton>
          </div>
        );
      case viewStates.add:
        return (
          <div className='flexBetween'>
            <span />
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={styles.btnStyles}
                onClick={handleClose}
              >
                <span>{t('cancel')}</span>
              </BaseButton>
              <BaseButton
                autoFocus
                className={styles.btnStyles}
                onClick={methods.handleSubmit(handleConfirm)}
                color='primary'
                disabled={!isFormValid}
              >
                <span>{t('registration')}</span>
              </BaseButton>
            </span>
          </div>
        );
      default:
        return null;
    }
  }, [
    formState.isValid,
    formState.isDirty,
    dialogState.type,
    openConfirmDelete,
    t,
    handleClose,
    methods,
    handleConfirm,
  ]);

  return (
    <BaseDialog
      open={dialogState.open}
      title={t('internalDocument')}
      handleClose={handleClose}
      sx={{
        '.MuiPaper-root': {
          maxWidth: '600px',
          '.MuiTypography-root': {
            padding: '30px 30px 12px 30px',
          },
        },
      }}
      contentChildren={
        <>
          {dialogState.type === viewStates.view ? (
            <FormView data={settingData} />
          ) : (
            <div
              className='flexColumn'
              style={{
                alignItems: 'flex-start',
                padding: '10px 0',
                gap: '16px',
              }}
            >
              <BaseSelect
                {...methods}
                name='data_type'
                data={type}
                label={t('type')}
                defaultValue={defaultType}
                placeholder={t('select')}
                rules={{
                  required: { value: true, message: t('errors.required') },
                }}
              />

              <BaseInput
                {...methods}
                name='data_name'
                maxLength={50}
                label={t('dataName')}
                placeholder={t('pleaseInputDataName')}
                rules={{
                  required: { value: true, message: t('errors.required') },
                }}
              />

              <BaseUploadFile
                {...methods}
                name='fileUpload'
                onChange={handleSelectedFile}
                rules={{
                  required: { value: true, message: t('errors.required') },
                }}
              />
            </div>
          )}
        </>
      }
      actionsChildren={renderedButtons}
    />
  );
};
