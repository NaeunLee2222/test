import { Box, Tab, Tabs } from '@mui/material';
import cn from 'classnames';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from '../../styles/AdminMain.module.scss';
import { CustomTabPanel, tabProps } from '../TabProps';
import { JudicialPrecedentMain } from './External/JudicialPrecedentMain';
import { LawsMain } from './External/LawsMain';
import { LegalInterpretationMain } from './External/LegalInterpretationMain';
import { TreatyMain } from './External/TreatyMain';

export const External = () => {
  const { t } = useTranslation('admin');
  const { t: tTax } = useTranslation('tax');
  const [value, setValue] = useState(0);

  const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <div className={cn(styles.adminMain, styles.isTabs)}>
      <h1 className={styles.pageTitleWithSmallPaddingBottom}>
        {tTax('menu.adminMenu.external')}
      </h1>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ margin: '0 24px' }}>
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label='basic tabs example'
            sx={{
              '.MuiTab-root': {
                fontSize: '16px',
                color: '#262626',
              },
              '.Mui-selected': {
                color: '#1890FF',
              },
            }}
          >
            <Tab label={t('statute')} {...tabProps(0)} />
            <Tab label={t('judicialPrecedent')} {...tabProps(1)} />
            <Tab label={t('interpretationExample')} {...tabProps(2)} />
            <Tab label={t('treatyTax')} {...tabProps(3)} />
          </Tabs>
        </Box>
        <div className={cn(styles.content, styles.expenseMain)}>
          <CustomTabPanel value={value} index={0}>
            <LawsMain />
          </CustomTabPanel>
          <CustomTabPanel value={value} index={1}>
            <JudicialPrecedentMain />
          </CustomTabPanel>
          <CustomTabPanel value={value} index={2}>
            <LegalInterpretationMain />
          </CustomTabPanel>
          <CustomTabPanel value={value} index={3}>
            <TreatyMain />
          </CustomTabPanel>
        </div>
      </Box>
    </div>
  );
};
