import { createUsage, getUsage, updateUsage } from '@/modules/admin/api/usage';
import { getOrgFromCookie, getUserIdFromCookie } from '@/utils';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Grid,
  TextField,
} from '@mui/material';
import { ChangeEvent, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import styles from './UsageMain.module.scss';

interface IFormValues {
  user_limit: number;
  org_limit: number;
  query_text_limit: number;
  answer_token_limit: number;
}

const MIN = 0;
const MAX_TEXT_LIMIT = 2000;
const MAX_ANSWER_TOKEN_LIMIT = 4096;
const LIMITED_FIELDS: Partial<
  Record<keyof IFormValues, { min: number; max: number }>
> = {
  query_text_limit: { min: MIN, max: MAX_TEXT_LIMIT },
  answer_token_limit: { min: MIN, max: MAX_ANSWER_TOKEN_LIMIT },
};

const parseNumberRegex = /[^\d]/g;

const formatNumber = (value: number | string): string => {
  const num = Number(value);
  return isNaN(num) ? '' : num.toLocaleString('en-US');
};

const parseNumber = (value: string): number =>
  Number(value.replace(parseNumberRegex, '') || 0);

export const UsageMain = () => {
  const { t } = useTranslation('admin');
  const [isNew, setIsNew] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const [initialValues, setInitialValues] = useState<IFormValues | null>(null);
  const [formChanged, setFormChanged] = useState(false);

  const userIdFromCookie = getUserIdFromCookie();
  const orgIdFromCookie = getOrgFromCookie();

  const { handleSubmit, setValue, watch, reset, getValues } =
    useForm<IFormValues>({
      mode: 'onChange',
      defaultValues: {
        user_limit: 0,
        org_limit: 0,
        query_text_limit: 0,
        answer_token_limit: 0,
      },
    });

  const fetchUsage = async () => {
    const data = await getUsage();
    setInitialValues(data);
    reset(data); // set form values
    setIsNew(false);
    setEditMode(false);
    setFormChanged(false);
  };

  useEffect(() => {
    fetchUsage();
  }, []);

  const handleUpdateUsage = async (props: IFormValues) => {
    try {
      await updateUsage(props);
    } catch (error) {
      console.error(error);
    }
  };

  const handleCreateUsage = async (props: IFormValues) => {
    try {
      await createUsage({
        ...props,
        user_id: Number(userIdFromCookie ?? 0),
        org_id: Number(orgIdFromCookie ?? 0),
      });
    } catch (error) {
      console.error(error);
    }
  };

  const onSubmit = (formData: IFormValues) => {
    if (isNew) {
      handleCreateUsage(formData);
    } else {
      handleUpdateUsage(formData);
    }
    setInitialValues(formData);
    setEditMode(false);
    setFormChanged(false);
  };

  const onCancel = () => {
    reset(initialValues!);
    setEditMode(false);
    setFormChanged(false);
  };

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    key: keyof IFormValues
  ) => {
    const raw = e.target.value;
    const parsed = parseNumber(raw);

    const limit = LIMITED_FIELDS[key];
    if (limit) {
      if (parsed < limit.min || parsed > limit.max) return;
    }

    setValue(key, parsed, { shouldDirty: true });

    const currentValues = getValues();
    const changed = Object.keys(currentValues).some(
      (k) =>
        currentValues[k as keyof IFormValues] !==
        initialValues?.[k as keyof IFormValues]
    );
    setFormChanged(changed);
  };

  const renderNumberField = (
    key: keyof IFormValues,
    labelKey: string,
    placeholderKey: string,
    helpTextKey?: string
  ) => {
    const value = watch(key) ?? 0;

    return (
      <Grid size={{ xs: 12, sm: 6 }}>
        <FormControl fullWidth className={styles.formItem}>
          <FormLabel className={styles.formLabel}>{t(labelKey)}</FormLabel>
          <TextField
            type='text'
            value={formatNumber(value)}
            onChange={(e) => handleChange(e, key)}
            placeholder={t(placeholderKey)}
            disabled={!editMode}
            size='small'
            InputProps={{
              endAdornment: (
                <span style={{ marginLeft: 4, color: 'var(--gray-900)' }}>
                  {!helpTextKey && t('usageForm.unit')}
                </span>
              ),
            }}
            sx={{
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: editMode
                  ? 'var(--primary-color-600) !important'
                  : 'none',
                border: editMode ? '' : 'none',
              },
              '& .MuiOutlinedInput-notchedOutline': {
                border: editMode ? '' : 'none',
              },
              '& .MuiInputBase-root': {
                height: '40px',
                boxSizing: 'border-box',
                borderRadius: '6px',
                background: editMode ? 'var(--white)' : 'var(--gray-100)',
              },
              '& .MuiInputBase-input.Mui-disabled': {
                WebkitTextFillColor: 'var(--gray-500)',
              },
              '& .MuiInputLabel-root.Mui-disabled': {
                color: 'var(--gray-500)',
              },
            }}
            helperText={helpTextKey ? t(helpTextKey) : ''}
            FormHelperTextProps={{
              style: { color: 'var(--gray-500)', height: '17px' },
            }}
          />
        </FormControl>
      </Grid>
    );
  };

  return (
    <Box className={styles.adminMain}>
      <Box className={styles.title}>
        <h1 className={styles.pageTitle}>{t('user.management')}</h1>
      </Box>
      <Box className={styles.container}>
        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <Box className={styles.formWrapper}>
            <Grid container spacing='24px'>
              {renderNumberField(
                'user_limit',
                'usageForm.limitPerUser',
                'usageForm.limitPerUserPlaceholder'
              )}
              {renderNumberField(
                'org_limit',
                'usageForm.warriorTotalLimit',
                'usageForm.warriorTotalLimitPlaceholder'
              )}
              {renderNumberField(
                'query_text_limit',
                'usageForm.questionTextInputLength',
                'usageForm.questionTextInputLengthPlaceholder',
                'usageForm.questionTextInputLengthHelp'
              )}
              {renderNumberField(
                'answer_token_limit',
                'usageForm.answerTokenLength',
                'usageForm.answerTokenLengthPlaceholder',
                'usageForm.answerTokenLengthHelp'
              )}
            </Grid>
          </Box>

          <Box className={styles.buttonGroup}>
            {!editMode && (
              <Button
                className={`${styles.button} ${styles.buttonEdit}`}
                variant='outlined'
                onClick={() => setEditMode(true)}
              >
                {t('usageForm.edit')}
              </Button>
            )}
            {editMode && (
              <>
                <Button
                  className={`${styles.button} ${styles.buttonCancel}`}
                  variant='outlined'
                  onClick={onCancel}
                >
                  {t('usageForm.cancel')}
                </Button>
                <Button
                  className={`${styles.button} ${styles.buttonSave}`}
                  variant='contained'
                  type='submit'
                  disabled={!formChanged}
                >
                  {t('usageForm.save')}
                </Button>
              </>
            )}
          </Box>
        </form>
      </Box>
    </Box>
  );
};
