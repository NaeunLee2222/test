import { ToolDialog } from '@/modules/admin/components/ToolManagement/ToolDialog';
import { ToolSearchWrapper } from '@/modules/admin/components/ToolManagement/ToolSettingAction';
import { ToolTable } from '@/modules/admin/components/ToolManagement/ToolTable';
import styles from '@/modules/admin/styles/Tool.module.scss';
import { useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { IDialog } from '../../types/user';

const ToolMain = () => {
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const { t } = useTranslation('tax');
  const [dialogOpen, setOpenDialog] = useState<IDialog>({
    open: false,
    type: 'view',
  });

  return (
    <div className={styles.adminMain} data-testid='tool-main'>
      <h1 className={styles.pageTitle}>{t('menu.adminMenu.toolManagement')}</h1>
      <div className={styles.content} data-testid='content-container'>
        <div className={styles.formSearch} data-testid='search-container'>
          <ToolSearchWrapper />
        </div>
        <ToolTable setOpenDialog={setOpenDialog} />
        <ToolDialog
          ref={dialogRef}
          dialogState={dialogOpen}
          setDialogState={setOpenDialog}
        />
      </div>
    </div>
  );
};

export default ToolMain;
