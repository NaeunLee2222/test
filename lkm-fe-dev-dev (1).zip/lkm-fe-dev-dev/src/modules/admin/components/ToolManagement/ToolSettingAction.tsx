import SearchInput from '@/modules/admin/components/Search/Input';
import SearchSelect from '@/modules/admin/components/Search/Select';
import {
  toolListPaginationAtom,
  useToolSettings,
} from '@/modules/admin/hooks/useToolSettings';
import styles from '@/modules/admin/styles/Tool.module.scss';
import { useToolGroupList } from '@/modules/agent/hooks/useAgent';
import { Button } from '@mui/material';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';

export const ToolSearchWrapper = () => {
  const { t } = useTranslation('admin');
  const [, setToolQuery] = useAtom(toolListPaginationAtom);
  const [{ refetch: getTools }] = useAtom(useToolSettings);

  const [search, setSearch] = useState('');
  const [toolGroupId, setToolGroupId] = useState('');
  const [toolType, setToolType] = useState('');
  const [{ data: toolGroups }] = useAtom(useToolGroupList);

  const toolGroupOptions = useMemo(
    () =>
      [{ id: '', name: t('all') }, ...(toolGroups || [])].map((group) => ({
        value: group.id,
        label: group.name,
      })),
    [toolGroups, t]
  );

  useEffect(() => {
    setToolQuery({
      toolGroupId: toolGroupId || undefined,
      toolName: search?.trim() || undefined,
      toolId: undefined,
      isVisible: toolType || undefined,
      page: 0,
      rowsPerPage: 10,
      sortDetail: undefined,
    });
    getTools();
  }, [toolGroupId, toolType]);

  const handleSearch = useCallback(() => {
    setToolQuery({
      toolGroupId: toolGroupId || undefined,
      toolName: search?.trim() || undefined,
      toolId: undefined,
      isVisible: toolType || undefined,
      page: 0,
      rowsPerPage: 10,
      sortDetail: undefined,
    });
    getTools();
  }, [search, setToolQuery, toolGroupId, toolType]);

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch();
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleClear = useCallback(() => {
    setToolGroupId('');
    setToolType('');
    setSearch('');
    setToolQuery({
      toolGroupId: undefined,
      toolName: undefined,
      toolId: undefined,
      isVisible: undefined,
      page: 0,
      rowsPerPage: 10,
      sortDetail: undefined,
    });
  }, [setToolQuery]);

  return (
    <div className={styles.searchContainer}>
      <div className={styles.selectContainer}>
        <div className={styles.selectField}>
          <div className={styles.label}>{`${t('tool.group')}`}</div>
          <SearchSelect
            options={toolGroupOptions}
            defaultValue=''
            value={toolGroupId}
            handleChange={setToolGroupId}
            height='32px'
          />
        </div>
        <div className={styles.selectField}>
          <div className={styles.label}>{`${t('tool.isVisible')}`}</div>
          <SearchSelect
            options={[
              { value: '', label: t('all') },
              { value: 'true', label: t('used') },
              { value: 'false', label: t('unused') },
            ]}
            defaultValue=''
            value={toolType}
            handleChange={setToolType}
            height='32px'
          />
        </div>
      </div>

      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('tool.searchToolPlaceholder')}
          search={search}
          className={styles.textField}
        />
      </div>
      <div className={styles.searchAction}>
        <Button
          variant='outlined'
          className={styles.clear}
          onClick={handleClear}
          type='button'
          tabIndex={0}
          size='small'
        >
          {t('reset')}
        </Button>
        <Button
          size='small'
          variant='contained'
          className={styles.search}
          onClick={handleSearch}
          type='button'
          tabIndex={0}
          sx={{ boxShadow: 'none' }}
        >
          {t('check')}
        </Button>
      </div>
    </div>
  );
};
