import { BaseTable } from '@/modules/admin/components/Table/BaseTable';
import {
  toolListPaginationAtom,
  toolSettingDataAtom,
  useToolDeleteMutation,
  useToolSettings,
} from '@/modules/admin/hooks/useToolSettings';
import { useAtom } from 'jotai';
import { useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import type { IDialog } from '../../types/user';

interface IProps {
  setOpenDialog: ({ open, type }: IDialog) => void;
}

export const ToolTable = ({ setOpenDialog }: IProps) => {
  const { t } = useTranslation('admin');

  const [{ refetch: getTools }] = useAtom(useToolSettings);

  useEffect(() => {
    getTools();
  }, [getTools]);

  const columns = useMemo(
    () => [
      {
        name: 'tool_group_name',
        label: t('tool.group'),
        width: '13%',
        sortable: true,
      },
      {
        name: 'name',
        label: t('tool.name'),
        width: '13%',
        sortable: false,
      },
      {
        name: 'description',
        label: t('tool.explanation'),
        width: '59%',
        sortable: true,
      },
      {
        name: 'is_visible',
        label: t('tool.isVisible'),
        width: '15%',
        format: (value: any) => (value === false ? t('unused') : t('used')),
      },
    ],
    [t]
  );

  return (
    <BaseTable
      setOpenDynamicDialog={setOpenDialog}
      columns={columns}
      paginationSettingAtom={toolListPaginationAtom}
      fieldSettingAtom={toolSettingDataAtom}
      getData={useToolSettings}
      hasCheckbox
      hasAddBtn
      handleDeleteMultiple={useToolDeleteMutation}
      keyField='id'
      addBtnLabel={t('tool.addTool')}
      popupConfirmTitle={t('toolDelete.title')}
      popupConfirmContent={t('toolDelete.message')}
      unit={t('piece')}
      deleteToastContent={t('toolDelete.success')}
    />
  );
};
