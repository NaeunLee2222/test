import BaseDetailsText from '@/modules/admin/components/Form/DetailsText/BaseDetailsText';
import { useToolSettings } from '@/modules/admin/hooks/useToolSettings';
import { ITool } from '@/modules/admin/types/tool';
import { useAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import styles from './Dialog.module.scss';

interface IProps {
  toolSettingData: ITool;
}

export const ToolView = ({ toolSettingData }: IProps) => {
  const { t } = useTranslation('admin');
  const [{ isRefetching, isFetching }] = useAtom(useToolSettings);

  return (
    <div className={styles.baseDialog}>
      <div className={styles.group}>
        <BaseDetailsText
          loading={isRefetching || isFetching}
          label={t('tool.group')}
          content={toolSettingData?.tool_group_name ?? ''}
          propsClassName={styles.toolDetailRow}
        />
        <BaseDetailsText
          loading={isRefetching || isFetching}
          label={t('tool.name')}
          content={toolSettingData?.name ?? ''}
          propsClassName={styles.toolDetailRow}
        />
        <BaseDetailsText
          loading={isRefetching || isFetching}
          label={t('tool.description')}
          content={toolSettingData?.description ?? ''}
          propsClassName={styles.toolDetailRow}
        />
        <BaseDetailsText
          loading={isRefetching || isFetching}
          label={t('tool.type')}
          content={toolSettingData?.type?.toUpperCase() ?? ''}
          propsClassName={styles.toolDetailRow}
        />
        <BaseDetailsText
          loading={isRefetching || isFetching}
          label={t('tool.isVisible')}
          propsClassName={styles.toolDetailRow}
          content={
            toolSettingData?.is_visible?.toString() === 'true'
              ? t('used')
              : t('unused')
          }
        />
      </div>
    </div>
  );
};
