import IconPlus from '@/assets/basic-icons/icon-plus-thin.svg?react';
import RefreshIcon from '@/assets/basic-icons/icon-refresh.svg?react';
import BaseInput from '@/modules/admin/components/Form/Inputs/BaseInput';
import BaseSearchSelect from '@/modules/admin/components/Form/Selects/SearchSelect';
import BaseSwitch from '@/modules/admin/components/Form/Switches/BaseSwitch';
import {
  toolGroupSettingDataAtom,
  toolSettingDataAtom,
  useToolDeleteMutation,
  useToolGroupMutation,
  useToolMutation,
  useToolSettings,
  useUpdateToolMutation,
  useUToolGroupRelationshipMutation,
} from '@/modules/admin/hooks/useToolSettings';
import { ITool, ToolSelectData, ToolType } from '@/modules/admin/types/tool';
import { useToolGroupList, useToolList } from '@/modules/agent/hooks/useAgent';
import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { BaseTextField } from '@/modules/core/components/common/BaseTextField';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { EButtonType } from '@/types/common';
import { sanitizeToolEndpoint } from '@/utils';
import { showSnackbar } from '@/utils/snackbarUtil';
import { Box } from '@mui/material';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { forwardRef, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import type { IDialog } from '../../types/user';
import styles from './ToolDialog.module.scss';
import { ToolView } from './ToolView';

interface IProps {
  dialogState: IDialog;
  setDialogState: ({ open, type }: IDialog) => void;
}

const viewStates = {
  view: 'view',
  edit: 'edit',
  add: 'add',
};

export const ToolDialog = forwardRef(
  ({ dialogState, setDialogState }: IProps, _ref) => {
    const { t } = useTranslation('admin');
    const methods = useForm();

    const [{ refetch: getTools }] = useAtom(useToolSettings);
    const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
    const [toolSettingData, setToolSettingData] = useAtom(toolSettingDataAtom);
    const [, setToolGroupSettingData] = useAtom(toolGroupSettingDataAtom);
    const [{ mutate: mutateToolGroup }] = useAtom(useToolGroupMutation);
    const [{ mutateAsync: mutateTool }] = useAtom(useToolMutation);
    const [{ mutateAsync: updateToolDetails }] = useAtom(useUpdateToolMutation);
    const [{ mutateAsync: updateTooRelationship }] = useAtom(
      useUToolGroupRelationshipMutation
    );
    const [{ mutate: mutateDeleteTool }] = useAtom(useToolDeleteMutation);
    const [submitting, setSubmitting] = useState(false);
    const toolGroupSearch = useState('');
    const toolSearch = useState('');
    const toolGroupObj = useState<ToolSelectData | null>(null);
    const toolObj = useState<ToolSelectData | null>(null);

    const handleClose = () => {
      setDialogState({ ...dialogState, open: false });
      methods.reset();
    };

    const toolType = methods.watch('type');
    const toolName = methods.watch('name');
    const toolDescription = methods.watch('description');
    const endpoint = methods.watch('endpoint');
    const toolGroupId = methods.watch('tool_group_id');

    const formValid = useMemo(
      () => !!toolType && !!toolName && !!toolGroupId,
      [toolGroupId, toolName, toolType]
    );

    const handleConfirm = async () => {
      if (submitting) return;
      setSubmitting(true);

      const sanitizedEndpoint = sanitizeToolEndpoint(endpoint);
      const finalData = {
        ...toolSettingData,
        ...methods.getValues(),
        id: toolObj[0]?.id as number,
        is_active: methods.getValues().is_active || false,
        endpoint: sanitizedEndpoint,
      };

      setToolSettingData(finalData);

      await updateTooRelationship(
        {
          callback: (isSuccess: boolean, response: any) => {
            const message =
              response?.data?.message ??
              (isSuccess
                ? t('tool.messages.updateToolGroupRelationshipSuccess')
                : t('tool.messages.updateToolGroupRelationshipFailure'));

            showSnackbar(message, isSuccess ? 'success' : 'error', 3);
            handleClose();
            getTools();
          },
        },
        {
          onSuccess: () => {
            setSubmitting(false);
          },
          onError: () => {
            setSubmitting(false);
          },
          onSettled: () => {
            setSubmitting(false);
          },
        }
      );
    };

    const handleUpdate = async () => {
      if (submitting) return;
      setSubmitting(true);

      const sanitizedEndpoint = sanitizeToolEndpoint(endpoint);
      const finalData = {
        ...toolSettingData,
        ...methods.getValues(),
        name: toolObj[0]?.name,
        is_active: methods.getValues().is_active || false,
        endpoint: sanitizedEndpoint,
        type: methods.getValues().type?.toLowerCase(),
      };

      setToolSettingData(finalData as ITool);

      await updateToolDetails(
        {
          callback: (
            isSuccess: boolean,
            response: {
              data?: { message?: string };
            }
          ) => {
            const message =
              response?.data?.message ??
              (isSuccess
                ? t('tool.messages.updateToolDetailsSuccess')
                : t('tool.messages.updateToolDetailsFailure'));
            showSnackbar(message, isSuccess ? 'success' : 'error', 3);
            handleClose();
            getTools();
          },
        },
        {
          onSuccess: () => {
            setSubmitting(false);
          },
          onError: () => {
            setSubmitting(false);
          },
          onSettled: () => {
            setSubmitting(false);
          },
        }
      );
    };

    const handleDelete = () => {
      setConfirmDialogData({ open: false });
      if (!toolSettingData?.id) return;

      mutateDeleteTool({
        selectedRows: [toolSettingData.id],
        callback: async (success) => {
          if (success) {
            showSnackbar(t('tool.messages.deleteToolSuccess'), 'success', 3, {
              vertical: 'bottom',
              horizontal: 'center',
            });
          } else {
            showSnackbar(t('tool.messages.deleteToolFailure'), 'error', 3, {
              vertical: 'bottom',
              horizontal: 'center',
            });
          }

          handleClose();
          await getTools();
        },
      });
    };

    const openConfirmDelete = () => {
      setConfirmDialogData({
        open: true,
        title: t('toolDelete.title'),
        contentText: t('toolDelete.message'),
        confirmText: t('toolDelete.confirmText'),
        handleConfirm: handleDelete,
        handleCancel: () => {
          setConfirmDialogData({
            open: false,
          });
        },
        type: EButtonType.DELETE,
      });
    };

    const renderTitle = () => {
      switch (dialogState.type) {
        case viewStates.view:
          return toolSettingData.name || t('tool.viewTool');
        case viewStates.edit:
          return t('tool.editTool');
        case viewStates.add:
          return t('tool.addTool');
        default:
          return '';
      }
    };

    const renderButtons = () => {
      switch (dialogState.type) {
        case viewStates.view:
          return (
            <div className='flexBetween'>
              <BaseButton
                buttonType='redLinked'
                className={cn(styles.btnStyles, styles.actionLinkRed)}
                onClick={openConfirmDelete}
              >
                <span>{t('delete')}</span>
              </BaseButton>
              <span className='flex' style={{ gap: '8px' }}>
                <BaseButton
                  buttonType='outlined'
                  className={cn(styles.btnStyles, styles.toDetailBtn)}
                  onClick={() => {
                    toolGroupObj[1]({
                      id: toolSettingData.tool_group_id,
                      name: toolSettingData.tool_group_name,
                    });
                    toolObj[1]({
                      id: toolSettingData.tool_id,
                      name: toolSettingData.name,
                    });
                    setDialogState({ open: true, type: 'edit' });
                  }}
                >
                  <span>{t('edit')}</span>
                </BaseButton>
              </span>
            </div>
          );
        case viewStates.edit:
          return (
            <div className='flexBetween'>
              <div />
              <span className='flex' style={{ gap: '8px' }}>
                <BaseButton
                  buttonType='outlined'
                  className={cn(styles.btnStyles, styles.toDetailBtn)}
                  onClick={() => setDialogState({ open: true, type: 'view' })}
                >
                  <span>{t('cancel')}</span>
                </BaseButton>
                <BaseButton
                  autoFocus
                  onClick={handleUpdate}
                  color='primary'
                  className={cn(styles.btnStyles, styles.saveBtn)}
                  disabled={!formValid}
                >
                  {submitting && (
                    <RefreshIcon
                      className={styles.iconSpin}
                      style={{ marginRight: '2px' }}
                    />
                  )}
                  <span> {t('editCheck')}</span>
                </BaseButton>
              </span>
            </div>
          );
        case viewStates.add:
          return (
            <div className='flexBetween'>
              <span />
              <span className='flex' style={{ gap: '8px' }}>
                <BaseButton
                  buttonType='outlined'
                  className={cn(styles.btnStyles, styles.toDetailBtn)}
                  onClick={handleClose}
                >
                  <span>{t('cancel')}</span>
                </BaseButton>
                <BaseButton
                  autoFocus
                  className={cn(styles.btnStyles, styles.saveBtn)}
                  onClick={handleConfirm}
                  color='primary'
                  disabled={!formValid}
                >
                  {submitting && (
                    <RefreshIcon
                      className={styles.iconSpin}
                      style={{ marginRight: '2px' }}
                    />
                  )}
                  <span> {t('registration')}</span>
                </BaseButton>
              </span>
            </div>
          );
        default:
          return null;
      }
    };

    useEffect(() => {
      renderButtons();
    }, [endpoint, toolDescription, toolName, toolType]);

    const onAfterSetTool = (value: any) => {
      methods.setValue('description', value?.description);
    };

    const handleCreateToolGroup = () => {
      toolGroupObj[1]({ name: toolGroupSearch[0] });
      toolGroupSearch[1]('');

      setToolGroupSettingData({
        name: toolGroupSearch[0],
        description: '',
      });

      try {
        mutateToolGroup({
          callback: async (isSuccess: boolean, response: any) => {
            const message =
              response?.data?.message ||
              (isSuccess ? t('tool.messages.createGroupSuccess') : '');

            showSnackbar(message, isSuccess ? 'success' : 'error', 3);

            methods.setValue('tool_group_id', response?.id);
          },
        });
      } catch (error) {
        console.error(error);
      }
    };

    const handleCreateTool = async () => {
      toolObj[1]({ name: toolSearch[0] });
      toolSearch[1]('');
      methods.setValue('description', '');
      setToolSettingData((prev) => ({
        ...prev,
        description: '',
      }));

      const sanitizedEndpoint = sanitizeToolEndpoint(endpoint);
      const finalData = {
        ...toolSettingData,
        ...methods.getValues(),
        name: toolSearch[0] as string,
        tool_group_id: methods.getValues('tool_group_id'),
        is_active: methods.getValues().is_active || false,
        endpoint: sanitizedEndpoint,
      };

      setToolSettingData(finalData);

      await mutateTool(
        {
          callback: (isSuccess: boolean, response: any) => {
            const message =
              response?.data?.message ??
              (isSuccess
                ? t('tool.messages.createMcpToolSuccess')
                : t('tool.messages.createMcpToolFailure'));

            toolObj[1]({ name: toolSearch[0], id: response?.id });
            methods.setValue('description', response?.description);
            methods.setValue('name', response?.name);

            showSnackbar(message, isSuccess ? 'success' : 'error', 3);
            setSubmitting(false);
          },
        },
        {
          onSuccess: () => {
            setSubmitting(false);
          },
          onError: () => {
            setSubmitting(false);
          },
          onSettled: () => {
            setSubmitting(false);
          },
        }
      );
    };

    return (
      <BaseDialog
        sx={{
          '.MuiPaper-root': {
            maxWidth: '600px',
            height: '652px',
          },
          '.MuiDialogContent-root': {
            maxHeight: '600px',
            overflow: 'auto',
          },
        }}
        open={dialogState.open}
        title={renderTitle()}
        handleClose={handleClose}
        paddingX={24}
        dialogTitleClassName={styles.dialogTitle}
        contentClassName={styles.userFormContainer}
        actionClassName={styles.actionButton}
        contentChildren={
          <>
            {dialogState.type === viewStates.view ? (
              <ToolView toolSettingData={toolSettingData} />
            ) : (
              <div
                className='flexColumn'
                style={{
                  gap: '16px',
                }}
              >
                <BaseSearchSelect
                  className={styles.toolCustomInput}
                  {...methods}
                  name='tool_group_id'
                  getData={useToolGroupList}
                  label={t('tool.group')}
                  defaultValue={
                    toolSettingData?.tool_group_id?.toString() ?? ''
                  }
                  placeholder={t('select')}
                  searchPlaceholder={t('tool.placeholders.searchToolGroups')}
                  rules={{
                    required: { value: true, message: t('errors.required') },
                  }}
                  noDataPrefix={<IconPlus />}
                  noDataNode={
                    <div>
                      {t('addNew')} {toolGroupSearch[0]}
                    </div>
                  }
                  noDataAction={handleCreateToolGroup}
                  searchState={toolGroupSearch}
                  selectedItem={toolGroupObj}
                />

                <div className={styles.groupInput}>
                  <BaseSearchSelect
                    className={styles.toolCustomInput}
                    {...methods}
                    name='name'
                    getData={useToolList}
                    label={t('tool.name')}
                    defaultValue={toolSettingData?.name}
                    placeholder={t('select')}
                    searchPlaceholder={t('tool.placeholders.searchTools')}
                    disabled={methods.getValues('tool_group_id') === ''}
                    rules={{
                      required: {
                        value: true,
                        message: t('errors.required'),
                      },
                    }}
                    onAfterSetValue={(_, value) => onAfterSetTool(value)}
                    noDataPrefix={<IconPlus />}
                    noDataNode={
                      <div>
                        {t('addNew')} {toolSearch[0]}
                      </div>
                    }
                    noDataAction={handleCreateTool}
                    searchState={toolSearch}
                    selectedItem={toolObj}
                  />
                  <Box>
                    <BaseInput
                      className={styles.toolCustomInput}
                      {...methods}
                      name='description'
                      defaultValue={toolSettingData?.description}
                      placeholder={t('tool.placeholders.description')}
                      rules={{
                        required: {
                          value: true,
                          message: t('errors.required'),
                        },
                      }}
                      disabled={!toolName}
                    />
                  </Box>
                </div>

                <div className={styles.groupInput}>
                  <BaseInput
                    className={styles.toolCustomInput}
                    readonly
                    {...methods}
                    name='type'
                    label={t('tool.type')}
                    defaultValue={
                      toolSettingData?.type?.toUpperCase() ?? ToolType.MCP
                    }
                    placeholder={t('select')}
                    rules={{
                      required: {
                        value: true,
                        message: t('errors.required'),
                      },
                    }}
                  />
                  {toolType === ToolType.MCP.toString() && (
                    <BaseInput
                      {...methods}
                      name='endpoint'
                      rows={6}
                      defaultValue={toolSettingData?.endpoint}
                      placeholder={t('tool.placeholders.endpoint')}
                      rules={{
                        required: {
                          value: true,
                          message: t('errors.required'),
                        },
                      }}
                    />
                  )}
                  {toolType === ToolType.Source.toString() && (
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                      }}
                    >
                      <div className={styles.textAreaInput}>
                        <BaseTextField
                          required={dialogState.type === viewStates.edit}
                          className={cn(styles.textFieldTextarea)}
                          disabled={false}
                          multiline
                          fullWidth
                          name='source_code'
                          defaultValue={toolSettingData?.source_code}
                          sx={{
                            '> *.MuiInputBase-root': {
                              'textarea': {
                                minHeight: '144px',
                                paddingTop: '10px',
                                paddingLeft: '8px',
                              },
                            },
                          }}
                          placeholder={t('tool.placeholders.sourceCode')}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <BaseSwitch
                  {...methods}
                  label={t('tool.isVisible')}
                  name='is_visible'
                  defaultValue={toolSettingData?.is_visible ?? true}
                  rules={{
                    required: {
                      value: true,
                      message: t('errors.required'),
                    },
                  }}
                />
              </div>
            )}
          </>
        }
        actionsChildren={renderButtons()}
      />
    );
  }
);

ToolDialog.displayName = 'ToolDialog ';
