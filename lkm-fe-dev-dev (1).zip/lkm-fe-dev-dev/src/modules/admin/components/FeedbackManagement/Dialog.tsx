import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { formatDateToKst } from '@/utils';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
  fieldSettingAtom,
  paginationSettingAtom,
} from '../../hooks/useFeedbackSettings';
import BaseDetailsText from '../Form/DetailsText/BaseDetailsText';
import styles from './Dialog.module.scss';

interface IProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

export const FeedbackDialog = ({ open, setOpen }: IProps) => {
  const { t } = useTranslation('admin');
  const navigate = useNavigate();
  const handleClose = () => {
    setOpen(false);
  };

  const [feedbackSettingData] = useAtom(fieldSettingAtom);
  const [feedbackPaginationData] = useAtom(paginationSettingAtom);
  const {
    create_dt,
    user_name,
    version,
    flag,
    comment,
    question,
    answer,
    history_id,
  } = feedbackSettingData;

  return (
    <BaseDialog
      open={open}
      title={t('feedback')}
      handleClose={handleClose}
      sx={{
        '.MuiPaper-root': {
          maxWidth: '784px',
        },
        '.MuiDialogContent-root': {
          border: 'none',
          paddingBottom: '24px',
          overflow: 'auto',
        },
      }}
      contentChildren={
        <div className={styles.baseDialog}>
          <div
            className={styles.group}
            style={{
              marginBottom: '16px',
            }}
          >
            <BaseDetailsText
              label={t('date')}
              content={
                create_dt ? formatDateToKst(create_dt, 'YYYY-MM-DD, HH:mm') : ''
              }
            />
            <BaseDetailsText label={t('version')} content={version || ''} />
            <BaseDetailsText label={t('name')} content={user_name || ''} />
            <BaseDetailsText
              label={t('feedback')}
              content={_.isEqual(flag, 1) ? t('like') : t('dislike')}
            />
            <BaseDetailsText label={t('comment')} content={comment || ''} />
          </div>

          <div className={styles.group}>
            <BaseDetailsText
              label={t('originHistory')}
              content=''
              extraContent={
                history_id && history_id !== -1 ? (
                  <span
                    role='presentation'
                    style={{
                      color: 'var(--primary-color-500)',
                      textDecoration: 'underline',
                      cursor: 'pointer',
                    }}
                    onClick={() => {
                      handleClose();
                      navigate(
                        `/settings/history?historyId=${history_id}&company=${feedbackPaginationData.company}`
                      );
                    }}
                  >
                    {t('redirect')}
                  </span>
                ) : (
                  ''
                )
              }
            />
            <BaseDetailsText label={t('question')} content={question || ''} />
            <BaseDetailsText label={t('answer')} content={answer || ''} />
          </div>
        </div>
      }
    />
  );
};
