import { useTranslation } from 'react-i18next';
import { useState } from 'react';
import styles from '../../styles/AdminMain.module.scss';
import { FeedbackTable } from './Table';
import { FeedbackDialog } from './Dialog';
import { FormSearch } from './FormSearch';

export const FeedbackMain = () => {
  const { t } = useTranslation('admin');
  const [dialogOpen, setOpenDialog] = useState(false);

  return (
    <div className={styles.adminMain} data-testid='feedback-main'>
      <h1 className={styles.pageTitle}>{t('feedback')}</h1>
      <div className={styles.content} data-testid='content-container'>
        <FormSearch />
        <FeedbackTable setOpenDialog={setOpenDialog} />
        <FeedbackDialog open={dialogOpen} setOpen={setOpenDialog} />
      </div>
    </div>
  );
};
