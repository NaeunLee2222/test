import { useTranslation } from 'react-i18next';
import { Dispatch, SetStateAction, useMemo } from 'react';
import _ from 'lodash';
import { formatDateToKst } from '@/utils';
import { BaseTable } from '../Table/BaseTable';
import {
  paginationSettingAtom,
  fieldSettingAtom,
  getData,
  downloadExcelMutation,
} from '../../hooks/useFeedbackSettings';

interface IFeedbackTable {
  setOpenDialog: Dispatch<SetStateAction<boolean>>;
}

export const FeedbackTable = ({ setOpenDialog }: IFeedbackTable) => {
  const { t } = useTranslation('admin');

  const columns = useMemo(
    () => [
      {
        name: 'create_dt',
        label: t('date'),
        width: '14%',
        sortable: true,
        format: (value: string) => formatDateToKst(value, 'YYYY-MM-DD'),
      },
      { name: 'version', label: t('version'), width: '14%', sortable: true },
      { name: 'user_name', label: t('name'), width: '14%' },
      {
        name: 'flag',
        label: t('feedback'),
        width: '12%',
        format: (value: string) =>
          _.isEqual(value, 1) ? t('like') : t('dislike'),
      },
      { name: 'comment', label: t('comment'), width: '46%' },
    ],
    [t]
  );

  return (
    <BaseTable
      setOpenDialog={setOpenDialog}
      columns={columns}
      paginationSettingAtom={paginationSettingAtom}
      fieldSettingAtom={fieldSettingAtom}
      getData={getData}
      downloadExcelMutation={downloadExcelMutation}
      hasCheckbox
    />
  );
};
