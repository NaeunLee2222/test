import InfoIcon from '@/assets/basic-icons/icon-info.svg?react';
import BarChartIconSrc from '@/assets/chart-icons/bar-chart-icon.svg';
import LineChartIconSrc from '@/assets/chart-icons/line-chart-icon.svg';
import DownArrowIcon from '@/assets/direction-icons/icon-caret-down.svg?react';
import UpArrowIcon from '@/assets/direction-icons/icon-caret-up.svg?react';
import { getReportChart } from '@/modules/admin/hooks/useDashboardSettings';
import dashboardStyles from '@/modules/admin/styles/Dashboard.module.scss';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import { Grid } from '@mui/material';
import ReactECharts from 'echarts-for-react';
import { useAtom } from 'jotai';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

const ReportCard = () => {
  const { t } = useTranslation('admin');
  const [{ data }] = useAtom(getReportChart);
  const [currentData, setCurrentData] = useState<any>([]);
  const [option, setOption] = useState({});

  useEffect(() => {
    setOption({
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          crossStyle: {
            color: '#999',
          },
          label: {
            backgroundColor: '#1a1a1a',
          },
        },
        backgroundColor: '#fff',
        textStyle: {
          color: '#1a1a1a',
        },
        borderWidth: 1,
        borderColor: '#ccc',
        padding: [5, 10],
        formatter: (params: any) => {
          const barValue = params[0].value;
          const lineValue = params[1].value;
          const date = params[0].axisValue;

          return `
          <div style="text-align: left">
            ${date}<br />
            <img src="${BarChartIconSrc}" alt="Line Chart" style="width: 20px; height: 20px; margin-right: 8px; display: inline-block; vertical-align: bottom;" />
            <span style="font-weight: 400; font-size: 13px">${t('dashboard.cardCreation')}</span> <span style="font-weight: 500; font-size: 13px">${barValue}</span><br />
            <img src="${LineChartIconSrc}" alt="Line Chart" style="width: 20px; height: 20px; margin-right: 8px; display: inline-block; vertical-align: bottom;" />
            <span style="font-weight: 400; font-size: 13px">${t('dashboard.cardExport')}</span> <span style="font-weight: 500; font-size: 13px">${lineValue}</span>
          </div>
        `;
        },
      },
      legend: {
        show: false,
      },
      grid: {
        top: '15%',
        left: '3.5%',
        right: '3.5%',
        bottom: '5%',
        containLabel: true,
      },
      xAxis: [
        {
          type: 'category',
          data: currentData?.xAxisData,
          axisPointer: {
            type: 'shadow',
          },
          axisLabel: {
            fontSize: 12,
          },
        },
      ],
      yAxis: [
        {
          type: 'value',
          min: 0,
          axisLabel: {
            fontSize: 12,
          },
          splitLine: {
            show: true,
            lineStyle: {
              type: 'dashed',
            },
          },
        },
      ],
      series: [
        {
          name: t('dashboard.cardCreation'),
          type: 'bar',
          data: currentData?.yAxisCreatedCardData,
          itemStyle: {
            color: '#5C7CFA',
          },
          barWidth: 14,
        },
        {
          name: t('dashboard.cardExport'),
          type: 'line',
          data: currentData?.yAxisExportCardData,
          symbolSize: 4,
          itemStyle: {
            color: '#434343',
          },
          lineStyle: {
            type: 'dotted',
            cap: 'butt',
          },
        },
      ],
    });
  }, [currentData, t]);

  useEffect(() => {
    setCurrentData({
      xAxisData: data?.chart?.data_list.map((item: any) => item.time),
      yAxisCreatedCardData: data?.chart?.data_list.map(
        (item: any) => item.total_created_card
      ),
      yAxisExportCardData: data?.chart?.data_list.map(
        (item: any) => item.total_export_card
      ),
    });
  }, [data]);

  return (
    <div className={dashboardStyles.reportCard}>
      <div className={dashboardStyles.cardHeader}>
        <div className={dashboardStyles.title}>{t('dashboard.report')}</div>
      </div>
      <div className={dashboardStyles.cardBody}>
        <ReactECharts
          option={option}
          style={{ height: '200px', width: '100%' }}
        />

        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 6 }}>
            <div className={dashboardStyles.infoCard}>
              <div className={dashboardStyles.label}>
                <span style={{ height: '18px' }}>
                  <img src={BarChartIconSrc} draggable={false} />
                </span>
                <span className={dashboardStyles.text}>
                  {t('dashboard.cardCreation')}
                </span>
                <BaseTooltip
                  title={t('dashboard.cardCreationTooltip')}
                  arrow
                  placement='top'
                >
                  <div className={dashboardStyles.tooltip}>
                    <InfoIcon />
                  </div>
                </BaseTooltip>
              </div>
              <div className={dashboardStyles.value}>
                <span className={dashboardStyles.total}>
                  {data?.card_information?.total_created_card}
                </span>
                <span className={dashboardStyles.percentage}>
                  {data?.card_information?.created_card_percentage_change}%
                </span>
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {(data?.card_information?.created_card_percentage_change ??
                    0) > 0 ? (
                    <UpArrowIcon
                      fill='var(--green-700)'
                      width='16'
                      height='7'
                    />
                  ) : (
                    <DownArrowIcon
                      fill='var(--primitives-red-70)'
                      width='16'
                      height='7'
                    />
                  )}
                </span>
              </div>
            </div>
          </Grid>

          <Grid size={{ xs: 12, sm: 6 }}>
            <div className={dashboardStyles.infoCard}>
              <div className={dashboardStyles.label}>
                <span style={{ height: '23px' }}>
                  <img
                    src={LineChartIconSrc}
                    alt='Line Chart'
                    draggable={false}
                  />
                </span>
                <span className={dashboardStyles.text}>
                  {t('dashboard.cardExport')}
                </span>
                <BaseTooltip
                  title={t('dashboard.cardExportTooltip')}
                  arrow
                  placement='top'
                >
                  <div className={dashboardStyles.tooltip}>
                    <InfoIcon />
                  </div>
                </BaseTooltip>
              </div>
              <div className={dashboardStyles.value}>
                <span className={dashboardStyles.total}>
                  {data?.card_information?.total_export_card || '-'}
                </span>
                <span className={dashboardStyles.percentage}>
                  {data?.card_information?.export_card_percentage_change}%
                </span>
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {(data?.card_information?.export_card_percentage_change ??
                    0) > 0 ? (
                    <UpArrowIcon
                      fill='var(--green-700)'
                      width='16'
                      height='7'
                    />
                  ) : (
                    <DownArrowIcon
                      fill='var(--primitives-red-70)'
                      width='16'
                      height='7'
                    />
                  )}
                </span>
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    </div>
  );
};

export default ReportCard;
