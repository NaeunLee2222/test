import {
  getDocumentChart,
  paramsAtom,
} from '@/modules/admin/hooks/useDashboardSettings';
import dashboardStyles from '@/modules/admin/styles/Dashboard.module.scss';
import { convertDateToUrlParams } from '@/utils';
import cn from 'classnames';
import ReactECharts from 'echarts-for-react';
import { useAtom } from 'jotai';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

interface IData {
  value: number | undefined;
  successValue: number | undefined;
  inprogressValue: number | undefined;
  failValue: number | undefined;
  name: string;
  itemStyle: { color: string };
}

const DocumentChart = ({ showMore = true }: { showMore?: boolean }) => {
  const { t } = useTranslation('admin');
  const navigate = useNavigate();
  const [{ data: chartData }] = useAtom(getDocumentChart);
  const [params] = useAtom(paramsAtom);
  const [currentData, setCurrentData] = useState<any>([]);
  const [option, setOption] = useState({});

  const handleClick = () => {
    const queryParams = convertDateToUrlParams(params);

    navigate(`/settings/document-external?${queryParams}`);
  };

  const renderDotColor = (index: number) => {
    switch (index) {
      case 0:
        return dashboardStyles.law;
      case 1:
        return dashboardStyles.interpretation;
      case 2:
        return dashboardStyles.judicial;
      case 3:
        return dashboardStyles.others;
      default:
        return dashboardStyles.others;
    }
  };

  useEffect(() => {
    const {
      collect_law,
      other,
      collect_judicial_precedent,
      collect_legal_interpretation,
    } = chartData || {};

    setCurrentData([
      {
        value: collect_law?.total,
        successValue: collect_law?.succeeded,
        inprogressValue: collect_law?.in_progress,
        failValue: collect_law?.failed,
        name: t('dashboard.law'),
        itemStyle: {
          color: '#4C6EF5',
          borderType: 'solid',
          borderColor: 'white',
          borderWidth: 2,
        },
      },
      {
        value: collect_legal_interpretation?.total,
        successValue: collect_legal_interpretation?.succeeded,
        inprogressValue: collect_legal_interpretation?.in_progress,
        failValue: collect_legal_interpretation?.failed,
        name: t('dashboard.interpretationExample'),
        itemStyle: {
          color: '#9254DE',
          borderType: 'solid',
          borderColor: 'white',
          borderWidth: 2,
        },
      },
      {
        value: collect_judicial_precedent?.total,
        successValue: collect_judicial_precedent?.succeeded,
        inprogressValue: collect_judicial_precedent?.in_progress,
        failValue: collect_judicial_precedent?.failed,
        name: t('dashboard.judicialPrecedent'),
        itemStyle: {
          color: '#BAC8FF',
          borderType: 'solid',
          borderColor: 'white',
          borderWidth: 2,
        },
      },
      {
        value: other?.total,
        successValue: other?.succeeded,
        inprogressValue: other?.in_progress,
        failValue: other?.failed,
        name: t('dashboard.others'),
        itemStyle: {
          color: '#7F7F7F',
          borderType: 'solid',
          borderColor: 'white',
          borderWidth: 2,
        },
      },
    ]);
  }, [chartData]);

  useEffect(() => {
    const total = chartData?.total || 0;

    const totalSuccessRate = (
      (currentData.reduce(
        (acc: number, item: IData) => acc + (item.successValue ?? 0),
        0
      ) /
        total) *
      100
    ).toFixed(0);

    setOption({
      tooltip: {
        trigger: 'item',
        formatter: (tooltipParams: any) => {
          const { value, data: itemData } = tooltipParams;

          return `<div style="font-size: 14px; color: black; text-align: left">
            <span style="font-size: 16px; font-weight: 500">${value} 건</span><br/>
            <div style="display: flex; align-items: center; margin-top: 5px;">
              성공: ${itemData.successValue}
            </div>
            <div style="display: flex; align-items: center;">
              수집중: ${itemData.inprogressValue}
            </div>
            <div style="display: flex; align-items: center;">
              미처리:&nbsp<span style="color: #F5222D">${itemData.failValue}</span>
            </div>
            </div>`;
        },
        backgroundColor: '#fff',
        textStyle: {
          color: 'black',
        },
        borderWidth: 1,
        borderColor: '#4C6EF5',
        padding: [5, 10],
      },
      legend: {
        show: false,
      },
      series: [
        {
          name: '문서 수집',
          type: 'pie',
          radius: ['55%', '90%'],
          avoidLabelOverlap: false,
          label: {
            show: false,
          },
          labelLine: {
            show: false,
          },
          data: currentData,
        },
        {
          type: 'pie',
          radius: ['0%', '0%'],
          label: {
            show: true,
            position: 'center',
            formatter: [
              `{total|${total}}{unit|건}`,
              `{additional|전체 성공률 ${totalSuccessRate}%}`,
            ].join('\n'),
            rich: {
              total: {
                fontSize: '26px',
                fontWeight: 'bold',
                color: 'black',
              },
              additional: {
                fontSize: '12px',
                color: '#7F7F7F',
              },
              unit: {
                fontSize: '12px',
                fontWeight: 'normal',
                color: 'black',
              },
            },
          },
          data: [{ value: total }],
          silent: true,
        },
      ],
    });
  }, [currentData]);

  return (
    <div className={dashboardStyles.documentChart}>
      <div className={dashboardStyles.cardHeader}>
        <div className={dashboardStyles.title}>{t('dashboard.document')}</div>
        {showMore && (
          <button
            className={dashboardStyles.seeMoreBtn}
            onClick={handleClick}
            type='button'
            tabIndex={0}
          >
            {t('seeMore')}
          </button>
        )}
      </div>
      <div
        className={dashboardStyles.cardBody}
        style={{ height: 'calc(100% - 48px)' }}
      >
        <div className={dashboardStyles.container}>
          {chartData && (
            <ReactECharts
              option={option}
              style={{ height: '360px', width: '360px' }}
            />
          )}

          <div className={dashboardStyles.legendContainer}>
            {currentData.map((item: IData, index: number) => (
              <div key={index} className={dashboardStyles.legendItem}>
                <div
                  className={cn(dashboardStyles.dot, renderDotColor(index))}
                />
                <div className={dashboardStyles.legendLabel}>
                  <div className={dashboardStyles.processedText}>
                    {item.name}
                  </div>
                  <div className={dashboardStyles.unprocessedText}>미처리</div>
                  <div className={dashboardStyles.unprocessedText}>성공률</div>
                </div>
                <div
                  className={cn(
                    dashboardStyles.legendValue,
                    dashboardStyles.text
                  )}
                >
                  <div className={dashboardStyles.processedText}>
                    {item.value}&nbsp;건
                  </div>
                  <div className={dashboardStyles.unprocessedText}>
                    <span
                      style={{
                        color:
                          (item.failValue || item.inprogressValue) &&
                          (item.failValue ?? 0) + (item.inprogressValue ?? 0) >
                            0
                            ? '#F03E3E'
                            : 'inherit',
                      }}
                    >
                      {(item.failValue ?? 0) + (item.inprogressValue ?? 0)}
                    </span>
                    &nbsp;건
                  </div>
                  <div className={dashboardStyles.unprocessedText}>
                    {(
                      ((item.successValue ?? 0) /
                        ((item.value ?? 0) === 0 ? 1 : (item.value ?? 0))) *
                      100
                    ).toFixed(2)}
                    &nbsp;%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentChart;
