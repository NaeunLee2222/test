import { useTranslation } from 'react-i18next';
import { Grid } from '@mui/material';
import { MobileExpandButton } from '@/modules/core/layout/Responsive/MobileExpandButton';
import { useUserMe } from '@/modules/core/hooks';
import { useAtom } from 'jotai';
import styles from '../../styles/AdminMain.module.scss';
import dashboardStyles from '../../styles/Dashboard.module.scss';
import ExpenseTabs from './Expense/Tabs';
import { FormSearch } from './FormSearch';
import DocumentChart from './Document';
import FeedbackCard from './Feedback';
import ReportCard from './Report';
import { CompanyFilter } from './CompanyFilter';

export const DashboardMain = () => {
  const { t } = useTranslation('admin');
  const [{ data: userData }] = useAtom(useUserMe);

  const isSuperAdmin = userData?.role?.includes('superadmin');

  return (
    <div className={styles.adminMain}>
      <div className={dashboardStyles.headerLayout}>
        <span className='flex'>
          <MobileExpandButton
            sx={{
              padding: 0,
            }}
          />
          <h1 className={dashboardStyles.pageTitle}>{t('dashboard.title')}</h1>
        </span>
        <FormSearch />
      </div>
      <div className={dashboardStyles.content}>
        <CompanyFilter />
        <ExpenseTabs showMore={isSuperAdmin} />
        <Grid container spacing={3} style={{ marginTop: '0' }}>
          <Grid size={{ xs: 12, md: 6 }}>
            <DocumentChart />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <Grid container spacing={3}>
              <Grid size={{ xs: 12 }}>
                <FeedbackCard showMore={isSuperAdmin} />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <ReportCard />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </div>
    </div>
  );
};
