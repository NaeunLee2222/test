import { RangeDatePicker } from '@/modules/core/components/common/DatePicker/RangeDatePicker';
import { getKstTimestampBySelectedDate } from '@/utils';
import { ToggleButton, ToggleButtonGroup } from '@mui/material';
import dayjs from 'dayjs';
import localeData from 'dayjs/plugin/localeData';
import weekday from 'dayjs/plugin/weekday';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useState } from 'react';
import { paramsAtom } from '../../hooks/useDashboardSettings';
import dashboardStyles from '../../styles/Dashboard.module.scss';

dayjs.extend(weekday);
dayjs.extend(localeData);

export const FormSearch = () => {
  const now = dayjs();
  const last7Days = dayjs().subtract(6, 'day');
  const [selectedDate, setSelectedDate] = useState([last7Days, now]);
  const [value, setValue] = useState('주');
  const [, setPage] = useAtom(paramsAtom);

  const handleSearch = () => {
    const dateStr = getKstTimestampBySelectedDate(selectedDate);
    const urlParams = new URLSearchParams(dateStr);

    const startDate = urlParams.get('startDate') || '';
    const endDate = urlParams.get('endDate') || '';

    setPage((prev) => ({ ...prev, startDate, endDate }));
  };

  const handleChangeDate = async (date: any) => {
    if (date && _.size(date) > 1) {
      const startDate = date[0] || '';
      const endDate = date[1] || '';

      setSelectedDate([dayjs(startDate), dayjs(endDate)]);
    }
  };

  const onChange = (
    _event: React.MouseEvent<HTMLElement>,
    selectedValue: string
  ) => {
    if (selectedValue !== null) {
      setValue(selectedValue);

      switch (selectedValue) {
        case '일':
          setSelectedDate([now, now]);
          break;
        case '주':
          setSelectedDate([last7Days, now]);
          break;
        case '월':
          setSelectedDate([dayjs().subtract(30, 'day'), now]);
          break;
        default:
          break;
      }
    }
  };

  useEffect(() => {
    handleSearch();
  }, [selectedDate]);

  return (
    <div className={dashboardStyles.formSearch}>
      <ToggleButtonGroup
        value={value}
        exclusive
        onChange={onChange}
        aria-label='date range'
        sx={{
          marginRight: '12px',
          '& .MuiToggleButtonGroup-grouped': {
            backgroundColor: 'transparent',
            border: 'none',
            borderRadius: '4px',
            padding: '10px 12px',
            fontSize: '16px',
            fontWeight: 500,
            color: 'var(--gray-900)',
            '&:hover': {
              backgroundColor: 'transparent !important',
            },
            '&.Mui-selected': {
              backgroundColor: 'transparent',
              color: 'var(--primary-color-600)',
              fontWeight: 600,
            },
          },
        }}
      >
        <ToggleButton value='일'>일</ToggleButton>
        <ToggleButton value='주'>주</ToggleButton>
        <ToggleButton value='월'>월</ToggleButton>
      </ToggleButtonGroup>
      <div
        className={dashboardStyles.inputDate}
        style={{ display: 'flex', justifyContent: 'space-between' }}
      >
        <RangeDatePicker
          className={dashboardStyles.dateRangePicker}
          onConfirm={(date: any) => handleChangeDate(date)}
          defaultValue={selectedDate}
          placement='bottomEnd'
        />
      </div>
    </div>
  );
};
