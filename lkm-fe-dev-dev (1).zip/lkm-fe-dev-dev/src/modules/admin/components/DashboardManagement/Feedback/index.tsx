import DislikeIcon from '@/assets/basic-icons/icon-dislike.svg?react';
import LikeIcon from '@/assets/basic-icons/icon-like.svg?react';
import DownArrowIcon from '@/assets/direction-icons/icon-caret-down.svg?react';
import UpArrowIcon from '@/assets/direction-icons/icon-caret-up.svg?react';
import {
  getFeedbackInfo,
  paramsAtom,
} from '@/modules/admin/hooks/useDashboardSettings';
import dashboardStyles from '@/modules/admin/styles/Dashboard.module.scss';
import { convertDateToUrlParams } from '@/utils';
import { Grid } from '@mui/material';
import { useAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

const FeedbackCard = ({ showMore = true }: { showMore?: boolean }) => {
  const { t } = useTranslation('admin');
  const navigate = useNavigate();
  const [{ data }] = useAtom(getFeedbackInfo);
  const [params] = useAtom(paramsAtom);

  const handleClick = () => {
    const queryParams = convertDateToUrlParams(params);

    navigate(`/settings/feedback?${queryParams}`);
  };

  return (
    <>
      <div className={dashboardStyles.cardHeader}>
        <div className={dashboardStyles.title}>{t('feedback')}</div>
        {showMore && (
          <button
            className={dashboardStyles.seeMoreBtn}
            onClick={handleClick}
            type='button'
            tabIndex={0}
          >
            {t('seeMore')}
          </button>
        )}
      </div>
      <div className={dashboardStyles.cardBody}>
        <Grid container spacing={3}>
          <Grid size={{ xs: 12, sm: 6 }}>
            <div className={dashboardStyles.feedbackCard}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <span className={dashboardStyles.icon}>
                  <LikeIcon />
                </span>
                <span className={dashboardStyles.text}>{t('like')}</span>
              </div>
              <div className={dashboardStyles.value}>
                <span className={dashboardStyles.total}>
                  {data?.total_like}
                </span>
                <span className={dashboardStyles.percentage}>
                  {data?.like_percentage_change}%
                </span>
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {(data?.like_percentage_change ?? 0) > 0 ? (
                    <UpArrowIcon
                      fill='var(--green-700)'
                      width='16'
                      height='7'
                    />
                  ) : (
                    <DownArrowIcon
                      fill='var(--primitives-red-70)'
                      width='16'
                      height='7'
                    />
                  )}
                </span>
              </div>
            </div>
          </Grid>
          <Grid size={{ xs: 12, sm: 6 }}>
            <div className={dashboardStyles.feedbackCard}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <span className={dashboardStyles.icon}>
                  <DislikeIcon />
                </span>
                <span className={dashboardStyles.text}>{t('dislike')}</span>
              </div>
              <div className={dashboardStyles.value}>
                <span className={dashboardStyles.total}>
                  {data?.total_dislike}
                </span>
                <span className={dashboardStyles.percentage}>
                  {data?.dislike_percentage_change}%
                </span>
                <span
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {(data?.dislike_percentage_change ?? 0) > 0 ? (
                    <UpArrowIcon
                      fill='var(--green-700)'
                      width='16'
                      height='7'
                    />
                  ) : (
                    <DownArrowIcon
                      fill='var(--primitives-red-70)'
                      width='16'
                      height='7'
                    />
                  )}
                </span>
              </div>
            </div>
          </Grid>
        </Grid>
      </div>
    </>
  );
};

export default FeedbackCard;
