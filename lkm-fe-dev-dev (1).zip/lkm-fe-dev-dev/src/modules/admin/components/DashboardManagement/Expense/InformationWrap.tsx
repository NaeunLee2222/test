import { convertCost } from '@/utils';
import { useTranslation } from 'react-i18next';
import dashboardStyles from '../../../styles/Dashboard.module.scss';

interface InformationWrapProps {
  daily_average_ask_count: number;
  daily_average_cost: number;
  daily_average_user_count: number;
  total_ask_count: number;
  total_cost: number;
}

export const InformationWrap = ({
  data = {
    daily_average_ask_count: 0,
    daily_average_cost: 0,
    daily_average_user_count: 0,
    total_ask_count: 0,
    total_cost: 0,
  },
}: {
  data?: InformationWrapProps;
}) => {
  const { t } = useTranslation('admin');
  const {
    daily_average_ask_count,
    daily_average_cost,
    daily_average_user_count,
    total_ask_count,
    total_cost,
  } = data;

  return (
    <div className={dashboardStyles.InformationWrap}>
      <div className={dashboardStyles.items}>
        <div className={dashboardStyles.item}>
          <span className={dashboardStyles.subItemTop}>
            <span className={dashboardStyles.tl}>{t('userName')}</span>
            <span className={dashboardStyles.tr}>{t('dailyAverage')}</span>
          </span>
          <span className={dashboardStyles.subItemBottom}>
            <span className={dashboardStyles.nl}>
              {daily_average_user_count}
            </span>
          </span>
        </div>
        <div className={dashboardStyles.item}>
          <span className={dashboardStyles.subItemTop}>
            <span className={dashboardStyles.tl}>{t('numberOfQuestions')}</span>
            <span className={dashboardStyles.tr}>
              {`${t('dailyAverage/Total')} (${t('case')})`}
            </span>
          </span>
          <span className={dashboardStyles.subItemBottom}>
            <span className={dashboardStyles.nl}>
              {daily_average_ask_count}
            </span>
            <span className={dashboardStyles.slash}>/</span>
            <span className={dashboardStyles.nr}>{total_ask_count}</span>
          </span>
        </div>
        <div className={dashboardStyles.item}>
          <span className={dashboardStyles.subItemTop}>
            <span className={dashboardStyles.tl}>{t('usageFee')}</span>
            <span
              className={dashboardStyles.tr}
            >{`${t('dailyAverage/Total')} (${t('won')})`}</span>
          </span>
          <span className={dashboardStyles.subItemBottom}>
            <span className={dashboardStyles.nl}>
              {convertCost(daily_average_cost)}
            </span>
            <span className={dashboardStyles.slash}>/</span>
            <span className={dashboardStyles.nr}>
              {convertCost(total_cost)}
            </span>
          </span>
        </div>
      </div>
    </div>
  );
};
