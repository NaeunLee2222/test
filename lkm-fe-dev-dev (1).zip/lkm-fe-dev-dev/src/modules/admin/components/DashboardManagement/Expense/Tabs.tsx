import { paramsAtom } from '@/modules/admin/hooks/useDashboardSettings';
import dashboardStyles from '@/modules/admin/styles/Dashboard.module.scss';
import { convertDateToUrlParams } from '@/utils';
import { useAtom } from 'jotai';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import styles from '../../../styles/AdminMain.module.scss';
import { CustomTabPanel } from '../../TabProps';
import { GeneralAdvice } from './GeneralAdvice';
import { ProfessionalAdvice } from './ProfessionalAdvice';

const customTab = {
  p: '0 24px',
  backgroundColor: '#fff',
  borderEndEndRadius: '6px',
  borderEndStartRadius: '6px',
};

const ExpenseTabs = ({ showMore = true }: { showMore?: boolean }) => {
  const { t } = useTranslation('admin');
  const navigate = useNavigate();
  const [value] = useState(0);
  const [params] = useAtom(paramsAtom);

  const handleClick = () => {
    const queryParams = convertDateToUrlParams(params);

    navigate(`/settings/expense?${queryParams}`, {
      state: { type: value === 0 ? 'pro' : 'common' },
    });
  };

  return (
    <>
      <div className={dashboardStyles.cardHeader} style={{ marginTop: '24px' }}>
        <div className={dashboardStyles.title}>{t('taxAdvice')}</div>
        {showMore && (
          <button
            className={dashboardStyles.seeMoreBtn}
            onClick={handleClick}
            type='button'
            tabIndex={0}
          >
            {t('seeMore')}
          </button>
        )}
      </div>
      <CustomTabPanel value={value} index={0} sx={customTab}>
        <ProfessionalAdvice />
      </CustomTabPanel>
      <CustomTabPanel
        className={styles.proAdvice}
        value={value}
        index={1}
        sx={customTab}
      >
        <GeneralAdvice />
      </CustomTabPanel>
    </>
  );
};

export default ExpenseTabs;
