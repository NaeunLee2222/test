import { useTranslation } from 'react-i18next';
import ReactECharts from 'echarts-for-react';

interface IProps {
  askCountData?: any;
  timeData?: any;
  userData?: any;
  costData?: any;
}

export const Chart = ({
  askCountData = [],
  timeData = [],
  costData = [],
  userData = [],
}: IProps) => {
  const { t } = useTranslation('admin');
  const options = {
    grid: { top: 30, right: 35, bottom: 24, left: 35 },
    xAxis: {
      type: 'category',
      name: `(${t('case')})`,
      nameTextStyle: {
        color: '#1a1a1a',
      },
      data: timeData,
      boundaryGap: false,
      axisLabel: {
        color: '#1a1a1a',
      },
    },
    yAxis: {
      type: 'value',
      axisLabel: {
        fontSize: 12,
        color: '#1a1a1a',
      },
      name: t('numberOfQuestions(number)'),
      nameTextStyle: {
        color: '#1a1a1a',
      },
      splitLine: {
        lineStyle: {
          type: 'dashed',
          width: 1,
          color: '#DADADA',
        },
      },
    },
    series: [
      {
        data: askCountData,
        type: 'line',
        color: '#5C7CFA',
        symbol: 'circle',
        symbolSize: 8,
      },
    ],
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#fff',
      textStyle: {
        color: '#1A1A1A',
      },
      borderWidth: 1,
      borderColor: '#ccc',
      padding: [5, 10],
      formatter: (params: any) => {
        const date = params[0].axisValue;
        const dateIndex = timeData.indexOf(date);
        const user = userData[dateIndex] || 0;
        const askCount = askCountData[dateIndex] || 0;
        const cost = costData[dateIndex] || 0;

        return `
          <div style="font-size: 14px; color: #1A1A1A; font-family: Pretendard;">
            ${date}<br />
            <div style="display: flex; align-items: center; margin-top: 4px;">
              <div style="width: 8px; height: 8px; background-color: #5C7CFA; border-radius: 50%; margin-right: 4px;"></div>
              사용자<span style="font-weight: 500; margin-left: 8px">${user}</span>
            </div>
            <div style="display: flex; align-items: center; margin-top: 4px;">
              <div style="width: 8px; height: 8px; background-color: #5C7CFA; border-radius: 50%; margin-right: 4px;"></div>
              질문수<span style="font-weight: 500; margin-left: 8px">${askCount}</span>
            </div>
            <div style="display: flex; align-items: center; margin-top: 4px;">
              <div style="width: 8px; height: 8px; background-color: #5C7CFA; border-radius: 50%; margin-right: 4px;"></div>
              사용료<span style="font-weight: 500; margin-left: 8px">${cost}</span>
            </div>
          </div>
        `;
      },
    },
  };

  return (
    <ReactECharts option={options} style={{ height: '282px', width: '100%' }} />
  );
};
