import {
  getGeneralInfo,
  getUsageChart,
} from '@/modules/admin/hooks/useDashboardSettings';
import dashboardStyles from '@/modules/admin/styles/Dashboard.module.scss';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { Chart } from './Chart';
import { InformationWrap } from './InformationWrap';

export const GeneralAdvice = () => {
  const [{ data: totalAsk }] = useAtom(getUsageChart);
  const [{ data: generalInfo }] = useAtom(getGeneralInfo);

  const timeData: string[] = [];
  const askCountData: number[] = [];
  const costData: number[] = [];
  const userData: number[] = [];
  if (totalAsk && 'data_list' in totalAsk && _.size(totalAsk.data_list) > 0) {
    totalAsk.data_list.forEach(
      ({ time, total_ask_count, total_cost, total_user }) => {
        timeData.push(time);
        if (typeof total_ask_count === 'number') {
          askCountData.push(total_ask_count);
        }
        if (typeof total_cost === 'number') {
          costData.push(total_cost);
        }
        if (typeof total_user === 'number') {
          userData.push(total_user);
        }
        return null;
      }
    );
  }

  return (
    <div className={dashboardStyles.expenseContainer}>
      <div className={dashboardStyles.chart}>
        {!_.isEmpty(askCountData) && !_.isEmpty(timeData) && (
          <Chart
            askCountData={askCountData}
            costData={costData}
            userData={userData}
            timeData={timeData}
          />
        )}
      </div>
      <div className={dashboardStyles.cards}>
        {generalInfo && <InformationWrap data={generalInfo} />}
      </div>
    </div>
  );
};
