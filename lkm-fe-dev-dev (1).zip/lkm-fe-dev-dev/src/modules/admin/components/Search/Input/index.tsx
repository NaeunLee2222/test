import IconMagnify from '@/assets/basic-icons/icon-magnify.svg?react';
import { TextField, TextFieldProps } from '@mui/material';
import React, { Dispatch, SetStateAction } from 'react';
import styles from '../../../styles/AdminMain.module.scss';

const SearchInput = ({
  placeholder,
  setSearch,
  onKeyUp,
  maxLength = 100,
  search,
  ...props
}: {
  placeholder?: string;
  maxLength?: number;
  setSearch: Dispatch<SetStateAction<string>>;
  onKeyUp: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  search: string;
} & TextFieldProps) => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(event.target.value);
  };

  const handleOnKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
    }
  };

  return (
    <TextField
      id='search'
      variant='outlined'
      fullWidth
      className={styles.textField}
      inputProps={{
        maxLength,
      }}
      style={{ height: '32px' }}
      value={search}
      onKeyUp={onKeyUp}
      onKeyDown={handleOnKeyDown}
      onChange={handleChange}
      placeholder={placeholder}
      sx={{
        color: 'red',
        '.MuiInputBase-root': {
          borderRadius: '6px',
          paddingRight: '8px',
          'input': {
            padding: '6px 8px',
            height: '20px',
          },
          '&.Mui-focused': {
            '& svg': {
              fill: 'var(--primary-color-800)',
            },
          },
        },
        '& fieldset': {
          border: '1px solid var(--gray-150)',
        },
        '&:hover': {
          '&& fieldset': {
            border: '1px solid var(--primary-color-600)',
          },
        },
        '&.Mui-disabled': {
          backgroundColor: 'var(--gray-100)',
        },
        '&::placeholder': {
          color: 'red',
        },
        '&.Mui-focused': {
          '& .MuiOutlinedInput-notchedOutline': {
            border: '1px solid var(--primary-color-600)',
            boxShadow: '0px 0px 0px 2px #1890FF33',
          },
        },
      }}
      InputProps={{
        endAdornment: (
          <IconMagnify width='16' height='16' fill='var(--gray-600)' />
        ),
      }}
      {...props}
    />
  );
};

export default SearchInput;
