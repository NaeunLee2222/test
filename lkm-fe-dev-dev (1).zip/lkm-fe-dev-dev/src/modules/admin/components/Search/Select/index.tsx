import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import { Select, MenuItem, FormControl } from '@mui/material';
import { BaseMenuSx } from '@/modules/core/components/common/BaseMenu';
import styles from './Select.module.scss';

interface ISearchSelect {
  options: { value: string | number; label: string; disabled?: boolean }[];
  defaultValue?: string | number;
  value?: string | number;
  handleChange: (value: any) => void;
  height?: string;
  sx?: any;
}

const ArrowDownIconComponent = (props: any) => (
  <span
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
    }}
    {...props}
  >
    <ArrowDownIcon width='.7rem' height='0.5rem' />
  </span>
);

const SearchSelect = ({
  options,
  defaultValue,
  value,
  handleChange,
  height = '40px',
  sx,
}: ISearchSelect) => (
  <FormControl
    className={`${styles.customSelect} customSelect`}
    style={{ height, width: '100%', maxWidth: 200 }}
  >
    <Select
      defaultValue={defaultValue}
      value={value}
      onChange={(event) => handleChange(event.target.value)}
      IconComponent={ArrowDownIconComponent}
      size='small'
      displayEmpty
      fullWidth
      MenuProps={{
        sx: BaseMenuSx,
        PopoverClasses: {
          root: styles.customSelect,
        },
      }}
      sx={{
        height,
        '& fieldset': {
          border: '1px solid var(--gray-150)',
        },
        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
          borderColor: 'var(--primary-color-600)',
          borderWidth: '1px',
        },
        '&:hover': {
          '&& fieldset': {
            border: '1px solid var(--primary-color-600)',
          },
        },
        ...sx,
      }}
      className={styles.customSelectInput}
    >
      {options.map((option) => (
        <MenuItem key={option.value} value={option.value}>
          {option.label}
        </MenuItem>
      ))}
    </Select>
  </FormControl>
);

export default SearchSelect;
