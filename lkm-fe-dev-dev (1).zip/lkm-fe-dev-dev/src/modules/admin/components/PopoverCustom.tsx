import IconEllipsis from '@/assets/basic-icons/icon-ellipsis.svg?react';
import Button from '@mui/material/Button';
import Popover from '@mui/material/Popover';
import { useState } from 'react';

export const PopoverCustom = (props: { children: any }) => {
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button
        aria-describedby={id}
        size='small'
        variant='text'
        onClick={handleClick}
        sx={{
          height: '20px',
          width: '20px',
          minWidth: '20px',
          '&:hover': {
            backgroundColor: 'var(--gray-100)',
          },
          '&:active': {
            backgroundColor: 'var(--gray-200)',
          },
        }}
      >
        <IconEllipsis />
      </Button>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        className='popoverStyle popoverCustom'
        sx={{
          '.MuiPopover-paper': {
            minWidth: '100px',
            border: '1px solid #0000000D',
            '&:hover': {
              '.MuiTypography-root': {
                backgroundColor: 'var(--gray-100)',
              },
            },
          },
        }}
      >
        {props.children}
      </Popover>
    </div>
  );
};
