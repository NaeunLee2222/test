import IconAgent from '@/assets/basic-icons/icon-agent.svg?react';
import IconDashboard from '@/assets/basic-icons/icon-dashboard.svg?react';
import IconSuperAdmin from '@/assets/basic-icons/icon-super-admin.svg?react';
import IconToolManagement from '@/assets/basic-icons/icon-tool-management.svg?react';
import IconUsage from '@/assets/basic-icons/icon-usage.svg?react';
import IconUser from '@/assets/basic-icons/icon-user.svg?react';
import IconDown from '@/assets/direction-icons/icon-chevron-down.svg?react';
import { BaseTooltip } from '@/modules/core/components/common/Tooltip';
import lnbStyles from '@/modules/core/components/LNB/LNB.module.scss';
import { useUserMe } from '@/modules/core/hooks';
import { isOpenLnbAtom, isOpenSubMenu } from '@/modules/core/jotai/layout';
import { adminRouteChildren } from '@/routers/routerList';
import { RoutesURL } from '@/routers/routes';
import {
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import Collapse from '@mui/material/Collapse';
import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';
import cn from 'classnames';
import { useAtom } from 'jotai';
import _ from 'lodash';
import * as React from 'react';
import { useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation, useNavigate } from 'react-router-dom';

export const AdminMenu = () => {
  const [{ data: userData }] = useAtom(useUserMe);
  const { t } = useTranslation('tax');

  const allMenus = useMemo(
    () => [
      // Wait confirmation from customer
      // {
      //   text: t('menu.adminMenu.dashboard'),
      //   path: RoutesURL.SETTINGS_DASHBOARD,
      //   icon: <IconDashboard />,
      // },
      // {
      //   text: t('menu.adminMenu.chat'),
      //   icon: <IconChat />,
      //   subMenu: [
      //     {
      //       text: t('menu.adminMenu.history'),
      //       path: RoutesURL.SETTINGS_HISTORY,
      //     },
      //     {
      //       text: t('menu.adminMenu.feedback'),
      //       path: RoutesURL.SETTINGS_FEEDBACK,
      //     },
      //     {
      //       text: t('menu.adminMenu.question'),
      //       path: RoutesURL.SETTINGS_QUESTION,
      //     },
      //   ],
      // },
      // {
      //   text: t('menu.adminMenu.expense'),
      //   icon: <IconExpense />,
      //   subMenu: [
      //     {
      //       text: t('menu.adminMenu.checkCostStatus'),
      //       path: RoutesURL.SETTINGS_EXPENSE,
      //     },
      //     {
      //       text: t('menu.adminMenu.usageSettings'),
      //       path: RoutesURL.SETTINGS_EXPENSE_CONTROL,
      //     },
      //   ],
      // },
      {
        text: t('menu.adminMenu.dashboard'),
        path: RoutesURL.SETTINGS_DASHBOARD,
        icon: <IconDashboard />,
      },
      {
        text: t('menu.adminMenu.toolManagement'),
        path: RoutesURL.SETTINGS_TOOL_MANAGEMENT,
        icon: <IconToolManagement />,
      },
      {
        text: t('menu.adminMenu.agentManagement'),
        icon: <IconAgent />,
        subMenu: [
          {
            text: t('menu.adminMenu.agentRegistrationRequest'),
            path: RoutesURL.SETTINGS_AGENT_REGISTRATION_REQUEST,
          },
          {
            text: t('menu.adminMenu.agentOperationManagement'),
            path: RoutesURL.SETTINGS_AGENT_OPERATION_MANAGEMENT,
          },
        ],
      },
      {
        text: t('menu.adminMenu.user'),
        path: RoutesURL.SETTINGS_USER,
        icon: <IconUser />,
      },
      {
        text: t('menu.adminMenu.usageSettings'),
        path: RoutesURL.SETTINGS_USAGE,
        icon: <IconUsage />,
      },

      // Wait confirmation from customer
      // {
      //   text: t('menu.adminMenu.document'),
      //   icon: <IconDocument />,
      //   subMenu: [
      //     {
      //       text: t('menu.adminMenu.external'),
      //       path: RoutesURL.SETTINGS_DOCUMENT_EXTERNAL,
      //     },
      //     // {
      //     //   text: t('menu.adminMenu.internal'),
      //     //   path: '/settings/document-internal',
      //     // },
      //   ],
      // },
      {
        text: t('menu.adminMenu.superadmin'),
        icon: <IconSuperAdmin />,
        subMenu: [
          {
            text: t('menu.adminMenu.fewShot'),
            path: RoutesURL.SETTINGS_FEW_SHOT,
          },
          {
            text: t('menu.adminMenu.prompt'),
            path: RoutesURL.SETTINGS_PROMPT,
          },
        ],
      },
    ],
    [t]
  );

  const menus = useMemo(() => {
    const adminMenus: {
      text: string;
      path?: string;
      icon?: React.ReactNode;
      subMenu?: any[];
    }[] = [];
    const adminPaths = adminRouteChildren.map(
      (i) => `${RoutesURL.SETTINGS}/${i.path}`
    );
    allMenus.forEach((menu) => {
      if (userData?.isSuperAdmin) {
        adminMenus.push(menu);
      } else if (userData?.isAdmin) {
        if (adminPaths.includes(menu.path!)) adminMenus.push(menu);
        else if (menu.subMenu) {
          const subMenu = menu.subMenu.filter((i) =>
            adminPaths.includes(i.path)
          );
          const newMenu = { ...menu, subMenu };
          if (subMenu.length > 0) adminMenus.push(newMenu);
        }
      }
    });
    return adminMenus;
  }, [allMenus, userData]);

  return (
    <List className={lnbStyles.list}>
      {menus.map((menu, index) => RenderMenu(menu, index))}
    </List>
  );
};

const RenderMenu = (menu: any, index: number, _isChild: boolean = false) => {
  const navigate = useNavigate();
  const location = useLocation();

  const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(
    null
  );

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;

  const [openSubMenu, setOpenSubMenu] = useAtom(isOpenSubMenu);
  const [isOpenLnb] = useAtom(isOpenLnbAtom);

  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOpenSubMenu = () => {
    setOpenSubMenu(!openSubMenu);
  };

  const activeChildMenu = useCallback(
    (path: string) =>
      location.pathname.startsWith(`${path}/`) || location.pathname === path,
    [location.pathname]
  );

  const activeMenu = useCallback(
    (obj: any) => {
      const { path, subMenu } = obj;
      if (!isOpenLnb && subMenu && subMenu.length > 0) {
        return (
          location.pathname.startsWith(`${path}/`) ||
          location.pathname === path ||
          subMenu
            .map((i: { path: string }) => i.path)
            .includes(location.pathname)
        );
      }
      return (
        location.pathname.startsWith(`${path}/`) || location.pathname === path
      );
    },
    [isOpenLnb, location.pathname]
  );

  const handleClickSubPopupMenu = (path: string) => {
    handleClose();
    navigate(path);
  };

  const hasSubMenu = menu?.subMenu ?? false;

  return (
    <div key={index} className={lnbStyles.wrapItem}>
      <ListItem key={menu.text} disablePadding sx={{ display: 'block' }}>
        <ListItemButton
          selected={activeMenu(menu)}
          className={isOpenLnb ? lnbStyles.item : lnbStyles.itemCollapse}
          onClick={(event) => {
            if (hasSubMenu) {
              if (isOpenLnb) {
                handleOpenSubMenu();
              } else {
                handleClick(event);
              }
            } else {
              navigate(menu?.path);
            }
          }}
          sx={[
            {
              height: 42,
              gap: '10px',
            },
            {
              '&.Mui-selected': {
                backgroundColor: isOpenLnb
                  ? 'rgba(var(--primary-selected), var(--alpha-20))'
                  : 'var(--primitives-darkBlue-30)',
                color: 'var(--gray-500)',
              },
            },
          ]}
        >
          {isOpenLnb ? (
            <ListItemText primary={menu.text} className={lnbStyles.text} />
          ) : (
            <BaseTooltip title={menu.text} placement='right'>
              <ListItemIcon className={lnbStyles.icon}>
                {menu?.icon ?? null}
              </ListItemIcon>
            </BaseTooltip>
          )}

          {hasSubMenu && isOpenLnb ? (
            <span className={lnbStyles.downIcon}>
              {openSubMenu ? (
                <IconDown
                  style={{
                    transform: 'rotate(180deg)',
                    color: 'var(--gray-500)',
                  }}
                />
              ) : (
                <IconDown
                  style={{
                    color: 'var(--gray-500)',
                  }}
                />
              )}
            </span>
          ) : (
            ''
          )}
        </ListItemButton>
      </ListItem>
      {hasSubMenu && (
        <Collapse in={openSubMenu} timeout='auto' unmountOnExit>
          <List component='div' disablePadding className={lnbStyles.childMenu}>
            {_.size(menu.subMenu) > 0 &&
              menu.subMenu.map((childMenu: any, childIndex: number) =>
                RenderMenu(childMenu, childIndex, true)
              )}
          </List>
        </Collapse>
      )}
      {!isOpenLnb && (
        <Popover
          id={id}
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          sx={{
            '.MuiPaper-root': {
              gap: '4px',
              display: 'flex',
              flexDirection: 'column',
              padding: '4px',
              boxShadow: '0px 9px 28px 8px #0000000D',
              borderRadius: '6px',
            },
          }}
        >
          {_.size(menu.subMenu) > 0 &&
            menu.subMenu.map((childMenu: any, _index: number) => (
              <Typography
                className={cn(
                  lnbStyles.popoverMenuItem,
                  activeChildMenu(childMenu?.path) ? lnbStyles.selected : ''
                )}
                onClick={() => handleClickSubPopupMenu(childMenu?.path)}
                key={`${index}-${_index}`}
              >
                {childMenu?.text}
              </Typography>
            ))}
        </Popover>
      )}
    </div>
  );
};
