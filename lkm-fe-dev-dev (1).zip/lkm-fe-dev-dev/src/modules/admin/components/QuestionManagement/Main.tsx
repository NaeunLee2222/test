import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import styles from '../../styles/AdminMain.module.scss';
import type { IDialog } from '../../types/user';
import { DialogForm } from './Dialog';
import { FormSearch } from './FormSearch';
import { Table } from './Table';

export const QuestionMain = () => {
  const { t } = useTranslation('admin');

  const [dialogOpen, setOpenDialog] = useState<IDialog>({
    open: false,
    type: 'view',
  });

  return (
    <div className={styles.adminMain} data-testid='question-main'>
      <h1 className={styles.pageTitle}>{t('exampleQuestion.pageTitle')}</h1>
      <div className={styles.content} data-testid='content-container'>
        <div className={styles.formSearch} data-testid='search-container'>
          <FormSearch />
        </div>
        <Table setOpenDialog={setOpenDialog} />
        <DialogForm dialogState={dialogOpen} setDialogState={setOpenDialog} />
      </div>
    </div>
  );
};
