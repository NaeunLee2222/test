import { useTranslation } from 'react-i18next';
import { formatDateToKst } from '@/utils';
import styles from './Dialog.module.scss';
import BaseDetailsText from '../Form/DetailsText/BaseDetailsText';

export const FormView = ({ data }: any) => {
  const { t } = useTranslation('admin');

  return (
    <div className={styles.baseDialog}>
      <div className={styles.group}>
        <BaseDetailsText
          label={t('advisoryType')}
          content={data?.is_pro ? t('pro') : t('common')}
        />
        <BaseDetailsText
          label={t('categoryName')}
          content={data?.category || ''}
        />
        <BaseDetailsText
          label={t('exampleQuestion.exampleQuestion')}
          content={data?.question || ''}
        />
        <BaseDetailsText label={t('author')} content={data?.user_name || ''} />
        <BaseDetailsText
          label={t('workingDay')}
          content={data?.date ? formatDateToKst(data.date, 'YYYY-MM-DD') : ''}
        />
        <BaseDetailsText
          label={t('disclosure')}
          content={data?.is_visible ? t('public') : t('private')}
        />
      </div>
    </div>
  );
};
