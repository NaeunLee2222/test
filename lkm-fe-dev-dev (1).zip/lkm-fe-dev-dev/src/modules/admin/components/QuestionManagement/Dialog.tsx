import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { getKeyByValue } from '@/utils';
import { showSnackbar } from '@/utils/snackbarUtil';
import { useAtom } from 'jotai';
import _ from 'lodash';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import {
  getLaw,
  questionSettingAtom,
  useDeleteMutation,
  useQuestionMutation,
} from '../../hooks/useQuestionSettings';
import styles from '../../styles/AdminMain.module.scss';
import type { ILawResponse, IQuestion } from '../../types/question';
import type { IDialog } from '../../types/user';
import BaseInput from '../Form/Inputs/BaseInput';
import BaseRadioGroup from '../Form/Radios/BaseRadioGroup';
import BaseSelect from '../Form/Selects/BaseSelect';
import BaseSwitch from '../Form/Switches/BaseSwitch';
import { FormView } from './FormView';

interface IProps {
  dialogState: IDialog;
  setDialogState: ({ open, type }: IDialog) => void;
}

const viewStates = {
  view: 'view',
  edit: 'edit',
  add: 'add',
};

export const DialogForm = ({ dialogState, setDialogState }: IProps) => {
  const { t } = useTranslation('admin');
  const methods = useForm();
  const { formState } = methods;

  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [questionSettingData, setQuestionSettingData] =
    useAtom(questionSettingAtom);
  const [{ mutate: mutateUser }] = useAtom(useQuestionMutation);
  const [{ data: lawData }] = useAtom(getLaw);
  const [defaultLaw1, setDefaultLaw1] = useState('');

  const handleClose = useCallback(() => {
    setDialogState({ ...dialogState, open: false });
    methods.reset();
    setDefaultLaw1('');
  }, [setDialogState, methods, dialogState]);

  const advisoryType = [
    { value: 'pro', label: t('pro') },
    { value: 'common', label: t('common') },
  ];

  const handleConfirm = useCallback(() => {
    const finalData = {
      ...questionSettingData,
      ...methods.getValues(),
      category: methods.getValues().law2,
      is_pro: methods.getValues().is_pro === 'pro',
      is_visible: methods.getValues().is_visible || false,
    };
    setQuestionSettingData(finalData as IQuestion);

    mutateUser({
      callback: (
        isSuccess: boolean,
        response: {
          message?: string;
        }
      ) => {
        const message = isSuccess
          ? finalData.id
            ? t('exampleQuestion.questionHasBeenUpdated')
            : t('exampleQuestion.questionHasBeenCreated')
          : response?.message || '';
        showSnackbar(message, isSuccess ? 'success' : 'error', 3);
      },
    });
    handleClose();
  }, [
    questionSettingData,
    methods,
    setQuestionSettingData,
    mutateUser,
    handleClose,
    t,
  ]);

  const law1 = useMemo(
    () => (lawData && _.size(lawData) > 0 ? Object.keys(lawData) : []),
    [lawData]
  );

  const watchLaw1 = methods.watch('law1') || '';
  const law2 = useMemo(
    () =>
      lawData && watchLaw1 ? lawData[watchLaw1 as keyof ILawResponse] : [],
    [lawData, watchLaw1]
  );

  useEffect(() => {
    if (
      lawData &&
      _.size(lawData) > 0 &&
      dialogState.type === viewStates.edit &&
      questionSettingData?.category
    ) {
      const law1Value = getKeyByValue(lawData, questionSettingData?.category);
      if (law1Value) {
        setDefaultLaw1(law1Value);
      }
    }
  }, [dialogState.type, lawData, questionSettingData?.category]);

  const [{ mutate: mutateDeleteQuestion }] = useAtom(useDeleteMutation);

  useEffect(() => {
    if (methods.getValues().law1 === '') {
      methods.setValue('law2', '');
    }
  }, [methods.getValues().law1]);

  const handleDelete = useCallback(() => {
    setConfirmDialogData({ open: false });
    if (!questionSettingData?.id) return;
    mutateDeleteQuestion({
      id: questionSettingData.id,
      callback: (isSuccess: boolean, response: { message?: string }) => {
        const message = isSuccess
          ? t('exampleQuestion.questionHasBeenDeleted')
          : response?.message || '';
        showSnackbar(message, isSuccess ? 'success' : 'error', 3);
      },
    });
    handleClose();
  }, [
    setConfirmDialogData,
    questionSettingData.id,
    mutateDeleteQuestion,
    handleClose,
    t,
  ]);

  const openConfirmDelete = useCallback(() => {
    setConfirmDialogData({
      open: true,
      title: t('exampleQuestion.title'),
      contentText: t('exampleQuestion.confirmDeleteMessage'),
      confirmText: t('delete'),
      handleConfirm: handleDelete,
      handleCancel: () => {
        setConfirmDialogData({
          open: false,
        });
      },
    });
  }, [handleDelete, setConfirmDialogData, t]);

  const renderTitle = () => {
    switch (dialogState.type) {
      case viewStates.view:
      case viewStates.edit:
        return t('exampleQuestion.exampleQuestion');
      case viewStates.add:
        return t('exampleQuestion.create');
      default:
        return '';
    }
  };

  const renderedButtons = useMemo(() => {
    const isFormValid = formState.isValid && formState.isDirty;
    switch (dialogState.type) {
      case viewStates.view:
        return (
          <div className='flexBetween'>
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='redLinked'
                className={styles.btnStyles}
                onClick={openConfirmDelete}
              >
                <span>{t('delete')}</span>
              </BaseButton>
            </span>
            <BaseButton
              buttonType='outlined'
              className={styles.btnStyles}
              onClick={() => setDialogState({ open: true, type: 'edit' })}
            >
              <span>{t('edit')}</span>
            </BaseButton>
          </div>
        );
      case viewStates.edit:
        return (
          <div className='flexBetween'>
            <BaseButton buttonType='redLinked' onClick={openConfirmDelete}>
              <span>{t('delete')}</span>
            </BaseButton>
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={styles.btnStyles}
                onClick={() => setDialogState({ open: true, type: 'view' })}
              >
                <span>{t('cancel')}</span>
              </BaseButton>
              <BaseButton
                autoFocus
                onClick={methods.handleSubmit(handleConfirm)}
                color='primary'
                className={styles.btnStyles}
                disabled={!methods.formState.isDirty}
              >
                <span>{t('editCheck')}</span>
              </BaseButton>
            </span>
          </div>
        );
      case viewStates.add:
        return (
          <div className='flexBetween'>
            <span />
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={styles.btnStyles}
                onClick={handleClose}
              >
                <span>{t('cancel')}</span>
              </BaseButton>
              <BaseButton
                autoFocus
                className={styles.btnStyles}
                onClick={methods.handleSubmit(handleConfirm)}
                color='primary'
                disabled={!isFormValid}
              >
                <span>{t('registration')}</span>
              </BaseButton>
            </span>
          </div>
        );
      default:
        return null;
    }
  }, [
    dialogState.type,
    formState.isValid,
    formState.isDirty,
    setDialogState,
    openConfirmDelete,
    t,
    handleClose,
    methods,
    handleConfirm,
  ]);

  const defaultAdvisoryType = useMemo(() => {
    let defaultType = 'pro';
    if (!_.isEmpty(questionSettingData) && !questionSettingData.is_pro) {
      defaultType = 'common';
    }
    return defaultType;
  }, [questionSettingData]);

  return (
    <>
      <BaseDialog
        open={dialogState.open}
        title={renderTitle()}
        handleClose={handleClose}
        sx={{
          '.MuiPaper-root': {
            maxWidth: '600px',
          },
        }}
        contentChildren={
          <>
            {dialogState.type === viewStates.view ? (
              <FormView data={questionSettingData} />
            ) : (
              <div
                className='flexColumn'
                style={{
                  gap: '16px',
                }}
              >
                <BaseSelect
                  {...methods}
                  name='law1'
                  data={law1}
                  label={t('detail')}
                  defaultValue={defaultLaw1}
                  placeholder={t('select')}
                  rules={{
                    required: { value: true, message: t('errors.required') },
                  }}
                />

                <BaseSelect
                  {...methods}
                  name='law2'
                  data={law2}
                  label={t('categoryName')}
                  disabled={!(law2 && _.size(law2) > 0)}
                  defaultValue={questionSettingData?.category}
                  placeholder={t('select')}
                  rules={{
                    required: { value: true, message: t('errors.required') },
                  }}
                />

                <BaseInput
                  {...methods}
                  name='question'
                  rows={3}
                  maxLength={50}
                  label={t('exampleQuestion.exampleQuestion')}
                  defaultValue={questionSettingData?.question}
                  placeholder={t(
                    'exampleQuestion.pleaseEnterAnExampleQuestion'
                  )}
                  rules={{
                    required: { value: true, message: t('errors.required') },
                  }}
                />

                <BaseRadioGroup
                  {...methods}
                  name='is_pro'
                  label={t('advisoryType')}
                  options={advisoryType}
                  defaultValue={defaultAdvisoryType}
                />

                <BaseSwitch
                  {...methods}
                  label={t('disclosure')}
                  name='is_visible'
                  defaultValue={questionSettingData?.is_visible}
                />
              </div>
            )}
          </>
        }
        actionsChildren={renderedButtons}
      />
    </>
  );
};
