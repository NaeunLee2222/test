import { useCompanyList, useUserMe } from '@/modules/core/hooks';
import { useAtom } from 'jotai';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  listPaginationAtom,
  useQuestionSettings,
} from '../../hooks/useQuestionSettings';
import styles from '../../styles/AdminMain.module.scss';
import SearchInput from '../Search/Input';
import SearchSelect from '../Search/Select';

export const FormSearch = () => {
  const [{ data: userData }] = useAtom(useUserMe);
  const isSuperAdmin = userData?.role?.includes('superadmin');

  const { t } = useTranslation('admin');
  const [advisoryType, setAdvisoryType] = useState('');
  const [disclosure, setDisclosure] = useState('');
  const [search, setSearch] = useState('');
  const [company, setCompany] = useState('');

  const [, setPage] = useAtom(listPaginationAtom);
  const [{ refetch }] = useAtom(useQuestionSettings);

  const [{ data: companyList }] = useAtom(useCompanyList);
  const companyOptions = useMemo(
    () =>
      companyList?.map((c) => ({
        value: c.name,
        label: c.name,
      })) || [],
    [companyList]
  );

  const handleSearch = (
    currentAdvisoryType?: string,
    currentDisclosure?: string,
    isEventDriven?: boolean
  ) => {
    let params = '';
    if (search) {
      params = `&search=${search}`;
    }
    if (currentAdvisoryType || advisoryType) {
      params = `${params}&isPro=${currentAdvisoryType || advisoryType}`;
    }
    if (currentDisclosure || disclosure) {
      params = `${params}&isVisible=${currentDisclosure || disclosure}`;
    }
    setPage((prev) => ({ ...prev, page: 0, search: params }));
    if (isEventDriven) refetch();
  };

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch('', '', true);
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleSelectCompany = (value: string) => {
    setCompany(value);
    setPage((prev) => ({ ...prev, page: 0, company: value }));
  };

  const handleSelectAdvisoryType = (value: string) => {
    setAdvisoryType(value);
    handleSearch(value, '', true);
  };

  const handleSelectDisclosure = (value: string) => {
    setDisclosure(value);
    handleSearch('', value, true);
  };

  useEffect(() => {
    if (companyList) {
      const defaultCompany = companyList?.find(
        (c) => c.name === userData?.company
      );
      setCompany(defaultCompany?.name || '');
      setPage((prev) => ({
        ...prev,
        page: 0,
        company: defaultCompany?.name || '',
      }));
    }
  }, [companyList, setPage]);

  return (
    <>
      {isSuperAdmin && (
        <div className={styles.selectField}>
          <div className={styles.label}>{`${t('company')}:`}</div>
          <SearchSelect
            options={companyOptions}
            // defaultValue={company}
            value={company}
            handleChange={handleSelectCompany}
          />
        </div>
      )}
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('advisoryType2')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: t('all') },
            { value: 'true', label: t('pro') },
            { value: 'false', label: t('common') },
          ]}
          defaultValue=''
          handleChange={handleSelectAdvisoryType}
        />
      </div>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('disclosure')}:`}</div>
        <SearchSelect
          options={[
            { value: '', label: t('all') },
            { value: 'true', label: t('public') },
            { value: 'false', label: t('private') },
          ]}
          defaultValue=''
          handleChange={handleSelectDisclosure}
        />
      </div>
      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('searchByDetailOrQuestion')}
          search={search}
        />
      </div>
    </>
  );
};
