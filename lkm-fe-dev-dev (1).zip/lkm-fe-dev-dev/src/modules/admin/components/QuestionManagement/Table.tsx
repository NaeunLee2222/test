import { formatDateToKst } from '@/utils';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
  listPaginationAtom,
  questionSettingAtom,
  useQuestionSettings,
} from '../../hooks/useQuestionSettings';
import type { IDialog } from '../../types/user';
import { BaseTable } from '../Table/BaseTable';

interface IProps {
  setOpenDialog: ({ open, type }: IDialog) => void;
}

export const Table = ({ setOpenDialog }: IProps) => {
  const { t } = useTranslation('admin');

  const columns = useMemo(
    () => [
      {
        name: 'is_pro',
        label: t('advisoryType2'),
        width: '10%',
        format: (value: any) => (value ? t('pro') : t('common')),
      },
      {
        name: 'category',
        label: t('categoryName'),
        width: '18%',
      },
      {
        name: 'question',
        label: t('exampleQuestion.exampleQuestion'),
        width: '40%',
      },
      { name: 'user_name', label: t('author'), width: '10%' },
      {
        name: 'date',
        label: t('workingDay'),
        width: '12%',
        format: (value: string) => formatDateToKst(value, 'YYYY-MM-DD'),
        sortable: true,
      },
      {
        name: 'is_visible',
        label: t('disclosure'),
        width: '10%',
        format: (value: any) => (value ? t('public') : t('private')),
      },
    ],
    [t]
  );

  return (
    <BaseTable
      setOpenDynamicDialog={setOpenDialog}
      columns={columns}
      paginationSettingAtom={listPaginationAtom}
      fieldSettingAtom={questionSettingAtom}
      getData={useQuestionSettings}
      hasAddBtn
      addBtnLabel={t('exampleQuestion.addBtnLabel')}
    />
  );
};
