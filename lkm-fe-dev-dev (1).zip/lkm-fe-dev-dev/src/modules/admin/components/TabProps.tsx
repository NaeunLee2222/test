import { Box } from '@mui/material';
import styles from '../styles/AdminMain.module.scss';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
  className?: string;
  sx?: any;
}

export const CustomTabPanel = (props: TabPanelProps) => {
  const { children, className = '', value, index, sx, ...other } = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      className={`${className} ${styles.tab}`}
      {...other}
    >
      {value === index && (
        <Box
          sx={{
            p: '24px',
            ...sx,
          }}
        >
          {children}
        </Box>
      )}
    </div>
  );
};

export const tabProps = (index: number) => ({
  id: `simple-tab-${index}`,
  'aria-controls': `simple-tabpanel-${index}`,
});
