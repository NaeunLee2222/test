import { useTranslation } from 'react-i18next';
import BaseDetailsText from '../Form/DetailsText/BaseDetailsText';
import styles from './Dialog.module.scss';
import { EUserRole } from './types';

export const UserView = ({ userSettingData }: any) => {
  const { t } = useTranslation('admin');

  return (
    <div className={styles.baseDialog}>
      <div className={styles.group}>
        <BaseDetailsText
          label={t('user.emailLabelView')}
          content={userSettingData?.email ?? ''}
          propsClassName={styles.userDetailRow}
        />
        <BaseDetailsText
          label={t('user.name')}
          content={userSettingData?.username ?? ''}
          propsClassName={styles.userDetailRow}
        />
        <BaseDetailsText
          label={t('user.company')}
          content={userSettingData?.company?.name ?? ''}
          propsClassName={styles.userDetailRow}
        />
        <BaseDetailsText
          label={t('user.role')}
          content={
            userSettingData?.role?.toString() === EUserRole.USER
              ? t('user.userRole.user')
              : t('user.userRole.admin')
          }
          propsClassName={styles.userDetailRow}
        />
        <BaseDetailsText
          label={t('user.isActive')}
          content={
            userSettingData?.is_activated
              ? t('user.active')
              : t('user.inactive')
          }
          propsClassName={styles.userDetailRow}
        />
      </div>
    </div>
  );
};
