import SearchInput from '@/modules/admin/components/Search/Input';
import SearchSelect from '@/modules/admin/components/Search/Select';
import styles from '@/modules/admin/components/UserManagement/UserManagement.module.scss';
import { userListPaginationAtom } from '@/modules/admin/hooks/useUserSettings';
import { useCompanyList, useUserMe } from '@/modules/core/hooks';
import { EActivatedStatus, ERole } from '@/types/user';
import { Button } from '@mui/material';
import { useAtom } from 'jotai';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';

export const UserSearchWrapper = () => {
  const { t } = useTranslation('admin');
  const [search, setSearch] = useState('');
  const [permission, setPermission] = useState(ERole.ALL);
  const [company, setCompany] = useState('');
  const [activated, setActivated] = useState(EActivatedStatus.ALL);

  const [, setPage] = useAtom(userListPaginationAtom);

  const [{ data: companyList }] = useAtom(useCompanyList);

  const [{ data: userData }] = useAtom(useUserMe);
  const isSuperAdmin = userData?.role?.includes(ERole.SUPPER_ADMIN);

  const roleOptions = useMemo(() => {
    const baseOptions = [
      { value: ERole.ALL, label: t('all') },
      { value: ERole.USER, label: t('user.common') },
      { value: ERole.ADMIN, label: t('user.admin') },
    ];

    if (isSuperAdmin) {
      baseOptions.splice(1, 0, {
        value: ERole.SUPPER_ADMIN,
        label: 'Superadmin',
      });
    }

    return baseOptions;
  }, [isSuperAdmin, t]);

  useEffect(() => {
    setPage((prev) => ({
      ...prev,
      page: 0,
      activated,
      permission,
      company,
      searchString: search,
      updated: Date.now(),
    }));
  }, [activated, permission, company]);

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      handleSearch();
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleSelectRoleType = (value: string) => {
    setPermission(value as ERole);
  };

  const handleSelectActivateType = (value: string) => {
    setActivated(value as EActivatedStatus);
  };

  const companyOptions = useMemo(
    () =>
      companyList?.map((c) => ({
        value: c.name,
        label: c.name,
      })) || [],
    [companyList]
  );

  const handleClear = () => {
    setPermission(ERole.ALL);
    setCompany('');
    setSearch('');
    setActivated(EActivatedStatus.ALL);
    setPage((prev) => ({
      ...prev,
      page: 0,
      activated: EActivatedStatus.INACTIVE,
      permission: ERole.ALL,
      company: '',
    }));
  };

  const handleSearch = () => {
    setPage((prev) => ({
      ...prev,
      page: 0,
      activated,
      permission,
      company,
      searchString: search,
      updated: Date.now(),
    }));
  };

  const handleSelectCompany = (value: string) => {
    setCompany(value);
  };

  useEffect(() => {
    if (companyList) {
      const defaultCompany = companyList?.find(
        (c) => c.name === userData?.company
      );
      setPage((prev) => ({
        ...prev,
        page: 0,
        company: defaultCompany?.name ?? '',
      }));
    }
  }, [companyList, setPage]);

  return (
    <div className={styles.searchContainer}>
      <div className={styles.selectContainer}>
        {isSuperAdmin && (
          <div className={styles.selectField}>
            <div className={styles.label}>{`${t('company')}:`}</div>
            <SearchSelect
              options={companyOptions}
              value={company}
              handleChange={handleSelectCompany}
              height='32px'
            />
          </div>
        )}
        <div className={styles.selectField}>
          <div className={styles.label}>{`${t('role')}:`}</div>
          <SearchSelect
            options={roleOptions}
            defaultValue=''
            handleChange={handleSelectRoleType}
            height='32px'
            value={permission}
          />
        </div>
        <div className={styles.selectField}>
          <div className={styles.label}>{`${t('activate')}:`}</div>
          <SearchSelect
            options={[
              { value: EActivatedStatus.ALL, label: t('all') },
              { value: EActivatedStatus.ACTIVE, label: t('user.active') },
              { value: EActivatedStatus.INACTIVE, label: t('user.inactive') },
            ]}
            value={activated}
            defaultValue=''
            handleChange={handleSelectActivateType}
            height='32px'
          />
        </div>
      </div>

      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}:`}</div>
        <SearchInput
          onKeyUp={handleOnKeyUpToSend}
          setSearch={setSearch}
          placeholder={t('searchByIdNameEmail')}
          search={search}
          className={styles.textField}
        />
      </div>
      <div className={styles.searchAction}>
        <Button
          variant='outlined'
          className={styles.clear}
          onClick={handleClear}
          type='button'
          tabIndex={0}
          size='small'
        >
          {t('reset')}
        </Button>
        <Button
          size='small'
          variant='contained'
          className={styles.search}
          onClick={() => {
            handleSearch();
          }}
          type='button'
          tabIndex={0}
        >
          {t('check')}
        </Button>
      </div>
    </div>
  );
};
