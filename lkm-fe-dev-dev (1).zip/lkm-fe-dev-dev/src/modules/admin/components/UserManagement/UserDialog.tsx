import { BaseButton } from '@/modules/core/components/common/BaseButton';
import { BaseDialog } from '@/modules/core/components/common/BaseDialog';
import { useOrganizationList } from '@/modules/core/hooks';
import { confirmDialogDataAtom } from '@/modules/core/jotai/confirm';
import { EButtonType } from '@/types/common';
import { ERole } from '@/types/user';
import { showSnackbar } from '@/utils/snackbarUtil';
import cn from 'classnames';
import { useAtom } from 'jotai';
import { useCallback, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import {
  userSettingAtom,
  useUserDeleteMutation,
  useUserMutation,
} from '../../hooks/useUserSettings';
import type { IDialog, IOrganization, IUser } from '../../types/user';
import BaseInput from '../Form/Inputs/BaseInput';
import BaseRadioGroup from '../Form/Radios/BaseRadioGroup';
import BaseSelect from '../Form/Selects/BaseSelect';
import BaseSwitch from '../Form/Switches/BaseSwitch';
import styles from './UserDialog.module.scss';
import { UserView } from './UserView';

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

interface IProps {
  dialogState: IDialog;
  setDialogState: ({ open, type }: IDialog) => void;
}

const viewStates = {
  view: 'view',
  edit: 'edit',
  add: 'add',
};

export const UserDialog = ({ dialogState, setDialogState }: IProps) => {
  const { t } = useTranslation('admin');
  const [, setConfirmDialogData] = useAtom(confirmDialogDataAtom);
  const [{ mutate: mutateDeleteUser }] = useAtom(useUserDeleteMutation);
  const [userSettingData, setUserSettingData] = useAtom(userSettingAtom);
  const [{ mutate: mutateUser }] = useAtom(useUserMutation);
  const [{ data: companyList }] = useAtom(useOrganizationList);
  const methods = useForm();

  const roles = useMemo(
    () => [
      { value: ERole.USER, label: t('user.common') },
      { value: ERole.ADMIN, label: t('user.admin') },
    ],
    [t]
  );

  const handleClose = useCallback(() => {
    setDialogState({ ...dialogState, open: false });
    methods.reset();
  }, [setDialogState, methods, dialogState]);

  const handleConfirm = useCallback(() => {
    const oldEmail = userSettingData.email;
    const finalData = {
      ...userSettingData,
      ...methods.getValues(),
      is_activated: methods.getValues().is_activated ?? false,
    };

    setUserSettingData(finalData as IUser);

    mutateUser({
      callback: (
        isSuccess: boolean,
        response: {
          message?: string;
        }
      ) => {
        const finalDataMessage = finalData.id
          ? t('user.userHasBeenUpdated')
          : t('user.userHasBeenCreated');

        const message = isSuccess
          ? finalDataMessage
          : (response?.message ?? '');
        showSnackbar(message, isSuccess ? 'success' : 'error', 3);
      },
      oldEmail,
    });
    handleClose();
  }, [
    userSettingData,
    methods,
    setUserSettingData,
    mutateUser,
    handleClose,
    t,
  ]);

  const handleDelete = useCallback(() => {
    setConfirmDialogData({ open: false });
    if (!userSettingData?.id) return;
    mutateDeleteUser(
      {
        userId: userSettingData.id,
      },
      {
        onSuccess: () => {
          showSnackbar(
            t('user.userHasBeenDeleted'),
            'success',
            3,
            {
              vertical: 'bottom',
              horizontal: 'center',
            },
            {
              disableWindowBlurListener: true,
              action: null,
              className: styles.successSnackbar,
            }
          );
        },
      }
    );
    handleClose();
  }, [
    setConfirmDialogData,
    userSettingData.id,
    mutateDeleteUser,
    handleClose,
    t,
  ]);

  const openConfirmDelete = () => {
    setConfirmDialogData({
      open: true,
      title: t('userDelete.title'),
      contentText: t('userDelete.message'),
      confirmText: t('userDelete.confirmText'),
      handleConfirm: handleDelete,
      handleCancel: () => {
        setConfirmDialogData({
          open: false,
        });
      },
      type: EButtonType.DELETE,
    });
  };

  const renderTitle = () => {
    switch (dialogState.type) {
      case viewStates.view:
      case viewStates.edit:
        return t('userName');
      case viewStates.add:
        return t('user.create');
      default:
        return '';
    }
  };

  const renderButtons = () => {
    const isFormValid = methods.formState.isValid && methods.formState.isDirty;
    switch (dialogState.type) {
      case viewStates.view:
        return (
          <div className='flexBetween'>
            <BaseButton
              buttonType='redLinked'
              className={cn(styles.btnStyles, styles.actionLinkRed)}
              onClick={openConfirmDelete}
            >
              <span>{t('delete')}</span>
            </BaseButton>
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={cn(styles.btnStyles, styles.toDetailBtn)}
                onClick={() => setDialogState({ open: true, type: 'edit' })}
              >
                <span>{t('edit')}</span>
              </BaseButton>
            </span>
          </div>
        );
      case viewStates.edit:
        return (
          <div className='flexBetween'>
            <div />
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={cn(styles.btnStyles, styles.toDetailBtn)}
                onClick={() => setDialogState({ open: true, type: 'view' })}
              >
                <span>{t('cancel')}</span>
              </BaseButton>
              <BaseButton
                autoFocus
                onClick={methods.handleSubmit(handleConfirm)}
                color='primary'
                className={cn(styles.btnStyles, styles.saveBtn)}
                disabled={
                  !methods.formState.isDirty || !methods.formState.isValid
                }
              >
                <span>{t('editCheck')}</span>
              </BaseButton>
            </span>
          </div>
        );
      case viewStates.add:
        return (
          <div className='flexBetween'>
            <span />
            <span className='flex' style={{ gap: '8px' }}>
              <BaseButton
                buttonType='outlined'
                className={cn(styles.btnStyles, styles.toDetailBtn)}
                onClick={handleClose}
              >
                <span>{t('cancel')}</span>
              </BaseButton>
              <BaseButton
                autoFocus
                className={cn(styles.btnStyles, styles.saveBtn)}
                onClick={methods.handleSubmit(handleConfirm)}
                color='primary'
                disabled={!isFormValid}
              >
                <span>{t('registration')}</span>
              </BaseButton>
            </span>
          </div>
        );
      default:
        return null;
    }
  };

  const companies =
    companyList?.map((company: IOrganization) => ({
      label: company.name,
      id: company.id,
    })) ?? [];

  return (
    <BaseDialog
      sx={{
        '.MuiPaper-root': {
          maxWidth: '600px',
        },
      }}
      open={dialogState.open}
      title={renderTitle()}
      handleClose={handleClose}
      paddingX={24}
      dialogTitleClassName={styles.dialogTitle}
      contentClassName={styles.userFormContainer}
      actionClassName={styles.actionButton}
      contentChildren={
        <>
          {dialogState.type === viewStates.view ? (
            <UserView userSettingData={userSettingData} />
          ) : (
            <div className={styles.useForm}>
              <BaseInput
                {...methods}
                name='email'
                label={t('user.emailLabel')}
                defaultValue={userSettingData?.email}
                placeholder={t('user.placeholders.email')}
                rules={{
                  required: { value: true },
                  pattern: {
                    value: emailRegex,
                  },
                }}
                className={styles.userCustomInput}
              />

              <BaseInput
                {...methods}
                name='username'
                label={t('user.name')}
                defaultValue={userSettingData?.username}
                placeholder={t('user.placeholders.name')}
                rules={{
                  required: { value: true },
                }}
                className={styles.userCustomInput}
              />
              <BaseSelect
                {...methods}
                data={companies}
                name='organization_id'
                label={t('user.company')}
                defaultValue={userSettingData?.company?.id?.toString() ?? ''}
                placeholder={t('select')}
                rules={{
                  required: { value: true },
                }}
                className={styles.userCustomInput}
                customSelectClassName={cn(
                  styles.customSelectInput,
                  methods.watch('organization_id') === ''
                    ? styles.selectDefaultValue
                    : ''
                )}
                hasPlaceholder
              />

              <BaseInput
                {...methods}
                name='password'
                label={
                  dialogState.type === viewStates.edit
                    ? t('user.editPasswordLabel')
                    : t('user.password')
                }
                type='password'
                defaultValue={userSettingData?.password}
                placeholder={
                  dialogState.type === viewStates.edit
                    ? ''
                    : t('user.placeholders.password')
                }
                rules={{
                  required:
                    dialogState.type === viewStates.edit
                      ? false
                      : { value: true },
                  minLength: {
                    value: 8,
                  },
                }}
                className={styles.userCustomInput}
              />
              <div className={styles.userRoleActions}>
                <BaseRadioGroup
                  {...methods}
                  name='role'
                  label={t('role')}
                  options={roles}
                  defaultValue={userSettingData.role ?? ERole.USER}
                  rules={{
                    required: { value: true },
                  }}
                  className={styles.checkboxClassName}
                />

                <BaseSwitch
                  {...methods}
                  label={t('user.isActive')}
                  name='is_activated'
                  defaultValue={userSettingData?.is_activated ?? true}
                />
              </div>
            </div>
          )}
        </>
      }
      actionsChildren={renderButtons()}
    />
  );
};
