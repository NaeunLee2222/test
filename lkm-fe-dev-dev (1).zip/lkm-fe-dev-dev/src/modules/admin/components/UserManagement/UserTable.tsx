import { useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
  handleDeleteMultiple,
  userListPaginationAtom,
  userSettingAtom,
  useUsersSettings,
} from '@/modules/admin/hooks/useUserSettings';
import { BaseTable } from '@/modules/admin/components/Table/BaseTable';
import { EUserRole } from '@/modules/admin/components/UserManagement/types';
import { useAtom } from 'jotai';
import { IDialog } from '@/modules/admin/types/user';

interface IProps {
  setOpenDialog: ({ open, type }: IDialog) => void;
}

export const UserTable = ({ setOpenDialog }: IProps) => {
  const { t } = useTranslation('admin');

  const [{ refetch }] = useAtom(useUsersSettings);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const columns = useMemo(
    () => [
      { name: 'email', label: t('email'), width: '35%' },
      { name: 'username', label: t('name'), width: '20%', sortable: true },
      {
        name: 'company',
        label: t('user.company'),
        width: '15%',
        sortable: true,
        format: (value: { name: string; id: string | number }) => value.name,
      },
      {
        name: 'role',
        label: t('role'),
        width: '15%',
        format: (value: any) =>
          value === EUserRole.USER
            ? t('user.userRole.user')
            : t('user.userRole.admin'),
      },
      {
        name: 'is_activated',
        label: t('activate'),
        width: '15%',
        format: (value: any) => (value ? t('user.active') : t('user.inactive')),
      },
    ],
    [t]
  );

  return (
    <BaseTable
      setOpenDynamicDialog={setOpenDialog}
      columns={columns}
      paginationSettingAtom={userListPaginationAtom}
      fieldSettingAtom={userSettingAtom}
      getData={useUsersSettings}
      hasCheckbox
      hasAddBtn
      handleDeleteMultiple={handleDeleteMultiple}
      keyField='id'
      unit={t('userCount')}
      addBtnLabel={t('user.addBtnLabel')}
      popupConfirmTitle={t('userDelete.title')}
      popupConfirmContent={t('userDelete.message')}
      deleteToastContent={t('user.userHasBeenDeleted')}
    />
  );
};
