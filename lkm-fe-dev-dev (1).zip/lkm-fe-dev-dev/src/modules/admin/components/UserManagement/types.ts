export enum EUserRole {
  USER = 'user',
  ADMIN = 'admin',
}
