import styles from '@/modules/admin/components/UserManagement/UserManagement.module.scss';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import type { IDialog } from '../../types/user';
import { UserDialog } from './UserDialog';
import { UserSearchWrapper } from './UserSettingAction';
import { UserTable } from './UserTable';

export const UserMain = () => {
  const { t } = useTranslation('admin');

  const [openDialog, setOpenDialog] = useState<IDialog>({
    open: false,
    type: 'view',
  });

  return (
    <div className={styles.adminMain} data-testid='user-main'>
      <h1 className={styles.pageTitle}>{t('user.management')}</h1>
      <div className={styles.content} data-testid='content-container'>
        <div className={styles.formSearch} data-testid='search-container'>
          <UserSearchWrapper />
        </div>
        <UserTable setOpenDialog={setOpenDialog} />
        <UserDialog dialogState={openDialog} setDialogState={setOpenDialog} />
      </div>
    </div>
  );
};
