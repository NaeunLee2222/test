import { Switch } from '@mui/material';
import React, { useEffect } from 'react';
import { Controller } from 'react-hook-form';
import { styled } from '@mui/material/styles';
import styles from '@/modules/admin/styles/AdminMain.module.scss';
import switchStyles from './Switch.module.scss';

interface BaseSwitchProps {
  name: string;
  label: string;
  rules?: any;
  control: any;
  defaultValue?: boolean;
  setValue?: (name: string, value: string | boolean | undefined) => void;
}

const CustomSwitch = styled(Switch)(({ theme }) => ({
  width: 44,
  height: 22,
  padding: 0,
  '& .MuiSwitch-switchBase': {
    padding: 0,
    margin: 2,
    transitionDuration: '300ms',
    '&.Mui-checked': {
      transform: 'translateX(20px)',
      color: '#fff',
      '& + .MuiSwitch-track': {
        backgroundColor: 'var(--primary-color-600)',
        opacity: 1,
        border: 0,
      },
      '&.Mui-disabled + .MuiSwitch-track': {
        opacity: 0.5,
      },
    },
    '&.Mui-focusVisible .MuiSwitch-thumb': {
      color: theme.palette.primary.main,
      border: '6px solid #fff',
    },
    '&.Mui-disabled .MuiSwitch-thumb': {
      color:
        theme.palette.mode === 'light'
          ? theme.palette.grey[100]
          : theme.palette.grey[600],
    },
    '&.Mui-disabled + .MuiSwitch-track': {
      opacity: theme.palette.mode === 'light' ? 0.7 : 0.3,
    },
  },
  '& .MuiSwitch-thumb': {
    boxSizing: 'border-box',
    width: 18,
    height: 18,
  },
  '& .MuiSwitch-track': {
    borderRadius: 20,
    backgroundColor: theme.palette.mode === 'light' ? '#E9E9EA' : '#39393D',
    opacity: 1,
    transition: theme.transitions.create(['background-color'], {
      duration: 500,
    }),
  },
}));

const BaseSwitch: React.FC<BaseSwitchProps> = ({
  name,
  label,
  rules,
  control,
  defaultValue,
  setValue,
}) => {
  useEffect(() => {
    setValue && setValue(name, defaultValue);
  }, [defaultValue, name, setValue]);

  return (
    <div className={switchStyles.layout}>
      <label htmlFor={name} className={styles.fieldLabel}>
        {label}
        {rules?.required && <span style={{ color: '#F03E3E' }}>*</span>}
      </label>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field }) => (
          <div className={switchStyles.switchBox}>
            <CustomSwitch {...field} checked={field.value ?? false} />
          </div>
        )}
      />
    </div>
  );
};

export default BaseSwitch;
