import { Skeleton } from '@mui/material';
import cn from 'classnames';
import React from 'react';
import detailsTextStyles from './DetailsText.module.scss';

const BaseDetailsText = ({
  label,
  content,
  contentStyle = {},
  extraContent,
  propsClassName,
  loading,
}: {
  label: string;
  content: string;
  contentStyle?: any;
  extraContent?: React.ReactNode;
  propsClassName?: string;
  loading?: boolean;
}) => (
  <div
    className={cn(
      detailsTextStyles.rows,
      detailsTextStyles.rowsMax500,
      propsClassName
    )}
  >
    <div className={detailsTextStyles.fieldLabel}>{label}</div>
    <div className={detailsTextStyles.fieldValue} style={contentStyle}>
      {loading ? (
        <Skeleton variant='rectangular' sx={{ width: '100%' }} />
      ) : (
        <>
          {content || ''}
          {extraContent}
        </>
      )}
    </div>
  </div>
);

export default BaseDetailsText;
