import IconCheckboxDefault from '@/assets/basic-icons/icon-checkbox-border.svg?react';
import IconCheckboxChecked from '@/assets/basic-icons/icon-checkbox-checked-border.svg?react';
import IconCheckboxCheckedDisable from '@/assets/basic-icons/icon-checked-disable.svg?react';
import { Checkbox, FormHelperText } from '@mui/material';
import React from 'react';

interface BaseCheckBoxProps {
  name?: string;
  checked?: boolean;
  onChange?: any;
  onClick?: any;
  disabled?: boolean;
  error?: string;
  style?: any;
  sx?: any;
  className?: string;
}

const BaseCheckBox: React.FC<BaseCheckBoxProps> = ({
  name,
  checked,
  onChange,
  onClick,
  disabled,
  error,
  style,
  sx,
  className,
}) => (
  <div className='custom-checkbox'>
    <Checkbox
      disableRipple
      name={name}
      checked={checked}
      onChange={onChange}
      onClick={onClick}
      disabled={disabled}
      icon={
        <div className='icon-default'>
          <IconCheckboxDefault />
        </div>
      }
      checkedIcon={
        disabled ? (
          <IconCheckboxCheckedDisable />
        ) : (
          <div className='icon-checked'>
            <IconCheckboxChecked fill='var(--primary-color-600)' />
          </div>
        )
      }
      style={style}
      sx={{
        '&.MuiButtonBase-root.MuiCheckbox-root': {
          padding: '4px !important',
          width: '24px',
          height: '24px',
        },
        ...sx,
      }}
      className={className}
    />
    {error && <FormHelperText>{error}</FormHelperText>}
  </div>
);

export default BaseCheckBox;
