import React, { useEffect } from 'react';
import { Select, MenuItem } from '@mui/material';
import { Controller } from 'react-hook-form';
import { BaseMenuSx } from '@/modules/core/components/common/BaseMenu';
import styles from '@/modules/admin/styles/AdminMain.module.scss';
import FormHelperText from '@mui/material/FormHelperText';
import _ from 'lodash';
import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import cn from 'classnames';

interface BaseSelectProps {
  data:
    | Array<string>
    | Array<{
        label: string;
        id: number | string;
      }>;
  control: any;
  name: string;
  label?: string;
  defaultValue?: string;
  rules?: any;
  disabled?: boolean;
  placeholder?: string;
  setValue?: (name: string, value: string) => void;
  className?: string;
  customSelectClassName?: string;
  hasPlaceholder?: boolean;
  placeholderClassName?: string;
}

const ArrowDownIconComponent = (props: any) => (
  <span
    style={{
      width: '16px',
      height: '14px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
    }}
    {...props}
  >
    <ArrowDownIcon width='.7rem' height='0.5rem' />
  </span>
);

const BaseSelect: React.FC<BaseSelectProps> = ({
  data,
  control,
  name,
  label,
  defaultValue = '',
  rules,
  disabled,
  placeholder,
  setValue,
  className = '',
  customSelectClassName = '',
  hasPlaceholder = true,
  placeholderClassName = '',
}) => {
  useEffect(() => {
    setValue && setValue(name, defaultValue);
  }, [defaultValue, name, setValue]);

  return (
    <div className={cn(styles.baseSelect, className)}>
      <label htmlFor={name} className={styles.fieldLabel}>
        {label}
        {rules?.required && <span style={{ color: '#F03E3E' }}>*</span>}
      </label>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <div className={styles.select}>
            <Select
              {...field}
              MenuProps={{
                sx: BaseMenuSx,
              }}
              className={customSelectClassName}
              value={field.value ?? ''}
              displayEmpty
              fullWidth
              error={!!error}
              disabled={disabled}
              IconComponent={ArrowDownIconComponent}
              sx={{
                height: '40px',
                fontSize: '14px',
                textAlign: 'start',
                '& fieldset': {
                  border: '1px solid var(--gray-200)',
                },
                '&:hover': {
                  '&& fieldset': {
                    border: '1px solid var(--primary-color-600)',
                  },
                },
                '&.Mui-disabled': {
                  backgroundColor: 'var(--gray-100)',
                },
                '.MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-150) !important',
                  borderRadius: '6px',
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--primary-color-600) !important',
                  borderWidth: '1px',
                  boxShadow: '0px 0px 0px 2px #1890FF33',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--primary-color-600) !important',
                },
                '&.Mui-disabled:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-150) !important',
                },
                '& .MuiSelect-icon': {},
                '& .MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input':
                  {
                    paddingLeft: '12px',
                  },
              }}
            >
              {hasPlaceholder && (
                <MenuItem value='' className={placeholderClassName}>
                  {placeholder}
                </MenuItem>
              )}
              {data &&
                _.size(data) > 0 &&
                data.map((item: any, index: number) => (
                  <MenuItem value={item.id ?? item} key={item + index}>
                    {item.label ?? item}
                  </MenuItem>
                ))}
            </Select>
            <FormHelperText>{error ? error.message : ''}</FormHelperText>
          </div>
        )}
      />
    </div>
  );
};

export default BaseSelect;
