import ArrowDownIcon from '@/assets/direction-icons/icon-chevron-down.svg?react';
import styles from '@/modules/admin/styles/AdminMain.module.scss';
import { Box, MenuItem, Popover, TextField } from '@mui/material';
import FormHelperText from '@mui/material/FormHelperText';
import { Atom, useAtom } from 'jotai';
import { AtomWithQueryResult } from 'jotai-tanstack-query';
import _ from 'lodash';
import React, {
  Dispatch,
  ReactNode,
  SetStateAction,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { Controller } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import SearchInput from '../../Search/Input';
import searchSelectStyles from './SearchSelect.module.scss';

interface SearchSelectProps {
  className?: string;
  getData: Atom<AtomWithQueryResult<any, Error>>;
  dataKey?: string;
  labelKey?: string;
  valueKey?: string;
  control: any;
  selectedItem: [any, Dispatch<SetStateAction<any | null>>];
  searchState: [string, Dispatch<SetStateAction<string>>];
  name: string;
  label?: string;
  defaultValue?: string;
  rules?: any;
  disabled?: boolean;
  placeholder?: string;
  searchPlaceholder?: string;
  setValue?: (name: string, value: string) => void;
  onAfterSetValue?: (name: string, value: any) => void;
  noDataPrefix?: ReactNode;
  noDataNode?: ReactNode;
  noDataAction?: () => void;
}

const BaseSearchSelect: React.FC<SearchSelectProps> = ({
  className = '',
  getData,
  dataKey,
  labelKey = 'name',
  valueKey = 'id',
  control,
  selectedItem,
  searchState,
  name,
  label,
  defaultValue = '',
  rules,
  disabled,
  placeholder,
  searchPlaceholder,
  setValue,
  onAfterSetValue,
  noDataPrefix,
  noDataNode,
  noDataAction,
}) => {
  const { t } = useTranslation('admin');
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [{ data }] = useAtom(getData);
  const [search, setSearch] = searchState;

  const filteredData = useMemo(() => {
    const value = (item: any) =>
      dataKey ? item[dataKey][labelKey] : item[labelKey];

    return [...(data ?? [])].filter((item) =>
      value(item)?.toLowerCase()?.includes(search.trim().toLowerCase())
    );
  }, [data, dataKey, labelKey, search]);

  const handleClick = (event: any) => {
    !disabled && setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleSetValue = useCallback(
    (value: any) => {
      const currentSelectedKey = dataKey
        ? selectedItem[0]?.[dataKey][valueKey]
        : selectedItem[0]?.[valueKey];

      const newSelectedKey = dataKey
        ? value?.[dataKey][valueKey]
        : value?.[valueKey];

      const newValue = currentSelectedKey !== newSelectedKey ? value : null;
      const valueToSet = !newValue
        ? newValue
        : dataKey
          ? newValue[dataKey][valueKey]
          : newValue[valueKey];

      setValue && setValue(name, valueToSet);
      selectedItem[1](newValue);
      setAnchorEl(null);
      onAfterSetValue && onAfterSetValue(name, newValue);
    },
    [dataKey, name, onAfterSetValue, setValue, valueKey, selectedItem]
  );

  useEffect(() => {
    searchState[1]('');
    if (!defaultValue) {
      selectedItem[1]('');
    }
  }, []);

  useEffect(() => {
    setValue && setValue(name, defaultValue);
  }, [defaultValue, name, setValue]);

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !filteredData.length) {
      if (noDataAction) {
        noDataAction();
        setAnchorEl(null);
      }
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleNoDataClick = useCallback(() => {
    noDataAction && noDataAction();
    setAnchorEl(null);
  }, [noDataAction]);

  const getValue = (item: any) => {
    if (!item) {
      return '';
    }
    return dataKey ? item?.[dataKey][labelKey] : item?.[labelKey];
  };

  return (
    <div className={styles.selectLayout}>
      <label htmlFor={name} className={styles.fieldLabel}>
        {label}
        {rules?.required && <span style={{ color: '#F03E3E' }}>*</span>}
      </label>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <div className={searchSelectStyles.wrapper}>
            <TextField
              className={className}
              onClick={(event) => {
                handleClick(event);
              }}
              onKeyDown={(e) => e.preventDefault()}
              aria-readonly
              {...field}
              multiline={false}
              value={getValue(selectedItem[0])}
              error={!!error}
              helperText={error ? error.message : ''}
              placeholder={placeholder}
              disabled={disabled}
              size='small'
              type='text'
              fullWidth
              InputProps={{
                endAdornment: <ArrowDownIcon />,
              }}
              sx={{
                '.MuiInputBase-root': {
                  cursor: 'pointer',
                  borderRadius: '6px',
                  height: 'unset',
                  padding: '10px 12px',
                  'input, textarea': {
                    color: 'var(--gray-900)',
                    padding: '0',
                    '&::placeholder': {
                      color: 'var(--gray-500)',
                      opacity: 1,
                    },
                  },
                },
                '& input': {
                  caretColor: 'transparent',
                  cursor: 'pointer',
                },
                '.MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-200) !important',
                  borderRadius: '6px',
                },
                '& .Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--primary-color-600) !important',
                  borderWidth: '1px',
                  boxShadow: '0px 0px 0px 2px #1890FF33',
                },
                '& .Mui-disabled': {
                  backgroundColor: 'var(--gray-100)',
                },
                '&:hover .Mui-disabled': {
                  '.MuiOutlinedInput-notchedOutline': {
                    borderColor: 'var(--gray-200) !important',
                  },
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--primary-color-600) !important',
                },
              }}
            />
            <Popover
              sx={{
                '.MuiPaper-root': {
                  width: '552px',
                  marginTop: '2px',
                  height: '220px',
                  padding: '8px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  flexShrink: '0',
                  borderRadius: '8px',
                  background: 'var(--white)',
                  boxShadow: '0px 0px 10px 0px rgba(0, 0, 0, 0.20)',
                },
              }}
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleClose}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              className={styles.searchValue}
            >
              <SearchInput
                onKeyUp={handleOnKeyUpToSend}
                setSearch={setSearch}
                placeholder={searchPlaceholder}
                search={search}
              />
              <div className={searchSelectStyles.itemArea}>
                {filteredData &&
                  _.size(data) > 0 &&
                  filteredData.map((item: any, index: number) => (
                    <MenuItem
                      onMouseDown={() => handleSetValue(item)}
                      value={getValue(item)}
                      key={index}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        borderRadius: '6px',
                      }}
                    >
                      {dataKey ? item[dataKey][labelKey] : item[labelKey]}
                    </MenuItem>
                  ))}
                {(!filteredData || _.size(filteredData) === 0) && (
                  <div className={searchSelectStyles.noResults}>
                    <div className={searchSelectStyles.noResultsText}>
                      {t('empty')}
                    </div>
                    {search && (
                      <Box
                        className={searchSelectStyles.noDataAction}
                        onClick={handleNoDataClick}
                      >
                        {noDataPrefix}
                        {noDataNode}
                      </Box>
                    )}
                  </div>
                )}
              </div>
            </Popover>
            <FormHelperText>{error ? error.message : ''}</FormHelperText>
          </div>
        )}
      />
    </div>
  );
};

export default BaseSearchSelect;
