import React, { useEffect } from 'react';
import { FormControlLabel, Radio, RadioGroup } from '@mui/material';
import { Controller } from 'react-hook-form';
import { styled } from '@mui/material/styles';
import styles from '@/modules/admin/styles/AdminMain.module.scss';
import cn from 'classnames';
import radioStyles from './Radio.module.scss';

interface BaseRadioGroupProps {
  label: string;
  name: string;
  options: { value: string | number; label: string }[];
  control?: any;
  defaultValue?: string | number;
  setValue?: (name: string, value: string | number | undefined) => void;
  rules?: any;
  className?: string;
}

const StyledRadio = styled(Radio)(() => ({
  color: 'var(--gray-300)',
  '&.Mui-checked': {
    color: 'var(--primary-color-800) !important',
  },
}));

const BaseRadioGroup: React.FC<BaseRadioGroupProps> = ({
  label,
  name,
  options,
  control,
  defaultValue,
  setValue,
  rules,
  className = '',
}) => {
  useEffect(() => {
    setValue && setValue(name, defaultValue);
  }, [defaultValue, name, setValue]);

  return (
    <div className={cn(radioStyles.layout, className)}>
      <label htmlFor={name} className={styles.fieldLabel}>
        {label}
        {rules?.required && <span style={{ color: '#F03E3E' }}>*</span>}
      </label>

      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field }) => (
          <RadioGroup {...field} value={field.value ?? ''} row>
            {options.map((option) => (
              <FormControlLabel
                key={option.value}
                value={option.value}
                control={<StyledRadio checked={field.value === option.value} />}
                label={option.label}
              />
            ))}
          </RadioGroup>
        )}
      />
    </div>
  );
};

export default BaseRadioGroup;
