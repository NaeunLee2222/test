import { ChangeEvent, useState } from 'react';
import { styled } from '@mui/material/styles';
import { Controller } from 'react-hook-form';
import Button from '@mui/material/Button';
import { useTranslation } from 'react-i18next';
import IconUpload from '@/assets/basic-icons/icon-upload.svg?react';
import IconDelete from '@/assets/basic-icons/icon-multiple-delete.svg?react';
import { TextField } from '@mui/material';
import _ from 'lodash';
import styles from '../../styles/AdminMain.module.scss';
import inputStyles from './Inputs/Input.module.scss';

type BaseUploadProps = {
  onChange: (event: any) => void;
  rules?: any;
  control: any;
  name: string;
};

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

const BaseUploadFile: React.FC<BaseUploadProps> = ({
  control,
  name,
  onChange,
  rules,
}) => {
  const { t } = useTranslation('admin');
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
  } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | undefined>(
    undefined
  );

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event?.target?.files?.[0];
    if (file) {
      const allowedTypes = [
        'image/jpeg',
        'image/png',
        'image/jpg',
        'application/pdf',
      ];
      const maxSize = 5 * 1024 * 1024; // 5MB

      if (allowedTypes.includes(file.type) && file.size <= maxSize) {
        setSelectedFile(file);
        onChange && onChange(file);
      } else {
        setSelectedFile(null);
        setErrorMessage('errorUploadFileImage');
        return;
      }
    }
    setErrorMessage(undefined);
  };

  const handleRemove = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.stopPropagation();
    e.preventDefault();
    setSelectedFile(null);
    onChange && onChange(null);
  };

  return (
    <div className={inputStyles.layout}>
      <label htmlFor='inputFile' className={styles.fieldLabel}>
        {t('file')}
        {rules?.required && (
          <span style={{ color: '#F03E3E', marginLeft: '4px' }}> *</span>
        )}
      </label>
      <div
        style={{
          width: '100%',
        }}
      >
        <Controller
          name={name}
          control={control}
          rules={rules}
          render={({ field, fieldState: { error } }) => {
            let erMess = '';
            if (error?.message && !errorMessage && !selectedFile) {
              erMess = error ? error.message : '';
            } else if (errorMessage) {
              erMess = t(errorMessage);
            }
            return (
              <TextField
                {...field}
                value={selectedFile?.name ?? t('validateImageFile')}
                variant='outlined'
                helperText={erMess}
                size='small'
                error={(!!error && !selectedFile) || !_.isEmpty(errorMessage)}
                sx={{
                  ':first-of-type': {
                    width: '100%',
                  },
                  'input': {
                    color: selectedFile ? 'var(--gray-900)' : 'var(--gray-500)',
                  },
                  '& fieldset': {
                    border: '1px solid var(--gray-200)',
                  },
                  '&:hover': {
                    '&& fieldset': {
                      border: '1px solid var(--primary-color-600)',
                    },
                  },
                }}
                InputProps={{
                  endAdornment: (
                    <>
                      {selectedFile ? (
                        <IconDelete
                          style={{
                            position: 'absolute',
                            right: 0,
                            width: '38px',
                            height: '38px',
                            cursor: 'pointer',
                            padding: '10px',
                            borderLeft: '1px solid #ddd',
                          }}
                          fill='var(--gray-600)'
                          onClick={(event: ChangeEvent<HTMLInputElement>) =>
                            handleRemove(event)
                          }
                        />
                      ) : (
                        <Button
                          component='label'
                          role={undefined}
                          tabIndex={-1}
                          endIcon={
                            <IconUpload
                              data-testid='upload-icon'
                              style={{
                                width: '38px',
                                height: '38px',
                                padding: '10px',
                                borderLeft: '1px solid #ddd',
                              }}
                            />
                          }
                          sx={{
                            padding: 0,
                            minWidth: 0,
                            position: 'absolute',
                            right: 0,
                            'span': {
                              margin: 0,
                            },
                          }}
                        >
                          <VisuallyHiddenInput
                            type='file'
                            onChange={(e) => {
                              handleChange(e);
                              field.onChange(e.target?.value);
                            }}
                          />
                        </Button>
                      )}
                    </>
                  ),
                }}
              />
            );
          }}
        />
      </div>
    </div>
  );
};

export default BaseUploadFile;
