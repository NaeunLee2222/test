import HidePasswordIcon from '@/assets/basic-icons/icon-hide-password.svg?react';
import ShowPasswordIcon from '@/assets/basic-icons/icon-show-password-revert.svg?react';
import styles from '@/modules/admin/styles/AdminMain.module.scss';
import TextField from '@mui/material/TextField';
import cn from 'classnames';
import React, { useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import inputStyles from './Input.module.scss';

interface BaseInputProps {
  control: any;
  name: string;
  label?: string;
  defaultValue?: string;
  rules?: any;
  disabled?: boolean;
  readonly?: boolean;
  endIcon?: React.ReactNode;
  placeholder?: string;
  type?: string;
  rows?: number;
  setValue?: (name: string, value: string) => void;
  maxLength?: number;
  className?: string;
}

const BaseInput: React.FC<BaseInputProps> = ({
  control,
  name,
  label,
  defaultValue = '',
  rules,
  disabled,
  readonly,
  endIcon,
  placeholder,
  type,
  setValue,
  rows = 1,
  maxLength = 0,
  className = '',
}) => {
  const [hidePassword, setHidePassword] = useState(true);

  const renderEndAdornment = () => {
    if (type === 'password') {
      return (
        <button
          type='button'
          className={inputStyles.passwordIcon}
          onClick={() => setHidePassword(!hidePassword)}
        >
          {hidePassword ? (
            <ShowPasswordIcon
              fill='var(--gray-500)'
              style={{ width: '20px', height: '20px' }}
            />
          ) : (
            <HidePasswordIcon
              fill='var(--gray-500)'
              style={{ width: '20px', height: '20px' }}
            />
          )}
        </button>
      );
    }
    return endIcon;
  };

  const getInputHeight = () => {
    switch (rows) {
      case 4:
        return '100px !important';
      case 5:
        return '120px !important';
      case 8:
        return '200px !important';
      default:
        return '144px !important';
    }
  };

  useEffect(() => {
    setValue && setValue(name, defaultValue);
  }, [defaultValue, name, setValue]);

  return (
    <div className={cn(inputStyles.layout, className)}>
      {label && (
        <label htmlFor={name} className={styles.fieldLabel}>
          {label}
          {rules?.required && <span style={{ color: '#F03E3E' }}>*</span>}
        </label>
      )}
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <TextField
            {...field}
            multiline={rows > 1}
            rows={rows}
            value={field.value ?? ''}
            error={!!error}
            helperText={error ? error.message : ''}
            placeholder={placeholder}
            disabled={disabled}
            size='small'
            type={type === 'password' && hidePassword ? 'password' : 'text'}
            fullWidth
            InputProps={{
              endAdornment: (
                <span className={styles.endIcon}>{renderEndAdornment()}</span>
              ),
            }}
            onKeyDown={(e) => readonly && e.preventDefault()}
            inputProps={{ maxLength: maxLength > 0 ? maxLength : 200 }}
            sx={{
              '.MuiInputBase-root': {
                borderRadius: '6px',
                height: getInputHeight(),
                padding: '10px 12px',
                'input, textarea': {
                  color: 'var(--gray-900)',
                  padding: '0',
                  lineHeight: '140%',
                  '&::placeholder': {
                    color: 'var(--gray-500)',
                    opacity: 1,
                  },
                },
              },
              '.MuiOutlinedInput-notchedOutline': {
                borderColor: 'var(--gray-200) !important',
                borderRadius: '6px',
              },
              '& .Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: 'var(--primary-color-600) !important',
                borderWidth: '1px',
                boxShadow: '0px 0px 0px 2px #1890FF33',
              },
              '& .Mui-disabled': {
                backgroundColor: 'var(--gray-100)',
              },
              '&:hover .Mui-disabled': {
                '.MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-200) !important',
                },
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: 'var(--primary-color-600) !important',
              },
            }}
          />
        )}
      />
    </div>
  );
};

export default BaseInput;
