import HidePasswordIcon from '@/assets/basic-icons/icon-hide-password.svg?react';
import ShowPasswordIcon from '@/assets/basic-icons/icon-show-password.svg?react';
import styles from '@/modules/admin/styles/AdminMain.module.scss';
import TextField from '@mui/material/TextField';
import React, { useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import inputStyles from './Input.module.scss';

interface BaseInputProps {
  control: any;
  name: string;
  label: string;
  defaultValue?: string;
  rules?: any;
  disabled?: boolean;
  endIcon?: React.ReactNode;
  placeholder?: string;
  type?: string;
  rows?: number;
  setValue?: (name: string, value: string) => void;
  maxLength?: number;
  helperText?: string;
}

const BaseInput: React.FC<BaseInputProps> = ({
  control,
  name,
  label,
  defaultValue = '',
  rules,
  disabled,
  endIcon,
  placeholder,
  type,
  setValue,
  rows = 1,
  maxLength = 0,
  helperText,
}) => {
  const [hidePassword, setHidePassword] = useState(true);

  const renderEndAdornment = () => {
    if (type === 'password') {
      return (
        <button
          type='button'
          className={inputStyles.passwordIcon}
          onClick={() => setHidePassword(!hidePassword)}
        >
          {hidePassword ? (
            <HidePasswordIcon
              fill='var(--gray-600)'
              style={{ width: '16px', height: '16px' }}
            />
          ) : (
            <ShowPasswordIcon
              fill='var(--gray-600)'
              style={{ width: '16px', height: '16px' }}
            />
          )}
        </button>
      );
    }
    return endIcon;
  };

  useEffect(() => {
    setValue && setValue(name, defaultValue);
  }, [defaultValue, name, setValue]);

  return (
    <div className={inputStyles.layout}>
      <div className={inputStyles.labelLayout}>
        <div className={inputStyles.label}>{label}</div>
        <div className={inputStyles.helperText}>{helperText}</div>
      </div>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field, fieldState: { error } }) => (
          <TextField
            {...field}
            multiline={rows > 1}
            rows={rows}
            value={field.value ?? ''}
            error={!!error}
            helperText={error ? error.message : ''}
            placeholder={placeholder}
            disabled={disabled}
            size='small'
            type={type === 'password' && hidePassword ? 'password' : 'text'}
            fullWidth
            InputProps={{
              endAdornment: (
                <span className={styles.endIcon}>{renderEndAdornment()}</span>
              ),
            }}
            inputProps={{ maxLength: maxLength > 0 ? maxLength : 200 }}
            sx={{
              '.MuiInputBase-root': {
                borderRadius: '6px',
                paddingRight: '12px',
                'input': {
                  color: 'var(--gray-900)',
                  padding: '10px 8px 10px 12px',
                  textAlign: 'right',
                  '&::placeholder': {
                    opacity: 1,
                  },
                },
              },
              '& fieldset': {
                border: '1px solid var(--gray-200)',
              },
              '&:hover': {
                '& fieldset': {
                  border: !disabled
                    ? '1px solid var(--primary-color-600)'
                    : '1px solid var(--gray-200)',
                },
              },
              '& .Mui-disabled': {
                backgroundColor: 'var(--gray-100)',
                borderRadius: '6px',

                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--gray-200) !important',
                },

                'input': {
                  color: 'var(--gray-400)',
                },
              },
              '.MuiOutlinedInput-notchedOutline': {
                borderColor: 'var(--gray-200)',
                borderRadius: '6px',
              },
              '& .Mui-focused .MuiOutlinedInput-notchedOutline': {
                border: '1px solid var(--primary-color-600)',
                boxShadow: '0px 0px 0px 2px #1890FF33',
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: !disabled
                  ? 'var(--primary-color-600)'
                  : 'var(--gray-200)',
              },
              '& .css-jedpe8-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input':
                {
                  paddingLeft: '12px',
                },
            }}
          />
        )}
      />
    </div>
  );
};

export default BaseInput;
