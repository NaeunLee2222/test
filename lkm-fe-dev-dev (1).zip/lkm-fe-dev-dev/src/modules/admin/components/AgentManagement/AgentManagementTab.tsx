import { Box } from '@mui/material';
import { AgentSearch } from '@/modules/admin/components/AgentManagement/AgentSearch';
import styles from '@/modules/admin/components/AgentManagement/AgentManagement.module.scss';
import { EAgentManagementTabMode } from '@/types/common';
import { AgentTable } from '@/modules/admin/components/AgentManagement/AgentTable';
import { Atom, PrimitiveAtom } from 'jotai';
import { AtomWithQueryResult } from 'jotai-tanstack-query';

interface IProps {
  type: EAgentManagementTabMode;
  getData: Atom<AtomWithQueryResult<any, Error>>;
  paginationSettingAtom: PrimitiveAtom<any>;
}

const AgentManagementTab = ({
  type,
  getData,
  paginationSettingAtom,
}: IProps) => (
  <Box className={styles.agentManagementTab}>
    <Box className={styles.formSearch} data-testid='search-container'>
      <AgentSearch />
    </Box>
    <Box className={styles.tableWrapper}>
      <AgentTable
        type={type}
        getData={getData}
        paginationSettingAtom={paginationSettingAtom}
      />
    </Box>
  </Box>
);

export { AgentManagementTab };
