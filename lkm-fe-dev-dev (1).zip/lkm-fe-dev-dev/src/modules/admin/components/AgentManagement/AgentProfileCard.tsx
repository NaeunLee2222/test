import CompanyIcon from '@/assets/basic-icons/icon-company.svg?react';
import EmailIcon from '@/assets/basic-icons/icon-email.svg?react';
import { useAtom } from 'jotai';
import { useUserDetailQuery } from '@/modules/core/hooks';
import { useAgentDetail } from '@/modules/chat/hooks/useAgents';
import { Box, Skeleton } from '@mui/material';
import styles from './AgentProfileCard.module.scss';

const AgentProfileCard = () => {
  const [{ data, isFetching: userFetching }] = useAtom(useUserDetailQuery);
  const [{ isFetching }] = useAtom(useAgentDetail);

  return (
    <div className={styles.card}>
      {isFetching || userFetching ? (
        <Box sx={{ display: 'flex', flexDirection: 'row', gap: '4px' }}>
          <Skeleton variant='circular' width={50} height={50} />
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <Skeleton variant='rounded' width={100} height={25} />
            <Skeleton variant='rounded' width={350} height={20} />
          </Box>
        </Box>
      ) : (
        <>
          <div className={styles.logo}>
            <div>{data?.username?.split('')?.[0]}</div>
          </div>
          <div className={styles.userDetails}>
            <div className={styles.name}>{data?.username}</div>
            <div className={styles.userInfo}>
              <div className={styles.company}>
                <CompanyIcon />
                <div className={styles.companyName}>
                  {data?.company?.name ?? ''}
                </div>
              </div>
              <div className={styles.divider} />
              <div className={styles.email}>
                <EmailIcon />
                <div>
                  <a href={`mailto:${data?.email}`}>{data?.email}</a>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AgentProfileCard;
