import GeneralAgentReview from '@/modules/agent/pages/GeneralAgentReview';
import AgentProfileCard from './AgentProfileCard';

const AgentGeneralSettings = () => (
  <GeneralAgentReview headerNode={<AgentProfileCard />} />
);

export default AgentGeneralSettings;
