import Calendar from '@/assets/basic-icons/icon-calendar2.svg?react';
import styles from '@/modules/admin/components/AgentManagement/AgentManagement.module.scss';
import SearchSelect from '@/modules/admin/components/Search/Select';
import {
  defaultAgentFilterValue,
  listAdminAgentPaginationAtom,
} from '@/modules/admin/jotai/agent';
import { EChatAgentStatus } from '@/modules/chat/types/agents';
import { DateTimeAdminTableFormat } from '@/types/common';
import { formatDateToKst } from '@/utils';
import { Button, TextField } from '@mui/material';
import cn from 'classnames';
import dayjs from 'dayjs';
import { useAtom } from 'jotai';
import { useCallback, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { DatePicker } from 'rsuite';
import 'rsuite/DateRangePicker/styles/index.css';

export const AgentSearch = () => {
  const { t } = useTranslation('admin');
  const [search, setSearch] = useState('');
  const [dateType, setDateType] = useState('');
  const [startDate, setStartDate] = useState<Date | null>();
  const [endDate, setEndDate] = useState<Date | null>();
  const [reviewStatus, setReviewStatus] = useState('');
  const [, setListAdminAgentPagination] = useAtom(listAdminAgentPaginationAtom);

  const dateTypeOptions = [
    { value: '', label: t('all') },
    {
      value: 'registered_at',
      label: t('agentManagement.table.applicationDate'),
    },
    {
      value: 'reviewed_at',
      label: t('agentManagement.table.approveRejectionDate'),
    },
  ];

  const reviewStatusOptions = [
    { value: '', label: t('all') },
    {
      value: EChatAgentStatus.SUBMITTED.toString(),
      label: t('tableStatus.submit'),
    },
    {
      value: EChatAgentStatus.DEPLOYED.toString(),
      label: t('tableStatus.approval'),
    },
    {
      value: EChatAgentStatus.REJECTED.toString(),
      label: t('tableStatus.rejection'),
    },
  ];

  const handleSearch = useCallback(() => {
    setListAdminAgentPagination((prev) => ({
      page: 0,
      rowsPerPage: prev.rowsPerPage,
      agent_type: prev.agent_type,
      date_type: dateType || undefined,
      end_date: endDate ? formatDateToKst(endDate.toISOString()) : undefined,
      start_date: startDate
        ? formatDateToKst(startDate.toISOString())
        : undefined,
      review_status: reviewStatus || undefined,
      search: search || undefined,
      sortDetail: prev.sortDetail,
    }));
  }, [
    dateType,
    endDate,
    reviewStatus,
    search,
    setListAdminAgentPagination,
    startDate,
  ]);

  const handleOnKeyUpToSend = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      setSearch((e.target as HTMLInputElement).value);
      handleSearch();
    } else {
      setSearch((e.target as HTMLInputElement).value);
    }
  };

  const handleClear = useCallback(() => {
    setDateType('');
    setReviewStatus('');
    setStartDate(undefined);
    setEndDate(undefined);
    setSearch('');
    setListAdminAgentPagination((prev) => ({
      ...defaultAgentFilterValue,
      agent_type: prev.agent_type,
    }));
  }, [setListAdminAgentPagination, setSearch]);

  const setReviewStatusAndSearch = useCallback(
    (value: string) => {
      setReviewStatus(value);
      setListAdminAgentPagination((prev) => ({
        ...prev,
        review_status: value,
      }));
      handleSearch();
    },
    [setListAdminAgentPagination, handleSearch]
  );

  const setStartDateAndSearch = useCallback(
    (value: Date | null) => {
      if (endDate) {
        let resultStartData = value;
        const startDateExc = dayjs(value);
        const endDateExc = dayjs(endDate);
        const diff = startDateExc.diff(endDateExc);

        if (diff > 0) {
          resultStartData = endDate;
        }
        setStartDate(resultStartData);
        setListAdminAgentPagination((prev) => ({
          ...prev,
          date_type: dateType ?? undefined,
          start_date: resultStartData
            ? formatDateToKst(resultStartData.toISOString())
            : undefined,
          end_date: endDate
            ? formatDateToKst(endDate.toISOString())
            : undefined,
        }));
        return;
      }

      setStartDate(value);
    },
    [setListAdminAgentPagination, endDate, dateType]
  );

  const setEndDateAndSearch = useCallback(
    (value: Date | null) => {
      if (startDate) {
        let resultEndDate = value;
        const startDateExc = dayjs(startDate);
        const endDateExc = dayjs(value);

        const diff = endDateExc.diff(startDateExc);

        if (diff < 0) {
          resultEndDate = startDate;
        }
        setEndDate(resultEndDate);

        setListAdminAgentPagination((prev) => ({
          ...prev,
          date_type: dateType ?? undefined,
          start_date: startDate
            ? formatDateToKst(startDate.toISOString())
            : undefined,
          end_date: resultEndDate
            ? formatDateToKst(resultEndDate.toISOString())
            : undefined,
        }));
        return;
      }
      setEndDate(value);
    },
    [setListAdminAgentPagination, startDate, dateType]
  );

  const setDateTypeAndSearch = useCallback(
    (value: string) => {
      setDateType(value);
      if (startDate && endDate) {
        setListAdminAgentPagination((prev) => ({ ...prev, date_type: value }));
        handleSearch();
      }
    },
    [setListAdminAgentPagination, endDate, handleSearch, startDate]
  );

  return (
    <div className={styles.searchContainer}>
      <div className={styles.selectContainer}>
        <div className={styles.selectField}>
          <div
            className={styles.label}
          >{`${t('agentManagement.form.period.title')}`}</div>
          <SearchSelect
            options={dateTypeOptions}
            defaultValue=''
            value={dateType}
            handleChange={setDateTypeAndSearch}
            height='32px'
          />
        </div>
        <div className={styles.dateSelectText}>
          <DatePicker
            className={cn(styles.datePickerField, 'custom-date-picker')}
            oneTap
            editable={false}
            format={DateTimeAdminTableFormat.yyyyMMdd}
            placeholder={t('agentDatePlaceholder')}
            value={startDate}
            onChange={(value: Date | null) => setStartDateAndSearch(value)}
            caretAs={Calendar}
          />
          <div className={styles.tilde}>~</div>
          <DatePicker
            className={cn(styles.datePickerField, 'custom-date-picker')}
            oneTap
            editable={false}
            format={DateTimeAdminTableFormat.yyyyMMdd}
            placeholder={t('agentDatePlaceholder')}
            value={endDate}
            onChange={(value: Date | null) => setEndDateAndSearch(value)}
            caretAs={Calendar}
          />
        </div>
        <div className={styles.selectField}>
          <div
            className={styles.label}
          >{`${t('agentManagement.form.situation.title')}`}</div>
          <SearchSelect
            options={reviewStatusOptions}
            defaultValue=''
            value={reviewStatus}
            handleChange={setReviewStatusAndSearch}
            height='32px'
          />
        </div>
      </div>

      <div className={styles.inputText}>
        <div className={styles.label}>{`${t('search')}`}</div>
        <TextField
          value={search}
          onKeyUp={handleOnKeyUpToSend}
          onChange={(e) => setSearch(e?.target?.value)}
          placeholder={t('agentManagement.form.searchPlaceholder')}
          className={styles.textField}
          sx={{
            '& fieldset': {
              border: '1px solid var(--gray-150)',
            },
            '&:hover': {
              '&& fieldset': {
                border: '1px solid var(--primary-color-600)',
              },
            },
          }}
        />
      </div>
      <div className={styles.searchAction}>
        <Button
          variant='outlined'
          className={styles.clear}
          onClick={handleClear}
          type='button'
          tabIndex={0}
          size='small'
        >
          {t('reset')}
        </Button>
        <Button
          size='small'
          variant='contained'
          className={styles.search}
          onClick={handleSearch}
          type='button'
          tabIndex={0}
          sx={{ boxShadow: 'none' }}
        >
          {t('check')}
        </Button>
      </div>
    </div>
  );
};
