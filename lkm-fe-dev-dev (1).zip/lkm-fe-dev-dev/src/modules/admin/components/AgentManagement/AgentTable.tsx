import styles from '@/modules/admin/components/AgentManagement/AgentManagement.module.scss';
import { BaseTable } from '@/modules/admin/components/Table/BaseTable';
import { showHeaderNodeAtom } from '@/modules/agent/jotai/agent';
import { RoutesURL } from '@/routers/routes';
import {
  EAgentManagementTabMode,
  EAgentTableStatus,
  EmptyString,
} from '@/types/common';
import { formatDateToKst } from '@/utils';
import { Box } from '@mui/material';
import cn from 'classnames';
import { Atom, PrimitiveAtom, useAtom } from 'jotai';
import { AtomWithQueryResult } from 'jotai-tanstack-query';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

interface IProps {
  type: EAgentManagementTabMode;
  getData: Atom<AtomWithQueryResult<any, Error>>;
  paginationSettingAtom: PrimitiveAtom<any>;
}

export const AgentTable = ({
  type,
  getData,
  paginationSettingAtom,
}: IProps) => {
  const { t } = useTranslation('admin');
  const navigate = useNavigate();
  const [, setShowHeaderNode] = useAtom(showHeaderNodeAtom);

  const columns = useMemo(
    () => [
      {
        name: 'id',
        label: t('agentManagement.table.number'),
        width: '80px',
        sortable: true,
        format: (_value: any, row: any) => <span>{row.id || EmptyString}</span>,
      },
      {
        name: 'user_name',
        label: t('agentManagement.table.proposer'),
        width: '120px',
        sortable: true,
        format: (value: any, _row: any) => <span>{value || EmptyString}</span>,
      },
      {
        name: 'name',
        label: t('agentManagement.table.agentName'),
        // width: '50%',
        sortable: true,
        format: (value: any, row: any) => (
          <Box
            className={styles.tableLink}
            onClick={(e) => handleNavigate(e, row)}
          >
            {value || EmptyString}
          </Box>
        ),
      },
      {
        name: 'review_status',
        label: t('agentManagement.table.situation'),
        width: '80px',
        sortable: true,
        format: (value: any, _row: any) => (
          <Box className={cn(styles.status, setStatusCss(value))}>
            {getStatusTitle(value) || EmptyString}
          </Box>
        ),
        contentAlign: 'center',
      },
      {
        name: 'registered_at',
        label: t('agentManagement.table.applicationDate'),
        width: '120px',
        sortable: true,
        format: (value: any, _row: any) => (
          <span>
            {value
              ? formatDateToKst(new Date(value).toISOString(), 'YYYY.MM.DD')
              : EmptyString}
          </span>
        ),
      },
      {
        name: 'reviewed_at',
        label: t('agentManagement.table.approveRejectionDate'),
        width: '120px',
        sortable: true,
        format: (value: any, _row: any) => (
          <span>
            {value
              ? formatDateToKst(new Date(value).toISOString(), 'YYYY.MM.DD')
              : EmptyString}
          </span>
        ),
      },
    ],

    [t]
  );

  const setStatusCss = (status: string) => {
    switch (status) {
      case EAgentTableStatus.APPROVAL:
        return styles.approval;
      case EAgentTableStatus.REJECTION:
        return styles.rejection;
      default:
        return styles.submit;
    }
  };

  const getStatusTitle = (status: string) => {
    switch (status) {
      case EAgentTableStatus.SUBMIT:
        return t('tableStatus.submit');
      case EAgentTableStatus.APPROVAL:
        return t('tableStatus.approval');
      case EAgentTableStatus.REJECTION:
        return t('tableStatus.rejection');
      default:
        return t('tableStatus.submit');
    }
  };

  const handleNavigate = (e: React.MouseEvent<HTMLDivElement>, row: any) => {
    e.stopPropagation();
    e.preventDefault();
    setShowHeaderNode(true);

    navigate(
      type === EAgentManagementTabMode.NORMAL
        ? `${RoutesURL.SETTINGS_AGENT_GENERAL_REGISTRATION}/${row.id}`
        : `${RoutesURL.SETTINGS_AGENT_LKM_REGISTRATION}/${row.id}`
    );
  };

  return (
    <BaseTable
      columns={columns}
      paginationSettingAtom={paginationSettingAtom}
      getData={getData}
      keyField='id'
      showSelected={false}
      showCountStatus
      unit={t('piece')}
    />
  );
};
