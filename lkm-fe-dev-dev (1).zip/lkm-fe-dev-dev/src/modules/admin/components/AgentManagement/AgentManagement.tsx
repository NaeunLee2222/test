import styles from '@/modules/admin/components/AgentManagement/AgentManagement.module.scss';
import { AgentManagementTab } from '@/modules/admin/components/AgentManagement/AgentManagementTab';
import { CustomTabPanel } from '@/modules/admin/components/TabProps';
import { useAdminAgentManagement } from '@/modules/admin/hooks/useAgentManagement';
import { listAdminAgentPaginationAtom } from '@/modules/admin/jotai/agent';
import { AgentType } from '@/modules/agent/type/agent';
import { EAgentManagementTabMode } from '@/types/common';
import { Box, Tab, Tabs } from '@mui/material';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

const AgentManagement = () => {
  const { t } = useTranslation('admin');

  const [tabIndex, setTabIndex] = useState(0);
  const [, setListAdminAgentPagination] = useAtom(listAdminAgentPaginationAtom);
  const [{ data }] = useAtom(useAdminAgentManagement);

  useEffect(() => {
    setListAdminAgentPagination((prev) => ({
      page: 0,
      rowsPerPage: prev.rowsPerPage,
      agent_type: tabIndex === 0 ? AgentType.GENERAL : AgentType.PRO,
      date_type: undefined,
      start_date: undefined,
      end_date: undefined,
      review_status: undefined,
      search: undefined,
      order_by: undefined,
      order_direction: undefined,
    }));
  }, []);

  const handleChange = (_event: React.SyntheticEvent, newTabIndex: number) => {
    let agentType = AgentType.GENERAL;

    // The index = 1 is for Pro agent
    if (newTabIndex === 1) {
      agentType = AgentType.PRO;
    }

    setListAdminAgentPagination((prev) => ({
      page: 0,
      rowsPerPage: prev.rowsPerPage,
      agent_type: agentType,
      date_type: undefined,
      start_date: undefined,
      end_date: undefined,
      review_status: undefined,
      search: undefined,
      order_by: undefined,
      order_direction: undefined,
    }));

    setTabIndex(newTabIndex);
  };

  const displayedTotal = useCallback(
    (isCurrentTab: boolean) => {
      if (data) {
        if (isCurrentTab) {
          return data.total_count;
        }

        return data.alter_total ?? 0;
      }

      return '';
    },
    [data]
  );

  return (
    <Box className={styles.adminMain}>
      <h1 className={styles.pageTitle}>{t('agentManagement.title')}</h1>
      <div className={styles.content}>
        <Box className={styles.tabsContainer}>
          <Tabs
            tabIndex={tabIndex}
            onChange={handleChange}
            className={styles.tabs}
          >
            <Tab
              label={`${t('agentManagement.tab.normal')} ${displayedTotal(tabIndex === 0)}`}
              className={styles.tab}
            />
            <Tab
              label={`${t('agentManagement.tab.flow')} ${displayedTotal(tabIndex === 1)}`}
              className={styles.tab}
            />
          </Tabs>
        </Box>

        <Box>
          <CustomTabPanel
            value={tabIndex}
            index={0}
            sx={{ padding: 0, paddingTop: '32px' }}
          >
            <AgentManagementTab
              type={EAgentManagementTabMode.NORMAL}
              getData={useAdminAgentManagement}
              paginationSettingAtom={listAdminAgentPaginationAtom}
            />
          </CustomTabPanel>

          <CustomTabPanel
            value={tabIndex}
            index={1}
            sx={{ padding: 0, paddingTop: '32px' }}
          >
            <AgentManagementTab
              type={EAgentManagementTabMode.FLOW}
              getData={useAdminAgentManagement}
              paginationSettingAtom={listAdminAgentPaginationAtom}
            />
          </CustomTabPanel>
        </Box>
      </div>
    </Box>
  );
};

export { AgentManagement };
