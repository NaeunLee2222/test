import { CircularProgress, Divider, Grid } from '@mui/material';
import cn from 'classnames';
import { useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import {
  separateNumberWithCommas,
  transformStringWithCommasToNumber,
} from '../../../../utils/commonUtil';
import { BaseButton } from '../../../core/components/common/BaseButton';
import { getUsageSettings, putUsageSettings } from '../../api/expense';
import styles from '../../styles/AdminMain.module.scss';
import CustomInput from '../Form/Inputs/CustomInput';
import { CompanyFilter } from './CompanyFilter';

export const ExpenseControl = () => {
  const { t } = useTranslation('admin');
  const { t: tTax } = useTranslation('tax');
  const methods = useForm();

  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [selectedCompany, setSelectedCompany] = useState('');

  const fetchData = async () => {
    if (!selectedCompany) return;
    try {
      const res = await getUsageSettings(selectedCompany);

      methods.setValue(
        'global_monthly_limit',
        separateNumberWithCommas(res.global_monthly_limit)
      );
      methods.setValue(
        'input_text_length',
        separateNumberWithCommas(res.input_text_length)
      );
      methods.setValue(
        'user_monthly_limit',
        separateNumberWithCommas(res.user_monthly_limit)
      );
      methods.setValue(
        'document_page_length',
        separateNumberWithCommas(res.document_page_length)
      );
    } catch (error) {
      console.error(error);
    }
  };

  const { formState } = methods;
  const isFormValid = useMemo(
    () => formState.isValid && formState.isDirty,
    [formState]
  );

  const submit = async () => {
    if (!isFormValid) return;
    setIsLoading(true);
    try {
      const finalData = Object.keys(methods.getValues()).reduce((acc, key) => {
        const typedKey = key as keyof typeof methods.getValues;
        acc[typedKey] = transformStringWithCommasToNumber(
          methods.getValues()[typedKey]
        );
        return acc;
      }, {} as any);

      await putUsageSettings(finalData, selectedCompany);
      setIsEditing(false);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = async () => {
    await fetchData();
    setIsEditing(false);
  };

  useEffect(() => {
    fetchData();
  }, [selectedCompany]);

  return (
    <div className={styles.adminMain}>
      <h1 className={styles.pageTitle}>
        {tTax('menu.adminMenu.usageSettings')}
      </h1>
      <div className={styles.content} style={{ gap: '24px' }}>
        <CompanyFilter onCompanyChange={setSelectedCompany} />
        <div className={cn(styles.formLayout, styles.bordered)}>
          <div className={styles.header}>
            <span className={styles.title}>{selectedCompany}</span>
            {isEditing ? (
              <div className={styles.btnGroup}>
                <div className={styles.secondaryButton}>
                  <BaseButton
                    buttonType='outlined'
                    className={styles.button}
                    onClick={handleCancel}
                    disabled={isLoading}
                  >
                    {t('cancel')}
                  </BaseButton>
                </div>
                <div className={styles.primaryButton}>
                  <BaseButton
                    className={styles.button}
                    onClick={() => submit()}
                    disabled={
                      isLoading || !formState.isValid || !formState.isDirty
                    }
                  >
                    {isLoading ? (
                      <CircularProgress color='inherit' size={20} />
                    ) : (
                      t('save')
                    )}
                  </BaseButton>
                </div>
              </div>
            ) : (
              <div className={styles.btnGroup}>
                <div className={styles.secondaryButton}>
                  <BaseButton
                    buttonType='outlined'
                    className={styles.button}
                    onClick={() => setIsEditing(true)}
                  >
                    {t('edit')}
                  </BaseButton>
                </div>
              </div>
            )}
          </div>
          <Divider className={styles.formDivider} />
          <Grid container rowSpacing={2} columnSpacing={7}>
            <Grid size={{ xs: 6 }}>
              <CustomInput
                {...methods}
                name='user_monthly_limit'
                label={t('expenseManagement.userMonthlyLimit')}
                disabled={!isEditing}
                endIcon={
                  <div style={{ color: '#1A1A1A', fontWeight: 500 }}>
                    {t('won')}
                  </div>
                }
                rules={{
                  required: { value: true, message: t('errors.required') },
                  pattern: {
                    value: /^[0-9,]*$/,
                    message: t('errors.onlyNumbers'),
                  },
                }}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <CustomInput
                {...methods}
                name='global_monthly_limit'
                label={t('expenseManagement.allMonthlyLimit')}
                disabled={!isEditing}
                endIcon={
                  <div style={{ color: '#1A1A1A', fontWeight: 500 }}>
                    {t('won')}
                  </div>
                }
                rules={{
                  required: { value: true, message: t('errors.required') },
                  pattern: {
                    value: /^[0-9,]*$/,
                    message: t('errors.onlyNumbers'),
                  },
                }}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <CustomInput
                {...methods}
                name='input_text_length'
                label={t('expenseManagement.inputTextLength')}
                disabled={!isEditing}
                helperText={t('expenseManagement.inputTextLengthHelper')}
                rules={{
                  required: { value: true, message: t('errors.required') },
                  pattern: {
                    value: /^[0-9,]*$/,
                    message: t('errors.onlyNumbers'),
                  },
                  validate: (value: string) => {
                    const num = transformStringWithCommasToNumber(value);

                    if (num < 0 || num > 2000) {
                      return 'Value must be between 0 and 2000';
                    }
                    return undefined;
                  },
                }}
              />
            </Grid>
            <Grid size={{ xs: 6 }}>
              <CustomInput
                {...methods}
                name='document_page_length'
                label={t('expenseManagement.documentPageLength')}
                helperText={t('expenseManagement.documentPageLengthHelper')}
                disabled={!isEditing}
                rules={{
                  required: { value: true, message: t('errors.required') },
                  pattern: {
                    value: /^[0-9,]*$/,
                    message: t('errors.onlyNumbers'),
                  },
                  validate: (value: string) => {
                    const num = transformStringWithCommasToNumber(value);
                    if (num < 0 || num > 1000) {
                      return 'Value must be between 0 and 1000';
                    }
                    return undefined;
                  },
                }}
              />
            </Grid>
          </Grid>
        </div>
      </div>
    </div>
  );
};
