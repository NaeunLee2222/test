import { useTranslation } from 'react-i18next';
import ReactECharts from 'echarts-for-react';
import styles from '../../styles/AdminMain.module.scss';

interface IProps {
  askCountData?: any;
  timeData?: any;
}

export const Chart = ({ askCountData = [], timeData = [] }: IProps) => {
  const { t } = useTranslation('admin');
  const options = {
    grid: { top: 50, right: 35, bottom: 24, left: 35 },
    xAxis: {
      type: 'category',
      name: `(${t('case')})`,
      nameTextStyle: {
        color: '#1a1a1a',
      },
      data: timeData,
      boundaryGap: false,
      axisLabel: {
        color: '#1a1a1a',
      },
    },
    yAxis: {
      type: 'value',
      axisLabel: {
        fontSize: 12,
        color: '#1a1a1a',
      },
      name: t('numberOfQuestions(number)'),
      nameTextStyle: {
        color: '#1a1a1a',
      },
      splitLine: {
        lineStyle: {
          type: 'dashed',
          width: 1,
          color: '#DADADA',
        },
      },
    },
    series: [
      {
        data: askCountData,
        type: 'line',
        color: '#5C7CFA',
        symbol: 'circle',
        symbolSize: 8,
      },
    ],
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#fff',
      textStyle: {
        color: '#1A1A1A',
        fontWeight: 400,
        fontSize: '13px',
      },
      borderWidth: 1,
      borderColor: '#ccc',
      padding: [5, 10],
    },
  };

  return (
    <div
      className={styles.chart}
      style={{
        margin: '0 0 24px',
      }}
    >
      <div className={styles.headerTitle}>
        {t('numberOfQuestionsByViewingPeriod')}
      </div>
      <ReactECharts option={options} />
    </div>
  );
};
