import { convertCost } from '@/utils';
import { Atom, PrimitiveAtom, useAtom } from 'jotai';
import { AtomWithQueryResult } from 'jotai-tanstack-query';
import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { fieldSettingAtom } from '../../hooks/useExpenseSettings';
import styles from '../../styles/AdminMain.module.scss';
import { BaseTable } from '../Table/BaseTable';
import { InformationWrap } from './InformationWrap';

interface IProps {
  getData: Atom<AtomWithQueryResult<any, Error>>;
  getInformation: Atom<AtomWithQueryResult<any, Error>>;
  paginationSettingAtom: PrimitiveAtom<any>;
  infoTitle?: string;
}

export const ExpenseTable = ({
  getData,
  getInformation,
  paginationSettingAtom,
  infoTitle,
}: IProps) => {
  const { t } = useTranslation('admin');
  const [{ data: informationData }] = useAtom(getInformation);

  const columns = useMemo(
    () => [
      { name: 'user_id', label: t('userName'), width: '33%' },
      {
        name: 'ask_count',
        label: t('numberOfQuestions(number)'),
        width: '33%',
        sortable: true,
      },
      {
        name: 'cost',
        label: t('usageFee(KRW)'),
        width: '33%',
        format: (value: string) => (value ? convertCost(value) : ''),
        sortable: true,
      },
    ],
    [t]
  );

  return (
    <div className={styles.expenseWrap}>
      <InformationWrap data={informationData} infoTitle={infoTitle} />
      <BaseTable
        setOpenDialog={() => {}}
        columns={columns}
        paginationSettingAtom={paginationSettingAtom}
        fieldSettingAtom={fieldSettingAtom}
        getData={getData}
        showTotalRecords={false}
      />
    </div>
  );
};
