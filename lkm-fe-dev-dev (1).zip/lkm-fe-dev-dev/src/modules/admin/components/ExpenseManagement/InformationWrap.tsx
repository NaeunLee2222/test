import { useTranslation } from 'react-i18next';
import { convertCost } from '../../../../utils';
import styles from '../../styles/AdminMain.module.scss';

interface InformationWrapProps {
  daily_average_ask_count: number;
  daily_average_cost: number;
  daily_average_user_count: number;
  total_ask_count: number;
  total_cost: number;
}

export const InformationWrap = ({
  data = {
    daily_average_ask_count: 0,
    daily_average_cost: 0,
    daily_average_user_count: 0,
    total_ask_count: 0,
    total_cost: 0,
  },
  infoTitle,
}: {
  data: InformationWrapProps;
  infoTitle?: string;
}) => {
  const { t } = useTranslation('admin');
  const {
    daily_average_ask_count,
    daily_average_cost,
    daily_average_user_count,
    total_ask_count,
    total_cost,
  } = data;

  return (
    <div className={styles.InformationWrap}>
      <div className={styles.headerTitle}>
        {infoTitle}
        <div className={styles.vl} />
        <div className={styles.hintText}>{t('upcomingBills')}</div>
      </div>
      <div className={styles.items}>
        <div className={styles.item}>
          <span className={styles.subItemTop}>
            <span className={styles.tl}>{t('userName')}</span>
            <span className={styles.tr}>{t('dailyAverage')}</span>
          </span>
          <span className={styles.subItemBottom}>
            <span className={styles.nl}>{daily_average_user_count}</span>
          </span>
        </div>
        <div className={styles.item}>
          <span className={styles.subItemTop}>
            <span className={styles.tl}>{t('numberOfQuestions')}</span>
            <span className={styles.tr}>
              {`${t('dailyAverage/Total')} (${t('case')})`}
            </span>
          </span>
          <span className={styles.subItemBottom}>
            <span className={styles.nl}>{daily_average_ask_count}</span>
            <span className={styles.slash}>/</span>
            <span className={styles.nr}>{total_ask_count}</span>
          </span>
        </div>
        <div className={styles.item}>
          <span className={styles.subItemTop}>
            <span className={styles.tl}>{t('usageFee')}</span>
            <span
              className={styles.tr}
            >{`${t('dailyAverage/Total')} (${t('won')})`}</span>
          </span>
          <span className={styles.subItemBottom}>
            <span className={styles.nl}>{convertCost(daily_average_cost)}</span>
            <span className={styles.slash}>/</span>
            <span className={styles.nr}>{convertCost(total_cost)}</span>
          </span>
        </div>
      </div>
    </div>
  );
};
