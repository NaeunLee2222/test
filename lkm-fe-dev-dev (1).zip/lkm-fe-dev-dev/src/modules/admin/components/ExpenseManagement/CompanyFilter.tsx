import { useAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import { useState, useMemo, useEffect } from 'react';
import { useUserMe, useCompanyList } from '@/modules/core/hooks';
import styles from '../../styles/AdminMain.module.scss';
import SearchSelect from '../Search/Select';

interface CompanyFilterProps {
  onCompanyChange: (company: string) => void;
}

export const CompanyFilter = ({ onCompanyChange }: CompanyFilterProps) => {
  const [{ data: userData }] = useAtom(useUserMe);
  const { t } = useTranslation('admin');

  const [company, setCompany] = useState('');
  const [{ data: companyList }] = useAtom(useCompanyList);

  const companyOptions = useMemo(
    () =>
      companyList?.map((c) => ({
        value: c.name,
        label: c.name,
      })) || [],
    [companyList]
  );

  const handleSelectCompany = (value: string) => {
    setCompany(value);
    onCompanyChange(value);
  };

  useEffect(() => {
    if (companyList) {
      const defaultCompany = companyList?.find(
        (c) => c.name === userData?.company
      );
      setCompany(defaultCompany?.name || '');
      onCompanyChange(defaultCompany?.name || '');
    }
  }, [companyList, onCompanyChange, userData?.company]);

  return (
    <div className={styles.companyFilter}>
      <div className={styles.selectField}>
        <div className={styles.label}>{`${t('company')}:`}</div>
        <SearchSelect
          options={companyOptions}
          // defaultValue={company}
          value={company}
          handleChange={handleSelectCompany}
        />
      </div>
    </div>
  );
};
