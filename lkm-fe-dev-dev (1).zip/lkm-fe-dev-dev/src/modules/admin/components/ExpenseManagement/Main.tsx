import { Box, Tab, Tabs } from '@mui/material';
import cn from 'classnames';
import { useSetAtom } from 'jotai';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { resetPaginationSettingAtom } from '../../hooks/useExpenseSettings';
import styles from '../../styles/AdminMain.module.scss';
import { CustomTabPanel, tabProps } from '../TabProps';
import { AdviceExpense } from './AdviceExpense';

export const ExpenseMain = () => {
  const { t } = useTranslation('admin');
  const { t: tTax } = useTranslation('tax');
  const [value, setValue] = useState(0);
  const callResetPagination = useSetAtom(resetPaginationSettingAtom);

  const handleChange = (_event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
    const isPro = newValue === 0;
    callResetPagination(isPro);
  };

  return (
    <div className={cn(styles.adminMain, styles.isTabs)}>
      <h1 className={styles.pageTitleWithSmallPaddingBottom}>
        {tTax('menu.adminMenu.checkCostStatus')}
      </h1>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ margin: '0 24px' }}>
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label='basic tabs example'
            sx={{
              '.MuiTab-root': {
                fontSize: '16px',
                color: 'var(--gray-900)',
              },
              '.Mui-selected': {
                color: 'var(--primary-color-600)',
              },
            }}
          >
            <Tab label={t('professionalAdvice')} {...tabProps(0)} />
            <Tab label={t('generalAdvice')} {...tabProps(1)} />
          </Tabs>
        </Box>
        <div className={`${styles.content} ${styles.expenseMain}`}>
          <CustomTabPanel value={value} index={0}>
            <AdviceExpense />
          </CustomTabPanel>
          <CustomTabPanel value={value} index={1}>
            <AdviceExpense />
          </CustomTabPanel>
        </div>
      </Box>
    </div>
  );
};
