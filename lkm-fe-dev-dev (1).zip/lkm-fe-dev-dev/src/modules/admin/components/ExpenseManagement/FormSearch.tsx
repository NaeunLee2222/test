import { RangeDatePicker } from '@/modules/core/components/common/DatePicker/RangeDatePicker';
import { useCompanyList, useUserMe } from '@/modules/core/hooks';
import { getKstTimestampBySelectedDate } from '@/utils';
import dayjs from 'dayjs';
import localeData from 'dayjs/plugin/localeData';
import weekday from 'dayjs/plugin/weekday';
import { PrimitiveAtom, useAtom } from 'jotai';
import _ from 'lodash';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import styles from '../../styles/AdminMain.module.scss';
import SearchSelect from '../Search/Select';

dayjs.extend(weekday);
dayjs.extend(localeData);

interface IProps {
  paginationSettingAtom: PrimitiveAtom<any>;
}

export const FormSearch = ({ paginationSettingAtom }: IProps) => {
  const [{ data: userData }] = useAtom(useUserMe);
  const isSuperAdmin = userData?.role?.includes('superadmin');

  const { t } = useTranslation('admin');
  const [searchParams] = useSearchParams();
  const now = dayjs();
  const last7Days = dayjs().subtract(6, 'day');
  const [selectedDate, setSelectedDate] = useState([last7Days, now]);
  const [, setPage] = useAtom(paginationSettingAtom);
  const [company, setCompany] = useState('');

  const [{ data: companyList }] = useAtom(useCompanyList);
  const companyOptions = useMemo(
    () =>
      companyList?.map((c) => ({
        value: c.name,
        label: c.name,
      })) || [],
    [companyList]
  );

  const handleSearch = ({
    currentDateValue,
  }: {
    currentDateValue: dayjs.Dayjs[];
  }) => {
    let params = '';
    const dateStr = getKstTimestampBySelectedDate(currentDateValue);
    if (dateStr) {
      params = `${params}&${dateStr}`;
    }
    setPage((prev: object) => ({
      ...prev,
      page: 0,
      rowsPerPage: 10,
      search: params,
    }));
  };

  const handleChangeDate = (date: any) => {
    if (date && _.size(date) > 1) {
      const startDate = date[0] || '';
      const endDate = date[1] || '';
      setSelectedDate([dayjs(startDate), dayjs(endDate)]);
      handleSearch({
        currentDateValue: [dayjs(startDate), dayjs(endDate)],
      });
    }
  };

  const handleSelectCompany = (value: string) => {
    setCompany(value);
    setPage((prev: object) => ({ ...prev, page: 0, company: value }));
  };

  useEffect(() => {
    const startDateParam = searchParams.get('startDate');
    const endDateParam = searchParams.get('endDate');
    const formattedDate = [dayjs(startDateParam), dayjs(endDateParam)];
    const isValidDate = formattedDate.every((date) => date.isValid());

    const dateToUse =
      isValidDate && startDateParam && endDateParam
        ? formattedDate
        : selectedDate;

    if (isValidDate && startDateParam && endDateParam) {
      setSelectedDate(formattedDate);
    }

    handleSearch({ currentDateValue: dateToUse });
  }, [searchParams, company]);

  useEffect(() => {
    if (companyList) {
      const defaultCompany = companyList?.find(
        (c) => c.name === userData?.company
      );
      setCompany(defaultCompany?.name || '');
      setPage((prev: object) => ({
        ...prev,
        page: 0,
        company: defaultCompany?.name || '',
      }));
    }
  }, [companyList, setPage]);

  return (
    <div
      className={styles.formSearch}
      style={{
        margin: '0 0 24px',
      }}
    >
      <div className={styles.inputDate}>
        <div className={styles.label}>{`${t('date')}:`}</div>
        <RangeDatePicker
          className={styles.dateRangePicker}
          onConfirm={(date: any) => handleChangeDate(date)}
          defaultValue={selectedDate}
        />
      </div>
      {isSuperAdmin && (
        <div className={styles.selectField} style={{ maxWidth: '240px' }}>
          <div className={styles.label}>{`${t('company')}:`}</div>
          <SearchSelect
            options={companyOptions}
            value={company}
            handleChange={handleSelectCompany}
          />
        </div>
      )}
    </div>
  );
};
