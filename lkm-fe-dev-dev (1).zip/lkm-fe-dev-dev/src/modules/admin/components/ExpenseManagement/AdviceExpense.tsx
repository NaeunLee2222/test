import { useAtom, useAtomValue } from 'jotai';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';
import {
  getData,
  getInformation,
  getTotalAskCount,
  paginationSettingAtom,
} from '../../hooks/useExpenseSettings';
import { Chart } from './Chart';
import { FormSearch } from './FormSearch';
import { ExpenseTable } from './Table';

export const AdviceExpense = () => {
  const { t } = useTranslation('admin');
  const [{ data: totalAsk }] = useAtom(getTotalAskCount);
  const timeData: string[] = [];
  const askCountData: number[] = [];
  if (totalAsk && 'data_list' in totalAsk && _.size(totalAsk.data_list) > 0) {
    totalAsk.data_list.map(({ time, total_ask_count }) => {
      timeData.push(time);
      if (typeof total_ask_count === 'number') {
        askCountData.push(total_ask_count);
      }
    });
  }

  const { isPro } = useAtomValue(paginationSettingAtom);

  return (
    <div>
      <FormSearch paginationSettingAtom={paginationSettingAtom} />
      <>
        {!_.isEmpty(askCountData) && !_.isEmpty(timeData) && (
          <Chart askCountData={askCountData} timeData={timeData} />
        )}
        <ExpenseTable
          getData={getData}
          getInformation={getInformation}
          paginationSettingAtom={paginationSettingAtom}
          infoTitle={isPro ? t('professionalAdvice') : t('generalAdvice')}
        />
      </>
    </div>
  );
};
