import IconRegenerate from '@/assets/basic-icons/icon-regenerate-16.svg?react';
import { TooltipCustom } from '@/modules/admin/components/TooltipCustom';
import { getStatusText } from '@/utils';
import styles from './FormatDocumentStatus.module.scss';

export const FormatDocumentStatus = (props: {
  value: any;
  action: any;
  t: any;
}) => {
  const { value, action, t } = props;
  const result = getStatusText(value, t);
  const isFailure = value === 'FAILED';
  return (
    <div>
      {isFailure ? (
        <div className={styles.failWrap}>
          <span>{result}</span>
          <TooltipCustom title={t('recollect')} placement='top'>
            <span
              role='presentation'
              className={styles.reloadWrap}
              onClick={action}
            >
              <IconRegenerate fill='var(--gray-700)' />
            </span>
          </TooltipCustom>
        </div>
      ) : (
        result
      )}
    </div>
  );
};
