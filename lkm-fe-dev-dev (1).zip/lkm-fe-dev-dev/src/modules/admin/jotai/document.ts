import { atom } from 'jotai';

export const refetchDocumentsAtom = atom<number | false>(false);
