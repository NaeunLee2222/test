import {
  AgentFilterParams,
  AgentHistoryFilterParams,
  DeployedAgentFilterParams,
} from '@/modules/admin/types/agent';
import { AgentType, UsageScope } from '@/modules/agent/type/agent';
import {
  DEFAULT_HISTORY_LIMIT,
  DEFAULT_LIMIT,
  DEFAULT_PAGE,
} from '@/types/common';
import { atom } from 'jotai';
import type { IUserEmailQuery } from '../types/user';

// ==============================
// Default Filter Values
// ==============================
export const defaultAgentFilterValue: AgentFilterParams = {
  page: DEFAULT_PAGE,
  rowsPerPage: DEFAULT_LIMIT,
  date_type: undefined,
  end_date: undefined,
  review_status: undefined,
  sortDetail: undefined,
  start_date: undefined,
  search: undefined,
  agent_type: AgentType.GENERAL,
};

export const defaultDeployedAgentFilterValue: DeployedAgentFilterParams = {
  page: DEFAULT_PAGE,
  rowsPerPage: DEFAULT_LIMIT,
  start_date: undefined,
  end_date: undefined,
  sortDetail: undefined,
  search: undefined,
  agent_type: undefined,
  is_activated: undefined,
  usage_scope: UsageScope.ORG,
};

// ==============================
// Pagination Atoms
// ==============================
export const listAdminAgentPaginationAtom = atom<AgentFilterParams>({
  ...defaultAgentFilterValue,
});

export const listDeployedAgentPaginationAtom = atom<DeployedAgentFilterParams>({
  ...defaultDeployedAgentFilterValue,
});

export const listAgentHistoryAtom = atom<AgentHistoryFilterParams>({
  agent_id: '',
  page: DEFAULT_PAGE,
  rowsPerPage: DEFAULT_HISTORY_LIMIT,
});

// ==============================
// UI/UX Control Atoms
// ==============================
export const selectedUsageScopeAtom = atom<UsageScope>(UsageScope.ORG);
export const rejectDescriptionAtom = atom<string | undefined>(undefined);
export const skipGetGeneralAgentAtom = atom(false);

// ==============================
// Query Atom
// ==============================
export const userEmailQueryAtom = atom<IUserEmailQuery>({});
