import { atom } from 'jotai';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import * as actions from '../api/question';
import { IQuestion } from '../types/question';

export const listPaginationAtom = atom({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
  company: '',
});

export const useQuestionSettings = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy, company } =
    get(listPaginationAtom);
  return {
    queryKey: [
      'admin',
      'question',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
      company || '',
    ],
    queryFn: async () =>
      company
        ? actions.getList(page, rowsPerPage, search, sortBy, company)
        : null,
    select: (data: any) =>
      data
        ? {
            data_list: data?.data_list || [],
            next_offset: data?.next_offset,
            total_count: data?.total_count,
          }
        : null,
  };
});

export const questionSettingAtom = atom<IQuestion>({
  id: undefined,
  question: '',
  user_name: '',
  category: '',
  is_pro: false,
  is_visible: true,
  date: '',
});

export const useQuestionMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'question'],
  mutationFn: async (data: any) => {
    const questionSettingData = get(questionSettingAtom);
    const { company } = get(listPaginationAtom);

    try {
      const response = questionSettingData.id
        ? await actions.update(questionSettingData, company)
        : await actions.create(questionSettingData, company);
      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'question'] });
  },
}));

export const useDeleteMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'question', 'delete'],
  mutationFn: async ({ id, callback }: any) => {
    const { company } = get(listPaginationAtom);
    try {
      const response = await actions.deleteRow(id, company);
      callback(true, response);
    } catch (error) {
      callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'question'] });
  },
}));

export const getLaw = atomWithQuery(() => ({
  queryKey: ['admin', 'question'],
  queryFn: async () => actions.getLaw(),
  isLoading: true,
}));
