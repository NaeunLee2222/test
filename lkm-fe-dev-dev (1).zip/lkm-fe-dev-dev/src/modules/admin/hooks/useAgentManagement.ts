import {
  createAgentHistory,
  getAdminAgents,
  getAdminDeployedAgents,
  getAgentHistory,
  patchAgentStatus,
} from '@/modules/admin/api/agent';
import {
  listAdminAgentPaginationAtom,
  listAgentHistoryAtom,
  listDeployedAgentPaginationAtom,
} from '@/modules/admin/jotai/agent';
import {
  IAdminAgentResponse,
  IAgentHistoryResponse,
} from '@/modules/admin/types/agent';
import { AgentType, UsageScope } from '@/modules/agent/type/agent';
import { AGENT_KEY } from '@/modules/chat/hooks/useAgents';
import { DEFAULT_HISTORY_LIMIT, DEFAULT_PAGE } from '@/types/common';
import { atomWithMutation, atomWithQuery } from 'jotai-tanstack-query';

export const useAdminAgentManagement = atomWithQuery((get) => {
  const {
    page,
    rowsPerPage,
    agent_type,
    date_type,
    start_date,
    end_date,
    review_status,
    search,
    sortDetail,
  } = get(listAdminAgentPaginationAtom);

  return {
    queryKey: [
      ...AGENT_KEY,
      page || 0,
      rowsPerPage || 10,
      agent_type,
      date_type,
      start_date,
      end_date,
      review_status,
      search,
      sortDetail,
    ],
    queryFn: async () => {
      const skip = page * rowsPerPage || 0;
      const limit = rowsPerPage || 10;
      const response = await getAdminAgents({
        skip,
        limit,
        agent_type,
        date_type,
        start_date,
        end_date,
        review_status,
        search,
        order_by: sortDetail?.sort,
        order_direction: sortDetail?.order,
      });

      let agentType: string | undefined;
      switch (agent_type) {
        case AgentType.GENERAL:
          agentType = AgentType.PRO;
          break;
        case AgentType.PRO:
          agentType = AgentType.GENERAL;
          break;
        default:
          agentType = undefined;
          break;
      }

      const alterResponse = await getAdminAgents({
        skip,
        limit,
        agent_type: agentType,
        date_type,
        start_date,
        end_date,
        review_status,
        search,
        order_by: sortDetail?.sort,
        order_direction: sortDetail?.order,
      });

      return {
        ...response,
        alter_total: alterResponse.total ?? alterResponse?.data?.total,
      };
    },
    select: (data: IAdminAgentResponse | null) => {
      if (!data) return null;
      const {
        submitted_count,
        deployed_count,
        rejected_count,
        agents,
        total,
        alter_total,
      } = data?.data || data;
      return {
        total_count: total,
        alter_total,
        total_submit: submitted_count,
        total_approval: deployed_count,
        total_rejection: rejected_count,
        data_list: [...agents],
      };
    },
  };
});

export const useDeployedAgentManagement = atomWithQuery((get) => {
  const {
    page,
    rowsPerPage,
    start_date,
    end_date,
    sortDetail,
    search,
    agent_type,
    usage_scope,
  } = get(listDeployedAgentPaginationAtom);

  return {
    queryKey: [
      ...AGENT_KEY,
      'deployed',
      page,
      rowsPerPage,
      start_date,
      end_date,
      sortDetail,
      search,
      agent_type,
      usage_scope,
    ],
    queryFn: async () => {
      const skip = page * rowsPerPage || 0;
      const limit = rowsPerPage || 10;
      const response = await getAdminDeployedAgents({
        skip,
        limit,
        agent_type,
        usage_scope,
        start_date,
        end_date,
        search,
        order_by: sortDetail?.sort,
        order_direction: sortDetail?.order,
      });

      let usageScope: string | undefined;
      switch (usage_scope) {
        case UsageScope.ORG:
          usageScope = UsageScope.PUBLIC;
          break;
        case UsageScope.PUBLIC:
          usageScope = UsageScope.ORG;
          break;
        default:
          usageScope = undefined;
          break;
      }

      const alterResponse = await getAdminDeployedAgents({
        skip,
        limit,
        agent_type,
        usage_scope: usageScope,
        start_date,
        end_date,
        search,
        order_by: sortDetail?.sort,
        order_direction: sortDetail?.order,
      });

      return {
        ...response,
        alter_total: alterResponse.total ?? alterResponse?.data?.total,
      };

      // return response
    },
    select: (data: IAdminAgentResponse | null) => {
      if (!data) return null;
      const {
        submitted_count,
        deployed_count,
        rejected_count,
        agents,
        total,
        alter_total,
      } = data?.data || data;
      return {
        total_count: total,
        alter_total,
        total_submit: submitted_count,
        total_approval: deployed_count,
        total_rejection: rejected_count,
        data_list: [...agents],
      };
    },
  };
});

export const usePatchAgentActivation = atomWithMutation(() => ({
  mutationKey: ['admin', 'agent', 'is_activated'],
  mutationFn: async (data: any) => {
    try {
      const response = await patchAgentStatus(data.agent_id, data.is_activated);
      data.callback(response);
    } catch (error) {
      data.callback(false, error);
    }
  },
}));

export const useCreateAgentHistory = atomWithMutation(() => ({
  mutationKey: ['admin', 'agent', 'is_activated'],
  mutationFn: async (data: any) => {
    try {
      const response = await createAgentHistory(
        data.agent_id,
        data.modified_user_id,
        data.description
      );
      data.callback(response);
    } catch (error) {
      data.callback(false, error);
    }
  },
}));

export const useGetAgentHistory = atomWithQuery((get) => {
  const { agent_id, page, rowsPerPage } = get(listAgentHistoryAtom);

  return {
    queryKey: [
      ...AGENT_KEY,
      page || DEFAULT_PAGE,
      rowsPerPage || DEFAULT_HISTORY_LIMIT,
    ],
    queryFn: async () => {
      const skip = page * rowsPerPage || 0;
      const limit = rowsPerPage || 10;
      const response = await getAgentHistory(agent_id.toString(), skip, limit);

      return response;
    },
    select: (data: IAgentHistoryResponse | null) => {
      if (!data) return null;
      const { agent_history, limit, message, skip, success } =
        data?.data || data;
      return {
        data_list: agent_history,
        limit,
        message,
        skip,
        success,
        total_count: agent_history.length,
      };
    },
  };
});
