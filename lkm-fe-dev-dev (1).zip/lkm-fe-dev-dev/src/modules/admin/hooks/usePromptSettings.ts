import { atom } from 'jotai';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import * as actions from '../api/prompt';
import { IPrompt } from '../types/prompt';

export const listPaginationAtom = atom({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
});

export const usePromptSettings = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy } = get(listPaginationAtom);
  return {
    queryKey: [
      'admin',
      'prompt',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
    ],
    queryFn: async () =>
      search ? actions.getList(page, rowsPerPage, search, sortBy) : null,
    select: (data: any) =>
      data
        ? {
            data_list: data?.prompt_list || [],
            next_offset: data?.next_offset,
            total_count: data?.total_count,
          }
        : null,
  };
});

export const promptSettingAtom = atom<IPrompt>({
  id: undefined,
  key: '',
  value: '',
  description: '',
  creator_id: '',
  create_dt: '',
});

export const usePromptMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'prompt'],
  mutationFn: async (data: any) => {
    const promptSettingData = get(promptSettingAtom);

    try {
      const response = await actions.create(promptSettingData);
      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'prompt'] });
  },
}));

export const useDeleteMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'prompt', 'delete'],
  mutationFn: async ({ id, callback }: any) => {
    try {
      const response = await actions.deleteRow(id);
      callback(true, response);
    } catch (error) {
      callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'prompt'] });
  },
}));
