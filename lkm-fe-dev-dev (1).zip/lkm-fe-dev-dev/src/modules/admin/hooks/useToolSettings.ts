import {
  createMcpTool,
  createToolGroup,
  deleteTool,
  getTools,
  patchTool,
  updateToolGroup,
  updateToolGroupRelationship,
} from '@/modules/admin/api/tool';
import {
  ITool,
  IToolDetailDto,
  IToolGroupDto,
  IToolGroupRelationshipDto,
  ToolQuery,
  type IMcpTool,
} from '@/modules/admin/types/tool';
import { IChatAgentToolResponse } from '@/modules/chat/types/agents';
import { PromiseStatus } from '@/types/common';
import { atom } from 'jotai';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import _ from 'lodash';

const DEFAULT_PAGE = 0;
const DEFAULT_PAGE_SIZE = 10;

export const toolListPaginationAtom = atom<ToolQuery>({
  toolGroupId: undefined,
  toolName: undefined,
  toolId: undefined,
  isVisible: undefined,
  page: 0,
  rowsPerPage: 10,
  sortDetail: {},
});

export const useToolSettings = atomWithQuery((get) => {
  const {
    toolGroupId,
    toolName,
    toolId,
    page,
    isVisible,
    rowsPerPage,
    sortDetail,
  } = get(toolListPaginationAtom);
  return {
    queryKey: [
      'admin',
      'tool',
      page,
      rowsPerPage,
      isVisible,
      sortDetail || {},
      toolGroupId,
      toolName,
      toolId,
    ],
    queryFn: async () => {
      const tools = await getTools(toolGroupId, toolName, toolId, isVisible);
      const pageIndex = page ?? DEFAULT_PAGE;
      const pageSize = rowsPerPage ?? DEFAULT_PAGE_SIZE;
      const start = pageIndex * pageSize;
      const end = (pageIndex + 1) * pageSize - 1;
      let toolList =
        tools?.data?.tools || tools?.tools || ([] as IChatAgentToolResponse[]);
      if (sortDetail) {
        const { order, sort } = sortDetail;
        toolList = _.orderBy([...toolList], [sort], [order]);
      }

      toolList = [...toolList].filter(
        (item, index) => index >= start && index <= end && !!item.id
      );

      const result = {
        tool_list: toolList,
        total_count: (tools?.data?.tools || tools?.tools || []).length,
        next_offset: Math.random(),
      };

      return result;
    },
    select: (data: any) => ({
      data_list: data?.tool_list ?? [],
      next_offset: data?.next_offset,
      total_count: data?.total_count,
    }),
    enabled: false,
  };
});

export const toolGroupSettingDataAtom = atom<IToolGroupDto>({
  id: undefined,
  name: '',
  description: '',
});

export const useToolGroupMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'tool_group', toolGroupSettingDataAtom],
  mutationFn: async (data: any) => {
    const toolGroupSettingData = get(toolGroupSettingDataAtom);

    try {
      const response = toolGroupSettingData.id
        ? await updateToolGroup(toolGroupSettingData)
        : await createToolGroup(toolGroupSettingData);
      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'tool'] });
  },
}));

export const toolSettingDataAtom = atom<ITool>({
  id: undefined,
  tool_id: '',
  tool_group_id: 0,
  tool_group_name: '',
  endpoint: undefined,
  name: '',
  description: '',
  type: '',
  is_visible: true,
  is_active: true,
});

export const useToolMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'tool'],
  mutationFn: async (data: any) => {
    const toolSettingData = get(toolSettingDataAtom);

    const payload: IMcpTool = {
      name: toolSettingData.name,
      description: toolSettingData.description,
      type: toolSettingData.type,
      icon_path: toolSettingData.icon_path,
      config: toolSettingData.config,
      endpoint: toolSettingData.endpoint,
      is_visible: toolSettingData.is_visible,
      tool_group_id: Number(toolSettingData.tool_group_id),
    };

    try {
      const response = await createMcpTool(payload);
      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'tool'] });
  },
}));

export const useUpdateToolMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'tool', 'update'],
  mutationFn: async (data: any) => {
    const toolSettingData = get(toolSettingDataAtom);

    try {
      const response = await patchTool({
        ...toolSettingData,
      } as IToolDetailDto);
      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'tool', 'update'] });
  },
}));

export const useUToolGroupRelationshipMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'tool_group_relationship', 'update'],
  mutationFn: async (data: any) => {
    const toolSettingData = get(toolSettingDataAtom);

    try {
      const response = await updateToolGroupRelationship({
        tool_group_id: toolSettingData.tool_group_id,
        tool_id: toolSettingData.id,
      } as IToolGroupRelationshipDto);

      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({
      queryKey: ['admin', 'tool_group_relationship', 'update'],
    });
  },
}));

export const useToolDeleteMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'tool', 'delete'],
  mutationFn: async (data: {
    selectedRows: number[];
    callback?: (success: boolean, messages: string[]) => void | Promise<void>;
  }) => {
    const promises = data.selectedRows.map((tool_id) => deleteTool(tool_id));
    const responses = await Promise.allSettled(promises);

    const success = responses.every(
      (response) =>
        response.status === PromiseStatus.FULFILLED &&
        (response.value.data?.success ?? response.value?.success)
    );

    if (data.callback) {
      data.callback(
        success,
        responses.map(
          (response) =>
            (response.status === PromiseStatus.FULFILLED &&
              (response.value?.data?.message ?? response.value?.message)) ||
            (response.status === PromiseStatus.REJECTED &&
              response.reason.message)
        )
      );
    }

    return responses;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'tool', 'delete'] });
  },
}));
