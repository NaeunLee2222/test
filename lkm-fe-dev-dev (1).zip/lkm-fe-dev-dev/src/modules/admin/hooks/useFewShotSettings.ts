import dayjs from 'dayjs';
import { atom } from 'jotai';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import * as actions from '../api/fewShot';
import { IFewShot } from '../types/fewShot';

export const listPaginationAtom = atom({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
});
export const fewShotDetailCompanyAtom = atom<string>('');
export const fewShotDetailStatusAtom = atom<string>('');
export const fewShotDetailDateAtom = atom<[dayjs.Dayjs, dayjs.Dayjs]>([
  dayjs().subtract(6, 'day'),
  dayjs(),
]);
export const fewShotDetailSearchAtom = atom<string>('');

export const useFewShotSettings = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy } = get(listPaginationAtom);

  return {
    queryKey: [
      'admin',
      'fewShot',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
    ],
    queryFn: async () => actions.getList(page, rowsPerPage, search, sortBy),
    select: (data: any) => ({
      data_list: data?.fewshot_list ?? [],
      next_offset: data?.next_offset,
      total_count: data?.total_count,
    }),
    isLoading: true,
    isFetching: true,
  };
});

export const fewShotDetailIdAtom = atom<number | null>(null);

export const getDetailMutation = atomWithQuery((get) => ({
  queryKey: ['admin', 'fewShot', 'detail', get(fewShotDetailIdAtom)],
  queryFn: async () => {
    const id = get(fewShotDetailIdAtom);
    const company = get(fewShotDetailCompanyAtom);
    if (!id || id === -1) return null;
    return actions.getDetail(id, company);
  },
  select: (data: IFewShot | null) =>
    data || {
      id: undefined,
      input: '',
      output: '',
      law_info: '',
      law_class: '',
      company: '',
      node_key: '',
      flag: 0,
      feedback_id: null,
      status: '',
      update_dt: '',
      create_dt: '',
    },
}));

export const useFewShotMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'fewShot', 'detail'],
  mutationFn: async ({
    data,
    company = '',
  }: {
    data: IFewShot;
    company?: string;
  }) => {
    const response = data.id
      ? await actions.update(data, company)
      : await actions.create(data, company);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'fewShot'] });
  },
}));

export const useDeleteMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'fewShot', 'delete'],
  mutationFn: async ({ id, company }: any) => actions.deleteRow(id, company),
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'fewShot'] });
  },
}));
