import { atom } from 'jotai';
import { atomWithMutation, atomWithQuery } from 'jotai-tanstack-query';
import * as actions from '../api/feedback';
import { IFeedback } from '../types/feedback';
import { IPagination } from '../types/table';

export const paginationSettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
  company: '',
});

export const fieldSettingAtom = atom<IFeedback>({
  id: undefined,
  message_id: '',
  flag: '',
  comment: '',
  create_dt: '',
  user_name: '',
  question: '',
  answer: '',
  version: '',
  history_id: -1,
});

export const getData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy, company } = get(
    paginationSettingAtom
  );
  return {
    queryKey: ['admin', 'feedback', page, rowsPerPage, search, sortBy, company],
    queryFn: async () =>
      search && company
        ? actions.getData(page, rowsPerPage, search, sortBy, company)
        : null,
  };
});

export const downloadExcelMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'feedback', 'download'],
  mutationFn: () => {
    const { search, sortBy, company } = get(paginationSettingAtom);
    return actions.downloadExcel(search, sortBy, company);
  },
}));
