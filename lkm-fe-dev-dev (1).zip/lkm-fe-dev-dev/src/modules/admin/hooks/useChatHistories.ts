import { atom } from 'jotai';
import { atomWithMutation, atomWithQuery } from 'jotai-tanstack-query';
import * as actions from '../api/history';
import {
  IChatHistories,
  IChatHistoriesMutationFnProps,
} from '../types/chatHistories';
import { IPagination } from '../types/table';

export const paginationSettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 50,
  search: '',
  sortBy: '',
  company: '',
  historyType: '',
});

export const fieldSettingAtom = atom<IChatHistories>({
  id: undefined,
  create_dt: '',
  user_name: '',
  title: '',
  versions: [],
});

export const getData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy, company, historyType } = get(
    paginationSettingAtom
  );
  return {
    queryKey: [
      'admin',
      'chat-histories',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
      company || '',
      historyType || '',
    ],
    queryFn: async () =>
      search && company
        ? actions.getData(
            page,
            rowsPerPage,
            search,
            sortBy,
            company,
            historyType
          )
        : null,
    isLoading: true,
    isFetching: true,
  };
});

export const downloadExcelMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'chat-histories', 'download'],
  mutationFn: ({ selectedRows }: IChatHistoriesMutationFnProps) => {
    const { search, sortBy, company } = get(paginationSettingAtom);
    return actions.downloadExcel(search, sortBy, selectedRows, company);
  },
}));
