import {
  atomWithQuery,
  atomWithMutation,
  queryClientAtom,
} from 'jotai-tanstack-query';
import { atom } from 'jotai';
import { refetchDocumentsAtom } from '../jotai/document';
import * as actions from '../api/documentExternal';
import { IPagination } from '../types/table';

export interface Chip {
  [key: string]: any;
}

export const chip2: Chip = {
  '국세기본': '국기',
  '국세징수': '국징',
  '법인세': '법인',
  '종합소득세': '종소',
  '부가가치세': '부가',
  '양도소득세': '양도',
  '상속증여세': '상증',
  '조세특례': '조특',
  '국제조세': '국조',
  '종합부동산세': '종부',
  '원천세': '원천',
  '소비세': '소비',
  '주세': '주세',
  '기타': '기타',
  '교육세': '교육',
  '농어촌특별세': '농특',
  '교통세': '교통',
  '조세범처벌': '조범',
  '인지세': ' 인지',
  '증권거래세': '증권',
};

export const paginationSettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
});

export const fieldSettingAtom = atom({
  id: undefined,
  title: '',
  department: '',
  law_kind: '',
  promulgation_number: '',
  promulgation_date: '',
  effective_date: '',
  history: '',
  law_serial_number: '',
  valid_date: '',
  is_latest: '',
  original_url: '',
  pdf_url: '',
  pdf_file_path: '',
  json_file_path: '',
  status: '',
  update_dt: '',
});

export const getData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy } = get(paginationSettingAtom);
  return {
    queryKey: ['admin', 'document', page, rowsPerPage, search, sortBy],
    queryFn: async () =>
      search ? actions.getLawData(page, rowsPerPage, search, sortBy) : null,
    refetchInterval: get(refetchDocumentsAtom),
  };
});

export const paginationJudicialPrecedentSettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
});

export const fieldJudicialPrecedentSettingAtom = atom({
  id: undefined,
  title: '',
  law_class: '',
  type: '',
  decision_type: '',
  case_number: '',
  sentencing_date: '',
  registration_date: '',
  original_url: '',
  json_file_path: '',
  status: '',
  update_dt: '',
});

export const getJudicialPrecedentData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy } = get(
    paginationJudicialPrecedentSettingAtom
  );
  return {
    queryKey: [
      'admin',
      'document',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
    ],
    queryFn: async () =>
      search
        ? actions.getJudicialPrecedentsData(page, rowsPerPage, search, sortBy)
        : null,
    refetchInterval: get(refetchDocumentsAtom),
  };
});

export const paginationLegalInterpretationSettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
});

export const fieldLegalInterpretationSettingAtom = atom({
  id: undefined,
  title: '',
  law_class: '',
  type: '',
  case_number: '',
  sentencing_date: '',
  registration_date: '',
  original_url: '',
  json_file_path: '',
  status: '',
  update_dt: '',
});

export const getLegalInterpretationData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy } = get(
    paginationLegalInterpretationSettingAtom
  );
  return {
    queryKey: [
      'admin',
      'document',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
    ],
    queryFn: async () =>
      search
        ? actions.getLegalInterpretationData(page, rowsPerPage, search, sortBy)
        : null,
    refetchInterval: get(refetchDocumentsAtom),
  };
});

export const paginationTreatySettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
});

export const fieldTreatySettingAtom = atom({
  id: undefined,
  treaty_type: '',
  country: '',
  original_url: '',
  json_file_path: '',
  status: '',
  update_dt: '',
  create_dt: '',
});

export const getTreatyData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy } = get(
    paginationTreatySettingAtom
  );
  return {
    queryKey: [
      'admin',
      'document',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
    ],
    queryFn: async () =>
      actions.getTreatyData(page, rowsPerPage, search, sortBy),
    refetchInterval: get(refetchDocumentsAtom),
  };
});

export const mutationJudicialPrecedentData = atomWithMutation((get) => {
  const { page, rowsPerPage, search, sortBy } = get(
    paginationJudicialPrecedentSettingAtom
  );
  const queryClient = get(queryClientAtom);
  const queryKey = [
    'admin',
    'document',
    page,
    rowsPerPage,
    search || '',
    sortBy || '',
  ];

  return {
    mutationKey: ['admin', 'document', 'retry'],
    mutationFn: async (row) => {
      await actions.retryJudicialPrecedentData(row);
    },
    onMutate: async (_variable: any) => {
      const previousData = queryClient.getQueryData(queryKey);
      queryClient.setQueryData(queryKey, (data: any) => ({
        ...data,
        /** set status of exact value that retried */
        data_list: data?.data_list.map((val: any) => {
          if (val.id === _variable.id)
            return {
              ...val,
              status: 'RETRYING',
            };
          return val;
        }),
      }));
      /** by invalidate and not refetching, component can get fake status   */
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'none',
      });
      return { previousData, queryKey };
    },
    onSuccess: (_data, _variable: any) => {
      /** when success retrying, invalidate and refetch query */
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'all',
      });
    },
  };
});

export const mutationLawData = atomWithMutation((get) => {
  const { page, rowsPerPage, search, sortBy } = get(paginationSettingAtom);
  const queryClient = get(queryClientAtom);
  const queryKey = [
    'admin',
    'document',
    page,
    rowsPerPage,
    search || '',
    sortBy || '',
  ];

  return {
    mutationKey: ['admin', 'document', 'retry'],
    mutationFn: async (row) => {
      await actions.retryLawData(row);
    },
    onMutate: async (_variable: any) => {
      const previousData = queryClient.getQueryData(queryKey);
      queryClient.setQueryData(queryKey, (data: any) => ({
        ...data,
        data_list: data?.data_list.map((val: any) => {
          if (val.id === _variable.id)
            return {
              ...val,
              status: 'RETRYING',
            };
          return val;
        }),
      }));
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'none',
      });
      return { previousData, queryKey };
    },
    onSettled: (_data, _variable: any) => {
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'all',
      });
    },
  };
});

export const mutationLegalInterpretationData = atomWithMutation((get) => {
  const { page, rowsPerPage, search, sortBy } = get(
    paginationLegalInterpretationSettingAtom
  );
  const queryClient = get(queryClientAtom);
  const queryKey = [
    'admin',
    'document',
    page,
    rowsPerPage,
    search || '',
    sortBy || '',
  ];

  return {
    mutationKey: ['admin', 'document', 'retry'],
    mutationFn: async (row) => {
      await actions.retryLegalInterpretationData(row);
    },
    onMutate: async (_variable: any) => {
      const previousData = queryClient.getQueryData(queryKey);
      queryClient.setQueryData(queryKey, (data: any) => ({
        ...data,
        data_list: data?.data_list.map((val: any) => {
          if (val.id === _variable.id)
            return {
              ...val,
              status: 'RETRYING',
            };
          return val;
        }),
      }));
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'none',
      });
      return { previousData, queryKey };
    },
    onSuccess: (_data, _variable: any) => {
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'all',
      });
    },
  };
});

export const mutationTreatyData = atomWithMutation((get) => {
  const { page, rowsPerPage, search, sortBy } = get(
    paginationTreatySettingAtom
  );
  const queryClient = get(queryClientAtom);
  const queryKey = [
    'admin',
    'document',
    page,
    rowsPerPage,
    search || '',
    sortBy || '',
  ];

  return {
    mutationKey: ['admin', 'document', 'retry'],
    mutationFn: async (row) => {
      await actions.retryTreatyData(row);
    },
    onMutate: async (_variable: any) => {
      const previousData = queryClient.getQueryData(queryKey);
      queryClient.setQueryData(queryKey, (data: any) => ({
        ...data,
        data_list: data?.data_list.map((val: any) => {
          if (val.id === _variable.id)
            return {
              ...val,
              status: 'RETRYING',
            };
          return val;
        }),
      }));
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'none',
      });
      return { previousData, queryKey };
    },
    onSuccess: (_data, _variable: any) => {
      queryClient.invalidateQueries({
        queryKey,
        exact: false,
        refetchType: 'all',
      });
    },
  };
});
