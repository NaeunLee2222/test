import {
  createUser,
  deleteUser,
  getUserList,
  updateUser,
} from '@/modules/admin/api/user';
import { ESortName } from '@/modules/admin/types/table';
import { useOrganizationList } from '@/modules/core/hooks';
import { ERole } from '@/types/user';
import { atom } from 'jotai';
import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import { ISortDetail, IUser } from '../types/user';

export const userListPaginationAtom = atom({
  page: 0,
  rowsPerPage: 10,
  search: '',
  company: '',
  sortDetail: {} as ISortDetail,
  activated: '',
  searchString: '',
  permission: '',
  updated: 0,
});

export const useUsersSettings = atomWithQuery((get) => {
  const {
    page,
    rowsPerPage,
    searchString,
    company,
    permission,
    activated,
    sortDetail,
  } = get(userListPaginationAtom);
  const { data: companyList } = get(useOrganizationList);
  let sortKey = '';

  if (sortDetail.sort === ESortName.USERNAME) {
    sortKey = `name_${sortDetail.order}`;
  }

  if (sortDetail.sort === ESortName.COMPANY) {
    sortKey = `org_${sortDetail.order}`;
  }

  return {
    queryKey: [
      'admin',
      'user',
      page,
      rowsPerPage,
      searchString || '',
      company || '',
      permission,
      activated,
      sortKey,
    ],
    queryFn: async () =>
      getUserList({
        page,
        rowsPerPage,
        searchString,
        company,
        permission,
        activated,
        sortKey,
      }),
    select: (data: any) => {
      const defaultData =
        data?.data && Array.isArray(data?.data?.users)
          ? data.data.users
          : undefined;
      const result =
        defaultData ??
        (data?.users && Array.isArray(data?.users) ? data?.users : []);

      return {
        data_list: result.map((user: IUser) => {
          const currentCompany = companyList?.find(
            (item) => item.id === user.organization_id
          );

          return {
            ...user,
            company: {
              name: currentCompany?.name ?? '',
              id: currentCompany?.id ?? '',
            },
          };
        }),
        total_count: data?.data?.total ?? data?.total,
      };
    },
    enabled: false,
  };
});

export const userSettingAtom = atom<IUser>({
  id: undefined,
  username: '',
  company: {
    name: '',
    id: '',
  },
  email: '',
  password: '',
  role: ERole.USER,
  is_activated: true,
});

export const useUserMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'user'],
  mutationFn: async (data: any) => {
    const userSettingData = get(userSettingAtom);

    try {
      const response = userSettingData.id
        ? await updateUser(userSettingData)
        : await createUser(userSettingData);
      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'user'] });
  },
}));

export const useUserDeleteMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'user', 'delete'],
  mutationFn: async ({ userId }: any) => {
    const response = await deleteUser(userId);
    return response;
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'user'] });
  },
}));

export const handleDeleteMultiple = atomWithMutation((get) => ({
  mutationKey: ['admin', 'user', 'deleteMultiple'],
  mutationFn: async ({
    selectedRows,
    callback,
  }: {
    selectedRows: string[];
    callback: (isSuccess: boolean, response: unknown) => void;
  }) => {
    try {
      const response = await Promise.all(
        selectedRows.map((item) => deleteUser(item))
      );

      callback(true, response);
    } catch (error) {
      callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'user'] });
  },
}));
