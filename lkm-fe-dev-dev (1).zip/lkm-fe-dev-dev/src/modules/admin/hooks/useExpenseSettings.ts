import { atom } from 'jotai';
import { atomWithQuery } from 'jotai-tanstack-query';
import * as actions from '../api/expense';
import type { IExpense } from '../types/expense';
import { IPagination } from '../types/table';

const TYPE_COMMON_PREFIX = 'common';
const TYPE_PRO_PREFIX = 'pro';

export const paginationSettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
  isPro: true,
  company: '',
});

export const resetPaginationSettingAtom = atom(
  null,
  (get, set, isPro: boolean) => {
    set(paginationSettingAtom, {
      page: 0,
      rowsPerPage: 10,
      search: '',
      sortBy: '',
      isPro,
      company: '',
    });
  }
);

export const fieldSettingAtom = atom<IExpense>({
  id: undefined,
  type: '',
  user_id: '',
  ask_count: '',
  cost: '',
  create_dt: '',
});

export const getData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy, isPro, company } = get(
    paginationSettingAtom
  );
  return {
    queryKey: [
      'admin',
      'expense',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
      isPro,
      company || '',
    ],
    queryFn: async () =>
      search && company
        ? actions.getData(
            isPro ? TYPE_PRO_PREFIX : TYPE_COMMON_PREFIX,
            page,
            rowsPerPage,
            search,
            sortBy,
            company
          )
        : null,
    isLoading: true,
    isFetching: true,
  };
});

export const getInformation = atomWithQuery((get) => {
  const { search, isPro, company } = get(paginationSettingAtom);
  return {
    queryKey: ['admin', 'expense', search || '', isPro, company || ''],
    queryFn: async () =>
      search && company
        ? actions.getInformation(
            isPro ? TYPE_PRO_PREFIX : TYPE_COMMON_PREFIX,
            search,
            company
          )
        : null,
    isLoading: true,
    isFetching: true,
  };
});

export const getTotalAskCount = atomWithQuery((get) => {
  const { search, isPro, company } = get(paginationSettingAtom);
  return {
    queryKey: [
      'admin',
      'expense',
      'totalAsk',
      search || '',
      isPro,
      company || '',
    ],
    queryFn: async () =>
      search && company
        ? actions.getTotalAskCount(
            isPro ? TYPE_PRO_PREFIX : TYPE_COMMON_PREFIX,
            search,
            company
          )
        : null,
    isLoading: true,
    isFetching: true,
  };
});
