import {
  atomWithMutation,
  atomWithQuery,
  queryClientAtom,
} from 'jotai-tanstack-query';
import { atom } from 'jotai';
import { refetchDocumentsAtom } from '../jotai/document';
import * as actions from '../api/documentInternal';
import { IPagination } from '../types/table';

export const paginationSettingAtom = atom<IPagination>({
  page: 0,
  rowsPerPage: 10,
  search: '',
  sortBy: '',
  company: '',
});

export const fieldSettingAtom = atom({
  id: undefined,
  data_name: '',
  data_type: '',
  username: '',
  filename: '',
  file_path: '',
  status: '',
  update_dt: '',
  file: null,
});

export const getData = atomWithQuery((get) => {
  const { page, rowsPerPage, search, sortBy, company } = get(
    paginationSettingAtom
  );
  return {
    queryKey: [
      'admin',
      'document',
      page,
      rowsPerPage,
      search || '',
      sortBy || '',
      company || '',
    ],
    queryFn: async () =>
      company
        ? actions.getData(page, rowsPerPage, search, sortBy, company)
        : null,
    isLoading: true,
    refetchInterval: get(refetchDocumentsAtom),
  };
});

export const useSubmitMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'document'],
  mutationFn: async (data: any) => {
    try {
      // const response = await actions.create(data.formData);
      const response = {
        message: '',
      };
      data.callback(true, response);
    } catch (error) {
      data.callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'document'] });
  },
}));

export const useDeleteMutation = atomWithMutation((get) => ({
  mutationKey: ['admin', 'document', 'delete'],
  mutationFn: async ({ id, callback }: any) => {
    try {
      const response = await actions.deleteRow(id);
      callback(true, response);
    } catch (error) {
      callback(false, error);
    }
  },
  onSettled: () => {
    const queryClient = get(queryClientAtom);
    queryClient.invalidateQueries({ queryKey: ['admin', 'question'] });
  },
}));
