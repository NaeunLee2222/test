import { atom } from 'jotai';
import { atomWithQuery } from 'jotai-tanstack-query';
import {
  getDocumentChartData,
  getFeedbackInfoData,
  getGeneralInfoData,
  getReportChartData,
  getUsageChartData,
} from '../api/dashboard';
import { IParams } from '../types/dashboard';

export const paramsAtom = atom<IParams>({
  type: 'pro',
  startDate: '',
  endDate: '',
  company: '',
});

export const getUsageChart = atomWithQuery((get) => {
  const { type, startDate, endDate, company } = get(paramsAtom);
  return {
    queryKey: [
      'admin',
      'dashboard',
      'usage-chart',
      type,
      startDate,
      endDate,
      company,
    ],
    queryFn: async () =>
      company ? getUsageChartData(type, startDate, endDate, company) : null,
  };
});

export const getGeneralInfo = atomWithQuery((get) => {
  const { type, startDate, endDate, company } = get(paramsAtom);
  return {
    queryKey: [
      'admin',
      'dashboard',
      'general-info',
      type,
      startDate,
      endDate,
      company,
    ],
    queryFn: async () =>
      company ? getGeneralInfoData(type, startDate, endDate, company) : null,
  };
});

export const getDocumentChart = atomWithQuery((get) => {
  const { startDate, endDate, company } = get(paramsAtom);
  return {
    queryKey: [
      'admin',
      'dashboard',
      'document-chart',
      startDate,
      endDate,
      company,
    ],
    queryFn: async () =>
      company ? getDocumentChartData(startDate, endDate, company) : null,
  };
});

export const getFeedbackInfo = atomWithQuery((get) => {
  const { startDate, endDate, company } = get(paramsAtom);
  return {
    queryKey: [
      'admin',
      'dashboard',
      'feedback-info',
      startDate,
      endDate,
      company,
    ],
    queryFn: async () =>
      company ? getFeedbackInfoData(startDate, endDate, company) : null,
  };
});

export const getReportChart = atomWithQuery((get) => {
  const { startDate, endDate, company } = get(paramsAtom);
  return {
    queryKey: [
      'admin',
      'dashboard',
      'report-chart',
      startDate,
      endDate,
      company,
    ],
    queryFn: async () =>
      company ? getReportChartData(startDate, endDate, company) : null,
  };
});
