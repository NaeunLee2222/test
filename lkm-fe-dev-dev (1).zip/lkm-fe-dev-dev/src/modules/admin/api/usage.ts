import {
  ICreateUsage,
  IUpdateUsage,
  IUsageResponse,
} from '@/modules/agent/type/agent';
import { chatInstance } from '@/modules/core/libs';
import { getUserIdFromCookie } from '@/utils';

const URL_PREFIX = `/usage/usage`;

export const getUsage = async () => {
  const response: IUsageResponse = await chatInstance.get(
    `${URL_PREFIX}?user_id=${getUserIdFromCookie()}`
  );

  return response;
};

export const createUsage = async (usageProp: ICreateUsage) => {
  try {
    const response = await chatInstance.post(URL_PREFIX, usageProp);
    return response;
  } catch (error) {
    console.error('Error when creating usage:', error);
    throw error;
  }
};

export const updateUsage = async (usageProp: IUpdateUsage) => {
  try {
    const response = await chatInstance.put(
      `${URL_PREFIX}?user_id=${getUserIdFromCookie()}`,
      usageProp
    );
    return response;
  } catch (error) {
    console.error('Error when creating usage:', error);
    throw error;
  }
};
