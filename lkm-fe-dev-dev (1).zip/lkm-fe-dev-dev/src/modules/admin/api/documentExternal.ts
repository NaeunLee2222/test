import { axiosInstance } from '@/modules/core/libs';
import {
  IDocCollectJpResponse,
  IDocCollectLiResponse,
  IDocLawResponse,
  IDocTreatyResponse,
} from '../types/document';

const ADMIN_PREFIX = '/core';

export const getLawData = async (
  page: number,
  size: number,
  search: string,
  sortBy: string
) => {
  try {
    const offset = page ? page * size : 0;
    const response: IDocLawResponse = await axiosInstance.get(
      `${ADMIN_PREFIX}/collect/laws?offset=${offset}&size=${size}${search ? `${search}` : ''}${sortBy ? `&sortBy=${sortBy}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getJudicialPrecedentsData = async (
  page: number,
  size: number,
  search: string,
  sortBy: string
) => {
  try {
    const offset = page ? page * size : 0;
    const response: IDocCollectJpResponse = await axiosInstance.get(
      `${ADMIN_PREFIX}/collect/judicial-precedents?offset=${offset}&size=${size}${search ? `${search}` : ''}${sortBy ? `&sortBy=${sortBy}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getLegalInterpretationData = async (
  page: number,
  size: number,
  search: string,
  sortBy: string
) => {
  try {
    const offset = page ? page * size : 0;
    const response: IDocCollectLiResponse = await axiosInstance.get(
      `${ADMIN_PREFIX}/collect/legal-interpretations?offset=${offset}&size=${size}${search ? `${search}` : ''}${sortBy ? `&sortBy=${sortBy}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getTreatyData = async (
  page: number,
  size: number,
  search: string,
  sortBy: string
) => {
  try {
    const offset = page ? page * size : 0;
    const response: IDocTreatyResponse = await axiosInstance.get(
      `${ADMIN_PREFIX}/collect/treaties?offset=${offset}&size=${size}${search ? `${search}` : ''}${sortBy ? `&sortBy=${sortBy}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const retryJudicialPrecedentData = async (row: any) => {
  try {
    const params = {
      title: row?.title,
      sentencing_date: row?.sentencing_date
        ? row.sentencing_date.replaceAll('-', '')
        : '',
      target_date: row?.registration_date
        ? row.registration_date.replaceAll('-', '')
        : '',
      case_number: row?.case_number,
    };
    return await axiosInstance.put(
      `${ADMIN_PREFIX}/kube/recollect-operation/law?law_type=judicial_precedent`,
      params
    );
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const retryLawData = async (row: any) => {
  try {
    const params = {
      title: row?.title,
      promulgation_date: row?.promulgation_date || '',
      target_date: row?.effective_date || '',
      law_serial_number: row?.law_serial_number,
    };
    return await axiosInstance.put(
      `${ADMIN_PREFIX}/kube/recollect-operation/law?law_type=law`,
      params
    );
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const retryLegalInterpretationData = async (row: any) => {
  try {
    const params = {
      title: row?.title,
      sentencing_date: row?.sentencing_date
        ? row.sentencing_date.replaceAll('-', '')
        : '',
      target_date: row?.registration_date
        ? row.registration_date.replaceAll('-', '')
        : '',
      case_number: row?.case_number,
    };
    return await axiosInstance.put(
      `${ADMIN_PREFIX}/kube/recollect-operation/law?law_type=legal_interpretation`,
      params
    );
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const retryTreatyData = async (row: any) => {
  try {
    const { treaty_type, country } = row;
    return await axiosInstance.put(
      `${ADMIN_PREFIX}/kube/recollect-operation/treaty?treaty_type=${treaty_type}&country=${country}`
    );
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};
