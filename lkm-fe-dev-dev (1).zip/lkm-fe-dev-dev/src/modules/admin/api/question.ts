import { axiosInstance } from '@/modules/core/libs';
import { ILawResponse, IQuestion, IQuestionResponse } from '../types/question';

const ADMIN_PREFIX = '/core';
const URL_PREFIX = `${ADMIN_PREFIX}/example-question/admin`;

export const getLaw = async () => {
  try {
    const response: ILawResponse = await axiosInstance.get(`/core/law`);
    return response;
  } catch (error) {
    console.error('Error fetching law:', error);
    throw error;
  }
};

export const getList = async (
  page: number,
  size: number,
  search: string,
  sortBy: string,
  company: string = ''
) => {
  const offset = page ? page * size : 0;
  const searchParams = [];
  if (offset) searchParams.push(`offset=${offset}`);
  if (size) searchParams.push(`size=${size}`);
  if (search) searchParams.push(`search=${search}`);
  if (sortBy) searchParams.push(`sortBy=${sortBy}`);
  if (company) searchParams.push(`company=${company}`);
  const searchParamsString = searchParams.join('&');
  const response: IQuestionResponse = await axiosInstance.get(
    `${URL_PREFIX}?${searchParamsString ? `${searchParamsString}` : ''}`
  );
  return response;
};

export const create = async (user: IQuestion, company: string = '') => {
  try {
    const searchParams = [];
    if (company) searchParams.push(`company=${company}`);
    const searchParamsString = searchParams.join('&');
    const response: IQuestion = await axiosInstance.post(
      `${URL_PREFIX}?${searchParamsString ? `${searchParamsString}` : ''}`,
      user
    );
    return response;
  } catch (error) {
    console.error('Error create data:', error);
    throw error;
  }
};

export const update = async (user: IQuestion, company: string = '') => {
  try {
    const searchParams = [];
    if (company) searchParams.push(`company=${company}`);
    const searchParamsString = searchParams.join('&');
    const response: IQuestion = await axiosInstance.patch(
      `${URL_PREFIX}/${user.id}?${searchParamsString ? `${searchParamsString}` : ''}`,
      user
    );
    return response;
  } catch (error) {
    console.error('Error update data:', error);
    throw error;
  }
};

export const deleteRow = async (id: string, company: string = '') => {
  try {
    const searchParams = [];
    if (id) searchParams.push(`question_id=${id}`);
    if (company) searchParams.push(`company=${company}`);
    const searchParamsString = searchParams.join('&');
    const response: IQuestion = await axiosInstance.delete(
      `${URL_PREFIX}/${id}?${searchParamsString ? `${searchParamsString}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error delete data:', error);
    throw error;
  }
};
