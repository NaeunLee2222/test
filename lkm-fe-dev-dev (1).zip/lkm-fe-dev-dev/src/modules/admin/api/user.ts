import { chatInstance } from '@/modules/core/libs';
import { buildUrlParams } from '@/utils';
import { IOrganization, IUser, IUserResponse } from '../types/user';

const USER_PREFIX = '/user';
const URL_ORGANIZATION = '/organization/all';

export const getUserList = async ({
  page,
  rowsPerPage,
  searchString,
  company,
  permission,
  activated,
  sortKey,
}: {
  page: number;
  rowsPerPage: number;
  searchString: string;
  company: string;
  permission: string;
  activated: string;
  sortKey: string;
}) => {
  let params = `?skip=${page * rowsPerPage}&limit=${rowsPerPage}`;
  if (searchString) {
    params += `&search=${searchString}`;
  }
  if (permission) {
    params += `&role=${permission}`;
  }
  if (activated) {
    params += `&is_activated=${Boolean(Number(activated))}`;
  }

  if (company) {
    params += `&company=${company}`;
  }

  if (sortKey) {
    params += `&order=${sortKey}`;
  }

  const response: IUserResponse = await chatInstance.get(
    `${USER_PREFIX}/all${params}`
  );
  return response;
};

export const createUser = async (user: IUser) => {
  const response: IUser = await chatInstance.post(`${USER_PREFIX}`, user);
  return response;
};

export const updateUser = async (user: IUser) => {
  const response: IUser = await chatInstance.put(
    `${USER_PREFIX}/${user.id}`,
    user
  );
  return response;
};

export const deleteUser = async (id: string) => {
  const response: IUser = await chatInstance.delete(`${USER_PREFIX}/${id}`);
  return response;
};

export const fetchOrganization = async () => {
  try {
    const response: { data: IOrganization[] } =
      await chatInstance.get(URL_ORGANIZATION);
    const result = response.data ? response.data : response;
    return result ?? [];
  } catch (error) {
    console.error('Error fetching organization data:', error);
    throw error;
  }
};

export const getUserByIdEmail = async (id?: string, email?: string) => {
  try {
    const searchParams = buildUrlParams({ id, email });
    const response: { data: IUser } = await chatInstance.get(
      `${USER_PREFIX}/?${searchParams}`
    );
    return response.data ?? response;
  } catch (error) {
    console.error('Error fetching user data:', error);
    throw error;
  }
};
