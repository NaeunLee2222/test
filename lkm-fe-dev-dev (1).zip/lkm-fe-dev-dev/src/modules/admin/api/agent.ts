import { agentInstance } from '@/modules/core/libs';
import { buildUrlParams } from '@/utils';
import {
  IAdminAgentResponse,
  IAgentHistoryResponse,
} from '@/modules/admin/types/agent';
import { DEFAULT_HISTORY_LIMIT, DEFAULT_PAGE } from '@/types/common';

const ADMIN_AGENT_PREFIX = '/admin/agents';

const DEFAULT_SKIP = 0;
const DEFAULT_LIMIT = 10;

export const getAdminAgents = async ({
  skip = DEFAULT_SKIP,
  limit = DEFAULT_LIMIT,
  agent_type,
  date_type,
  start_date,
  end_date,
  review_status,
  search,
  order_by,
  order_direction,
}: {
  skip: number;
  limit: number;
  agent_type?: string;
  date_type?: string;
  start_date?: string;
  end_date?: string;
  review_status?: string;
  search?: string;
  order_by?: string;
  order_direction?: string;
}) => {
  try {
    const params = {
      skip,
      limit,
      agent_type,
      date_type,
      start_date,
      end_date,
      review_status,
      search,
      order_by,
      order_direction,
    };
    const searchParams = buildUrlParams(params);
    const response: IAdminAgentResponse = await agentInstance.get(
      `${ADMIN_AGENT_PREFIX}${searchParams && `?${searchParams}`}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getAdminDeployedAgents = async ({
  skip = DEFAULT_SKIP,
  limit = DEFAULT_LIMIT,
  agent_type,
  usage_scope,
  is_activated,
  start_date,
  end_date,
  search,
  order_by,
  order_direction,
}: {
  skip: number;
  limit: number;
  agent_type?: string;
  usage_scope?: string;
  is_activated?: string;
  start_date?: string;
  end_date?: string;
  search?: string;
  order_by?: string;
  order_direction?: string;
}) => {
  try {
    const params = {
      skip,
      limit,
      agent_type,
      usage_scope,
      is_activated,
      start_date,
      end_date,
      search,
      order_by,
      order_direction,
    };
    const searchParams = buildUrlParams(params);
    const response: IAdminAgentResponse = await agentInstance.get(
      `${ADMIN_AGENT_PREFIX}/deployed${searchParams && `?${searchParams}`}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const patchAgentStatus = async (
  agent_id: string,
  is_activated: boolean
) => {
  try {
    const response: IAdminAgentResponse = await agentInstance.patch(
      `${ADMIN_AGENT_PREFIX}/${agent_id}/activation`,
      {
        is_activated,
      }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const createAgentHistory = async (
  agent_id: string,
  modified_user_id: number,
  description: string
) => {
  try {
    const response: IAdminAgentResponse = await agentInstance.post(
      `${ADMIN_AGENT_PREFIX}/${agent_id}/history`,
      {
        modified_user_id,
        description,
      }
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getAgentHistory = async (
  agent_id: string,
  skip: number = DEFAULT_PAGE,
  limit: number = DEFAULT_HISTORY_LIMIT
) => {
  try {
    const response: IAgentHistoryResponse = await agentInstance.get(
      `${ADMIN_AGENT_PREFIX}/${agent_id}/history?skip=${skip}&limit=${limit}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};
