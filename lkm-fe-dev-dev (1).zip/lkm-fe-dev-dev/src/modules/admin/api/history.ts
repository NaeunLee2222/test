import { axiosInstance } from '@/modules/core/libs';
import { formatApi } from '@/utils';
import { IChatHistoriesResponse } from '../types/chatHistories';

const ADMIN_PREFIX = '/core';
const URL_PREFIX = `${ADMIN_PREFIX}/chat/histories`;

export const getData = async (
  page: number,
  size: number,
  search: string,
  sortBy: string,
  company: string = '',
  historyType: string = ''
) => {
  try {
    const offset = page ? page * size : 0;

    const response: IChatHistoriesResponse = await axiosInstance.get(
      `${URL_PREFIX}?offset=${offset}&size=${size}${search ? `${search}` : ''}${sortBy ? `&sortBy=${sortBy}` : ''}${company ? `&company=${company}` : ''}${historyType && historyType !== '' ? `&historyType=${historyType}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const downloadExcel = async (
  search: string,
  sortBy: string,
  selectedRows: number[],
  company: string = ''
) => {
  try {
    await axiosInstance.get(
      formatApi(
        `${URL_PREFIX}/export?${search ? `${search}` : ''}${sortBy ? `&sortBy=${sortBy}` : ''}${selectedRows.length > 0 ? `&selectedIds=${selectedRows.toString()}` : ''}${company ? `&company=${company}` : ''}`
      ),
      {
        responseType: 'blob',
        headers: {
          Accept:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        },
      }
    );
  } catch (error) {
    console.error('Error when download excel:', error);
    throw error;
  }
};
