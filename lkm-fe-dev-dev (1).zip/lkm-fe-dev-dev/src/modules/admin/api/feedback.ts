import { IFeedbackResponse } from '@/modules/agent/type/agent';
import { axiosInstance } from '@/modules/core/libs';

const ADMIN_PREFIX = '/core';
const URL_PREFIX = `${ADMIN_PREFIX}/chat/feedbacks`;

export const getData = async (
  page: number,
  size: number,
  search: string,
  sortBy: string,
  company: string = ''
) => {
  const offset = page ? page * size : 0;
  const searchParams = [];
  if (offset) searchParams.push(`offset=${offset}`);
  if (size) searchParams.push(`size=${size}`);
  if (search) searchParams.push(`search=${search}`);
  if (sortBy) searchParams.push(`sortBy=${sortBy}`);
  if (company) searchParams.push(`company=${company}`);
  const searchParamsString = searchParams.join('&');

  const response: IFeedbackResponse = await axiosInstance.get(
    `${URL_PREFIX}?${searchParamsString ? `${searchParamsString}` : ''}`
  );
  return response;
};

export const downloadExcel = async (
  search: string,
  sortBy: string,
  company: string = ''
) => {
  const searchParams = [];
  if (search) searchParams.push(`search=${search}`);
  if (sortBy) searchParams.push(`sortBy=${sortBy}`);
  if (company) searchParams.push(`company=${company}`);
  const searchParamsString = searchParams.join('&');
  try {
    const response = await axiosInstance.get(
      `${URL_PREFIX}/export?${searchParamsString ? `${searchParamsString}` : ''}`,
      {
        responseType: 'blob',
        headers: {
          Accept:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        },
      }
    );
    return response;
  } catch (error) {
    console.error('Error when download excel:', error);
    throw error;
  }
};
