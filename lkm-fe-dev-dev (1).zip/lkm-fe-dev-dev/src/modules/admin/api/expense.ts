import { axiosInstance } from '@/modules/core/libs';
import {
  IExpenseInformationResponse,
  IExpenseResponse,
  ITotalAskResponse,
  IUsageSettings,
} from '../types/expense';

const ADMIN_PREFIX = '/core';
const USAGE_PREFIX = `${ADMIN_PREFIX}/usages`;

export const getData = async (
  type: string,
  page: number,
  size: number,
  search: string,
  sortBy: string,
  company: string = ''
) => {
  try {
    const offset = page ? page * size : 0;
    const searchParams = [];
    if (type) searchParams.push(`type=${type}`);
    if (sortBy) searchParams.push(`sortBy=${sortBy}`);
    if (offset) searchParams.push(`offset=${offset}`);
    if (size) searchParams.push(`size=${size}`);
    if (search) searchParams.push(`search=${search}`);
    if (company) searchParams.push(`company=${company}`);
    const searchParamsString = searchParams.join('&');

    const response: IExpenseResponse = await axiosInstance.get(
      `${USAGE_PREFIX}${searchParamsString ? `?${searchParamsString}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getInformation = async (
  type: string,
  search: string,
  company: string = ''
) => {
  try {
    const searchParams = [];
    if (type) searchParams.push(`type=${type}`);
    if (search) searchParams.push(`search=${search}`);
    if (company) searchParams.push(`company=${company}`);
    const searchParamsString = searchParams.join('&');

    const response: IExpenseInformationResponse = await axiosInstance.get(
      `${USAGE_PREFIX}/general-information?${searchParamsString ? `${searchParamsString}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching information:', error);
    throw error;
  }
};

export const getUsageSettings = async (company: string = '') => {
  try {
    const response: IUsageSettings = await axiosInstance.get(
      `${USAGE_PREFIX}/settings${company ? `?company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching usage settings:', error);
    throw error;
  }
};

export const putUsageSettings = async (data: any, company: string = '') => {
  try {
    const response: IUsageSettings = await axiosInstance.put(
      `${USAGE_PREFIX}/settings${company ? `?company=${company}` : ''}`,
      data
    );
    return response;
  } catch (error) {
    console.error('Error updating usage settings:', error);
    throw error;
  }
};

export const getTotalAskCount = async (
  type: string,
  search: string,
  company: string = ''
) => {
  try {
    const response: ITotalAskResponse = await axiosInstance.get(
      `${USAGE_PREFIX}/chart?${search ? `${search}` : ''}&type=${type}${company ? `&company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching total ask count:', error);
    throw error;
  }
};
