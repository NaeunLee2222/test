import { axiosInstance } from '@/modules/core/libs';
import { IFewShot, IFewShotResponse } from '../types/fewShot';

const ADMIN_PREFIX = '/core';
const URL_PREFIX = `${ADMIN_PREFIX}/fewshot`;

export const getList = async (
  page: number,
  size: number,
  search: string,
  sortBy: string,
  company: string = ''
) => {
  const offset = page ? page * size : 0;
  const searchParams = [];
  if (offset) searchParams.push(`offset=${offset}`);
  if (size) searchParams.push(`limit=${size}`);
  if (search) searchParams.push(`search=${search}`);
  if (sortBy) {
    sortBy = sortBy.split('_')[2];
    searchParams.push(`sort_by=${sortBy}`);
  }
  if (company) searchParams.push(`company=${company}`);
  const searchParamsString = searchParams.join('&');
  const response: IFewShotResponse = await axiosInstance.get(
    `${URL_PREFIX}?${searchParamsString ? `${searchParamsString}` : ''}`
  );
  return response;
};

export const getDetail = async (id: string | number, company: string) => {
  const searchParams = [];
  if (id) searchParams.push(`fewshot_id=${id}`);
  if (company) searchParams.push(`company=${company}`);
  const searchParamsString = searchParams.join('&');
  const response: IFewShot = await axiosInstance.get(
    `${URL_PREFIX}/id?${searchParamsString ? `${searchParamsString}` : ''}`
  );
  return response;
};

export const create = async (data: IFewShot, company: string) => {
  try {
    const searchParams = [];
    if (company) searchParams.push(`company=${company.toLowerCase()}`);
    const searchParamsString = searchParams.join('&');
    const response: IFewShot = await axiosInstance.post(
      `/chat/fewshot/manual?${searchParamsString ? `${searchParamsString}` : ''}`,
      { fewshot_list: [data] }
    );
    return response;
  } catch (error) {
    console.error('Error create data:', error);
    throw error;
  }
};

export const update = async (data: IFewShot, company: string) => {
  try {
    const searchParams = [];
    if (company) searchParams.push(`company=${company.toLowerCase()}`);
    const searchParamsString = searchParams.join('&');
    const response: IFewShot = await axiosInstance.patch(
      `/chat/fewshot/manual?${searchParamsString ? `${searchParamsString}` : ''}`,
      { fewshot_list: [data] }
    );
    return response;
  } catch (error) {
    console.error('Error update data:', error);
    throw error;
  }
};

export const deleteRow = async (id: string, company: string) => {
  try {
    const searchParams = [];
    if (id) searchParams.push(`fewshot_id=${id}`);
    if (company) searchParams.push(`company=${company.toLowerCase()}`);
    const searchParamsString = searchParams.join('&');
    const response: IFewShot = await axiosInstance.delete(
      `/chat/fewshot/manual?${searchParamsString ? `${searchParamsString}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error delete data:', error);
    throw error;
  }
};
