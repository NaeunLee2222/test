import { axiosInstance } from '@/modules/core/libs';
import { IDocInternal, IDocInternalResponse } from '../types/document';

const ADMIN_PREFIX = '/admin';
const URL_PREFIX = `${ADMIN_PREFIX}/collect-documents`;

export const getData = async (
  page: number,
  size: number,
  search: string,
  sortBy: string,
  company: string = ''
) => {
  try {
    const offset = page ? page * size : 0;
    const response: IDocInternalResponse = await axiosInstance.get(
      `${URL_PREFIX}?offset=${offset}&size=${size}${search ? `${search}` : ''}${sortBy ? `&sortBy=${sortBy}` : ''}${company ? `&company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const deleteRow = async (id: string) => {
  try {
    const response: IDocInternal = await axiosInstance.delete(
      `${URL_PREFIX}/${id}`
    );
    return response;
  } catch (error) {
    console.error('Error delete data:', error);
    throw error;
  }
};
