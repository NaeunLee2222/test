import {
  IResponse,
  ITool,
  IToolDetailDto,
  IToolGroupDto,
  IToolGroupRelationshipDto,
  type IMcpTool,
} from '@/modules/admin/types/tool';
import {
  IGeneralToolResponse,
  IToolGroupResponse,
} from '@/modules/agent/type/agent';
import { agentInstance } from '@/modules/core/libs';
import { buildUrlParams } from '@/utils';

const URL_PREFIX = `/tools`;
const TOOL_GROUPS_POSTFIX = `/tool_group`;
const ADD_TOOL_GROUP = `${TOOL_GROUPS_POSTFIX}`;
const UPDATE_TOOL_GROUP = `/update${TOOL_GROUPS_POSTFIX}`;
const GROUPS_RELATIONSHIP_POSTFIX = `/tool_group_relationship`;

export const getTools = async (
  tool_group_id?: string,
  tool_name?: string,
  tool_id?: string,
  is_visible?: string
) => {
  const params = {
    tool_group_id,
    tool_name,
    tool_id,
    is_visible,
  };
  const searchParams = buildUrlParams(params);
  const response: IGeneralToolResponse = await agentInstance.get(
    `${URL_PREFIX}${searchParams && `?${searchParams}`}`
  );

  return response;
};

export const createToolGroup = async (
  toolGroup: IToolGroupDto
): Promise<IToolGroupResponse> => {
  try {
    const response: IToolGroupResponse = await agentInstance.post(
      ADD_TOOL_GROUP,
      toolGroup
    );
    return response;
  } catch (error) {
    console.error('Error when creating tool group:', error);
    throw error;
  }
};

export const updateToolGroup = async (
  toolGroup: IToolGroupDto
): Promise<IToolGroupResponse> => {
  try {
    const response: IToolGroupResponse = await agentInstance.put(
      UPDATE_TOOL_GROUP,
      toolGroup
    );
    return response;
  } catch (error) {
    console.error('Error when creating tool group:', error);
    throw error;
  }
};

export const createMcpTool = async (mcpTool: IMcpTool) => {
  try {
    const response: ITool = await agentInstance.post(`tool`, mcpTool);
    return response;
  } catch (error) {
    console.error('Error when creating MCP tool:', error);
    throw error;
  }
};

export const updateToolGroupRelationship = async (
  relationship: IToolGroupRelationshipDto
) => {
  try {
    const response = await agentInstance.put(
      `update${GROUPS_RELATIONSHIP_POSTFIX}`,
      relationship
    );
    return response;
  } catch (error) {
    console.error('Error when creating tool groups relationship:', error);
    throw error;
  }
};

export const patchTool = async (tool: IToolDetailDto) => {
  try {
    const response: ITool = await agentInstance.put(`tool/${tool.id}`, tool);
    return response;
  } catch (error) {
    console.error('Error when updating tool:', error);
    throw error;
  }
};

export const deleteTool = async (toolId: number) => {
  try {
    const response: IResponse = await agentInstance.delete(`tool/${toolId}`);
    return response;
  } catch (error) {
    console.error('Error when deleting tool:', error);
    throw error;
  }
};
