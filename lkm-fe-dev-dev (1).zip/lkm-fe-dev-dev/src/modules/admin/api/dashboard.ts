import { axiosInstance } from '@/modules/core/libs';
import {
  IDocumentChartResponse,
  IFeedbackInfoResponse,
  IGeneralInfoResponse,
  IReportChartResponse,
  IUsageChartResponse,
} from '../types/dashboard';

const ADMIN_PREFIX = '/core';
const URL_PREFIX = `${ADMIN_PREFIX}/dashboard`;

export const getUsageChartData = async (
  type: string,
  startDate: string,
  endDate: string,
  company: string = ''
) => {
  try {
    const response: IUsageChartResponse = await axiosInstance.get(
      `${URL_PREFIX}/chart-usage?startDate=${startDate}&endDate=${endDate}&type=${type}${company ? `&company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getGeneralInfoData = async (
  type: string,
  startDate: string,
  endDate: string,
  company: string = ''
) => {
  try {
    const response: IGeneralInfoResponse = await axiosInstance.get(
      `${URL_PREFIX}/general-information-usage?startDate=${startDate}&endDate=${endDate}&type=${type}${company ? `&company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getDocumentChartData = async (
  startDate: string,
  endDate: string,
  company: string = ''
) => {
  try {
    const response: IDocumentChartResponse = await axiosInstance.get(
      `${URL_PREFIX}/chart-document?startDate=${startDate}&endDate=${endDate}${company ? `&company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getFeedbackInfoData = async (
  startDate: string,
  endDate: string,
  company: string = ''
) => {
  try {
    const response: IFeedbackInfoResponse = await axiosInstance.get(
      `${URL_PREFIX}/feedback-information?startDate=${startDate}&endDate=${endDate}${company ? `&company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

export const getReportChartData = async (
  startDate: string,
  endDate: string,
  company: string = ''
) => {
  try {
    const response: IReportChartResponse = await axiosInstance.get(
      `${URL_PREFIX}/chart-report-card?startDate=${startDate}&endDate=${endDate}${company ? `&company=${company}` : ''}`
    );
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};
