export interface AgentFilterParams {
  page: number;
  rowsPerPage: number;
  agent_type?: string;
  date_type?: string;
  start_date?: string;
  end_date?: string;
  review_status?: string;
  search?: string;
  sortDetail?: {
    order: string;
    sort: string;
  };
}

export interface DeployedAgentFilterParams {
  page: number;
  rowsPerPage: number;
  agent_type?: string;
  usage_scope?: string;
  is_activated?: string;
  start_date?: string;
  end_date?: string;
  search?: string;
  sortDetail?: {
    order: string;
    sort: string;
  };
}

export interface AgentHistoryFilterParams {
  agent_id: string;
  page: number;
  rowsPerPage: number;
}

export interface IAdminAgentResponse {
  data: {
    success: boolean;
    message: string;
    agents: IAgentResponse[];
    total: number;
    submitted_count: number;
    deployed_count: number;
    rejected_count: number;
    skip: number;
    alter_total?: number;
    limit: number;
  };

  success: boolean;
  message: string;
  agents: IAgentResponse[];
  total: number;
  submitted_count: number;
  deployed_count: number;
  rejected_count: number;
  skip: number;
  limit: number;
  alter_total?: number;
}

export interface IAgentResponse {
  id: number;
  name: string;
  user_name: string;
  agent_type: string;
  review_status: string;
  usage_scope: string;
  is_activated?: boolean;
  admin_name?: string;
  registered_at?: string;
  reviewed_at?: string;
}
export interface IAgentHistoryResponse {
  data: {
    success: boolean;
    message: string;
    agent_history: IAgentHistory[];
    skip: number;
    limit: number;
  };
  success: boolean;
  message: string;
  agent_history: IAgentHistory[];
  skip: number;
  limit: number;
}

export interface IAgentHistory {
  created_at: string;
  description: string;
  expert_agent_id: number;
  modified_user_id: number;
  modified_user_name: string | null;
  updated_at: string | null;
}
