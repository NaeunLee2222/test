export interface IQuestion {
  id?: number;
  question: string;
  user_name: string;
  category: string;
  is_pro: boolean;
  is_visible: boolean;
  date: string;
}

export interface IQuestionResponse {
  data_list: IQuestion[];
  total_count: number;
  next_offset: number;
}

export interface ILawResponse {
  국세개별세법: [];
  국세공통: [];
  기타: [];
  지방세법: [];
}
