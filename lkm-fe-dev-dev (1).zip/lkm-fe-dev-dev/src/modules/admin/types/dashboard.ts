export interface IParams {
  type: string;
  startDate: string;
  endDate: string;
  company: string;
}

export interface IUsageChartData {
  time: string;
  total_ask_count: number;
  total_cost: number;
  total_user: number;
}

export interface IUsageChartResponse {
  data_list: IUsageChartData[];
  mode: string;
}

export interface IGeneralInfoResponse {
  daily_average_user_count: number;
  daily_average_ask_count: number;
  daily_average_cost: number;
  total_ask_count: number;
  total_cost: number;
}

export interface IDocumentChartResponse {
  total: number;
  collect_law: {
    total: number;
    succeeded: number;
    failed: number;
    in_progress: number;
  };
  collect_judicial_precedent: {
    total: number;
    succeeded: number;
    failed: number;
    in_progress: number;
  };
  collect_legal_interpretation: {
    total: number;
    succeeded: number;
    failed: number;
    in_progress: number;
  };
  other: {
    total: number;
    succeeded: number;
    failed: number;
    in_progress: number;
  };
}

export interface IFeedbackInfoResponse {
  total_like: number;
  like_percentage_change: number;
  total_dislike: number;
  dislike_percentage_change: number;
}

export interface IReportChartResponse {
  card_information: {
    total_created_card: number;
    created_card_percentage_change: number;
    total_export_card: number;
    export_card_percentage_change: number;
  };
  chart: {
    mode: string;
    data_list: {
      total_created_card: number;
      total_export_card: number;
      time: string;
    }[];
  };
}
