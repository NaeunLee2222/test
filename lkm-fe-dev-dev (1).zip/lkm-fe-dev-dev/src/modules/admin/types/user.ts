export interface IUser {
  id?: number;
  username: string;
  company: {
    id: string | number;
    name: string;
  };
  email: string;
  role: string;
  is_activated: boolean;
  password?: string;
  organization_id?: number | string;
  team_id?: number | string;
  created_at?: string;
  updated_at?: string | null;
}

export interface IUserResponse {
  users: IUser[];
  total_count: number;
  next_offset: number;
  total: number;
  skip: number;
  limit: number;
  order?: number | string | null;
}

export interface IDialog {
  open: boolean;
  type: 'edit' | 'add' | 'view';
}

export interface IOrganization {
  'id': number;
  'name': string;
  'description': string;
  'created_at': string;
  'updated_at'?: string;
}

export interface IUserEmailQuery {
  id?: string;
  email?: string;
}

export interface ISortDetail {
  sort: string;
  order: string;
}
