export interface IExpense {
  id?: number;
  type: string;
  user_id: string;
  ask_count: string;
  cost: string;
  create_dt: string;
}

export interface IExpenseResponse {
  data_list: IExpense[];
  total_count: number;
  next_offset: number;
}

export interface IExpenseInformationResponse {
  daily_average_ask_count: number;
  daily_average_cost: number;
  daily_average_user_count: number;
  total_ask_count: number;
  total_cost: number;
}

export interface IUsageSettings {
  global_monthly_limit: number | string;
  input_text_length: number | string;
  output_token_length: number | string;
  user_monthly_limit: number | string;
  document_page_length: number | string;
}

export interface IAsk {
  total_ask_count?: number;
  time: string;
}

export interface ITotalAskResponse {
  data_list: IAsk[];
  mode: string;
}
