export interface IDocLaw {
  id?: number | string;
  title: string;
  department: string;
  law_kind: string;
  promulgation_number: string;
  promulgation_date: number;
  effective_date: number;
  history: string;
  law_serial_number: number;
  valid_date: string;
  is_latest: number;
  original_url: string;
  pdf_url: string;
  pdf_file_path: string;
  json_file_path: string;
  status: string;
  update_dt: string;
}

export interface IDocLawResponse {
  data_list: IDocLaw[];
  total_count: number;
  next_offset: number;
}

export interface IDocCollectJp {
  id?: number | string;
  title: string;
  law_class: string;
  type: string;
  decision_type: string;
  case_number: number;
  sentencing_date: number;
  registration_date: string;
  original_url: string;
  json_file_path: number;
  status: string;
  update_dt: string;
}

export interface IDocCollectJpResponse {
  data_list: IDocCollectJp[];
  total_count: number;
  next_offset: number;
}

export interface IDocCollectLi {
  id?: number | string;
  title: string;
  law_class: string;
  type: string;
  case_number: number;
  sentencing_date: number;
  registration_date: string;
  original_url: string;
  json_file_path: number;
  status: string;
  update_dt: string;
}

export interface IDocCollectLiResponse {
  data_list: IDocCollectLi[];
  total_count: number;
  next_offset: number;
}

export interface IDocInternal {
  id?: number | string;
  data_name: string;
  data_type: string;
  username: string;
  filename: string;
  file_path: string;
  status: string;
  update_dt: string;
  file: any;
}

export interface IDocInternalResponse {
  data_list: IDocInternal[];
  total_count: number;
  next_offset: number;
}

export interface IDocTreaty {
  id?: number | string;
  treaty_type: string;
  country: string;
  original_url: string;
  json_file_path: string;
  status: string;
  update_dt: string;
  create_dt: string;
}

export interface IDocTreatyResponse {
  data_list: IDocTreaty[];
  total_count: number;
  next_offset: number;
}
