export interface IPrompt {
  id?: number;
  key: string;
  value: string;
  description: string;
  creator_id: string;
  create_dt: string;
}

export interface IPromptResponse {
  data_list: IPrompt[];
  total_count: number;
  next_offset: number;
}
