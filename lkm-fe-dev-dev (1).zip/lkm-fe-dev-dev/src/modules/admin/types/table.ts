export interface IPagination {
  page: number;
  rowsPerPage: number;
  search: string;
  sortBy: string;
  sortDetail?: object;
  isPro?: boolean;
  company?: string;
  historyType?: string;
}

export enum ESortName {
  USERNAME = 'username',
  COMPANY = 'company',
}
