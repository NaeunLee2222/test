export interface IChatHistories {
  id?: string;
  create_dt: string;
  user_name: string;
  title: string;
  versions: any[];
}

export interface IChatHistoriesResponse {
  data_list: IChatHistories[];
  total_count: number;
  next_offset: number;
}

export interface IChatHistoriesMutationFnProps {
  selectedRows: number[];
  unSelectedRows: number[];
}
