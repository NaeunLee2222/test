export interface IFewShot {
  id?: number;
  input: string;
  output: string;
  law_info: string;
  law_class: string;
  node_key: string;
  company: string;
  flag?: number;
  feedback_id?: number | null;
  status?: string;
  update_dt?: string;
  create_dt?: string;
}

export interface IFewShotResponse {
  data_list: IFewShot[];
  total_count: number;
  next_offset: number;
}
