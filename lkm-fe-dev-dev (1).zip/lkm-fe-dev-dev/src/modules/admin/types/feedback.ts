export interface IFeedback {
  id?: number;
  message_id: string;
  flag: string;
  comment: string;
  create_dt: string;
  user_name: string;
  question: string;
  answer: string;
  version: string;
  history_id: number;
}
