export interface IToolGroupDto {
  'id'?: number;
  'name': string;
  'description': string;
  'is_visible'?: boolean;
}

export interface IResponse {
  data: {
    success: boolean;
    message: string;
  };

  success: boolean;
  message: string;
}

export interface ITool {
  id?: number;
  tool_id: string | number;
  tool_group_id: number;
  tool_group_name: string;
  endpoint?: string;
  source_code?: string;
  name: string;
  description: string;
  type: string;
  icon_path?: string;
  config?: any;
  is_visible: boolean;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface IToolDetailDto {
  id?: number;
  name: string;
  type: string;
  icon_path?: string;
  config?: any;
  endpoint?: string;
  description: string;
  is_visible: boolean;
}

export interface IMcpTool {
  name: string;
  description: string;
  type: string;
  icon_path?: string;
  config: any;
  endpoint?: string;
  is_visible: boolean;
  tool_group_id: number;
}

export interface IToolGroupRelationshipDto {
  tool_group_id: number;
  tool_id: number;
}

export enum ToolType {
  MCP = 'MCP',
  Source = 'source',
}

export interface ToolQuery {
  toolGroupId?: string;
  isVisible?: string;
  toolName?: string;
  toolId?: string;
  page?: number;
  rowsPerPage?: number;
  sortDetail?: any;
}

export interface ToolSelectData {
  id?: string | number;
  name?: string;
  description?: string;
}
