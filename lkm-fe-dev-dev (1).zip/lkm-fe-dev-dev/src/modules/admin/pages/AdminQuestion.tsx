import { QuestionMain } from '../components/QuestionManagement/Main';

const AdminQuestion = () => <QuestionMain />;

export { AdminQuestion };
