import { HistoryMain } from '../components/HistoryManagement/Main';

const AdminHistory = () => <HistoryMain />;

export { AdminHistory };
