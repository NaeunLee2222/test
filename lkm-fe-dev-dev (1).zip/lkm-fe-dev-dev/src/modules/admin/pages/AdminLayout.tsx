import {
  initLayoutDataAtom,
  layoutDataAtom,
} from '@/modules/core/jotai/layout';
import { useAtom } from 'jotai';
import { useEffect } from 'react';
import { Outlet } from 'react-router-dom';

const adminMenuImportFn = () =>
  import('@/modules/admin/components/Menu/AdminMenu').then((module) => ({
    default: module.AdminMenu,
  }));

const AdminLayout = () => {
  const [layoutData] = useAtom(layoutDataAtom);
  const [, initLayoutData] = useAtom(initLayoutDataAtom);

  useEffect(() => {
    if (layoutData.lnbCustomMenuKey === 'admin') return;
    initLayoutData({
      lnbCustomMenuKey: 'admin',
      lnbCustomMenu: adminMenuImportFn,
    });
  }, [layoutData]);

  return <Outlet />;
};

export { AdminLayout };
