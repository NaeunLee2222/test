import { ExpenseMain } from '../components/ExpenseManagement/Main';

const AdminExpense = () => <ExpenseMain />;

export { AdminExpense };
