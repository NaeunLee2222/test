import { PromptMain } from '../components/PromptManagement/Main';

const AdminPrompt = () => <PromptMain />;

export { AdminPrompt };
