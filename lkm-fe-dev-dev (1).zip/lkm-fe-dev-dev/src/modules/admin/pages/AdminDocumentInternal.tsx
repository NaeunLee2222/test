import { Main } from '../components/DocumentManagement/Internal/Main';

const AdminDocumentInternal = () => <Main />;

export { AdminDocumentInternal };
