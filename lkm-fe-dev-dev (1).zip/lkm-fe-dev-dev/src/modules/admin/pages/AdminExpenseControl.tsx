import { ExpenseControl } from '../components/ExpenseManagement/ExpenseControl';

const AdminExpenseControl = () => <ExpenseControl />;

export { AdminExpenseControl };
