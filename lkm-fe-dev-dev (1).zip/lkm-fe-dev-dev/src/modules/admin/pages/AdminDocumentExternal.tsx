import { External } from '../components/DocumentManagement/External';

const AdminDocumentExternal = () => <External />;

export { AdminDocumentExternal };
