import { OperationManagement } from '../components/OperationManagement/OperationManagement';

const AdminOperationManagement = () => <OperationManagement />;

export { AdminOperationManagement };
