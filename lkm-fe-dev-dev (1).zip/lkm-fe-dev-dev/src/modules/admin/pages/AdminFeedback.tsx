import { FeedbackMain } from '../components/FeedbackManagement/Main';

const AdminFeedback = () => <FeedbackMain />;

export { AdminFeedback };
