import { UserMain } from '../components/UserManagement/UserMain';

const AdminUser = () => <UserMain />;

export { AdminUser };
