import { UsageMain } from '../components/UsageManagement/UsageMain';

const AdminUsage = () => <UsageMain />;

export { AdminUsage };
