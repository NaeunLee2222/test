import ToolMain from '@/modules/admin/components/ToolManagement/Main';

const AdminToolManagement = () => <ToolMain />;

export { AdminToolManagement };
