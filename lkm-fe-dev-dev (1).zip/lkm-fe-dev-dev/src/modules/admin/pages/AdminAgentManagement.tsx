import { AgentManagement } from '../components/AgentManagement/AgentManagement';

const AdminAgentManagement = () => <AgentManagement />;

export { AdminAgentManagement };
