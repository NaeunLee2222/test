import { FewShotMain } from '../components/FewShotManagement/Main';

const AdminFewShot = () => <FewShotMain />;

export { AdminFewShot };
