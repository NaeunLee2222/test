import { DashboardMain } from '../components/DashboardManagement/Main';

const AdminDashboard = () => <DashboardMain />;

export { AdminDashboard };
