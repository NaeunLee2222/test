## 📝 Pull Request

### Title

### Description

- Please summarize the contents of the included commits and related issue numbers.

---

### ✅ Checklist

You do not need to write this. Just double-check it once more before request.

- [ ] All included commits follow the commit message rules
- [ ] Rebased to the latest base branch
- [ ] No conflicts with the base branch
- [ ] Functionality tested locally
- [ ] No unnecessary files included (patch/temp/logs)

---

### 💡 Special Notes

- Including `ESC_BUILD` in commit messages will skip build and deployment automatically
