const https = require('https');

class SimpleMCPClient {
  constructor(url) {
    this.url = url;
    this.sessionId = null;
  }

  async initialize() {
    const data = JSON.stringify({
      jsonrpc: '2.0',
      method: 'initialize',
      params: {
        protocolVersion: '2025-06-18',
        capabilities: {
          tools: {},
          resources: {}
        },
        clientInfo: {
          name: 'simple-mcp-client',
          version: '1.0.0'
        }
      },
      id: 1
    });

    return this.makeRequest(data);
  }

  async listTools() {
    const data = JSON.stringify({
      jsonrpc: '2.0',
      method: 'tools/list',
      params: {
        sessionId: this.sessionId
      },
      id: 2
    });

    return this.makeRequest(data);
  }

  async listResources() {
    const data = JSON.stringify({
      jsonrpc: '2.0',
      method: 'resources/list',
      params: {
        sessionId: this.sessionId
      },
      id: 3
    });

    return this.makeRequest(data);
  }

  makeRequest(data) {
    return new Promise((resolve, reject) => {
      const url = new URL(this.url);
      
      const options = {
        hostname: url.hostname,
        port: url.port || 443,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json, text/event-stream',
          'Content-Length': Buffer.byteLength(data)
        },
        timeout: 30000
      };

      const req = https.request(options, (res) => {
        let responseData = '';
        
        res.on('data', (chunk) => {
          responseData += chunk;
        });
        
        res.on('end', () => {
          try {
            // SSE 응답 처리
            if (responseData.startsWith('event: message')) {
              const lines = responseData.split('\n');
              for (const line of lines) {
                if (line.startsWith('data: ')) {
                  const jsonData = line.substring(6);
                  const parsed = JSON.parse(jsonData);
                  resolve(parsed);
                  return;
                }
              }
            } else {
              const parsed = JSON.parse(responseData);
              resolve(parsed);
            }
          } catch (error) {
            reject(new Error(`Failed to parse response: ${error.message}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(error);
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.write(data);
      req.end();
    });
  }
}

// 테스트 실행
async function testMCPConnection() {
  const client = new SimpleMCPClient('https://lkm-dev.skax.co.kr/mcp/html/mcp/');
  
  try {
    console.log('Initializing MCP connection...');
    const initResult = await client.initialize();
    console.log('Initialize result:', initResult);
    
    // 세션 ID 저장
    if (initResult.result && initResult.result.sessionId) {
      client.sessionId = initResult.result.sessionId;
      console.log('Session ID:', client.sessionId);
    }
    
    console.log('\nListing tools...');
    const toolsResult = await client.listTools();
    console.log('Tools result:', toolsResult);
    
    console.log('\nListing resources...');
    const resourcesResult = await client.listResources();
    console.log('Resources result:', resourcesResult);
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

testMCPConnection(); 