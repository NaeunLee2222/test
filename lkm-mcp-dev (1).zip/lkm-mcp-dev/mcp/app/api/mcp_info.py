from starlette.routing import Mount


def get_mounted_routes_info(app):
    """
    마운트된 모든 MCP 라우터 정보를 반환합니다.
    """
    mounted_routes = []
    for route in app.routes:
        if isinstance(route, Mount):
            route_info = {
                "name": route.path.strip("/"),
                "path": route.path + "/mcp",
            }
            mounted_routes.append(route_info)
    return mounted_routes
