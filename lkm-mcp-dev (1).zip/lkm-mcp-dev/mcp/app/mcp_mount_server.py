from contextlib import AsyncExitStack, asynccontextmanager
import os
import json
from fastapi import FastAPI
from fastmcp import FastMCP
from fastmcp.server.proxy import ProxyClient
from starlette.routing import Mount, BaseRoute
from typing import List, cast

# --- 기존 MCP 앱들 임포트 ---
from mcpserver.planning import planning_app
from mcpserver.document import document_app
from mcpserver.database import database_app
from mcpserver.html import html_app
from mcpserver.comparator import comparator_app
from mcpserver.websearch2report import websearch2report_app
from mcpserver.emergency import emergency_app
from mcpserver.emergency_mail import emergency_mail_app
from mcpserver.emergency_slack import emergency_slack_app
from mcpserver.searchfile import searchfile_app
from mcpserver.searchrdb import searchrdb_app
from mcpserver.report2ppt_sync import report2ppt_sync_app
from mcpserver.excel2html import excel2html_app
from mcpserver.tavilysearch import tavilysearch_app
from mcpserver.ocr import ocr_app
from mcpserver.bingsearch import bingsearch_app
from mcpserver.googlesearch import googlesearch_app
from api.mcp_info import get_mounted_routes_info
from mcpserver.mindmap import mindmap_app
from mcpserver.visualization import visualization_app
from mcpserver.apitest import apitest_app
from mcpserver.dbrouter import dbrouter_app
# from mcpserver.tbe_generator import tbe_app
from mcpserver.tbe_generator2 import tbe2_app
from mcpserver.analyticsplanner import analyticsplanner_app
from mcpserver.feature_importance import feature_importance_app
from mcpserver.data_processor import data_processor_app
from mcpserver.data2chart import data2chart_app
from mcpserver.generate_report import generate_report_app
from mcpserver.rfq_searchfile import rfq_searchfile_app
from mcpserver.temporary_tools import temporary_tools_app



mcp_prefix = "/mcp"


config = json.load(open(os.path.join(os.path.dirname(__file__), 'mcp_config.json')))  # noqa: F821

proxy_apps_list = []
for server_name, server_conf in config.get('mcpServers', {}).items():
    single_server_config = {server_name: server_conf}
    proxy = FastMCP.as_proxy(ProxyClient(single_server_config), name=f"{server_name}-Proxy")
    proxy_app = proxy.http_app()
    proxy_apps_list.append({'name': server_name, 'app': proxy_app})

@asynccontextmanager
async def combined_lifespan(app: FastAPI):
    """모든 MCP와 supergateway의 라이프사이클을 함께 관리"""
    async with AsyncExitStack() as stack:
        # 모든 MCP 앱들의 lifespan_context를 반복문으로 등록
        for app_name, mcp_app in mcp_apps.items():
            
            await stack.enter_async_context(mcp_app.router.lifespan_context(app))
            
        
        # Proxy 앱들의 lifespan_context 등록
        for proxy_info in proxy_apps_list:
            await stack.enter_async_context(proxy_info['app'].router.lifespan_context(app))
        
        yield


# --- 라우트 설정 ---
mcp_apps = {
    "document": document_app,
    "database": database_app,
    "html": html_app,
    "comparator": comparator_app,
    "websearch2report": websearch2report_app,
    "emergency": emergency_app,
    "emergency_mail": emergency_mail_app,
    "emergency_slack": emergency_slack_app,
    "searchfile": searchfile_app,
    "searchrdb": searchrdb_app,
    "report2ppt_sync": report2ppt_sync_app,
    "excel2html_cloud": excel2html_app,
    "tavilysearch": tavilysearch_app,
    "bingsearch": bingsearch_app,
    "googlesearch": googlesearch_app,
    "mindmap": mindmap_app,
    "ocr": ocr_app,
    "visualization": visualization_app,
    "apitest": apitest_app,
    "tbe2" : tbe2_app,
    "dbrouter" : dbrouter_app,
    "analyticsplanner" : analyticsplanner_app,
    "feature_importance": feature_importance_app,
    "data_processor": data_processor_app,
    "data2chart": data2chart_app,
    "generate_report": generate_report_app,
    "planning" : planning_app,
    "rfq_searchfile" : rfq_searchfile_app,
    "temporary_tools" : temporary_tools_app
}

routes: List[Mount] = [Mount(f"{mcp_prefix}/{path}", app=app) for path, app in mcp_apps.items()]


for proxy_info in proxy_apps_list:
    routes.append(Mount(f"{mcp_prefix}/{proxy_info['name']}", app=proxy_info['app']))


# 최종 앱 생성
app = FastAPI(
    routes=cast(List[BaseRoute], routes),
    lifespan=combined_lifespan,
)


@app.get("/mcp-routers")
async def get_mcp_routers():
    """마운트된 모든 MCP 라우터 정보를 반환합니다."""
    return get_mounted_routes_info(app)

@app.get("/health")
async def health_check():
    return {"status": "ok"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("mcp_mount_server:app", host="0.0.0.0", port=8050)
