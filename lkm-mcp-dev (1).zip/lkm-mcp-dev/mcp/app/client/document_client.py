
import os
import aiohttp
from uvicorn.main import logger


class DocumentClient:
    def __init__(self):
        if os.getenv("TASK_AGENT_ROUTE") == "DEV":  
            self.base_url = "http://lkm-document:8900"  
        else:
            self.base_url = "http://localhost:8900"  

    async def convert_to_pdf(self, file_path: str) -> str:
        """
        파일을 PDF로 변환하는 API 호출
        200 OK일 때 output_path를 반환
        """
        convert_to_pdf_url = f"{self.base_url}/document/convert/convert-to-pdf"
        
        logger.info(f"convert_to_pdf_url: {convert_to_pdf_url}")
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(convert_to_pdf_url, json={"input_path": file_path}) as response:
                    if response.status == 200:
                        response_data = await response.json()
                        return response_data.get("output_path", "")
                    else:
                        # 에러 발생 시 빈 문자열 반환
                        return ""
                        
        except Exception as e:
            # 예외 발생 시 빈 문자열 반환
            return ""

    async def convert_to_docx(self, file_path: str) -> str:
        """
        파일을 DOCX로 변환하는 API 호출
        200 OK일 때 output_path를 반환
        """
        convert_to_docx_url = f"{self.base_url}/document/convert/convert-to-docx"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(convert_to_docx_url, json={"input_path": file_path}) as response:
                    if response.status == 200:
                        response_data = await response.json()
                        return response_data.get("output_path", "")
                    else:
                        # 에러 발생 시 빈 문자열 반환
                        return ""
                        
        except Exception as e:
            # 예외 발생 시 빈 문자열 반환
            return ""

    async def convert_to_html(self, file_path: str) -> str:
        """
        파일을 HTML로 변환하는 API 호출
        200 OK일 때 output_path를 반환
        """
        convert_to_html_url = f"{self.base_url}/document/convert/convert-to-html"
        
        logger.info(f"convert_to_html_url: {convert_to_html_url}")
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(convert_to_html_url, json={"input_path": file_path}) as response:
                    if response.status == 200:
                        response_data = await response.json()
                        return response_data.get("output_path", "")
                    else:
                        # 에러 발생 시 빈 문자열 반환
                        return ""
                        
        except Exception as e:
            # 예외 발생 시 빈 문자열 반환
            return ""

    async def convert_to_xlsx(self, file_path: str) -> str:
        """
        파일을 XLSX로 변환하는 API 호출
        200 OK일 때 output_path를 반환
        """
        convert_to_xlsx_url = f"{self.base_url}/document/convert/convert-to-xlsx"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(convert_to_xlsx_url, json={"input_path": file_path}) as response:
                    if response.status == 200:
                        response_data = await response.json()
                        return response_data.get("output_path", "")
                    else:
                        # 에러 발생 시 빈 문자열 반환
                        return ""
                        
        except Exception as e:
            # 예외 발생 시 빈 문자열 반환
            return ""
    
    
    async def compare_docx(self, file_path1: str, file_path2: str) -> str:
        """
        두 DOCX 파일을 비교하는 API 호출
        200 OK일 때 output_path를 반환
        """
        compare_docx_url = f"{self.base_url}/document/compare/compare-html"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(compare_docx_url, json={
                    "base_html_path": file_path1,
                    "comparative_html_path": file_path2
                }) as response:
                    if response.status == 200:
                        response_data = await response.json()
                        return response_data.get("output_path", "")
                    else:
                        # 에러 발생 시 빈 문자열 반환
                        return ""
                        
        except Exception as e:
            # 예외 발생 시 빈 문자열 반환
            return ""