from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv
from typing import Optional
from langchain_core.messages import SystemMessage, HumanMessage
import pandas as pd
import json
import re
import os
import plotly.express as px
import random
import datetime
from fastmcp import FastMCP
from utils.llm import LLMSingleton
from pydantic import BaseModel, Field
from mcpserver.functions.saver import save_html

llm = LLMSingleton.get_llm()

visualization_mcp = FastMCP(
    name = "VisualizationServer",
    stateless_http = True
)

class VisualizationInput(BaseModel):
    file_path: str = Field(description="시각화 할 데이터(csv, json) 파일 경로")
    user_input: str = Field(description="시각화 요청 사항")

class VisualizationOutput(BaseModel):
    visualization_html: str = Field(description="시각화 결과가 포함된 HTML 파일")

@visualization_mcp.tool(
    description="사용자의 요청에 따라 데이터를 다양한 차트 형태로 시각화하여 제공합니다."
)
def generate_chart(input: VisualizationInput) -> VisualizationOutput:
    
    file_path = input.file_path
    user_input = input.user_input
    
    data = json.loads(load_file(file_path))
    metadata = get_metadata(data)
    chart_recommendations = recommend_chart(data, metadata, user_input)
    valid_configs = get_valid_configs(data, metadata, chart_recommendations, user_input)
    
    if isinstance(valid_configs, list):
        html_filename = create_plotly_charts(file_path, data, valid_configs)
    else:
        html_filename = create_plotly_charts(file_path, data, [valid_configs])
    
    return html_filename

############## LLM 호출 ##############
def call_llm_base(data, user_prompt, system_prompt=None):
    if system_prompt is None:
        messages = [HumanMessage(content=user_prompt.format(data=data))]
    else:
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt.format(data=data))
        ]
    
    response = llm.invoke(messages)
    return response.content

############## 파일 로드 관련 함수 ##############
def load_file(filepath):
    """
    파일 경로를 받아 csv 또는 json 파일을 자동으로 인식하여 읽고,
    항상 json 형태(리스트/딕셔너리)로 최대 100개만 반환합니다.
    """
    ext = os.path.splitext(filepath)[-1].lower()
    if ext == '.csv':
        df = pd.read_csv(filepath)
        # DataFrame을 dict의 리스트로 변환 (최대 100개)
        data = df.head(100).to_dict(orient='records')
        return json.dumps(data, ensure_ascii=False, indent=2)
    elif ext == '.json':
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # JSON이 리스트(레코드) 형태라면 최대 100개만 반환
        if isinstance(data, list):
            return json.dumps(data[:100], ensure_ascii=False, indent=2)
        # JSON이 딕셔너리라면 key-value 테이블로 변환 (최대 100개)
        elif isinstance(data, dict):
            items = list(data.items())[:100]
            return json.dumps(dict(items), ensure_ascii=False, indent=2)
        else:
            # 기타 형태는 json 문자열로 반환
            return json.dumps(data, ensure_ascii=False, indent=2)
    else:
        raise ValueError("지원하지 않는 파일 형식입니다. (csv, json만 지원)")


############## JSON 파싱 ##############
def parse_llm_json_response(response_text):
    """
    Parse LLM response text and extract JSON content.
    
    Args:
        response_text (str): Raw response text from LLM
        
    Returns:
        dict: Parsed JSON object
        
    Raises:
        json.JSONDecodeError: If JSON parsing fails after all cleaning attempts
    """
    try:
        # Clean the response to extract JSON
        # Remove any markdown formatting and extract JSON content
        json_match = re.search(r'```json\s*(.*?)\s*```', response_text, re.DOTALL)
        if json_match:
            json_content = json_match.group(1)
        else:
            # If no markdown formatting, try to find JSON object directly
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                json_content = json_match.group(0)
            else:
                json_content = response_text.strip()
        
        return json.loads(json_content)
        
    except json.JSONDecodeError as e:
        print(f"JSON parsing error: {e}")
        print("Raw response:")
        print(repr(response_text))
        print("\nAttempting to clean and retry...")
        
        # Additional cleaning attempts
        try:
            # Remove any leading/trailing whitespace and non-JSON content
            cleaned = re.sub(r'^[^{]*', '', response_text)
            cleaned = re.sub(r'[^}]*$', '', cleaned)
            return json.loads(cleaned)
        except json.JSONDecodeError as e2:
            print(f"Still failed after cleaning: {e2}")
            raise e2
        
############## 메타데이터 추출 ##############
def get_metadata(data):
    system_prompt_step1 = """You are a data visualization expert specializing in Plotly Express.  
        Your job is to analyze structured JSON data and extract metadata that helps generate appropriate visualizations using Plotly.

        For every given dataset, extract the following metadata for each field (column):
        1. Field name  
        2. Data type (categorical, numerical, datetime, boolean, etc.)  
        3. Number of unique values  
        4. Three example values  
        5. Missing value existence (True/False)

        Output the result as a clean, markdown table with the following columns:
        | Field | Type | Unique Values | Example Values | Has Missing? |

        Only use the JSON provided by the user. Do not guess or infer fields not in the data.  
        This metadata will be used to determine chart type, axis mapping, and grouping strategy.
        You are a data visualization expert specializing in Plotly Express.  
        Your job is to analyze structured JSON data and extract metadata that helps generate appropriate visualizations using Plotly.

        For every given dataset, extract the following metadata for each field (column):
        1. Field name  
        2. Data type (categorical, numerical, datetime, boolean, etc.)  
        3. Number of unique values  
        4. Three example values  
        5. Missing value existence (True/False)

        Output the result as a clean, markdown table with the following columns:
        | Field | Type | Unique Values | Example Values | Has Missing? |

        Only use the JSON provided by the user. Do not guess or infer fields not in the data.  
        This metadata will be used to determine chart type, axis mapping, and grouping strategy.
        """

    user_prompt_step1 = """Please analyze the following JSON dataset and extract metadata useful for Plotly chart generation.  

        utput only a **markdown table** with the following columns, and **nothing else**. Do not include any explanation, heading, or additional text.
        
        Return the result as a markdown table with the following columns:  
        | Field | Type | Unique Values | Example Values | Has Missing? |

        JSON:
        {data}
        """

    metadata = call_llm_base(data, user_prompt_step1, system_prompt_step1)
    return metadata

############## 차트 타입 추천 ##############
def recommend_chart(data, metadata, user_input):
    """
    데이터와 메타데이터를 기반으로 차트 타입을 추천하는 함수
    
    Args:
        data: 차트 데이터 (JSON 형태)
        metadata: 데이터 메타데이터 (markdown 테이블 형태)
        
    Returns:
        dict: 차트 타입 추천 결과 (1~4개)
    """
    system_prompt_step2 = """
        You are a data visualization expert specializing in Plotly Express.

        Your task is to recommend the most suitable chart types based on the provided dataset and metadata.
        
        IMPORTANT: Only recommend charts that can actually be created with the available data.
        - Recommend between 1 to 4 chart types maximum
        - Each chart must be feasible with the given data structure
        - Rank them from most to least appropriate
        - DO NOT recommend charts that would result in null/empty axis assignments

        Consider the following factors when choosing chart types:
        1. **Data characteristics**: 
           - For categorical vs numerical: bar, box, violin, pie
           - For time series: line, area
           - For distributions: histogram, box, violin
           - For correlations: scatter
           - For hierarchical data: treemap, sunburst
           - For funnel processes: funnel, funnel_area
           - For parallel comparisons: parallel_coordinates, parallel_categories

        2. **Data feasibility check**:
           - bar/line/area: Need both categorical and numerical fields
           - scatter: Need at least 2 numerical fields
           - box/violin: Need categorical and numerical fields
           - histogram: Need at least 1 numerical field
           - pie/treemap/sunburst: Need categorical names and numerical values
           - parallel_coordinates: Need multiple numerical fields
           - parallel_categories: Need multiple categorical fields

        3. **Data size and complexity**:
           - Small datasets (< 20 points): pie, bar, line
           - Medium datasets (20-100 points): bar, box, scatter, violin
           - Large datasets (> 100 points): histogram, density_heatmap, scatter

        4. **Field characteristics from metadata**:
           - Number of unique values in each field
           - Data types (categorical, numerical, datetime)
           - Missing value patterns

        Choose from these chart types:
        "line", "bar", "area", "scatter", "box", "violin", "histogram", "density_heatmap", 
        "pie", "treemap", "sunburst", "parallel_coordinates", "parallel_categories", 
        "funnel", "funnel_area", "density_contour"

        CRITICAL: Only recommend charts where you can clearly identify appropriate x/y axis assignments from the available fields.

        Return a JSON object like this:
        {
        "recommendations": [
            {
                "rank": 1,
                "chart_type": "<type>",
                "justification": "<why this is the best chart for this dataset and why it's feasible>"
            },
            {
                "rank": 2,
                "chart_type": "<type>",
                "justification": "<why this is the second best option and why it's feasible>"
            }
        ]
        }

        Do not return anything else. Output only valid JSON.
        """
        

    user_prompt_step2 = """Based on the following data, metadata, and user request, recommend between 1-4 most appropriate and FEASIBLE chart types to visualize this dataset using Plotly, ranked in order of suitability.

        PRIORITIZE USER-REQUESTED CHART TYPES when feasible with the data.

        USER REQUEST:
        {user_input}

        DATA:
        {data}

        METADATA:
        {metadata}
        """

    messages = [
        SystemMessage(content=system_prompt_step2),
        HumanMessage(content=user_prompt_step2.format(data=json.dumps(data), metadata=metadata, user_input=user_input))
    ]

    response = llm.invoke(messages)
    chart_recommendations = parse_llm_json_response(response.content)

    return chart_recommendations

############## 차트 config 설정 ##############
def get_config(data, metadata, chart_recommendations, chart_rank=1, user_input=None):
    """
    차트 타입에 맞는 축 및 그룹핑 설정을 결정하는 함수
    
    Args:
        data: 차트 데이터 (JSON 형태)
        metadata: 데이터 메타데이터 (markdown 테이블 형태)
        chart_recommendations: 차트 타입 추천 결과 (4개 추천 포함)
        chart_rank: 사용할 차트의 순위 (1~4, 기본값: 1)
        user_input: 사용자 요청 (선택사항)
        
    Returns:
        dict: 차트 설정 (x, y, color, facet_col 등)
    """
    if chart_rank < 1 or chart_rank > len(chart_recommendations['recommendations']):
        raise ValueError(f"chart_rank는 1부터 {len(chart_recommendations['recommendations'])} 사이의 값이어야 합니다.")
    
    selected_chart = chart_recommendations['recommendations'][chart_rank - 1]
    chart_type = selected_chart['chart_type']
    
    system_prompt_config = """
        You are a data visualization expert specializing in Plotly Express.

        Your job is to determine the most appropriate axis and grouping variables for a SPECIFIC chart type.

        You will be given:
        - A metadata summary table with field information
        - A specific chart type that has already been chosen
        - The actual dataset
        - User's specific request (if any)

        **PRIORITY RULES:**
        1. **CHART-SPECIFIC USER REQUEST**: If user mentions specific variables AND specific chart types (e.g., "pie chart for gender comparison"), apply user preferences ONLY if the current chart type matches the user's requested chart type
        2. **GENERAL USER REQUEST**: If user mentions variables without specifying chart types (e.g., "compare by gender"), apply to all relevant chart types
        3. **CHART TYPE REQUIREMENTS**: Ensure selections meet chart type constraints
        4. **DATA-DRIVEN SELECTION**: For remaining assignments, use data characteristics

        **Chart type specific requirements:**
        - **bar/line/area**: x=categorical/time, y=numerical, color=categorical
        - **scatter**: x=numerical, y=numerical, color=categorical
        - **box/violin**: x=categorical, y=numerical, color=categorical
        - **histogram**: x=numerical, color=categorical
        - **pie/treemap/sunburst**: names=categorical, values=numerical, color=categorical
        - **funnel**: x=categorical, y=numerical
        - **parallel_coordinates**: dimensions=[numerical_fields]
        - **parallel_categories**: dimensions=[categorical_fields]

        **Selection criteria:**
        1. **X-axis**: Choose based on chart type requirements and user preferences (if applicable to current chart type)
        2. **Y-axis**: Choose numerical field for most charts, prioritize user-mentioned variables (if applicable to current chart type)
        3. **Color**: Choose categorical field mentioned by user (if applicable to current chart type) or with moderate unique values (2-10)
        4. **Facet_col**: Choose categorical field for subplotting if user requests grouping (if applicable to current chart type)

        **Field priority rules:**
        - If user mentions specific variables FOR THIS CHART TYPE → prioritize those for appropriate axes
        - If user mentions chart-specific requests (e.g., "pie chart for gender") and current chart type doesn't match → ignore user variable preferences and use data-driven selection
        - For categorical fields: prefer fields with fewer unique values for x-axis
        - For numerical fields: prefer fields with more variation for y-axis
        - For color: avoid fields with too many unique values (>10)
        - For faceting: use fields with very few unique values (2-4)

        **IMPORTANT**: Only include fields that are actually needed for the specific chart type. Do NOT include null values for fields that are not applicable to the chart type.

        Return your answer as a valid JSON object only, without any explanation or additional text:

        ```json
        {
        "x": "<field_name>",
        "y": "<field_name>",
        "color": "<field_name or null>",
        "facet_col": "<field_name or null>",
        "justification": "Explain why each variable was selected, mentioning whether user preferences were applied to THIS SPECIFIC chart type or if data-driven selection was used."
        }
        ```
        """
        
    user_prompt_config = """Based on the following metadata, chart type, data, and user request, determine the best x-axis, y-axis, and grouping fields for the specific chart type.

        IMPORTANT: Apply user variable preferences ONLY if they are relevant to the current chart type. If user specifies "pie chart for gender comparison" but current chart type is "bar", then use data-driven selection instead of forcing gender variable.

        USER REQUEST:
        {user_input}

        CURRENT CHART TYPE:
        {chart_type}

        METADATA:
        {metadata}

        DATA:
        {data}
        """
        
    messages = [
        SystemMessage(content=system_prompt_config),
        HumanMessage(content=user_prompt_config.format(
            user_input=user_input or "No specific variable preferences provided",
            metadata=json.dumps(metadata), 
            chart_type=chart_type,
            data=json.dumps(data)
        ))
    ]

    response = llm.invoke(messages)
    chart_config = parse_llm_json_response(response.content)
    
    # 선택된 차트 정보도 함께 반환
    chart_config['selected_chart'] = selected_chart

    return chart_config

############## 차트 config 유효성 검증 ##############
def get_config_with_validation(data, metadata, chart_recommendations, chart_rank=1, user_input=None):
    """
    차트 설정을 가져오고 유효성을 검증하는 함수
    """
    try:
        config = get_config(data, metadata, chart_recommendations, chart_rank, user_input)
        
        # 필수 요소 검증
        chart_type = config['selected_chart']['chart_type']
        
        # 차트 타입별 필수 요소 검증
        validation_rules = {
            'bar': ['x', 'y'],
            'line': ['x', 'y'],
            'area': ['x', 'y'],
            'scatter': ['x', 'y'],
            'box': ['x', 'y'],
            'violin': ['x', 'y'],
            'histogram': ['x'],
            'pie': ['names', 'values'],
            'treemap': ['names', 'values'],
            'sunburst': ['names', 'values'],
            'funnel': ['x', 'y'],
            'parallel_coordinates': ['dimensions'],
            'parallel_categories': ['dimensions']
        }
        
        required_fields = validation_rules.get(chart_type, ['x', 'y'])
        
        # 필수 필드가 모두 존재하고 null이 아닌지 확인
        for field in required_fields:
            if field not in config or config[field] is None:
                return None
        
        # null 값 제거 (필요하지 않은 필드들)
        cleaned_config = {}
        for key, value in config.items():
            if value is not None or key in ['justification', 'selected_chart']:
                cleaned_config[key] = value
        
        return cleaned_config
        
    except Exception as e:
        return None

############## 유효성 검증된 것 필터링 ##############
def get_valid_configs(data, metadata, chart_recommendations, user_input=None):
    """
    유효한 차트 설정들만 반환하는 함수
    """
    valid_configs = []
    
    for i in range(1, len(chart_recommendations['recommendations']) + 1):
        config = get_config_with_validation(data, metadata, chart_recommendations, chart_rank=i, user_input=user_input)
        if config:
            valid_configs.append(config)
    
    return valid_configs


############## 차트 생성 ##############
def create_plotly_charts(filepath, data, valid_configs):
    """
    유효한 설정들을 기반으로 모든 차트를 생성하는 함수
    
    Args:
        filepath: 원본 파일 경로
        data: 차트 데이터
        valid_configs: 유효한 차트 설정 리스트
    
    Returns:
        str: 결합된 HTML 파일명
    """
    if not valid_configs:
        return None
    
    df = pd.DataFrame(data)
    base_filename = os.path.splitext(os.path.basename(filepath))[0]
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    plot_func_map = {
        "bar": px.bar, "line": px.line, "area": px.area, "scatter": px.scatter,
        "box": px.box, "violin": px.violin, "histogram": px.histogram,
        "density_heatmap": px.density_heatmap, "pie": px.pie, "treemap": px.treemap,
        "sunburst": px.sunburst, "parallel_coordinates": px.parallel_coordinates,
        "parallel_categories": px.parallel_categories, "funnel": px.funnel,
        "funnel_area": px.funnel_area, "density_contour": px.density_contour
    }
    
    available_templates = ["plotly_white", "ggplot2", "seaborn", "simple_white"]
    
    charts_html = ""
    
    n_charts = len(valid_configs)
    for i, config in enumerate(valid_configs):
        chart_info = config["selected_chart"]
        chart_type = chart_info["chart_type"]
        
        # 차트 타입에 따라 다른 파라미터 처리
        if chart_type in ["pie", "treemap", "sunburst"]:
            # names와 values 사용
            names = config.get("names")
            values = config.get("values")
            color = config.get("color")
            facet_col = config.get("facet_col")
            
            print(f"{chart_type}: names={names}, values={values}, color={color}")
            
            if not names or not values:
                print(f"Skipping {chart_type} chart due to missing names or values")
                continue
                
        else:
            # x, y 사용
            x = config.get("x")
            y = config.get("y")
            color = config.get("color")
            facet_col = config.get("facet_col")
            
            print(f"{chart_type}: x={x}, y={y}, color={color}")
            
            if not x or not y:
                print(f"Skipping {chart_type} chart due to missing x or y")
                continue
        
        # 파라미터 구성
        params = {
            "data_frame": df,
            "template": random.choice(available_templates)
        }
        
        if chart_type == "pie":
            params.update({"values": values, "names": names})
        elif chart_type in ["treemap", "sunburst"]:
            params.update({"values": values, "path": [names]})
        elif chart_type in ["histogram", "density_heatmap", "density_contour"]:
            params["x"] = x
        elif chart_type in ["parallel_coordinates", "parallel_categories"]:
            params["dimensions"] = [x, y] + ([color] if color else [])
        elif chart_type in ["funnel", "funnel_area"]:
            params.update({"x": x, "y": y})
        else:
            params.update({"x": x, "y": y})
        
        if color and chart_type not in ["parallel_coordinates", "parallel_categories"]:
            params["color"] = color
        if facet_col and chart_type in ["bar", "line", "area", "scatter", "box", "violin", "histogram"]:
            params["facet_col"] = facet_col
        
        try:
            # 차트 생성
            fig = plot_func_map[chart_type](**params)
            
            # 차트 레이아웃 조정 (크기 제한)
            fig.update_layout(
                autosize=True,
                margin=dict(l=20, r=20, t=20, b=20),
                showlegend=True,
                width=None,
                height=None,
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=-0.2,
                    xanchor="center",
                    x=0.5
                ) if chart_type not in ["pie", "treemap", "sunburst"] else dict()
            )
            
            # HTML 변환 (include_plotlyjs='inline'으로 완전한 차트 생성)
            chart_html = fig.to_html(
                include_plotlyjs='inline',
                div_id=f"chart_{i}",
                config={
                    'responsive': True, 
                    'displayModeBar': False,
                    'autosizable': True
                }
            )
            
            # body 태그 내용만 추출
            body_start = chart_html.find('<body>') + 6
            body_end = chart_html.find('</body>')
            chart_content = chart_html[body_start:body_end] if body_start > 5 else chart_html
            
            # 차트 제목과 설정 정보 생성
            if chart_type in ["pie", "treemap", "sunburst"]:
                chart_title = f"{chart_type.capitalize()}: {values} by {names}"
                config_info = f"names={names}, values={values}, color={color}"
            else:
                chart_title = f"{chart_type.capitalize()}: {y} by {x}"
                config_info = f"x={x}, y={y}, color={color}"
                
            # 중앙정렬 클래스 추가
            chart_class = "chart-item"
            # 홀수 개일 때 마지막 차트만 중앙 정렬 (너비는 동일하게 유지)
            if n_charts % 2 == 1 and i == n_charts - 1:
                chart_class += " center-last"
            
            charts_html += f"""
            <div class=\"{chart_class}\">
                <h3>{chart_title}</h3>
                <p class=\"config\">{config_info}</p>
                <div class=\"chart-wrapper\">
                    {chart_content}
                </div>
            </div>
            """
            
        except Exception as e:
            print(f"Error creating {chart_type} chart: {e}")
            continue
    
    # HTML 파일 생성
    combined_filename = f"{base_filename}_dashboard_{timestamp}.html"
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Charts Dashboard</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            h1 {{ text-align: center; margin-bottom: 30px; }}
            .charts-grid {{ 
                display: grid; 
                grid-template-columns: 1fr 1fr; 
                gap: 30px; 
                margin-top: 20px; 
            }}
            .chart-item {{ 
                border: 1px solid #ddd; 
                border-radius: 8px; 
                padding: 15px; 
                background: #fafafa; 
                min-height:500px;
            }}
            .chart-item h3 {{ margin: 0 0 5px 0; color: #333; }}
            .config {{ font-size: 12px; color: #666; margin: 0 0 15px 0; }}
            .chart-wrapper {{ 
                width: 100%; 
                height: 500px; 
            }}
            .chart-wrapper > div {{
                width: 100% !important;
                height: 100% !important;
            }}
            /* 홀수 개일 때 마지막 차트 중앙 정렬 (너비는 동일하게 유지) */
            .center-last {{
                grid-column: 1 / span 2;
                justify-self: center;
                width: calc(50% - 15px);
            }}
            @media (max-width: 768px) {{
                .charts-grid {{ grid-template-columns: 1fr; }}
                .center-last {{ 
                    grid-column: auto; 
                    justify-self: auto;
                    width: 100%;
                }}
            }}
        </style>
    </head>
    <body>
        <h1>{base_filename}</h1>
        <div class="charts-grid">
            {charts_html}
        </div>
    </body>
    </html>
    """
        
    full_path = os.path.join(os.getcwd(), "sample/output.html")
    save_path = save_html("","",str(html_content),full_path=full_path)
    
    return save_path


visualization_app = visualization_mcp.http_app()