from fastmcp import FastMCP


# Import required modules and initialize the builder from open_deep_research
import uuid
import os, sys
import json

from pydantic import BaseModel, Field
from langgraph.types import Command
from langgraph.checkpoint.memory import MemorySaver
from .open_deep_research.src.open_deep_research.graph import builder
from dotenv import load_dotenv

from mcpserver.functions.file_handler import FileHandler
from utils.state_loader import StateLoader

load_dotenv()  # .env 파일 로드

file_handler = FileHandler()
state_loader = StateLoader()

package_path = os.path.join(os.path.dirname(__file__), "open_deep_research", "src")
if package_path not in sys.path:
    sys.path.insert(0, package_path)
    
    


websearch2report_mcp = FastMCP(
    name = "WebserachServer",
    stateless_http = True
)


os.environ["AZURE_OPENAI_ENDPOINT"] = os.getenv("OPENAI_ENDPOINT")

# Create a memory-based checkpointer and compile the graph
# This enables state persistence and tracking throughout the workflow execution
memory = MemorySaver()
graph = builder.compile(checkpointer=memory)

# 간단히 그래프 구조 출력
graph_data = graph.get_graph(xray=1)
# print("Graph Nodes:", graph_data.nodes)
# print("Graph Edges:", graph_data.edges)

# Define report structure template and configure the research workflow
# This sets parameters for models, search tools, and report organization
REPORT_STRUCTURE = """Use this structure to create a report on the user-provided topic:

1. Introduction (no research needed)
   - Brief overview of the topic area

2. Main Body Sections:
   - Each section should focus on a sub-topic of the user-provided topic
   
3. Conclusion
   - Aim for 1 structural element (either a list of table) that distills the main body sections 
   - Provide a concise summary of the report"""


# Search API 선택
SEARCH_API = "bingsearch"
SEARCH_API_CONFIG = {}

if SEARCH_API == "googlesearch":
    SEARCH_API_CONFIG = {
        "api_key": os.getenv("GOOGLE_API_KEY"),
        "cx": os.getenv("GOOGLE_CX"),
    }
elif SEARCH_API == "perplexity":
    SEARCH_API_CONFIG = {"api_key": os.getenv("PERPLEXITY_API_KEY")}
elif SEARCH_API == "bingsearch":
    SEARCH_API_CONFIG = {
        "api_key": os.getenv("BING_SEARCH_KEY"),
        "max_results": 10,
        "include_raw_content": True,
    }
else:
    raise ValueError(f"Invalid search API: {SEARCH_API}")


# Planner, Writer 선택
MODEL_PROVIDER = "azure_openai"

if MODEL_PROVIDER == "azure_openai":
    MODEL = os.getenv("OPENAI_DEPLOYMENT")
    # Azure OpenAI 추가 설정
    MODEL_AZURE_ENDPOINT = os.getenv("OPENAI_ENDPOINT")
    MODEL_API_KEY = os.getenv("OPENAI_API_KEY")
    MODEL_AZURE_DEPLOYMENT = os.getenv("OPENAI_DEPLOYMENT")
    MODEL_API_VERSION = os.getenv("OPENAI_API_VERSION")
    MODEL_KWARGS = {}
elif MODEL_PROVIDER == "anthropic":
    MODEL = "claude-3-7-sonnet-latest"
    MODEL_KWARGS = {
        "anthropic_api_key": os.getenv("ANTHROPIC_API_KEY"),
        "max_retries": 3,
    }
else:
    raise ValueError(f"Invalid planner provider: {MODEL_PROVIDER}")


# Configuration : Use OpenAI o3 for both planning and writing (selected option)
thread = {
    "configurable": {
        "thread_id": str(uuid.uuid4()),
        "search_api": SEARCH_API,
        "search_api_config": SEARCH_API_CONFIG,
        "planner_provider": MODEL_PROVIDER,  # openai에서 azure_openai로 변경
        "planner_model": MODEL,
        "planner_azure_endpoint": MODEL_AZURE_ENDPOINT,
        "planner_api_key": MODEL_API_KEY,
        "planner_azure_deployment": MODEL_AZURE_DEPLOYMENT,
        "planner_api_version": MODEL_API_VERSION,
        "planner_model_kwargs": MODEL_KWARGS,
        "writer_provider": MODEL_PROVIDER,  # openai에서 azure_openai로 변경
        "writer_model": MODEL,
        "writer_azure_endpoint": MODEL_AZURE_ENDPOINT,
        "writer_api_key": MODEL_API_KEY,
        "writer_azure_deployment": MODEL_AZURE_DEPLOYMENT,
        "writer_api_version": MODEL_API_VERSION,
        "writer_model_kwargs": MODEL_KWARGS,
        "max_search_depth": 2,
        "report_structure": REPORT_STRUCTURE,
    }
}


# Function to handle interrupts and collect feedback
async def handle_interrupt(event):
    interrupt_value = event["__interrupt__"][0].value
    print("\n--- INTERRUPT ---")
    print(interrupt_value)
    print("----------------\n")

    # In interactive mode, you could get user feedback
    # For script mode, we'll just continue automatically
    return "continue"


# Function to run the initial research phase
async def run_research():
    try:
        async for event in graph.astream(
            {"topic": topic}, thread, stream_mode="updates"
        ):
            if "__interrupt__" in event:
                return await handle_interrupt(event)
        return True  # Default return if no interrupts occurred
    except Exception as e:
        print(f"Error during initial research: {str(e)}")
        return False


# Function to finalize and generate the report
async def generate_report():
    try:
        async for event in graph.astream(
            Command(resume=True), thread, stream_mode="updates"
        ):
            print(event)
            print("\n")

        # Get final report from state
        final_state = graph.get_state(thread)
        print("\nfinal state")
        print(f"\n{final_state}")
        report = final_state.values.get("final_report")
        return report
    except Exception as e:
        print(f"Error generating report: {str(e)}")
        return "Failed to generate report due to an error."



async def websearch_to_report_origin(research_topic: str) -> str:  # wo feedback

    global thread  # thread 변수를 전역으로 참조

    # search_api 프린트
    print(f"[websearch_to_report] search_api: {thread['configurable'].get('search_api')}")

    # 스레드 ID 새로 생성 (매번 새로운 연구를 위해)
    thread_config = thread.copy()  # 기조 설정 복사
    thread_config["configurable"]["thread_id"] = str(uuid.uuid4())  # 새 ID 할당

    print("Starting research phase...")
    try:
        async for event in graph.astream(
            {"topic": research_topic}, thread, stream_mode="updates"
        ):
            print(event)
            print("\n")

        final_state = graph.get_state(thread)
        print("\nfinal state")
        print(f"\n{final_state}")

        report = str(final_state.values.get("final_report"))


        # 보고서 저장 안함
        # results_dir = os.path.join(
        #     os.path.dirname(__file__), "open_deep_research", "results"
        # )
        # os.makedirs(results_dir, exist_ok=True)
        # from datetime import datetime
        # current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        # topic_short = (
        #     "".join(
        #         char
        #         for char in research_topic.split(",")[0][:10]
        #         if char.isalnum() or char.isspace()
        #     )
        #     .strip()
        #     .replace(" ", "_")
        # )
        # filename = f"{topic_short}_{current_time}.md"
        # result_file_path = os.path.join(results_dir, filename)
        # result_file_path = file_handler.get_dir_path(result_file_path)
        # with open(result_file_path, "w", encoding="utf-8") as f:
        #     f.write(f"# {research_topic}\n\n")
        #     f.write(report)

        # print(f"\nReport saved to: {result_file_path}")

        return report
    except Exception as e:
        print(f"Error during research: {str(e)}")
        return "Failed to generate report due to an error."

@websearch2report_mcp.tool(
    description="입력받은 주제에 대해 웹 검색 결과를 기반으로 관련 보고서를 생성합니다."
)
async def websearch_to_report(file_path: str):
    try:
        file_path = file_handler.get_dir_path(file_path)
        with open(file_path, "r", encoding="utf-8") as f:
            context = json.load(f)
        report = websearch_to_report_origin(context["user_query"])

        context["tool_calling_history"].append({"report_result": report})
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(context, f, ensure_ascii=False, indent=4)
            
    except Exception as e:
        context["tool_calling_history"].append(
            {"tool_name": "websearch_to_report",
                "error": str(e)})
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(context, f, ensure_ascii=False, indent=4)

    import time
    time.sleep(3)

    return "report 작성완료"


websearch2report_app = websearch2report_mcp.http_app()