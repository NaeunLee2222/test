import json
import os
import requests
from datetime import datetime, timedelta
from pydantic import BaseModel, Field
from fastmcp import FastMCP
from mcpserver.functions.file_handler import FileHandler

file_handler = FileHandler()


emergency_slack_mcp = FastMCP(
    name = "EmergencySlackServer",
    stateless_http = True
)

class SendSlackNotificationInput(BaseModel):
    output_path: str = Field(
        ..., description="emergency tool로 생성된 비상 대응 메시지 파일의 경로"
    )

@emergency_slack_mcp.tool(description="생성된 긴급 메시지를 Slack을 통해 전송합니다.")
def send_slack(input: SendSlackNotificationInput) -> dict:
    # 파일 경로 처리 (get_file_path 사용)
    output_path = file_handler.get_file_path(input.output_path)
    if not output_path:
        return {
            "success": False,
            "error": f"File not found: {input.output_path}",
            "status_code": None
        }

    encodings = ["utf-8", "cp949", "euc-kr"]
    msg_json = None

    # 파일 읽기 시도
    for encoding in encodings:
        try:
            with open(output_path, 'r', encoding=encoding) as f:
                msg_json = f.read()
            break
        except UnicodeDecodeError:
            continue
        except Exception as e:
            return {
                "success": False,
                "error": f"Unexpected error with {encoding}: {e}",
                "status_code": None
            }

    if msg_json is None:
        return {
            "success": False,
            "error": f"Failed to read file with any encoding: {encodings}",
            "status_code": None
        }

    # JSON 파싱 시도
    try:
        msg_dict = json.loads(msg_json)
    except json.JSONDecodeError as e:
        return {
            "success": False,
            "error": f"Invalid JSON format in file {output_path}: {e}",
            "status_code": None
        }
    
    # 메시지 데이터 추출

    disaster_type = msg_dict.get("disaster_type", "비상상황이 발생했습니다")
    roles = msg_dict.get("msg_team", {}).get("roles", [])
    report_flow = msg_dict.get("report_flow", "보고 체계 정보 없음")
    msg_personal = msg_dict.get("msg_personal", "개인별 조치 없음")
    file_name = msg_dict.get("file_name", "비상대응매뉴얼")
    
    # 직원 정보에서 webhook URL과 직원 정보 가져오기
    employee_info = msg_dict.get("employee_info", {})
    webhook_url = employee_info.get("webhook_url", "")
    employee_name = employee_info.get("name", "담당자")
    employee_position = employee_info.get("position", "직원")
    target_webhook_url = msg_dict.get("target_webhook_url", "")
    site = employee_info.get("site", "")
    
    if not webhook_url:
        return_message = f"{employee_name}님의 Slack webhook URL이 설정되지 않았습니다."
        return return_message


    # 조직별 대응 체계 메시지 구성
    msg_role = "🏢 *조직별 대응 체계*"
    for role in roles:
        msg_role += f"\n\n_{role.get('role_name', '역할명 없음')}_"
        for action in role.get("actions", []):
            msg_role += f"\n- {action}"

    current_time = (datetime.now() + timedelta(hours=9)).strftime("%Y-%m-%d %H:%M")

    # Slack Block Kit 메시지 페이로드 구성
    payload = {
        "attachments": [
            {
                "color": "#FF0000",  # 빨간색
                "blocks": [
                    {
                        "type": "header",
                        "text": {"type": "plain_text", "text": "🚨 긴급 대응 요청"},
                    },
                    {
                        "type": "context",
                        "elements": [
                            {"type": "mrkdwn", "text": f"발생시간: {current_time}"}
                        ],
                    },
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*{site}에서 {disaster_type}*\n\n{employee_name}님({employee_position}) 및 관련 담당자는 아래 역할과 조치 내용을 확인하고 즉시 대응해 주시기 바랍니다.",
                        },
                    },
                    {
                        "type": "actions",
                        "elements": [
                            {
                                "type": "button",
                                "text": {
                                    "type": "plain_text",
                                    "text": "✅ 상황 접수 완료",
                                },
                                "style": "primary",
                                "action_id": "situation_received",
                                "value": f"received_{employee_name}",
                                "confirm": {
                                    "title": {
                                        "type": "plain_text",
                                        "text": "상황 접수 완료 확인",
                                    },
                                    "text": {
                                        "type": "plain_text",
                                        "text": f"{employee_name}님이 상황을 접수 완료 처리하시겠습니까?",
                                    },
                                    "confirm": {
                                        "type": "plain_text",
                                        "text": "접수하기",
                                    },
                                    "deny": {"type": "plain_text", "text": "취소"},
                                },
                            },
                            {
                                "type": "button",
                                "text": {
                                    "type": "plain_text",
                                    "text": "🆘 긴급 지원 요청",
                                },
                                "style": "danger",
                                "action_id": "emergency_support",
                                "value": f"support_{employee_name}",
                                "confirm": {
                                    "title": {
                                        "type": "plain_text",
                                        "text": "긴급 지원 요청 확인",
                                    },
                                    "text": {
                                        "type": "plain_text",
                                        "text": f"{employee_name}님이 긴급 지원을 요청하시겠습니까?",
                                    },
                                    "confirm": {
                                        "type": "plain_text",
                                        "text": "요청하기",
                                    },
                                    "deny": {"type": "plain_text", "text": "취소"},
                                },
                            },
                        ],
                    },
                    {
                        "type": "section",
                        "fields": [
                            {
                                "type": "mrkdwn",
                                "text": f"*📞 보고 및 연락 체계*\n\n{report_flow}",
                            },
                            {"type": "mrkdwn", "text": f"*📋 참고문서*\n\n{file_name}"},
                        ],
                    },
                    {"type": "section", "text": {"type": "mrkdwn", "text": msg_role}},
                    {
                        "type": "section",
                        "text": {"type": "mrkdwn", "text": f"*🙋‍♂️ {employee_name}님 개인별 조치*\n\n{msg_personal}"},
                    },
                ],
            }
        ]
    }

    context["tool_calling_history"].append(
        {"emergency_result": emergency_result})
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(context, f, ensure_ascii=False, indent=4)
    import time
    time.sleep(3)
    

    try:
        response = requests.post(
            target_webhook_url,
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        
        success = response.status_code == 200

        return_message = f"{employee_name}님({employee_position})에게 Slack 긴급 메시지가 성공적으로 전송되었습니다." if success else f"Slack 전송 실패 (상태코드: {response.status_code})"
    
        
    except requests.exceptions.Timeout:
        return_message = f"{employee_name}님에게 Slack 전송 중 시간 초과가 발생했습니다."
        
    except requests.exceptions.RequestException as e:
        return_message = f"{employee_name}님에게 Slack 전송 중 네트워크 오류가 발생했습니다."

    except Exception as e:
        return_message = f"{employee_name}님에게 Slack 전송 중 오류가 발생했습니다."
        
    return return_message



emergency_slack_app = emergency_slack_mcp.http_app()