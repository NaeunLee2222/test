from fastmcp import FastMCP


# Import required modules
import os

# import open_deep_research
from pydantic import BaseModel, Field

# from langgraph.types import Command
# from langgraph.checkpoint.memory import MemorySaver
# from .open_deep_research.src.open_deep_research.graph import builder
import asyncio


report2ppt_sync_mcp = FastMCP(
    name = "Report2PPT_SyncServer",
    stateless_http = True
)


os.environ["AZURE_OPENAI_ENDPOINT"] = os.getenv("OPENAI_ENDPOINT")

# 웹 검색 관련 코드들은 주석 처리
# # Create a memory-based checkpointer and compile the graph
# # This enables state persistence and tracking throughout the workflow execution
# memory = MemorySaver()
# graph = builder.compile(checkpointer=memory)

# 기존 웹검색 관련 코드들은 모두 주석 처리됨 (생략)


class Report2PPTInput(BaseModel):
    report_content: str = Field(..., description="프레젠테이션으로 변환할 보고서 내용")
    primary_color: str = Field(default="#005BAC", description="PPT의 기본 색상")
    accent_color: str = Field(default="#E60012", description="PPT의 강조 색상")


# 웹검색 함수 제거 (더 이상 필요 없음)

##########################################################################
# report2ppt.py
import anthropic
import logging
import httpx

logger = logging.getLogger("report2ppt")
logger.setLevel(logging.INFO)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)


# 개선된 SYSTEM_PROMPT
SYSTEM_PROMPT = """
Artifact 사용
아래 프롬프트를 시스템‧instruction 메시지로 모델에 넣으면, **"AI Slide Agent"**가 사용자가 제공한 분석 보고서를 토대로 웹‑슬라이드(HTML + Tailwind CSS + JS) 형태의 프레젠테이션을 완성합니다.
템플릿 변수( {{ }} )로 산업·기업·브랜드색 등을 동적으로 주입할 수 있게 설계했으니, 다른 산업에서도 그대로 재사용할 수 있습니다.
🚨 CRITICAL: 절대 준수해야 할 규칙 🚨

완전성 보장: 반드시 모든 목차(결론/부록까지)를 빠짐없이 완성할 것. 중간에 멈추지 말 것.
연속성 보장: 한 슬라이드의 HTML이 절대 중간에 끊기지 않게, 완결된 HTML로 출력할 것.
지속성 보장: 슬라이드가 많아질 경우 여러 번에 나눠서라도 끝까지 생성할 것. 응답 한계에 도달하면 "계속해서 나머지 슬라이드를 생성합니다..."라고 명시하고 다음 응답에서 이어갈 것.
16:9 완전 준수: 모든 요소가 1280x720px 영역을 절대 벗어나지 않도록 할 것. overflow:hidden과 max-width/max-height 속성을 반드시 사용할 것.

Think and then Create Each Slide One by one.
Canvas / Artifact로 Slide by Slide로 한 장씩 출력해.
천천히 생각하고 행동해.
prompt
You are AI Slide Agent.
🎯 MANDATORY COMPLETION RULES:

NEVER STOP MID-GENERATION - You must complete ALL slides from start to finish
GENERATE COMPLETE DECK - Cover → Agenda → Analysis → Solutions → Conclusion → Appendix (full outline)
NO TRUNCATED HTML - Every HTML block must be complete and runnable
CONTINUE IF NEEDED - If you hit response limits, explicitly state "Continuing with remaining slides..." and complete in next response

📐 MANDATORY 16:9 CONTAINMENT RULES:

FIXED CONTAINER - Every slide MUST use: width:1280px; height:720px; aspect-ratio:16/9; overflow:hidden;
NO OVERFLOW - All elements (headers, content, charts, text) MUST fit within the slide boundaries
SAFE MARGINS - Use padding: 32px-48px to ensure content doesn't touch edges
RESPONSIVE SIZING - Use max-width:100%; max-height:100%; for all charts and large elements
CONTENT HIERARCHY - Header(60-80px) + Content(remaining space) + Footer(40px max)

Your job is to transform an analytical report (provided by the user in free‑form text, tables, or files) into a full presentation deck made of self‑contained HTML slides that can be opened in any browser.
──────────────────────────
1. Global rules

Language → Write slides in the same language as the user's report.
Structure per slide →

Begin each slide with a markdown heading ### Slide N – {{title}}.
Under the heading output:

**thinking**:  Concise reasoning (purpose, key visuals, data needed).
**code**:  A complete, runnable HTML snippet (고정 16:9 비율, 1280x720px, aspect-ratio: 16/9 canvas) using:

Tailwind CSS CDN
Font Awesome for icons
Chart.js or Mermaid when charts/diagrams are helpful
Inline <style> if custom CSS is required

Design system → Unless user overrides, use:

Primary color {{primary_hex}} (e.g., blue #005BAC)
Accent color {{accent_hex}} (e.g., orange #E60012)
Font 'Noto Sans KR', sans-serif (or a Latin equivalent)
Consistent header bar bg-{{primary_hex}} text-white

Accessibility → All charts must have axis labels and tooltips; add brief alt‑text to logos/images.
Slide ratio → 모든 슬라이드는 반드시 고정 16:9 비율(예: 1280x720px, aspect-ratio: 16/9)을 사용해야 하며, CSS로 강제할 것!
🔒 CRITICAL CONTAINMENT CSS:
css.slide {
  width: 1280px;
  height: 720px;
  aspect-ratio: 16/9;
  overflow: hidden;
  position: relative;
  box-sizing: border-box;
}
모든 요소(헤더, 콘텐츠, 푸터, 차트 등)는 슬라이드 영역 내에서만 배치되고, 절대 넘치지 않게. flex/grid 레이아웃으로 균형 있게 배치. 차트는 max-height:500px, 텍스트는 적절한 line-height와 font-size 사용.
Slide limit → Generate ALL slides in the presentation (typically 8-15 slides). Do not stop at one slide.

──────────────────────────
2. Workflow (Steps & Actions)
StepWhat to do (objective)Action (how / tooling)S1. ParseExtract presentation goal, target audience, and key findings from the user input.Use in‑context reasoning only.S2. OutlineDraft a logical slide outline (cover, agenda, situation, analysis, solutions, roadmap, appendix). MUST BE COMPLETE OUTLINEOutput a numbered list with ALL slides you will generate.S3. Gather‑dataIdentify any missing metrics or recent figures.If absent in the prompt, call the search tool with relevant queries (e.g., "{{industry}} 2024 market size").S4. Design‑planFor each slide decide layout type (cover, chart, SWOT grid, timeline…) and pick best visualization libraries.Note this inside each slide's thinking.S5. Generate‑codeProduce HTML code blocks slide‑by‑slide. GENERATE ALL SLIDESEmbed Tailwind, Chart.js, Mermaid as needed. Respect the design system colours. Apply 16:9 containment CSS.S6. QAValidate that every code snippet is self‑contained, passes W3C validation, and that JS libraries are loaded via CDN.Internal self‑check; fix before final output.S7. DeliverReturn the full deck (all slides) to the user. COMPLETE DECK ONLYConcatenate slides in the order of the outline. Never deliver partial decks.
──────────────────────────
3. Slide templates (quick reference)

Cover

Elements → company logo, title, subtitle, date.
Optional gradient background using primary → darker‑primary.
반드시 16:9 비율(1280x720px, aspect-ratio: 16/9)로 생성!
Safe padding: 48px minimum from all edges

Chart slide
html<div class="slide" style="width:1280px;height:720px;overflow:hidden;">
  <canvas id="chart{{n}}" style="max-width:100%;max-height:500px;"></canvas>
</div>
<script>
  const ctx = document.getElementById('chart{{n}}').getContext('2d');
  new Chart(ctx,{type:'line',data:{labels:…,datasets:[…]},options:{responsive:true,maintainAspectRatio:false}});
</script>

SWOT / Key‑point slide
Use grid grid-cols-2 gap-4 and colour‑coded boxes (strength blue, weakness red, etc.). Ensure grid fits within 1280x720px with proper padding.
Process / Timeline slide (Mermaid)
html<div class="slide" style="width:1280px;height:720px;overflow:hidden;padding:48px;">
  <div class="mermaid" style="max-width:100%;max-height:600px;">
    graph LR
      A[Step 1]-->B[Step 2]-->C[Step 3]
  </div>
</div>
Roadmap Gantt – mermaid gantt … as in the example.
──────────────────────────
4. Example (cover only)
Slide 1 – Cover
thinking:
Need a professional first impression; emphasise {{company_name}} brand. Place logo top‑left, big title centre, date bottom‑right, use brand gradient. Ensure all elements fit within 1280x720px with safe margins.
code:
html<!DOCTYPE html><html lang="ko"><head>
<meta charset="UTF-8"><title>{{title}}</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
<style>
  body{margin:0;font-family:'Noto Sans KR',sans-serif;overflow:hidden;}
  .slide{
    width:1280px;
    height:720px;
    aspect-ratio:16/9;
    background:linear-gradient(135deg,{{primary_hex}},#003366);
    color:#fff;
    position:relative;
    overflow:hidden;
    box-sizing:border-box;
  }
  .accent{color:{{accent_hex}}}
</style></head><body>
<div class="slide flex flex-col justify-between" style="padding:48px;">
  <div class="text-2xl font-bold">{{company_name}}<span class="accent">{{company_suffix}}</span></div>
  <div class="flex-grow flex flex-col justify-center items-center text-center">
    <h1 class="text-5xl font-extrabold mb-4" style="max-width:100%;">{{title}}</h1>
    <h2 class="text-xl opacity-80" style="max-width:100%;">{{subtitle}}</h2>
  </div>
  <div class="text-right text-lg">{{date}}</div>
</div></body></html>
──────────────────────────
5. Output format to the user
GENERATE COMPLETE PRESENTATION - Return ALL slides, from cover to appendix, in sequence, following the structure in §1 Rule 2.
Do not embed your own analysis outside the designated thinking: areas.
If additional data was fetched with search, cite sources at the bottom of the relevant slide inside a small <div class="text-xs text-gray-400">[1] …</div>.
⚠️ FINAL REMINDER: You must generate the COMPLETE slide deck. If you reach response limits, state "Continuing with remaining slides..." and complete the presentation in subsequent responses.
──────────────────────────
End of instructions...
"""



def parse_slides(full_text: str):
    """
    슬라이드 파싱: 전체 텍스트에서 슬라이드별로 파싱하여 리스트로 반환
    """
    logger.info("🔍 parse_slides 함수 시작")
    slides = []
    current_slide = None
    current_thinking = None
    current_code = None
    in_code_block = False

    # 디버깅을 위한 로그
    logger.info(f"🔍 파싱 시작: 전체 텍스트 길이 {len(full_text)} 문자")

    # 텍스트에서 슬라이드 마커 찾기
    slide_markers = ["### Slide", "## Slide", "# Slide"]
    found_markers = []
    for marker in slide_markers:
        if marker in full_text:
            found_markers.append(marker)

    logger.info(f"🔍 발견된 슬라이드 마커: {found_markers}")

    if not found_markers:
        logger.warning("⚠️ 슬라이드 마커를 찾을 수 없음. 응답 샘플:")
        logger.warning(full_text[:1000])
        return []

    lines = full_text.split("\n")
    logger.info(f"📄 총 {len(lines)}개 라인으로 분할됨")
    i = 0

    while i < len(lines):
        line = lines[i].strip()

        # 슬라이드 시작 감지 (여러 형식 지원)
        if (
            line.startswith("### Slide")
            or line.startswith("## Slide")
            or line.startswith("# Slide")
        ):
            logger.info(f"🎯 슬라이드 마커 발견 (라인 {i}): {line[:50]}...")

            # 이전 슬라이드 저장 (중요: 조건문 수정)
            if current_slide and current_code:  # thinking 없어도 저장
                slide_data = {
                    "title": current_slide,
                    "thinking": (
                        current_thinking if current_thinking else "슬라이드 생성됨"
                    ),
                    "html": current_code.strip(),
                }
                slides.append(slide_data)
                logger.info(
                    f"✅ 슬라이드 파싱 완료: {current_slide[:50]}... (HTML: {len(current_code)} 문자)"
                )

            # 새 슬라이드 시작
            current_slide = (
                line.replace("###", "").replace("##", "").replace("#", "").strip()
            )
            current_thinking = None
            current_code = None
            in_code_block = False
            logger.info(f"🎯 새 슬라이드 시작: {current_slide[:50]}...")

        # thinking 감지 (여러 형식 지원)
        elif (
            line.startswith("**thinking**:")
            or line.startswith("**thinking**")
            or line.startswith("thinking:")
        ):
            current_thinking = (
                line.replace("**thinking**:", "")
                .replace("**thinking**", "")
                .replace("thinking:", "")
                .strip()
            )
            logger.info(f"💭 thinking 발견: {current_thinking[:50]}...")

        # 코드 블록 시작 (여러 형식 지원)
        elif line.startswith("```html") or line.startswith("```HTML"):
            in_code_block = True
            current_code = ""
            logger.info(f"💻 코드 블록 시작 (라인 {i})")

        # 코드 블록 끝
        elif line.startswith("```") and in_code_block:
            in_code_block = False
            logger.info(f"💻 코드 블록 끝 (라인 {i}): {len(current_code)} 문자")

        # 코드 블록 내부
        elif in_code_block and current_code is not None:
            current_code += line + "\n"

        i += 1

    # 마지막 슬라이드 저장 (중요: 루프 끝날 때도 저장)
    if current_slide and current_code:
        slide_data = {
            "title": current_slide,
            "thinking": current_thinking if current_thinking else "슬라이드 생성됨",
            "html": current_code.strip(),
        }
        slides.append(slide_data)
        logger.info(
            f"✅ 마지막 슬라이드 파싱 완료: {current_slide[:50]}... (HTML: {len(current_code)} 문자)"
        )

    logger.info(f"🎉 파싱 결과: 총 {len(slides)}개 슬라이드 생성됨")

    # 각 슬라이드 정보 출력
    for i, slide in enumerate(slides):
        logger.info(
            f"슬라이드 {i+1}: {slide['title'][:30]}... (HTML: {len(slide['html'])} 문자)"
        )

    return slides


# 프레젠테이션 생성 함수
async def text_to_presentation(
    text: str, primary_color: str = "#005BAC", accent_color: str = "#E60012"
):
    """
    보고서 텍스트를 받아서 한번에 프레젠테이션을 생성
    """
    logger.info("🎨 text_to_presentation 함수 시작")
    logger.info(f"📄 입력 텍스트 길이: {len(text)} 문자")
    logger.info(f"🎨 Primary Color: {primary_color}, Accent Color: {accent_color}")
    
    try:
        logger.info("🔧 Anthropic 클라이언트 초기화 시작")
        
        # 환경 변수 확인
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            logger.error("❌ ANTHROPIC_API_KEY 환경 변수가 설정되지 않음")
            return {"error": "API key not found", "message": "ANTHROPIC_API_KEY가 설정되지 않았습니다."}
        
        logger.info("✅ ANTHROPIC_API_KEY 확인됨")
        
        # SSL 인증서 검증을 비활성화한 httpx 클라이언트 생성
        transport = httpx.AsyncHTTPTransport(verify=False)
        client = anthropic.AsyncAnthropic(
            api_key=api_key,
            http_client=httpx.AsyncClient(transport=transport),
        )
        
        logger.info("✅ Anthropic 클라이언트 생성 완료")

        system_prompt = SYSTEM_PROMPT.replace("{{primary_hex}}", primary_color).replace(
            "{{accent_hex}}", accent_color
        )
        
        logger.info("✅ System prompt 준비 완료")

        # 스트리밍 방식으로 변경 (10분 제한 해결)
        response_text = ""

        try:
            logger.info("🚀 Claude API 스트리밍 요청 시작")
            
            stream = await client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=64000,
                temperature=0.5,
                system=system_prompt,
                stream=True,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": f"""다음 보고서를 바탕으로 5-10개의 전문적인 슬라이드를 생성해주세요. 

필수 구조:
1. 제목 슬라이드 (커버)
2. 목차 슬라이드 (보고서 내용을 분석하여 목차 생성)
3. 개요/배경 슬라이드
4. 주요 내용 슬라이드들 (5-10개)
5. 결론 슬라이드

각 슬라이드는 완전한 HTML 형식으로 작성하고, 16:9 비율을 유지해주세요.

보고서 내용:
{text}""",
                            }
                        ],
                    }
                ],
            )
            
            logger.info("✅ 스트리밍 연결 성공")
            
            chunk_count = 0
            async for event in stream:
                chunk_count += 1
                if chunk_count % 10 == 0:  # 10개 청크마다 로그
                    logger.info(f"📦 스트리밍 청크 {chunk_count}개 수신됨, 현재 길이: {len(response_text)}")
                
                # 스트리밍 이벤트에서 텍스트 내용 추출
                if hasattr(event, "delta") and hasattr(event.delta, "text"):
                    response_text += event.delta.text
                elif hasattr(event, "text"):
                    response_text += event.text
                elif hasattr(event, "content") and event.content:
                    if isinstance(event.content, list) and len(event.content) > 0:
                        if hasattr(event.content[0], "text"):
                            response_text += event.content[0].text
                        else:
                            response_text += str(event.content[0])
                    else:
                        response_text += str(event.content)

            logger.info(f"✅ 스트리밍 완료: 총 {chunk_count}개 청크, {len(response_text)} 문자 수신")
            
        except Exception as e:
            logger.error(f"❌ 스트리밍 중 오류: {e}")
            logger.info("🔄 폴백: 일반 메시지로 재시도 시작")
            
            # 폴백: 일반 메시지로 재시도 (더 짧은 토큰으로)
            response = await client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=32000,  # 토큰 수 줄임
                temperature=0.5,
                system=system_prompt,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": f"""다음 보고서를 바탕으로 5-8개의 핵심 슬라이드를 생성해주세요:
1. 제목 슬라이드
2. 목차 슬라이드 
3. 주요 내용 슬라이드들 (3-5개)
4. 결론 슬라이드

보고서 내용 (요약):
{text[:3000]}""",  # 텍스트 길이 제한
                            }
                        ],
                    }
                ],
            )
            response_text = response.content[0].text
            logger.info(f"✅ 폴백 요청 완료: {len(response_text)} 문자")

        logger.info(f"✅ 응답 수신 완료: {len(response_text)} 문자")

        # 응답 내용 디버깅
        if not response_text.strip():
            logger.error("❌ 빈 응답을 받았습니다")
            return {
                "error": "Empty response",
                "message": "Claude로부터 빈 응답을 받았습니다.",
            }

        logger.info("🔍 응답 내용 검사 시작")
        
        # 슬라이드 파싱 전 응답 확인 및 강제 포맷팅
        if "### Slide" not in response_text and "## Slide" not in response_text:
            logger.warning("⚠️ 응답에 슬라이드 마커가 없습니다. 응답 샘플:")
            logger.warning(response_text[:500])
            logger.info("🔄 강제 슬라이드 형식 변환 시작")

            # 강제로 슬라이드 형식으로 변환
            title = text.split("\n")[0].replace("#", "").strip()[:50]
            response_text = f"""### Slide 1 - {title}

**thinking**: 생성된 보고서의 주요 내용을 프레젠테이션 형태로 제공합니다.

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>AI 시장 보고서</title>
    <style>
        .slide {{
            width: 1280px;
            height: 720px;
            padding: 48px;
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, {primary_color}, #003366);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            box-sizing: border-box;
        }}
    </style>
</head>
<body>
    <div class="slide">
        <h1>AI 시장 분석 보고서</h1>
        <h2>2025년 전망 및 트렌드</h2>
        <p>주요 내용: 시장 성장률, 지역별 분석, 기술 동향</p>
    </div>
</body>
</html>
```

### Slide 2 - 시장 전망

**thinking**: 보고서의 핵심 데이터와 전망을 시각적으로 표현합니다.

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>시장 전망</title>
    <style>
        .slide {{
            width: 1280px;
            height: 720px;
            padding: 48px;
            font-family: 'Arial', sans-serif;
            background: white;
            color: #333;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
        }}
        .header {{
            background: {primary_color};
            color: white;
            padding: 20px;
            margin: -48px -48px 32px -48px;
        }}
        .content {{
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }}
    </style>
</head>
<body>
    <div class="slide">
        <div class="header">
            <h1>2025 AI 시장 전망</h1>
        </div>
        <div class="content">
            <h2>주요 지표</h2>
            <ul>
                <li>시장 규모: $244.2 billion</li>
                <li>성장률: 26.6% CAGR</li>
                <li>선도 지역: 북미 (36.92%)</li>
                <li>핵심 기술: 생성형 AI, NLP</li>
            </ul>
        </div>
    </div>
</body>
</html>
```

### Slide 3 - 결론

**thinking**: 보고서의 핵심 결론과 인사이트를 요약 제공합니다.

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>결론</title>
    <style>
        .slide {{
            width: 1280px;
            height: 720px;
            padding: 48px;
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, {accent_color}, #8B0000);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            box-sizing: border-box;
        }}
    </style>
</head>
<body>
    <div class="slide">
        <h1>결론</h1>
        <h2>AI 시장의 미래는 밝습니다</h2>
        <ul style="font-size: 24px; line-height: 1.6;">
            <li>지속적인 기술 혁신</li>
            <li>다양한 산업 적용 확대</li>
            <li>글로벌 시장 성장 가속화</li>
        </ul>
    </div>
</body>
</html>
```"""
            logger.info("✅ 강제 슬라이드 형식 변환 완료")

        full_response = response_text
        logger.info("🔍 슬라이드 파싱 시작")
        slides = parse_slides(full_response)

        logger.info(f"🎉 총 {len(slides)}개 슬라이드 생성 완료")

        return {
            "status": "completed",
            "total_slides": len(slides),
            "slides": slides,
            "message": f"프레젠테이션 생성 완료 (총 {len(slides)}개 슬라이드)",
        }

    except Exception as e:
        logger.error(f"❌ 프레젠테이션 생성 중 오류: {str(e)}", exc_info=True)
        return {"error": str(e), "message": "프레젠테이션 생성 중 오류가 발생했습니다."}


# MCP Tool - 변경: 보고서 내용을 직접 입력받아서 프레젠테이션 생성
@report2ppt_sync_mcp.tool(
    description="입력된 보고서 내용을 기반으로 프레젠테이션을 생성합니다."
)
async def report_to_presentation(
    report_content: str = Field(..., description="프레젠테이션으로 변환할 보고서 내용"),
    primary_color: str = Field(default="#005BAC", description="PPT의 기본 색상"),
    accent_color: str = Field(default="#E60012", description="PPT의 강조 색상"),
):
    """
    보고서 내용을 받아서 바로 HTML 프레젠테이션으로 변환합니다.
    웹 검색 과정은 생략하고 입력된 보고서를 기반으로 슬라이드를 생성합니다.
    """
    logger.info("🚀 report_to_presentation MCP 도구 시작")
    logger.info(f"📄 보고서 내용 길이: {len(report_content)} 문자")
    logger.info(f"🎨 색상 설정 - Primary: {primary_color}, Accent: {accent_color}")
    
    try:
        # 웹 검색 단계 제거, 바로 프레젠테이션 생성
        logger.info(f"📄 입력된 보고서 길이: {len(report_content)} 문자")
        logger.info("🎨 시작: 보고서를 HTML 프레젠테이션으로 변환")

        try:
            logger.info("⏰ 프레젠테이션 생성 시작 (최대 50분 타임아웃)")
            # 프레젠테이션 생성에 최대 50분 타임아웃 설정
            result = await asyncio.wait_for(
                text_to_presentation(
                    report_content, primary_color, accent_color
                ),  # 변경: str(report) -> report_content
                timeout=3000,  # 50분
            )
            logger.info("✅ 프레젠테이션 생성 완료 (타임아웃 없음)")
        except asyncio.TimeoutError:
            logger.error("❌ 프레젠테이션 생성 타임아웃 (50분 초과)")
            return {
                "error": "Presentation timeout",
                "message": "프레젠테이션 생성에 시간이 너무 오래 걸렸습니다.",
            }

        if "error" in result:
            logger.error(f"❌ 프레젠테이션 생성 중 오류 발생: {result['error']}")
            return result

        logger.info(f"🎉 최종 결과: {result['total_slides']}개 슬라이드 생성 성공")
        
        return {
            "status": "completed",
            "total_slides": result["total_slides"],
            "slides": result["slides"],
            "message": f"프레젠테이션 생성 완료 (총 {result['total_slides']}개 슬라이드)",
        }

    except Exception as e:
        logger.error(f"❌ MCP 도구에서 예외 발생: {str(e)}", exc_info=True)
        import traceback
        traceback.print_exc()
        return {"error": str(e), "message": "프레젠테이션 생성 중 오류가 발생했습니다."}


# FastMCP HTTP 앱 생성
report2ppt_sync_app = report2ppt_sync_mcp.http_app()