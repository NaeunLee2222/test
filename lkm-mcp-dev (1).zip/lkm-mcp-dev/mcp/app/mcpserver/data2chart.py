import pandas as pd
import plotly.express as px
import os
from typing import Optional, List, Dict, Any
import datetime
from langchain_core.messages import SystemMessage, HumanMessage
from utils.llm import LLMSingleton
import re
import ast
from fastmcp import FastMCP
import json
from mcpserver.functions.file_handler import FileHandler
file_handler = FileHandler()

llm = LLMSingleton.get_llm()

data2chart_mcp = FastMCP(
    name = "Data2Chart",
    stateless_http = True
)

@data2chart_mcp.tool(description="""여러 전처리된 데이터 파일 정보를 받아서 차트를 생성하고 이를 포함한 하나의 대시보드 HTML을 생성합니다.""")
def generate_chart(preprocessed_chart_data: list) -> Optional[str]:
    try:
        chart_info_list = []
        for chart_data in preprocessed_chart_data:
            if isinstance(chart_data, dict) and "chart_type" in chart_data and "pre_processed_file_path" in chart_data:
                chart_info_list.append({
                    "chart_type": chart_data["chart_type"],
                    "file_path": chart_data["pre_processed_file_path"]
                })
        
        print(f"대시보드 생성 요청: {len(chart_info_list)}개의 그래프")
        
        html_charts = []
        successful_charts = 0
        
        for i, chart_info in enumerate(chart_info_list):
            chart_type = chart_info["chart_type"]
            file_path = chart_info["file_path"]
            print(f"그래프 {i+1} 처리 중: {chart_type} - {file_path}")
            chart_html = generate_chart_for_analysis(file_path, chart_type)
            html_charts.append(chart_html)
            successful_charts += 1
        
        full_html = create_dashboard_html(html_charts)
        saved_file_path = save_dashboard_html(full_html, base_name="dashboard")
        
        return saved_file_path
        
    except Exception as e:
        print(f"대시보드 생성 오류: {str(e)}")
        return None


def load_processed_data(file_path: str) -> pd.DataFrame:
    """데이터 로드 및 기본 전처리"""

    full_file_path = file_handler.get_file_path(file_path)
    if not full_file_path:
        raise ValueError(f"파일을 찾을 수 없습니다: {file_path}")
    
    ext = os.path.splitext(file_path)[-1].lower()
    try:
        if ext == '.csv':

            encodings = ['utf-8', 'euc-kr', 'cp949', 'latin1', 'iso-8859-1']
            df = None
            
            for encoding in encodings:
                try:
                    df = pd.read_csv(full_file_path, encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
                except Exception as e:
                    continue
            
            if df is None:
                raise ValueError("지원되는 인코딩으로 파일을 읽을 수 없습니다.")
                
        elif ext == '.json':
            with open(full_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict) and 'data' in data:
                    df = pd.DataFrame(data['data'])
                elif isinstance(data, list):
                    df = pd.DataFrame(data)
                else:
                    df = pd.DataFrame([{'key': k, 'value': v} for k, v in data.items()])
        else:
            raise ValueError("지원하지 않는 파일 형식입니다. (csv, json만 지원)")
    except Exception as e:
        raise ValueError(f"파일 로드 중 오류 발생: {str(e)}")
    
    df = process_monthly_data(df)

    return df

def process_monthly_data(df):
    """월별 데이터 자동 감지 및 처리 (pd.to_datetime 자동 변환 포함)"""
    for col in df.columns:
        if df[col].dtype == 'object':
            sample_values = df[col].dropna().astype(str)
            if len(sample_values) > 0:

                patterns = [
                    r'^[A-Za-z]{3}\.\d{2}$',  
                    r'^[A-Za-z]{3}-\d{2}$',  
                    r'^[A-Za-z]{3} \d{4}$',  
                    r'^\d{4}-\d{2}$',  
                    r'^\d{2}/\d{4}$' 
                ]
                is_monthly = False
                for pattern in patterns:
                    if sample_values.str.match(pattern).any():
                        is_monthly = True
                        break
                try:
                    dt = pd.to_datetime(df[col], errors='coerce', infer_datetime_format=True)
                    if dt.notnull().sum() > 0:
                        df[col] = dt.dt.strftime('%Y-%m')
                        print(f"컬럼 '{col}'을 pd.to_datetime으로 변환하여 YYYY-MM 형식으로 통일")
                except Exception as e:
                    print(f"pd.to_datetime 변환 실패: {e}")

                if is_monthly:
                    unique_values = sample_values.unique()
                    sorted_values = sorted(unique_values)
                    print(f"정렬된 월별 값: {sorted_values}")
                    df[col] = pd.Categorical(df[col], categories=sorted_values, ordered=True)
                    print(f"컬럼 '{col}'을 범주형으로 변환 완료")
                    print(f"변환 후 타입: {df[col].dtype}")
                    print(f"카테고리: {df[col].cat.categories.tolist()}")
    return df

def create_dashboard_html(html_charts: List[str]) -> str:
    """대시보드 HTML 템플릿 생성"""
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Data Dashboard</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script> <!-- todo: 정적 파일 변경 필요 -->
        <style>
            body {{ 
                font-family: 'Segoe UI', Arial, sans-serif; 
                margin: 0; 
                padding: 20px; 
                background-color: #f8f9fa;
                overflow-x: hidden;
            }}
            .container {{ 
                max-width: 100%; 
                margin: 0 auto; 
                background: white; 
                border-radius: 10px; 
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                padding: 30px;
                overflow-x: hidden;
            }}
            .dashboard-title {{
                text-align: center;
                color: #2c3e50;
                margin-bottom: 30px;
                font-size: 28px;
                font-weight: bold;
            }}
            .chart-grid {{
                display: flex;
                flex-direction: column;
                gap: 30px;
                margin-top: 20px;
                width: 100%;
            }}
            .chart-container {{ 
                background: white;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                padding: 20px;
                min-height: 500px;
                width: 100%;
                max-width: 100%;
                overflow-x: auto;
                box-sizing: border-box;
            }}
            .chart-title {{
                text-align: center;
                color: #34495e;
                margin-bottom: 15px;
                font-size: 18px;
                font-weight: 600;
            }}
            /* plotly 차트 반응형 설정 */
            .plotly-graph-div {{
                width: 100% !important;
                max-width: 100% !important;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="dashboard-title">스테인리스강 불량 예측 분석 대시보드</div>
            <div class="chart-grid">
                {''.join(html_charts)}
            </div>
        </div>
    </body>
    </html>
    """

def extract_data_profile(df, n=5):
    """데이터 프로파일 생성 (LLM에게 제공할 정보)"""
    profile = {
        "columns": list(df.columns),
        "dtypes": {col: str(df[col].dtype) for col in df.columns},
        "shape": df.shape,
        "sample_rows": df.head(n).to_dict(orient="records"),
        "null_counts": df.isnull().sum().to_dict(),
        "unique_counts": {col: df[col].nunique() for col in df.columns},
        "numeric_columns": df.select_dtypes(include=['number']).columns.tolist(),
        "categorical_columns": df.select_dtypes(include=['object', 'category']).columns.tolist(),
        "examples": {col: df[col].dropna().unique()[:3].tolist() if df[col].nunique() > 0 else [] for col in df.columns}
    }
    return profile

def validate_and_clean_code(code_response: str) -> str:
    """LLM 응답에서 안전한 코드 추출"""

    code_pattern = r'```(?:python)?\s*(.*?)\s*```'
    match = re.search(code_pattern, code_response, re.DOTALL)
    if match:
        code = match.group(1)
    else:
        code = code_response.strip()
    
    lines = code.split('\n')
    cleaned_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            cleaned_lines.append(line.rstrip())
    
    cleaned_code = '\n'.join(cleaned_lines)
    
    if not cleaned_code.strip():
        raise ValueError("생성된 코드가 비어있습니다.")
    
    # 위험 키워드 검사
    dangerous_patterns = [
        r'\bimport\s+', 
        r'\bfrom\s+',   
        r'\bopen\s*\(',
        r'\beval\s*\(',
        r'\bexec\s*\(',
        r'\bos\.',
        r'\bsubprocess\b',
        r'\bstatsmodels\b', 
        r'\bsklearn\b',     
        r'\bscipy\b',      
        r'\bmatplotlib\b',  
        r'\bseaborn\b'  
    ]
    
    for pattern in dangerous_patterns:
        if re.search(pattern, cleaned_code):
            raise ValueError(f"안전하지 않은 코드 패턴이 감지되었습니다: {pattern}")
    
    try:
        ast.parse(cleaned_code)
    except SyntaxError as e:
        raise ValueError(f"코드 문법 오류: {str(e)}\n문제 코드:\n{cleaned_code}")
    
    return cleaned_code

def save_dashboard_html(full_html: str, base_name: str = "dashboard") -> str:
    """대시보드 HTML 파일 저장"""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{base_name}_{timestamp}.html"
    
    file_handler.save_file(file_name=file_name, content=full_html, file_type="html")
    
    saved_file_path = file_handler.get_dir_path(file_name)
    print(f"대시보드 HTML 파일 저장: {saved_file_path}")
    return saved_file_path

def generate_chart_for_analysis(file_path: str, chart_type: str) -> str:
    try:
        df = load_processed_data(file_path)
        profile = extract_data_profile(df, n=3)
        
        system_prompt = """
        당신은 plotly 전문가입니다. plotly.express를 사용하여 차트를 생성하는 Python 코드를 작성하세요.

        요구사항:
        1. plotly.express (px)와 pandas만 사용하세요
        2. 기존 DataFrame 반드시 'df'를 사용하세요
        3. **import 문을 사용하지 마세요 - pandas와 plotly는 이미 import되어 있습니다**
        4. 'fig'라는 이름의 figure 변수를 생성해야 합니다
        5. **차트에 title을 설정하지 마세요 - 제목은 HTML 템플릿에서 처리됩니다**

        가독성을 생각해서 x축과 y축의 레이블을 적절히 조정하세요.

        ⚠️ 매우 중요한 데이터 처리 규칙:
        - **기존 범주형 데이터는 절대 임의로 A, B, C, D 등으로 변환하지 마세요**
        - **실제 데이터의 원래 범주 값들을 그대로 사용하세요**
        - **pd.cut()으로 임의의 라벨을 만드는 것은 금지합니다**
        - **예: df['slab_grind_category'] = pd.cut(df['slab_grind'], bins=4, labels=['A', 'B', 'C', 'D']) ← 이런 코드 금지**
        - **대신 실제 범주 값들을 그대로 사용: df.groupby('slab_grind')['value'].sum()**


        실행 가능한 Python 코드만 반환하세요.
        **데이터 프레임은 항상 df로 사용하세요**
        """
        
        dtypes_str = json.dumps(profile['dtypes'], indent=2)
        sample_data_str = json.dumps(profile['sample_rows'][:3], indent=2) 
        examples_str = json.dumps(profile['examples'], indent=2)
        
        user_prompt = f"""
        데이터 정보:
        - 형태: {profile['shape']}
        - 컬럼: {profile['columns']}
        - 데이터 타입: {dtypes_str}
        - 숫자 컬럼: {profile['numeric_columns']}
        - 범주형 컬럼: {profile['categorical_columns']}
        - 샘플 데이터: {sample_data_str}
        - 컬럼 예시: {examples_str}

        차트 타입 요청: {chart_type}

        중요사항: 
        - 요청된 차트 타입에 맞는 차트를 생성하세요: {chart_type}
        - **차트에 title 파라미터를 절대 사용하지 마세요 - 제목 중복을 방지하기 위해 HTML에서 처리됩니다**
        - 범주형 x축의 경우 fig.update_xaxes(type='category')를 추가하세요
        - 색상 팔레트를 적절히 선택하세요
        - **범주형 데이터는 실제 값 그대로 사용하세요 (A, B, C, D 등 임의 라벨 금지)**

        plotly 코드를 생성하세요
        """
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt)
        ]
        
        response = llm.invoke(messages)
        print(f"LLM 생성 코드 (차트 타입: {chart_type}, 파일: {file_path}):\n{response.content}")

        cleaned_code = validate_and_clean_code(str(response.content))
        print(f"정리된 코드:\n{cleaned_code}")
        
        safe_globals = {
            'pd': pd,
            'px': px,
            'df': df.copy(),
            'fig': None
        }
        
        try:
            exec(cleaned_code, safe_globals)
        except Exception as e:
            error_msg = str(e)
            print(f"차트 생성 1차 오류: {error_msg}")
            

            retry_prompt = f"""
이전 코드 실행 오류: {error_msg}

수정 사항:
1. import 문을 사용하지 마세요 - pandas와 plotly는 이미 사용 가능합니다
2. plotly.express (px)만 사용하여 차트를 생성하세요
3. **범주형 데이터는 실제 값 그대로 사용하세요 (A, B, C, D 등 임의 라벨 금지)**
4. **그 외의 라이브러리는 사용하지 마세요**
5. **데이터 프레임은 항상 df로 사용하세요**

수정된 코드를 생성하세요:
"""
            messages.append(HumanMessage(content=retry_prompt))
            retry_response = llm.invoke(messages)
            retry_code = validate_and_clean_code(str(retry_response.content))
            print(f"2차 재생성된 코드:\n{retry_code}")
            
            try:
                exec(retry_code, safe_globals)
            except Exception as e2:
                error_msg2 = str(e2)
                print(f"차트 생성 2차 오류: {error_msg2}")
                
                retry_prompt2 = f"""
이전 코드 실행 오류: {error_msg2}

수정 사항:
1. import 문을 사용하지 마세요 - pandas와 plotly는 이미 사용 가능합니다
2. plotly.express (px)만 사용하여 차트를 생성하세요
3. x축 레이블이 많으면 tickmode='array'로 간격 조정하세요
4. **범주형 데이터는 실제 값 그대로 사용하세요 (A, B, C, D 등 임의 라벨 금지)**
5. 더 간단하고 기본적인 차트 코드를 생성하세요
6. **그 외의 라이브러리는 사용하지 마세요**

수정된 코드를 생성하세요:
"""
                messages.append(HumanMessage(content=retry_prompt2))
                retry_response2 = llm.invoke(messages)
                retry_code2 = validate_and_clean_code(str(retry_response2.content))
                print(f"3차 재생성된 코드:\n{retry_code2}")
                
                try:
                    exec(retry_code2, safe_globals)
                except Exception as e3:
                    print(f"차트 생성 3차 오류: {str(e3)}")
                    return f'<div class="chart-container"><div class="chart-title">{chart_type}</div><p>차트 생성 실패: {str(e3)}</p></div>'
        fig = safe_globals.get('fig', None)
        if fig is None:
            return f'<div class="chart-container"><div class="chart-title">{chart_type}</div><p>차트 생성 실패: Figure 객체가 생성되지 않음</p></div>'

        # 차트 레이아웃을 반응형으로 설정
        fig.update_layout(
            autosize=True,
            margin=dict(l=50, r=50, t=50, b=50),
            template="plotly_white"
        )
        
        html_code = fig.to_html(
            include_plotlyjs='cdn', 
            full_html=False,
            config={'responsive': True, 'displayModeBar': True, 'modeBarButtonsToRemove': ['pan2d', 'lasso2d']}
        )

        chart_html = f'<div class="chart-container"><div class="chart-title">{chart_type}</div>{html_code}</div>'
        return chart_html
    except Exception as e:
        print(f"차트 생성 오류 (차트 타입: {chart_type}, 파일: {file_path}): {str(e)}")
        return f'<div class="chart-container"><div class="chart-title">{chart_type}</div><p>차트 생성 실패</p></div>'


# MCP 앱 생성
data2chart_app = data2chart_mcp.http_app()