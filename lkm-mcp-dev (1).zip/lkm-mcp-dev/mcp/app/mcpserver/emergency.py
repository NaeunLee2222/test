from utils.llm import LLMSingleton
import json
import re
import os
import random
from pydantic import BaseModel, Field
from langchain_core.messages import SystemMessage, HumanMessage
from fastmcp import FastMCP
from markitdown import MarkItDown
from mcpserver.functions.file_handler import FileHandler
# from mcpserver.functions.saver import save_json
from utils.state_loader import StateLoader
import csv
import uuid
from typing import Any

file_handler = FileHandler()
llm = LLMSingleton.get_llm()
state_loader = StateLoader()

emergency_mcp = FastMCP(
    name = "EmergencyServer",
    stateless_http = True
)

class GetEmergencyMsgInput(BaseModel):
    position: str = Field(
        ..., description="긴급 메시지를 받을 직책/직무명 (예: Chamber System 현장운전원)"
    )
    hr_csv_path: str = Field(
        ..., description="searchrdb에서 반환된 직원 정보 CSV 파일 경로"
    )
    disaster_type: str = Field(
        default="", description="재난 유형"
    )

@emergency_mcp.tool(
    description="특정 직책의 직원들을 위한 개인 맞춤형 비상 대응 메시지를 생성합니다."
)

def generate_msg(input: GetEmergencyMsgInput) -> dict:
    """실제 긴급 메시지 생성 로직"""
    
    def preserve_formatting(text):
        normalized = re.sub(r"\s+", " ", text)
        normalized = normalized.strip()
        return normalized

    def remove_indexing(text):
        return re.sub(r"(^|\s+)(\d+\.|\d+\))\s+", " ", text).strip()

    try:
        # hr_csv_path에서 직원 정보와 manual_file_path(.docx) 경로 추출
        hr_csv_actual_path = file_handler.get_file_path(input.hr_csv_path)
        if not hr_csv_actual_path:
            raise Exception(f"직원 CSV 파일 경로를 찾을 수 없습니다: {input.hr_csv_path}")

        hr_data = []
        with open(hr_csv_actual_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                hr_data.append(row)
        if not hr_data:
            raise Exception(f"CSV에서 직원 데이터를 찾을 수 없습니다: {hr_csv_actual_path}")

        # 디버깅: CSV 구조 확인
        print(f"=== CSV 디버깅 정보 ===")
        print(f"총 {len(hr_data)}명의 직원 데이터")
        print(f"CSV 컬럼들: {list(hr_data[0].keys()) if hr_data else 'No data'}")
        if hr_data:
            print(f"첫 번째 직원 데이터: {hr_data[0]}")

        # msg_dict 초기화 (기본값 설정)
        msg_dict = {
            "disaster_type": input.disaster_type or "비상상황이 발생했습니다.",
            "msg_team": {"roles": []},
            "report_flow": "보고 체계 정보 없음"
        }
        file_name = "매뉴얼"

        employee_messages = []
        skipped_reasons = []  # 건너뛴 이유 추적
        processed_count = 0
        
        for i, employee in enumerate(hr_data):
            name = employee.get("name", "").strip()
            position_emp = employee.get("position", input.position).strip()
            webhook_url = employee.get("webhook_url", "").strip()
            email = employee.get("email", "").strip()
            manual_file_path = employee.get("manual_file_path", "").strip()
            site = employee.get("site", "").strip()
            
            print(f"\n--- 직원 {i+1}: {name} ---")
            print(f"name: '{name}' (길이: {len(name)})")
            print(f"position: '{position_emp}'")
            print(f"manual_file_path: '{manual_file_path}'")
            print(f"site: '{site}'")
            
            # 각 조건을 개별적으로 체크
            if not name:
                reason = f"이름이 비어있음: '{name}'"
                print(f"{reason}")
                skipped_reasons.append(f"직원{i+1}: {reason}")
                continue
                
            if not manual_file_path:
                reason = f"매뉴얼 파일 경로가 비어있음: '{manual_file_path}'"
                print(f"{reason}")
                skipped_reasons.append(f"직원{i+1}({name}): {reason}")
                continue
                
            file_exists = os.path.exists(manual_file_path)
            print(f"파일 존재 여부: {file_exists}")
            if not file_exists:
                reason = f"매뉴얼 파일이 존재하지 않음: {manual_file_path}"
                print(f"{reason}")
                skipped_reasons.append(f"직원{i+1}({name}): {reason}")
                continue
            
            print(f"모든 조건 만족 - 처리 시작")

            try:
                # 매뉴얼 문서 읽기 (직원별로 다를 수 있음)
                md = MarkItDown()
                file_result = md.convert(manual_file_path)
                file_content = file_result.markdown
                file_lines = file_content.splitlines()
                normalized_lines = []
                for line in file_lines:
                    clean_line = remove_indexing(preserve_formatting(line))
                    normalized_lines.append(clean_line)
                document = "\n".join(normalized_lines)
                file_name = os.path.basename(manual_file_path)

                # 첫 번째 직원일 때만 팀별 조치사항 추출 (모든 직원이 같은 매뉴얼을 사용한다고 가정)
                if processed_count == 0:
                    print("팀별 조치사항 추출 중...")
                    msg_team = get_team_actions(document)
                    try:
                        temp_msg_dict = json.loads(msg_team)
                        msg_dict.update(temp_msg_dict)
                        # 재난 유형 설정 (입력값 우선, 없으면 문서에서 추출된 값 사용)
                        if input.disaster_type:
                            msg_dict["disaster_type"] = input.disaster_type
                        print("팀별 조치사항 추출 완료")
                    except json.JSONDecodeError as e:
                        print(f"JSON 파싱 오류: {e}")
                        # 기본값 유지
                        pass

                print("개인별 조치사항 추출 중...")
                msg_personal = get_personal_actions(document, file_name, name, position_emp, site)

                # 개별 메시지 데이터 구성
                personal_msg_dict = msg_dict.copy()
                personal_msg_dict["msg_personal"] = msg_personal
                personal_msg_dict["file_name"] = file_name
                personal_msg_dict["target_position"] = input.position
                personal_msg_dict["site"] = site
                personal_msg_dict["employee_info"] = {
                    "name": name,
                    "position": position_emp,
                    "webhook_url": webhook_url,
                    "email": email,
                    "site": site,
                }
                personal_msg_dict["target_email"] = email
                personal_msg_dict["target_webhook_url"] = webhook_url

                output_filename = f"emergency_msg_{name}_{position_emp.replace(' ', '_')}_{random.randint(1,9999)}.json"
                output_path = file_handler.get_dir_path(output_filename)
                file_handler.save_file(file_name=output_filename, content=personal_msg_dict, file_type="json")

                chat_text = format_emergency_message_for_chat(personal_msg_dict, name, position_emp, site)

                employee_messages.append({
                    "name": name,
                    "position": position_emp,
                    "output_path": str(output_path),
                    "chat_text": chat_text,
                    "webhook_url": webhook_url,
                    "email": email,
                    "site": site,
                })
                
                processed_count += 1
                print(f"직원 {name} 처리 완료")
                
            except Exception as e:
                reason = f"처리 중 오류: {str(e)}"
                print(f"{reason}")
                skipped_reasons.append(f"직원{i+1}({name}): {reason}")
                import traceback
                print(f"상세 오류: {traceback.format_exc()}")
                continue

        # 디버깅 요약 출력
        print(f"\n=== 처리 결과 요약 ===")
        print(f"총 직원 수: {len(hr_data)}")
        print(f"처리된 직원 수: {len(employee_messages)}")
        print(f"건너뛴 직원 수: {len(skipped_reasons)}")
        if skipped_reasons:
            print("건너뛴 이유들:")
            for reason in skipped_reasons:
                print(f"  - {reason}")

        if processed_count == 0:
            return {
                "success": False,
                "error": "처리할 수 있는 직원이 없습니다.",
                "message": "CSV 파일의 모든 직원이 필수 조건(이름, 매뉴얼 파일)을 만족하지 않습니다.",
                "debug_info": {
                    "total_employees": len(hr_data),
                    "processed_employees": len(employee_messages),
                    "skipped_reasons": skipped_reasons,
                    "hr_data_sample": hr_data[:3] if hr_data else []
                }
            }

        return {
            "success": True,
            "message": f"{input.position} 직책 {len(employee_messages)}명의 긴급 메시지가 생성되었습니다.",
            "target_position": input.position,
            "site": site,
            "employee_count": len(employee_messages),
            "employee_messages": employee_messages,
            "disaster_type": msg_dict.get("disaster_type"),
            "manual_file": file_name,
            "debug_info": {
                "total_employees": len(hr_data),
                "processed_employees": len(employee_messages),
                "skipped_reasons": skipped_reasons
            }
        }
    except Exception as e:
        import traceback
        return {
            "success": False,
            "error": str(e),
            "message": f"에러 발생: {str(e)}",
            "traceback": traceback.format_exc()
        }


def format_emergency_message_for_chat(msg_dict, name, position, site):
    """비상 메시지를 채팅 인터페이스용 텍스트로 포맷팅"""

    # NaN, None, '', 'nan' 등 비정상 값이 들어올 경우를 방지
    def safe_value(val, default="(정보 없음)"):
        if val is None:
            return default
        if isinstance(val, float) and (val != val):  # NaN 체크
            return default
        if isinstance(val, str) and (val.strip().lower() == "nan" or val.strip() == ""):
            return default
        return val

    
    disaster_type = safe_value(msg_dict.get("disaster_type"), "비상상황")
    roles = msg_dict.get("msg_team", {}).get("roles", [])
    report_flow = safe_value(msg_dict.get("report_flow"), "보고 체계 정보 없음")
    msg_personal = safe_value(msg_dict.get("msg_personal"), "개인별 조치 없음")
    file_name = safe_value(msg_dict.get("file_name"), "문서명 없음")

    # 긴급 대응 요청 메시지를 깔끔하게 포맷 (슬랙 스타일 이모지, 구분선, 들여쓰기 등)
    chat_text = "🚨 **긴급 대응 요청**\n"
    chat_text += f"{disaster_type}이 발생했습니다.\n"
    chat_text += "모든 담당자는 아래 연락과 조치 내용을 확인하고 즉시 대응해 주시기 바랍니다.\n\n"

    # 버튼 스타일 안내 (실제 버튼은 아니지만 시각적으로 구분)
    chat_text += "✅ 상황 접수 완료    🆘 긴급 지원 요청\n\n"

    # 보고 및 연락 체계
    # 보고 및 연락 체계를 한 줄로, 화살표로 이어지게 출력
    chat_text += "📞 *보고 및 연락 체계*\n"
    if isinstance(report_flow, str):
        # 여러 줄이 들어올 경우 첫 줄만 사용 (필요시 조정)
        report_line = str(report_flow).strip().splitlines()[0]
        # 불필요한 공백 제거 및 연속된 화살표 정리
        steps = [str(safe_value(step)).strip() for step in report_line.split("→")]
        joined_steps = " → ".join(steps)
        chat_text += f"{joined_steps}\n"
    else:
        chat_text += f"{str(safe_value(report_flow))}\n"
    chat_text += "\n"

    # 참고문서
    chat_text += f"📋 *참고문서*\n{file_name}\n\n"

    # 조직별 대응 체계
    chat_text += "🏢 *조직별 대응 체계*\n"
    if roles and isinstance(roles, list):
        for role in roles:
            role_name = safe_value(role.get("role_name"), "역할명 없음")
            chat_text += f"\n*{role_name}*\n"
            actions = role.get("actions", [])
            if actions and isinstance(actions, list):
                for action in actions:
                    chat_text += f"　- {safe_value(action, '조치 없음')}\n"
            else:
                chat_text += "　- 조치 없음\n"
    else:
        chat_text += "　• 조직별 역할 정보 없음\n"
    chat_text += "\n\n"

    # 개인별 조치
    chat_text += f"🙋‍♂️ *개인별 조치*\n{str(msg_personal).strip()}\n"

    return chat_text


def get_team_actions(markdown_text) -> str:
    """재난상황 발생 시 각 직급별 책임과 대응 조치를 추출하는 함수"""

    system_prompt = """
    당신은 산업 안전 매뉴얼과 비상 대응 지침서를 분석하는 전문가입니다.

    입력으로 주어지는 텍스트는 재난 발생 시의 비상 대응 매뉴얼이며, Markdown 형식으로 제공됩니다.  
    당신의 목표는 이 문서를 기반으로 **JSON 형태**의 역할별 조치 요약을 생성하는 것입니다.

    다음의 지침을 따르세요:

    1. 문서에서 등장하는 **각 직책 또는 역할명**을 식별하세요.
    - '담당자', '작업자', '인원' 등의 모호한 표현은 문맥을 통해 구체적인 직책으로 판단하여 명확히 정리하세요.
    - 예시: _현장운전원_, _장치운전원_, _총괄 관리자_, _지원 팀장_

    2. 각 역할별로 **재난 발생 시 수행해야 할 핵심 조치**를 3~4개 추출하세요.
    - 반드시 문서 내 실제 지시/행동 문장을 근거로 작성합니다.
    - 다음은 포함하지 마세요:
        - 평상시 훈련, 교육, 점검 등 사전 예방 활동
        - 선언적 원칙, 추상적 문장
        - 담당자 입장에서 실제 판단이나 실행이 어려운 추상적 책임

    3. 각 조치는 다음 형식을 따르세요:
    - 문장 하나에 상황과 조치를 담고, 가능한 한 짧고 명확하게 작성하세요.
    - 서론 없이 **즉시 실행 가능한 행동 지시문** 형태로 구성하세요.
    - 가장 중요한 조치부터 나열하세요.
    - 예시:
        - _재난 감지 시 즉시 현장 작업을 중단하고 상황실에 보고._
        - _설비 이상 발생 시 인근 지역 대피 유도 후 전원 차단을 수행._

    4. 문서에서 **보고 및 지휘 체계(보고 흐름)**를 파악해 정리하세요.
    - 명시적 표현을 찾으세요: "A는 B에게 보고한다", "지시를 받는다", "상황을 전달한다", "연락한다", "통보한다" 등
    - 간접 표현도 포함하세요: 상황을 지휘, 통보, 연락, 승인, 전파, 지시, 협조 등의 관계 구조를 추론
    - 문서 내 모든 부서와 직책 간의 상하관계, 보고체계, 의사결정 흐름을 파악하세요
    - 비상상황 발생 시 최초 발견자부터 최종 의사결정자까지의 정보 전달 경로를 추적하세요
    - 각 단계별 책임자와 그들 간의 커뮤니케이션 방식(유선, 무선, 대면 등)도 파악 가능하면 포함하세요
    - 전체적으로 일관된 흐름을 Slack 메시지 **마지막에 한 줄로 요약**하세요.
    - 예시: 최초 발견자 → 현장 작업자 → 팀원 → 현장 책임자 → 운영팀장 → 본부장 → 대표이사

    5. 재난 유형은 문서 내용을 분석하여 경고 메시지 형태로 작성하세요.
    - 단순한 명사형(예: "재난", "홍수")이 아닌 경고 메시지 형태로 작성합니다.
    - 예시: "재난이 발생했습니다.", "화재가 발생했습니다.", "유해물질이 누출되었습니다."

    6. 결과 출력 형식은 아래와 같이 구성하세요.  
    **Slack Webhook 메시지에 바로 붙일 수 있도록**, 시각적으로 명확한 형식으로 작성합니다.
    - 볼드체는 사용하지 말고, *이탤릭체* 또는 _밑줄_ 정도만 사용하세요.
    - 각 역할 구간은 줄바꿈으로 구분하세요.
    - 각 항목은 마침표(.) 없이 끝맺으세요

    출력 예시:
    {
        "disaster_type": "화재가 발생했습니다.",
        "msg_team": {
            "roles": [
                {
                    "role_name": "역할명",
                    "actions": [
                        "주요 조치 1",
                        "주요 조치 2", 
                        "주요 조치 3"
                    ]
                },
                {
                    "role_name": "역할명",
                    "actions": [
                        "주요 조치 1",
                        "주요 조치 2",
                        "주요 조치 3"
                    ]
                }
            ]
        },
        "report_flow": "역할 A → 역할 B → 역할 C"
    }

    중요: 응답은 반드시 JSON 형식으로만 제공하고, 코드 블록(```json ```)으로 묶지 마세요. 순수한 JSON 텍스트만 반환해야 합니다.
    """

    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=markdown_text),
    ]
    response = llm.invoke(messages)

    # TextContent 객체를 문자열로 변환
    if hasattr(response, 'content'):
        return str(response.content).strip()
    else:
        return str(response).strip()


def get_personal_actions(markdown_text, file_name, name, position, site) -> str:
    """재난상황 발생 시 개인별 대응 조치를 추출하는 함수"""

    system_prompt = """
    당신은 산업 안전 비상 대응 매뉴얼을 기반으로, Slack 메시지에 포함될 개인 맞춤형 조치 메시지를 생성하는 전문가입니다.

    입력으로는 다음 정보가 제공됩니다:
    - 이름 
    - 직무 및 담당 설비
    - 문서 내 해당 직무 또는 설비와 관련된 비상 시나리오 또는 지침 내용

    당신의 목표는, **설비 관련 즉시 대응 조치**와 **중요 보고 조치**를 중심으로 구성된 Slack용 메시지를 생성하는 것입니다.

    중요: 입력된 문서에서 직접적으로 관련 있는 내용만 추출하세요. 매뉴얼에 명시되지 않은 조치를 임의로 생성하지 마세요. 관련 지침이 없을 경우 '매뉴얼에 구체적인 지침이 없습니다'라고 명시하세요.

    ---

    **출력 지침은 다음과 같습니다:**

    1. 다음 형식을 반드시 따르세요:

    ⚠️ *이름 님(직무 및 담당설비)의 즉시 대응 조치*

    1. 조치 제목
    간단한 설명
    
    2. 조치 제목
    간단한 설명
    ...

    모든 조치는 비상 상황 대응 문서에 기반한 실제 조치입니다.

    2. 각 항목은 다음 기준을 충족해야 합니다:
    - **실제 지시/행동**에 기반한 내용만 포함합니다. 추상적 역할은 제외합니다.
    - 각 조치 항목은 **간결한 제목 + 한 줄 설명** 형식을 유지합니다.
    - Slack 수신자가 한눈에 보고 **즉시 이해하고 실행할 수 있어야** 합니다.
    - 조치는 우선순위에 따라 정렬하세요. 설비 관련 조치가 최우선입니다. 특히 실제 설비 작동과 직접 관련된 조치를 먼저 나열하세요.

    3. 특정 설비나 부품명 등은 입력으로 주어진 문서에서 추출된 경우에만 포함하세요. 

    4. 매뉴얼의 전체 맥락을 고려하되, 해당 직무/설비와 가장 직접적으로 관련된 조치만 추출하세요.

    ---

    - **Slack Webhook 메시지에 바로 붙일 수 있도록**, 시각적으로 명확한 형식으로 작성합니다.
    - 이탤릭체는 타이틀의 *이름 님(직무 및 담당설비)의 즉시 대응 조치* 형식에만 적용하세요.
    - 각 조치는 실행 가능한 구체적 행동을 명사형으로 표현하고, 마침표(.) 없이 끝맺으세요.
    - 추가 설명이나 불필요한 서문 없이 바로 조치 목록을 시작하세요.
    - 조치 내용에는 절대 이탤릭체나 밑줄 등의 형식을 적용하지 마세요.
    - 교육, 훈련 관련 내용은 포함하지 마세요. 이 메시지는 실제 비상 상황에서 전달되는 것입니다.

    마지막으로, 모든 조치 목록 아래에 다음 문구를 추가하세요:
    "_더 자세한 지침은 {file_name}을 참고하시기 바랍니다._"
    """

    user_prompt = f"""
    다음은 재난 대응 매뉴얼의 마크다운 형식입니다. 

    이 중, 이름: {name}, 직무 및 담당 설비: {position}, 근무지: {site}에 해당하는 사람이 **재난 발생 시 수행해야 할 즉시 대응 조치**를 정리해 주세요.

    직무 또는 설비명과 정확히 일치하지 않더라도, 비슷한 역할이나 관련 설비가 언급된 지침도 고려하세요.
    하지만 명확히 관련되지 않은 내용은 포함하지 마세요.

    문서 내 관련 지침이 있다면 그에 근거해 조치 목록을 생성하세요.
    지침이 충분하지 않을 경우, 해당 직무에 가장 적합한 일반적인 재난 대응 조치를 최소한으로만 포함하세요.

    우선순위는 다음과 같이 정렬하세요:
    1. 설비 작동 및 제어와 직접 관련된 조치
    2. 설비 안전 확보와 관련된 조치
    3. 기타 대응 조치

    중요: 교육, 훈련 관련 내용은 포함하지 마세요. 이 메시지는 실제 비상 상황에서 전달되는 것입니다.

    --- 매뉴얼 시작 ---
    {markdown_text}
    --- 매뉴얼 끝 ---
    
    파일명: {file_name}
    """

    messages = [SystemMessage(content=system_prompt), HumanMessage(content=user_prompt)]
    response = llm.invoke(messages)

    # TextContent 객체를 문자열로 변환
    if hasattr(response, 'content'):
        return str(response.content).strip()
    else:
        return str(response).strip()


emergency_app = emergency_mcp.http_app()