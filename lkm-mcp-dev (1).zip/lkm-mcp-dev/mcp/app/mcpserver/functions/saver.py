import os
import json
from typing import Any



def create_diff_dict(
    file_paths: list[str],
    sentences: list[str],
    p_tags: list[str],
    highlight_colors: list[str],
) -> dict[str]:

    diff_dict = {}
    diff_dict["names"] = file_paths
    diff_dict["sentences"] = sentences
    diff_dict["p_tags"] = p_tags
    diff_dict["highlight_colors"] = highlight_colors
    return diff_dict


# compare_htmls, compare_similar_docs, convert_markdown, get_emergency_msg 관련
def save_json(save_dir: str, file_name: str, save_data: Any) -> str:
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    save_path = os.path.join(save_dir, file_name)


    try:
        with open(save_path, "w", encoding="utf-8") as f:
            # json.dump: Python 객체를 JSON으로 직렬화하여 파일에 바로 저장
            # ensure_ascii=False: 한글 등 비ASCII 문자 그대로 저장
            # indent=4: 들여쓰기 4칸으로 가독성 좋게 저장
            json.dump(save_data, f, ensure_ascii=False, indent=4)

            # 아래는 f.write를 사용한 동등한 방법입니다:
            # json_str = json.dumps(save_data, ensure_ascii=False, indent=4)
            # f.write(json_str)
    except Exception as e:
        print(f"파일 저장 중 오류 발생: {e}")

    return str(save_path)


# merge_htmls, html_higlighter, metadata_update 관련

def save_html(
    save_dir: str, file_name: str, save_data: Any, full_path: str = None
) -> str:


    if full_path:
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        save_path = full_path

    else:
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        save_path = os.path.join(save_dir, file_name)

    try:

        with open(save_path, "w", encoding="utf-8") as f_out:
            f_out.write(save_data)

    except Exception as e:
        print(f"파일 저장 중 오류 발생: {e}")

    return str(save_path)

