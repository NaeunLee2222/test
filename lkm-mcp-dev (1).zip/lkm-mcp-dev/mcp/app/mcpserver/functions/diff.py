import json
from langchain_core.messages import SystemMessage, HumanMessage
import difflib
from utils.llm import LLMSingleton

llm = LLMSingleton.get_llm()

def call_llm_diff(text, user_prompt, system_prompt=None):

    if system_prompt is None:
            messages = [HumanMessage(content=user_prompt.format(text=text))]
    else:
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt.format(text=text))
        ]
    
    response = llm.invoke(messages)

    # 응답이 None인 경우 처리
    if response is None or not response.content or response.content.isspace():
        print("Warning: Empty, None, or whitespace response from LLM")
        return "{\"similar_pairs\": []}"
        
    # JSON 파싱 시도 전 응답 정제
    try:
        # 응답에서 JSON 부분만 추출 시도
        content = response.content.strip()
        json_start = content.find("{")
        json_end = content.rfind("}") + 1
        
        if json_start >= 0 and json_end > json_start:
            json_str = content[json_start:json_end]
            # JSON 파싱 테스트
            json.loads(json_str)
            return json_str
        else:
            print("Warning: No valid JSON found in response")
            return "{\"similar_pairs\": []}"
            
    except Exception as e:
        print(f"Warning: Error processing LLM response - {str(e)}")
        return "{\"similar_pairs\": []}"

def compare_sections_with_difflib(base_sections: list[dict[str, str]], comparative_sections: list[dict[str, str]]) -> dict[str, dict[str, list[str]]]:

        comparison_results = {}

        # 기준 문서와 비교 문서 간 목차가 동일해야 함.
        for section_idx in range(len(base_sections)):
            if section_idx >= len(comparative_sections):
                break
                
            section = base_sections[section_idx]["title"]
            baseline_content = base_sections[section_idx]["content"]
            target_content = comparative_sections[section_idx]["content"]

            comparison_results[section] = {
                "removed_lines": [],
                "added_lines": [],
                "unchanged_lines": [],
                "removed_indices": [],
                "added_indices": [],
                "unchanged_indices": []
            }

            # 둘 다 비어있으면 비교 생략
            if not baseline_content and not target_content:
                continue

            if type(baseline_content) == str:
                baseline_lines = baseline_content.splitlines()
            else:
                baseline_lines = baseline_content

            if type(target_content) == str:
                target_lines = target_content.splitlines()
            else:
                target_lines = target_content

            # ref를 기준으로 difflib으로 줄 단위 비교
            diff_ref = list(difflib.ndiff(baseline_lines, target_lines))
            # target을 기준으로 difflib으로 줄 단위 비교
            diff_reverse = list(difflib.ndiff(target_lines, baseline_lines))

            # diff 결과 처리
            baseline_idx = 0
            for line in diff_ref:
                if line.startswith('- '):
                    # '- ' 접두사 제거 후 저장 (삭제된 라인)
                    comparison_results[section]["removed_lines"].append(line[2:])
                    comparison_results[section]["removed_indices"].append(baseline_idx)
                    baseline_idx += 1
                # ref를 기준으로 unchanged indexing
                elif line.startswith('  '):
                    # '  ' 접두사 제거 후 저장 (변경 없음)
                    comparison_results[section]["unchanged_lines"].append(line[2:])
                    comparison_results[section]["unchanged_indices"].append(baseline_idx)
                    baseline_idx += 1
            
            target_idx = 0
            for line in diff_reverse:
                if line.startswith('- '):
                    # '- ' 접두사 제거 후 저장 (삭제된 라인)
                    comparison_results[section]["added_lines"].append(line[2:])
                    comparison_results[section]["added_indices"].append(target_idx)
                    target_idx += 1
                elif line.startswith('  '):
                    target_idx += 1

        return comparison_results

    
def compare_semantic_similarity_with_llm(removed_lines, added_lines):

    if not removed_lines or not added_lines:
        return {"similar_pairs": []}

    # 취소선(~~)이 포함된 라인은 비교에서 제외 (원본 인덱스는 따로 저장)
    filtered_removed_lines = []
    filtered_added_lines = []
    removed_indices_map = {}  # 필터링된 인덱스 → 원본 인덱스
    added_indices_map = {}    # 필터링된 인덱스 → 원본 인덱스

    for i, line in enumerate(removed_lines):
        if "~~" not in line:
            filtered_removed_lines.append(line)
            removed_indices_map[len(filtered_removed_lines) - 1] = i

    for i, line in enumerate(added_lines):
        if "~~" not in line:
            filtered_added_lines.append(line)
            added_indices_map[len(filtered_added_lines) - 1] = i

    # 필터링 후 둘 중 하나라도 비어있으면 매칭 없음
    if not filtered_removed_lines or not filtered_added_lines:
        return {"similar_pairs": []}

    semantic_similarity_system_prompt = "You are an expert in analyzing text differences and identifying semantic similarities."

    semantic_similarity_user_prompt = f"""
    You are given two lists of text lines: REMOVED LINES (from the baseline) and ADDED LINES (from the target).
    Your task is to find pairs of lines (one from each list) that are semantically identical, even if their wording, phrasing, or formatting is different.

    STRICT MATCHING GUIDELINES (read carefully!):

    1. Do NOT match any pair if either line is empty or consists only of whitespace. Ignore such pairs completely.
    2. Only consider lines as semantically identical if they convey exactly the same information, with absolutely no difference in numbers, dates, quantities, or any specific values.
    3. If two lines are about the same topic but have different numbers, dates, or values (even if the difference is very small, e.g., "2.7" vs "2.8"), they are NOT semantically identical. Do NOT match them.
    - For example, "| ESS-82110 | 2.7 | Painting |" and "| ESS-82110 | 2.8 | Painting |" are NOT semantically identical and must NOT be matched, because the numbers are different.
    4. If two lines differ only in formatting (e.g., bold, font), but the content and ALL values (including numbers, dates, quantities) are the same, you may match them.
    5. If two lines have the same core meaning but differ only in singular/plural forms (e.g., "item" vs "items") or contain minor grammatical errors, you may consider them semantically identical and match them, BUT ONLY IF all numbers, dates, and values are exactly the same.
    6. Do NOT match lines if one is empty and the other is not, even if the non-empty line is similar to other lines.
    7. Do NOT match lines that are only partially similar or have missing/extra information. 
    - IMPORTANT: If a line in the baseline (REMOVED LINES) contains a reference, attachment, requirement, or any specific information (such as a document number, attachment number, referenced standard, or any other detail), and the corresponding line in the target (ADDED LINES) omits or lacks that information, these lines are NOT semantically identical. 
    - For example, "Standard Specification and Drawings listed in Attachment #4 and #5" and "Standard Specification and Drawings listed in Attachment #4" are NOT semantically identical, because the reference to "#5" is missing in the target line. Any omission of referenced documents, attachments, or requirements is a significant difference and must NOT be matched.
    8. Only include pairs that are truly semantically equivalent in all details, including numbers and values, except for minor grammatical differences or singular/plural forms as described above.
    9. PAY SPECIAL ATTENTION TO CHECKBOXES: If a line contains a checkbox (such as '[X]', '[x]', '[ ]', or similar), you MUST treat the checked/unchecked status as a critical difference. For example, '[X]' and '[ ]' are NOT semantically identical, even if the rest of the line is the same. Do NOT match lines that differ in checkbox status.

    10. IMPORTANT: If two lines refer to the same concept or object using different but equivalent terminology, you should consider them semantically identical as long as all numbers, dates, and values are the same, and as long as all referenced documents, attachments, and requirements are present in both lines. For example, treat "Shell and Tube Heat Exchanger" and "HEAT EXCHANGER (SHELL & TUBE TYPE)" as semantically identical, since they refer to the same equipment type, but only if all referenced details are included in both lines. Use your judgment to recognize equivalent technical terms, synonyms, or paraphrased expressions that clearly refer to the same thing in context, provided all values and referenced information match.

    REMOVED LINES:
    {json.dumps(filtered_removed_lines, ensure_ascii=False)}

    ADDED LINES:
    {json.dumps(filtered_added_lines, ensure_ascii=False)}

    Return your answer as a JSON object in the following format:
    {{
        "similar_pairs": [
            {{"removed_index": 0, "added_index": 2, "explanation": "These lines are semantically identical except for formatting or terminology."}}
        ]
    }}

    - Only include pairs that are truly semantically identical according to the rules above.
    - If no such pairs exist, return "similar_pairs": [].
    - Do NOT include any pair where either line is empty or only whitespace.
    - Do NOT include any pair where numbers, dates, values, referenced documents, attachments, or requirements differ, are missing, or are omitted, even slightly.
    - Emphasize: If numbers, dates, quantities, values, or referenced information (such as attachments, standards, or requirements) are even slightly different or missing, do NOT match the lines. For example, "2.7" vs "2.8" → DO NOT match. "Attachment #4 and #5" vs "Attachment #4" → DO NOT match.
    """

    try:        
        response = call_llm_diff(semantic_similarity_user_prompt, semantic_similarity_system_prompt)
        result = json.loads(response)

        # 필터링된 인덱스를 원본 인덱스로 다시 매핑
        mapped_similar_pairs = []
        for pair in result.get("similar_pairs", []):
            filtered_removed_idx = pair["removed_index"]
            filtered_added_idx = pair["added_index"]

            # 매핑에 존재하는 인덱스만 포함
            if filtered_removed_idx in removed_indices_map and filtered_added_idx in added_indices_map:
                original_removed_idx = removed_indices_map[filtered_removed_idx]
                original_added_idx = added_indices_map[filtered_added_idx]

                mapped_similar_pairs.append({
                    "removed_index": original_removed_idx,
                    "added_index": original_added_idx,
                    "explanation": pair.get("explanation", "Semantically similar content")
                })

        return {"similar_pairs": mapped_similar_pairs}
    except Exception as e:
        print(f"Error in semantic comparison: {e}")
        return {"similar_pairs": []}

def refine_diff_results_with_llm(comparison_results: dict[str, dict[str, list[str]]], baseline_sections: list[dict[str, str]]):

    refined_results = {}

    # 딕셔너리 생성으로 O(1) 시간 복잡도로 접근
    baseline_dict = {cur_section['title']: cur_section['content'] for cur_section in baseline_sections}

    for section, results in comparison_results.items():
        removed_lines = results["removed_lines"]
        added_lines = results["added_lines"]
        unchanged_lines = results["unchanged_lines"]
        removed_indices = results["removed_indices"]
        added_indices = results["added_indices"]
        unchanged_indices = results["unchanged_indices"]

        # 둘 중 하나라도 없으면 LLM 처리 생략
        if not removed_lines or not added_lines:
            refined_results[section] = results
            continue

        # LLM으로 의미적으로 동일한 쌍 찾기
        similar_pairs_result = compare_semantic_similarity_with_llm(removed_lines, added_lines)
        similar_pairs = similar_pairs_result.get("similar_pairs", [])

        # 매칭된 라인 추적용 리스트
        semantic_matches = []

        # 원하는 섹션의 내용 직접 접근
        baseline_content = baseline_dict.get(section, "")
        if type(baseline_content) == str:
            baseline_original_lines = baseline_content.splitlines()
        else:
            baseline_original_lines = baseline_content

        # 처리된 인덱스 집합
        processed_removed_indices = set()
        processed_added_indices = set()

        # removed_lines의 원본 위치 매핑
        removed_line_to_position = {}
        for i, line in enumerate(removed_lines):
            for j, orig_line in enumerate(baseline_original_lines):
                if line == orig_line:
                    removed_line_to_position[i] = j
                    break

        # 의미적 매칭 쌍 처리
        for pair in similar_pairs:
            removed_idx = pair["removed_index"]
            added_idx = pair["added_index"]
            explanation = pair.get("explanation", "Semantically similar content")

            if 0 <= removed_idx < len(removed_lines) and 0 <= added_idx < len(added_lines):
                # 처리된 인덱스 표시
                processed_removed_indices.add(removed_idx)
                processed_added_indices.add(added_idx)

                # 매칭 정보 저장
                semantic_matches.append({
                    "baseline_line": removed_lines[removed_idx],
                    "target_line": added_lines[added_idx],
                    "baseline_index": removed_indices[removed_idx],
                    "target_index": added_indices[added_idx],
                    "explanation": explanation
                })

        # 매칭되지 않은 라인만 남기기
        new_removed_lines = [line for i, line in enumerate(removed_lines) if i not in processed_removed_indices]
        new_removed_indices = [idx for i, idx in enumerate(removed_indices) if i not in processed_removed_indices]
        
        new_added_lines = [line for i, line in enumerate(added_lines) if i not in processed_added_indices]
        new_added_indices = [idx for i, idx in enumerate(added_indices) if i not in processed_added_indices]

        # unchanged_lines에 의미적으로 동일한 라인(기준 라인 기준) 추가
        all_unchanged = unchanged_lines.copy()
        all_unchanged_indices = unchanged_indices.copy()
        
        for pair in similar_pairs:
            removed_idx = pair["removed_index"]
            if 0 <= removed_idx < len(removed_lines):
                all_unchanged.append(removed_lines[removed_idx])
                all_unchanged_indices.append(removed_indices[removed_idx])

        # unchanged_lines를 기준 문서의 원래 순서대로 정렬
        unchanged_position_map = {}
        for i, line in enumerate(all_unchanged):
            for j, orig_line in enumerate(baseline_original_lines):
                if line == orig_line:
                    unchanged_position_map[i] = j
                    break

        sorted_unchanged = [(i, line, all_unchanged_indices[i]) for i, line in enumerate(all_unchanged)]
        sorted_unchanged.sort(key=lambda x: unchanged_position_map.get(x[0], float('inf')))
        new_unchanged_lines = [line for _, line, _ in sorted_unchanged]
        new_unchanged_indices = [idx for _, _, idx in sorted_unchanged]

        # 보정 결과 저장
        refined_results[section] = {
            "removed_lines": new_removed_lines,
            "added_lines": new_added_lines,
            "unchanged_lines": new_unchanged_lines,
            "removed_indices": new_removed_indices,
            "added_indices": new_added_indices,
            "unchanged_indices": new_unchanged_indices,
            "semantic_matches": semantic_matches
        }

    return refined_results

def get_each_section_differences(base_file_sections: list[dict[str, str]], comparative_sections: dict[str, list[dict[str, str]]]):

    comparison_results = {}
    for file_name, file_sections in comparative_sections.items():
        initial_results = compare_sections_with_difflib(base_file_sections, file_sections)
        
        # LLM을 이용해 semantic similarity 결과 보정
        refined_results = refine_diff_results_with_llm(initial_results, base_file_sections)
        
        # 의미론적 매칭 결과 출력(확인용)
        for section, results in refined_results.items():
            if "semantic_matches" in results and results["semantic_matches"]:
                print(f"\n섹션: {section}")
                for i, match in enumerate(results["semantic_matches"], 1):
                    print(f"매칭 {i}:")
                    print(f"  Baseline: {match['baseline_line']} (인덱스: {match['baseline_index']})")
                    print(f"  Target  : {match['target_line']} (인덱스: {match['target_index']})")
                    print(f"  Reason  : {match['explanation']}")
        
        comparison_results[file_name] = refined_results

    return comparison_results
