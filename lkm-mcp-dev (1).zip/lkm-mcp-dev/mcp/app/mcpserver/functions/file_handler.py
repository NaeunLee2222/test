import os 
import json
from typing import Any, List, Optional, Union
from concurrent.futures import ThreadPoolExecutor
import shutil
from dotenv import load_dotenv

load_dotenv()

class FileHandler:
    """
    파일 시스템 작업을 위한 유틸리티 클래스
    
    이 클래스는 파일의 저장, 로드, 편집, 삭제 등의 작업을 제공합니다.
    모든 파일 작업은 지정된 마운트 경로 내에서 수행됩니다.
    
    Attributes:
        mount_path (str): 파일 작업이 수행될 기본 디렉토리 경로
    """
    
    def __init__(self, mount_path: Optional[str] = None):
        """
        FileHandler 인스턴스를 초기화합니다.
        
        Args:
            mount_path (Optional[str]): 파일 작업을 수행할 기본 디렉토리 경로.
                                      None인 경우 기본 경로(/app/shared_data)를 사용합니다.
        """
        self.mount_path = os.getenv("BASE_DIR")
        if mount_path:
            self.mount_path = mount_path
        if not os.path.exists(self.mount_path):
            os.makedirs(self.mount_path, exist_ok=True)
            
    def make_dir(self, dir_name: str):
        """
        지정된 이름의 디렉토리를 생성합니다.
        
        Args:
            dir_name (str): 생성할 디렉토리의 이름
            
        Returns:
            None: 성공 시 None 반환, 실패 시 None 반환
        """
        try:
            os.makedirs(os.path.join(self.mount_path, dir_name), exist_ok=True)
        except Exception as e:
            print(e)
            return None
    def _get_relative_path(self, directory: str):
        """
        지정된 디렉토리의 상대 경로를 반환합니다.
        self.mount_path로 시작하면 그 부분을 제거한 경로를 반환합니다.
        """
        if directory.startswith(self.mount_path):
            rel_path = directory[len(self.mount_path):]
            # 앞에 / 있으면 제거
            if rel_path.startswith(os.sep):
                rel_path = rel_path[1:]
            return rel_path
        else:
            return directory
        
    def get_dir_path(self, dir_name: str):
        """
        디렉토리의 전체 경로를 반환합니다.
        """
        dir_name = self._get_relative_path(dir_name)
        return os.path.join(self.mount_path, dir_name)

    def get_file_path(self, file_name: str)->str:
        """
        파일의 전체 경로를 반환합니다.
        
        Args:
            file_name (str): 파일 이름
            
        Returns:
            str: 파일의 전체 경로, 실패 시 None
        """
        try:    
            file_name = self._get_relative_path(file_name)
            return os.path.join(self.mount_path, file_name)
        except Exception as e:
            raise e
    
    def save_file(self, file_name: str, content: Union[str, bytes, dict], file_type: str = "auto"):
        """
        파일을 저장합니다. 지원하는 형식: doc, docx, xls, xlsx, ppt, pptx, pdf, html, json
        
        Args:
            file_name (str): 저장할 파일의 이름
            content (Union[str, bytes, dict]): 저장할 데이터
            file_type (str): 파일 타입 ("doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf", "html", "json", "csv", "auto")
                           "auto"인 경우 파일 확장자나 content 타입을 기반으로 자동 판단
            
        Returns:
            bool: 성공 시 True, 실패 시 False
            
        Raises:
            ValueError: 지원하지 않는 파일 타입이나 데이터 타입인 경우
        """

        SUPPORTED_FORMATS = {
            "doc": bytes,
            "docx": bytes, 
            "xls": bytes,
            "xlsx": bytes,
            "ppt": bytes,
            "pptx": bytes,
            "pdf": bytes,
            "html": str,
            "csv": str,
            "json": dict,
            "txt": str,
            "md": str
        }
        
        try:
            file_name = self._get_relative_path(file_name)
            file_path = self.get_file_path(file_name)

            if file_type == "auto":
                file_type = file_name.split('.')[-1].lower()  

            if file_type not in SUPPORTED_FORMATS:
                raise ValueError(f"지원하지 않는 파일 형식: {file_type}. 지원 형식: {list(SUPPORTED_FORMATS.keys())}")

            expected_type = SUPPORTED_FORMATS[file_type]
            if not isinstance(content, expected_type):
                raise ValueError(f"{file_type} 파일은 {expected_type.__name__} 타입이 필요합니다.")

            if file_type in ["doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf"]:
                with open(file_path, "wb") as f:
                    f.write(content)
            elif file_type in ["html", "csv", "txt", "md"]:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)
            elif file_type == "json":
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(content, f, ensure_ascii=False, indent=4)
            return True

        except Exception as e:
            print(f"파일 저장 중 오류 발생: {e}")
            return False

        
    def load_binary(self, file_name: str):
        """
        파일에서 바이너리 데이터를 읽어옵니다.
        
        Args:
            file_name (str): 읽을 파일의 이름
            
        Returns:
            bytes: 파일의 바이너리 데이터, 실패 시 None
        """
        try:
            file_name = self._get_relative_path(file_name)
            with open(self.get_file_path(file_name), "rb") as f:
                return f.read()
        except Exception as e:
            print(e)
            return None
        
    def load_text(self, file_name: str):
        """
        파일에서 텍스트 데이터를 UTF-8 인코딩으로 읽어옵니다.
        
        Args:
            file_name (str): 읽을 파일의 이름
            
        Returns:
            str: 파일의 텍스트 내용, 실패 시 None
        """
        try:
            file_name = self._get_relative_path(file_name)
            with open(self.get_file_path(file_name), "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            print(e)
            return None
        
    def load_json(self, file_name: str)->Any:
        """
        파일에서 JSON 데이터를 읽어옵니다.
        
        Args:
            file_name (str): 읽을 JSON 파일의 이름
            
        Returns:
            dict: 파싱된 JSON 데이터, 실패 시 None
        """
        try:
            file_name = self._get_relative_path(file_name)
            with open(self.get_file_path(file_name), "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(e)
            return None
        
    def edit_text(self, file_name: str, content: str):
        """
        기존 텍스트 파일의 내용을 새로운 내용으로 덮어씁니다.
        
        Args:
            file_name (str): 편집할 파일의 이름
            content (str): 새로 저장할 텍스트 내용
            
        Returns:
            None: 성공 시 None 반환, 실패 시 None 반환
        """
        try:
            file_name = self._get_relative_path(file_name)
            with open(self.get_file_path(file_name), "w", encoding="utf-8") as f:
                f.write(content)
        except Exception as e:
            print(e)
            return None
        
    def edit_json(self, file_name: str, content: dict):
        """
        기존 JSON 파일의 내용을 새로운 JSON 데이터로 덮어씁니다.
        
        Args:
            file_name (str): 편집할 JSON 파일의 이름
            content (dict): 새로 저장할 JSON 데이터
            
        Returns:
            None: 성공 시 None 반환, 실패 시 None 반환
        """
        try:
            file_name = self._get_relative_path(file_name)
            with open(self.get_file_path(file_name), "w", encoding="utf-8") as f:
                json.dump(content, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(e)
            return None
    
    def _delete_single_file(self, file_name: str):
        """
        단일 파일 삭제를 위한 내부 헬퍼 메서드입니다.
        
        Args:
            file_name (str): 삭제할 파일의 이름
            
        Returns:
            bool: 삭제 성공 시 True, 실패 시 False
        """
        try:
            file_name = self._get_relative_path(file_name)
            file_path = self.get_file_path(file_name)
            if os.path.exists(file_path):
                os.remove(file_path)
                return True
            else:
                print(f"File {file_name} does not exist")
                return False
        except Exception as e:
            print(f"Error deleting {file_name}: {e}")
            return False
    
    def delete_file(self, file_name: Union[str, List[str]]):
        """
        하나 또는 여러 파일을 병렬 처리로 삭제합니다.
        
        이 메서드는 ThreadPoolExecutor를 사용하여 여러 파일을 동시에 삭제합니다.
        최대 10개의 스레드를 사용하여 병렬 처리를 수행합니다.
        
        Args:
            file_name (Union[str, List[str]]): 삭제할 파일의 이름 또는 파일 이름들의 리스트
            
        Returns:
            None: 성공 시 None 반환, 실패 시 None 반환
            
        Note:
            삭제 결과는 콘솔에 출력됩니다 (예: "Deleted 5/10 files successfully")
        """
        if isinstance(file_name, str):
            file_name = [file_name]
        file_name = [os.path.join(self.mount_path, self._get_relative_path(file)) for file in file_name]
        
        try:
            # ThreadPoolExecutor를 사용하여 병렬 처리
            with ThreadPoolExecutor(max_workers=min(len(file_name), 10)) as executor:
                # 모든 파일 삭제 작업을 병렬로 실행
                results = list(executor.map(self._delete_single_file, file_name))
            
            # 결과 요약
            successful = sum(results)
            total = len(file_name)
            print(f"Deleted {successful}/{total} files successfully")
            
        except Exception as e:
            print(f"Error in parallel file deletion: {e}")
            return None
        
