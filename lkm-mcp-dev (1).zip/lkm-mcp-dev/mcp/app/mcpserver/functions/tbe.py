import ast
from typing import Any
from bs4 import BeautifulSoup
from dotenv import load_dotenv
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from mcpserver.functions.saver import save_html
logger = logging.getLogger(__name__)

from utils.llm import LLMSingleton
# from mcpserver.functions.file_handler import FileHandler
# file_handler = FileHandler()

load_dotenv()  # .env 파일 로드

llm = LLMSingleton.get_llm()


# RFQ 문서에서 프로젝트명, 아이템&수량, Special Notes를 구조화된 형태로 추출
def extract_structured_data(rfq_content):
    """RFQ 문서에서 프로젝트명, 아이템&수량, Special Notes를 구조화된 형태로 추출"""
    
    extraction_prompt = f"""
    다음 RFQ 문서에서 정보를 추출하여 지정된 형식으로 정리해주세요. 

    ### RFQ 문서 내용:
    {rfq_content}

    ### 추출해야 할 정보:
    1. 프로젝트명 (Project Name)
    2. ITEMS AND QUANTITIES 테이블의 아이템 정보
    3. ITEMS AND QUANTITIES 테이블 바로 다음에 Special Notes 내용 존재 여부 파악 (존재할 경우 내용 추출)

    ### 참고사항:
    - 아이템 번호는 대부분 알파벳과 숫자로 이루어져 있습니다.
    - 만약 RFQ 문서에서 ITEMS AND QUANTITIES 테이블 바로 다음에 Special Notes가 있으면 그 내용도 함께 추출해주세요.
    - **special notes 내용은 반드시 ITEMS AND QUANTITIES 테이블 바로 근처에 존재할 경우에만 추출하세요.**

    출력 형식은 반드시 JSON 형식으로만 출력하세요. 다른 설명 없이 JSON만 반환하세요.
    {{
        "project_name": "프로젝트명",
        "items_and_quantities": [
            ["아이템 번호1", "수량"],
            ["아이템 번호2", "수량"],
            ["아이템 번호3", "수량"],
            ...
            ["아이템 번호n", "수량"],
            ["Total", "전체 수량"]
        ],
        "special_notes": [
            ["[Special Note]", ""],
            ["Special Note 내용1", ""],
            ["Special Note 내용2", ""]
        ]
    }}

    출력 예시(Special Notes 존재):
    {{
        "project_name": "2026년 No.1OBB TA 관련 통합구매(Group D)",
        "items_and_quantities": [
            ["AL-E1401A", "1 Set"],
            ["HP-E9114B", "1 Set"],
            ["RC-E8425B", "2 Sets"],
            ["P-E3515", "4 Sets"],
            ["Total", "8 Sets"]
        ],
        "special_notes": [
            ["[Special Note]", ""],
            ["Special Note 내용1", ""],
            ["Special Note 내용2", ""]
        ]
    }}

    출력 예시(Special Notes 존재하지 않음):
    {{
        "project_name": "2026년 No.1OBB TA 관련 통합구매(Group D)",
        "items_and_quantities": [
            ["AL-E1401A", "1 Set"],
            ["HP-E9114B", "1 Set"],
            ["RC-E8425B", "2 Sets"],
            ["P-E3515", "4 Sets"],
            ["Total", "8 Sets"]
        ],
        "special_notes": [

        ]
    }}

    주의사항:
    - ITEMS AND QUANTITIES 섹션에서 아이템 번호와 수량만 추출
    - Special Notes가 없으면 빈 배열 반환
    - 정확한 JSON 형식으로 출력
    - 다른 설명이나 markdown 표시 없이 순수 JSON만 반환
    """
    
    response = llm.invoke(extraction_prompt)
    json_content = response.content.strip()
    
    # JSON 문자열을 파이썬 딕셔너리로 변환
    try:
        import json
        structured_dict = json.loads(json_content)
        return structured_dict
    except json.JSONDecodeError:
        # JSON 파싱에 실패한 경우, 원본 텍스트에서 JSON 부분만 추출 시도
        if "```json" in json_content:
            json_start = json_content.find("```json") + 7
            json_end = json_content.find("```", json_start)
            json_content = json_content[json_start:json_end].strip()
        elif "{" in json_content and "}" in json_content:
            json_start = json_content.find("{")
            json_end = json_content.rfind("}") + 1
            json_content = json_content[json_start:json_end]
        
        try:
            structured_dict = json.loads(json_content)
            return structured_dict
        except json.JSONDecodeError:
            logger.error(f"JSON 파싱 오류: {json_content}")
            return None


def replace_project_name_in_tbe_html(tbe_html_path, tbe_html_content, new_project_name, llm, modified_file_path):
    """HTML 파일에서 project_name을 new_project_name으로 교체하는 함수"""

    project_name_prompt = f"""다음 텍스트는 테이블 형태의 문서에서 추출한 내용입니다. 
    이 텍스트를 분석하여 프로젝트명을 찾아서 정확히 출력해주세요. 

    [참고 사항]
    각 셀은 |로 구분되어 있습니다.
    각 행은 \n으로 구분되어 있습니다.

    Technical Clarification Sheet(TBE)에서 추출한 내용:
    {tbe_html_content}

    프로젝트명이 포함된 셀을 찾아서 전문을 정확히 출력해주세요. 추가 설명은 불필요합니다.
    """

    # LLM에게 프로젝트명 추출 요청
    project_name_response = llm.invoke(project_name_prompt)
    project_name = project_name_response.content.strip()

    # html_content = file_handler.load_text(tbe_html_path)

    with open(tbe_html_path, 'r', encoding='utf-8') as file:
        html_content = file.read()
    
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table')
    if not table:
        return ""
    
    rows = table.find_all('tr')
    
    for row in rows:
        cells = row.find_all(['td', 'th'])
        for cell in cells:
            cell_text = cell.get_text(strip=True)
            if cell_text == project_name:
                cell.string = new_project_name
    

    modified_file_path = save_html("","",str(soup),full_path=modified_file_path)
    #file_handler.save_file(file_name = modified_file_path, content=str(soup), file_type="html")
    logger.info(f"프로젝트명이 성공적으로 교체되었습니다.")
    
    return modified_file_path


def remove_items_and_quantity_rows(tbe_html_path, tbe_html_content, llm)->tuple[str, int, str]:

    item_quantity_prompt = f"""다음 텍스트는 테이블 형태의 문서에서 추출한 내용입니다. 
    이 텍스트를 분석하여 아이템 및 수량 정보가 적힌 부분을 찾아서 해당 연속된 행들을 모두 출력해주세요. 그리고 첫 번째 행 내용 바로 직전 행 내용도 출력해주세요.

    [참고 사항]
    각 셀은 |로 구분되어 있습니다.
    각 행은 \n으로 구분되어 있습니다.
    **아이템 및 수량 정보는 보통 특정 부품(시리얼 넘버)과 이 부품이 몇개 필요한지(set, sets)에 대한 내용이 연속되게 적혀있습니다.** 이점을 각별히 유의해서 파악하세요.
    (예를 들어, OP-E3451B | 1 Set 와 같은 정보를 포함하고 있을 수 있습니다.)

    Technical Clarification Sheet(TBE)에서 추출한 내용:
    {tbe_html_content}

    제목에 해당하는 행은 제외하고 아이템 및 수량 정보가 포함된 연속된 첫 행과 마지막 행을 출력해주세요. 추가 설명은 불필요합니다.
    **만약 아이템 및 수량 정보와 관련된 special note가 있다면, 이 부분 역시 아이템 및 수량 정보가 적힌 부분이라고 취급해주세요.**
    **주의: 소제목으로 취급되는 행은 첫 행이 될 수 없습니다.**

    반드시 다음 형식으로만 답변해주세요:
    ["첫 번째 행 내용", "마지막 행 내용"]
    
    위 형식이 아닌 답변은 절대로 하지 마세요. 코드 블록이나 plaintext 등 다른 형식으로 감싸지 마세요.
    """

    item_quantity_response = llm.invoke(item_quantity_prompt)
    item_quantity_info = item_quantity_response.content.strip()
    
    # 코드 블록이나 plaintext 형식이 포함된 경우 제거
    if item_quantity_info.startswith('```'):
        lines = item_quantity_info.split('\n')
        for i, line in enumerate(lines):
            if line.startswith('['):
                item_quantity_info = '\n'.join(lines[i:])
                break
        if item_quantity_info.endswith('```'):
            item_quantity_info = item_quantity_info[:-3].strip()
    
    try:
        rows_to_remove = ast.literal_eval(item_quantity_info)
    except (ValueError, SyntaxError) as e:
        logger.error(f"LLM 응답 파싱 오류: {e}")
        logger.error(f"원본 응답: {item_quantity_info}")
        return ""
    
    print("rows_to_remove", rows_to_remove)
    
    # html_content = file_handler.load_text(tbe_html_path)
    with open(tbe_html_path, 'r', encoding='utf-8') as file:
        html_content = file.read()
    
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table')
    
    if not table:
        return ""
    
    # 테이블의 모든 행을 찾기
    all_rows = table.find_all('tr')
    
    if len(rows_to_remove) < 2:
        return ""
    
    start_text = rows_to_remove[0].replace("|", " ").strip()
    end_text = rows_to_remove[1].replace("|", " ").strip()
    # 첫 번째 행과 마지막 행의 인덱스 찾기
    start_index = -1
    end_index = -1
    
    for i, row in enumerate(all_rows):
        # 행의 텍스트 내용 확인
        cells = row.find_all(['td', 'th'])
        row_content = []
        for cell in cells:
            cell_text = cell.get_text(strip=True)
            row_content.append(cell_text)
        row_content = "|".join(row_content) + "|"
        if row_content.replace("|", " ").strip() == start_text:
            start_index = i
        if row_content.replace("|", " ").strip() == end_text:
            end_index = i
    
    saved_style_info = None
    saved_index = start_index
    
    while saved_index <= end_index:
        # 저장할 행의 HTML 구조를 추출하되 텍스트 내용은 제거
        row_copy = BeautifulSoup(str(all_rows[saved_index]), 'html.parser')
        
        # rowspan이 있는 셀이 있는지 확인
        has_rowspan = False
        for cell in row_copy.find_all(['td', 'th']):
            if cell.get('rowspan'):
                has_rowspan = True
                break
        
        # rowspan이 있으면 다음 행으로 넘어가기
        if has_rowspan:
            saved_index += 1
            continue
        
        # rowspan이 없는 경우 처리
        for cell in row_copy.find_all(['td', 'th']):
            cell.string = ""
        saved_style_info = str(row_copy)
        break

    # 첫 번째 행부터 마지막 행까지 삭제
    if start_index != -1 and end_index != -1 and start_index <= end_index:
        for i in range(end_index, start_index - 1, -1):  # 역순으로 삭제
            all_rows[i].decompose()
    
    # file_handler.save_file(file_name = tbe_html_path, content=str(soup), file_type="html")
    tbe_html_path = save_html("","",str(soup),full_path=tbe_html_path)
    logger.info(f"지정된 행들이 성공적으로 삭제되었습니다.")
    
    return tbe_html_path, start_index, saved_style_info



def remove_private_info(tbe_html_path, tbe_html_content, llm):
    """HTML 파일에서 지정된 텍스트가 포함된 셀들을 공백으로 바꾸는 함수"""
    
    privacy_detection_prompt = f"""다음 텍스트는 테이블 형태의 문서에서 추출한 내용입니다. 
    이 텍스트를 분석하여 개인정보(이름, 이메일 주소, 전화번호, 주소 등)라고 판단되는 셀의 전문을 정확하게 식별해주세요. 해당 셀은 2개 이상일 수 있습니다.

    [참고 사항]
    각 셀은 |로 구분되어 있습니다.
    각 행은 \n으로 구분되어 있습니다.

    Technical Clarification Sheet(TBE)에서 추출한 내용:
    {tbe_html_content}

    **셀의 전문은 |과 | 사이에 들어 있는 전체 내용입니다. 개인정보가 포함된 전체 셀 내용을 그대로 출력해야 합니다.**

    다음 형식으로 개인정보가 들어 있는 셀의 전문을 정확히 출력해주세요:

    [
    "탐지된 셀의 완전한 전문1",
    "탐지된 셀의 완전한 전문2",
    "탐지된 셀의 완전한 전문3"
    ]

    개인정보가 없는 경우:
    []

    **반드시 위의 형식으로만 답변하고 다른 설명은 포함하지 마세요.**

    """

    try:
        # LLM에게 개인정보 식별 요청
        privacy_response = llm.invoke(privacy_detection_prompt)
        privacy_info = privacy_response.content.strip()
        
        # Markdown 코드 블록 제거
        if privacy_info.startswith('```'):
            privacy_info = privacy_info.split('\n', 1)[1]
        if privacy_info.endswith('```'):
            privacy_info = privacy_info.rsplit('\n', 1)[0]
        
        # plaintext, json 등의 라벨 제거
        privacy_info = privacy_info.replace('plaintext', '').replace('json', '').strip()
        
        cells_to_remove = ast.literal_eval(privacy_info)
        
    except (ValueError, SyntaxError) as e:
        logger.error(f"LLM 응답 파싱 오류: {e}")
        logger.error(f"LLM 응답 내용: {privacy_info}")
        cells_to_remove = []
    
    # html_content = file_handler.load_text(tbe_html_path)
    with open(tbe_html_path, 'r', encoding='utf-8') as file:
        html_content = file.read()
    
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table')
    
    if not table:
        return ""
    
    # 테이블의 모든 행을 찾기
    all_rows = table.find_all('tr')
    
    for i, row in enumerate(all_rows):
        # 행의 텍스트 내용 확인
        cells = row.find_all(['td', 'th'])
        for cell in cells:
            cell_text = cell.get_text(strip=True)
            # cells_to_remove 리스트에 있는 값이 cell_text에 포함되면 셀 내용을 공백으로 변경
            for remove_text in cells_to_remove:
                if remove_text in cell_text:
                    cell.clear()
                    cell.string = ""
                    # 배경색을 흰색으로 설정
                    cell['style'] = 'background-color: white;'
                    break

    # 수정된 HTML을 새로운 파일에 저장

    # file_handler.save_file(file_name = tbe_html_path, content=str(soup), file_type="html")
    tbe_html_path = save_html("","",str(soup),full_path=tbe_html_path)
    logger.info(f"개인정보가 포함된 셀이 성공적으로 삭제되었습니다.")

    return tbe_html_path


def get_tbe_col_idx(html_content, llm)->list[Any]:
    """
    tbe content에서 순번, description, specification 컬럼이 몇번 째 열인지, 워딩은 무엇인지 찾는다.
    """
    
    tbe_col_idx_prompt = f"""
    내가 지금 주어진 문서에서 순번, description, specification 컬럼이 몇번 째 열인지 찾으려고 해. 
    설명없이 정확하게 해당 컬럼들이 몇번 째 열인지 숫자로 표현해주고, 각 컬럼의 실제 이름도 HTML content에 기입되어 있는 글자 그대로 써줘. (0부터 시작)
    참고로 순번 컬럼은 숫자로 채워져있을 확률이 높고(1, 1.1, 2.1.2 등), description은 영어 문자로 채워져 있을 확률이 높아. specification은 간단한 영어 문자로 채워져있을 확률이 높아. (required, not required, - 15'C 등)

    다음과 같은 형식으로만 답변해줘:
    순번컬럼: [숫자] | [실제컬럼명]
    description컬럼: [숫자] | [실제컬럼명]
    specification컬럼: [숫자] | [실제컬럼명]

    HTML content:
    {html_content}
    """    
    
    tbe_col_idx_response = llm.invoke(tbe_col_idx_prompt)
    
    # 응답에서 숫자와 컬럼명 추출
    response_lines = tbe_col_idx_response.content.strip().split('\n')
    
    no_col_idx = None
    desc_col_idx = None
    req_col_idx = None
    no_col_name = None
    desc_col_name = None
    req_col_name = None
    
    for line in response_lines:
        if '순번컬럼:' in line:
            try:
                parts = line.split(':')[1].strip().split('|')
                no_col_idx = int(parts[0].strip())
                no_col_name = parts[1].strip() if len(parts) > 1 else None
            except:
                pass
        elif 'description컬럼:' in line:
            try:
                parts = line.split(':')[1].strip().split('|')
                desc_col_idx = int(parts[0].strip())
                desc_col_name = parts[1].strip() if len(parts) > 1 else None
            except:
                pass
        elif 'specification컬럼:' in line:
            try:
                parts = line.split(':')[1].strip().split('|')
                req_col_idx = int(parts[0].strip())
                req_col_name = parts[1].strip() if len(parts) > 1 else None
            except:
                pass

    result = [no_col_idx, desc_col_idx, req_col_idx, no_col_name, desc_col_name, req_col_name]

    return result


def extract_matched_data(tbe_html_path, main_cols_info_list)->tuple[list[Any], str]:
    """
    HTML 파일에서 No., Description, Requirements 열의 값을 매칭해서 출력한다. (단, 컬럼명 나온 이후 부터 매칭)
    Requirements가 빈 칸인 경우는 포함하지 않는다.
    text-decoration이 none과 line-through가 모두 존재하는 셀은 배경색을 변경하고 "(확인 요망)"을 빨간 글씨로 추가한다.
    """
    # html_content = file_handler.load_text(tbe_html_path)
    with open(tbe_html_path, 'r', encoding='utf-8') as file:
        html_content = file.read()
    
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table')
    
    if not table:
        return [], None

    no_col_idx, desc_col_idx, req_col_idx, no_col_name, desc_col_name, req_col_name = main_cols_info_list

    no_col_name = no_col_name.replace(' ', '')
    desc_col_name = desc_col_name.replace(' ', '')
    req_col_name = req_col_name.replace(' ', '')
    
    rows = table.find_all('tr')
    matched_data = []
    
    # 헤더 행을 찾고 그 이후부터 데이터를 추출
    header_found = False
    no_header_match = False
    desc_header_match = False
    req_header_match = False
    
    for row in rows:
        cells = row.find_all(['td', 'th'])
        
        # 헤더 행인지 확인 (세 개의 컬럼명이 모두 정확히 매칭되는지)
        if not header_found:
            if no_col_idx < len(cells) and cells[no_col_idx].get_text(strip=True) == no_col_name:
                no_header_match = True
            if desc_col_idx < len(cells) and cells[desc_col_idx].get_text(strip=True) == desc_col_name:
                desc_header_match = True
            if req_col_idx < len(cells) and cells[req_col_idx].get_text(strip=True) == req_col_name:
                req_header_match = True
            
            # 세 개의 헤더가 모두 올바른 위치에서 발견되면 헤더 행으로 판단
            if no_header_match and desc_header_match and req_header_match:
                header_found = True
                continue  # 헤더 행은 건너뛰고 다음 행부터 데이터 추출
        
        # 헤더가 발견된 이후의 행에서만 데이터를 추출
        if header_found:
            # 열 인덱스가 모두 유효한지 확인
            if (no_col_idx is not None and desc_col_idx is not None and 
                req_col_idx is not None and len(cells) > max(no_col_idx, desc_col_idx, req_col_idx)):

                no_value = cells[no_col_idx].get_text(strip=True) if no_col_idx < len(cells) else ""
                desc_value = cells[desc_col_idx].get_text(strip=True) if desc_col_idx < len(cells) else ""
                req_value = cells[req_col_idx].get_text(strip=True) if req_col_idx < len(cells) else ""
                
                # Requirements가 비어있지 않은 경우만 저장
                if req_value and desc_value:
                    matched_data.append({
                        'No': no_value,
                        'Description': desc_value,
                        'Requirements': req_value
                    })
                
                # 각 셀에서 text-decoration 확인 및 수정
                cell = cells[desc_col_idx]

                # 셀 내의 모든 font 태그 검사
                font_tags = cell.find_all('font')
                has_none = False
                has_line_through = False
                
                for font_tag in font_tags:
                    style = font_tag.get('style', '')
                    if 'text-decoration: none' in style:
                        has_none = True
                    if 'text-decoration: line-through' in style:
                        has_line_through = True
                
                # none과 line-through가 모두 존재하는 경우
                if has_none and has_line_through:
                    # 셀에 배경색 추가
                    current_style = cell.get('style', '')
                    if 'background-color' not in current_style:
                        new_style = current_style + '; background-color: #ffcccc;' if current_style else 'background-color: #ffcccc;'
                        cell['style'] = new_style
                    
                    # 텍스트 내용 맨 끝에 "(확인 요망)" 빨간 글씨로 추가
                    cell_text = cell.get_text()
                    if '(확인 요망)' not in cell_text:
                        # 새로운 빨간색 font 태그 생성
                        warning_font = soup.new_tag('font', style='color: #FF0000; font-weight: bold;')
                        warning_font.string = ' (확인 요망)'
                        
                        # 셀의 마지막에 추가
                        cell.append(warning_font)

                # 해당 셀의 모든 font 태그에 text-decoration: none 적용
                cell = cells[desc_col_idx]
                font_tags = cell.find_all('font')
                
                for font_tag in font_tags:
                    current_style = font_tag.get('style', '')
                    # 기존 text-decoration 제거 후 none 추가
                    style_parts = [part.strip() for part in current_style.split(';') if part.strip()]
                    new_style_parts = []
                    
                    for part in style_parts:
                        if not part.startswith('text-decoration'):
                            new_style_parts.append(part)
                    
                    # text-decoration: none 추가
                    new_style_parts.append('text-decoration: none')
                    font_tag['style'] = '; '.join(new_style_parts)
                
                # font 태그가 없는 경우 셀 자체에 스타일 적용
                if not font_tags:
                    current_style = cell.get('style', '')
                    style_parts = [part.strip() for part in current_style.split(';') if part.strip()]
                    new_style_parts = []
                    
                    for part in style_parts:
                        if not part.startswith('text-decoration'):
                            new_style_parts.append(part)
                    
                    new_style_parts.append('text-decoration: none')
                    cell['style'] = '; '.join(new_style_parts)
                                    
    # file_handler.save_file(file_name = tbe_html_path, content=str(soup), file_type="html")
    tbe_html_path = save_html("","",str(soup),full_path=tbe_html_path)
    
    return matched_data, tbe_html_path


# required와 not required 판단
def check_requirements(llm, context, question_set):
    """
    주어진 question_set에 대한 requirements가 옳은지 판단하고,
    옳지 않은 경우 올바른 값으로 수정하여 반환한다.
    판단할 수 없는 경우 그에 대한 메시지를 반환한다.
    """
    # 모든 질문을 하나의 프롬프트에 포함
    questions_text = ""
    for i, item in enumerate(question_set, 1):
        no = item['No']
        description = item['Description']
        current_requirement = item['Requirements']
        questions_text += f"""
        {i}. 항목 번호: {no}
           설명: {description}
           현재 요구사항: {current_requirement}
        """
    
    # LLM에게 모든 질문을 한번에 판단 요청하는 프롬프트
    prompt = f"""
    다음은 기술 사양서(Technical Specification) 문서의 내용입니다. 
    이 문서는 markitdown을 통해 변환된 것으로, [x] 표시는 체크박스가 선택된 상태(체크됨)를 의미하고, [ ] 표시는 체크박스가 선택되지 않은 상태를 의미합니다.

    {context}

    위 문서에서 ~~표시로 처리된 것은 취소선을 의미합니다. 즉 원래 문장과 반대의 의미를 가집니다.
    (ex. 필요한 과일: 사과, 포도, ~~오렌지~~, 바나나 라면, 오렌지는 필요하지 않은 과일입니다.)
    위 문서를 참고하여 다음 항목들의 요구사항(Requirements)이 올바른지 판단해주세요:

    {questions_text}
    판단할 때 다음 사항을 고려해주세요:
    - [x] 표시는 해당 항목이 선택/필요함을 의미합니다 (Required)
    - [ ] 표시는 해당 항목이 선택되지 않음/불필요함을 의미합니다 (Not Required)
    - 문서에서 해당 항목에 대한 명시적인 정보를 찾아 판단해주세요.
    - 만약 해당 항목에 대한 근거가 여러개일 경우에는, 해당 항목과 가장 유사한 텍스트를 기반으로 판단하세요.
    - 문서에서 해당 항목에 대한 내용이 없는 경우 판단할 수 없음을 응답해주세요.

    **출력 형식을 정확히 지켜주세요:**
    각 항목에 대해 다음 형식으로 응답해주세요:

    항목 번호: [항목번호]
    설명: [Description 내용]
    현재 요구사항: [현재 Requirements 값]
    [UNDETERMINED/CORRECT/INCORRECT]: [올바른 요구사항]
    근거: [문서에서 해당 항목에 대한 구체적인 정보와 판단 근거]

    예시:
    항목 번호: 3.1
    설명: Audio codec support  
    현재 요구사항: Required  
    CORRECT: Required  
    근거: 문서에서 3.1 항목은 Scope of Supply 섹션에서 [x]로 표시되어 있어 요구사항이 올바릅니다.

    항목 번호: 3.2
    설명: Video encoding feature  
    현재 요구사항: Required  
    INCORRECT: Not Required  
    근거: 문서에서 3.2 항목은 Scope of Supply 섹션에서 [ ]로 표시되어 있어 실제로는 불필요합니다.

    항목 번호: 3.3
    설명: Network interface module
    현재 요구사항: Not Required
    UNDETERMINED: 판단할 수 없음
    근거: 문서에서 해당 항목에 대한 명확한 정보를 찾을 수 없습니다.

    각 항목에 대해 순서대로 위 형식으로 응답해주세요.
    """
    response = llm.invoke(prompt)
    result_text = response.content.strip()
    
    return result_text

def parse_answer_result(answer_text):

    lines = answer_text.split('\n')
    
    parsed_items = []
    current_item = {}
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        if line.startswith('항목 번호:'):
            # 새로운 항목 시작
            if current_item:
                # 이전 항목 저장 (INCORRECT 또는 UNDETERMINED인 경우만)
                if 'judgment' in current_item and current_item['judgment'] in ['INCORRECT', 'UNDETERMINED']:
                    parsed_items.append(current_item)
            
            current_item = {'no': line.split(':', 1)[1].strip()}
            
        elif line.startswith('설명:'):
            current_item['description'] = line.split(':', 1)[1].strip()
            
        elif line.startswith('현재 요구사항:'):
            current_item['current_requirement'] = line.split(':', 1)[1].strip()
            
        elif any(line.startswith(prefix) for prefix in ['INCORRECT:', 'UNDETERMINED:', 'CORRECT:']):
            if line.startswith('INCORRECT:'):
                current_item['judgment'] = 'INCORRECT'
                current_item['corrected_requirement'] = line.split(':', 1)[1].strip()
            elif line.startswith('UNDETERMINED:'):
                current_item['judgment'] = 'UNDETERMINED'
                current_item['corrected_requirement'] = '(확인 요망)'
            else:  # CORRECT
                current_item['judgment'] = 'CORRECT'
                
        elif line.startswith('근거:'):
            current_item['evidence'] = line.split(':', 1)[1].strip()
    
    # 마지막 항목 처리
    if current_item and 'judgment' in current_item and current_item['judgment'] in ['INCORRECT', 'UNDETERMINED']:
        parsed_items.append(current_item)
    
    return parsed_items


def get_all_incorrect_undetermined(matched_data, rfq_context, llm):

    all_results = []

    # matched_data를 10개씩 묶어서 처리할 작업 목록 생성
    tasks = []
    for i in range(1, len(matched_data), 10):
        # 10개씩 슬라이싱 (마지막 그룹은 10개 미만일 수 있음)
        question_set = matched_data[i:i+10]
        group_num = (i-1)//10 + 1
        start_idx = i
        end_idx = min(i+9, len(matched_data)-1)
        
        tasks.append({
            'group': group_num,
            'items': f"{start_idx}~{end_idx}",
            'question_set': question_set
        })

    try:
        # ThreadPoolExecutor를 사용하여 병렬 처리
        max_workers = min(len(tasks), 4)  # 최대 4개의 스레드 사용
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 각 작업을 executor에 제출
            future_to_task = {
                executor.submit(check_requirements, llm, rfq_context, task['question_set']): task 
                for task in tasks
            }
            
            # 완료된 작업들을 수집
            for future in as_completed(future_to_task):
                task = future_to_task[future]
                try:
                    temp_answer = future.result()
                    print(f"=== 그룹 {task['group']}: 항목 {task['items']} 완료 ===")
                    
                    # 결과 저장
                    all_results.append({
                        'group': task['group'],
                        'items': task['items'],
                        'answer': temp_answer
                    })
                except Exception as e:
                    logger.error(f"그룹 {task['group']} 처리 중 오류 발생: {e}")
                    print(f"=== 그룹 {task['group']}: 항목 {task['items']} 오류 발생 ===")
    except Exception as e:
        for task in tasks:
            answer = check_requirements(llm, rfq_context, task['question_set'])
            all_results.append(
                {"answer" : answer}
            )


    # 모든 결과에서 INCORRECT 및 UNDETERMINED 항목들 수집
    all_incorrect_undetermined = []

    for result in all_results:
        incorrect_undetermined_items = parse_answer_result(result['answer'])
        all_incorrect_undetermined.extend(incorrect_undetermined_items)

    return all_incorrect_undetermined


def modify_tbe_html(tbe_html_path, all_incorrect_undetermined_list, main_cols_info_list):
    """
    HTML 테이블의 요구사항 컬럼을 수정하고 새로운 파일명으로 저장하는 함수
    """
    # html_content = file_handler.load_text(tbe_html_path)
    with open(tbe_html_path, 'r', encoding='utf-8') as file:
        html_content = file.read()
    
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table')
    
    if not table:
        print("테이블을 찾을 수 없습니다.")
        return html_content
    
    rows = table.find_all('tr')
    no_col_idx, desc_col_idx, req_col_idx, _, _, _ = main_cols_info_list
    
    changes_made = 0
    
    # 각 행을 검사하여 매칭되는 항목 찾기
    for row in rows:
        cells = row.find_all(['td', 'th'])
        
        # 셀이 충분한지 확인
        if len(cells) <= max(no_col_idx, desc_col_idx, req_col_idx):
            continue
            
        # 현재 행의 No와 Description 값 추출
        current_no = cells[no_col_idx].get_text(strip=True)
        current_desc = cells[desc_col_idx].get_text(strip=True)
        
        # all_incorrect_undetermined_list에서 매칭되는 항목 찾기
        for item in all_incorrect_undetermined_list:
            if (item.__contains__('no') and item.__contains__('description')) and\
            (current_no.strip() == item['no'].strip() and current_desc.strip() == item['description'].strip()):
                
                # 요구사항 셀 내용 수정
                old_value = cells[req_col_idx].get_text(strip=True)
                cells[req_col_idx].string = item['corrected_requirement']
                
                # 셀 배경색 설정
                if item['corrected_requirement'] == '(확인 요망)':
                    cells[req_col_idx]['style'] = 'background-color: #ffcccc;'  # 옅은 빨강색
                else:
                    cells[req_col_idx]['style'] = 'background-color: #ccddff;'  # 옅은 파랑색
                
                print(f"항목 {current_no} 수정: '{old_value}' → '{item['corrected_requirement']}'")
                changes_made += 1
                break
    
    print(f"총 {changes_made}개 항목이 수정되었습니다.")
    
    # 출력 파일명 결정
    # file_handler.save_file(file_name = tbe_html_path, content=str(soup), file_type="html")
    tbe_html_path = save_html("","",str(soup),full_path=tbe_html_path)
    
    return tbe_html_path

# Item and quantity 중 병합된 셀 쪼개기
def check_empty_quantities(items_and_quantities_list):
    
    # 데이터 복사본 생성
    processed_data = [item[:] for item in items_and_quantities_list]
    
    current_index = 0
    while current_index < len(processed_data):
        # 현재 항목이 비어있지 않은 수량을 가지고 있는지 확인
        if len(processed_data[current_index]) > 1 and processed_data[current_index][1].strip():
            # 수량에서 숫자 추출
            numbers = re.findall(r'\d+', processed_data[current_index][1])
            if numbers:
                current_item_quantity = int(numbers[0])
                
                # 바로 다음부터 연속된 빈 값들 찾기
                next_index = current_index + 1
                empty_quantity_count = 0
                empty_item_indices = []
                
                search_index = next_index
                while search_index < len(processed_data) and len(processed_data[search_index]) > 1 and not processed_data[search_index][1].strip():
                    empty_item_indices.append(search_index)
                    empty_quantity_count += 1
                    search_index += 1
                
                # 조건 확인 및 처리
                if empty_quantity_count > 0:
                    if empty_quantity_count + 1 == current_item_quantity:
                        # 조건 만족: 현재 항목과 빈 값들을 모두 "1 Set"으로 설정
                        processed_data[current_index][1] = "1 Set"
                        for empty_index in empty_item_indices:
                            processed_data[empty_index][1] = "1 Set"
                    else:
                        # 조건 불만족: 현재 항목과 빈 값들을 모두 "(확인 요망)"으로 설정
                        processed_data[current_index][1] = "(확인 요망)"
                        for empty_index in empty_item_indices:
                            processed_data[empty_index][1] = "(확인 요망)"
                
                # 처리된 빈 값들 다음 위치로 이동
                current_index = search_index
            else:
                current_index += 1
        else:
            current_index += 1
    
    return processed_data

# html -> 행과 셀의 내용 추출
def extract_html_table_content(file_path:str, cell_delimiter:str="|", row_delimiter:str="|\n"):
    """HTML 파일에서 테이블의 모든 셀 값을 구분자로 구분하여 하나의 문자열로 반환하는 함수"""

    # html_content = file_handler.load_text(file_path)

    with open(file_path, 'r', encoding='utf-8') as file:
        html_content = file.read()
    
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table')
    
    if not table:
        return ""
    
    rows = table.find_all('tr')
    all_content = []
    
    for row in rows:
        cells = row.find_all(['td', 'th'])
        row_content = []
        for i, cell in enumerate(cells):
            cell_text = cell.get_text(strip=True)
            row_content.append(cell_text)
        # 각 행의 셀들을 구분자로 연결
        row_string = cell_delimiter.join(row_content)
        all_content.append(row_string)
    
    # 모든 행을 행 구분자로 연결하여 최종 문자열 생성
    final_content = row_delimiter.join(all_content)
    return final_content


# RFQ 문서에서 프로젝트명, 아이템&수량, Special Notes를 구조화된 형태로 추출
def extract_rfq_structured_data(rfq_content:str) -> dict[str, Any]:
    """RFQ 문서에서 프로젝트명, 아이템&수량, Special Notes를 구조화된 형태로 추출"""
    
    extraction_prompt = f"""
    다음 RFQ 문서에서 정보를 추출하여 지정된 형식으로 정리해주세요. 

    ### RFQ 문서 내용:
    {rfq_content}

    ### 추출해야 할 정보:
    1. 프로젝트명 (Project Name)
    2. ITEMS AND QUANTITIES 테이블의 아이템 정보
    3. ITEMS AND QUANTITIES 테이블 바로 다음에 Special Notes 내용 존재 여부 파악 (존재할 경우 내용 추출)

    ### 참고사항:
    - 아이템 번호는 대부분 알파벳과 숫자로 이루어져 있습니다.
    - 만약 RFQ 문서에서 ITEMS AND QUANTITIES 테이블 바로 다음에 Special Notes가 있으면 그 내용도 함께 추출해주세요.
    - **special notes 내용은 반드시 ITEMS AND QUANTITIES 테이블 바로 근처에 존재할 경우에만 추출하세요.**

    출력 형식은 반드시 JSON 형식으로만 출력하세요. 다른 설명 없이 JSON만 반환하세요.
    {{
        "project_name": "프로젝트명",
        "items_and_quantities": [
            ["아이템 번호1", "수량"],
            ["아이템 번호2", "수량"],
            ["아이템 번호3", "수량"],
            ...
            ["아이템 번호n", "수량"],
            ["Total", "전체 수량"]
        ],
        "special_notes": [
            ["[Special Note]", ""],
            ["Special Note 내용1", ""],
            ["Special Note 내용2", ""]
        ]
    }}

    출력 예시(Special Notes 존재):
    {{
        "project_name": "2026년 No.1OBB TA 관련 통합구매(Group D)",
        "items_and_quantities": [
            ["AL-E1401A", "1 Set"],
            ["HP-E9114B", "1 Set"],
            ["RC-E8425B", "2 Sets"],
            ["P-E3515", "4 Sets"],
            ["Total", "8 Sets"]
        ],
        "special_notes": [
            ["[Special Note]", ""],
            ["Special Note 내용1", ""],
            ["Special Note 내용2", ""]
        ]
    }}

    출력 예시(Special Notes 존재하지 않음):
    {{
        "project_name": "2026년 No.1OBB TA 관련 통합구매(Group D)",
        "items_and_quantities": [
            ["AL-E1401A", "1 Set"],
            ["HP-E9114B", "1 Set"],
            ["RC-E8425B", "2 Sets"],
            ["P-E3515", "4 Sets"],
            ["Total", "8 Sets"]
        ],
        "special_notes": [

        ]
    }}

    주의사항:
    - ITEMS AND QUANTITIES 섹션에서 아이템 번호와 수량만 추출
    - Special Notes가 없으면 빈 배열 반환
    - 정확한 JSON 형식으로 출력
    - 다른 설명이나 markdown 표시 없이 순수 JSON만 반환
    """
    
    response = llm.invoke(extraction_prompt)
    json_content = response.content.strip()
    print(f"json_content : {json_content}")
    
    # JSON 문자열을 파이썬 딕셔너리로 변환
    try:
        import json
        structured_dict = json.loads(json_content)
        return structured_dict
    except json.JSONDecodeError:
        # JSON 파싱에 실패한 경우, 원본 텍스트에서 JSON 부분만 추출 시도
        if "```json" in json_content:
            json_start = json_content.find("```json") + 7
            json_end = json_content.find("```", json_start)
            json_content = json_content[json_start:json_end].strip()
        elif "{" in json_content and "}" in json_content:
            json_start = json_content.find("{")
            json_end = json_content.rfind("}") + 1
            json_content = json_content[json_start:json_end]
        
        try:
            structured_dict = json.loads(json_content)
            return structured_dict
        except json.JSONDecodeError:
            print(f"JSON 파싱 오류: {json_content}")
            return None

def add_new_row(item, quantity, style_info, desc_col_idx, req_col_idx):

    new_row_soup = BeautifulSoup(style_info, 'html.parser')
    new_row = new_row_soup.find('tr')

    cells = new_row.find_all(['td', 'th'])

    cells[desc_col_idx].string = item
    cells[req_col_idx].string = quantity
    
    return new_row


# bold 처리, 밑줄 추가
def add_total_row(item, quantity, style_info, desc_col_idx, req_col_idx):

    new_row_soup = BeautifulSoup(style_info, 'html.parser')
    new_row = new_row_soup.find('tr')

    cells = new_row.find_all(['td', 'th'])

    # item 셀: 우측정렬, 볼드체, 밑줄 추가, 검은색 글자
    cells[desc_col_idx].clear()
    item_span = new_row_soup.new_tag('span', style='font-weight: bold; text-decoration: underline; text-align: right; display: block; color: black;')
    item_span.string = item
    cells[desc_col_idx].append(item_span)
    cells[desc_col_idx]['style'] = cells[desc_col_idx].get('style', '') + ' text-align: right;'
    
    # quantity 셀: 볼드체, 밑줄 추가, 검은색 글자
    cells[req_col_idx].clear()
    quantity_span = new_row_soup.new_tag('span', style='font-weight: bold; text-decoration: underline; color: black;')
    quantity_span.string = quantity
    cells[req_col_idx].append(quantity_span)
    
    return new_row


def add_special_note_title_row(item, quantity, style_info, desc_col_idx, req_col_idx):

    new_row_soup = BeautifulSoup(style_info, 'html.parser')
    new_row = new_row_soup.find('tr')

    cells = new_row.find_all(['td', 'th'])

    # item 셀: 좌측정렬, 볼드체, 검은색 글자
    cells[desc_col_idx].clear()
    item_span = new_row_soup.new_tag('span', style='font-weight: bold; text-align: left; display: block; color: black;')
    item_span.string = item
    cells[desc_col_idx].append(item_span)
    cells[desc_col_idx]['style'] = cells[desc_col_idx].get('style', '') + ' text-align: left;'
    
    # quantity 셀: 빈칸
    cells[req_col_idx].clear()
    
    return new_row


def add_special_note_row(item, quantity, style_info, desc_col_idx, req_col_idx):

    new_row_soup = BeautifulSoup(style_info, 'html.parser')
    new_row = new_row_soup.find('tr')

    cells = new_row.find_all(['td', 'th'])

    # item 셀: 검정색 적용, 글자 굵기 기본
    cells[desc_col_idx].clear()
    item_span = new_row_soup.new_tag('span', style='color: black; font-weight: normal;')
    item_span.string = item
    cells[desc_col_idx].append(item_span)
    
    # quantity 셀: 검정색 적용, 글자 굵기 기본
    cells[req_col_idx].clear()
    quantity_span = new_row_soup.new_tag('span', style='color: black; font-weight: normal;')
    quantity_span.string = quantity
    cells[req_col_idx].append(quantity_span)
    
    return new_row

def add_item_and_quantity(tbe_html_path, removed_start_idx, new_rows_data, style_info, cols_info_list):

    new_rows_data_list = [item[:] for item in new_rows_data["items_and_quantities"]]

    ##### new_rows_data 검증
    for row in new_rows_data_list:
        if not row[1] or row[1].strip() == '':
            new_rows_data_list = check_empty_quantities(new_rows_data_list)
            break
    
    # html_content = file_handler.load_text(tbe_html_path)
    with open(tbe_html_path, 'r', encoding='utf-8') as file:
        html_content = file.read()

    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table')
    
    if not table:
        logger.error("테이블을 찾을 수 없습니다.")
        return ""
    
    all_rows = table.find_all('tr')
    _, desc_col_idx, req_col_idx, _, _, _ = cols_info_list

    for row in new_rows_data_list:

        item = row[0]
        quantity = row[1]

        if item.lower() == "total":
            # 내가 정한 스타일로 추가하기
            new_row = add_total_row(item, quantity, style_info, desc_col_idx, req_col_idx)
        else:
            new_row = add_new_row(item, quantity, style_info, desc_col_idx, req_col_idx)

        all_rows[removed_start_idx].insert_before(new_row)
        
    if new_rows_data["special_notes"]:

        for row in new_rows_data["special_notes"]:
            # 고정 값으로 내가 추가하기 - style default

            item = row[0]
            quantity = row[1]

            if item == "[Special Note]":
                # 내가 정한 스타일로 추가하기
                new_row = add_special_note_title_row(item, quantity, style_info, desc_col_idx, req_col_idx)
            else:
                new_row = add_special_note_row(item, quantity, style_info, desc_col_idx, req_col_idx)

            all_rows[removed_start_idx].insert_before(new_row)
    
    # 수정된 HTML을 새로운 파일에 저장
    # file_handler.save_file(file_name=tbe_html_path, content=str(soup), file_type="html")
    tbe_html_path = save_html("","",str(soup),full_path=tbe_html_path)
    logger.info(f"Item and quantities가 성공적으로 교체되었습니다.")
    
    return tbe_html_path