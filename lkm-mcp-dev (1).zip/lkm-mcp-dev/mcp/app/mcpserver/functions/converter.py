import re
import os
import random
from pydantic import BaseModel, Field
from markitdown import MarkItDown
from mcpserver.functions.saver import save_json
from client.document_client import DocumentClient


def preserve_formatting(text):
    normalized = re.sub(r"\s+", " ", text)
    normalized = normalized.strip()
    return normalized


def remove_indexing(text):
    return re.sub(r"(^|\s+)(\d+\.|\d+\))\s+", " ", text).strip()


def extract_docx_using_markitdown(file_path):
    md = MarkItDown()
    file_result = md.convert(file_path)
    file_content = file_result.markdown
    file_lines = file_content.splitlines()
    normalized_lines = []

    for line in file_lines:
        clean_line = remove_indexing(preserve_formatting(line))
        normalized_lines.append(clean_line)

    return normalized_lines

class ConvertWordToMarkdownInput(BaseModel):
    file_path: list = Field(
        ..., description="Markdown으로 변환할 워드 문서들의 경로 리스트"
    )

def convert_markdown(input: ConvertWordToMarkdownInput) -> str:
    contents_dict = {
        file_path: "\n".join(extract_docx_using_markitdown(file_path))
        for file_path in input.file_path
    }

    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(script_dir, "..", "test", "temp")
    output_filename = f"markdown_dict_{random.randint(1,9999)}.json"

    output_path = save_json(output_dir, output_filename, contents_dict)

    return output_path


class DocxToHtmlInput(BaseModel):
    docx_path: str = Field(..., description="HTML로 변환할 원본 DOCX 파일의 경로")
    start_page: int = Field(1,description="변환을 시작할 페이지 번호 (default: 1) / RFQ 문서는 보통 2페이지부터 시작합니다.")


async def docxTohtml(input: DocxToHtmlInput) -> str:
  
    # API 클라이언트 설정
    document_client = DocumentClient()
    output_path = await document_client.convert_to_html(input.docx_path)
    return output_path


async def convert_html_to_docx(html_path: str) -> str:
    try:
        
        document_client = DocumentClient()
        output_path = await document_client.convert_to_docx(html_path)
        return output_path
        
    except Exception as e:
        print(f"전체 프로세스에서 오류 발생: {str(e)}")
        print(f"오류 타입: {type(e).__name__}")
        import traceback
        print(f"상세 오류 정보:\n{traceback.format_exc()}")
        raise