from utils.llm import LLMSingleton
from fastmcp import FastMCP
import pickle
import joblib
import numpy as np
import pandas as pd

from typing import Dict, List, Any, Optional, Union
import warnings
from mcpserver.functions.file_handler import FileHandler

warnings.filterwarnings("ignore")

llm = LLMSingleton.get_llm()
file_handler = FileHandler()

feature_importance_mcp = FastMCP(
    name = "FeatureImportanceServer",
    stateless_http = True
)


@feature_importance_mcp.tool(
    description="""모델 파일을 로드해서 feature importance top 3개를 출력합니다."""
)
def get_ml_feature_importance(csv_file_path: str):
    """CSV 파일에서 모델 경로를 추출하고 feature importance를 추출하는 함수"""
    try:
        # CSV 파일 경로 확인
        csv_path = file_handler.get_file_path(csv_file_path)
        if not csv_path:
            return {
                "error": f"CSV 파일 경로를 찾을 수 없습니다: {csv_file_path}",
                "suggestion": "파일 경로를 확인해주세요",
            }

        # CSV 파일 읽기
        try:
            df = pd.read_csv(csv_path)
            print(f"CSV 파일 내용: {df.head()}")
        except Exception as e:
            return {"error": f"CSV 파일 읽기 오류: {str(e)}", "csv_path": csv_file_path}

        # model_path 컬럼에서 모델 파일 경로 추출
        if 'model_path' not in df.columns:
            return {
                "error": "CSV 파일에 'model_path' 컬럼이 없습니다",
                "available_columns": list(df.columns),
                "suggestion": "CSV 파일 구조를 확인해주세요"
            }

        # 첫 번째 행의 model_path 사용
        model_path = df.iloc[0]['model_path']
        print(f"추출된 모델 경로: {model_path}")

        # 모델 로드
        try:
            model = load_model(model_path)  # load_model 내부에서 file_handler 사용
        except Exception as e:
            return {"error": f"모델 로드 중 오류: {str(e)}", "model_path": model_path}

        # Feature importance 추출
        try:
            feature_importance_data = extract_feature_importance(model)
        except Exception as e:
            return {
                "error": f"Feature importance 추출 중 오류: {str(e)}",
                "model_path": model_path,
            }

        # Feature importance 분석 (feature_names는 None으로 전달)
        analysis_result = analyze_feature_importance(feature_importance_data, None)

        if isinstance(analysis_result, dict) and "error" in analysis_result:
            return analysis_result

        # 결과 반환 (상위 3개만)
        result = []
        if isinstance(analysis_result, list):
            for feature in analysis_result[:3]:  # 상위 3개만 처리
                if (
                    isinstance(feature, dict)
                    and "feature" in feature
                    and "importance" in feature
                ):
                    result.append(str(feature["feature"]))
        print(result)

        return result

    except Exception as e:
        return {
            "error": str(e),
            "suggestion": "입력 데이터를 확인하고 다시 시도해주세요",
        }


def load_model(model_path: str):
    """LightGBM과 XGBoost 모델 파일을 로드하는 함수"""
    try:
        # file_handler를 사용해서 파일 경로 확인
        file_path = file_handler.get_file_path(model_path)
        if not file_path:
            raise ValueError(f"파일 경로를 찾을 수 없습니다: {model_path}")

        # 파일 확장자 확인
        file_extension = file_path.lower().split(".")[-1] if "." in file_path else ""

        if file_extension == "pkl":
            # pickle 파일 로딩 시도
            try:
                # 방법 1: 기본 pickle 로딩
                with open(file_path, "rb") as f:
                    model = pickle.load(f)
            except Exception as e1:
                try:
                    # 방법 2: joblib으로 시도
                    model = joblib.load(file_path)
                except Exception as e2:
                    # 모든 방법 실패 시 상세한 오류 정보 제공
                    error_details = {
                        "pickle_basic_error": str(e1),
                        "joblib_error": str(e2),
                    }
                    raise ValueError(f"모델 파일 로딩 실패. 상세 오류: {error_details}")
        elif file_extension == "joblib":
            model = joblib.load(file_path)
        else:
            raise ValueError(f"지원하지 않는 모델 파일 형식입니다: {file_extension}")

        return model
    except Exception as e:
        raise ValueError(f"모델 로드 중 오류가 발생했습니다: {str(e)}")


def extract_feature_importance(model, model_type: Optional[str] = None):
    """LightGBM과 XGBoost 모델에서 feature importance를 추출하는 함수"""
    try:
        # 모델 타입 자동 감지
        if model_type is None:
            model_type = type(model).__name__

        feature_importance = {}

        # XGBoost 모델 처리
        if "XGB" in model_type or "XGBoost" in model_type:
            try:
                # XGBoost의 gain 기반 feature importance 추출
                importance_dict = model.get_booster().get_score(importance_type="gain")

                # 딕셔너리를 리스트로 변환하고 정렬
                importance_items = list(importance_dict.items())
                importance_items.sort(key=lambda x: x[1], reverse=True)

                # feature names와 values 분리
                feature_names = [item[0] for item in importance_items]
                importance_values = [item[1] for item in importance_items]

                feature_importance["type"] = "xgboost_gain"
                feature_importance["values"] = importance_values
                feature_importance["feature_names"] = feature_names
                feature_importance["model_type"] = model_type

            except Exception as e:
                # XGBoost gain 추출 실패 시 기본 feature_importances_ 사용
                if hasattr(model, "feature_importances_"):
                    feature_importance["type"] = "feature_importances"
                    feature_importance["values"] = model.feature_importances_.tolist()
                    feature_importance["model_type"] = model_type
                else:
                    raise ValueError(
                        f"XGBoost 모델에서 feature importance를 추출할 수 없습니다: {str(e)}"
                    )

        # LightGBM 모델처리
        elif (
            "LGBM" in model_type
            or "LGBMClassifier" in model_type
            or "LGBMRegressor" in model_type
        ):
            try:
                # LightGBM의 feature importance 추출 (gain 기준 우선 시도)
                if hasattr(model, "feature_importances_"):
                    # gain 기준으로 feature importance 추출 시도
                    try:
                        if hasattr(model, "booster_") and model.booster_:
                            # gain 기준 feature importance 추출
                            gain_importance = model.booster_.feature_importance(
                                importance_type="gain"
                            )
                            # numpy 배열인 경우를 고려하여 안전하게 확인
                            if (
                                gain_importance is not None
                                and len(gain_importance) > 0
                                and np.any(gain_importance)
                            ):
                                feature_importance["type"] = "lightgbm_gain"
                                feature_importance["values"] = (
                                    gain_importance.tolist()
                                    if hasattr(gain_importance, "tolist")
                                    else gain_importance
                                )
                                feature_importance["model_type"] = model_type
                            else:
                                # gain이 없으면 기본 split 사용
                                feature_importance["type"] = "lightgbm_split"
                                feature_importance["values"] = (
                                    model.feature_importances_.tolist()
                                )
                                feature_importance["model_type"] = model_type
                        else:
                            # booster가 없으면 기본 split 사용
                            feature_importance["type"] = "lightgbm_split"
                            feature_importance["values"] = (
                                model.feature_importances_.tolist()
                            )
                            feature_importance["model_type"] = model_type
                    except Exception:
                        # gain 추출 실패 시 기본 split 사용
                        feature_importance["type"] = "lightgbm_split"
                        feature_importance["values"] = (
                            model.feature_importances_.tolist()
                        )
                        feature_importance["model_type"] = model_type

                    # LightGBM에서 feature names 추출 시도 (디버깅용)
                    print(f"[DEBUG] LightGBM 모델 타입: {type(model)}")
                    print(f"[DEBUG] 모델의 모든 속성: {dir(model)}")
                    # 가장 많이 쓰는 속성만 시도
                    if hasattr(model, "feature_name_") and model.feature_name_:
                        print(f"[DEBUG] feature_name_ 사용: {model.feature_name_}")
                        feature_importance["feature_names"] = model.feature_name_
                    elif hasattr(model, "feature_names") and model.feature_names:
                        print(f"[DEBUG] feature_names 사용: {model.feature_names}")
                        feature_importance["feature_names"] = model.feature_names
                    elif hasattr(model, "booster_") and model.booster_:
                        if (
                            hasattr(model.booster_, "feature_name")
                            and model.booster_.feature_name
                        ):
                            print(
                                f"[DEBUG] booster_.feature_name 사용: {model.booster_.feature_name}"
                            )
                            feature_importance["feature_names"] = (
                                model.booster_.feature_name
                            )
                        elif (
                            hasattr(model.booster_, "feature_names")
                            and model.booster_.feature_names
                        ):
                            print(
                                f"[DEBUG] booster_.feature_names 사용: {model.booster_.feature_names}"
                            )
                            feature_importance["feature_names"] = (
                                model.booster_.feature_names
                            )
                    else:
                        print("[DEBUG] feature names를 찾을 수 없음")
                else:
                    raise ValueError(
                        "LightGBM 모델에서 feature_importances_를 찾을 수 없습니다"
                    )
            except Exception as e:
                raise ValueError(
                    f"LightGBM 모델에서 feature importance를 추출할 수 없습니다: {str(e)}"
                )

        # 지원하지 않는 모델 타입
        else:
            raise ValueError(
                f"지원하지 않는 모델 타입입니다: {model_type}. LightGBM과 XGBoost 모델만 지원합니다."
            )

        return feature_importance

    except Exception as e:
        raise ValueError(f"Feature importance 추출 중 오류가 발생했습니다: {str(e)}")


def analyze_feature_importance(
    feature_importance: Dict[str, Any], feature_names: Optional[List[str]] = None
) -> Union[List[Dict[str, Any]], Dict[str, str]]:
    """Feature importance를 분석하고 top 3개를 반환하는 함수"""
    try:
        values = feature_importance.get("values", [])
        if not values:
            return {
                "error": "Feature importance 값이 없습니다",
                "suggestion": "모델이 feature importance를 제공하지 않거나 추출할 수 없습니다",
            }

        # XGBoost 모델의 경우 내장된 feature names 사용
        if (
            feature_importance.get("type") == "xgboost_gain"
            and "feature_names" in feature_importance
        ):
            feature_labels = feature_importance["feature_names"]
        # LightGBM 모델의 경우 내장된 feature names 사용 (gain 또는 split)
        elif (
            feature_importance.get("type")
            in ["lightgbm_gain", "lightgbm_split", "feature_importances"]
        ) and "feature_names" in feature_importance:
            feature_labels = feature_importance["feature_names"]
        # 사용자가 제공한 feature names가 있으면 사용
        elif feature_names is not None and len(feature_names) == len(values):
            feature_labels = feature_names
        else:
            feature_labels = [f"Feature_{i}" for i in range(len(values))]

        # 상위 3개 feature만 추출
        sorted_indices = np.argsort(values)[::-1]  # 내림차순

        top_3_features = []
        for i in range(min(3, len(sorted_indices))):
            idx = sorted_indices[i]
            feature_name = str(feature_labels[idx])
            
            # 특정 패턴 변환
            if feature_name == "slab_grind_HSHS":
                feature_name = "slab_grind"
            elif "ap_plant_1공장" in feature_name:
                feature_name = "ap_plant"
            
            top_3_features.append(
                {"feature": feature_name, "importance": float(values[idx])}
            )

        return top_3_features

    except Exception as e:
        return {"error": f"Feature importance 분석 중 오류가 발생했습니다: {str(e)}"}


feature_importance_app = feature_importance_mcp.http_app()
