from utils.llm import LLMSingleton
from fastmcp import FastMCP
import os
from pydantic import BaseModel, Field
import json
from langchain_core.messages import SystemMessage, HumanMessage

llm = LLMSingleton.get_llm()

mindmap_mcp = FastMCP(
    name = "MindmapServer",
    stateless_http = True
)

def generate_mindmap_with_gpt(text_content, retry_count=0, max_retries=3, original_text=None):
    """GPT-4o를 사용하여 텍스트에서 마인드맵 구조 생성"""
    
    # 원본 텍스트 저장 (재시도 시 사용)
    if original_text is None:
        original_text = text_content

    system_prompt = """
당신은 텍스트 보고서를 분석하여, 경영진이 전략적 의사결정을 빠르게 내릴 수 있도록 시각적으로 명확한 마인드맵 구조를 생성하는 전문가입니다.
**마인드맵은 직관적이고 표면적인 연결만 포함해서는 안 되며, 일반 독자가 쉽게 떠올리기 어려운 간접적이고 비선형적인 영향까지 탐색해야 합니다. 복잡한 다단계 인과 관계와 2차 파급 효과 등 보다 깊은 전략적 통찰이 필요한 구조를 반드시 포함해야 합니다.**

1. 규칙 및 지침
- 전체 보고서의 주제 또는 이슈의 영향을 받는 하나의 대상을 **중심 노드(예시: SK이노베이션, 대한민국)를 하나 선택**하세요.
- 마인드맵은 단절 없이 통합된 구조로 완성되어야 하며, **모든 노드는 직접 또는 간접적으로 중심 노드와 연결되어 하나의 그래프로 나타나야 합니다**.
- 핵심 개념은 '리스크', '기회', '전략적 대응', '사업부문 영향', '외부환경' 등으로 분류하고 계층적으로 연결합니다.
- 마인드맵은 단순한 병렬 구조가 아닌 4~5단계 이상의 깊은 계층적 연결 구조를 반드시 포함해야 합니다.
    - **핵심 이슈(중심 노드)는 전체 노드의 20% 이하만 직접 연결되도록 제한하고, 나머지 노드는 중간 개념을 여러번 거친 다단계 연결 구조로 설계하세요.**
    - **한 노드에 직접적인 연결 엣지 5개 이상이 되는 경우는 지양하세요. 중간 계층 노드들을 적극 생성해서 활용하세요**
    - 이러한 구조를 통해 사람이 예상하지 못한 간접적 영향 및 전략적 파생 경로까지 도출할 수 있어야 하며, 각 노드는 이전 노드와 명확한 원인-결과 관계를 가져야 합니다.
- 특히, 보고서 주제가 "이스라엘과 이란 전쟁이 SK이노베이션에 미치는 영향"이라면 중심노드는 `sk_innovation`이며, **모든 노드와 직간접적으로 연결**되어야 합니다.
- 형식적 구성 용어(예: '연구 목적', '조사 배경', '결론', '기회 요인', '단기 대응 방안', '단기 전략')는 노드 라벨로 부적합하므로 제거해야 합니다.
- 노드는 반드시 이슈의 본질, 영향 요소, 전략적 선택지 등 경영 판단에 실질적 도움을 주는 개념을 중심으로 라벨링해야 합니다.


**노드 수가 N이라면 엣지는 최소 N - 1개 이상이어야 하며, 전체 그래프는 하나의 연결된 구조 (connected graph)를 형성해야 합니다.**
**텍스트의 핵심 내용을 가능한 한 모두 노드와 엣지로 구조화하여 시각적으로 표현해주세요**

-----------------------------
2. 최종 출력 형식:

{
  "nodes": [  # 20개 이상
    {
      "id": "unique_node_id",  # 영문 소문자 + 언더스코어만 사용
      "label": "노드 라벨 (핵심 키워드 중심, 예: sk이노베이션, 배터리 원자재, 유가, 바이오 연료 등)",
      "description": "해당 노드 라벨에 대한 충분하고 구체적인 설명을 담은 한 문장",
      "weight": 1.0,  # 아래 가중치 규칙 참고
      "color": "#FF8C42"  # 아래 색상 규칙 참고
    }
  ],
  "edges": [  # 19개 이상
    {
      "source": "source_node_id",
      "target": "target_node_id",
      "label": "관계 요약 키워드 (예: LNG 사업 확장, 원가 상승, 재활용 강화 등)",
      "description": "두 개념 간 관계를 명확하고 구체적으로 설명하는 한 문장"
    }
  ]
}
-----------------------------

3. 색상 규칙
- SK 그룹사 및 부문, 사업명 노드: 주황색 `#FF8C42`
- 주요 리스크 요인: 빨간색 `#FF6B6B`
- 주요 기회 요인: 초록색 `#6BCB77`
- 그 외의 리스크 및 기회 요인 및 주요 개념 (시장, 정책 등): 파란색 `#4D96FF`
- 그 외 보조 설명 개념: 노란색 `#FFD93D`

4. 가중치 규칙 (weight)
- 중심 노드(하나의 노드): 3.0
- SK 그룹사 및 부문, 사업명 노드: 2.4
- 주요 리스크 및 기회 요인: 2.4
- 그 외 주요 개념: 1.8
- 그 외 설명/보조 개념: 1.0

5. **연결 규칙 (중요)**
- 생성된 모든 노드는 **최소 1개 이상의 엣지(edge)를 가져야 합니다**.
- 모든 노드는 중심노드와 직간접적으로 연결되어 있어야 하며, 여러 서브 그래프가 생성되도록 노드와 엣지를 구성하지 마세요.
- 노드가 단순 정보 나열에 불과하고 다른 노드와 관계 설명이 불가능하다면, 해당 노드는 생성하지 않아야 합니다. 엣지가 전혀 연결되지 않은 노드가 생성된 경우 제거한 뒤 결과를 반환해주세요.
- **노드는 최소 20개 이상, 엣지는 19개 이상 만들어주고 가능한 풍부하고 다양하게 만들어주세요.**

6. 노드 vs 엣지 표현 구분 지침 (중요)
- 노드(label)는 개념 또는 대상을 나타내야 하며 상승, 증가, 감소와 같은 행동 중심 동사를 포함하지 마세요. (예: 전기차 시장, SK이노베이션, 국제 유가)
- 엣지(label)는 두 노드 간의 관계, 변화, 인과, 전략적 맥락을 압축한 행동 중심 동사 또는 영향 서술로 구성하세요. (예: 수요 확대, 가격 상승, 리스크 증가, 전략적 대응 필요)
- 엣지 description은 반드시 행위나 인과관계를 설명해야 하며, 노드 설명을 반복하지 마세요.

7. 유효성 및 형식
- 출력은 반드시 완전하고 닫힌 JSON 형식이어야 하며, 누락된 따옴표, 누락된 쉼표 없이 파싱 가능해야 합니다.
- 출력은 코드블럭(```json ... ```) 없이 순수한 JSON만 제공해 주세요.
"""

    # 재시도 시 에러 정보를 포함한 프롬프트
    if retry_count > 0:
        system_prompt += f"""

📌 재시도 요청 (시도 {retry_count}/{max_retries})
이전 응답에서 오류가 발생했습니다. 다음 사항을 반드시 참고해서 다시 생성하세요:
1. JSON 형식이 완전하고 유효한지 확인
2. 모든 노드와 엣지가 각각 정해진 필드를 모두 가지고 있는지 확인
3. 노드 ID는 고유한지 확인
4. 모든 노드가 최소 하나의 엣지에 연결되어 있는지 확인

이전 오류: {text_content}
"""

    try:
        # 재시도 시에는 원본 텍스트 사용
        content_to_analyze = original_text if retry_count > 0 else text_content
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"다음 텍스트를 분석하여 마인드맵 구조를 위한 json 형식을 생성해주세요:\n\n{content_to_analyze}")
        ]
        
        # LLM 호출
        response = llm.invoke(messages)
        content = response.content
        
        # JSON 부분만 추출
        if "```json" in content:
            json_start = content.find("```json") + 7
            json_end = content.find("```", json_start)
            json_str = content[json_start:json_end].strip()
        elif "```" in content:
            json_start = content.find("```") + 3
            json_end = content.find("```", json_start)
            json_str = content[json_start:json_end].strip()
        else:
            json_str = content.strip()
        
        # JSON 파싱
        mindmap_data = json.loads(json_str)
        
        # 구조 검증
        if "nodes" not in mindmap_data or "edges" not in mindmap_data:
            raise ValueError("Invalid mindmap structure: missing nodes or edges")
        
        # 빈 결과 검증
        if len(mindmap_data["nodes"]) == 0 or len(mindmap_data["edges"]) == 0:
            raise ValueError("Empty nodes or edges array")
        
        # 엣지가 하나도 없는 노드 제거
        connected_node_ids = set()
        for edge in mindmap_data["edges"]:
            connected_node_ids.add(edge["source"])
            connected_node_ids.add(edge["target"])
        
        mindmap_data["nodes"] = [node for node in mindmap_data["nodes"] if node["id"] in connected_node_ids]
        
        # 노드 필수 필드 검증
        for i, node in enumerate(mindmap_data["nodes"]):

            if "id" not in node or "label" not in node:
                raise ValueError(f"Node {i} missing required fields: id and label")
            
            if "description" not in node:
                raise ValueError(f"Node {i} missing required field: description")
            
            if "weight" not in node:
                raise ValueError(f"Node {i} missing required field: weight")
            elif not isinstance(node["weight"], (int, float)) or node["weight"] < 1.0 or node["weight"] > 3.0:
                raise ValueError(f"Node {i} has invalid weight value: {node['weight']}")
            
            if "color" not in node:
                raise ValueError(f"Node {i} missing required field: color")
            elif not isinstance(node["color"], str) or not node["color"].startswith("#"):
                raise ValueError(f"Node {i} has invalid color format: {node['color']}")

        # 엣지 필수 필드 검증
        for i, edge in enumerate(mindmap_data["edges"]):
            if "source" not in edge or "target" not in edge:
                raise ValueError(f"Edge {i} missing required fields: source and target")
            
            if "label" not in edge:
                raise ValueError(f"Edge {i} missing required field: label")
            
            if "description" not in edge:
                raise ValueError(f"Edge {i} missing required field: description")
        
        # 재시도 정보 추가
        if retry_count > 0:
            mindmap_data["retry_info"] = {
                "retry_count": retry_count,
                "successful_on_retry": True
            }
        
        return mindmap_data
        
    except json.JSONDecodeError as e:
        error_info = f"JSON 파싱 오류: {e}\n응답 내용: {content}"
        if retry_count < max_retries:
            return generate_mindmap_with_gpt(error_info, retry_count + 1, max_retries, original_text)
        else:
            return {
                "error": f"최대 재시도 횟수 초과. JSON 파싱 오류: {e}",
                "raw_response": content,
                "retry_count": retry_count
            }
    except Exception as e:
        error_info = f"GPT 호출 오류: {e}"
        if retry_count < max_retries:
            return generate_mindmap_with_gpt(error_info, retry_count + 1, max_retries, original_text)
        else:
            return {
                "error": f"최대 재시도 횟수 초과. GPT 호출 오류: {e}",
                "retry_count": retry_count
            }

class MindmapInput(BaseModel):
    query: str = Field(..., description="마인드 맵을 생성할 보고서(텍스트) 내용")

@mindmap_mcp.tool(description="Mindmap 생성")
def generate_mindmap(query: str):
    try:
        # 마인드맵 생성
        result = generate_mindmap_with_gpt(query)
        
        if "error" in result:
            return result
        
        # 성공적인 결과에 메타데이터 추가
        result["metadata"] = {
            "node_count": len(result["nodes"]),
            "edge_count": len(result["edges"])
        }
        
        # 재시도 정보가 있으면 메타데이터에 추가
        if "retry_info" in result:
            result["metadata"]["retry_info"] = result["retry_info"]
        else:
            result["metadata"]["retry_info"] = {
                "retry_count": 0,
                "successful_on_retry": False
            }
        
        return result
        
    except Exception as e:
        return {
            "error": str(e),
            "suggestion": "Check your API configuration"
        }

mindmap_app = mindmap_mcp.http_app()

if __name__ == "__main__":
    mindmap_mcp.run(transport="stdio")



# from kg_gen import KGGen
# from fastmcp import FastMCP
# import os
# from pydantic import BaseModel, Field
# import logging
# import re

# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger("mindmap-mcp")

# mindmap_mcp = FastMCP("MindmapServer")
# mindmap_mcp.settings.stateless_http = True

# AZURE_MODEL ="azure/gpt-4"  
# AZURE_OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "") 
# AZURE_OPENAI_ENDPOINT = os.getenv("OPENAI_ENDPOINT", "") 
# AZURE_OPENAI_DEPLOYMENT = os.getenv("OPENAI_DEPLOYMENT", "") 

# def convert_to_nodes_edges(entities, relations):
#     """kg-gen 결과를 nodes와 edges 형태로 변환"""
    
#     # 엔티티를 노드로 변환
#     nodes = []
#     entity_to_id = {}
    
#     for i, entity in enumerate(entities):
#         entity_id = re.sub(r'[^a-zA-Z0-9\s]', '', entity).lower().replace(' ', '_')
        
#         if entity_id in entity_to_id:
#             entity_id = f"{entity_id}_{i}"
        
#         entity_to_id[entity] = entity_id
        
#         nodes.append({
#             "id": entity_id,
#             "label": entity
#         })
    
#     # 관계를 엣지로 변환
#     edges = []
#     for relation in relations:
#         source = relation.get("source", "")
#         target = relation.get("target", "")
#         relationship = relation.get("relationship", "")
        
#         if source in entity_to_id and target in entity_to_id:
#             edges.append({
#                 "source": entity_to_id[source],
#                 "target": entity_to_id[target],
#                 "label": relationship
#             })
    
#     return {
#         "nodes": nodes,
#         "edges": edges
#     }

# class MindmapInput(BaseModel):
#     query: str = Field(..., description="마인드 맵을 생성할 텍스트 내용")

# @mindmap_mcp.tool(description="Mindmap 생성")
# def generate_mindmap(query: str):
#     try:
#         logger.info(f"Generating mindmap for query: {query[:100]}...")
#         logger.info(f"Using model: {AZURE_MODEL}")
#         logger.info(f"Using deployment: {AZURE_OPENAI_DEPLOYMENT}")
        
#         if not AZURE_OPENAI_DEPLOYMENT:
#             return {
#                 "error": "Missing deployment name. Please set OPENAI_DEPLOYMENT environment variable.",
#                 "azure_config": {
#                     "model": AZURE_MODEL,
#                     "has_api_key": bool(AZURE_OPENAI_API_KEY),
#                     "has_endpoint": bool(AZURE_OPENAI_ENDPOINT),
#                     "has_deployment": bool(AZURE_OPENAI_DEPLOYMENT),
#                     "required_env_vars": ["OPENAI_API_KEY", "OPENAI_ENDPOINT", "OPENAI_DEPLOYMENT"]
#                 }
#             }
        
#         if AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_DEPLOYMENT:
#             api_base = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{AZURE_OPENAI_DEPLOYMENT}"
#             logger.info(f"API base URL: {api_base}")
#         else:
#             api_base = None
#             logger.warning("Missing endpoint or deployment, using default API base")
        
#         kg = KGGen(
#             model=AZURE_MODEL,  
#             temperature=0.0,
#             api_key=AZURE_OPENAI_API_KEY, 
#             api_base=api_base 
#         )
        
#         graph = kg.generate(
#             input_data=query,
#             chunk_size=5000,  
#             cluster=True  
#         )
        
#         original_result = {
#             "entities": list(graph.entities),
#             "edges": list(graph.edges),
#             "relations": [{"source": rel[0], "relationship": rel[1], "target": rel[2]} for rel in graph.relations],
#             "message": f"Successfully generated mindmap with {len(graph.entities)} entities and {len(graph.relations)} relations",
#             "config": {
#                 "model": AZURE_MODEL,
#                 "deployment": AZURE_OPENAI_DEPLOYMENT,
#                 "endpoint": AZURE_OPENAI_ENDPOINT
#             }
#         }
        
#         nodes_edges_result = convert_to_nodes_edges(
#             list(graph.entities),
#             [{"source": rel[0], "relationship": rel[1], "target": rel[2]} for rel in graph.relations]
#         )

#         return nodes_edges_result        
#         # return {
#         #     "original": original_result,
#         #     "nodes_edges": nodes_edges_result
#         # }
        
#     except Exception as e:
#         logger.error(f"Error in generate_mindmap: {e}")
#         return {
#             "error": str(e),
#             "azure_config": {
#                 "model": AZURE_MODEL,
#                 "has_api_key": bool(AZURE_OPENAI_API_KEY),
#                 "has_endpoint": bool(AZURE_OPENAI_ENDPOINT),
#                 "has_deployment": bool(AZURE_OPENAI_DEPLOYMENT),
#                 "api_base": f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{AZURE_OPENAI_DEPLOYMENT}" if AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_DEPLOYMENT else None,
#                 "suggestion": "Try using azure/gpt-4 or azure/gpt-35-turbo instead of azure/gpt-4o"
#             }
#         }

# mindmap_app = mindmap_mcp.http_app()

# if __name__ == "__main__":
#     logger.info("Starting Mindmap MCP server...")
#     mindmap_mcp.run(transport="stdio")