from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
from dotenv import load_dotenv
from typing import Optional, Dict, Any, List
import pandas as pd
import numpy as np
import json
import os
import datetime
from fastmcp import FastMCP
from utils.llm import LLMSingleton
import re
import ast
from mcpserver.functions.file_handler import FileHandler
file_handler = FileHandler()

load_dotenv()
llm = LLMSingleton.get_llm()

data_processor_mcp = FastMCP(
    name = "DataProcessor",
    stateless_http = True
)

@data_processor_mcp.tool(description="""분석 계획에 따라 각각의 차트 생성을 위한 데이터를 전처리하여 각각의 파일로 저장합니다.""")
def data_preprocess(file_path: str, plan: str) -> List[Dict[str, str]]:
    
    try:
        raw_data = load_data(file_path, 100000)
        file_extension = os.path.splitext(file_path)[-1].lower()
        
        try:
            graph_requirements = analyze_plan(plan, raw_data)
            preprocessing_requirements = analyze_plan_for_propocessing(plan, raw_data)
            print(f"그래프 한줄 설명: {graph_requirements}")
            print(f"그래프 전처리 요구사항: {preprocessing_requirements}")
        except Exception as e:
            print(f"계획 분석 중 예외 발생: {str(e)}")
            import traceback
            traceback.print_exc()

            graph_requirements = [
                {
                    "description": "기본 데이터 분석"
                }
            ]

        graph_analyses = []
        
        for i, requirement in enumerate(graph_requirements):
            try:
                preprocessing_plan = preprocessing_requirements[i]['preprocessing_plan']
                query = "그래프 설명: " + requirement['description'] + "\n전처리 방법: " + preprocessing_plan
                preprocessing_code = generate_preprocessing_code(raw_data, query)
                print(f"생성된 전처리 코드:\n{preprocessing_code}")
                cleaned_code = validate_and_clean_code(preprocessing_code)
                
                processed_data, execution_success, error_msg = execute_preprocessing_code(cleaned_code, raw_data)
                
                if execution_success:

                    output_file_path = save_processed_data(processed_data, file_path, file_extension, f"analysis_{i+1}")
                    graph_analysis = {
                        "chart_type": requirement['description'],
                        "pre_processed_file_path": output_file_path
                    }
                    graph_analyses.append(graph_analysis)
                else:
                    print(f"분석 {i+1} 처리 실패: {error_msg}")
                    
            except Exception as e:
                print(f"분석 {i+1} 처리 중 오류: {str(e)}")
                import traceback
                traceback.print_exc()
                continue
        
        print(graph_analyses)
        return graph_analyses
            
    except Exception as e:
        return []

def load_data(file_path: str, max_rows: int = 10000) -> Dict[str, Any]:
    """
    파일을 로드하여 데이터와 메타데이터를 반환 (행 수 제한)
    """

    actual_file_path = file_handler.get_file_path(file_path)
    if not actual_file_path or not os.path.exists(actual_file_path):
        raise ValueError(f"파일을 찾을 수 없습니다: {file_path}")
    
    ext = os.path.splitext(actual_file_path)[-1].lower()
    
    if ext == '.csv':

        encodings = ['utf-8', 'euc-kr', 'cp949', 'latin1', 'iso-8859-1']
        df = None
        
        for encoding in encodings:
            try:
                df = pd.read_csv(actual_file_path, nrows=max_rows, encoding=encoding)
                break
            except UnicodeDecodeError:
                continue
            except Exception as e:
                continue
        
        if df is None:
            raise ValueError("지원되는 인코딩으로 파일을 읽을 수 없습니다. (utf-8, euc-kr, cp949, latin1, iso-8859-1)")

        data = df.to_dict(orient='records')
        
    elif ext == '.json':
        with open(actual_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, dict):

                data = [{'key': k, 'value': v} for k, v in data.items()]
            
            if isinstance(data, list) and len(data) > max_rows:
                data = data[:max_rows]
    else:
        raise ValueError("지원하지 않는 파일 형식입니다. (csv, json만 지원)")

    df = pd.DataFrame(data)
    metadata = {
        'columns': list(df.columns),
        'dtypes': {col: str(df[col].dtype) for col in df.columns},
        'shape': df.shape,
        'null_counts': df.isnull().sum().to_dict(),
        'unique_counts': {col: df[col].nunique() for col in df.columns}
    }
    
    return {
        'data': data,
        'metadata': metadata,
        'dataframe': df
    }

def analyze_plan(plan: str, raw_data: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    분석 계획을 분석하여 필요한 그래프들을 파악
    """
    df = raw_data['dataframe']
    profile = extract_data_profile(df, n=5)
    
    system_prompt = """
    분석 계획을 읽고 몇개의 그래프가 필요한지 판단하고 그에 맞는 데이터 분석들을 파악하여 JSON 형태로 반환하세요.
    
    [중요한 데이터 분석 원칙]
    - 특정 월이나 기간에 대한 분석 요청이 있어도, 비교 분석을 위해 전체 기간의 데이터를 월별/기간별로 그룹화하여 패턴을 파악해야 합니다.
    - 단순히 특정 기간만 필터링하는 것이 아니라, 전체 기간을 기준으로 비교 분석이 가능하도록 description을 작성해주세요.
    - 예: "9월 불량품 발생 원인" → "월별 불량품 발생률 비교 분석" (9월만 분석하는 것이 아니라, 전체 기간을 월별로 그룹화하여 9월의 특이점을 찾을 수 있도록)
    - 시간 축이 포함된 분석은 반드시 "월별", "기간별", "시계열" 등의 표현을 포함해야 합니다.
    
    각 분석에 대해 다음 정보를 제공하세요:
    - description: 데이터 분석에 대한 간단한 설명 (위 원칙에 따라 전체 기간 비교 분석 관점으로 작성)
    
    반드시 다음 형식으로만 응답하세요 (개행문자나 추가 공백 없이)
    예시:
    [{{"description":"월별 장입 온도별 불량률 비교"}},{{"description":"월별 슬라브 그라인딩 방법의 상관관계 히트맵"}},{{"description":"월별 공장별 불량률 비교"}}]
    
    가능한 컬럼들: {columns}
    샘플 데이터: {sample_data}
    
    JSON 형식으로만 응답하세요.
    """
    
    user_prompt = f"""
    분석 계획: {plan}
    
    데이터 컬럼: {profile['columns']}
    샘플 데이터: {profile['sample_rows'][0] if profile['sample_rows'] else {}}
    
    이 계획에 따라 필요한 데이터 분석들을 파악해주세요.
    """
    
    messages = [
        SystemMessage(content=system_prompt.format(
            columns=profile['columns'],
            sample_data=profile['sample_rows'][0] if profile['sample_rows'] else {}
        )),
        HumanMessage(content=user_prompt)
    ]
    
    response = llm.invoke(messages)
    print(f"LLM 응답: {response.content}")
    try:
        cleaned_response = response.content.strip()
        
        if '```' in cleaned_response:
            import re
            code_pattern = r'```(?:json)?\s*(.*?)\s*```'
            match = re.search(code_pattern, cleaned_response, re.DOTALL)
            if match:
                cleaned_response = match.group(1).strip()
        
        analysis_requirements = json.loads(cleaned_response)
        
        if not isinstance(analysis_requirements, list):
            raise ValueError("응답이 리스트 형태가 아닙니다.")
        
        for req in analysis_requirements:
            if not isinstance(req, dict) or 'description' not in req:
                raise ValueError("분석 요구사항에 필수 필드가 없습니다.")
        
        return analysis_requirements
        
    except (json.JSONDecodeError, ValueError) as e:
        try:
            import re
            description_pattern = r'"description"\s*:\s*"([^"]+)"'
            descriptions = re.findall(description_pattern, response.content)
            
            if descriptions:
                analysis_requirements = [{"description": desc} for desc in descriptions]
                return analysis_requirements
        except Exception as regex_error:
            pass
        
        return [
            {
                "description": "기본 데이터 분석"
            }
        ]

def analyze_plan_for_propocessing(plan: str, raw_data: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    분석 계획을 분석하여 필요한 그래프들을 파악
    """
    df = raw_data['dataframe']
    profile = extract_data_profile(df, n=5)
    
    system_prompt = """
    분석 계획을 읽고 몇개의 그래프가 필요한지 판단하고 그에 맞는 데이터 전처리 기법을 파악하여 JSON 형태로 반환하세요.
    
    [중요한 데이터 전처리 원칙]
    - 특정 월이나 기간에 대한 분석 요청이 있어도, 비교 분석을 위해 전체 기간의 데이터를 월별/기간별로 그룹화하여 패턴을 파악해야 합니다.
    - 단순히 특정 기간만 필터링하는 것이 아니라, 전체 기간을 기준으로 비교 분석이 가능하도록 전처리 방법을 작성해주세요.
    - 예: "9월 불량품 발생 원인" → 9월만 분석하는 것이 아니라, 전체 기간을 월별로 그룹화하여 9월의 특이점을 찾아야 합니다.
    - 시간 축이 포함된 전처리는 반드시 전체 기간을 월별/기간별로 그룹화하는 방식을 사용해야 합니다.
    
    각 분석에 대해 다음 정보를 제공하세요:
    - preprocessing_plan: 데이터 전처리 방법에 대한 설명 (위 원칙에 따라 전체 기간 비교 분석이 가능하도록 작성)
    
    반드시 다음 형식으로만 응답하세요 (개행문자나 추가 공백 없이)
    예시:
    [{{"preprocessing_plan":"전체 기간 데이터를 월별로 그룹화하고, 장입 온도를 100도 단위로 구간화한 후, 각 (월, 온도구간) 조합별 불량률 계산"}},{{"preprocessing_plan":"전체 기간 데이터를 월별로 그룹화하고, 슬라브 그라인딩 방법을 카테고리로 분류한 후, 각 (월, 그라인딩 방법) 조합별 상관관계 분석"}},{{"preprocessing_plan":"전체 기간 데이터를 월별로 그룹화하고, 각 월별 공장별 불량률 계산"}}]
    
    가능한 컬럼들: {columns}
    샘플 데이터: {sample_data}
    
    JSON 형식으로만 응답하세요.
    """
    
    user_prompt = f"""
    분석 계획: {plan}
    
    데이터 컬럼: {profile['columns']}
    샘플 데이터: {profile['sample_rows'][0] if profile['sample_rows'] else {}}
    
    이 계획에 따라 필요한 데이터 분석들을 파악해주세요.
    """
    
    messages = [
        SystemMessage(content=system_prompt.format(
            columns=profile['columns'],
            sample_data=profile['sample_rows'][0] if profile['sample_rows'] else {}
        )),
        HumanMessage(content=user_prompt)
    ]
    
    response = llm.invoke(messages)
    
    print(f"LLM 응답 (전처리 계획): {response.content}")
    
    try:
        cleaned_response = response.content.strip()
        
        if '```' in cleaned_response:
            import re
            code_pattern = r'```(?:json)?\s*(.*?)\s*```'
            match = re.search(code_pattern, cleaned_response, re.DOTALL)
            if match:
                cleaned_response = match.group(1).strip()

        preprocessing_requirements = json.loads(cleaned_response)

        if not isinstance(preprocessing_requirements, list):
            raise ValueError("응답이 리스트 형태가 아닙니다.")
        
        for req in preprocessing_requirements:
            if not isinstance(req, dict) or 'preprocessing_plan' not in req:
                raise ValueError("분석 요구사항에 필수 필드가 없습니다.")
        
        return preprocessing_requirements
        
    except (json.JSONDecodeError, ValueError) as e:
        try:
            import re

            preprocessing_plan_pattern = r'"preprocessing_plan"\s*:\s*"([^"]+)"'
            preprocessing_plan = re.findall(preprocessing_plan_pattern, response.content)
            
            if preprocessing_plan:
                analysis_requirements = [{"preprocessing_plan": desc} for desc in preprocessing_plan]
                return analysis_requirements
        except Exception as regex_error:
            pass
        return [
            {
                "preprocessing_plan": "기본 데이터 분석"
            }
        ]

def extract_data_profile(df, n=5):
    """
    데이터프레임의 구조 및 샘플 데이터를 추출
    """
    profile = {
        "columns": list(df.columns),
        "dtypes": {col: str(df[col].dtype) for col in df.columns},
        "sample_rows": df.head(n).to_dict(orient="records"),
        "null_counts": df.isnull().sum().to_dict(),
        "unique_counts": {col: df[col].nunique() for col in df.columns},
        "examples": {col: df[col].dropna().unique()[:3].tolist() if df[col].nunique() > 0 else [] for col in df.columns}
    }
    return profile

def validate_and_clean_code(code_response: str) -> str:
    """
    LLM 응답에서 실제 코드만 추출하고 기본 검증 수행
    """
    code_pattern = r'```(?:python)?\s*(.*?)\s*```'
    match = re.search(code_pattern, code_response, re.DOTALL)
    
    if match:
        code = match.group(1)
    else:
        code = code_response
    
    lines = code.split('\n')
    cleaned_lines = []
    
    for line in lines:
        stripped_line = line.strip()
        if stripped_line and not stripped_line.startswith('#'):
            cleaned_lines.append(line.rstrip())
    
    cleaned_code = '\n'.join(cleaned_lines)
    
    if not cleaned_code.strip():
        raise ValueError("생성된 코드가 비어있습니다.")
    
    dangerous_keywords = ['import', 'open', 'file', 'os.', 'subprocess', 'eval', 'exec']
    for keyword in dangerous_keywords:
        if keyword in cleaned_code and keyword not in ['import pandas', 'import numpy']:
            raise ValueError(f"안전하지 않은 코드가 감지되었습니다: {keyword}")
    try:
        ast.parse(cleaned_code)
    except SyntaxError as e:
        raise ValueError(f"코드 문법 오류: {str(e)}\n문제가 있는 코드:\n{cleaned_code}")
    
    return cleaned_code

def generate_preprocessing_code(raw_data: Dict[str, Any], user_query: str) -> str:
    """
    LLM을 사용하여 전처리 코드 생성
    """
    df = raw_data['dataframe']
    profile = extract_data_profile(df, n=3)
    
    system_prompt = """
    당신은 pandas 전문가입니다. 데이터 전처리를 위한 깔끔하고 실행 가능한 Python 코드를 생성하세요.
    
    엄격한 요구사항:
    1. 유효한 Python 코드만 반환하세요
    2. pandas (pd)와 numpy (np)만 사용하세요
    3. 기존 DataFrame 'df'를 사용하세요
    4. import 문을 사용하지 마세요
    5. print 문이나 주석을 사용하지 마세요
    6. 적절한 들여쓰기 (4칸 공백)
    7. 간단하고 단일 목적의 작업
    
    날짜 그룹화 형식 요구사항:
    - 연도별 그룹화: YYYY 형식 사용 (예: 2023, 2024)
    - 월별 그룹화: YYYY-MM 형식 사용 (예: 2023-06, 2023-07)
    - 날짜별 그룹화: YYYY-MM-DD 형식 사용 (예: 2023-01-15)
    
    추가 요구사항:
    - 월별 그룹화 시, 컬럼에 'Jun.23', '2023.6', '2023-06' 등 다양한 월 문자열이 들어올 수 있으니,
      반드시 pd.to_datetime(df['month'], errors='coerce')로 변환 후 .dt.strftime('%Y-%m')을 사용해 YYYY-MM 형식으로 통일하세요.
    
    예시:
    # 월별 문자열이 다양한 경우:
    df['month'] = pd.to_datetime(df['month'], errors='coerce').dt.strftime('%Y-%m')
    
    # 필터링:
    df = df[df['column'] > 100]
    
    # 그룹화:
    df = df.groupby('category')['value'].sum().reset_index()
    
    # 상위 N개:
    df = df.nlargest(10, 'score')
    
    # 날짜 필터링 및 그룹화:
    df['date'] = pd.to_datetime(df['date'])
    df = df[df['date'].dt.year == 2023]
    
    # 월별 그룹화 (YYYY-MM 형식):
    df['month'] = pd.to_datetime(df['month'], errors='coerce').dt.strftime('%Y-%m')
    df = df.groupby('month')['value'].sum().reset_index()


    코드만 반환하세요, 다른 것은 포함하지 마세요.
    **데이터 프레임은 항상 df로 사용하세요**
    """
    
    user_prompt = f"""
    Data columns: {profile['columns']}
    Sample row: {profile['sample_rows'][0] if profile['sample_rows'] else {}}
    
    Task: {user_query}
    
    ⚠️ 매우 중요: 반드시 위의 Data columns에 있는 실제 컬럼명만 사용하세요!
    
    Generate pandas code
    """
    
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ]
    
    response = llm.invoke(messages)
    return response.content

def execute_preprocessing_code(code: str, raw_data: Dict[str, Any]) -> tuple[List[Dict[str, Any]], bool, Optional[str]]:
    """
    전처리 코드를 안전하게 실행
    """
    # 안전한 실행 환경 설정
    safe_globals = {
        'pd': pd,
        'np': np,
        'df': raw_data['dataframe'].copy(),
        're': re
    }
    
    try:
        exec(code, safe_globals)
        
        if 'df' not in safe_globals:
            return raw_data['data'], False, "처리 코드에서 'df' 변수를 찾을 수 없습니다."
        
        processed_df = safe_globals['df']
        
        if not isinstance(processed_df, pd.DataFrame):
            return raw_data['data'], False, "처리 결과가 DataFrame이 아닙니다."
        
        if len(processed_df) == 0:
            return raw_data['data'], False, "처리 결과 데이터가 비어있습니다."
        
        return processed_df.to_dict(orient='records'), True, None
        
    except Exception as e:
        error_msg = f"코드 실행 오류: {str(e)}\n실행된 코드:\n{code}"
        print(error_msg)
        return raw_data['data'], False, str(e)

def save_processed_data(processed_data: List[Dict[str, Any]], original_file_path: str, file_extension: str, graph_suffix: str = "") -> str:
    """
    처리된 데이터를 파일로 저장 (입력 파일과 동일한 형식)
    """
    base_name = os.path.splitext(os.path.basename(original_file_path))[0]
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    suffix = f"_{graph_suffix}" if graph_suffix else ""
    
    if file_extension == '.csv':
        filename = f"{base_name}_preprocessed{suffix}_{timestamp}.csv"
        
        df = pd.DataFrame(processed_data)
        csv_content = df.to_csv(index=False, encoding='utf-8-sig')
        
        file_handler.save_file(file_name=filename, content=csv_content, file_type="csv")
        
    else:
        filename = f"{base_name}_preprocessed{suffix}_{timestamp}.json"
        
        def json_serializer(obj):
            if pd.isna(obj):
                return None
            if isinstance(obj, (pd.Timestamp, datetime.datetime)):
                return obj.isoformat()
            if isinstance(obj, np.integer):
                return int(obj)
            if isinstance(obj, np.floating):
                return float(obj)
            return str(obj)
        
        json_data = {"data": processed_data}
        file_handler.save_file(file_name=filename, content=json_data, file_type="json")
    
    saved_file_path = file_handler.get_dir_path(filename)
    return saved_file_path


# MCP 앱 생성
data_processor_app = data_processor_mcp.http_app()
