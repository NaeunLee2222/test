import pandas as pd
import os
import json

from typing import Optional, List, Dict, Any
from langchain_core.messages import SystemMessage, HumanMessage
from utils.llm import LLMSingleton
from fastmcp import FastMCP
from mcpserver.functions.file_handler import FileHandler
import datetime

from pydantic import BaseModel, Field

llm = LLMSingleton.get_llm()
file_handler = FileHandler()

generate_report_mcp = FastMCP(
    name = "GenerateReport",
    stateless_http = True
)

class GenerateReportInput(BaseModel):
    preprocessed_chart_data: List[Dict[str, str]] = Field(..., description="전처리된 차트 데이터 정보")
    user_query: str = Field(..., description="사용자 쿼리")
    key_features: List[str] = Field(..., description="모델 feature importance 리스트")
    analytics_plan: str = Field(..., description="분석 계획")


@generate_report_mcp.tool(description="""여러 전처리된 데이터 파일 정보, 유저 쿼리, 모델 feature importance 리스트를 참고하여 종합 분석 보고서를 생성합니다.""")
def generate_report(preprocessed_chart_data: List[Dict[str, str]], user_query: str, key_features: List[str], analytics_plan: str) -> Optional[str]:
    try:
        file_summaries = []
        
        for chart_data in input.preprocessed_chart_data:
            if isinstance(chart_data, dict) and "chart_type" in chart_data and "pre_processed_file_path" in chart_data:
                description = chart_data["chart_type"]
                file_path = chart_data["pre_processed_file_path"]
                
                try:
                    df = load_processed_data(file_path)
                    summary = summarize_dataframe(df, description)
                    file_summaries.append(summary)
                except Exception as e:
                    file_summaries.append(f"[오류] {description}: {str(e)}")

                print(file_summaries)
        
        system_prompt = """

        당신은 데이터 분석 전문가입니다. 여러 데이터 분석 결과와 요약, 그리고 사용자의 요청을 바탕으로 종합적인 보고서를 작성하세요.

        [마크다운 포맷팅 지침]
        다음과 같은 마크다운 포맷을 반드시 사용하여 보고서를 작성하세요:

        [출력 형식 - 반드시 이 순서와 구조로 작성]
        
        # 데이터 분석 보고서
        
        ---
        
        ## 프로젝트 개요
        
        ### 문제 상황
        {user_query}에 기술된 현재 문제 상황을 2~3 문장으로 자세하게 설명
        
        ### 분석 목표  
        본 보고서의 분석 목적 및 기대 효과를 2~3 문장으로 서술
        
        ---
        
        ## 데이터 주요 변수 설명
        
        | 변수명 | 설명 |
        |--------|------|
        | **변수1** | 변수 1에 대한 상세 설명 |
        | **변수2** | 변수 2에 대한 상세 설명 |
        
        ---
        
        ## 가설 정의
        
        > **데이터 분석을 통해 검증하고자 하는 주요 가설들**
        
        ### 가설 1
        **가설 내용:** 가설 1 내용과 부가 설명을 자세히 기술
        
        ### 가설 2  
        **가설 내용:** 가설 2 내용과 부가 설명을 자세히 기술
        
        ### 가설 3
        **가설 내용:** 가설 3 내용과 부가 설명을 자세히 기술
        
        ---
        
        ## 차트 해석 및 분석 내용
        
        ### 가설 1 검증: [차트명]
        **주요 발견사항:**
        - 차트 1의 실제 데이터 값과 분포를 구체적으로 분석하여 가설 검증 결과 제시
        - 핵심 수치와 패턴을 포함한 상세 분석
        
        ### 가설 2 검증: [차트명]  
        **주요 발견사항:**
        - 차트 2의 실제 데이터 값과 분포를 구체적으로 분석하여 가설 검증 결과 제시
        - 핵심 수치와 패턴을 포함한 상세 분석
        
        ### 가설 3 검증: [차트명]
        **주요 발견사항:**
        - 차트 3의 실제 데이터 값과 분포를 구체적으로 분석하여 가설 검증 결과 제시  
        - 핵심 수치와 패턴을 포함한 상세 분석
        
        ---
        
        ## 분석 내용 정리
        
        ### 주요 발견사항
        
        차트 데이터를 종합적으로 분석하여 주요 발견사항을 상세히 정리하세요:
        
        **1. 핵심 발견사항 1**
        각 발견사항마다 최소 3-5문장 이상의 상세한 설명을 포함하여 데이터에서 관찰된 패턴, 트렌드, 이상치에 대한 구체적인 분석을 제시하세요.
        
        **2. 핵심 발견사항 2** 
        발견사항들 간의 상관관계나 인과관계를 설명하고, 비즈니스적 관점에서 이러한 발견사항이 갖는 의미와 시사점을 논의하세요.
        
        **3. 핵심 발견사항 3**
        추가적인 주요 발견사항과 그 의미를 상세히 설명하세요.
        
        ---
        
        ## 개선 방안
        
        ### 구체적 실행 계획
        
        분석 결과를 바탕으로 한 구체적인 개선 제안을 상세히 작성하세요:
        
        **1. 단기 개선 방안**  
        각 개선 방안마다 최소 4-6문장 이상의 상세한 설명을 포함하여 구체적인 실행 방법과 단계별 접근법을 제시하세요.
        
        **2. 중기 개선 방안**
        개선 방안 구현에 필요한 리소스, 시간, 비용 등을 고려한 실행 계획을 설명하세요.
        
        **3. 장기 개선 방안**
        개선 방안 실행 시 발생할 수 있는 위험 요소와 대응 방안을 논의하세요.
        
        ---
        
        ## 결론 및 제언
        
        > **핵심 요약 및 향후 방향성**
        
        분석 결과를 종합하여 핵심 인사이트와 향후 실행해야 할 우선순위를 제시하세요.

        [작성 규칙]
        - 반드시 위의 마크다운 포맷을 정확히 사용하세요
        - 이모지와 구분선(---)을 적절히 활용하여 가독성을 높이세요
        - 표, 리스트, 소제목 등을 적극 활용하세요
        - 각 데이터의 특징과 의미를 잘 연결해서 설명하세요
        - 데이터 간의 연관성, 인사이트, 주목할 점을 강조하세요
        - 반드시 한국어로 작성하세요
        - 위 구조를 엄격히 준수하여 보고서를 작성하세요
        """
        user_prompt = f"""
        다음 정보를 바탕으로 종합 분석 보고서를 작성하세요.

        [사용자 요청]
        {input.user_query}

        [주요 분석 변수]
        {', '.join(input.key_features) if input.key_features else '없음'}

        [가설 정의]
        {input.analytics_plan}

        [차트 데이터 정보]"""
        
        for idx, fs in enumerate(file_summaries):
            user_prompt += f"\n차트 {idx+1}: {fs}"
        
        user_prompt += """

        [중요 지침]
        - 위에 제공된 차트 데이터 정보를 반드시 그대로 활용하여 각 가설에 대한 구체적인 차트 분석 및 해석을 작성하세요.
        - 각 차트의 실제 데이터 값과 분포를 참고하여 가설 검증에 필요한 인사이트를 도출하세요.
        - 데이터의 구체적인 수치와 패턴을 언급하여 분석의 신뢰성을 높이세요.

        위 정보를 종합하여 보고서를 작성하세요."""
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt)
        ]
        response = llm.invoke(messages)
        report_text = response.content.strip()
        
        saved_file_path = save_report_text(report_text, base_name="report")
        
        return saved_file_path
    except Exception as e:
        return None

def load_processed_data(file_path: str) -> pd.DataFrame:
    """데이터 로드 및 기본 전처리"""
    # file_handler를 사용해서 전체 파일 경로 가져오기
    full_file_path = file_handler.get_file_path(file_path)
    if not full_file_path:
        raise ValueError(f"파일을 찾을 수 없습니다: {file_path}")
    
    ext = os.path.splitext(file_path)[-1].lower()
    try:
        if ext == '.csv':
            # 다양한 인코딩 시도
            encodings = ['utf-8', 'euc-kr', 'cp949', 'latin1', 'iso-8859-1']
            df = None
            
            for encoding in encodings:
                try:
                    df = pd.read_csv(full_file_path, encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
                except Exception as e:
                    continue
            
            if df is None:
                raise ValueError("지원되는 인코딩으로 파일을 읽을 수 없습니다.")
                
        elif ext == '.json':
            with open(full_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict) and 'data' in data:
                    # data 키가 있는 경우
                    df = pd.DataFrame(data['data'])
                elif isinstance(data, list):
                    # 리스트인 경우
                    df = pd.DataFrame(data)
                else:
                    # 딕셔너리를 리스트로 변환
                    df = pd.DataFrame([{'key': k, 'value': v} for k, v in data.items()])
        else:
            raise ValueError("지원하지 않는 파일 형식입니다. (csv, json만 지원)")
    except Exception as e:
        raise ValueError(f"파일 로드 중 오류 발생: {str(e)}")
    
    return df

def summarize_dataframe(df: pd.DataFrame, description: str) -> str:
    """데이터프레임을 분석하여 요약 생성"""
    summary = f"[설명] {description}\n"
    summary += f"- 컬럼: {', '.join(df.columns)}\n"
    summary += f"- 데이터 형태: {df.shape[0]}행 x {df.shape[1]}열\n"
    

    if len(df) <= 10:
        summary += f"- 전체 데이터:\n"
        for idx, row in df.iterrows():
            summary += f"  {idx+1}: {dict(row)}\n"
    else:
        summary += f"- 데이터 샘플 (상위 5행):\n"
        for idx, row in df.head(5).iterrows():
            summary += f"  {idx+1}: {dict(row)}\n"
    
    return summary

def save_report_text(report_text: str, base_name: str = "report") -> str:
    """보고서 마크다운 파일 저장"""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{base_name}_{timestamp}.md"
    
    file_handler.save_file(file_name=file_name, content=report_text, file_type="md")
    
    saved_file_path = file_handler.get_dir_path(file_name)
    print(f"보고서 마크다운 파일 저장: {saved_file_path}")
    return saved_file_path


generate_report_app = generate_report_mcp.http_app()
