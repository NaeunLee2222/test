import os
import json
import requests
from fastmcp import FastMCP
from pydantic import BaseModel, Field
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeResult, ContentFormat
from dotenv import load_dotenv

load_dotenv()


# MCP 서버 생성
ocr_mcp = FastMCP(
    name = "OCRServer",
    stateless_http = True
)

# 입력 모델 정의
class OCRInput(BaseModel):
    file_path: str = Field(..., description="분석할 PDF, 이미지 등의 파일 경로")

@ocr_mcp.tool(description="Azure Document Intelligence를 사용하여 문서(PDF, 이미지, word, excel)를 분석하고 구조화된 결과를 파일로 저장합니다.")
def analyze_document(input: OCRInput) -> str:
    """
    주어진 문서를 분석하고 추출된 정보를 파일로 저장합니다.
    
    Args:
        input: OCR 분석을 위한 입력 파라미터
        
    Returns:
        str: 결과가 저장된 파일의 경로
    """

    endpoint = os.getenv("AZURE_DOCINTELLIGENCE_ENDPOINT")
    key = os.getenv("AZURE_DOCINTELLIGENCE_KEY")
    
    if not endpoint or not key:
        return {
            "success": False, 
            "error": "환경 변수가 설정되지 않았습니다. .env 파일에 endpoint와 API-KEY를 설정해주세요."
        }

    if not os.path.exists(input.file_path):
        return {
            "success": False, 
            "error": f"파일을 찾을 수 없습니다: {input.file_path}"
        }

    document_intelligence_client = DocumentIntelligenceClient(
        endpoint=endpoint, credential=AzureKeyCredential(key)
    )

    try:
        model_id = "prebuilt-layout"
        request_options = {"content_type": "application/octet-stream"}

        with open(input.file_path, "rb") as f:
            poller = document_intelligence_client.begin_analyze_document(
                model_id, analyze_request=f, **request_options
            )
        
        result = poller.result()

        # 전체 결과를 JSON으로 변환
        result_dict = result.as_dict()  # Azure API 결과
        
        # words 부분 제거 (불필요한 상세 데이터)
        if "pages" in result_dict:
            for page in result_dict["pages"]:
                if "words" in page:
                    del page["words"]
        
        output = {
            "success": True,
            "file_path": input.file_path,
            "result": result_dict
        }

        # JSON 출력 (보기 좋게 포맷팅)
        output_content = json.dumps(output, ensure_ascii=False, indent=2)
        output_file = os.path.splitext(input.file_path)[0] + "_ocr_result.json"

        # 결과 파일 저장
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(output_content)

        return output_file

    except Exception as e:

        return str(e)

ocr_app = ocr_mcp.http_app() 