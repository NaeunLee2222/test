from fastmcp import FastMCP
from mcpserver.functions.file_handler import FileHandler
file_handler = FileHandler()



apitest_mcp = FastMCP(
    name = "APITestServer",
    stateless_http=True
)


@apitest_mcp.tool(description="API 테스트를 위한 도구")
def apitest(input: str) -> str:
    return "API 테스트 결과"

@apitest_mcp.tool(description="파일 처리를 위한 도구")
def file_handler_test1(input: str) -> str:
    import os
    files = os.listdir(input)
    return f"file_handler.mount_path: {file_handler.mount_path} \n 파일 리스트: {files}"

@apitest_mcp.tool(description="파일 처리를 위한 도구")
def file_handler_test2(input: str) -> str:
    import os
    folders = [f for f in os.listdir(file_handler.mount_path) if os.path.isdir(os.path.join(file_handler.mount_path, f))]
    return f"폴더 리스트: {folders}"


apitest_app = apitest_mcp.http_app()
