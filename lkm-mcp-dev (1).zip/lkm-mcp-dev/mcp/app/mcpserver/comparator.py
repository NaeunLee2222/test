import os
import difflib
import json
from fastmcp import FastMCP
from pydantic import BaseModel, Field
from bs4 import BeautifulSoup
from langchain_core.messages import SystemMessage, HumanMessage
from datetime import datetime
from utils.llm import LLMSingleton
from mcpserver.functions.saver import save_html
from mcpserver.functions.converter import extract_docx_using_markitdown, docxTohtml, DocxToHtmlInput, convert_html_to_docx
from mcpserver.html import remove_cover_page
from mcpserver.data_processor import load_data
#from mcpserver.functions.file_handler import FileHandler
from client.document_client import DocumentClient

#file_handler = FileHandler()

llm = LLMSingleton.get_llm()

comparator_mcp = FastMCP(
    name = "ComparatorServer",
    stateless_http = True
)

class SelectBaseDocInput(BaseModel):
    user_query: str = Field(..., description="사용자가 입력한 쿼리")
    searched_file_csv_path: str = Field(
        ..., description="검색 결과가 저장된 csv 파일 경로"
    )


class SelectBaseDocOutput(BaseModel):
    base_doc: str = Field(..., description="선택된 기준 문서의 경로")
    candidate_docs_before_filtering: list = Field(..., description="취급 대상 필터링 전 후보 문서들의 경로 리스트")


class FilterDocsInput(BaseModel):
    base_doc: str = Field(..., description="기준 문서 경로")
    docs_list: list = Field(
        ..., description="취급 대상 필터링 전 비교 대상 후보 문서들의 경로를 담은 리스트"
    )
    num_docs: int = Field(1, description="취급할 문서 개수")


class FilterDocsOutput(BaseModel):
    similar_docs: list = Field(..., description="취급 대상 필터링 후 최종 비교 대상 문서들의 경로 리스트")


class CompareMergeDocsInput(BaseModel):
    base_doc: str = Field(..., description="기준 문서 경로")
    comparative_doc: list = Field(..., description="최종 비교 대상 문서들의 경로 리스트")


class CompareMergeDocsOutput(BaseModel):
    compare_merge_result_path: str = Field(..., description="비교 결과 파일 경로")


# @comparator_mcp.tool(
#     description="사용자 쿼리와 문서들의 내용을 비교하여 가장 유사한 문서 1개의 경로를 반환합니다."
# )
def select_base_doc(input: SelectBaseDocInput) -> SelectBaseDocOutput:

    searched_file_data = load_data(input.searched_file_csv_path, 100000)

    doc_paths = searched_file_data["dataframe"]["doc_path"]
    descriptions = searched_file_data["dataframe"]["description"]

    docs_info_dict = dict(zip(doc_paths, descriptions))

    # LLM을 사용하여 가장 유사한 문서 선택
    system_message = SystemMessage(
        content="""
    사용자 쿼리와 문서들의 내용을 비교하여 가장 유사한 문서 1개의 키값만을 반환하세요.
    반드시 주어진 문서 키값 중 하나만 반환해야 합니다.
    다른 설명이나 추가 텍스트 없이 키값만 반환하세요.
    """
    )

    human_message = HumanMessage(
        content=f"""
    사용자 쿼리: {input.user_query}
    
    문서 정보:
    {json.dumps(docs_info_dict, ensure_ascii=False, indent=2)}
    
    가장 유사한 문서의 키값만을 반환하세요. 절대 어떠한 추가 설명도 덧붙이지 마세요.
    """
    )

    response = llm.invoke([system_message, human_message])
    base_doc = response.content.strip()

    candidate_docs = list(docs_info_dict.keys())

    # difflib을 사용하여 가장 유사한 문서 찾기 (output parsing error 방지)
    max_similarity = 0
    new_base_doc = None
    
    for doc in candidate_docs:
        similarity = difflib.SequenceMatcher(None, base_doc, doc).ratio()
        if similarity > max_similarity:
            max_similarity = similarity
            new_base_doc = doc

    candidate_docs_before_filtering = []
    for doc in candidate_docs:
        if doc == new_base_doc:
            continue
        candidate_docs_before_filtering.append(doc)

    # return SelectBaseDocOutput(
    #     base_doc=new_base_doc,
    #     candidate_docs_before_filtering=candidate_docs_before_filtering
    # )

    return new_base_doc, candidate_docs_before_filtering


# 취급 문서 선정 - difflib SequenceMatcher 사용
@comparator_mcp.tool(
    description="비교 대상 후보 문서들 중 기준 문서와 비교할 문서 1개를 선정합니다."
)
# def filter_docs(input: FilterDocsInput) -> FilterDocsOutput:
def filter_docs(input: FilterDocsInput) -> list:

    # base_doc의 확장자 추출
    base_doc_ext = os.path.splitext(input.base_doc)[1].lower()

    # input.num_docs llm이 잘못 세팅하는 경우 방지
    # num_docs = input.num_docs
    num_docs = 1

    # 후보 문서 확장자 맞추기
    candidate_docs = []
    for doc in input.docs_list:
        if doc.split("/")[-1] == input.base_doc.split("/")[-1]:
            continue
        if os.path.splitext(doc)[1].lower() != base_doc_ext:
            # 해당 doc의 확장자를 변환하는 코드 - aspose
            # changed_doc = aspose로 변환(doc)
            # candidate_docs.append(changed_doc)
            pass
        else:
            candidate_docs.append(doc)

    similar_docs = []

    if base_doc_ext == ".docx":
        base_doc = {
            input.base_doc: "\n".join(extract_docx_using_markitdown(input.base_doc))
        }
        candidate_docs_dict = {
            doc: "\n".join(extract_docx_using_markitdown(doc)) for doc in candidate_docs
        }
        similar_docs = get_similar_docx(base_doc, candidate_docs_dict, num_docs)
        if len(similar_docs) < num_docs:
            raise ValueError("저장소에 존재하는 유사 문서가 부족합니다.")
    elif base_doc_ext == ".pdf":
        pass
    elif base_doc_ext == ".html":
        pass
    else:
        # 모두 다 html로 변환해서 하기
        pass

    # return FilterDocsOutput(similar_docs=similar_docs)
    return similar_docs

# 문서 비교 및 병합
@comparator_mcp.tool(description="기준 문서 1개와 대상 문서 1개를 비교하여 병합합니다.")
# async def compare_merge_docs(input: CompareMergeDocsInput) -> CompareMergeDocsOutput:
async def compare_merge_docs(input: CompareMergeDocsInput) -> tuple[str, str]:

    comparative_doc = input.comparative_doc[0]

    base_doc_ext = os.path.splitext(input.base_doc)[1].lower()
    filtered_doc_ext = os.path.splitext(comparative_doc)[1].lower()

    base_html = guarantee_html(input.base_doc, base_doc_ext)
    filtered_html = guarantee_html(comparative_doc, filtered_doc_ext)

    # RFQ 문서에 무조건 표지가 존재한다고 가정
    base_html = remove_cover_page(base_html)
    filtered_html = remove_cover_page(filtered_html)

    base_html = add_custom_strikethrough(base_html)
    filtered_html = add_custom_strikethrough(filtered_html)

    compared_result = await compare_html(base_html, filtered_html)

    output_html_path = postprocess(compared_result, "purple", "green", "crimson")

    output_docx_path = await convert_html_to_docx(output_html_path)

    # return CompareMergeDocsOutput(compare_merge_result_path=output_path)
    return output_html_path, output_docx_path

# base_doc, candidate_docs: {doc_path: doc_content}
def get_similar_docx(
    base_doc: dict[str, str], candidate_docs: dict[str, str], num_docs: int
) -> list:
    similar_docs = []

    for doc_path, doc_content in candidate_docs.items():

        similarity = difflib.SequenceMatcher(
            None, list(base_doc.values())[0], doc_content
        ).ratio()

        if similarity > 0.7:
            similar_docs.append((doc_path, similarity))

    # similarity가 높은 순으로 정렬
    similar_docs.sort(key=lambda x: x[1], reverse=True)

    # doc_path만 추출하여 반환할 리스트 생성
    similar_docs = [doc_path for doc_path, _ in similar_docs]

    if len(similar_docs) < num_docs:
        return similar_docs
    else:
        return similar_docs[:num_docs]


# 파일 확장자가 html이 아닌 경우 html로 변환
async def guarantee_html(file_path: str, file_ext: str) -> str:
        """파일이 HTML이 아닌 경우 HTML로 변환하여 경로를 반환합니다."""
        if file_ext == ".html":
            return file_path
        else:
            html_path = os.path.splitext(file_path)[0] + ".html"
            if not os.path.exists(html_path):
                html_path = await docxTohtml(
                    DocxToHtmlInput(docx_path=file_path, start_page=1)
                )
            return html_path


# 취소선 인지 (전처리)
def add_custom_strikethrough(html_path: str) -> str:

    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    soup = BeautifulSoup(content, "html.parser")

    # text-decoration:line-through를 포함하는 모든 요소 찾기
    for element in soup.find_all(style=True):
        style = element.get("style", "")
        if "text-decoration:line-through" in style:

            # 기존 텍스트 뒤에 ' 취소선' 텍스트 직접 추가
            if element.string:
                element.string = element.string + " 커스텀취소선"
            else:
                # 복잡한 내용이 있는 경우 마지막에 텍스트 추가
                element.append(" 커스텀취소선")

    output_html_path = html_path.replace(".html", "_strikethrough.html")

    # 수정된 내용을 새로운 파일에 저장
    with open(output_html_path, "w", encoding="utf-8") as f:
        f.write(str(soup))

    return output_html_path


async def compare_html(base_html: str, filtered_html: str) -> str:
    try:
        
        document_client = DocumentClient()
        output_path = await document_client.compare_docx(base_html, filtered_html)
        return output_path
        
    except Exception as e:
        print(f"전체 프로세스에서 오류 발생: {str(e)}")
        print(f"오류 타입: {type(e).__name__}")
        import traceback
        print(f"상세 오류 정보:\n{traceback.format_exc()}")
        raise


# 취소선 인지 복원 (후처리)
def postprocess(input_file_path, base_color, comp_color, caution_color):

    with open(input_file_path, "r", encoding="utf-8") as f:
        content = f.read()

    soup = BeautifulSoup(content, "html.parser")

    # 모든 del과 ins 태그를 순서대로 찾아서 바꾸기
    all_tags = soup.find_all(["del", "ins"])

    for tag in all_tags:

        if tag.name == "del":

            child_tags = tag.find_all()
            if child_tags:
                first_child = child_tags[0]
                if first_child.name == "img":
                    continue

                # 자식 태그의 내용이 "커스텀취소선"인지 확인
                if first_child.get_text().strip() == "커스텀취소선":
                    first_child["style"] = f"color: {caution_color};"
                    first_child.string = "(취소선 확인 필요)"
                else:
                    if "style" in first_child.attrs:
                        first_child["style"] = (
                            first_child["style"] + f"; color: {base_color};"
                        )
                    else:
                        first_child["style"] = f"color: {base_color};"

                    if first_child.string:
                        first_child.string = first_child.string + " "

                    # del 태그를 첫 번째 자식 태그로 교체
                    tag.replace_with(first_child)
            else:
                # 자식 태그가 없으면 태그 자체의 내용 확인
                if tag.get_text().strip() == "커스텀취소선":
                    tag.name = "span"
                    tag["style"] = f"color: {caution_color};"
                    tag.string = "(취소선 확인 필요)"
                else:
                    # 자식 태그가 없으면 span으로 변경
                    tag.name = "span"
                    tag["style"] = f"color: {base_color};"

                    if tag.string:
                        tag.string = tag.string + " "

        elif tag.name == "ins":

            child_tags = tag.find_all()
            if child_tags:
                first_child = child_tags[0]
                if first_child.name == "img":
                    continue

                if first_child.get_text().strip() == "커스텀취소선":
                    first_child["style"] = f"color: {caution_color};"
                    first_child.string = "(취소선 확인 필요)"
                else:
                    if "style" in first_child.attrs:
                        first_child["style"] = (
                            first_child["style"] + f"; color: {comp_color};"
                        )
                    else:
                        first_child["style"] = f"color: {comp_color};"

                    if first_child.string:
                        first_child.string = first_child.string + " "

                    # ins 태그를 첫 번째 자식 태그로 교체
                    tag.replace_with(first_child)
            else:
                # 자식 태그가 없으면 태그 자체의 내용 확인
                if tag.get_text().strip() == "커스텀취소선":
                    tag.name = "span"
                    tag["style"] = f"color: {caution_color};"
                    tag.string = "(취소선 확인 필요)"
                else:
                    # 자식 태그가 없으면 span으로 변경
                    tag.name = "span"
                    tag["style"] = f"color: {comp_color};"

                    if tag.string:
                        tag.string = tag.string + " "

    all_tags = soup.find_all(style=True)
    for tag in all_tags:
        style_attr = tag.get("style", "")
        text_content = tag.get_text().strip()

        # style 속성에 text-decoration:line-through가 포함되어 있고, 내용이 "커스텀취소선"인 경우
        if (
            "text-decoration:line-through" in style_attr
            and text_content == "커스텀취소선"
        ):
            # 해당 태그를 완전히 제거
            tag.decompose()

    #todo path refactoring
    target_dir = "/app/shared_data/compared_result"
    output_file_name = os.path.basename(input_file_path).replace(".html", "_final.html")

    output_path = save_html(target_dir, output_file_name, str(soup))

    return output_path


comparator_app = comparator_mcp.http_app()
