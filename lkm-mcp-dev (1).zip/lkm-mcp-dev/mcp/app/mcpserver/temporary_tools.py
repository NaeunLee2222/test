import os
import json
import difflib
from utils.llm import LLMSingleton
from mcpserver.functions.file_handler import FileHandler
from mcpserver.comparator import SelectBaseDocOutput
from langchain_core.messages import SystemMessage, HumanMessage
from fastmcp import FastMCP
from pydantic import BaseModel, Field

file_handler = FileHandler()

llm = LLMSingleton.get_llm()

temporary_tools_mcp = FastMCP(
    name = "TemporaryToolsServer",
    stateless_http = True
)

# AGS 캔버스 테스트용
@temporary_tools_mcp.tool(
    description="html 파일을 표시합니다. 표시할 html 파일의 경로를 반환합니다."
)
def temp_show_html(temp_query: str) -> str:

    rfq_html_path = "/app/shared_data/lkm_mcp/compared_result/compared_result_0647_final.html"

    return rfq_html_path

class TempSelectBaseDocInput(BaseModel):
    user_query: str = Field(..., description="사용자가 입력한 쿼리")

@temporary_tools_mcp.tool(
    description="사용자의 쿼리와 문서들의 내용을 비교하여 가장 유사한 문서 1개의 경로를 반환합니다."
)
# def temp_select_base_doc(input: TempSelectBaseDocInput) -> SelectBaseDocOutput:
def temp_select_base_doc(input: TempSelectBaseDocInput) -> tuple[str, list]:

    docs_info_dict = {

            "/app/shared_data/rfq/Bottom_Channel_Only_Heat_Exchanger.docx"
        : "프로젝트명: 25년 No.2 BTX TA P-E3515 Bottom Channel 제작구매, 장비명: P-E3515, 장비 종류: 열교환기, **Scope: Bottom Channel only**",

            "/app/shared_data/rfq/Bundle_Heat_Exchanger_Assembly_GroupA.docx"
        : "프로젝트명: 2023년 No.1FCC TA 관련 통합구매(Group A), 장비명: AL-E5507A, RC-E4413 등 34종, 장비 종류: 열교환기, **Scope: Tube bundle only, Heat Exchanger 전체 교체**",

            "/app/shared_data/rfq/Bundle_Replacement_Heat_Exchanger.docx"
        : "프로젝트명: 25년도 No.2 FCC TA 생산3팀 재질개선 투자, 장비명: AL-E5401A 등 12종, 장비 종류: 열교환기, **Scope: Tube bundle only**",

            "/app/shared_data/rfq/Lean_Gas_Cooler_Heat_Exchanger.docx"
        : "프로젝트명: No.2 RFCC 수익성 증대사업 (Lean Gas Cooler, RC-E3414B), 장비명: RC-E3414B, 장비 종류: 열교환기, **Scope: New Assembly**",

            "/app/shared_data/rfq/Shell_Tube_Heat_Exchanger.docx"
        : "프로젝트명: 25년도 No.2 GDS 처리량 증대 사업 (GD-E5011D 열교환기), 장비명: GD-E5011D, 장비 종류: 열교환기, **Scope: Tube bundle only**",
    }

    candidate_docs = list(docs_info_dict.keys())

    # LLM을 사용하여 가장 유사한 문서 선택
    system_message = SystemMessage(
        content="""
    사용자 쿼리와 문서들의 내용을 비교하여 가장 유사한 문서 1개의 키값만을 반환하세요.
    반드시 주어진 문서 키값 중 하나만 반환해야 합니다.
    다른 설명이나 추가 텍스트 없이 키값만 반환하세요.
    """
    )

    human_message = HumanMessage(
        content=f"""
    사용자 쿼리: {input.user_query}
    
    문서 정보:
    {json.dumps(docs_info_dict, ensure_ascii=False, indent=2)}
    
    가장 유사한 문서의 키값만을 반환하세요. 절대 어떠한 추가 설명도 덧붙이지 마세요.
    """
    )

    response = llm.invoke([system_message, human_message])
    base_doc = response.content.strip()

    # difflib을 사용하여 가장 유사한 문서 찾기 (output parsing error 방지) 
    max_similarity = 0
    new_base_doc = None
    
    for doc in candidate_docs:
        similarity = difflib.SequenceMatcher(None, base_doc, doc).ratio()
        if similarity > max_similarity:
            max_similarity = similarity
            new_base_doc = doc

    candidate_docs_before_filtering = []
    for doc in candidate_docs:
        if doc == new_base_doc:
            continue
        candidate_docs_before_filtering.append(doc)

    # return SelectBaseDocOutput(
    #     base_doc=new_base_doc,
    #     candidate_docs_before_filtering=candidate_docs_before_filtering
    # )

    return new_base_doc, candidate_docs_before_filtering


temporary_tools_app = temporary_tools_mcp.http_app()
