import os
import json
import uuid
from fastmcp import FastMCP
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from mcpserver.functions.converter import extract_docx_using_markitdown
from mcpserver.excel2html import excel_to_html_simple, Excel2HtmlSimpleInput, get_general_sheet
from mcpserver.functions.tbe import *
from mcpserver.functions.file_handler import FileHandler
from mcpserver.functions.saver import save_json

file_handler = FileHandler()

load_dotenv()

tbe2_mcp = FastMCP(
    name = "Tbe2Server",
    stateless_http = True
)


class ExtractRfqInput(BaseModel):
    created_or_uploaded_rfq_path: str = Field(..., description="사용자가 업로드한 RFQ 문서의 경로 또는 이전 스텝에서 최종 생성되어 저장된 RFQ 문서(docx)의 경로 (**주의: 기준 RFQ 문서 아님**)")


class ExtractRfqOutput(BaseModel):
    rfq_info_path: str = Field(..., description="추출된 RFQ 정보가 담긴 JSON 파일의 경로")


class TBEPreprocessInput(BaseModel):
    base_tbe_path: str = Field(..., description="기준 TBE 문서의 경로")
    rfq_info_path: str = Field(..., description="추출된 RFQ 정보가 담긴 JSON 파일의 경로")


class TBEPreprocessOutput(BaseModel):
    tbe_info_path: str = Field(..., description="전처리된 TBE 문서 정보가 담긴 JSON 파일의 경로")


class TBEMainProcessInput(BaseModel):
    created_or_uploaded_rfq_path: str = Field(..., description="사용자가 업로드한 RFQ 문서의 경로 또는 이전 스텝에서 최종 생성되어 저장된 RFQ 문서(docx)의 경로 (**주의: 기준 RFQ 문서 아님**)")
    tbe_info_path: str = Field(..., description="전처리된 TBE 문서 정보가 담긴 JSON 파일의 경로")


class TBEMainProcessOutput(BaseModel):
    created_tbe_path: str = Field(..., description="최종 생성된 TBE 문서 HTML 파일의 경로")

###################################################### 여기 수정해야 함
# 1. RFQ에서 정보 추출 (테스트 및 확인 필요)
@tbe2_mcp.tool(description="""TBE 전처리를 위한 RFQ 문서에서 프로젝트 명과 장비 정보를 추출합니다.
1. 입력받은 문서 제목을 바탕으로 대응하는 RFQ 문서를 찾습니다.
2. 찾은 RFQ 문서를 분석하여 프로젝트 명과 장비 정보를 추출합니다.
3. 추출된 정보를 JSON 파일로 저장합니다.
4. 저장한 JSON 파일의 경로를 반환합니다.""")
def extract_rfq_info_for_tbe(input: ExtractRfqInput) -> ExtractRfqOutput:

    # base_rfq_name = input.created_or_uploaded_rfq_path.split("/")[-1].split(".")[0]

    # # base_rfq_path = file_handler.get_file_path(
    # #     os.path.join("rfq", base_rfq_name + ".docx"))
    # base_rfq_path = "/app/shared_data/lkm_mcp/rfq/" + base_rfq_name + ".docx"

    # # 가져온 함수
    # rfq_context = "\n".join(extract_docx_using_markitdown(base_rfq_path))
    # print(f"rfq_context_length : {len(rfq_context)}")

    rfq_context = "\n".join(extract_docx_using_markitdown(input.created_or_uploaded_rfq_path))

    # RFQ 문서에서 프로젝트명, 아이템&수량, Special Notes를 구조화된 형태로 추출
    structured_data = extract_rfq_structured_data(rfq_context)

    target_dir = "/app/shared_data/result"
    file_name = f"rfq_info_{str(uuid.uuid4())}.json"
    output_path = save_json(target_dir, file_name, structured_data)

    # file_name = f"rfq_info_{str(uuid.uuid4())}.json"
    # output_path = file_handler.get_dir_path(file_name)
    # file_handler.save_file(file_name = file_name, content=structured_data, file_type="json")

    return ExtractRfqOutput(rfq_info_path=output_path)


# 2. 기준 TBE 전처리 - 기본 데이터 추출, 프로젝트 명 기입, 불필요한 데이터 제거
@tbe2_mcp.tool(description="""기준 RFQ와 매칭되는 TBE 문서를 전처리합니다.
1. 기준 RFQ 문서의 이름을 사용하여 대응하는 TBE 엑셀 문서를 찾습니다.
2. 찾은 TBE 문서를 분석하여 기본데이터를 추출합니다.
3. 프로젝트명을 기입하고 불필요한 데이터를 제거합니다.
4. 전처리된 데이터를 JSON 파일로 저장합니다.
5. 저장한 JSON 파일의 경로를 반환합니다."""
)
async def preprocess_tbe(input: TBEPreprocessInput) -> TBEPreprocessOutput:
    
    # base_tbe_name = input.base_doc_path.split("/")[-1].split(".")[0]

    # base_tbe_path = file_handler.get_file_path(
    #     os.path.join("tbe", base_tbe_name + ".html"))    
    
    # 입력 파일의 확장자 확인
    # 자체적으로 잘랐음
    input_extension = os.path.splitext(input.base_tbe_path)[1].lower()
    if input_extension == ".html":
        pass
    elif input_extension in [".xlsx", ".xls"]:
        excel2html_input = Excel2HtmlSimpleInput(excel_file_path=input.base_tbe_path)
        base_tbe_path = (await excel_to_html_simple(excel2html_input))
        base_tbe_path = get_general_sheet(base_tbe_path)
    else:
        raise ValueError("TBE 문서의 확장자가 올바르지 않습니다.")
    
    # if not os.path.exists(base_tbe_path):
    #     extension = None
    #     for extension in [".xlsx", ".xls"]:
    #         tbe_path = os.path.join("tbe", base_tbe_name + extension)
    #         if os.path.exists(tbe_path):
    #             excel2html_input = Excel2HtmlInput(excel_file_path=tbe_path)
    #             break
    #     if extension:
    #         base_tbe_path = (await excel_to_html(excel2html_input))["files"][0]
    #     else:
    #         return {}

    structured_data = json.load(open(input.rfq_info_path, "r", encoding="utf-8"))
    html_table_content:str = extract_html_table_content(base_tbe_path)
    modified_file_path = base_tbe_path.replace(".html", "_preprocessed.html")
    # modified_file_path = os.path.join("tbe", base_tbe_name+ "_" + "preprocessed.html")
    new_project_name = "Project : " + structured_data["project_name"]

    modified_file_path = replace_project_name_in_tbe_html(
        tbe_html_path=base_tbe_path,
        tbe_html_content=html_table_content,
        new_project_name=new_project_name,
        llm=llm,
        modified_file_path=modified_file_path)

    removed_rows_file_path, removed_start_index, saved_style_info = remove_items_and_quantity_rows(modified_file_path, html_table_content, llm)

    removed_private_info_file_path:str = remove_private_info(removed_rows_file_path, html_table_content, llm)

    # 1. TBE 시트에서 No., Description, Requirements 에 해당하는 열의 idx와 값을 찾는다.
    main_cols_info_list = [None, None, None, None, None, None]

    retry_count = 0
    while None in main_cols_info_list and retry_count < 5:
        main_cols_info_list: list[Any] = get_tbe_col_idx(html_table_content, llm)
        retry_count += 1

    if retry_count == 5:
        raise Exception("TBE 시트에서 No., Description, Requirements 에 해당하는 열의 idx를 찾을 수 없습니다.")

    output = {
        "removed_start_index": removed_start_index,
        "saved_style_info": saved_style_info,
        "main_cols_info_list": main_cols_info_list,
        "removed_private_info_file_path": removed_private_info_file_path,
        "structured_data": structured_data
    }

    target_dir = "/app/shared_data/result"
    file_name = f"tbe_info_{str(uuid.uuid4())}.json"
    output_path = save_json(target_dir, file_name, output)

    # file_name = f"tbe_info_{str(uuid.uuid4())}.json"
    # output_path = file_handler.get_dir_path(file_name)
    # file_handler.save_file(file_name = file_name, content=output, file_type="json")

    return TBEPreprocessOutput(tbe_info_path=output_path)


# 3. 기준 TBE 본문 수정
@tbe2_mcp.tool(description=
"""전처리된 TBE 문서를 기반으로 No., Description, Requirements 에 해당하는 데이터들을 정제합니다.
1. 정제된 데이터를 바탕으로 요구사항의 옳고 그름을 판단합니다.
2. 요구사항의 옳고 그름을 판단한 결과를 바탕으로 요구사항을 수정합니다.
3. 사전에 분석한 RFQ 문서 내용을 기반으로 TBE 문서에 아이템&수량을 추가합니다.
4. 최종 수정된 TBE 문서의 정보 파일 경로를 반환합니다.""")
def modify_tbe_content(input: TBEMainProcessInput) -> TBEMainProcessOutput:

    # base_rfq_name = input.rfq_path.split("/")[-1].split(".")[0]

    # base_rfq_path = file_handler.get_file_path(
    #     os.path.join("rfq", base_rfq_name + ".docx"))

    # rfq_context = "\n".join(extract_docx_using_markitdown(base_rfq_path))

    rfq_context = "\n".join(extract_docx_using_markitdown(input.created_or_uploaded_rfq_path))

    tbe_info = json.load(open(input.tbe_info_path, "r", encoding="utf-8"))
    # tbe_info = file_handler.load_json(input.tbe_info_path)
    removed_start_index = tbe_info["removed_start_index"]
    saved_style_info = tbe_info["saved_style_info"]
    main_cols_info_list = tbe_info["main_cols_info_list"]
    removed_private_info_file_path = tbe_info["removed_private_info_file_path"]
    structured_data = tbe_info["structured_data"]

    # 1. 실제 테이블에서 No., Description, Requirements 에 해당하는 데이터들을 정제한다.
    matched_data, preprocessed_tbe_html_path = extract_matched_data(removed_private_info_file_path, main_cols_info_list)

    # 2. 1에서 얻은 정보를 바탕으로 요구사항의 옳고 그름을 판단한다.
    all_incorrect_undetermined = get_all_incorrect_undetermined(matched_data, rfq_context, llm)

    # 3. 2에서 얻은 정보를 바탕으로 요구사항을 수정한다.
    modified_tbe_html_path = modify_tbe_html(preprocessed_tbe_html_path, all_incorrect_undetermined, main_cols_info_list)

    # 4. 3에서 얻은 정보를 바탕으로 아이템&수량을 추가한다.
    created_tbe_html_path = add_item_and_quantity(
        tbe_html_path=modified_tbe_html_path, 
        removed_start_idx=removed_start_index, 
        new_rows_data=structured_data, 
        style_info=saved_style_info, 
        cols_info_list=main_cols_info_list)

    return TBEMainProcessOutput(created_tbe_path=created_tbe_html_path)

tbe2_app = tbe2_mcp.http_app()