from fastmcp import FastMCP
from mcpserver.functions.file_handler import FileHandler
from utils.llm import LLMSingleton
from langchain_core.messages import SystemMessage, HumanMessage
import json

planning_mcp = FastMCP(
    name = "PlanningServer",
    stateless_http = True
)

llm = LLMSingleton.get_llm()
file_handler = FileHandler()

@planning_mcp.tool(description="프로젝트 계획 생성")
def intent_analysis(file_path: str) -> str:
    """사용자 쿼리를 분석하여 의도를 분석합니다."""
    try:
        # 파일 내용 읽기
        # JSON 파일에서 user_query 추출
        content_json = file_handler.load_json(file_path)
        if content_json and "user_query" in content_json:
            content_text = content_json["user_query"]
        else:
            content_text = ""
        
        # LLM 분석
        system_prompt = "주어진 문서를 분석하여 프로젝트 의도와 계획을 제공하세요."
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=content_text)
        ]
        
        response = llm.invoke(messages)
        return str(response.content)
        
    except Exception as e:
        return f"분석 중 오류가 발생했습니다: {str(e)}"



@planning_mcp.tool(description="프로젝트 계획 생성")
def make_todo_list(file_path: str) -> str:
    """사용자 쿼리를 분석하여 구체적인 TODO 리스트와 소요시간을 생성합니다."""
    try:
        # 파일 내용 읽기
        content_json = file_handler.load_json(file_path)
        
        # content_json의 모든 내용을 활용
        user_query = content_json.get("user_query", "")
        chat_id = content_json.get("chat_id", "")
        created_at = content_json.get("created_at", "")
        tool_calling_history = content_json.get("tool_calling_history", [])
        messages = content_json.get("messages", [])
        
        # 전체 컨텍스트 정보를 포함한 분석 텍스트 구성
        context_info = f"""
사용자 쿼리: {user_query}
채팅 ID: {chat_id}
생성 시간: {created_at}
도구 호출 이력: {json.dumps(tool_calling_history, ensure_ascii=False, indent=2)}
메시지 히스토리: {json.dumps(messages, ensure_ascii=False, indent=2)}
"""
        
        # LLM 분석 - 구체적인 TODO 리스트와 소요시간 요청
        system_prompt = """주어진 정보를 분석하여 프로젝트 계획을 수립하세요. 

사용자 쿼리를 바탕으로 해야 할 일들을 단계별로 나누고, 각 단계에서 수행할 구체적인 작업들을 제시하세요. 각 작업당 약 10~20초 정도 소요될 것으로 예상하고, 전체 소요시간도 함께 알려주세요.

자연스러운 줄글로 응답해주세요."""
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=context_info)
        ]
        
        response = llm.invoke(messages)
        return str(response.content)
        
    except Exception as e:
        return f"TODO 리스트 생성 중 오류가 발생했습니다: {str(e)}"
    

planning_app = planning_mcp.http_app()
