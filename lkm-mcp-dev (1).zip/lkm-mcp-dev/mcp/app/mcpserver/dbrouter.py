from fastmcp import FastMCP

from pydantic import BaseModel, Field

import os
import yaml
import json
from langchain_openai import AzureChatOpenAI
from mcpserver.functions.file_handler import FileHandler
from utils.state_loader import StateLoader


state_loader = StateLoader()
file_handler = FileHandler()

dbrouter_mcp = FastMCP(
    name = "DBRouterServer",
    stateless_http = True
)

def create_llm():
    """Azure OpenAI LLM 인스턴스 생성"""
    return AzureChatOpenAI(
        azure_deployment=os.getenv("OPENAI_DEPLOYMENT"),
        azure_endpoint=os.getenv("OPENAI_ENDPOINT"),
        api_version=os.getenv("OPENAI_API_VERSION"),
        api_key=os.getenv("OPENAI_API_KEY"),
        n=1,
        temperature=0,
        max_tokens=500,
        model=os.getenv("OPENAI_MODEL"),
        verbose=True,
        streaming=False,
    )


def load_db_config(config_file="dbconfig.yaml"):
    """YAML 설정 파일을 로드"""
    with open(config_file, 'r', encoding='utf-8') as file:
        return yaml.safe_load(file)


def select_database(user_query, config_file="dbconfig.yaml"):
    """LLM을 사용하여 사용자 쿼리에 적합한 데이터베이스 선택"""
    
    config = load_db_config(config_file)
    
    db_info = []
    for db_identifier, db_config in config['databases'].items():
        db_info.append(f"- {db_identifier}")

        schemas = db_config.get('schemas', {})
        for schema_name, schema_info in schemas.items():
            description = schema_info.get('description', '설명 없음')
            db_info.append(f"  └─ {schema_name}: {description}")

    db_info_str = "\n".join(db_info)

    system_prompt = f"""당신은 사용자 쿼리를 분석하여 적절한 데이터베이스와 스키마를 선택하는 전문가입니다. 
    주어진 데이터베이스 정보를 바탕으로 사용자의 질문에 가장 적합한 데이터베이스와 스키마를 선택해주세요.
    반드시 주어진 JSON 형식으로만 응답하세요.
    """

    user_prompt = f"""
    사용자의 쿼리를 분석하여 가장 적합한 데이터베이스와 스키마를 선택해주세요.

    사용 가능한 데이터베이스와 스키마:
    {db_info_str}

    사용자 쿼리: "{user_query}"

    다음 JSON 형식으로만 응답해주세요:
    {{
        "selected_database": "데이터베이스 식별자",
        "selected_schema": "스키마 이름",
        "confidence": 0.95,
        "reasoning": "선택 이유"
    }}

    선택 기준:
    1. 쿼리 내용과 데이터베이스 설명의 연관성
    2. 키워드 매칭
    3. 사용자 의도 파악
    """
    
    llm = create_llm()
    response = llm.invoke(system_prompt + "\n\n" + user_prompt)
    
    try:
        response_text = response.content.strip()
        
        if "```" in response_text:
            lines = response_text.split('\n')
            filtered_lines = [line for line in lines if not line.strip().startswith('```')]
            response_text = '\n'.join(filtered_lines)
        
        selection_result = json.loads(response_text)
    
        # 데이터베이스 존재 여부 검증
        selected_db = selection_result.get("selected_database")
        if selected_db not in config['databases']:
            raise ValueError(f"선택된 데이터베이스 '{selected_db}'가 존재하지 않습니다.")
        # 스키마 존재 여부 검증
        selected_schema = selection_result.get("selected_schema")
        selected_db_config = config['databases'][selected_db]
        available_schemas = selected_db_config.get('schemas', {})
        if not available_schemas:
            raise ValueError(f"선택된 스키마 '{selected_schema}'가 존재하지 않습니다")
        
        return selection_result
        
    except json.JSONDecodeError as e:
        raise ValueError(f"LLM 응답을 JSON으로 파싱할 수 없습니다: {e}")

def get_db_connection_info(db_identifier, selected_schema, config_file="dbconfig.yaml"):
    """선택된 데이터베이스의 연결 정보 반환"""
    config = load_db_config(config_file)

    return db_identifier, selected_schema

class DBRouterInput(BaseModel):
    user_query: str = Field(..., description="사용자 쿼리")
    config_file: str = Field("dbconfig.yaml", description="데이터베이스 및 스키마 정보 yaml 파일")

@dbrouter_mcp.tool(description="사용자 쿼리에 적합한 데이터베이스를 routing하고 연결 정보를 반환합니다.")
def db_router(input: DBRouterInput):
    """사용자 쿼리에 따라 적합한 데이터베이스를 선택하고 연결 정보 반환"""
    
    # 1. 데이터 베이스 선택
    selection_result = select_database(input.user_query, input.config_file)
    print(f"\n DB 선택 결과 \n{selection_result}")
    
    # 2. 연결 정보 가져오기
    selected_db = selection_result['selected_database']
    selected_schema = selection_result['selected_schema']
    db_identifier, selected_schema = get_db_connection_info(selected_db, selected_schema, input.config_file)
    print(f"\n 연결 정보 \ndb_identifier:{db_identifier}, schema:{selected_schema}")

    return db_identifier, selected_schema


dbrouter_app = dbrouter_mcp.http_app()

