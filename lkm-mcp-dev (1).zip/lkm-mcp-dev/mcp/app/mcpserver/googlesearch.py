from fastmcp import FastMCP


from pydantic import BaseModel, Field
import os
from dotenv import load_dotenv
import aiohttp

load_dotenv()


googlesearch_mcp = FastMCP(
    name = "GoogleSearchServer",
    stateless_http = True
)
class GoogleSearchInput(BaseModel):
    query: str = Field(..., description="Google 검색에 사용할 쿼리 문자열")
    num: int = Field(5, description="검색 결과 개수 (기본값 5, 최대 10)")

@googlesearch_mcp.tool(description="Google Custom Search API로 검색")
async def google_search(input: GoogleSearchInput):
    query = input.query
    num = input.num
    api_key = os.getenv("GOOGLE_SEARCH_KEY")
    cx = os.getenv("GOOGLE_CX")
    if not api_key:
        raise ValueError("GOOGLE_SEARCH_KEY 환경변수가 설정되어 있지 않습니다.")
    if not cx:
        raise ValueError("GOOGLE_CX 환경변수가 설정되어 있지 않습니다.")
    endpoint = "https://www.googleapis.com/customsearch/v1"
    params = {
        "q": query,
        "key": api_key,
        "cx": cx,
        "num": num
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(endpoint, params=params) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                raise RuntimeError(f"Google API error: {resp.status}, {error_text}")
            data = await resp.json()
            results = []
            for item in data.get("items", []):
                results.append({
                    "title": item.get("title"),
                    "url": item.get("link"),
                    "snippet": item.get("snippet")
                })
            return {"results": results}

googlesearch_app = googlesearch_mcp.http_app()