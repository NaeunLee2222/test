import json
import os
import logging
from datetime import datetime, timedelta
from typing import Optional, List
from pydantic import BaseModel, Field
from fastmcp import FastMCP
import resend
from mcpserver.functions.file_handler import FileHandler
from utils.state_loader import StateLoader


file_handler = FileHandler()
state_loader = StateLoader()

emergency_mail_mcp = FastMCP(
    name = "EmergencyMailServer",
    stateless_http = True
)


class SendEmergencyMailInput(BaseModel):
    """긴급 메일 전용 파라미터 (파일 기반)"""
    output_path: str = Field(..., description="emergency tool로 생성된 비상 대응 메시지 파일의 경로")

def setup_resend():
    """Resend 클라이언트 초기화"""
    api_key = os.getenv("RESEND_API_KEY")
    if not api_key:
        raise ValueError("RESEND_API_KEY 환경변수가 설정되지 않았습니다.")
    
    sender_email = os.getenv("SENDER_EMAIL_ADDRESS")
    if not sender_email:
        raise ValueError("SENDER_EMAIL_ADDRESS 환경변수가 설정되지 않았습니다.")
    
    resend.api_key = api_key.strip()
    return sender_email.strip()


def build_emergency_email_html(disaster_type: str, employee_name: str, employee_position: str, site: str,
                              current_time: str, report_flow: str, file_name: str,
                              team_message: dict, personal_message: str) -> str:
    """긴급 상황용 HTML 이메일 템플릿""" 
    
    # 팀별 역할 HTML 구성
    roles_html = ""
    for role in team_message.get("roles", []):
        roles_html += f"""
        <div style="margin-bottom: 15px;">
            <h4 style="color: #007bff; margin-bottom: 8px; font-size: 16px;">{role.get('role_name', '역할명 없음')}</h4>
            <ul style="margin: 0; padding-left: 20px; color: #495057;">
"""
        for action in role.get("actions", []):
            roles_html += f"                <li style='margin-bottom: 5px;'>{action}</li>\n"
        
        roles_html += """            </ul>
        </div>
"""
    
    # 개인별 메시지를 HTML로 변환
    personal_html = personal_message.replace('\n\n', '</p><p>').replace('\n', '<br>')
    if personal_html and not personal_html.startswith('<p>'):
        personal_html = f"<p>{personal_html}</p>"
    
    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>긴급 대응 요청</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f8f9fa;">
    <div style="max-width: 800px; margin: 0 auto; background-color: white; box-shadow: 0 0 10px rgba(0,0,0,0.1);">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; padding: 25px; text-align: center;">
            <h1 style="margin: 0; font-size: 28px; font-weight: bold;">🚨 긴급 대응 요청</h1>
            <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;">발생시간: {current_time}</p>
        </div>
        
        <!-- Main Content -->
        <div style="padding: 30px;">
            <!-- Alert Box -->
            <div style="background-color: #fff3cd; border: 2px solid #ffeaa7; padding: 20px; border-radius: 8px; margin-bottom: 25px; border-left: 6px solid #f39c12;">
                <h2 style="color: #856404; margin: 0 0 10px 0; font-size: 22px; font-weight: bold;">{site}에서 {disaster_type}</h2>
                <p style="margin: 0; font-size: 16px; line-height: 1.5;"><strong>{employee_name}님({employee_position})</strong> 및 관련 담당자는 아래 역할과 조치 내용을 확인하고 <span style="color: #dc3545; font-weight: bold;">즉시 대응</span>해 주시기 바랍니다.</p>
            </div>
            
            <!-- Action Buttons -->
            <div style="text-align: center; margin-bottom: 30px;">
                <a href="mailto:emergency@company.com?subject=상황접수완료-{employee_name}" 
                   style="display: inline-block; background-color: #28a745; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin: 0 10px; font-weight: bold;">
                    ✅ 상황 접수 완료
                </a>
                <a href="mailto:emergency@company.com?subject=긴급지원요청-{employee_name}" 
                   style="display: inline-block; background-color: #dc3545; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin: 0 10px; font-weight: bold;">
                    🆘 긴급 지원 요청
                </a>
            </div>
            
            <!-- Info Grid -->
            <div style="display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 30px;">
                <div style="flex: 1; min-width: 300px; background-color: #e8f5e8; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px;">
                    <h3 style="color: #155724; margin: 0 0 15px 0; font-size: 18px; border-bottom: 2px solid #155724; padding-bottom: 5px;">📞 보고 및 연락 체계</h3>
                    <p style="font-weight: bold; color: #155724; margin: 0; font-size: 16px; line-height: 1.4;">{report_flow}</p>
                </div>
                <div style="flex: 1; min-width: 300px; background-color: #e2e3f3; border: 1px solid #c3c6e7; padding: 20px; border-radius: 8px;">
                    <h3 style="color: #383d5c; margin: 0 0 15px 0; font-size: 18px; border-bottom: 2px solid #383d5c; padding-bottom: 5px;">📋 참고문서</h3>
                    <p style="margin: 0; font-size: 16px; color: #383d5c; font-weight: 600;">{file_name}</p>
                </div>
            </div>
            
            <!-- Team Response -->
            <div style="border: 1px solid #dee2e6; padding: 25px; border-radius: 8px; margin-bottom: 25px; background-color: #f8f9fa;">
                <h3 style="color: #495057; margin: 0 0 20px 0; font-size: 20px; border-bottom: 3px solid #007bff; padding-bottom: 10px;">🏢 조직별 대응 체계</h3>
                {roles_html}
            </div>
            
            <!-- Personal Instructions -->
            <div style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); border: 2px solid #007bff; padding: 25px; border-radius: 8px; position: relative;">
                <div style="position: absolute; top: -12px; left: 20px; background-color: #007bff; color: white; padding: 5px 15px; border-radius: 15px; font-size: 14px; font-weight: bold;">
                    개인별 조치사항
                </div>
                <h3 style="color: #495057; margin: 15px 0 20px 0; font-size: 20px;">🙋‍♂️ {employee_name}님 개인별 조치</h3>
                <div style="background-color: white; padding: 20px; border-radius: 5px; border-left: 5px solid #007bff; font-size: 15px; line-height: 1.6;">
                    {personal_html}
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div style="background-color: #343a40; color: #adb5bd; padding: 25px; text-align: center; font-size: 14px;">
            <p style="margin: 0 0 10px 0;">이 메시지는 <strong style="color: white;">비상대응시스템</strong>에서 자동 발송되었습니다.</p>
            <p style="margin: 0;">추가 문의사항은 상급자 또는 안전관리팀에 연락하시기 바랍니다.</p>
            <hr style="border: none; border-top: 1px solid #495057; margin: 20px 0;">
            <p style="margin: 0; font-size: 12px; opacity: 0.8;">Emergency Response System | Company Safety Department</p>
        </div>
    </div>
</body>
</html>
"""



@emergency_mail_mcp.tool(description="생성된 긴급 메시지를 이메일을 통해 전송합니다.")
def send_mail(input: SendEmergencyMailInput) -> dict:
    """
    긴급 상황 전용 이메일 발송 도구 (파일 기반)
    emergency tool에서 생성된 JSON 파일을 읽어서 HTML 이메일 발송
    """
    # 파일 경로 처리 (get_file_path 사용)
    output_path = file_handler.get_file_path(input.output_path)
    if not output_path:
        return {
            "success": False,
            "error": f"File not found: {input.output_path}",
            "status_code": None
        }

    encodings = ["utf-8", "cp949", "euc-kr"]
    msg_json = None

    # 파일 읽기 시도
    for encoding in encodings:
        try:
            with open(output_path, 'r', encoding=encoding) as f:
                msg_json = f.read()
            break
        except UnicodeDecodeError:
            continue
        except Exception as e:
            return {
                "success": False,
                "error": f"Unexpected error with {encoding}: {e}",
                "status_code": None
            }

    if msg_json is None:
        return {
            "success": False,
            "error": f"Failed to read file with any encoding: {encodings}",
            "status_code": None
        }

    # JSON 파싱 시도
    try:
        msg_dict = json.loads(msg_json)
    except json.JSONDecodeError as e:
        return {
            "success": False,
            "error": f"Invalid JSON format in file {output_path}: {e}",
            "status_code": None
        }

    
    # 메시지 데이터 추출
    disaster_type = msg_dict.get("disaster_type", "비상상황이 발생했습니다")
    report_flow = msg_dict.get("report_flow", "보고 체계 정보 없음")
    msg_personal = msg_dict.get("msg_personal", "개인별 조치 없음")
    file_name = msg_dict.get("file_name", "비상대응매뉴얼")
    
    # 직원 정보 (human_resource 테이블에서 온 데이터)
    employee_info = msg_dict.get("employee_info", {})
    employee_email = employee_info.get("email", "")
    employee_name = employee_info.get("name", "담당자")
    employee_position = employee_info.get("position", "직원")
    site = employee_info.get("site", "")
    
    target_email = msg_dict.get("target_email", "")
    
    
    try:
        sender_email = setup_resend()
        
        # 현재 시간 (KST)
        current_time = (datetime.now()).strftime("%Y-%m-%d %H:%M")
        
        # 이메일 제목
        subject = f"🚨 긴급 대응 요청 - {disaster_type}"
        
        # HTML 이메일 본문 생성
        html_content = build_emergency_email_html(
            disaster_type, employee_name, employee_position, site, current_time,
            report_flow, file_name, msg_dict.get("msg_team", {}), msg_personal
        )

        context["tool_calling_history"].append(
            {"sender_email": sender_email,
            "target_email": target_email,
            "subject": subject,
            "html_content": html_content,
            "emergency_result": emergency_result})
        
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(context, f, ensure_ascii=False, indent=4)

    except Exception as e:
        context["tool_calling_history"].append(
            {"tool_name": "send_mail",
                "error": str(e)})
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(context, f, ensure_ascii=False, indent=4)
            
        import time
        time.sleep(3)
        
    return file_path
    

@emergency_mail_mcp.tool(description="이메일 전송을 위한 데이터를 읽어서 이메일 전송합니다.")
def send_email(file_path: str) -> str:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            context = json.load(f)
        
        tool_calling_history = context["tool_calling_history"][-1]
    
        sender_email = tool_calling_history["sender_email"] if tool_calling_history.get("sender_email") else ""
        target_email = tool_calling_history["target_email"] if tool_calling_history.get("target_email") else ""
        subject = tool_calling_history["subject"] if tool_calling_history.get("subject") else ""
        html_content = tool_calling_history["html_content"] if tool_calling_history.get("html_content") else ""
        emergency_result = tool_calling_history["emergency_result"]

        dict_for_class = {}
        if sender_email != "":
            dict_for_class["sender_email"] = "발신자의 이메일"
        if target_email != "":
            dict_for_class["target_email"] = "수신자의 이메일"
        if subject != "":
            dict_for_class["subject"] = "이메일 제목"
        if html_content != "":
            dict_for_class["html_content"] = "이메일 내용"
        
        # dict_for_class를 사용해서 동적으로 InputModel 생성
        if list(dict_for_class.keys()) != []:
            InputModel = create_input_model_from_dict(dict_for_class, "InputModel")
            print(f"생성된 InputModel 필드: {list(dict_for_class.keys())}")
            input_data = state_loader.invoke_state(StrOutput=InputModel, file_path=file_path)
            print(f"input_data: {input_data}")
            if dict_for_class.get("sender_email"):
                sender_email = input_data.sender_email
            if dict_for_class.get("target_email"):
                target_email = input_data.target_email
            if dict_for_class.get("subject"):
                subject = input_data.subject
            if dict_for_class.get("html_content"):
                html_content = input_data.html_content
        

            # Resend를 통한 이메일 발송
        email_response = resend.Emails.send({
            "from": sender_email,
            "to": [target_email],
            "subject": subject,
            "html": html_content,
        })

        return_message = f"{target_email}에게 이메일이 성공적으로 전송되었습니다."
        context["tool_calling_history"].append(
            {"emergency_result": emergency_result})
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(context, f, ensure_ascii=False, indent=4)
        import time
        time.sleep(3)


    except Exception as e:
        context["tool_calling_history"].append(
            {"tool_name": "send_email",
                "error": str(e)})
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(context, f, ensure_ascii=False, indent=4)
        import time
        time.sleep(3)
        return_message = f"이메일 전송 중 오류가 발생했습니다."
    return return_message



emergency_mail_app = emergency_mail_mcp.http_app()