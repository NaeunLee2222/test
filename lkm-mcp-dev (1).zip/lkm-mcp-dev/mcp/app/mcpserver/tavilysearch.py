from fastmcp import FastMCP


from tavily import TavilyClient
from pydantic import BaseModel, Field
import os
from dotenv import load_dotenv

# .env 파일에서 환경변수 불러오기
load_dotenv()

tavilysearch_mcp = FastMCP(
    name = "TavilySearchServer",
    stateless_http = True
)

class TavilySearchInput(BaseModel):
    query: str = Field(..., description="타빌리 검색에 사용할 쿼리 문자열")

@tavilysearch_mcp.tool(description="Tavily Search API로 웹 검색")
async def tavily_search(input: TavilySearchInput): 
    query = input.query
    api_key = os.getenv("TAVILY_SEARCH_API_KEY")
    if not api_key:
        raise ValueError("TAVILY_SEARCH_API_KEY 환경변수가 설정되어 있지 않습니다.")
    tavily_client = TavilyClient(api_key=api_key)
    response = tavily_client.search(query)
    return response

tavilysearch_app = tavilysearch_mcp.http_app()


