from fastmcp import FastMCP

from pydantic import BaseModel, Field
from mcp.types import TextContent
from typing import Union, List, Dict, Any
from langchain_openai import AzureChatOpenAI

import os
import json
import psycopg2
from psycopg2 import Error
import re
from pathlib import Path
import csv
import yaml
from typing import List, Optional, Dict, Any, Union
import uuid

from mcpserver.functions.file_handler import FileHandler
from utils.state_loader import StateLoader

file_handler = FileHandler()
state_loader = StateLoader()

searchrdb_mcp = FastMCP(
    name = "SearchRdbServer",
    stateless_http = True
)

def load_db_config(db_identifier: str, schema_name: str):
    """YAML 파일에서 특정 데이터 베이스와 스키마 설정을 로드합니다."""
    try:
        config_path = Path("dbconfig.yaml")
        if not config_path.exists():
            raise FileNotFoundError(f"dbconfig file not found: {config_path}")
        with open(config_path, 'r', encoding='utf-8') as file:
            config = yaml.safe_load(file)
        
        db_config = config["databases"][db_identifier]

        #필드 검증
        contents = ["host", "database", "username", "password", "port"]
        for content in contents:
            if content not in db_config:
                raise ValueError(f"Missing required field '{content}' in database config for '{db_identifier}'")
        connection_config = {
            "host": db_config.get("host"),
            "database": db_config.get("database"),
            "user": db_config.get("username"),
            "password": db_config.get("password"),
            "port": db_config.get("port", 5432),
        }
        return connection_config, schema_name
    
    except Exception as e:
        error_msg = f"Error loading dbconfig.yaml for {db_identifier}: {e}"
        return None, error_msg



def create_llm():
    return AzureChatOpenAI(
        azure_deployment=os.getenv("OPENAI_DEPLOYMENT"),
        azure_endpoint=os.getenv("OPENAI_ENDPOINT"),
        api_version=os.getenv("OPENAI_API_VERSION"),
        api_key=os.getenv("OPENAI_API_KEY"),
        n=1,
        temperature=0,
        max_tokens=500,
        model=os.getenv("OPENAI_MODEL"),
        verbose=True,
        streaming=False,
    )

def extract_sql_from_response(content):
    """LLM 응답에서 SQL 쿼리만 추출"""

    sql_pattern = r"```sql\s*(.*?)\s*```"
    matches = re.findall(sql_pattern, content, re.DOTALL)

    if matches:
        return matches[0].strip()
    else:
        try:
            # 일반적인 SQL 패턴을 찾되, 주석은 제외
            sql_keywords = r"(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER)"
            matches = re.findall(
                f"{sql_keywords}.*?;", content, re.DOTALL | re.IGNORECASE
            )
            if matches:
                return matches[0].strip()
        except Exception as e:
            pass

    return None

def get_db_schema(conn):
    """PostgreSQL 데이터베이스에 연결해 현재 스키마의 테이블/칼럼/PK 정보를 문자열로 반환한다"""
    schema = []

    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"""
                set search_path to {DB_SCHEMA};
                show search_path;
                           """
            )

            # 테이블 리스트 검색
            cursor.execute(
                f"""
                SELECT table_schema,table_name 
                FROM information_schema.tables 
                WHERE table_schema = '{DB_SCHEMA}'
            """
            )
            tables = cursor.fetchall()

            if not tables:
                return "No tables found in the database schema."

            for table in tables:
                table_schema = table[0]
                table_name = table[1]

                # 각 테이블의 column 정보 검색
                cursor.execute(
                    f"""
                    SELECT column_name, data_type 
                    FROM information_schema.columns 
                    WHERE table_name = '{table_name}'
                """
                )
                columns = cursor.fetchall()

                if not tables:
                    return f"No tables found in the database schema {DB_SCHEMA}."

                table_info = f"Table: {table_schema}.{table_name}\nColumns:\n"
                for col in columns:
                    col_name, col_type = col
                    table_info += f"  - {col_name}: {col_type}\n"

                # 추가: 기본 키 정보 가져오기
                cursor.execute(
                    f"""
                    SELECT c.column_name
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.constraint_column_usage AS ccu USING (constraint_schema, constraint_name)
                    JOIN information_schema.columns AS c ON c.table_schema = tc.constraint_schema
                      AND tc.table_name = c.table_name AND ccu.column_name = c.column_name
                    WHERE constraint_type = 'PRIMARY KEY' AND tc.table_name = '{table_name}'
                """
                )
                pks = cursor.fetchall()
                if pks:
                    pk_names = [pk[0] for pk in pks]
                    table_info += f"Primary Key(s): {', '.join(pk_names)}\n"

                schema.append(table_info)

            cursor.execute(
                """
                set search_path to default;
                           """
            )

        return "\n".join(schema)

        

    except Error as e:
        return f"Error retrieving schema: {str(e)}"

def fix_sql_query(llm, db_schema, query, sql_query, error_info):
    """LLM을 사용해 SQL 문법 오류 자동 수정"""

    system_prompt = f"""You are a PostgreSQL database expert. Review the user's question, 
    the database schema, the SQL query that was generated, and the error message returned by 
    the database. Fix ONLY the syntax errors in the SQL query without changing the logic.
    Output ONLY the fixed SQL query wrapped in ```sql and ``` tags.

    Database Schema:
    {db_schema}
    """

    user_prompt = f"""Question: {query}

    SQL Query with errors:
    {sql_query}

    Error message:
    {error_info}

    Please fix the SQL syntax errors only. Return ONLY the corrected SQL query.
    
    ADDITIONAL INSTRUCTION:
    - When using LIKE clauses, also consider creating OR conditions with Korean/English translations of the search keywords to improve search coverage.
    - For example: WHERE column LIKE '%keyword%' OR column LIKE '%키워드%' OR column LIKE '%translated_term%'
    - If the error is "No results found", make LIKE keywords more general and less specific. Use shorter, broader terms instead of exact phrases.
    - For example: change '%머신러닝 모델%' to '%머신러닝%' or '%모델%', change '%불량 원인 분석%' to '%불량%' or '%원인%'"""

    try:
        response = llm.invoke(system_prompt + "\n\n" + user_prompt)
        content = response.content
        fixed_sql = extract_sql_from_response(content)

        if fixed_sql:
            return fixed_sql
        else:
            return sql_query  # 생성 실패 시 원래 코드 반환
    except Exception as e:
        return sql_query

class SearchRdbInput(BaseModel):
    query: str = Field(..., description="데이터베이스 검색에 사용할 자연어 쿼리")
    db_identifier: str = Field(..., description="dbconfig.yaml 파일의 데이터베이스 식별자")
    schema_name: str = Field(..., description="dbconfig.yaml 파일의 데이터베이스 스키마 이름")

@searchrdb_mcp.tool(description="routing된 데이터베이스에 연결하여 자연어 쿼리에 대해 생성한 SQL로 관계형 데이터베이스를 검색합니다.")
def searchrdb(input: SearchRdbInput) -> Union[List[TextContent], Dict[str, Any], str]:    
    """
    자연어 쿼리를 사용하여 관계형 데이터베이스를 검색합니다.

    Args:
        query: 데이터베이스 검색에 사용할 자연어 쿼리
        db_identifier: dbconfig.yaml 파일의 데이터베이스 식별자
        schema_name: dbconfig.yaml 파일의 데이터베이스 스키마 이름
    """
    try:
        llm = create_llm()
    except Exception as e:
        error_msg = f"Failed to initialize LLM: {str(e)}"

        return [TextContent(type="text", text=error_msg)]

    conn = None

    global DB_CONFIG, DB_SCHEMA
    
    try:
        DB_CONFIG, DB_SCHEMA = load_db_config(db_identifier=input.db_identifier, schema_name=input.schema_name)

        # PostgreSQL 연결
        conn = psycopg2.connect(**DB_CONFIG)

        # Database schema 불러오기
        db_schema = get_db_schema(conn)
        print("\ndb_schema")
        print(db_schema)

        system_prompt = f"""You are a PostgreSQL database expert. Your task is to convert natural language questions
        into correct SQL queries based on the database schema provided. Return ONLY the SQL query wrapped in 
        ```sql and ``` tags. Ensure the SQL is syntactically correct for PostgreSQL.

        Database Schema:
        {db_schema}
        """
    
        user_prompt = f"""
        Convert this question to SQL: {input.query}

        IMPORTANT
        - If there are keywords, use LIKE in the WHERE clause
        - When using AS clauses for column aliases, always maintain the original column names.
        """

        # LLM으로 SQL 생성
        response = llm.invoke(system_prompt + "\n\n" + user_prompt)
        content = response.content
        sql_query = extract_sql_from_response(content)

        print("\nsql_query")
        print(sql_query)

        if not sql_query:
            return [
                TextContent(
                    type="text",
                    text="Failed to generate SQL query from the question. Please try rephrasing your question.",
                )
            ]

        # SQL 쿼리 실행
        try:
            with conn.cursor() as cursor:
                cursor.execute(sql_query)

                # INSERT, UPDATE, DELETE, etc 인 경우 커밋 안함
                if cursor.description is None:
                    return [
                        TextContent(
                            type="text",
                            text=f"SQL Query:\n```sql\n{sql_query}\n```\n\nDatabase change detected. This operation is not allowed."
                        )
                    ]
                    # 변경사항 적용 코드
                    # affected_rows = cursor.rowcount
                    # conn.commit() #변경사항 커밋
                    # return [
                    #     TextContent(
                    #         type="text",
                    #         text=f"SQL Query:\n```sql\n{sql_query}\n```\n\nQuery executed successfully. Affected rows: {affected_rows}",
                    #     )
                    # ]

                # SELECT만 있는 경우
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()

                result_md = "| " + " | ".join(columns) + " |\n"
                result_md += "| " + " | ".join(["---" for _ in columns]) + " |\n"

                if not rows:
                    raise Error("No results found")

                else:
                    csv_filename = f"searhrdb_result_{str(uuid.uuid4())}.csv"
                    csv_filename = file_handler.get_dir_path(csv_filename)
                    
                    if os.path.exists(csv_filename):
                        with open(csv_filename, "r", encoding="utf-8") as check_file:
                            if check_file.read().strip():  
                                open(csv_filename, "w").close() 
                    
                    with open(csv_filename, "w", newline="", encoding="utf-8") as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow(columns)
                        for idx, row in enumerate(rows):
                            writer.writerow([str(val) if val is not None else "" for val in row])
                            if idx < 50:
                                row_values = [str(val) if val is not None else "NULL" for val in row]
                                result_md += "| " + " | ".join(row_values) + " |\n"

                    if len(rows) > 50:
                        result_md += "\n_Note: Results limited to 100 rows. Full results are saved in the CSV file._"

                print(f"SQL Query:\n```sql\n{sql_query}\n```\n\nResults:\n{result_md}")
                return csv_filename

        # 에러 있는 경우 SQL문 수정
        except Error as e:
            conn.rollback()

            for attempt in range(4):
                fixed_sql = fix_sql_query(
                    llm, db_schema, input.query, sql_query, str(e)
                )

                if fixed_sql == sql_query:
                    break  # 수정사항 없을 시 Break

                sql_query = fixed_sql
                print("\nfixed_sql_query")
                print(sql_query)

                try:
                    with conn.cursor() as cursor:
                        cursor.execute(sql_query)

                        if cursor.description is None:
                            return [
                                TextContent(
                                    type="text",
                                    text=f"SQL Query:\n```sql\n{sql_query}\n```\n\nDatabase change detected. This operation is not allowed."
                                )
                            ]
                            # 변경사항 적용 코드
                            # affected_rows = cursor.rowcount
                            # conn.commit() #변경사항 커밋
                            # return [
                            #     TextContent(
                            #         type="text",
                            #         text=f"SQL Query:\n```sql\n{sql_query}\n```\n\nQuery executed successfully. Affected rows: {affected_rows}",
                            #     )
                            # ]

                        columns = [desc[0] for desc in cursor.description]
                        rows = cursor.fetchall()

                        result_md = "| " + " | ".join(columns) + " |\n"
                        result_md += (
                            "| " + " | ".join(["---" for _ in columns]) + " |\n"
                        )

                        if not rows:
                            raise Error("No results found")

                        else:
                            csv_filename = f"searhrdb_result_{str(uuid.uuid4())}.csv"
                            csv_filename = file_handler.get_dir_path(csv_filename)

                            if os.path.exists(csv_filename):
                                with open(csv_filename, "r", encoding="utf-8") as check_file:
                                    if check_file.read().strip():  
                                        open(csv_filename, "w").close() 

                            with open(csv_filename, "w", newline="", encoding="utf-8") as csvfile:
                                writer = csv.writer(csvfile)
                                writer.writerow(columns)
                                for idx, row in enumerate(rows):
                                    writer.writerow([str(val) if val is not None else "" for val in row])
                                    if idx < 50:
                                        row_values = [str(val) if val is not None else "NULL" for val in row]
                                        result_md += "| " + " | ".join(row_values) + " |\n"

                            if len(rows) > 50:
                                result_md += "\n_Note: Results limited to 100 rows. Full results are saved in the CSV file._"

                        print(f"SQL Query:\n```sql\n{sql_query}\n```\n\nResults:\n{result_md}")
                        return csv_filename

                except Error as e2:
                    if attempt == 3:  # 마지막 시도 실패
                        return [
                            TextContent(
                                type="text",
                                text=f"Failed to execute SQL query after multiple fix attempts.\n\nSQL Query:\n```sql\n{sql_query}\n```\n\nError: {str(e2)}\n\nPlease try rephrasing your question or check if the requested data exists in the database.",
                            )
                        ]

    except Error as e:
        error_msg = f"Database connection error: {str(e)}"
        return [TextContent(type="text", text=error_msg)]

    finally:
        if conn:
            conn.close()
    
    return [TextContent(type="text", text="Unexpected error occurred")]


searchrdb_app = searchrdb_mcp.http_app()
