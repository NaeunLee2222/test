import os
import random
import json
import html
import re
from fastmcp import FastMCP
from bs4 import BeautifulSoup
from difflib import SequenceMatcher
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from mcpserver.functions.saver import save_html
from mcpserver.functions.converter import convert_html_to_docx
# from mcpserver.functions.file_handler import FileHandler
from utils.llm import LLMSingleton

# file_handler = FileHandler()

llm = LLMSingleton.get_llm()

html_mcp = FastMCP(
    name = "HtmlServer",
    stateless_http = True
)

class HtmlHighlighterInput(BaseModel):
    highlighted_info_path: str = Field(..., description="하이라이트 할 정보가 담긴 json 파일의 경로")


class ReplaceRfqItemListInput(BaseModel):
    base_html_path: str = Field(..., description="생성된 RFQ 파일 (html)의 경로 (**주의: RFQ 커버 파일 아님**)")
    user_query: str = Field(..., description="사용자 요청")


class CreateRfqCoverInput(BaseModel):
    metadata: dict = Field(
        ...,
        description="""메타데이터 딕셔너리.{{
    "project_no": "추출된 장비명",
    "project_title": "추출된 프로젝트명",
    "location": "추출된 위치",
    "client": "추출된 고객사명",
    "date": "추출된 날짜",
    "prp": "추출된 작성자",
    "rew": "추출된 검토자",
    "app": "추출된 승인자" }} """,
    )


class CreateRfqCoverOutput(BaseModel):
    rfq_cover_path: str = Field(..., description="생성된 RFQ 커버 페이지의 경로")


class CombineRfqCoverInput(BaseModel):
    base_html_path: str = Field(..., description="생성된 RFQ 파일 (html)의 경로")
    cover_path: str = Field(..., description="커버 페이지의 경로")


class CombineRfqCoverOutput(BaseModel):
    combined_rfq_html_path: str = Field(..., description="커버 페이지가 삽입된 최종 RFQ 문서(html)의 경로 (Canvas 출력용)")
    combined_rfq_docx_path: str = Field(..., description="커버 페이지가 삽입된 최종 RFQ 문서(docx)의 경로")


class mergeHTMLsInput(BaseModel):
    highlighted_htmls_path: list = Field(
        ..., description="하이라이트 완료된 HTML 파일들의 경로를 담은 리스트"
    )
  

#@html_mcp.tool(description="HTML 문서에서 지정된 문장들을 하이라이트 처리합니다.")
def html_highlighter(input: HtmlHighlighterInput) -> str:
    with open(input.highlighted_info_path, encoding="utf-8") as f:
        highlighted_info = json.load(f)

    paths = highlighted_info["names"]
    highlight_sentences_list = highlighted_info["sentences"]
    highlight_p_tags_list = highlighted_info["p_tags"]
    highlight_colors = highlighted_info["highlight_colors"]

    random_num = random.randint(1, 9999)

    save_paths = []

    for idx in range(len(paths)):

        if paths[idx].lower().endswith(".html"):
            cur_path = paths[idx]
        else:
            # start_page 1로 설정
            cur_path = docxTohtml(DocxToHtmlInput(docx_path=paths[idx], start_page=1))

        cur_input = {
            "html_path": cur_path,
            "highlight_sentences": highlight_sentences_list[idx],
            "highlight_p_tags": highlight_p_tags_list[idx],
            "output_path": f"result/highlihted_result_{idx}_{random_num}.html",
            "highlight_color": highlight_colors[idx],
        }

        highlighted_count = 0
        table_count = 0
        not_found_texts = []

        html_text = open(cur_input["html_path"], "r", encoding="utf-8").read()

        # highlight_sentences 리스트의 각 문장에 대해 하이라이팅 수행
        soup = BeautifulSoup(html_text, "html.parser")
        ##### Markdown 가정. 나중에 고쳐야 함.
        for sentence in cur_input["highlight_sentences"]:
            # 일반 텍스트 하이라이팅 처리
            if not is_markdown_table_row(sentence):
                result = highlight_html_text(
                    soup,
                    sentence,
                    threshold=0.9,
                    highlight_color=cur_input["highlight_color"],
                )
                if result:
                    highlighted_count += 1
                else:
                    not_found_texts.append(sentence)
            else:
                matched_rows = highlight_html_table_row(soup, sentence)
                if matched_rows:
                    table_count += 1
                else:
                    not_found_texts.append(sentence)

        highlight_html_p_tag(
            soup, cur_input["highlight_p_tags"], cur_input["highlight_color"]
        )

        # print(f"\n{highlighted_count}개의 매칭된 텍스트 태그와 {table_count}개의 테이블 행을 하이라이팅했습니다.")


        # 매칭되지 않은 텍스트 출력
        if not_found_texts:
            print("\n\n===== 매칭되지 않은 텍스트 =====")
            print(f"총 {len(not_found_texts)}개의 텍스트가 매칭되지 않았습니다.")
            for i, text in enumerate(not_found_texts):
                print(f"\n{i+1}. {text}")

        full_path = os.path.join(os.getcwd(), cur_input["output_path"])
        save_path = save_html("","",str(soup),full_path=full_path)

        save_paths.append(save_path)

    return save_paths


@html_mcp.tool(description="RFQ 문서의 아이템 리스트를 사용자 요청에 포함된 새로운 아이템 리스트로 교체합니다.")
def replace_rfq_item_list(input: ReplaceRfqItemListInput) -> str:
    """RFQ 문서의 아이템 리스트를 새로운 아이템 리스트로 교체. RFQ 문서에서 아이템 테이블을 지우고, 새로운 html 테이블 삽입."""

    with open(input.base_rfq_html_path, "r", encoding="utf-8") as f:
        rfq_html = f.read()
    new_item_table_html = create_item_table_html(input.user_query)
    rfq_html_content = extract_tables_from_html(rfq_html)

    rfq_item_prompt = f"""
    다음 텍스트는 RFQ 문서에서 추출한 테이블들입니다. 이 테이블을 분석하여 정확한 Item No을 하나만 추출해 주세요.
    
    [참고 사항]
    Item No는 여러 개가 존재할 수 있습니다. 이 중 하나만 찾아 정확한 item no만 추출해 주세요.
    추출된 Item No를 반환해 주세요.
    
    RFQ 문서에서 추출한 테이블 내용:
    {rfq_html_content}
    
    예시 반환값: AL-E5401A
    추가 설명은 불필요합니다.
    """

    # 아이템 리스트 테이블이 여러 개일 수 있으므로, 매칭되는 모든 테이블을 새 테이블로 교체한다.

    rfq_item_no_response = llm.invoke(rfq_item_prompt)
    rfq_item_no = rfq_item_no_response.content.strip()

    soup = BeautifulSoup(rfq_html, "html.parser")
    tables = soup.find_all("table")
    found_tables = []

    # 1. rfq_item_no가 포함된 테이블을 모두 찾는다.
    for table in tables:
        if rfq_item_no and rfq_item_no in table.get_text():
            found_tables.append(table)

            # 해당 테이블 근처 (보통 아래에) special note 관련한 문장이 존재함.
            # 먼저 llm에게 해당 테이블 근처의 문장을 입력값으로 주고, special note(s) 관련 문장이 있는지 확인
            # 해당 테이블과, 근처 문장들을 추출. (n자 이내로)

            # 테이블 이후 n자 이내의 텍스트를 추출
            # 테이블 다음 모든 태그를 순회하며 텍스트를 누적
            next_node = table.next_sibling
            collected_text = ""
            char_limit = 1500
            while next_node and len(collected_text) < char_limit:
                # 태그 또는 NavigableString 모두 처리
                if hasattr(next_node, "get_text"):
                    text = next_node.get_text(separator=" ", strip=True)
                else:
                    text = str(next_node).strip()
                if text:
                    collected_text += text + " "
                next_node = next_node.next_sibling
            special_note_context = collected_text[:char_limit].strip()

            special_note_prompt = f"""
            다음 텍스트는 RFQ 문서에서 추출한 html 텍스트입니다. 이 텍스트에서 Special Note(s)가 있다면 첫 번째 문장의 텍스트 내용과 마지막 문장의 텍스트 내용을 추출해 주세요.
            RFQ 문서에서 추출한 items and quantities 테이블 아래의 문장들 텍스트:
            {special_note_context}

            ## Instructions
            1. special note 가 있는지 판단하세요.
            2. special note가 없다면, 빈 리스트를 반환하시오.
            3. special note가 있다면, 다음 참고사항을 참고하여 specail notes의 첫 번째 문장과 마지막 문장을 추출하세요.

            ## special note 관련 참고 사항
            보통 special note는 items and quantities 테이블 아래에 있습니다.
            시작은 special note 관련 문장입니다. special note 또는 비슷한 문장이 있다면, 첫 번째 문장으로 채택하세요.
            만약, special note가 소제목처럼 있다면, 이를 첫 문장으로 채택하세요. ex) [ Special Note ]
            문장은 텍스트를 온전하게 추출해 주세요.
            
            반드시 다음 형식으로만 답변해 주세요:
            ["첫 번째 문장 내용", "마지막 문장 내용"]
            
            위 형식이 아닌 답변은 절대로 하지 마세요. 코드 블록이나 plaintext 등 다른 형식으로 감싸지 마세요.
            """

            special_note_response = llm.invoke(special_note_prompt)
            special_note_content = special_note_response.content.strip()

            print(special_note_content)

            # LLM 응답을 JSON으로 파싱 시도
            try:
                special_note = json.loads(special_note_content)
                if isinstance(special_note, list) and len(special_note) == 2:
                    special_note_start = special_note[0]
                    special_note_end = special_note[1]

                    # 테이블 다음의 모든 sibling 요소들을 순회하며 special note 범위 찾기
                    current_node = table.next_sibling
                    start_found = False
                    end_found = False
                    nodes_to_remove = []
                    accumulated_text = ""

                    while current_node and not end_found:
                        # 텍스트 노드나 태그 노드 모두 처리
                        if hasattr(current_node, "get_text"):
                            node_text = current_node.get_text(strip=True)
                        else:
                            node_text = str(current_node).strip()

                        # 의미있는 텍스트가 있는 경우에만 처리
                        if node_text:
                            accumulated_text += " " + node_text
                            accumulated_text = accumulated_text.strip()

                            # 공백을 제거한 텍스트로 매칭 확인
                            accumulated_text_no_space = accumulated_text.replace(" ", "")
                            special_note_start_no_space = special_note_start.replace(" ", "")
                            special_note_end_no_space = special_note_end.replace(" ", "")
                            
                            # 시작 문장을 찾았을 때 - 더 단순한 조건으로 변경
                            if not start_found and special_note_start_no_space in accumulated_text_no_space:
                                start_found = True
                                print(f"★ START 매칭으로 start_found = True 설정")
                                # 현재까지의 모든 노드를 수집
                                nodes_to_remove = []
                                temp_node = table.next_sibling
                                while temp_node and temp_node != current_node.next_sibling:
                                    nodes_to_remove.append(temp_node)
                                    temp_node = temp_node.next_sibling
                            
                            # 시작을 찾은 후 계속 수집
                            elif start_found:
                                nodes_to_remove.append(current_node)

                            # 마지막 문장을 찾으면 종료 - 시작과 끝이 같은 경우 처리
                            if start_found and (special_note_end_no_space in accumulated_text_no_space or special_note_start == special_note_end):
                                end_found = True
                                print(f"★ END 매칭으로 end_found = True 설정")
                                break
                        else:
                            # 빈 텍스트 노드도 시작을 찾은 후라면 수집
                            if start_found:
                                nodes_to_remove.append(current_node)

                        current_node = current_node.next_sibling

                    # special note 영역 삭제
                    if start_found and end_found:
                        for i, node in enumerate(nodes_to_remove):
                            try:
                                if hasattr(node, "decompose"):
                                    node.decompose()
                                elif hasattr(node, "extract"):
                                    node.extract()
                                else:
                                    # NavigableString인 경우
                                    if node.parent:
                                        node.parent.remove(node)
                            except Exception as e:
                                print(f"노드 삭제 실패: {e}")
                    else:
                        print(f"★ 삭제 조건 미충족 - start_found: {start_found}, end_found: {end_found}")

            except (json.JSONDecodeError, IndexError, TypeError):
                # JSON 파싱 실패시 로그만 남기고 계속 진행
                print(f"Special note 파싱 실패: {special_note_content}")

        # 2. 매칭된 모든 테이블을 새 테이블로 교체
        if found_tables:
            for table in found_tables:
                # 새 테이블을 생성하고 table의 내용을 교체
                new_table_soup = BeautifulSoup(new_item_table_html, "html.parser")
                new_table = new_table_soup.find("table")  # 새로 생성된 테이블 요소 추출
                
                # 기존 테이블의 모든 내용을 새 테이블 내용으로 교체
                table.clear()  # 기존 테이블 내용 삭제
                table.append(new_table)  # 새 테이블 내용 추가

    current_dir = "/app/shared_data/compared_result"
    filename = f"item_list_replaced_result_{random.randint(1,9999)}.html"
    output_path = save_html(current_dir, filename, str(soup))

    return output_path


@html_mcp.tool(description="RFQ 문서의 커버 페이지를 생성합니다.")
def create_rfq_cover(input: CreateRfqCoverInput) -> CreateRfqCoverOutput:

    cover_html = replace_metadata(input.metadata)
    
    # 커버 HTML을 파일로 저장
    # current_dir = file_handler.get_dir_path("rfq/result")
    current_dir = "/app/shared_data/result"
    cover_filename = f"rfq_cover_{random.randint(1,9999)}.html"
    output_path = save_html(current_dir, cover_filename, cover_html)

    return CreateRfqCoverOutput(rfq_cover_path=output_path)


@html_mcp.tool(description="RFQ 문서의 커버 페이지를 기존 HTML에 삽입합니다.")
def combine_rfq_cover(input: CombineRfqCoverInput) -> CombineRfqCoverOutput:

    with open(input.base_html_path, "r", encoding="utf-8") as f:
        html_content = f.read()

    html_soup = BeautifulSoup(html_content, "html.parser")

    with open(input.cover_path, "r", encoding="utf-8") as f:
        cover_html = f.read()
    
    cover_soup = BeautifulSoup(cover_html, "html.parser")
    cover_body_content = cover_soup.body.decode_contents()

    # 기존 HTML의 body 태그 찾기
    body_tag = html_soup.body

    # body 태그의 시작 부분에 cover HTML의 body 내용 삽입
    if body_tag:
        # 기존 내용을 임시 저장
        original_content = body_tag.decode_contents()
        # body 태그 내용을 비우고
        body_tag.clear()
        # cover HTML 내용을 먼저 추가
        body_tag.append(BeautifulSoup(cover_body_content, "html.parser"))
        # 기존 내용을 다시 추가
        body_tag.append(BeautifulSoup(original_content, "html.parser"))

        print("metadata update 완료")

    # target_dir = file_handler.get_dir_path("rfq/result")
    target_dir = "/app/shared_data/result"

    # 파일명에서 숫자 부분만 추출
    base_name = os.path.basename(input.cover_path)
    name_without_ext = os.path.splitext(base_name)[0]  # 확장자 제거
    
    # 정규표현식을 사용하여 숫자 부분 추출
    number_match = re.search(r'_(\d+)$', name_without_ext)
    if number_match:
        extracted_number = number_match.group(1)
        output_file_name = f"final_rfq_{extracted_number}.html"
    else:
        output_file_name = base_name.replace(".html", "_final_rfq.html")

    output_html_path = save_html(target_dir,output_file_name,str(html_soup))

    output_docx_path = convert_html_to_docx(output_html_path)

    return CombineRfqCoverOutput(combined_rfq_html_path=output_html_path, combined_rfq_docx_path=output_docx_path)


def normalize_text(text):
    """
    텍스트를 정규화하는 함수 - 연속된 공백을 하나로 치환

    Args:
        text: 정규화할 텍스트

    Returns:
        정규화된 텍스트
    """
    return re.sub(r"\s+", " ", text.strip())


def highlight_html_text(soup, query, threshold=0.9, highlight_color="mistyrose"):
    """
    HTML 문서 전체에서 쿼리 텍스트를 찾고, 매칭되는 모든 요소를 반환하는 함수

    Args:
        soup: BeautifulSoup 객체
        query: 찾을 텍스트
        threshold: 유사도 임계값 (0~1)

    Returns:
        매칭된 요소들의 그룹 목록
    """

    all_text_nodes = []
    for element in soup.find_all(string=True):
        if element.strip():
            all_text_nodes.append(
                {
                    "element": element,
                    "text": normalize_text(element),
                    "parent": element.parent,
                    "parent_tag": element.parent.name,
                    "parent_attrs": element.parent.attrs,
                }
            )

    # 쿼리 정규화
    query_clean = normalize_text(query)

    # 전체 문서 텍스트 생성 (각 노드 사이에 공백 추가)
    document_text = " ".join(node["text"] for node in all_text_nodes)

    # 전체 문서에서 쿼리 찾기
    matches = []

    # 전체 문서에서 정확한 일치 검색
    if query_clean in document_text:
        # 정확한 일치가 있는 경우 단순 문자열 위치 비교로 찾기
        start_pos = 0
        while True:
            pos = document_text.find(query_clean, start_pos)
            if pos == -1:
                break

            matches.append(
                {
                    "type": "exact",
                    "position": pos,
                    "length": len(query_clean),
                    "text": query_clean,
                }
            )
            start_pos = pos + 1

    # 유사도 기반 검색 (정확한 일치가 없는 경우)
    if not matches:
        # 슬라이딩 윈도우 방식으로 유사한 부분 찾기
        window_size = len(query_clean.split())
        words = document_text.split()

        for i in range(len(words) - window_size + 1):
            window_text = " ".join(words[i : i + window_size])
            similarity = SequenceMatcher(
                None, query_clean.lower(), window_text.lower()
            ).ratio()

            if similarity >= threshold:
                # 유사한 부분 찾음
                pos = document_text.find(window_text)
                matches.append(
                    {
                        "type": "similar",
                        "position": pos,
                        "length": len(window_text),
                        "text": window_text,
                        "similarity": similarity,
                    }
                )

    # 매칭된 부분에 해당하는 원본 텍스트 노드 찾기
    match_results = []

    for match in matches:
        match_start = match["position"]
        match_end = match_start + match["length"]

        # 매칭된 부분에 해당하는 원본 텍스트 노드 찾기
        current_pos = 0
        matched_nodes = []

        for i, node in enumerate(all_text_nodes):
            node_start = current_pos
            node_text = node["text"]
            node_end = node_start + len(node_text) + 1  # +1은 노드 사이 공백 고려

            # 노드가 매칭 범위와 겹치는지 확인
            if node_start < match_end and node_end > match_start:
                matched_nodes.append(node)

                # 매칭된 노드에 하이라이팅 적용
                node["element"].wrap(
                    soup.new_tag("span", style=f"background-color: {highlight_color};")
                )

            current_pos = node_end

        if matched_nodes:
            match_result = {
                "type": match["type"],
                "matched_text": match["text"],
                "similarity": match.get("similarity", 1.0),
                "nodes": matched_nodes,
                "elements": [node["element"] for node in matched_nodes],
                "parents": [node["parent"] for node in matched_nodes],
            }
            match_results.append(match_result)

    # 유사도 및 매치 유형 기준으로 정렬
    match_results.sort(
        key=lambda x: (1 if x["type"] == "exact" else 0, x["similarity"]), reverse=True
    )

    return match_results


def highlight_html_p_tag(soup, p_tag_idx_list: List[int], highlight_color="mistyrose"):
    # 테이블 셀(td, th) 내의 p 태그만 찾아서 리스트로 만듦
    all_p_tags = []
    for cell in soup.find_all(["td", "th"]):
        p_tags = cell.find_all("p")
        for p in p_tags:
            all_p_tags.append(p)

    for p_tag_idx in p_tag_idx_list:
        if p_tag_idx < len(all_p_tags):
            # 해당 인덱스의 셀 선택
            p_tag = all_p_tags[p_tag_idx]

        # 셀 텍스트 저장
        p_tag_text = p_tag.get_text().strip()
        # 공백 정규화
        p_tag_text = re.sub(r"\s+", " ", p_tag_text)

        # 셀에 직접 스타일 적용하여 하이라이팅
        if "style" in p_tag.attrs:
            p_tag["style"] = p_tag["style"] + f"; background-color: {highlight_color};"
        else:
            p_tag["style"] = f"background-color: {highlight_color};"
    return


def is_markdown_table_row(text):
    """
    마크다운 테이블 행인지 확인하는 함수
    """
    # 공백 제거 후 확인
    text = text.strip()

    if not text:
        return False

    # 테이블 행은 |로 시작하고 끝나야 함
    if not (text.startswith("|") and text.endswith("|")):
        return False

    return True


def highlight_html_table_row(soup, markdown_row):
    """
    마크다운 테이블 행과 HTML 테이블 행을 매칭하는 함수
    하나의 마크다운 행에 대해 매칭되는 HTML 행을 찾아 반환하고 매칭된 행을 하늘색으로 하이라이팅
    """
    # 마크다운 행에서 셀 추출
    markdown_cells = [cell.strip() for cell in markdown_row.strip("|").split("|")]

    # 마크다운 셀에서 서식 제거
    cleaned_cells = []
    for cell in markdown_cells:
        # 취소선 (~~text~~) 처리
        clean_cell = re.sub(r"~~(.*?)~~", r"\1", cell)
        # 볼드 (**text** 또는 __text__) 처리
        clean_cell = re.sub(r"\*\*(.*?)\*\*|__(.*?)__", r"\1\2", clean_cell)
        # 이탤릭 (*text* 또는 _text_) 처리
        clean_cell = re.sub(r"\*(.*?)\*|_(.*?)_", r"\1\2", clean_cell)
        # 공백 정규화
        clean_cell = re.sub(r"\s+", " ", clean_cell.strip())
        cleaned_cells.append(clean_cell)

    matched_rows = []

    # HTML의 모든 테이블 행 검색
    for table in soup.find_all("table"):
        for html_row in table.find_all("tr"):
            html_cells = html_row.find_all(["td", "th"])

            # 셀 수가 다르면 이 행은 건너뛰기
            if len(html_cells) != len(cleaned_cells):
                continue

            row_match = True
            match_quality = 0  # 매칭 품질 점수

            # 각 셀 비교
            for i, markdown_cell in enumerate(cleaned_cells):
                if i >= len(html_cells):
                    row_match = False
                    break

                html_cell_text = html_cells[i].get_text().strip()
                # 공백 정규화
                html_cell_text = re.sub(r"\s+", " ", html_cell_text)

                # 빈 셀은 항상 매치로 처리
                if markdown_cell == "" or html_cell_text == "":
                    continue

                # 정확한 매칭만 허용
                if markdown_cell == html_cell_text:
                    match_quality += 1
                else:
                    row_match = False
                    break

            if row_match:
                # 매칭된 행에 하늘색 하이라이팅 적용
                if "style" in html_row.attrs:
                    html_row["style"] = (
                        html_row["style"] + "; background-color: skyblue;"
                    )
                else:
                    html_row["style"] = "background-color: skyblue;"

                # 완벽하게 매칭된 경우만 결과에 추가 (모든 셀이 매칭된 경우)
                if match_quality == len(cleaned_cells):
                    matched_rows.append(
                        {
                            "match_quality": match_quality,
                            "similarity": 1.0,  # 완벽한 매칭은 항상 1.0
                        }
                    )

    # 매칭 품질이 높은 순으로 정렬
    matched_rows.sort(key=lambda x: x["match_quality"], reverse=True)
    return matched_rows


def create_item_table_html(user_query: str):
    # 아이템 리스트를 입력받아서 새로운 html 테이블을 생성합니다.

    item_prompt = f"""
            유저 쿼리에서 item no, description, quantity를 추출하여 아래와 같은 리스트 형태를 반환.
        없는 항목은 빈 문자열로 처리 예:("item_no": "A1234", "description": "", "quantity": ""). 유저 쿼리에 해당 항목이 없다면 빈 문자열 반환.
        
        유저 쿼리:
        {user_query}
        
        **반드시 dictionary를 포함하는 리스트 형식만 반환하고, 다른 설명이나 텍스트는 포함하지 마세요. quantity는 반드시 숫자로 반환.**
        반환 예시:
        [
            {{"item_no": "A001", "description": "Item 1", "quantity": 5}},
            {{"item_no": "A002", "description": "Item 2", "quantity": 3}},
            {{"item_no": "A003", "description": "Item 3", "quantity": 7}}
        ]

        **위 형식이 아닌 답변은 절대로 하지 마세요. 코드 블록이나 plaintext 등 다른 형식으로 감싸지 마세요.**
    
    """

    item_list_response = llm.invoke(item_prompt)
    item_list_json = item_list_response.content.strip()
    print(item_list_json)
    
    try:
        item_list = json.loads(item_list_json)
    except json.JSONDecodeError as e:
        print(f"JSON 디코딩 오류: {e}")
        print(f"응답 내용: {item_list_json}")
        # 기본값으로 빈 리스트 반환
        item_list = []

    # 테이블 템플릿
    item_table_html = """
    <tr style="height: 14.65pt">
        <td
        style="
            width: 18.9pt;
            border-right-style: solid;
            border-right-width: 0.75pt;
            padding-right: 4.58pt;
            padding-left: 4.95pt;
            vertical-align: top;
            -aw-border-right: 0.5pt single;
        "
        >
        
        
        <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
            <span style="font-family: Arial">{index}</span>
        </p>
        </td>
        <td
        style="
            width: 79.4pt;
            border-top-style: solid;
            border-top-width: 0.75pt;
            border-right-style: solid;
            border-right-width: 0.75pt;
            border-left-style: solid;
            border-left-width: 0.75pt;
            padding-right: 4.58pt;
            padding-left: 4.58pt;
            vertical-align: middle;
            -aw-border-left: 0.5pt single;
            -aw-border-right: 0.5pt single;
            -aw-border-top: 0.5pt single;
        "
        >
        

        <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
            <span style="font-family: Arial">{item_no}</span>
        </p>
        </td>
        <td
        style="
            width: 249.3pt;
            border-style: solid;
            border-width: 0.75pt;
            padding-right: 4.58pt;
            padding-left: 4.58pt;
            vertical-align: top;
            -aw-border: 0.5pt single;
        "
        >
        <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
            <span style="font-family: Arial"
            >{description}</span
            >
        </p>
        </td>
        <td
        style="
            width: 54.95pt;
            border-top-style: solid;
            border-top-width: 0.75pt;
            border-left-style: solid;
            border-left-width: 0.75pt;
            border-bottom-style: solid;
            border-bottom-width: 0.75pt;
            padding-right: 4.95pt;
            padding-left: 4.58pt;
            vertical-align: top;
            -aw-border-bottom: 0.5pt single;
            -aw-border-left: 0.5pt single;
            -aw-border-top: 0.5pt single;
        "
        >
        <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
            <span style="font-family: Arial">{quantity} Set</span>
        </p>
        </td>
    </tr>
    """

    table_header_html = """
    <table
  cellspacing="0"
  cellpadding="0"
  style="
    margin-left: 25pt;
    margin-bottom: 0pt;
    -aw-border-insidev: 0.5pt single #000000;
    border-collapse: collapse;
  "
>
  <tr style="height: 7.3pt">
    <td
      style="
        width: 18.9pt;
        border-top-style: solid;
        border-top-width: 1.5pt;
        border-right-style: solid;
        border-right-width: 0.75pt;
        border-bottom-style: solid;
        border-bottom-width: 0.75pt;
        padding-right: 4.58pt;
        padding-left: 4.95pt;
        vertical-align: top;
        -aw-border-bottom: 0.5pt single;
        -aw-border-right: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">NO.</span>
      </p>
    </td>
    <td
      style="
        width: 79.4pt;
        border-style: solid;
        border-width: 1.5pt 0.75pt 0.75pt;
        padding-right: 4.58pt;
        padding-left: 4.58pt;
        vertical-align: top;
        -aw-border-bottom: 0.5pt single;
        -aw-border-left: 0.5pt single;
        -aw-border-right: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">ITEM NO.</span>
      </p>
    </td>
    <td
      style="
        width: 249.3pt;
        border-style: solid;
        border-width: 1.5pt 0.75pt 0.75pt;
        padding-right: 4.58pt;
        padding-left: 4.58pt;
        vertical-align: top;
        -aw-border-bottom: 0.5pt single;
        -aw-border-left: 0.5pt single;
        -aw-border-right: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">DESCRIPTION</span>
      </p>
    </td>
    <td
      style="
        width: 54.95pt;
        border-top-style: solid;
        border-top-width: 1.5pt;
        border-left-style: solid;
        border-left-width: 0.75pt;
        border-bottom-style: solid;
        border-bottom-width: 0.75pt;
        padding-right: 4.95pt;
        padding-left: 4.58pt;
        vertical-align: top;
        -aw-border-bottom: 0.5pt single;
        -aw-border-left: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">QUANTITY</span>
      </p>
    </td>
  </tr>"""

    table_footer_html = """
      <tr style="height: 8.15pt">
    <td
      style="
        width: 18.9pt;
        border-right-style: solid;
        border-right-width: 0.75pt;
        padding-right: 4.58pt;
        padding-left: 4.95pt;
        vertical-align: top;
        -aw-border-right: 0.5pt single;
      "
    >
      
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">&nbsp;</span>
      </p>
    </td>
    <td
      style="
        width: 79.4pt;
        border-style: solid;
        border-width: 0.75pt;
        padding-right: 4.58pt;
        padding-left: 4.58pt;
        vertical-align: top;
        -aw-border: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">&nbsp;</span>
      </p>
    </td>
    <td
      style="
        width: 249.3pt;
        border-style: solid;
        border-width: 0.75pt;
        padding-right: 4.58pt;
        padding-left: 4.58pt;
        vertical-align: top;
        -aw-border: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">Total</span>
      </p>
    </td>
    <td
      style="
        width: 54.95pt;
        border-top-style: solid;
        border-top-width: 0.75pt;
        border-left-style: solid;
        border-left-width: 0.75pt;
        border-bottom-style: solid;
        border-bottom-width: 0.75pt;
        padding-right: 4.95pt;
        padding-left: 4.58pt;
        vertical-align: top;
        -aw-border-bottom: 0.5pt single;
        -aw-border-left: 0.5pt single;
        -aw-border-top: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; text-align: center; font-size: 10pt">
        <span style="font-family: Arial">{total_quantity} Sets</span>
      </p>
    </td>
  </tr>
  <tr style="height: 7.3pt">
    <td
      colspan="4"
      style="
        width: 432.25pt;
        border-top-style: solid;
        border-top-width: 0.75pt;
        border-bottom-style: solid;
        border-bottom-width: 1.5pt;
        padding-right: 4.95pt;
        padding-left: 4.95pt;
        vertical-align: top;
        -aw-border-top: 0.5pt single;
      "
    >
      <p style="margin-bottom: 0pt; font-size: 10pt">
        <span style="font-family: Arial">[Special Note]</span>
      </p>
      <p style="margin-bottom: 0pt; font-size: 10pt">
        <span style="font-family: Arial">&nbsp; </span>
      </p>
      <p style="margin-bottom: 0pt; font-size: 10pt">
        <span style="font-family: Arial">&nbsp;</span>
      </p>
    </td>
  </tr>
</table>"""

    final_table_html = table_header_html
    item_no = ""
    description = ""
    quantity = ""
    index = 0
    total_quantity = 0

    # 각 아이템에 대해 테이블 행 생성
    for item in item_list:
        index += 1
        item_no = item.get("item_no")
        description = item.get("description")
        quantity = item.get("quantity")
        total_quantity += quantity

        final_table_html += item_table_html.format(
            index=index,
            item_no=item_no,
            description=description,
            quantity=quantity,
        )

    final_table_html += table_footer_html.format(total_quantity=total_quantity)
    return final_table_html


def extract_tables_from_html(html_content: str) -> list[str]:
    """HTML 파일에서 테이블 태그를 추출하여 리스트로 반환."""
    soup = BeautifulSoup(html_content, "html.parser")
    tables = soup.find_all("table")
    return [str(table) for table in tables]


def replace_metadata(metadatas):
    project_no = metadatas.get("project_no", "N/A")
    project_title = metadatas.get("project_title", "N/A")
    location = metadatas.get("location", "")
    client = metadatas.get("client", "")
    date = metadatas.get("date", "")
    description = metadatas.get("description", "")
    prp = metadatas.get("prp", "")
    app = metadatas.get("app", "")
    rew = metadatas.get("rew", "")
    chk = metadatas.get("chk", "")

    cover_html = f"""<html>
  <head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <meta content="text/css" http-equiv="Content-Style-Type" />
    <meta content="Aspose.Words for Python via .NET 25.5.0" name="generator" />
    <title></title>
  </head>
  <body style="font-family: 'Times New Roman'; font-size: 12pt">
    <div>
      <div style="-aw-headerfooter-type: header-primary; clear: both">
        <p style="margin-top: 0pt; margin-bottom: 0pt">
          <span
            style="
              height: 0pt;
              display: block;
              position: absolute;
              z-index: -65537;
            "
          ></span>
        </p>
      </div>
      <p style="margin-top: 0pt; margin-bottom: 0pt"></p>
      <p
        style="
          margin-top: 0pt;
          margin-bottom: 10pt;
          text-align: justify;
          line-height: 150%;
          font-size: 15pt;
        "
      >
        <span style="font-family: Arial; font-weight: bold"> </span>
      </p>
      <p
        style="
          margin-top: 0pt;
          margin-right: 17.95pt;
          margin-bottom: 10pt;
          text-align: center;
          line-height: 115%;
          font-size: 20pt;
          vertical-align: bottom;
        "
      >
        <span
          style="font-family: Arial; font-weight: bold; vertical-align: bottom"
          >Requisition for Quotation</span
        >
      </p>
      <p
        style="
          margin-top: 0pt;
          margin-right: 17.95pt;
          margin-bottom: 10pt;
          text-align: center;
          line-height: 115%;
          font-size: 20pt;
          vertical-align: bottom;
        "
      >
        <span
          style="font-family: Arial; font-weight: bold; vertical-align: bottom"
          >(Technical)</span
        >
      </p>
      <p
        style="
          margin-top: 0pt;
          margin-right: 24pt;
          margin-bottom: 100pt;
          text-align: center;
          line-height: 150%;
          font-size: 20pt;
        "
      ></p>
            <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,sans-serif">&nbsp;</span></p>
      <p
        style="
          margin-top: 0pt;
          margin-bottom: 10pt;
          text-align: center;
          line-height: 115%;
          font-size: 20pt;
        "
      ></p>
      <p
        style="
          margin-top: 0pt;
          margin-left: 40pt;
          margin-bottom: 10pt;
          text-align: justify;
          line-height: 115%;
          font-size: 10pt;
        "
      >
        <span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span
        ><span style="font-family: Arial"> </span>
      </p>
      <p
        style="
          margin-top: 0pt;
          margin-left: 40pt;
          margin-bottom: 10pt;
          text-align: justify;
          line-height: 115%;
        "
      >
        <span style="font-family: Arial"> </span>
      </p>
      <p
        style="
          margin-top: 0pt;
          margin-bottom: 0pt;
          text-align: justify;
          line-height: 115%;
        "
      >
        <span style="font-family: Arial"> </span>
      </p>
      <p
        style="
          margin-top: 0pt;
          margin-bottom: 0pt;
          text-align: justify;
          line-height: 115%;
        "
      >
        <span style="font-family: Arial"> </span>
      </p>
      <table
        cellpadding="0"
        cellspacing="0"
        style="width: 490.3pt; border-collapse: collapse"
      >
        <tr style="height: 21.45pt">
          <td
            style="
              width: 78.3pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >Project No.</span
              >
            </p>
          </td>
          <td
            style="
              width: 412pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >: {project_no}</span
              >
            </p>
          </td>
        </tr>
        <tr style="height: 22pt">
          <td
            style="
              width: 78.3pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >Project Title</span
              >
            </p>
          </td>
          <td
            style="
              width: 412pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >: {project_title}</span
              >
            </p>
          </td>
        </tr>
        <tr style="height: 21.45pt">
          <td
            style="
              width: 78.3pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >Location</span
              >
            </p>
          </td>
          <td
            style="
              width: 412pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >: {location}</span
              >
            </p>
          </td>
        </tr>
        <tr style="height: 21.45pt">
          <td
            style="
              width: 78.3pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >Client</span
              >
            </p>
          </td>
          <td
            style="
              width: 412pt;
              padding-right: 5.65pt;
              padding-left: 5.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: justify;
                font-size: 11pt;
              "
            >
              <span style="font-family: '맑은 고딕'; font-weight: bold"
                >: {client}</span
              >
            </p>
          </td>
        </tr>
      </table>
      <p
        style="
          margin-top: 0pt;
          margin-bottom: 100pt;
          text-align: justify;
          line-height: 115%;
          font-size: 13pt;
        "
      >
            <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,sans-serif">&nbsp;</span></p>
        <span style="font-family: Arial"> </span>
      </p>
      <table
        cellpadding="0"
        cellspacing="0"
        style="
          width: 495.05pt;
          border: 2.25pt double #000000;
          border-collapse: collapse;
        "
      >
        <tr style="height: 20pt; page-break-inside: avoid">
          <td
            style="
              width: 30pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.38pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 68.15pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 177.2pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.65pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 70.85pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.38pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
        </tr>
        <tr style="height: 20pt; page-break-inside: avoid">
          <td
            style="
              width: 30pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.38pt;
              vertical-align: top;
            "
          >
            <h1
              style="
                margin-top: 0pt;
                margin-bottom: 0pt;
                text-align: center;
                page-break-after: avoid;
                line-height: 18pt;
              "
            >
              <span
                style="
                  font-family: Arial;
                  font-size: 10pt;
                  font-weight: normal;
                  color: #ff0000;
                "
                > </span
              >
            </h1>
          </td>
          <td
            style="
              width: 68.15pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 177.2pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: justify;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.65pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 70.85pt;
              border-bottom-style: solid;
              border-bottom-width: 1pt;
              padding-right: 1.38pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
        </tr>
        <tr style="height: 20pt; page-break-inside: avoid">
          <td
            style="
              width: 30pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.38pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 68.15pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: justify;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 177.2pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: justify;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 49.65pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
          <td
            style="
              width: 70.85pt;
              padding-right: 1.38pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial"> </span>
            </p>
          </td>
        </tr>
        <tr style="height: 20pt; page-break-inside: avoid">
          <td
            style="
              width: 30pt;
              border-top-style: solid;
              border-top-width: 1pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: double;
              border-bottom-width: 2.25pt;
              padding-right: 1.4pt;
              padding-left: 1.38pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">0</span>
            </p>
          </td>
          <td
            style="
              width: 68.15pt;
              border-top-style: solid;
              border-top-width: 1pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: double;
              border-bottom-width: 2.25pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">{date}</span>
            </p>
          </td>
          <td
            style="
              width: 177.2pt;
              border-top-style: solid;
              border-top-width: 1pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: double;
              border-bottom-width: 2.25pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 12.5pt;
              "
            >
              <span
                style="line-height: 115%; font-family: Arial; font-size: 10pt"
                >{description}</span
              >
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-top-style: solid;
              border-top-width: 1pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: double;
              border-bottom-width: 2.25pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">{prp}</span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-top-style: solid;
              border-top-width: 1pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: double;
              border-bottom-width: 2.25pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">{chk}</span>
            </p>
          </td>
          <td
            style="
              width: 49.65pt;
              border-top-style: solid;
              border-top-width: 1pt;
              border-right-style: solid;
              border-right-width: 1pt;
              border-bottom-style: double;
              border-bottom-width: 2.25pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">{rew}</span>
            </p>
          </td>
          <td
            style="
              width: 70.85pt;
              border-top-style: solid;
              border-top-width: 1pt;
              border-bottom-style: double;
              border-bottom-width: 2.25pt;
              padding-right: 1.38pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">{app}</span>
            </p>
          </td>
        </tr>
        <tr style="height: 20pt; page-break-inside: avoid">
          <td
            style="
              width: 30pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.38pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">Rev.</span>
            </p>
          </td>
          <td
            style="
              width: 68.15pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">Date</span>
            </p>
          </td>
          <td
            style="
              width: 177.2pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">Description</span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">Prp'd</span>
            </p>
          </td>
          <td
            style="
              width: 49.6pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">Chk'd</span>
            </p>
          </td>
          <td
            style="
              width: 49.65pt;
              border-right-style: solid;
              border-right-width: 1pt;
              padding-right: 1.4pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >
              <span style="font-family: Arial">Rew'd</span>
            </p>
          </td>
          <td
            style="
              width: 70.85pt;
              padding-right: 1.38pt;
              padding-left: 1.65pt;
              vertical-align: top;
            "
          >
            <p
              style="
                margin-top: 0pt;
                margin-bottom: 10pt;
                text-align: center;
                line-height: 115%;
                font-size: 10pt;
              "
            >

              <span style="font-family: Arial">App'd</span>
            </p>
          </td>
        </tr>
      </table>
      <div style="margin-bottom: 500px"></div>
    </div>
  </body>
</html>
"""

    return cover_html

#@comparator_mcp.tool(description="두 개의 HTML 문서를 병합하여 하나의 문서로 구성합니다.")
def merge_htmls(input: mergeHTMLsInput) -> str:
    first_file, second_file = input.highlighted_htmls_path

    current_dir = os.getcwd()
    format_file_path = os.path.join(
        current_dir, "sample/estimate_data/combined_html_format.html"
    )

    with open(format_file_path, "r", encoding="utf-8") as f_template:
        html_template = f_template.read()

    # Read content of the HTML files
    with open(first_file, "r", encoding="utf-8") as f_in_1:
        first_html_content = f_in_1.read()
    with open(second_file, "r", encoding="utf-8") as f_in_2:
        second_html_content = f_in_2.read()

    # Escape HTML content for use in srcdoc attribute
    escaped_first_html = html.escape(first_html_content)
    escaped_second_html = html.escape(second_html_content)

    # Replace iframe src attributes with srcdoc containing the escaped HTML content
    # For iframe1
    html_template = re.sub(
        r'(<iframe[^>]+id="iframe1"[^>]+)src="[^"]*"',
        rf'\1srcdoc="{escaped_first_html}"',
        html_template,
    )
    # For iframe2
    html_template = re.sub(
        r'(<iframe[^>]+id="iframe2"[^>]+)src="[^"]*"',
        rf'\1srcdoc="{escaped_second_html}"',
        html_template,
    )

    output_path = os.path.join(
        current_dir, f"result/merged_diff_{random.randint(1,9999)}.html"
    )
    output_filename = f"merged_diff_{random.randint(1,9999)}.html"

    output_path = save_html(current_dir, output_filename, html_template)

    return output_path
  
@html_mcp.tool(description="아무 string이나 뱉는 무조건 성공하는 mcp")
def test_mcp(input: str) -> str:
  
    return "test"


def remove_cover_page(html_path):
    """
    HTML 파일에서 표지(커버 페이지)를 제거하는 함수
    """
    if not os.path.exists(html_path):
        raise FileNotFoundError(f"파일을 찾을 수 없습니다: {html_path}")

    base_name = os.path.splitext(os.path.basename(html_path))[0]
    output_dir = os.path.dirname(html_path)
    output_path = os.path.join(output_dir, f"{base_name}_no_cover.html")

    try:
        with open(html_path, 'r', encoding='utf-8') as f:
            html_content = f.read()

        page_break_patterns = [
            r'<[^>]*page-break-before\s*:\s*always[^>]*>',
            r'<br[^>]*style="[^"]*page-break-before\s*:\s*always[^"]*"[^>]*>',
            r'<p[^>]*style="[^"]*page-break-before\s*:\s*always[^"]*"[^>]*>',
            r'<div[^>]*style="[^"]*page-break-before\s*:\s*always[^"]*"[^>]*>',
        ]

        page_break_position = -1
        for pattern in page_break_patterns:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                page_break_position = match.start()
                break

        if page_break_position == -1:
            print(f"경고: {html_path}에서 page-break-before를 찾을 수 없습니다. 원본 파일을 그대로 사용합니다.")
            return html_path  # 커버 페이지가 없는 경우 어떻게 처리할지 고민 필요

        content_after_break = html_content[page_break_position:]

        html_start = ""
        head_match = re.search(r'<html[^>]*>.*?<head.*?</head>', html_content, re.DOTALL | re.IGNORECASE)
        if head_match:
            html_start = head_match.group()
            body_start_match = re.search(r'<body[^>]*>', html_content, re.IGNORECASE)
            if body_start_match:
                html_start += "\n" + body_start_match.group()
        else:
            html_start = """<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Document</title>
</head>
<body>"""

        final_html = html_start + "\n" + content_after_break

        if not re.search(r'</body>', final_html, re.IGNORECASE):
            final_html += "\n</body>"
        if not re.search(r'</html>', final_html, re.IGNORECASE):
            final_html += "\n</html>"

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(final_html)

        print(f"커버 페이지 제거 완료: {output_path}")
        return output_path

    except Exception as e:
        print(f"HTML 커버 제거 중 오류: {str(e)}, 원본 파일을 그대로 사용합니다.")
        return html_path


html_app = html_mcp.http_app()
