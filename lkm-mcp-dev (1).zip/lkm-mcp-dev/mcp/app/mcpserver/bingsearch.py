from fastmcp import FastMCP

from pydantic import BaseModel, Field
import os
from dotenv import load_dotenv
import aiohttp

# .env 파일에서 환경변수 불러오기
load_dotenv()

bingsearch_mcp = FastMCP(
    name = "BingSearchServer",
    stateless_http = True
)
class BingSearchInput(BaseModel):
    query: str = Field(..., description="Bing 검색에 사용할 쿼리 문자열")
    count: int = Field(5, description="검색 결과 개수 (기본값 5)")

@bingsearch_mcp.tool(description="Bing Web Search API로 검색")
async def bing_search(input: BingSearchInput):
    query = input.query
    count = input.count
    api_key = os.getenv("BING_SEARCH_KEY")
    if not api_key:
        raise ValueError("BING_API_KEY 환경변수가 설정되어 있지 않습니다.")
    endpoint = "https://api.bing.microsoft.com/v7.0/search"
    params = {
        "q": query,
        "count": count,
        "responseFilter": "webpages"
    }
    headers = {
        "Ocp-Apim-Subscription-Key": api_key
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(endpoint, params=params, headers=headers) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                raise RuntimeError(f"Bing API error: {resp.status}, {error_text}")
            data = await resp.json()
            # 웹페이지 결과만 추출
            results = []
            for item in data.get("webPages", {}).get("value", []):
                results.append({
                    "title": item.get("name"),
                    "url": item.get("url"),
                    "snippet": item.get("snippet")
                })
            return {"results": results}

bingsearch_app = bingsearch_mcp.http_app()