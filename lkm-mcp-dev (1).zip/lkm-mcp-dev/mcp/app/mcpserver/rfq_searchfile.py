from typing import Dict, Optional, List
from fastmcp import FastMCP
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient, SearchItemPaged
from azure.search.documents.models import VectorizableTextQuery, VectorizedQuery
from langchain_openai import AzureOpenAIEmbeddings
from dotenv import load_dotenv
from pydantic import BaseModel, Field

import psycopg2
import os
import json
import zipfile
import uuid
import shutil



from mcpserver.functions.file_handler import FileHandler
from utils.state_loader import StateLoader

load_dotenv()

file_handler = FileHandler()
state_loader = StateLoader()

# 통합된 MCP 서버
rfq_searchfile_mcp = FastMCP(
    name = "RFQ_SearchFileServer",
    stateless_http = True
)
def get_embedding_model() -> AzureOpenAIEmbeddings:
    return AzureOpenAIEmbeddings(
        azure_endpoint=os.getenv("EMBEDDING_ENDPOINT"),
        api_key=os.getenv("EMBEDDING_KEY"),
        azure_deployment=os.getenv("EMBEDDING_DEPLOYMENT"),
    )


class VectorApproach:
    def __init__(
        self,
        search_index: str,
        search_endpoint: str,
        search_key: str,
        embedding_approach,
    ):
        self.search_index = search_index
        self.search_endpoint = search_endpoint
        self.search_key = search_key
        self.embedding_approach = embedding_approach

    @staticmethod
    def _format_results(results: SearchItemPaged[Dict], top: int=10)->List[str]:
        seen_mrnos = set()
        for result in results:
            mrno = result.get("MRNO")
            if mrno is not None and mrno not in seen_mrnos:
                seen_mrnos.add(mrno)
            if len(seen_mrnos) >= top:
                break
        mrnos = list(seen_mrnos)

        conn = psycopg2.connect(
            host=os.getenv("DB_HOST"),
            database=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            port=os.getenv("DB_PORT")
        )
        with conn.cursor() as cursor:
            sql = "SELECT file_path FROM rfq.rfq_info WHERE MRNO IN %s"
            cursor.execute(sql, (tuple(mrnos),))
            results = cursor.fetchall()
        return [result[0] for result in results]

    def get_search_client(self):
        return SearchClient(
            self.search_endpoint, self.search_index, AzureKeyCredential(self.search_key)
        )
    
    def search_vector(
        self,
        query: str = "",
        fields: str = "content_vector",
        top: int = 10,
    ):
        """
        file_id를 사용한 벡터 검색
        """
        search_client = self.get_search_client()

        # 쿼리를 벡터로 변환
        embedding = self.embedding_approach.embed_query(query)

        # 벡터 쿼리 생성
        vector_query = VectorizedQuery(
            vector=embedding, k_nearest_neighbors=top, fields=fields
        )

        select_fields = ["id", "MRNO"]

        # 벡터 검색 실행
        results = search_client.search(
            search_text=None,  # 순수 벡터 검색을 위해 텍스트 검색 비활성화
            # filter=filter_str if filter_str else None,
            vector_queries=[vector_query],
            top=top*4,
            select=select_fields,
        )

        return self._format_results(results, top)
    
    def search_hybrid(
        self,
        query_text: str,
        fields: str,
        top=10):
        search_client = self.get_search_client()
        """키워드와 벡터 검색 가중치 조정"""

        query_vector = VectorizableTextQuery(text=query_text, k_nearest_neighbors=top*4, fields=fields)
    
        # 별도로 키워드 검색
        results = search_client.search(  
            search_text=query_text,  
            vector_queries=[query_vector],
            select=["id", "MRNO"],
            top=top*4
        )
        return self._format_results(results, top)


vector_approach = VectorApproach(
        search_index="lkm_rfq_250730",
        search_endpoint=os.getenv("AZURE_AI_SEARCH_ENDPOINT"),
        search_key=os.getenv("AZURE_AI_SEARCH_KEY"),
        embedding_approach=get_embedding_model()
    )


def decode_filename(filename_bytes):
    """여러 인코딩을 순차적으로 시도"""
    encodings = ['cp949', 'euc-kr', 'utf-8', 'cp437']
    
    for encoding in encodings:
        try:
            return filename_bytes.decode(encoding)
        except UnicodeDecodeError:
            continue
    
    return filename_bytes.decode('utf-8', errors='ignore')


def rfq_searchfile_origin(folder_path: str, keywords: list, doc_types: list, unique_uuid: str) -> list[dict]:
    """
    특정 폴더들 내에서 키워드와 조건을 기반으로 문서를 검색하는 함수

    :param folder_path: 검색할 폴더 경로 (예: '/path/to/MR24010002M', '/path/to/MR24010003M')
    :param keywords: 검색할 키워드들 (파일 이름에 포함되어야 하는 단어들)
    :param doc_types: 문서 형식들 (예: ['docx', 'doc'], ['xlsx', 'xls'], ['pdf'])
    :return: 검색된 파일 정보의 리스트
    """

    result_files = []

    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        print(f"폴더를 찾을 수 없음: {folder_path}")
        return []

    extract_base_path = f'/app/shared_data/{unique_uuid}'
    os.makedirs(extract_base_path, exist_ok=True)

    # 폴더 내 모든 파일 탐색 (하위 폴더 포함)
    for root, _, files in os.walk(folder_path):
        for file_name in files:
            file_path = os.path.join(root, file_name)
            # ZIP 파일 처리
            if file_name.lower().endswith(".zip"):
                try:
                    with zipfile.ZipFile(file_path, "r") as zip_ref:
                        for zip_info in zip_ref.infolist():
                            filename_bytes = zip_info.filename.encode('cp437')
                            zip_file_path = decode_filename(filename_bytes)

                            if zip_file_path.endswith("/"):
                                continue

                            file_name_in_zip = os.path.basename(zip_file_path)

                            if not file_name_in_zip:
                                continue

                            # 문서 타입 필터링
                            if doc_types:
                                has_valid_extension = any(
                                    file_name_in_zip.lower().endswith(f".{doc_type.lower()}")
                                    for doc_type in doc_types
                                )
                                if not has_valid_extension:
                                    continue

                            # 키워드 필터링
                            if keywords and not any(
                                keyword.lower() in file_name_in_zip.lower()
                                for keyword in keywords
                            ):
                                continue
                            
                            # zip 파일 추출 후 base 폴더로 이동
                            try:
                                extracted_file_path = zip_ref.extract(zip_file_path, path=extract_base_path)
                                result_files.append(extracted_file_path)
                                print(f"ZIP에서 추출 완료: {extracted_file_path}")
                            
                            except Exception as extract_error:
                                print(f"ZIP에서 파일 추출 실패 {zip_file_path}: {str(extract_error)}")

                except Exception as e:
                    print(f"ZIP 파일 {file_path} 처리 중 오류 발생: {str(e)}")

            # 일반 파일 처리
            else:
                # 문서 타입 필터링
                if doc_types:
                    has_valid_extension = any(
                        file_name.lower().endswith(f".{doc_type.lower()}")
                        for doc_type in doc_types
                    )
                    if not has_valid_extension:
                        continue

                # 키워드 필터링
                if keywords and not any(
                    keyword.lower() in file_name.lower()
                    for keyword in keywords
                ):
                    continue

                result_files.append(file_path)

    # 결과 1개로 맞춤 (확장자 우선순위 적용)
    if len(result_files) > 1:
        print(f"결과 개수: {len(result_files)}")
        print(f"결과: {result_files}")
        if doc_types == ['doc', 'docx']:
            for file in result_files:
                if file.endswith('.docx'):
                    result_files = [file]
                    break
        else:
            for file in result_files:
                if file.endswith('.xlsx'):
                    result_files = [file]
                    break

        result_files = [result_files[0]]
    
    # base 폴더로 복사
    if result_files and not result_files[0].startswith('/app/shared_data'):
        source_file = result_files[0]
        file_name = os.path.basename(source_file)
        destination_file = os.path.join(extract_base_path, file_name)
        
        try:
            shutil.copy2(source_file, destination_file)
            result_files[0] = destination_file
            print(f"파일 복사 완료: {source_file} -> {destination_file}")
        except Exception as copy_error:
            print(f"파일 복사 실패 {source_file}: {str(copy_error)}")
            
    return result_files


# Pydantic 모델들
class RFQ_SearchInput(BaseModel):
    query: str = Field(description="검색 쿼리")

class RFQ_SearchOutput(BaseModel):
    folder_results: List[dict] = Field(description="최종 결과: [RFQ파일, TBE파일] 쌍들의 리스트")


# 통합된 MCP 도구
@rfq_searchfile_mcp.tool(description="벡터 검색 후 RFQ/TBE 파일 검색하는 통합 도구")
# def rfq_searchfile(input: RFQ_SearchInput) -> RFQ_SearchOutput:
def rfq_searchfile(input: RFQ_SearchInput) -> dict:
    """
    쿼리로 벡터 검색을 수행한 후, 결과 폴더들에서 RFQ/TBE 파일을 검색합니다.
    
    파이프라인:
    1. query로 벡터 검색 실행
    2. 검색 결과 file_paths 획득 (중간 결과)
    3. file_paths를 폴더 경로로 사용해서 RFQ/TBE 파일 검색
    4. 최종 folder_results 반환
    
    Args:
        input: 검색 쿼리
        
    Returns:
        최종 RFQ/TBE 파일 검색 결과(folder_results)
    """
    
    # 1단계: 벡터 검색
    print(f"벡터 검색 쿼리: {input.query}")
    file_paths = vector_approach.search_vector(input.query, top=20)
    print(f"벡터 검색 결과 파일 경로 수: {len(file_paths)}")
    
    # 2단계: 파일 경로들을 폴더 경로로 사용해서 RFQ/TBE 파일 검색
    final_results = []
    unique_uuid = str(uuid.uuid4())
    
    for folder_path in file_paths:
        print(f"\n폴더 검색: {folder_path}")
        
        rfq_result = rfq_searchfile_origin(folder_path=folder_path, keywords=['rfq'], doc_types=['doc', 'docx'], unique_uuid=unique_uuid)
        tbe_result = rfq_searchfile_origin(folder_path=folder_path, keywords=['tcs', 'tbe'], doc_types=['xlsx', 'xls'], unique_uuid=unique_uuid)
        
        if len(rfq_result) > 0 and len(tbe_result) > 0:
            combined_result = [rfq_result[0], tbe_result[0]]
            final_results.append(combined_result)
            print(f"RFQ: {rfq_result[0]}")
            print(f"TBE: {tbe_result[0]}")
    
    print(f"\n최종 결과")
    print(f"조건을 만족하는 폴더 수: {len(final_results)}")
    
    if not final_results:
        print("조건을 만족하는 폴더가 없습니다.")
    
    return RFQ_SearchOutput(folder_results=final_results)


rfq_searchfile_app = rfq_searchfile_mcp.http_app()