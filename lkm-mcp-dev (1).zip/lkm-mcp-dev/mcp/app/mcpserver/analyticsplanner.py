from fastmcp import FastMCP


from pydantic import BaseModel, Field

import os
import json
from langchain_openai import AzureChatOpenAI

analyticsplanner_mcp = FastMCP(
    name = "AnalyticsPlannerServer",
    stateless_http = True
)

def create_llm():
    """Azure OpenAI LLM 인스턴스 생성"""
    return AzureChatOpenAI(
        azure_deployment=os.getenv("OPENAI_DEPLOYMENT"),
        azure_endpoint=os.getenv("OPENAI_ENDPOINT"),
        api_version=os.getenv("OPENAI_API_VERSION"),
        api_key=os.getenv("OPENAI_API_KEY"),
        n=1,
        temperature=0,
        max_tokens=10000,
        model=os.getenv("OPENAI_MODEL"),
        verbose=True,
        streaming=False,
    )

class AnalyticsPlannerInput(BaseModel):
    user_query: str = Field(..., description="사용자 쿼리")
    analysis_factors: list[str] = Field(..., description="분석 대상 요소들")
    factors_description: dict[str, str] = Field(..., description="분석 대상 요소들의 설명")

@analyticsplanner_mcp.tool(description="""분석 요소들과 요소별 설명을 고려하여 사용자 쿼리에 적절한 데이터 분석 계획 생성""")
def analytics_planner(input: AnalyticsPlannerInput):
    """분석 요소들과 요소별 설명을 고려하여 사용자 쿼리에 적절한 데이터 분석 계획 생성"""
    llm = create_llm()

    system_prompt = f"""
    당신은 데이터 분석 전문가입니다. 사용자의 쿼리에 대해 체계적이고 실용적인 데이터 분석 계획을 수립해주세요.
    
    가설을 단 3개 이상 도출하고, 각 가설별로 모든 항목을 빠짐없이 작성해주세요.

    다음은 분석 대상 요소들과 요소들에 대한 설명입니다. 반드시 고려하세요:
    분석 요소: {input.analysis_factors}
    요소별 설명: {input.factors_description}

    [중요한 데이터 전처리 원칙]
    - 특정 월이나 기간에 대한 분석 요청이 있어도, 비교 분석을 위해 전체 기간의 데이터를 월별/기간별로 그룹화하여 패턴을 파악해야 합니다.
    - 단순히 특정 기간만 필터링하는 것이 아니라, 전체 기간을 기준으로 비교 분석이 가능하도록 전처리 방법을 작성해주세요.
    - 예: "9월 불량품 발생 원인" → 9월만 분석하는 것이 아니라, 전체 기간을 월별로 그룹화하여 9월의 특이점을 찾아야 합니다.

    [데이터 전처리 방법 작성 시 주의사항]
    - 특정 기간 분석 요청이 있어도 전체 기간을 월별/기간별로 그룹화하여 비교 분석 가능하도록 작성
    - 단순 필터링이 아닌 그룹화와 집계를 통한 패턴 분석 방법 제시
    - 예시: "날짜 데이터를 월별로 그룹화하고, 각 월별 통계 계산" (O) / "9월 데이터만 필터링" (X)

    1. 첫 번째 가설 제목
        - 가설 제목
        - 시각화할 1개의 그래프 정의
        - 데이터 전처리 방법

    2. 두 번째 가설
        - 가설 제목
        - 시각화할 1개의 그래프 정의
        - 데이터 전처리 방법

    3. 세 번째 가설
        - 가설 제목
        - 시각화할 1개의 그래프 정의
        - 데이터 전처리 방법
    """

    user_prompt = f"""
    사용자 쿼리: {input.user_query}

    위 쿼리에 대해 분석 계획을 정확히 위의 구조에 맞게 작성해주세요.
    
    가설을 3개 이상 도출하고, 각 가설별로 모든 항목을 빠짐없이 작성해주세요.
    """


    prompt = f"{system_prompt}\n\n{user_prompt}"
    try: 
        response = llm.invoke(prompt)
        response_text = response.content.strip()
        
        print(f"\nanalysis_factors\n{input.analysis_factors}")
        print(f"\nanalysis_factors_metadata 5개\n{dict(list(input.factors_description.items())[:5])}")
        print(f"\n분석계획\n{response_text}")
        return response_text

    except Exception as e:
        return f"Error: {str(e)}"
analyticsplanner_app = analyticsplanner_mcp.http_app()