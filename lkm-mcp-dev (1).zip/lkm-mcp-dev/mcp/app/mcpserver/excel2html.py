from fastmcp import FastMCP
from pydantic import BaseModel, Field
import os
import requests
from dotenv import load_dotenv
from bs4 import BeautifulSoup
import re
import logging
from pathlib import Path
from client.document_client import DocumentClient

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# .env 파일 로드
load_dotenv()

# MCP 서버 생성
excel2html_mcp = FastMCP(
    name = "Excel2HtmlServer",
    stateless_http = True
)

# 입력 모델 정의
class Excel2HtmlInput(BaseModel):
    excel_file_path: str = Field(..., description="변환할 엑셀 파일 경로")

class Excel2HtmlSimpleInput(BaseModel):
    excel_file_path: str = Field(..., description="변환할 엑셀 파일 경로")

# 환경 변수 검증
def validate_env_vars():
    """필요한 환경 변수가 설정되어 있는지 검증합니다."""
    client_id = os.getenv('ASPOSE_CLOUD_CLIENT_ID')
    client_secret = os.getenv('ASPOSE_CLOUD_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        raise ValueError("ASPOSE_CLOUD_CLIENT_ID와 ASPOSE_CLOUD_CLIENT_SECRET 환경 변수를 설정해주세요.")
    return client_id, client_secret

# 초기 환경 변수 검증
CLIENT_ID, CLIENT_SECRET = validate_env_vars()

# 유틸리티 함수들
def get_access_token():
    """Aspose.Cloud API 액세스 토큰을 가져옵니다."""
    token_url = "https://api.aspose.cloud/connect/token"
    data = {
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET
    }
    
    response = requests.post(token_url, data=data, verify=False)
    if response.status_code == 200:
        return response.json()["access_token"]
    else:
        raise Exception(f"토큰 발급 실패: {response.text}")

def create_html_document(head_content, body_content, styles_content):
    """HTML 문서를 생성하는 공통 함수"""
    return f"""<!DOCTYPE html>
<html>
{head_content}
<body>
{body_content}
{styles_content}
</body>
</html>"""

def extract_common_elements(soup):
    """공통으로 사용될 head와 styles를 추출합니다."""
    head = soup.find('head')
    if head:
        # JavaScript 함수 제거 (시트 전환 관련)
        for script in head.find_all('script'):
            script.decompose()
        head_content = str(head)
    else:
        head_content = "<head></head>"
    
    styles = soup.find_all('style')
    styles_content = '\n'.join(str(style) for style in styles) if styles else ""
    
    return head_content, styles_content

def get_sheet_name(sheet_div):
    """시트 이름을 추출합니다."""
    for attr_name, attr_value in sheet_div.attrs.items():
        if attr_name.lower() == 'sheetname':
            return attr_value
    
    table_id = sheet_div.get('id', '')
    return f"sheet_{table_id}" if table_id else "unknown"

def process_sheet(sheet_div, common_head, common_styles, output_dir):
    """개별 시트를 처리하여 HTML 파일로 저장합니다."""
    sheet_name = get_sheet_name(sheet_div)
    table = sheet_div.find('table')
    
    if not table:
        return None
    
    safe_sheet_name = re.sub(r'[<>:"/\\|?*]', '_', sheet_name)
    output_file = os.path.join(output_dir, f"{safe_sheet_name}.html")
    
    html_content = create_html_document(common_head, str(table), common_styles)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    return output_file

def split_html_sheets(html_content, output_dir):
    """HTML 내용을 시트별로 분리합니다."""
    os.makedirs(output_dir, exist_ok=True)
    
    soup = BeautifulSoup(html_content, 'html.parser')
    common_head, common_styles = extract_common_elements(soup)
    
    section_div = soup.find('div', id='section')
    if not section_div:
        raise ValueError("시트를 찾을 수 없습니다.")
    
    created_files = []
    for sheet_div in section_div.find_all('div', id=re.compile(r'table_\d+')):
        output_file = process_sheet(sheet_div, common_head, common_styles, output_dir)
        if output_file:
            created_files.append(output_file)
    
    return created_files

# Tool 함수들

#@excel2html_mcp.tool(description="""엑셀 파일을 HTML로 변환하고 필요한 경우 시트별로 분리합니다.""")
async def excel_to_html(input: Excel2HtmlInput):
    """
    엑셀 파일을 HTML로 변환하고 필요한 경우 시트별로 분리합니다.
    """
    try:
        document_client = DocumentClient()
        output_path = await document_client.convert_to_html(input.excel_file_path)
        
        # HTML 내용 파싱
        html_content = Path(output_path).read_text(encoding='utf-8')
        soup = BeautifulSoup(html_content, 'html.parser')
        common_head, common_styles = extract_common_elements(soup)
        
        # 시트 구조 확인
        section_div = soup.find('div', id='section')
        
        if section_div:
            # 다중 시트 구조인 경우
            sheet_divs = section_div.find_all('div', id=re.compile(r'table_\d+'))
            sheet_count = len(sheet_divs)
            
            if sheet_count > 1:
                created_files = split_html_sheets(convert_response.content, output_dir)
                result = {
                    "status": "success",
                    "message": f"엑셀 파일이 {sheet_count}개의 시트로 분리되어 HTML로 변환되었습니다.",
                    "files": created_files
                }
            else:
                # 단일 시트지만 다중 시트 구조인 경우
                output_file = os.path.join(output_dir, f"{os.path.splitext(file_name)[0]}.html")
                with open(output_file, 'wb') as f:
                    f.write(convert_response.content)
                result = {
                    "status": "success",
                    "message": "엑셀 파일이 HTML로 변환되었습니다.",
                    "files": [output_file]
                }
        else:
            # 단일 시트 구조인 경우
            table = soup.find('table')
            if not table:
                raise ValueError("테이블을 찾을 수 없습니다.")
            
            output_file = os.path.join(output_dir, f"{os.path.splitext(file_name)[0]}.html")
            html_content = create_html_document(common_head, str(table), common_styles)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
            result = {
                "status": "success",
                "message": "엑셀 파일이 HTML로 변환되었습니다.",
                "files": [output_file]
            }
        
        # 3. 업로드된 파일 삭제
        delete_url = f"{base_url}/cells/storage/file/{file_name}"
        delete_response = requests.delete(delete_url, headers=headers, verify=False)
        if delete_response.status_code != 200:
            logger.warning(f"파일 삭제 실패: {delete_response.text}")
        
        return result
        
    except Exception as e:
        logger.error(f"변환 중 오류 발생: {str(e)}")
        return {
            "status": "error",
            "message": f"변환 중 오류가 발생했습니다: {str(e)}"
        }

@excel2html_mcp.tool(
    description="""
엑셀 파일을 단일 HTML 파일로 변환합니다. 시트 분리 없이 하나의 파일로 출력됩니다.
"""
)
async def excel_to_html_simple(input: Excel2HtmlSimpleInput):
    """
    엑셀 파일을 단일 HTML 파일로 변환합니다. 시트 분리 없이 하나의 파일로 출력됩니다.
    """
    document_client = DocumentClient()
    output_path = await document_client.convert_to_html(input.excel_file_path)
    return output_path
    
    # try:
    #     access_token = get_access_token()
    #     base_url = "https://api.aspose.cloud/v3.0"
    #     file_name = os.path.basename(input.excel_file_path)
    #     headers = {"Authorization": f"Bearer {access_token}"}
        
    #     # 1. 파일 업로드
    #     upload_url = f"{base_url}/cells/storage/file/{file_name}"
    #     with open(input.excel_file_path, 'rb') as f:
    #         upload_response = requests.put(upload_url, headers=headers, data=f, verify=False)
    #         if upload_response.status_code != 200:
    #             raise Exception(f"파일 업로드 실패: {upload_response.text}")
        
    #     # 2. HTML로 변환
    #     convert_url = f"{base_url}/cells/{file_name}?format=html"
    #     convert_response = requests.get(convert_url, headers=headers, verify=False)
        
    #     if convert_response.status_code != 200:
    #         raise Exception(f"변환 실패: {convert_response.text}")
        
    #     # 출력 디렉토리 설정
    #     output_dir = os.path.splitext(input.excel_file_path)[0] + '_html'
    #     os.makedirs(output_dir, exist_ok=True)
        
    #     # HTML 파일 저장
    #     output_file = os.path.join(output_dir, f"{os.path.splitext(file_name)[0]}.html")
    #     with open(output_file, 'wb') as f:
    #         f.write(convert_response.content)
        
    #     # 3. 업로드된 파일 삭제
    #     delete_url = f"{base_url}/cells/storage/file/{file_name}"
    #     delete_response = requests.delete(delete_url, headers=headers, verify=False)
    #     if delete_response.status_code != 200:
    #         logger.warning(f"파일 삭제 실패: {delete_response.text}")
        
    #     return output_file
        
    # except Exception as e:
    #     logger.error(f"변환 중 오류 발생: {str(e)}")
    #     return {
    #         "status": "error",
    #         "message": f"변환 중 오류가 발생했습니다: {str(e)}"
    #     }

def get_general_sheet(input: str) -> str:
    """
    HTML 구조에서 id="section" 내부의 id="table_0"인 부분만 남기고 나머지 table들을 제거합니다.
    동일한 파일에 덮어씁니다.
    
    Args:
        input: HTML 파일 경로
    
    Returns:
        수정된 HTML 파일 경로
    """
    try:
        # HTML 파일 읽기
        with open(input, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # id="section"인 div 찾기
        section_div = soup.find('div', id='section')
        if not section_div:
            logger.warning("id='section'인 div를 찾을 수 없습니다.")
            return input
        
        # section 내의 모든 div 찾기
        all_divs = section_div.find_all('div', recursive=False)
        
        # table_0이 아닌 모든 div 제거
        for div in all_divs:
            div_id = div.get('id', '')
            if div_id != 'table_0':
                div.decompose()
        
        # 동일한 파일에 덮어쓰기
        with open(input, 'w', encoding='utf-8') as f:
            f.write(str(soup))
        
        return input
        
    except Exception as e:
        logger.error(f"HTML 처리 중 오류 발생: {str(e)}")
        return input
    

# HTTP 앱 생성
excel2html_app = excel2html_mcp.http_app() 
