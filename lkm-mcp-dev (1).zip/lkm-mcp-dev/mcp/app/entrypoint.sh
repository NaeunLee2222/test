mkdir -p /app/shared_data/lkm_mcp

echo "RFQ data 복사 중 ..."
if [ -d "/app/test/temp/rfq" ]; then
    ls -al /app/test/temp/rfq/
    mkdir -p /app/shared_data/lkm_mcp/rfq
    ls -al /app/shared_data/lkm_mcp/
    cp -r /app/test/temp/rfq/* /app/shared_data/lkm_mcp/rfq/
    ls -al /app/shared_data/lkm_mcp/rfq/
    echo "✓ RFQ 데이터 복사 완료"
else
    echo "⚠ RFQ 디렉토리를 찾을 수 없습니다: /app/test/temp/rfq"
fi

echo "TBE data 복사 중 ..."
if [ -d "/app/test/temp/tbe" ]; then
    mkdir -p /app/shared_data/lkm_mcp/tbe
    cp -r /app/test/temp/tbe/* /app/shared_data/lkm_mcp/tbe/.
    echo "✓ TBE 데이터 복사 완료"
else
    echo "⚠ TBE 디렉토리를 찾을 수 없습니다: /app/test/temp/tbe"
fi

echo "비상대응훈련시나리오 문서 복사 중 ..."
if [ -d "/app/test/demo" ]; then
    cp -r /app/test/demo/* /app/shared_data/lkm_mcp
    echo "✓ 비상대응훈련시나리오 문서 복사 완료"
else
    echo ":경고: demo 디렉토리를 찾을 수 없습니다: /app/test/demo"
fi


# 추가적인 복사 작업들 예시
echo "추가 데이터 복사 중..."


echo "권한 설정 중..."
chmod -R 755 /app/shared_data
chown -R $(whoami):$(whoami) /app/shared_data 2>/dev/null || true

echo "=== 초기화 완료 ==="
echo "=== MCP Mount Server 시작 ==="
exec 1>&2 

# 메인 애플리케이션 실행
# exec python mcp_mount_server.py