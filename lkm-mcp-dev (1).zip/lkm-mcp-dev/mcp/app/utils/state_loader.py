import json
from typing import Any, Type
from pydantic import BaseModel
from utils.llm import LLMSingleton
from mcpserver.functions.file_handler import FileHandler
from langchain_core.messages import SystemMessage, HumanMessage

llm = LLMSingleton.get_llm()

class StateLoader:
    """
    StateLoader 클래스는 대화 상태를 관리하고 LLM을 사용하여 구조화된 출력을 생성하는 클래스입니다.
    
    이 클래스는 LLMSingleton을 사용하여 LLM 인스턴스를 관리하며,
    Pydantic 모델을 사용하여 구조화된 출력을 생성합니다.
    """
    
    def __init__(self):
        """
        StateLoader 인스턴스를 초기화합니다.
        """
        self.llm = LLMSingleton.get_llm()
    
    @staticmethod
    def _get_model_params(StrOutput: Type[BaseModel]) -> str:
        """
        Pydantic 모델의 필드 정보를 문자열 형태로 변환합니다.
        
        Args:
            StrOutput (Type[BaseModel]): 필드 정보를 추출할 Pydantic 모델 클래스
            
        Returns:
            str: 모델의 각 필드명과 설명을 포함한 문자열
                형식: "field_name : field_description"
        """
        return "\n".join(
            [f'{field_name} : {field_info.description or ""}'
            for field_name, field_info in StrOutput.model_fields.items()]
        )

    def invoke_state(self, StrOutput: Type[BaseModel], file_path: str):
        """
        주어진 채팅 ID의 상태 정보를 기반으로 LLM을 호출하여 구조화된 출력을 생성합니다.
        
        Args:
            StrOutput (Type[BaseModel]): 출력할 구조화된 데이터의 Pydantic 모델 클래스
            chat_id (str): 대화 상태를 로드할 채팅 ID
            
        Returns:
            BaseModel: LLM이 생성한 구조화된 출력
            
        Note:
            - memory/{chat_id}.json 파일에서 이전 대화 상태를 로드합니다.
            - LLM에게 현재 상태와 요청할 출력 형식을 전달합니다.
            - 한국어로 친절한 비서 역할을 수행하도록 설정되어 있습니다.
        """
        
        # 모델의 필드명만 가져오기
        StrOutput_fields = list(StrOutput.model_fields.keys())

        # memory 파일 로드 (파일이 없으면 기본값 사용)
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                memory = json.load(f)
        except Exception as e:
            # 파일이 없으면 기본 메모리 데이터 생성
            raise e

        tool_calling_history :list = memory["tool_calling_history"]
        tool_calling_history_str = "\n".join(
            [f"{i+1} : {history}" for i, history in enumerate(tool_calling_history)]
        )
        user_query = tool_calling_history["user_query"]
        actions = tool_calling_history["plan"]["action_plan"]
        actions_str = "\n".join(
            [f"{i+1} : {action}" for i, action in enumerate(actions)]
        )
        current_action_order = tool_calling_history["plan"]["action_order"]

        
        human_message = f"""내가 너에게 했던 질문은 다음과 같아.
        user_query : {user_query}
        너가 계획한 내용은 다음과 같은 순서로 구성되어있어.
        {actions_str}
        이 중 현재 진행중인 작업은 {actions[current_action_order]} 이야.
        현재까지 작업을 진행하면서 나온 결과는 순서대로 다음과 같아.
        {tool_calling_history_str}
        이 내용을 바탕으로 현재 진행중인 작업에서 필요한 내용을 작성해줘.
        작성해야할 내용 : {StrOutput_fields}
        출력 포맷은 다음과 같습니다.
        {self._get_model_params(StrOutput)}
        """
        messages = [
            SystemMessage(content="너는 특수 에이전트야. 현재 진행상황을 바탕으로 주어진 포맷에 맞춰서 출력을 생성해야해."),
            HumanMessage(content=human_message)
        ]
        
        # structured output을 위한 LLM 설정
        structured_llm = self.llm.with_structured_output(StrOutput)
        response = structured_llm.invoke(messages)
        return response