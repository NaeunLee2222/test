# LKM backend

[![python3.10](https://img.shields.io/badge/python-v3.10-blue.svg)]()
[![springboot3.1.2](https://img.shields.io/badge/springboot-v3.1.2-green.svg)]()
[![Node v20.12.2](https://img.shields.io/badge/node-v20.12.2-yellow.svg)]()

---
This project is initially based on the `ai-core` repository.  

### Run Service

- local

  - 권장 실행 환경: VS Code
  - VS Code launch.json 활용해서 실행
  - deploy/scripts/ai-chat-init-data.sql 을 활용해서 더미 데이터 삽입
  - 세부사항 노션 참고

- docker

  ```bash
  # Build Images
  docker build -t skccaichatbot.azurecr.io/{svc-name}:{tag-name} app/{directory_name}/.

  # Run Containers
  vi .env
  set -a; source .env; set +a
  envsubst < docker-compose.yml > docker-compose.yml
  docker compose -f docker-compose.yml up -d
  ```

- k8s

### 디렉터리 구조

```sh
/
├── apps                    # 어플리케이션
│   └── llm-hub             # LLM service 개발을 위한 tool, utility가 정리된 service
└── data                    # data하위 모든 파일은 gitignore
```

### Branch Naming and Rule

자유롭게 Branch를 생성하고 관리
Branch 생성시 아래 prefix 적용

```sh
docs: 문서 수정
feature: 새로운 기능 추가
fix: 버그 수정
design: CSS 등 사용자 UI 디자인 변경
style: 코드 포맷팅, 세미콜론 누락, 코드 변경이 없는 경우
refactor : 코드 리펙토링
test : 테스트 코드, 리펙토링 테스트 코드 추가
chore : 빌드 업무 수정, 패키지 매니저 수정
rename: 파일 혹은 폴더명을 수정하거나 옮기는 작업만인 경우
remove: 파일을 삭제하는 작업만 한 경우
hotfix: release 버전에서 급하게 치명적인 버그를 고쳐야하는 경우
```

각 Branch에서 Commit & Push 후 항상 Pull Requests를 생성하여 main Branch에 병합

.
