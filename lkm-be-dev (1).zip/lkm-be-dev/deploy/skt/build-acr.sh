#!/bin/bash

set -e

if [ "$#" -ne 1 ] || { [ "$1" != "dev" ] && [ "$1" != "prd" ]; }; then
  echo "Usage: $0 [dev|prd]"
  exit 1
fi

ENV=$1

if [ "$ENV" == "prd" ]; then
  ENV_FILE=".env-deploy-prd"
  IMAGE_SUFFIX="-prd"
elif [ "$ENV" == "dev" ]; then
  ENV_FILE=".env-deploy-dev"
  IMAGE_SUFFIX="-dev"
fi

if [ ! -f $ENV_FILE ]; then
  echo "$ENV_FILE 파일을 찾을 수 없습니다."
  exit 1
fi

export $(grep -v '^#' $ENV_FILE | xargs)

generate_version() {
  BRANCH=$(git rev-parse --abbrev-ref HEAD)
  TAG=$(git describe --exact-match --tags $(git rev-parse HEAD) 2>/dev/null || true)
  COMMIT_HASH=$(git rev-parse --short HEAD)
  DATE=$(date '+%Y%m%d-%H%M')
  
  case $BRANCH in
    "feature/"* | "chore/"* | "hotfix/"*)
      VERSION="eph-${COMMIT_HASH}"
      ;;
    "develop")
      if [ -n "$TAG" ]; then
        VERSION="${TAG}-dev"
      else
        VERSION="dev-${COMMIT_HASH}"
      fi
      ;;
    "release/"*)
      if [ -n "$TAG" ]; then
        VERSION="${TAG}-rc"
      else
        echo "Error: release 브랜치는 태그가 필요합니다."
        exit 1
      fi
      ;;
    "production")
      if [ -n "$TAG" ]; then
        VERSION="$TAG"
      else
        echo "Error: production 브랜치는 태그가 필요합니다."
        exit 1
      fi
      ;;
    *)
      VERSION="eph-${COMMIT_HASH}"
      ;;
  esac

  echo "Branch: $BRANCH"
  echo "Image version: $VERSION"
}

check_existing_tag() {
  local repo=$1
  
  echo "Checking if tag ${VERSION} already exists in ${repo}..."
  
  if az acr repository show-tags \
    -n ${ACR_NAME} \
    --repository ${repo} \
    --output table \
    --username ${ACR_USERNAME} \
    --password "${ACR_PASSWORD}" | grep -q "^${VERSION}"; then
    echo "Error: Tag ${VERSION} already exists in repository ${repo}"
    exit 1
  fi
}

build_images() {

echo "Building images..."
  docker build --platform=linux/amd64 \
    -t ${ACR_NAME}.azurecr.io/${TASK_AGENT_REPO}:${VERSION} \
    -f ./task-agent/Dockerfile \
    ./task-agent

  docker build --platform=linux/amd64 \
    -t ${ACR_NAME}.azurecr.io/${AI_CHAT_REPO}:${VERSION} \
    -f ./ai-chat/Dockerfile \
    ./ai-chat
}

acr_login() {
  echo "${ACR_PASSWORD}" | docker login -u "${ACR_USERNAME}" --password-stdin ${ACR_NAME}.azurecr.io
}

push_images() {

  echo "Pushing images..."
  docker push ${ACR_NAME}.azurecr.io/${TASK_AGENT_REPO}:${VERSION}
  docker push ${ACR_NAME}.azurecr.io/${AI_CHAT_REPO}:${VERSION}
}

verify_push() {
  echo "Checking tags for TASK_AGENT_REPO:"
  az acr repository show-tags -n ${ACR_NAME} --repository ${TASK_AGENT_REPO} --output table -u ${ACR_USERNAME} -p ${ACR_PASSWORD} | grep ${VERSION} && echo "Tag ${VERSION} was successfully pushed to TASK_AGENT_REPO." || echo "Tag ${VERSION} was not found in TASK_AGENT_REPO."
  
  echo "Checking tags for AI_CHAT_REPO:"
  az acr repository show-tags -n ${ACR_NAME} --repository ${AI_CHAT_REPO} --output table -u ${ACR_USERNAME} -p ${ACR_PASSWORD} | grep ${VERSION} && echo "Tag ${VERSION} was successfully pushed to AI_CHAT_REPO." || echo "Tag ${VERSION} was not found in AI_CHAT_REPO."
}


cd ../../apps || exit 1
generate_version

# 빌드 전 태그 존재 여부 확인
check_existing_tag ${TASK_AGENT_REPO}
check_existing_tag ${AI_CHAT_REPO}

build_images
push_images
verify_push


echo "배포 완료"
