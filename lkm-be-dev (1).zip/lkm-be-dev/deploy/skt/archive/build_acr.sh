#!/bin/bash

set -e

ENV_FILE=".env-deploy"
if [ ! -f $ENV_FILE ]; then
  echo "$ENV_FILE 파일을 찾을 수 없습니다."
  exit 1
fi

export $(grep -v '^#' $ENV_FILE | xargs)

generate_version() {
  TAG=$(git describe --tags --abbrev=0 2>/dev/null || true)
  if [ -n "$TAG" ]; then
    VERSION=$TAG
  else
    COMMIT_HASH=$(git rev-parse --short HEAD)
    VERSION="$COMMIT_HASH"
  fi
  echo "이미지 버전: $VERSION"
}

build_images() {
  docker build --platform=linux/amd64 \
    -t ${ACR_NAME}.azurecr.io/${TASK_AGENT_REPO}:${VERSION} \
    -f ./task-agent/Dockerfile \
    .

  docker build --platform=linux/amd64 \
    -t ${ACR_NAME}.azurecr.io/${AI_CHAT_REPO}:${VERSION} \
    -f ./ai-chat/Dockerfile \
    .
}

acr_login() {
  echo "${ACR_PASSWORD}" | docker login -u "${ACR_USERNAME}" --password-stdin ${ACR_NAME}.azurecr.io
}

push_images() {
  docker push ${ACR_NAME}.azurecr.io/${TASK_AGENT_REPO}:${VERSION}
  docker push ${ACR_NAME}.azurecr.io/${AI_CHAT_REPO}:${VERSION}
}

verify_push() {
  az acr repository list -n ${ACR_NAME} --output table -u ${ACR_USERNAME} -p ${ACR_PASSWORD}
  az acr repository show-tags -n ${ACR_NAME} --repository ${TASK_AGENT_REPO} -u ${ACR_USERNAME} -p ${ACR_PASSWORD}
  az acr repository show-tags -n ${ACR_NAME} --repository ${AI_CHAT_REPO} -u ${ACR_USERNAME} -p ${ACR_PASSWORD}
}

cd ../apps || exit 1
generate_version
build_images
acr_login
push_images
verify_push

echo "배포 완료"
