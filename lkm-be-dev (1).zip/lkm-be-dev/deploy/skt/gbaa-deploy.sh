#!/bin/bash

# 환경 변수 설정
GITLAB_REPO_DIR="your-gitlab-repo-dir"
GITLAB_USERNAME="your-gitlab-username"
GITLAB_TOKEN="your-gitlab-token"
GITLAB_BRANCH="your-gitlab-branch"
ACR_NAME="your-acr-name"
ACR_USERNAME="your-acr-username"
ACR_PASSWORD="your-acr-password"

set -e

if [ -z "$1" ]; then
    echo "Error: docker image tar 파일명을 입력해주세요"
    echo "Usage: ./gbaa-deploy.sh <docker-image-tar-file>"
    exit 1
fi

IMAGE_TAR_FILE=$1

pull_gitlab_repo() {
    echo "GitLab 저장소 pull 중..."

    if [ -d "$GITLAB_REPO_DIR" ]; then
        cd $GITLAB_REPO_DIR
        git checkout ${GITLAB_BRANCH}
        git pull origin ${GITLAB_BRANCH}
        # git pull origin ${GITLAB_BRANCH} https://${GITLAB_USERNAME}:${GITLAB_TOKEN}@gitlab.tde.sktelecom.com/RPAPROJ/adotbiz_src.git
    else
        echo "❌ Error: GitLab 저장소($GITLAB_REPO_DIR)를 찾을 수 없습니다."
        echo "다음 명령어로 저장소를 먼저 클론해주세요"
        exit 1
    fi
}

load_docker_image() {
    echo "Docker 이미지 로드 중..."

    cd $GITLAB_REPO_DIR

    if [ -f "$IMAGE_TAR_FILE" ]; then
        LOAD_OUTPUT=$(docker load < $IMAGE_TAR_FILE)
        echo "$LOAD_OUTPUT"

        FULL_IMAGE_NAME=$(echo "$LOAD_OUTPUT" | grep "Loaded image: " | sed 's/Loaded image: //')
        IMAGE_NAME=$(echo "$FULL_IMAGE_NAME" | sed 's/.*\.azurecr\.io\///')
        if [ -z "$IMAGE_NAME" ]; then
            echo "Error: 이미지 이름을 추출할 수 없습니다"
            exit 1
        fi

        echo "IMAGE_NAME: $IMAGE_NAME"
    else
        echo "Error: $IMAGE_TAR_FILE 파일을 찾을 수 없습니다"
        exit 1
    fi
}

login_acr() {
    echo "ACR 로그인 중..."

    docker login $ACR_NAME.azurecr.io -u $ACR_USERNAME -p $ACR_PASSWORD

    if [ $? -ne 0 ]; then
        echo "Error: ACR 로그인 실패"
        exit 1
    fi
}

push_docker_image() {
    echo "Docker 이미지 태그 설정 중..."

    NEW_IMAGE_NAME="$ACR_NAME.azurecr.io/$IMAGE_NAME"

    if [ "$FULL_IMAGE_NAME" != "$NEW_IMAGE_NAME" ]; then
        echo "Docker 이미지 태그 설정 중..."
        docker tag $IMAGE_NAME $NEW_IMAGE_NAME
    fi

    echo "ACR에 이미지 푸시 중..."
    docker push $NEW_IMAGE_NAME

    if [ $? -eq 0 ]; then
        echo "이미지 푸시 완료: $NEW_IMAGE_NAME"
    else
        echo "Error: 이미지 푸시 실패"
        exit 1
    fi
}

restart_pod() {
    DEPLOYMENT_NAME=$(echo "$IMAGE_NAME" | cut -d':' -f1)
    echo "재시작 Deployment 이름: $DEPLOYMENT_NAME"

    echo "Deployment 이미지 업데이트 중..."
    CURRENT_IMAGE=$(kubectl get deployment $DEPLOYMENT_NAME -n gbaa -o jsonpath='{.spec.template.spec.containers[0].image}')
    
    if [ "$CURRENT_IMAGE" == "$NEW_IMAGE_NAME" ]; then
        echo "현재 이미지와 새 이미지가 동일합니다. Deployment를 강제로 재시작합니다..."
        kubectl rollout restart deployment $DEPLOYMENT_NAME -n gbaa
    else
        echo "새로운 이미지로 업데이트합니다..."
        kubectl set image deployment/$DEPLOYMENT_NAME $DEPLOYMENT_NAME=$NEW_IMAGE_NAME -n gbaa
        echo "Deployment 업데이트 완료"
    fi
    
    if [ $? -eq 0 ]; then
        echo "Deployment 상태 확인 중..."
        kubectl rollout status deployment/$DEPLOYMENT_NAME -n gbaa
    else
        echo "Error: Deployment 업데이트 실패"
        exit 1
    fi
}

print_separator() {
    echo -e "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
}

main() {
    print_separator
    echo "🚀 AI Chat 배포 프로세스 시작..."
    print_separator
    
    echo "📦 1단계: GitLab 저장소 업데이트"
    pull_gitlab_repo
    print_separator
    
    echo "🔄 2단계: Docker 이미지 로드"
    load_docker_image
    print_separator
    
    echo "🔑 3단계: ACR 로그인"
    login_acr
    print_separator
    
    echo "⬆️  4단계: Docker 이미지 푸시"
    push_docker_image
    print_separator
    
    echo "🔄 5단계: Kubernetes Deployment 업데이트"
    restart_pod
    print_separator
    
    echo "✅ 배포 프로세스 완료!"
    print_separator
}

main