#!/bin/bash
# gitlab-migration.sh
#
# 이 스크립트는 GitHub의 dev, stg, prd 브랜치 내용을 각각
# GitLab의 GBCR-dev, GBCR-stg, GBCR-prd 브랜치로 매핑합니다.
# 또한, OLD_DIR (예: "/Users/K/Desktop/ai-coding/solur-ai-core/apps") 내의
# apps 폴더에서 "ai-chat"과 "task-agent" 폴더만 선택하여,
# NEW_BASE_DIR (예: "/Users/K/Desktop/GBAA-GitLab/adotbiz/solur-ai-core/apps") 아래로 이동시킨 후,
# 변경 사항을 커밋하고 GitLab 원격 저장소("origin")로 푸시합니다.
#
# 사용 방법:
#   해당 파일을 실행하기 전 로컬에 github / gitlab repository 가 각각 clone 및 pull 되어있어야 합니다.
#   1. 이 파일을 예: gitlab-migration.sh 로 저장합니다.
#   2. 아래 설정 변수들을 필요에 따라 수정합니다.
#   3. 실행 권한 부여: chmod +x gitlab-migration.sh
#   4. Git 리포지토리 루트(OLD_DIR, 즉 각 apps 폴더가 있는 위치)에서 실행: ./gitlab-migration.sh

###############################
# 설정 변수 (필요에 따라 수정)
###############################

# 기존 코드가 위치한 폴더 (여기서는 git 리포지토리의 작업 디렉토리, 예: "apps" 폴더)
OLD_DIR="/Users/K/Desktop/ai-coding/solur-ai-core/apps"

# 새 폴더 구조의 최종 위치 (GitLab에 업로드될 폴더 경로)
NEW_BASE_DIR="/Users/K/Desktop/GBAA-GitLab/adotbiz/solur-ai-core/apps"

# OLD_DIR 내에서 옮길 폴더 목록 (예: OLD_DIR/apps 내에서 선택할 폴더들)
FOLDERS_TO_MOVE=("ai-chat" "task-agent")

# 브랜치 목록 (GitHub에서는 dev, stg, prd가 있다고 가정)
# BRANCHES=("dev" "stg" "prd")
BRANCHES=("develop")
# 새 브랜치 이름은 "GBCR-" 접두어를 붙입니다.
# 예: dev -> GBCR-dev, stg -> GBCR-stg, prd -> GBCR-prd

# GitLab 원격 저장소 이름 (여기서는 "origin"으로 설정; 미리 등록되어 있어야 함)
GITLAB_REMOTE="origin"

###############################
# 스크립트 시작
###############################

# OLD_DIR가 존재하는지 확인
if [ ! -d "$OLD_DIR" ]; then
    echo "오류: '$OLD_DIR' 폴더가 존재하지 않습니다."
    exit 1
fi

echo "=============================="
echo "브랜치별 폴더 재구성과 이름 변경 자동화 시작"
echo "OLD_DIR = $OLD_DIR"
echo "NEW_BASE_DIR = $NEW_BASE_DIR"
echo "=============================="

# 각 브랜치(dev, stg, prd)에 대해 처리
for branch in "${BRANCHES[@]}"; do
    OLD_BRANCH="$branch"
    NEW_BRANCH="GBCR-${branch}"
    echo "------------------------------"
    echo "[$OLD_BRANCH] -> [$NEW_BRANCH] 처리 시작"
    
    # GitHub에서 최신 브랜치 정보 가져오기
    echo "  >> GitHub 최신 브랜치 목록 동기화 (fetch)"
    git -C "$OLD_DIR" fetch origin
    
    # GitHub에서 브랜치 checkout 및 최신 코드 pull
    echo "  >> GitHub에서 브랜치 [$OLD_BRANCH] 체크아웃"
    if ! git -C "$OLD_DIR" checkout "$OLD_BRANCH"; then
        echo "  오류: 브랜치 [$OLD_BRANCH] 체크아웃 실패. 건너뜁니다."
        continue
    fi

    echo "  >> GitHub에서 최신 코드 pull"
    git -C "$OLD_DIR" pull origin "$OLD_BRANCH"

    # 새 브랜치(NEW_BRANCH)가 이미 존재하는지 확인 후, 있으면 체크아웃, 없으면 생성
    if git -C "$NEW_BASE_DIR" show-ref --verify --quiet refs/heads/"$NEW_BRANCH"; then
        echo "  브랜치 [$NEW_BRANCH]가 이미 존재합니다. 체크아웃합니다."
        git -C "$NEW_BASE_DIR" checkout "$NEW_BRANCH"
    else
        echo "  브랜치 [$NEW_BRANCH]가 존재하지 않습니다. [$OLD_BRANCH] 기준으로 새로 생성합니다."
        if ! git -C "$NEW_BASE_DIR" checkout -b "$NEW_BRANCH" "$OLD_BRANCH"; then
            echo "  오류: 브랜치 [$NEW_BRANCH] 생성 실패. 건너뜁니다."
            continue
        fi
    fi

    # NEW_BASE_DIR의 존재 여부 확인 (반드시 존재해야 함)
    if [ ! -d "$NEW_BASE_DIR" ]; then
        echo "오류: '$NEW_BASE_DIR' 폴더가 존재하지 않습니다."
        exit 1
    fi

    # OLD_DIR에서 지정한 폴더들을 NEW_BASE_DIR로 이동 (덮어쓰기)
    for folder in "${FOLDERS_TO_MOVE[@]}"; do
        SRC_PATH="${OLD_DIR}/${folder}"
        DEST_PATH="${NEW_BASE_DIR}/${folder}"
        
        if [ -d "$SRC_PATH" ]; then
            echo "  [$folder] 이동 시작: $SRC_PATH -> $DEST_PATH"

            # GitHub에서 삭제된 파일이 GitLab에서도 삭제되도록 --delete 옵션 추가
            rsync -av --delete --exclude ".git/" "$SRC_PATH/" "$DEST_PATH/"

            echo "  이동 완료: $DEST_PATH"
        else
            echo "  주의: '$SRC_PATH' 폴더가 존재하지 않습니다. 건너뜁니다."
        fi
    done

    # 변경 사항 add 및 커밋 (OLD_DIR 내에서 실행)
    git -C "$NEW_BASE_DIR" add .
    if git -C "$NEW_BASE_DIR" diff --cached --quiet; then
        echo "  변경 사항이 없습니다."
    else
        git -C "$NEW_BASE_DIR" commit -m "구조 재구성: $OLD_DIR 내 ['${FOLDERS_TO_MOVE[*]}'] 폴더를 '$NEW_BASE_DIR'로 이동 (브랜치: $NEW_BRANCH)"
    fi

    echo ">> [$NEW_BRANCH] 처리 완료"
    echo "------------------------------"
done

echo "=============================="
echo "모든 브랜치 처리 완료"
echo "GitLab 원격 저장소($GITLAB_REMOTE)로 푸시 시작"
echo "=============================="

# 각 새 브랜치를 GitLab 원격 저장소로 푸시 (OLD_DIR 내에서 실행)
for branch in "${BRANCHES[@]}"; do
    NEW_BRANCH="GBCR-${branch}"
    echo "푸시: 브랜치 [$NEW_BRANCH]"
    if ! git -C "$NEW_BASE_DIR" push -u "$GITLAB_REMOTE" "$NEW_BRANCH"; then
        echo "  오류: 브랜치 [$NEW_BRANCH] 푸시 실패"
    else
        echo "  브랜치 [$NEW_BRANCH] 푸시 성공."
    fi
done

echo "자동화 작업 완료."
