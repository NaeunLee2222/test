#!/bin/bash

set -e

# 환경 파라미터 검증
if [ "$#" -ne 1 ] || { [ "$1" != "dev" ] && [ "$1" != "prod" ]; }; then
  echo "Usage: $0 [dev|prod]"
  exit 1
fi

ENV=$1

if [ "$ENV" == "prod" ]; then
  ENV_FILE=".env-deploy-prod"
  IMAGE_SUFFIX="-prod"
elif [ "$ENV" == "dev" ]; then
  ENV_FILE=".env-deploy-dev"
  IMAGE_SUFFIX="-dev"
fi

if [ ! -f $ENV_FILE ]; then
  echo "$ENV_FILE 파일을 찾을 수 없습니다."
  exit 1
fi

export $(grep -v '^#' $ENV_FILE | xargs)

generate_version() {
  TAG=$(git describe --tags --abbrev=0 2>/dev/null || true)
  if [ -n "$TAG" ]; then
    VERSION=$TAG
  else
    COMMIT_HASH=$(git rev-parse --short HEAD)
    VERSION="$COMMIT_HASH"
  fi
  echo "이미지 버전: $VERSION"
}

build_images() {
  docker build --platform=linux/amd64 \
    -t ${ACR_NAME}.azurecr.io/${TASK_AGENT_REPO}:${VERSION} \
    -f ./task-agent/Dockerfile \
    ./task-agent

  docker build --platform=linux/amd64 \
    -t ${ACR_NAME}.azurecr.io/${AI_CHAT_REPO}:${VERSION} \
    -f ./ai-chat/Dockerfile \
    ./ai-chat
}

SAVE_DIR="/tmp/gbaa-docker-images"

save_images() {
  
  mkdir -p $SAVE_DIR

  echo "Docker 이미지를 저장합니다: /tmp"
  docker save ${ACR_NAME}.azurecr.io/${TASK_AGENT_REPO}:${VERSION} > /tmp/task-agent${IMAGE_SUFFIX}.tar
  docker save ${ACR_NAME}.azurecr.io/${AI_CHAT_REPO}:${VERSION} > /tmp/ai-chat${IMAGE_SUFFIX}.tar
}

upload_to_gitlab() {

  cd $SAVE_DIR
  git init
  git remote add origin https://gitlab.tde.sktelecom.com/RPAPROJ/adotbiz_src.git > /dev/null 2>&1 || true
  git fetch origin

  GIT_LFS_SKIP_SMUDGE=1 git checkout -B gbaa-deploy origin/gbaa-deploy || git checkout -b gbaa-deploy

  cp -f /tmp/task-agent${IMAGE_SUFFIX}.tar ./task-agent${IMAGE_SUFFIX}.tar || true
  cp -f /tmp/ai-chat${IMAGE_SUFFIX}.tar ./ai-chat${IMAGE_SUFFIX}.tar || true

  git lfs track "*.tar"

  git add .gitattributes task-agent${IMAGE_SUFFIX}.tar ai-chat${IMAGE_SUFFIX}.tar
  git commit -m "Add Docker images ${ENV} $(date +'%Y-%m-%d %H:%M:%S')"
  git push origin gbaa-deploy --force

  echo "Uploaded Docker images to GitLab."
}


cd ../../apps || exit 1
generate_version
build_images
save_images
upload_to_gitlab


echo "배포 완료"
