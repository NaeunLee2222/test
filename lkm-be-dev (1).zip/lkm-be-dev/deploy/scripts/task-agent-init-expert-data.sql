-- expert_agents 데이터 삽입
INSERT INTO ai_chat.expert_agents (id, created_user_id, name, description, category, usage_scope, org_id, team_id, created_at, updated_at) VALUES
(1, 101, 'Engr.업무 지원 Agent', 'RFQ/TBE sheet 자동 작성 및 기술검증', 'document', 'public', 1, 1, NOW(), NOW());

-- 일관성을 위해 sequence 재설정
SELECT setval('ai_chat.expert_agents_id_seq', (SELECT MAX(id) FROM ai_chat.expert_agents));


-- step 데이터 삽입
INSERT INTO ai_chat.steps (id, expert_agent_id, name, description, "order", created_at, updated_at) VALUES
(1, 1, 'RFQ 초안 생성', '기존 RFQ를 참고하여 새로운 RFQ 초안을 생성합니다', 0, NOW(), NOW()),
(2, 1, 'RFQ 검색', '조건에 맞는 RFQ 문서를 검색합니다', 1, NOW(), NOW()),
(3, 1, 'TBE 생성', 'RFQ 기반으로 TBE 문서를 생성합니다', 2, NOW(), NOW()),
(4, 1, 'RFQ 정합성 검토', 'RFQ 문서의 정합성을 검토합니다', 3, NOW(), NOW());

-- 일관성을 위해 sequence 재설정
SELECT setval('ai_chat.steps_id_seq', (SELECT MAX(id) FROM ai_chat.steps));


-- action 데이터 삽입
INSERT INTO ai_chat.actions (id, step_id, name, description, "order") VALUES
-- RFQ 초안 생성 액션
(1, 1, '데이터 추출', '채팅에서 전달받은 입력데이터에서 장비명, 제목, 담당자명을 추출해줘', 0),
(2, 1, 'Temp.RFQ 폴더에서 검색 (파일 검색)', '채팅에서 전달받은 입력데이터에서 장비명을 검색키워드로 추출해서 최근 5개 파일 조회하고싶어', 1),
(3, 1, '기준 RFQ 선정', '이전 단계에서 검색한 파일 중 채팅에서 전달받은 입력데이터와 가장 유사한 RFQ를 선정해줘', 2),
(4, 1, 'RFQ 섹션 구분', '문서 내 구조를 파악하여 섹션을 구분해줘', 3),
(5, 1, '비교 대상으로 취급할 RFQ 선정', '각 RFQ에서 추출된 목차와 섹션 내용을 바탕으로 기준 RFQ와의 비교 대상으로 취급할지 결정해줘', 4),
(6, 1, '기준 RFQ와 비교 대상 RFQ들 간 차이점 비교', '기준 RFQ의 섹션 내용과 비교 대상 RFQ의 섹션 내용을 비교해서 공통점과 차이점을 도출해줘', 5),
(7, 1, 'RFQ 초안 작성', '이전 단계에서 도출한 비교 내용을 토대로 RFQ 초안 작성해줘', 6),
(8, 1, '문서 기본 정보 수정 (텍스트 수정)', '이전 단계에서 작성한 RFQ 초안을 확인해서 장비명, 제목, 담당자명을 수정해줘', 7),
(9, 1, 'Feedback 반영', 'Feedback DB에서 적합한 항목을 검색하여 이를 문서에 적용', 8),
(10, 1, 'Canvas로 출력', '작성된 RFQ 초안 출력', 9),
(11, 1, '파일 저장', '작성된 RFQ 초안 저장', 10),

-- RFQ 검색 액션
(12, 2, 'RDB검색', '사용자가 제공한 조건에 맞게 데이터를 필터링하고, 결과값을 반환해줘', 0),
(13, 2, '폴더 내 RFQ 파일 검색', '유저가 입력한 키워드를 기반으로 문서를 검색해줘', 1),

-- TBE 생성 액션
(14, 3, 'RFQ 차이점 추출', '기준 RFQ와 새 RFQ의 차이점을 분석해줘', 0),
(15, 3, '이전 TBE 구조 분석', '이전 TBE Sheet의 엑셀 시트를 읽어줘', 1),
(16, 3, 'RFQ-TBE 구조 매핑', 'RFQ 차이점을 보고, TBE Sheet에서 바뀌어야 하는 row들의 목록을 찾아줘', 2),
(17, 3, 'TBE 기본 정보 수정', '프로젝트명, 장비정보, 날짜 등 기본 정보를 description column에 반영하여 바꿔줘', 3),
(18, 3, 'TBE 요구사항 업데이트', 'RFQ의 기술 요구사항, 코드/표준, 특이사항 등의 requirement 여부를 requirement colum에 반영하여 바꿔 줘', 4),
(19, 3, 'TBE 출력', '완성된 TBE를 Canvas로 시각화하여 출력', 5),

-- RFQ 정합성 검토 액션
(20, 4, '섹션 구분', '문서 내 구조를 파악하여 섹션 구분', 0),
(21, 4, '섹션 내부 일관성 검토', '체크박스 상태, 기술 서술 간 논리적 불일치 등 섹션 내부의 일관성을 검토', 1),
(22, 4, '섹션 간 교차 검토', '문서 내 연관된 섹션 간 논리적 흐름과 맥락의 일관성을 교차 검토', 2),
(23, 4, '필수 요소 누락 검토', '문서 내 필수 정보, 참조 요소(첨부 문서, 표 등)의 누락 여부를 검토', 3),
(24, 4, '중복 서술 검출', '문서 전체에서 중복 서술 항목을 탐지', 4),
(25, 4, '단위/용어 일관성 확인', '단위 및 용어 사용의 불일치 여부를 점검', 5);

-- 일관성을 위해 sequence 재설정
SELECT setval('ai_chat.actions_id_seq', (SELECT MAX(id) FROM ai_chat.actions));

-- tool 데이터 삽입
INSERT INTO ai_chat.tools (id, name, description, type, icon_path, config, created_at, updated_at, endpoint) VALUES
(1, 'search_latest_documents', '특정 키워드와 조건을 기반으로 최신 문서를 검색하는 함수', 'mcp', NULL,
'{
  "parameters": [
    {
      "name": "keywords",
      "type": "array",
      "required": true,
      "description": "검색할 키워드들",
      "items": {"type": "string"}
    },
    {
      "name": "doc_type",
      "type": "string",
      "required": false,
      "description": "문서 형식 (예: ''docx'', ''xlsx'', ''pdf'')",
      "enum": ["docx", "xlsx", "pdf"]
    },
    {
      "name": "author",
      "type": "string",
      "required": false,
      "description": "문서의 작성자"
    },
    {
      "name": "date_range_years",
      "type": "integer",
      "required": false,
      "description": "최근 몇 년 간의 문서만 검색"
    },
    {
      "name": "docs_num",
      "type": "integer",
      "required": false,
      "description": "반환할 문서의 개수",
      "default": 1
    },
    {
      "name": "sort_order",
      "type": "string",
      "required": false,
      "description": "정렬 기준 (''asc'', ''desc'')",
      "default": "desc"
    },
    {
      "name": "path",
      "type": "string",
      "required": false,
      "description": "문서 검색 경로"
    }
  ]
}', NOW(), NOW(), '{"url": "http://127.0.0.1:80/sse", "transport": "sse"}'),
(2, 'docx_to_html_tool', 'Word 문서를 HTML로 변환', 'mcp', NULL,
'{
  "parameters": [
    {
      "name": "file_paths",
      "type": "list[str]",
      "required": true,
      "description": "변환할 Word 문서들의 경로 리스트"
    }
  ]
}', NOW(), NOW(), '{"url": "http://127.0.0.1:80/sse", "transport": "sse"}');

-- 일관성을 위해 sequence 재설정
SELECT setval('ai_chat.tools_id_seq', (SELECT MAX(id) FROM ai_chat.tools));


-- action_tool_relationship 데이터 삽입
INSERT INTO ai_chat.action_tool_relationship (action_id, tool_id) VALUES
(1, 1),  -- 데이터 추출
(10, 2);  -- html 변환
