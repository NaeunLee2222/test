-- SET ROLE workat_db_service;

CREATE TYPE http_method AS ENUM ('GET', 'POST', 'PUT', 'DELETE', 'PATCH');
-- 사용 범위를 위한 열거형 타입 생성
CREATE TYPE usage_scope AS ENUM ('public', 'team', 'personal');
-- 문서 상태를 위한 열거형 타입 생성
CREATE TYPE procedure_document_status AS ENUM ('active', 'deleted');


CREATE TABLE IF NOT EXISTS api_specs (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    is_tool_enabled BOOLEAN DEFAULT TRUE,
    service_category VARCHAR(100),
    endpoint VARCHAR(255) NOT NULL,
    description VARCHAR(500),
    method http_method NOT NULL,
    params JSON,
    body JSON,
    headers JSON,
    response_format JSON,
    rate_limit INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE
);


-- expert_agents 테이블
CREATE TABLE IF NOT EXISTS expert_agents (
    id SERIAL PRIMARY KEY,
    created_user_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(255),
    usage_scope usage_scope,
    org_id INTEGER,
    team_id INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE
);

-- steps 테이블
CREATE TABLE IF NOT EXISTS steps (
    id SERIAL PRIMARY KEY,
    expert_agent_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    "order" INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE
);

-- actions 테이블
CREATE TABLE IF NOT EXISTS actions (
    id SERIAL PRIMARY KEY,
    step_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    "order" INTEGER NOT NULL
);

-- tools 테이블
CREATE TABLE IF NOT EXISTS tools (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(255), -- 추후 Enum으로 변경 가능
    icon_path VARCHAR(255),
    config JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE,
    endpoint VARCHAR(255)
);

-- action_tool_relationship 테이블
CREATE TABLE IF NOT EXISTS action_tool_relationship (
    id SERIAL PRIMARY KEY,
    action_id INTEGER NOT NULL,
    tool_id INTEGER NOT NULL
);

-- procedure_documents 테이블
CREATE TABLE IF NOT EXISTS procedure_documents (
    id SERIAL PRIMARY KEY,
    expert_agent_id INTEGER,
    uploaded_user_id INTEGER NOT NULL,
    filename VARCHAR(64) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    file_type VARCHAR(255) NOT NULL,
    status procedure_document_status,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE
);
