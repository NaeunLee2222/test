-- SET ROLE workat_db_service;

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    username VARCHAR(50),
    is_active BOOLEAN NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE,
    profile TEXT
);

CREATE TABLE IF NOT EXISTS task_agents (
    id SERIAL PRIMARY KEY,
    task_agent_name VARCHAR(100) NOT NULL UNIQUE,
    task_agent_url VARCHAR(255) NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE IF NOT EXISTS chats (
    id VARCHAR(36) NOT NULL PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL REFERENCES users (user_id),
    title TEXT,
    model VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE,
    config_json TEXT
);

CREATE TABLE IF NOT EXISTS chat_messages (
    uuid VARCHAR(36) NOT NULL PRIMARY KEY,
    parent_uuid VARCHAR(36),
    chat_id VARCHAR(36) NOT NULL REFERENCES chats,
    task_agent_id INTEGER NOT NULL REFERENCES task_agents,
    role VARCHAR(10) NOT NULL,
    type VARCHAR(10) NOT NULL,
    content TEXT NOT NULL,
    is_aborted BOOLEAN NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS chat_task_agent_states (
    chat_message_uuid VARCHAR(36) NOT NULL PRIMARY KEY REFERENCES chat_messages,
    state JSON,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);