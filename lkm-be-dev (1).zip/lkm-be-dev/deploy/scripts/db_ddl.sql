-- DB 접속
psql -h <host> -U <username> -d <database>

-- gbcr_ai_chat 스키마 생성
CREATE SCHEMA IF NOT EXISTS gbcr_ai_chat;

-- gbcr_task_agent 스키마 생성
CREATE SCHEMA IF NOT EXISTS gbcr_task_agent;