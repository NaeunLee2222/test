#!/bin/bash
# git origin 소스를 받아온 후 venv 디렉토리를 삭제하는 스크립트

git fetch --all
git pull origin

git clean -f -d
find . -type d -name 'venv' | xargs rm -rf
