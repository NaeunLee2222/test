#!/bin/bash
# ----
# 아래와 같이 workspace root에서 실행
# ./settings/local/set-whole-settings.sh

# 실행 후에 launch.json으로 파이선 서비스 실행이 안되는 경우
# vscode에서 Cmd + Shift + P의 명령 팔레트에서 Python Debugger: Clear Cache and reload window 실행
# ----

# conda deactivate

cd ./apps/action-hub

python3.10 -m venv venv
source venv/bin/activate
pip install -r app/requirements.txt

cd ..