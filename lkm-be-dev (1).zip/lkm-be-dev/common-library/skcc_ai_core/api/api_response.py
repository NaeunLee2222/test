from typing import Any, Optional

from pydantic import BaseModel

from .error.error_code import ErrorCode


class ErrorModel(BaseModel):
    code: int
    name: str
    message: Optional[str] = None

    @classmethod
    def create_error_model(
        cls, error_code: ErrorCode, detail: Optional[str] = None
    ) -> "ErrorModel":
        return cls(code=error_code.value, name=error_code.name, message=detail)


class ResponseModel(BaseModel):
    data: Optional[Any] = None
    error: Optional[ErrorModel] = None
