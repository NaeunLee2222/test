from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse

from ..api_response import ErrorModel, ResponseModel
from .error_code import ErrorCode
from .service_exception import ServiceException


def set_error_handlers(app: FastAPI, logger):
    @app.exception_handler(ServiceException)
    async def predefined_exception_handler(request: Request, exc: ServiceException):
        logger.error(str(exc))
        return JSONResponse(
            status_code=exc.status_code,
            content=ResponseModel(
                error=ErrorModel.create_error_model(
                    error_code=exc.error_code, detail=exc.detail
                )
            ).model_dump(),
        )

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        logger.error(str(exc))
        if exc.status_code < 200 or exc.status_code == 204 or exc.status_code == 304:
            return Response(status_code=exc.status_code)
        return JSONResponse(
            status_code=exc.status_code,
            content=ResponseModel(
                error=ErrorModel.create_error_model(
                    error_code=ErrorCode.UNEXPECTED_ERROR
                )
            ).model_dump(),
        )

    @app.exception_handler(Exception)
    async def base_exception_handler(request: Request, exc: Exception):
        logger.error(str(exc))
        return JSONResponse(
            status_code=500,
            content=ResponseModel(
                error=ErrorModel.create_error_model(
                    error_code=ErrorCode.UNEXPECTED_ERROR
                )
            ).model_dump(),
        )
