# setup.py

from setuptools import find_packages, setup

setup(
    name="skcc_ai_core",  # 패키지 이름을 여기에 넣습니다.
    version="0.1.0",
    packages=find_packages(),  # 디렉토리에서 패키지를 자동으로 찾습니다.
    install_requires=[
        "pydantic>=1.8.2",  # 패키지의 의존성 목록입니다.
    ],
    description="ErrorModel과 ResponseModel 클래스를 제공하는 패키지",
    author="",  # 본인의 이름이나 조직 이름을 넣습니다.
    author_email="",  # 본인의 이메일을 넣습니다.
    url="https://github.com/skcc-ai/ai-core",  # GitHub 리포지토리 URL을 넣습니다.
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",  # 최소 파이썬 버전을 명시합니다.
)
