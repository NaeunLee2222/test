### apps

| Name       | Port | Description |
| ---------- | ---- | ----------- |
| llm-hub    | 8001 |             |
| action-hub | 8002 |             |
| auth       | 8003 |             |
| docs       | 8004 |             |
