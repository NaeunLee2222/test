import httpx
from agents.supervisor.agents import RouterAgent
from core.config import get_setting
from core.context import get_current_user_info, get_transaction_id
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel

settings = get_setting()


# Pydantic 모델 정의
class MessageRequest(BaseModel):
    content: str


class MessageResponse(BaseModel):
    content: str


# StateGraph 워크플로우 정의
def get_graph(task_agents):
    a = settings.SK_AI_PLATFORM_ENABLED
    if settings.SK_AI_PLATFORM_ENABLED:
        llm = ChatOpenAI(
            api_key=settings.SK_AI_PLATFORM_API_KEY,
            base_url=settings.SK_AI_PLATFORM_URL,
            model=settings.SK_AI_PLATFORM_CHAT_MODEL_NAME,
            n=1,
            temperature=0,
            max_tokens=None,
            verbose=True,
            streaming=True,
            default_headers={
                "aip-user": f"{get_current_user_info().department}/{get_current_user_info().user_id}",
                "aip-app-id": f"{settings.COMPANY.lower()}-{settings.APP_NAME}-app-{settings.ENVIRONMENT.lower()}",
                "aip-transaction-id": get_transaction_id(),
            },
        )
    else:
        llm = AzureChatOpenAI(
            azure_deployment=settings.OPENAI_DEPLOYMENT,
            azure_endpoint=settings.OPENAI_ENDPOINT,
            api_version=settings.OPENAI_API_VERSION,
            api_key=settings.OPENAI_API_KEY,
            n=1,
            temperature=0,
            max_tokens=None,
            model=settings.OPENAI_MODEL,
            verbose=True,
            streaming=True,
        )
    workflow = StateGraph(dict)  # 상태를 dict로 지정
    router = RouterAgent(task_agents, llm).get_agent()

    # router 노드 추가
    workflow.add_node("router", router)

    workflow.add_edge(START, "router")

    workflow.add_edge("router", END)  # 모든 노드가 END로 연결되도록 설정
    graph = workflow.compile()
    return graph
