from typing import Optional

from agents.supervisor.prompt import PromptGuardPrompt
from core.config import get_setting
from core.log.logging import get_logging
from langgraph.graph import END, START, StateGraph

logger = get_logging()
settings = get_setting()
langfuse_handler = None
try:
    from langfuse.callback import CallbackHandler

    if all(
        hasattr(settings, attr) and getattr(settings, attr)
        for attr in ["LANGFUSE_HOST", "LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY"]
    ):
        langfuse_handler = CallbackHandler(
            secret_key=settings.LANGFUSE_SECRET_KEY,
            public_key=settings.LANGFUSE_PUBLIC_KEY,
            host=settings.LANGFUSE_HOST,
        )
except ImportError:
    pass


def get_llm_config(session_id: Optional[int] = None) -> dict:
    """Generate LLM config with or without langfuse handler"""
    if langfuse_handler and session_id:
        return {
            "callbacks": [langfuse_handler],
            "metadata": {"langfuse_session_id": session_id},
        }
    return {}


class RouterAgent:
    def __init__(self, task_choice_state, llm):
        self.llm = llm
        self.task_choice_state = task_choice_state

    def prompt_guard(self, state: dict) -> dict:
        user_input = self.task_choice_state["content"]
        task_agents = self.task_choice_state["task_agents"]
        agent_url_map = {
            agent["task_agent_name"]: agent["task_agent_url"] for agent in task_agents
        }
        history = self.task_choice_state["messages_list"]

        prompt = PromptGuardPrompt(task_agents, history=history, user_query=user_input)
        system_prompt = prompt.make_system_prompt()
        user_prompt = prompt.make_user_prompt()
        output_format = prompt.OutputFormat
        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]

        # LLM 호출
        structured_llm = self.llm.with_structured_output(output_format)
        response = structured_llm.invoke(
            chat_messages,
            config=get_llm_config(session_id=self.task_choice_state["chat_id"]),
        )
        response = response.model_dump()

        logger.info(
            f"[PROMPT GUARD 결과]: {response['safety']} / {response['classification_result']}\n이유: {response['reason']}\n사용자에게 전달할 쿼리: {response['user_message']}"
        )
        state["safety"] = response["safety"]
        state["safety_message"] = response["user_message"]

        # todo 환경에 따라 default agent 설정, 추후 변경 포인트
        if settings.TASK_AGENT_ROUTE == "DEV":
            default_agent = agent_url_map.get("expert-dev")
        else:
            default_agent = agent_url_map.get("expert")

        state["next"] = default_agent
        return state

    # 동기 함수로 감싸서 StateGraph에 연결할 함수
    def router(self, state: dict) -> dict:
        former_ai_answer = self.task_choice_state["former_ai_answer"]
        task_agents = self.task_choice_state["task_agents"]
        history = self.task_choice_state["messages_list"]
        agent_url_map = {
            agent["task_agent_name"]: agent["task_agent_url"] for agent in task_agents
        }

        # TODO: frontend에서 전달받은 agent_name으로 url routing
        agent_name = state.get("agent_name")
        if agent_name:
            task_agent = agent_url_map.get(agent_name)
            state["next"] = task_agent

        return state

    def get_agent(self):
        # StateGraph 생성 및 router 노드 추가
        workflow = StateGraph(dict)
        workflow.add_node("prompt_guard", self.prompt_guard)
        workflow.add_node("router", self.router)  # 동기 래퍼 함수 사용

        conditional_map = {"safe": "router", "unsafe": END}

        workflow.add_edge(START, "prompt_guard")
        workflow.add_conditional_edges(
            "prompt_guard", lambda x: x["safety"], conditional_map
        )
        workflow.add_edge("router", END)
        return workflow.compile()
