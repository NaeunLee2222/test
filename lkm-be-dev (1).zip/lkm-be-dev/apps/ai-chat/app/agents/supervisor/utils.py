import json
import re
import time
from typing import Any, Dict, List

import tiktoken
from core.log.logging import get_logging
from langchain.callbacks.base import BaseCallbackHandler

logger = get_logging()


def extract_json(text):
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        json_str = match.group()
        try:
            data = json.loads(json_str)
            return data
        except json.JSONDecodeError:
            logger.error("유효한 JSON 형식이 아닙니다.")
            return None
    else:
        logger.error("JSON 형식의 데이터를 찾을 수 없습니다.")
        return None


def chat2text(history):
    history_text = ""
    for i in history:
        history_text += f"{i[0]} : {i[1]}\n"
    return history_text
