import os

import mysql.connector
from dotenv import load_dotenv

# 데이터베이스 연결 설정
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(current_dir))
dotenv_path = os.path.join(project_root, ".env")
load_dotenv(dotenv_path)

config = {
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "host": "localhost",
    "database": os.getenv("DB_NAME"),
    "port": os.getenv("DB_PORT"),
}

try:
    # 데이터베이스에 연결
    cnx = mysql.connector.connect(**config)
    cursor = cnx.cursor()

    # 모든 테이블 이름 가져오기
    cursor.execute("SHOW TABLES")
    tables = cursor.fetchall()

    # 각 테이블의 모든 데이터 삭제
    for table in tables:
        table_name = table[0]
        cursor.execute(f"TRUNCATE TABLE {table_name}")
        print(f"Deleted all data from {table_name}")

    # 변경사항 커밋
    cnx.commit()

except mysql.connector.Error as err:
    print(f"Error: {err}")

finally:
    # 연결 종료
    if "cnx" in locals() and cnx.is_connected():
        cursor.close()
        cnx.close()
        print("Database connection closed.")
