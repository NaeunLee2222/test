import json
import os
import uuid

import pytest
import requests
from dotenv import load_dotenv

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(current_dir))
dotenv_path = os.path.join(project_root, ".env")
load_dotenv(dotenv_path)

BASE_URL = f"http://localhost:{os.getenv('APP_PORT', 8040)}/api/v1"


@pytest.fixture
def sample_api_spec():
    unique_id = str(uuid.uuid4())[:8]
    return {
        "name": f"Sample API {unique_id}",
        "endpoint": f"http://example.com/api/{unique_id}",
        "description": f"This is a sample API {unique_id}",
        "service_category": "Sample",
        "method": "POST",
        "params": {"param1": "string", "param2": "integer"},
        "body": {"field1": "string", "field2": "boolean"},
        "headers": None,
        "response_format": {"result": "string"},
        "rate_limit": 100,
    }


def test_create_api_spec(sample_api_spec):
    response = requests.post(f"{BASE_URL}/api-specs/", json=sample_api_spec)
    assert response.status_code == 200, f"Failed to create API spec: {response.text}"
    created_spec = response.json()
    assert created_spec["name"] == sample_api_spec["name"]
    return created_spec["id"]


def test_read_api_specs():
    response = requests.get(f"{BASE_URL}/api-specs/")
    assert response.status_code == 200, f"Failed to read API specs: {response.text}"
    specs = response.json()
    assert isinstance(specs, list), "Expected a list of API specs"
    assert len(specs) > 0, "No API specs found"


def test_read_specific_api_spec(sample_api_spec):
    created_id = test_create_api_spec(sample_api_spec)
    response = requests.get(f"{BASE_URL}/api-specs/{created_id}")
    assert (
        response.status_code == 200
    ), f"Failed to read specific API spec: {response.text}"
    spec = response.json()
    assert spec["id"] == created_id
    assert spec["name"] == sample_api_spec["name"]


def test_update_api_spec(sample_api_spec):
    unique_id = str(uuid.uuid4())[:8]
    created_id = test_create_api_spec(sample_api_spec)
    update_data = {
        "name": f"Updated Sample API {unique_id}",
        "description": "This is an updated sample API",
    }
    response = requests.put(f"{BASE_URL}/api-specs/{created_id}", json=update_data)
    assert response.status_code == 200, f"Failed to update API spec: {response.text}"
    updated_spec = response.json()
    assert updated_spec["name"] == update_data["name"]
    assert updated_spec["description"] == update_data["description"]


def test_delete_api_spec(sample_api_spec):
    created_id = test_create_api_spec(sample_api_spec)
    response = requests.delete(f"{BASE_URL}/api-specs/{created_id}")
    assert response.status_code == 200, f"Failed to delete API spec: {response.text}"
    deleted_response = response.json()
    assert deleted_response["detail"] == "API Spec deleted successfully"

    # Verify that the spec is actually deleted
    response = requests.get(f"{BASE_URL}/api-specs/{created_id}")
    assert (
        response.status_code == 404
    ), f"API spec still exists after deletion: {response.text}"


if __name__ == "__main__":
    pytest.main([__file__])
