import json
import os

import pytest
import requests
from dotenv import load_dotenv

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(current_dir))
dotenv_path = os.path.join(project_root, ".env")
load_dotenv(dotenv_path)

BASE_URL = f"http://localhost:{os.getenv('APP_PORT', 8040)}/api/v1"

api_specs = {
    1: {
        "name": "list_job_postings",
        "endpoint": "http://10.250.178.135:8070/api/job-postings",
        "description": "List job postings",
        "params": None,
        "service_category": "hr",
        "body": {
            "searchText": "string(optional)",
            "corpCode": "string(optional)",
            "recruitType": "string(optional)",
        },
        "headers": None,
        "method": "POST",
        "response_format": {"jobPostings": "array"},
    },
    2: {
        "name": "register_job_posting",
        "endpoint": "http://10.250.178.135:8070/api/job-postings/register",
        "description": "Register a new job posting",
        "params": None,
        "service_category": "hr",
        "body": {
            "title": "string(required)",
            "description": "string(required)",
            "corpCode": "integer(required)",
            "recruitType": "string(required)",
            "deadline": "string(required)",
        },
        "headers": None,
        "method": "POST",
        "response_format": {"jobPostingId": "integer"},
    },
    3: {
        "name": "update_job_posting",
        "endpoint": "http://10.250.178.135:8070/api/job-postings/update/{id}",
        "description": "Update a job posting",
        "service_category": "hr",
        "params": {"id": "integer"},
        "body": {
            "title": "string(optional)",
            "description": "string(optional)",
            "corpCode": "int(optional)",
            "recruitType": "string(optional)",
            "deadline": "string(optional)",
        },
        "headers": None,
        "method": "PUT",
        "response_format": {"success": "boolean"},
    },
    4: {
        "name": "get_applicants",
        "endpoint": "http://10.250.178.135:8070/api/job-postings/applicants",
        "description": "Get applicants for a job posting",
        "service_category": "hr",
        "params": None,
        "body": {
            "postingId": "integer(required)",
            "startDate": "string(optional)",
            "endDate": "string(optional)",
        },
        "headers": None,
        "method": "POST",
        "response_format": {"applicants": "array"},
    },
    5: {
        "name": "download_resumes",
        "endpoint": "http://10.250.178.135:8070/api/job-postings/resumes",
        "description": "Download resumes for applicants",
        "service_category": "hr",
        "params": None,
        "body": {"applicantIds": "array(required)"},
        "headers": None,
        "method": "POST",
        "response_format": {"resumes": "array"},
    },
}


@pytest.fixture(scope="module")
def registered_apis():
    """API 스펙들을 등록하고 등록된 ID들을 반환"""
    registered_ids = []
    current_specs = requests.get(f"{BASE_URL}/api-specs/")
    for spec in api_specs.values():
        # 이미 등록된 API인 경우 삭제 후 재등록
        if any(s["name"] == spec["name"] for s in current_specs.json()):
            id = spec["endpoint"].split("/")[-1]
            requests.delete(f"{BASE_URL}/api-specs/{id}")
        response = requests.post(f"{BASE_URL}/api-specs/", json=spec)
        assert response.status_code == 200, f"Failed to register API: {response.text}"
        registered_ids.append(response.json()["id"])
    return registered_ids


@pytest.fixture
def query_endpoint():
    return f"{BASE_URL}/handle_query/query"


@pytest.fixture
def call_api_endpoint():
    return f"{BASE_URL}/api-call/api-call"


def test_query_with_string_api_name(query_endpoint):
    payload = {
        "query": "What job postings are available?",
        "api_name": "list_job_postings",
    }
    response = requests.post(query_endpoint, json=payload)
    assert response.status_code == 200
    result = response.json()
    assert "error" not in result


def test_query_with_none_api_name(query_endpoint):
    payload = {"query": "Tell me about job opportunities"}
    response = requests.post(query_endpoint, json=payload)
    assert response.status_code == 200
    result = response.json()
    assert "error" not in result
    print(result)


def test_query_with_invalid_api_name(query_endpoint):
    payload = {"query": "Invalid query", "api_name": "123"}
    response = requests.post(query_endpoint, json=payload)
    assert response.status_code == 500
    result = response.json()
    print(result)


def test_call_api_list_job_postings(call_api_endpoint):
    """list_job_postings API 호출 테스트"""
    payload = {
        "api_name": "list_job_postings",
        "api_spec": {
            "body": {
                "searchText": "Software Engineer",
                "corpCode": "12345",
                "recruitType": "Full-time",
            }
        },
    }
    response = requests.post(call_api_endpoint, json=payload)
    assert response.status_code == 200
    result = response.json()
    print(result)


def test_call_api_register_job_posting(call_api_endpoint):
    """register_job_posting API 호출 테스트"""
    payload = {
        "api_name": "register_job_posting",
        "api_spec": {
            "body": {
                "title": "Senior Software Engineer",
                "description": "We are looking for a senior software engineer...",
                "corpCode": 12345,
                "recruitType": "Full-time",
                "deadline": "2024-12-31",
            },
            "params": None,
            "headers": None,
        },
    }
    response = requests.post(call_api_endpoint, json=payload)
    assert response.status_code == 200
    result = response.json()
    print(result)


def test_call_api_download_resumes(call_api_endpoint):
    """download_resumes API 호출 테스트"""
    payload = {
        "api_name": "download_resumes",
        "api_spec": {"body": {"applicantIds": [1, 2, 3]}},
    }
    response = requests.post(call_api_endpoint, json=payload)
    assert response.status_code == 200
    result = response.json()
    print(result)


if __name__ == "__main__":
    pytest.main([__file__])

