from typing import Optional

from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class ErrorResponse(BaseModel):
    error_code: int
    error_name: str
    error_message: Optional[str] = None

    @classmethod
    def create_error_response(
        cls, error_code: ErrorCode, detail: Optional[str] = None
    ) -> "ErrorResponse":
        return cls(
            error_code=error_code.value,
            error_name=error_code.name,
            error_message=detail,
        )


def set_error_handlers(app: FastAPI, logger):
    @app.exception_handler(ServiceException)
    async def predefined_exception_handler(request: Request, exc: ServiceException):
        logger.error(str(exc))
        return JSONResponse(
            status_code=exc.status_code,
            content=ErrorResponse.create_error_response(
                error_code=exc.error_code, detail=exc.detail
            ).model_dump(),
        )

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        logger.error(str(exc))
        if exc.status_code < 200 or exc.status_code == 204 or exc.status_code == 304:
            return Response(status_code=exc.status_code)
        if exc.detail:
            return JSONResponse(
                status_code=exc.status_code,
                content=exc.detail
                )
        
        return JSONResponse(
            status_code=exc.status_code,
            content=ErrorResponse.create_error_response(
                error_code=ErrorCode.UNEXPECTED_ERROR
            ).model_dump(),
        )

    @app.exception_handler(Exception)
    async def base_exception_handler(request: Request, exc: Exception):
        logger.error(str(exc))
        return JSONResponse(
            status_code=500,
            content=ErrorResponse.create_error_response(
                error_code=ErrorCode.UNEXPECTED_ERROR
            ).model_dump(),
        )
