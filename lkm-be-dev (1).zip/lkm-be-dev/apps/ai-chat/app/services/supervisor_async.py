import asyncio
import json
import random
from dataclasses import dataclass
from functools import partial
from typing import AsyncGenerator, Optional

from core.log.logging import get_logging
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from services.schemas.supervisor_chat import SupervisorChatRequest
from services.supervisor_base import SupervisorBase
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()


def next_or_none(gen):
    """
    동기 제너레이터에서 next()를 호출하되,
    더 이상 요소가 없으면(StopIteration) None을 반환한다.
    더 이상 요소가 없으면(StopIteration) None을 반환한다.
    """
    try:
        return next(gen)
    except StopIteration:
        return None


@dataclass
class SupervisorASync(SupervisorBase):
    def __init__(
        self,
        *,
        db: AsyncSession,
        chat_info: SupervisorChatRequest,
        user_info: Optional[dict] = None,
    ):
        chat_info.is_stream = True
        super().__init__(db=db, chat_info=chat_info, user_info=user_info)

    async def run_async(self) -> AsyncGenerator[str, None]:
        loop = asyncio.get_running_loop()
        loop.create_task(self.run_background())
        while True:
            # run_in_executor로 'next_or_none'을 호출해,
            # StopIteration이 스레드 안에서 처리되도록 만든다.
            chunk = await loop.run_in_executor(
                None, partial(next_or_none, self._thread_generator)
            )
            if chunk is None:
                break
            yield chunk

    async def run_background(self):
        try:
            self._thread_generator.send("event: start\n\n")
            self._send_message(self._ai_message_id, "id")
            await self.run()
        except Exception as e:
            self._thread_generator.send(f"event: error: {str(e)}\n\n")
            logger.error(f"Error in background task: {e}")
        finally:
            self._thread_generator.send("event: end\n\n")
            self._thread_generator.close()

    async def execute(self):
        ai_content = ""
        buffer = ""
        content_metadata = []
        state = {}

        # 실시간 스트리밍 처리
        async for chunk in self._response.content.iter_any():
            try:
                decoded_string = chunk.decode("utf-8")
                buffer += decoded_string

                # 즉시 처리 - JSON 객체가 완성되는 즉시 전송
                buffer, ai_content, state = await self._process_buffer_realtime(
                    buffer, content_metadata, ai_content, state
                )

            except Exception as e:
                logger.error(f"Error processing chunk: {e}")
                continue

        # 버퍼에 남은 데이터 최종 처리
        if buffer.strip():
            await self._process_final_buffer(
                buffer, content_metadata, ai_content, state
            )

        try:
            # 마지막 메시지 생성
            await self._create_message(
                id=self._ai_message_id,
                parent_id=self._user_message.id,
                chat_id=self._chat_info.chat_id,
                task_agent_id=self._chat_info.task_agent_id,
                expert_agent_id=self._chat_info.expert_agent_id,
                role="assistant",
                # todo 최종 메시지 생성은 현재 content_metadata가 겹치므로 제거함.
                content="",
                content_metadata=json.dumps(content_metadata, ensure_ascii=False),
            )

            # await self._create_state(
            #     message_id=self._ai_message_id,
            #     state=state,
            # )
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Error processing response: {str(e)}",
            )

    async def _process_buffer_realtime(
        self, buffer: str, content_metadata: list, ai_content: str, state: dict
    ) -> tuple[str, str, dict]:
        """실시간으로 버퍼를 처리하여 완성된 JSON을 즉시 전송"""
        processed_length = 0

        while True:
            # { 찾기
            json_start = buffer.find("{", processed_length)
            if json_start == -1:
                break

            # 매칭되는 } 찾기
            brace_count = 0
            pos = json_start

            while pos < len(buffer):
                if buffer[pos] == "{":
                    brace_count += 1
                elif buffer[pos] == "}":
                    brace_count -= 1
                    if brace_count == 0:
                        # 완성된 JSON 발견
                        json_str = buffer[json_start : pos + 1]

                        # 즉시 처리 및 전송
                        success, ai_content, state = (
                            await self._process_and_send_immediately(
                                json_str, content_metadata, ai_content, state
                            )
                        )

                        if success:
                            await asyncio.sleep(random.uniform(1.0, 2.0))
                            processed_length = pos + 1
                        else:
                            processed_length = json_start + 1
                        break
                pos += 1
            else:
                # 완성되지 않은 JSON - 더 많은 데이터 필요
                break

        # 처리된 부분 제거
        return buffer[processed_length:], ai_content, state

    async def _process_final_buffer(
        self, buffer: str, content_metadata: list, ai_content: str, state: dict
    ):
        """버퍼 마지막 처리 - 남은 JSON들을 모두 처리"""
        # 여러 JSON이 이어져 있을 수 있으므로 모든 가능성 시도
        pos = 0
        while pos < len(buffer):
            json_start = buffer.find("{", pos)
            if json_start == -1:
                break

            # 가장 긴 유효한 JSON 찾기
            for end_pos in range(len(buffer), json_start, -1):
                if buffer[end_pos - 1] == "}":
                    candidate = buffer[json_start:end_pos]
                    if self._is_valid_json_structure(candidate):
                        success, ai_content, state = (
                            await self._process_and_send_immediately(
                                candidate, content_metadata, ai_content, state
                            )
                        )
                        if success:
                            await asyncio.sleep(random.uniform(1.5, 3.0))
                            pos = end_pos
                            break
            else:
                pos = json_start + 1

    def _is_valid_json_structure(self, text: str) -> bool:
        """JSON 구조가 유효한지 빠르게 체크"""
        return text.count("{") == text.count("}") and text.count("{") > 0

    async def _process_and_send_immediately(
        self, json_str: str, content_metadata: list, ai_content: str, state: dict
    ) -> tuple[bool, str, dict]:
        """JSON을 파싱하고 유효한 경우 즉시 전송"""
        try:
            data = json.loads(json_str)

            # 데이터 추출 및 정리
            type_value = data.get("type", "").strip()
            content = data.get("content", "")
            description = data.get("description", "").strip()
            key = data.get("key", "").strip()
            title = data.get("title", "").strip()

            # 강력한 필터링
            if not self._is_valid_message(type_value, content, data):
                return True, ai_content, state  # 스킵하지만 성공으로 처리

            # 콘텐츠 누적 (token 타입)
            if type_value == "token" and content:
                ai_content += content

            # todo state dict 구조 변경으로 인해 주석처리 추후 저장하는 과정 수정 필요
            # # 상태 업데이트
            # if data.get("state"):
            #     state_data = data.get("state")
            #     if isinstance(state_data, dict):
            #         state.update(state_data)
            #     else:
            #         logger.warning(
            #             f"상태 데이터가 dictionary가 아닙니다: {type(state_data)} - {state_data}"
            #         )

            # 메타데이터 저장
            content_metadata.append(
                {
                    "type": type_value,
                    "content": content,
                    "description": description,
                    "key": key,
                    "title": title,
                }
            )

            # 즉시 프론트엔드로 전송

            self._send_message(content, type_value, description, key, title)

            # 중요 메시지 로깅
            if type_value in [
                "END",
                "START",
                "ROUTING",
                "WORKFLOW",
                "STEP_START",
                "STEP_END",
            ]:
                logger.info(f"[{type_value}] 즉시 전송됨: {content[:30]}...")

            if type_value == "END":
                logger.info(f" END 메시지 전송 완료: {json_str}")

            return True, ai_content, state

        except json.JSONDecodeError:
            logger.debug(f"JSON 파싱 실패 (스킵): {json_str[:50]}...")
            return False, ai_content, state
        except Exception as e:
            logger.error(f"메시지 처리 오류: {e}")
            return False, ai_content, state

    def _is_valid_message(self, type_value: str, content: str, data: dict) -> bool:
        """메시지가 전송할 가치가 있는지 판단"""

        # 완전히 빈 메시지 제외
        if not type_value and not content:
            return False

        # type만 있고 content가 비어있는 무의미한 메시지들 필터링
        meaningless_types = ["id"]  # id 타입은 무시
        if type_value in meaningless_types:
            return False

        # 빈 content지만 중요한 타입들은 허용
        important_types = [
            "END",
            "START",
            "ROUTING",
            "WORKFLOW",
            "STEP_START",
            "STEP_END",
        ]
        if type_value in important_types:
            return True

        # content가 있는 메시지는 허용
        if content:
            return True

        # 기타 유용한 메타데이터가 있는 경우 허용
        if data.get("description") or data.get("key") or data.get("title"):
            return True

        return False


class SupervisorGeneralChatASync(SupervisorASync):
    """슈퍼 에이전트 채팅용 SupervisorASync"""

    # def _determine_chat_type(self) -> str:
    #     return "SuperAgentChat"

    async def async_init(self):
        """초기화 후 chat_type 업데이트"""
        await super().async_init()
        # await self._update_chat_type()


class SupervisorExpertChatASync(SupervisorASync):
    """에이전트 채팅용 SupervisorASync"""

    # def _determine_chat_type(self) -> str:
    #     return "ExpertAgentChat"

    async def async_init(self):
        """초기화 후 chat_type 업데이트"""
        await super().async_init()
        # await self._update_chat_type()


# class SupervisorAIChatASync(SupervisorASync):
#     """AI 채팅용 SupervisorASync"""

# def _determine_chat_type(self) -> str:
#     return "AIChat"
