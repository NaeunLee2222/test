from typing import List

from core.config import get_setting
from core.log.logging import get_logging
from core.security import UserInfo
from database.crud.user import CRUDOrganization, CRUDTeam, CRUDUser
from database.models.user import Organization, Team, User
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from services.schemas.user import (
    UserCreate,
    UserCreateRequest,
    UserPasswordUpdate,
    UserUpdate,
    UserUpdateRequest,
)
from sqlalchemy.ext.asyncio import AsyncSession

settings = get_setting()
logger = get_logging()


class UserService:
    def __init__(self):
        self.crud_user = CRUDUser()
        self.crud_organization = CRUDOrganization()
        self.crud_team = CRUDTeam()

    # admin 권한 체크
    async def check_admin_permission(self, current_user: UserInfo):
        if current_user.role != "admin":
            raise ServiceException(
                status_code=403,
                error_code=ErrorCode.ACCESS_DENIED,
                detail="관리자만 사용자를 생성할 수 있습니다.",
            )
        return True

    async def create_user(
        self,
        db: AsyncSession,
        user_data: UserCreateRequest,
        current_user: UserInfo,
    ):
        """
        서비스 레이어: 새로운 사용자 생성
        - 관리자만 생성 가능
        - 이메일 중복 체크
        """
        # 권한 체크
        if current_user.role != "admin":
            raise ServiceException(
                status_code=403,
                error_code=ErrorCode.ACCESS_DENIED,
                detail="관리자만 사용자를 생성할 수 있습니다.",
            )

        # 이메일 중복 체크
        existing_user = await self.crud_user.get_user_by_email(db, user_data.email)
        if existing_user:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.DUPLICATE_ENTITY,
                detail="이미 존재하는 이메일입니다.",
            )

        # UserCreate 인스턴스 생성
        user_create = UserCreate(
            email=user_data.email,
            password=user_data.password,
            username=user_data.username,
            organization_id=user_data.organization_id,
            team_id=user_data.team_id,
            role=user_data.role,
            is_activated=user_data.is_activated,
        )

        # 사용자 생성
        user = await self.crud_user.create_user(db, user_create)
        return user

    async def get_user_by_user_id(self, db: AsyncSession, user_id: int) -> User:
        user = await self.crud_user.get_user_by_user_id(db, user_id)
        return user

    async def get_user_by_email(self, db: AsyncSession, email: str) -> User:
        user = await self.crud_user.get_user_by_email(db, email)
        return user

    async def get_multi_filtered_user(
        self,
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
        search: str = None,
        is_activated: bool = None,
        role: str = None,
        order: str = None,
    ) -> tuple[List[User], int]:
        """
        사용자 목록을 필터링하여 조회합니다.

        Args:
            db: 데이터베이스 세션
            skip: 건너뛸 레코드 수
            limit: 조회할 레코드 수
            search: 검색어 (이메일, 사용자명)
            is_activated: 활성화 상태 필터
            role: 역할 필터
            order: 정렬 방식

        Returns:
            tuple: (사용자 목록, 전체 개수)
        """
        # 비즈니스 로직: 파라미터 검증
        if limit > 100:
            limit = 100
        if skip < 0:
            skip = 0

        # 비즈니스 로직: 검색어 전처리
        if search:
            search = search.strip()
            if len(search) < 2:
                search = None

        # CRUD 호출
        users, total = await self.crud_user.get_multi_filtered_user(
            db,
            skip=skip,
            limit=limit,
            search=search,
            is_activated=is_activated,
            role=role,
            order=order,
        )

        return users, total

    async def update_user(
        self, id: int, db: AsyncSession, user_data: UserUpdateRequest
    ) -> User:
        existing_user = await self.crud_user.get_user_by_user_id(db, id)
        if not existing_user:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="사용자를 찾을 수 없습니다.",
            )

        original_user = await self.crud_user.get_user_by_email(db, user_data.email)
        if original_user.email != user_data.email:
            existing_user = await self.crud_user.get_user_by_email(db, user_data.email)
            if existing_user:
                raise ServiceException(
                    status_code=400,
                    error_code=ErrorCode.DUPLICATE_ENTITY,
                    detail="이미 존재하는 이메일입니다.",
                )
        user_update = UserUpdate(
            id=user_data.id,
            email=user_data.email,
            username=user_data.username,
            organization_id=user_data.organization_id,
            team_id=user_data.team_id,
            role=user_data.role,
            is_activated=user_data.is_activated,
        )
        updated_user = await self.crud_user.update_user(db, user_update)

        is_password_updated = user_data.password is not None
        if is_password_updated:
            user_password_update = UserPasswordUpdate(
                id=user_data.id, password=user_data.password
            )
            await self.crud_user.update_user_password(db, user_password_update)

        return updated_user

    async def delete_user(self, db: AsyncSession, user_id: int) -> None:
        existing_user = await self.crud_user.get_user_by_user_id(db, user_id)
        if not existing_user:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="사용자를 찾을 수 없습니다.",
            )
        await self.crud_user.delete(db=db, id=existing_user.id)

    async def get_company_info(
        self, db: AsyncSession, org_id: int, team_id: int
    ) -> tuple[str, str]:
        organization: Organization = await self.crud_organization.get(db, org_id)
        team: Team = await self.crud_team.get(db, team_id)
        return organization.name, team.name
