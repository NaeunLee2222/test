from typing import Optional, Union
from database.crud.user import CRUDUserMemory, CRUDUserPreference, CRUDUser
from database.crud.expert_agent import APIExpertAgent
from sqlalchemy.ext.asyncio import AsyncSession
from services.schemas.user import (
    UserMemory,
    UserMemoryRequest,
    UserMemoryUpdateRequest,
    UserPreference,
)
from core.log.logging import get_logging
from error.error_code import ErrorCode
from error.service_exception import ServiceException

logger = get_logging()


class UserPreferenceService:
    def __init__(self):
        self.crud_user_preference = CRUDUserPreference()
        self.crud_user = CRUDUser()
        self.api_expert_agent = APIExpertAgent()

    async def user_agent_validation(
        self,
        user_id: Optional[int | None],
        agent_id: Optional[int | None],
        db: AsyncSession,
    ):
        """Optimized validation with single database calls and proper error handling"""
        try:
            # Validate user if provided
            if user_id:
                user = await self.crud_user.get_user_by_user_id(db=db, user_id=user_id)
                if not user:
                    logger.error(f"User not found with user_id: {user_id}")
                    raise ServiceException(
                        status_code=404,
                        error_code=ErrorCode.RESOURCE_NOT_FOUND,
                        detail=f"User not found with user_id: {user_id}",
                    )

            # Validate agent if provided (external API call)
            if agent_id:
                agent = await self.api_expert_agent.get_expert_agent_by_id(
                    agent_id=agent_id
                )
                if not agent:
                    logger.error(f"Agent not found with agent_id: {agent_id}")
                    raise ServiceException(
                        status_code=404,
                        error_code=ErrorCode.RESOURCE_NOT_FOUND,
                        detail=f"Agent not found with agent_id: {agent_id}",
                    )
        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Validation failed, {str(e)}",
            )

    async def get_user_preference(
        self, user_id: int, agent_id: int, db: AsyncSession
    ) -> Union[UserPreference, dict]:
        """Optimized preference retrieval with single database call"""
        try:
            # Validate user and agent
            await self.user_agent_validation(user_id=user_id, agent_id=agent_id, db=db)

            # Single database call to get preference
            user_preference = await self.crud_user_preference.get_user_preference(
                db=db, user_id=user_id, agent_id=agent_id
            )

            if not user_preference:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"User preference not found with user_id: {user_id} and agent_id: {agent_id}",
                )

            return UserPreference.model_validate(user_preference)
        except ServiceException as se:
            raise se
        except Exception as e:
            logger.error(f"Error getting user preference: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get user preference, {str(e)}",
            )

    async def create_user_preference(
        self, user_id: int, agent_id: int, db: AsyncSession
    ) -> Union[UserPreference, dict]:
        try:
            # Validate user exists
            user = await self.crud_user.get_user_by_user_id(db=db, user_id=user_id)
            if not user:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"User not found with user_id: {user_id}",
                )

            # Check for existing preference
            existing_user_preference = (
                await self.crud_user_preference.get_user_preference(
                    db=db, user_id=user_id, agent_id=agent_id
                )
            )

            if existing_user_preference:
                raise ServiceException(
                    status_code=400,
                    error_code=ErrorCode.DUPLICATE_ENTITY,
                    detail=f"User preference already exists with user_id: {user_id} and agent_id: {agent_id}",
                )

            # Create new preference
            user_preference = await self.crud_user_preference.create_user_preference(
                db=db, user_id=user_id, agent_id=agent_id
            )
            return UserPreference.model_validate(user_preference)
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to create user preference, {str(e)}",
            )

    async def update_user_preference(
        self, user_preference: UserPreference, db: AsyncSession
    ) -> Union[UserPreference, dict]:
        """Optimized preference update with proper transaction handling"""
        try:
            # Validate user and agent
            await self.user_agent_validation(
                user_id=user_preference.user_id if user_preference.user_id else None,
                agent_id=user_preference.agent_id if user_preference.agent_id else None,
                db=db,
            )

            # Get existing preference
            existing_user_preference = (
                await self.crud_user_preference.get_user_preference_by_id(
                    db=db, user_preference_id=user_preference.id
                )
            )
            if not existing_user_preference:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"User preference not found with user_preference_id: {user_preference.id}",
                )

            # Validate user ID match
            if bool(
                user_preference.user_id
                and existing_user_preference.user_id != user_preference.user_id
            ):
                raise ServiceException(
                    status_code=401,
                    error_code=ErrorCode.INVALID_AUTH,
                    detail=f"User id is not match. user_id: {user_preference.user_id}",
                )

            # Validate agent ID match
            if bool(
                user_preference.agent_id
                and existing_user_preference.agent_id != user_preference.agent_id
            ):
                raise ServiceException(
                    status_code=401,
                    error_code=ErrorCode.INVALID_AUTH,
                    detail=f"Agent id is not match. agent_id: {user_preference.agent_id}",
                )

            # Update preference
            updated_preference = await self.crud_user_preference.update_user_preference(
                db=db, user_preference=user_preference
            )
            return UserPreference.model_validate(updated_preference)
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to update user preference, {str(e)}",
            )

    async def delete_user_preference(
        self, user_id: int, agent_id: int, db: AsyncSession
    ):
        """Optimized preference deletion with proper transaction handling"""
        try:
            result = await self.crud_user_preference.delete_user_preference(
                db=db, user_id=user_id, agent_id=agent_id
            )
            if not result:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"User preference not found with user_id: {user_id} and agent_id: {agent_id}",
                )
            return True
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to delete user preference, {str(e)}",
            )


class UserMemoryService:
    def __init__(self):
        self.crud_user_memory = CRUDUserMemory()
        self.crud_user = CRUDUser()
        self.api_expert_agent = APIExpertAgent()

    async def user_agent_validation(
        self, user_id: int, agent_id: int, db: AsyncSession
    ):
        try:
            # Validate user exists
            user = await self.crud_user.get_user_by_user_id(db=db, user_id=user_id)
            if not user:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"User not found with user_id: {user_id}",
                )

            # Validate agent exists (external API call)
            agent = await self.api_expert_agent.get_expert_agent_by_id(
                agent_id=agent_id
            )
            if not agent:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"Agent not found with agent_id: {agent_id}",
                )
            return False
        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Validation failed, {str(e)}",
            )

    async def get_memories_by_user_agent(
        self, user_id: int, agent_id: int, db: AsyncSession
    ):
        try:
            # Validate user and agent
            await self.user_agent_validation(user_id=user_id, agent_id=agent_id, db=db)

            # Single database call to get memories
            user_memories = await self.crud_user_memory.get_user_memory(
                db=db, user_id=user_id, agent_id=agent_id
            )

            return [
                UserMemory.model_validate(user_memory) for user_memory in user_memories
            ]
        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get user memories, {str(e)}",
            )

    async def create_user_memory(
        self, user_memory_request: UserMemoryRequest, db: AsyncSession
    ):
        """Optimized memory creation with proper transaction handling"""
        try:
            # Validate user and agent
            await self.user_agent_validation(
                user_id=user_memory_request.user_id,
                agent_id=user_memory_request.agent_id,
                db=db,
            )

            # Create memory
            user_memory = await self.crud_user_memory.create_user_memory(
                db=db,
                user_id=user_memory_request.user_id,
                agent_id=user_memory_request.agent_id,
                contents=user_memory_request.contents,
            )

            return UserMemory.model_validate(user_memory)
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to create user memory, {str(e)}",
            )

    async def update_user_memory(
        self,
        user_memory_id: int,
        user_memory_update_request: UserMemoryUpdateRequest,
        db: AsyncSession,
    ) -> Union[UserMemory, dict]:
        """Optimized memory update with proper transaction handling"""
        try:
            # Get existing memory
            existing_memory = await self.crud_user_memory.get_user_memory_by_id(
                db=db, user_memory_id=user_memory_id
            )
            if not existing_memory:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"User memory not found with user_memory_id: {user_memory_id}",
                )

            # Update memory
            updated_memory = await self.crud_user_memory.update_user_memory(
                db=db,
                user_memory_id=user_memory_id,
                user_memory=user_memory_update_request,
            )

            return UserMemory.model_validate(updated_memory)
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to update user memory, {str(e)}",
            )

    async def delete_user_memory(self, user_memory_id: int, db: AsyncSession):
        """Optimized memory deletion with proper transaction handling"""
        try:
            # Get existing memory
            existing_memory = await self.crud_user_memory.get_user_memory_by_id(
                db=db, user_memory_id=user_memory_id
            )
            if not existing_memory:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"User memory not found with user_memory_id: {user_memory_id}",
                )

            # Delete memory
            await self.crud_user_memory.delete_user_memory(
                db=db, user_memory_id=user_memory_id
            )
            return True
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to delete user memory, {str(e)}",
            )

    async def delete_all_user_memory(
        self, user_id: int, agent_id: int, db: AsyncSession
    ):
        """Optimized bulk memory deletion with proper transaction handling"""
        try:

            # Delete all memories
            await self.crud_user_memory.delete_all_user_memory(
                db=db, user_id=user_id, agent_id=agent_id
            )

            return True
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to delete all user memories, {str(e)}",
            )
