import json
from abc import abstractmethod
from dataclasses import dataclass
from typing import Any, Optional

from agents.supervisor.supervisor import get_graph
from aiohttp import ClientResponse, ClientSession, ClientTimeout
from core.context import get_transaction_id
from core.log.logging import get_logging
from core.utils.stream import ThreadedGenerator
from database.crud.chat import CRUDChat
from database.crud.chat_message import CRUDChatMessage
from database.crud.chat_task_agent_state import (
    create_chat_task_agent_state,
)
from database.crud.task_agent import get_task_agents
from database.crud.user import CRUDUser
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import HTTPException
from services.schemas.auth import UserInfo
from services.schemas.chat import ChatCreateWithId
from services.schemas.chat_task_agent_state import ChatTaskAgentStateCreate
from services.schemas.supervisor_chat import (
    SupervisorChatMessage,
    SupervisorChatRequest,
    SupervisorInput,
)

# from services.user import get_or_create_user
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()
crud_chat = CRUDChat()
crud_chat_message = CRUDChatMessage()
crud_user = CRUDUser()


async def get_user_profile(user_id, db: AsyncSession):
    db_user_info = await crud_user.get_user_by_user_id(db, user_id)
    try:
        return db_user_info.profile
    except:
        print("DB 조회중 에러발생")


@dataclass
class SupervisorBase:
    AIOHTTP_CLIENT_TIMEOUT = 1200

    db: AsyncSession
    _state: dict
    _agent_url: str
    _task_agent_id: int
    _chat_info: SupervisorChatRequest
    _supervisor_input: SupervisorInput
    _response: ClientResponse
    _ai_message_id: str
    _user_message: SupervisorChatMessage
    _thread_generator: ThreadedGenerator
    _graph: Any  # StateGraph 타입을 나중에 명확히 지정

    def __init__(
        self,
        *,
        db: AsyncSession,
        chat_info: SupervisorChatRequest,
        user_info: Optional[UserInfo] = None,
    ):
        self.db = db
        self._chat_info = chat_info
        self._user_info = user_info or UserInfo(
            user_id="5",
            email="user@skax.com",
            username="홍길동",
            org_name="SKAX",
            team_name="AI Team",
            role="Admin",
        )
        self._supervisor_input = SupervisorInput(
            model="Supervisor", messages=chat_info.messages, stream=chat_info.is_stream
        )
        self._thread_generator = ThreadedGenerator()
        self._graph = None  # 초기화 시 그래프를 None으로 설정
        self._response = None
        self._state = {}
        self._task_agent_id = chat_info.task_agent_id
        self._expert_agent_id = chat_info.expert_agent_id

    async def async_init(self):
        # self.profile = await get_user_profile(
        #     user_id=self._user_info.user_id, db=self.db
        # )
        # self._user_info.profile = self.profile
        self._user_message = self._chat_info.messages[-1]

        self._ai_message_id = self._chat_info.child_id
        logger.info(f"create chat, chat_id: {self._chat_info.chat_id}")
        await self._create_chat()
        await self.__select_agent(self._chat_info.chat_id)
        await self._get_state()
        logger.info("#### get state ####")
        logger.info(self._state)
        await self._create_message(
            id=self._user_message.id,
            parent_id=self._user_message.parent_id,
            chat_id=self._chat_info.chat_id,
            task_agent_id=self._task_agent_id,
            role=self._user_message.role,
            type="chat",
            content=self._user_message.content,
            content_metadata="",
        )

    def _send_message(
        self,
        content: str,
        type="token",
        description="",
        key="",
        title="",
    ):
        data = {
            "type": type,
            "content": content,
            "description": description,
            "key": key,
            "id": self._ai_message_id,
            "title": title,
        }
        self._thread_generator.send(
            f"event: data\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
        )

    async def _create_chat(self):
        # 채팅 생성 (기본 chat_type으로 생성)
        user_info = self._user_info
        title = (
            self._chat_info.messages[0].content[:30]
            if self._chat_info.messages
            else f"{user_info.username}의 채팅"
        )
        # 기본 chat_type으로 채팅 생성
        chat_data = ChatCreateWithId(
            id=self._chat_info.chat_id,
            user_id=int(self._user_info.user_id),
            title=title,
            model="",
            config={},
            # chat_type="AIChat",  # 기본값
        )
        await crud_chat.get_or_create_chat(db=self.db, chat_data=chat_data)

    # async def _update_chat_type(self):
    #     """채팅 타입을 업데이트합니다."""
    #     chat_type = self._determine_chat_type()
    #     await crud_chat.update_chat_type(
    #         db=self.db, chat_id=self._chat_info.chat_id, chat_type=chat_type
    #     )

    # def _determine_chat_type(self) -> str:
    #     """
    #     엔드포인트별로 적절한 chat_type을 결정합니다.
    #     기본값은 AIChat입니다.
    #     """
    #     return "AIChat"

    async def _get_state(self):
        # AI 메시지 UUID가 없는 경우 빈 리스트 할당
        if not self._ai_message_id:
            self._state["messages"] = []
        else:
            # 최신 메시지를 모두 가져오기
            all_messages = await crud_chat_message.get_chat_messages_by_chat_id(
                db=self.db,
                chat_id=self._chat_info.chat_id,
                skip=0,  # 모든 메시지를 가져오도록 설정
            )

            # chat_message_uuid 리스트 생성
            message_ids = [msg.id for msg in all_messages]

            # state 가 존재하는 메시지만 필터링
            valid_states = []

            # todo state 현재 사용하지 않도록 주석처리
            # for id in reversed(message_ids):  # 최신 메시지부터 탐색
            #     if len(valid_states) >= 7:  # 최대 5개만 저장
            #         break
            #     state_from_db = await get_chat_task_agent_state(
            #         db=self.db, chat_message_id=id
            #     )
            #     if (
            #         state_from_db and state_from_db.state
            #     ):  # state가 존재하는 경우만 추가
            #         valid_states.append(state_from_db.state)

            # # 최신 메시지부터 추가했으므로, 가장 오래된 것이 0번이 되도록 순서 뒤집기
            # valid_states.reverse()

            # state 저장
            self._state["messages"] = valid_states

        # 기존 safety 관련 정보도 저장
        self._state["safety"] = self.safety
        self._state["safety_message"] = self.safety_message

    async def _create_state(self, message_id: str, state: dict):
        state_info = ChatTaskAgentStateCreate(
            chat_message_id=message_id,
            # todo 결과 다 넣을 수 있도록 추후 수정
            state=state,
        )

        await create_chat_task_agent_state(
            db=self.db,
            state=state_info,
        )

    async def _create_message(
        self,
        *,
        id: str,
        parent_id: str,
        chat_id: str,
        task_agent_id: Optional[int] = None,
        expert_agent_id: Optional[int] = None,
        role: str = "ai",
        type: str = "chat",
        content: str,
        content_metadata: str,
    ):
        # ChatMessageCreateRequest 스키마에 맞게 필드 수정
        message_dict = {
            "id": id,
            "chat_id": chat_id,
            "parent_id": parent_id,  # parent_uuid를 parent_id로 매핑
            "content": content,
            "role": role,
            "content_metadata": content_metadata if content_metadata != "" else None,
            "attachment": None,
        }

        await crud_chat_message.create(db=self.db, obj_in=message_dict)

    async def __select_agent(self, chat_id: str):
        task_agents = await get_task_agents(db=self.db)
        logger.info(f"task_agents: {task_agents}")
        logger.info(f"task_agents[0].task_agent_name: {task_agents[0].task_agent_name}")
        # self._agent_url = task_agents[0].task_agent_url

        # Task agent 선택을 위한 state 구성
        task_choice_state = {
            "content": self._user_message.content,
            "messages_list": [
                message.model_dump() for message in self._chat_info.messages
            ],
            "former_ai_answer": None,  # 기본값 설정
            "chat_id": chat_id,
            "task_agents": [
                {
                    "task_agent_name": agent.task_agent_name,
                    "task_agent_url": agent.task_agent_url,
                    "description": agent.description,
                }
                for agent in task_agents
            ],
        }

        # 이전 task agent 응답 가져오기
        if len(self._chat_info.messages) >= 2:
            try:
                task_choice_state["former_ai_answer"] = self._chat_info.messages[
                    -2
                ].content
            except IndexError:
                pass

        self._graph = get_graph(task_choice_state)

        # Graph 실행 및 결과 확인
        result = None
        for output in self._graph.stream(task_choice_state):
            if "__end__" not in output:
                result = output

        if not result:
            raise HTTPException(status_code=404, detail="No valid response generated.")

        # 선택된 task agent URL 설정
        self.safety = result["router"]["safety"]
        self.safety_message = result["router"]["safety_message"]
        self._agent_url = result["router"]["next"]

        logger.info("-" * 100)
        logger.info(f"selected agent : {self._agent_url}")
        if not self._agent_url or self._agent_url == "None":
            # raise HTTPException(status_code=404, detail="No task agent selected.")
            self._agent_url = task_agents[0].task_agent_url

        # selected_task_agent = next(
        #     (agent for agent in task_agents if agent.task_agent_url == self._agent_url),
        #     None,
        # )
        # self._task_agent_id = selected_task_agent.id

    async def run(self):
        async with ClientSession(
            trust_env=True,
            timeout=ClientTimeout(total=self.AIOHTTP_CLIENT_TIMEOUT),
        ) as session:
            try:
                async with session.request(
                    method="POST",
                    url=f"{self._agent_url}",
                    json={
                        "input_data": [
                            message.dict()
                            for message in self._supervisor_input.messages
                        ],
                        "stream": self._supervisor_input.stream,
                        "state": self._state,
                        "user_info": self._user_info.model_dump(),
                        "chat_id": self._chat_info.chat_id,
                        "expert_agent_id": self._expert_agent_id,
                        "canvas": self._chat_info.canvas,
                    },
                    headers={
                        "Content-Type": "application/json",
                        "x-transaction-id": get_transaction_id() or "no-transaction-id",
                    },
                ) as response:
                    logger.info(
                        f"Request sent and received from {self._agent_url} - Status: {response.status}, Transaction ID: {get_transaction_id()}"
                    )
                    self._response = response
                    return await self.execute()
            except Exception as e:
                raise ServiceException(
                    status_code=500,
                    error_code=ErrorCode.UNEXPECTED_ERROR,
                    detail=(f"Failed to process Task Agent request/response: {str(e)}"),
                )

    @abstractmethod
    async def execute(self):
        pass
