from datetime import datetime

from database.crud.documents import CRUDDocuments
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from services.schemas.documents import DocCreate, DocState
from sqlalchemy.ext.asyncio import AsyncSession

crud_docs = CRUDDocuments()


async def create_document(db: AsyncSession, *, doc_data: DocCreate):
    try:
        return await crud_docs.create(db, doc_data.model_dump())
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to create document, {str(e)}",
        )


async def update_document_state(
    db: AsyncSession, *, doc_id: int, state: str = "UPLOAD"
):
    try:
        # 1. document 가져오기
        db_docs = await crud_docs.get(db, doc_id)
        if not db_docs:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Document with id {doc_id} not found",
            )

        # 2. state, updated_at 업데이트
        update_data = {"state": state, "updated_at": datetime.utcnow()}

        # 3. 업데이트 수행
        updated_chat = await crud_docs.update(db, db_obj=db_docs, obj_in=update_data)
        return updated_chat
    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to update document state, {str(e)}",
        )


async def get_document_with_chatid(db: AsyncSession, *, chat_id: str, doc_id: int):
    try:
        db_docs = await crud_docs.get_document_with_chatid(
            db=db, chat_id=chat_id, doc_id=doc_id
        )
        if not db_docs:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Document with id {doc_id} not found",
            )

        doc_state = DocState(
            doc_id=db_docs.id,
            original_filename=db_docs.original_filename,
            state=db_docs.state,
        )
        return doc_state

    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get document state, {str(e)}",
        )
