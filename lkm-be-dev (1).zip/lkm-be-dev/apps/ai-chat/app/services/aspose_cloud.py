import os
import shutil
import tempfile

import asposewordscloud
import asposewordscloud.models.requests
from asposecellscloud.apis.cells_api import CellsApi
from asposecellscloud.models import *
from asposecellscloud.requests import *
from core.config import get_setting
from core.log.logging import get_logging
from database.crud.chat_canvas import CRUDCanvas
from database.models.chat import ChatCanvas
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

settings = get_setting()
logger = get_logging()


class AsposeCloudService:
    def __init__(self):
        self.client_id = settings.ASPOSE_CLOUD_CLIENT_ID
        self.client_secret = settings.ASPOSE_CLOUD_CLIENT_SECRET
        self.canvas_crud = CRUDCanvas()
        self.words_api = asposewordscloud.WordsApi(self.client_id, self.client_secret)
        self.words_api.api_client.rest_client.pool_manager.connection_pool_kw[
            "cert_reqs"
        ] = "CERT_NONE"

    async def _get_canvas(self, db: AsyncSession, canvas_uuid: str):
        canvas = await self.canvas_crud.get_canvas(db, canvas_uuid)
        if not canvas:
            raise HTTPException(status_code=404, detail="Canvas not found")
        if canvas.file_extension != "html":
            raise HTTPException(status_code=400, detail="Canvas is not HTML")
        return canvas

    async def _get_temp_file(self, canvas: ChatCanvas):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".html") as temp_file:
            temp_file.write(canvas.content.encode("utf-8"))
            return temp_file.name

    async def convert_html_to_pdf(self, db: AsyncSession, canvas_uuid: str):
        canvas = await self._get_canvas(db, canvas_uuid)
        temp_file_path = await self._get_temp_file(canvas)

        try:
            request_html = open(temp_file_path, "rb")
            request_pdf = asposewordscloud.models.requests.ConvertDocumentRequest(
                document=request_html, format="pdf"
            )
            response = self.words_api.convert_document(request_pdf)
            return response

        except Exception as e:
            logger.error(f"Error converting HTML to PDF: {e}")
            raise HTTPException(
                status_code=500, detail="Error converting HTML to PDF"
            ) from e

    async def convert_html_to_docx(self, db: AsyncSession, canvas_uuid: str):
        canvas = await self._get_canvas(db, canvas_uuid)
        temp_file_path = await self._get_temp_file(canvas)
        request_html = open(temp_file_path, "rb")
        request_docx = asposewordscloud.models.requests.ConvertDocumentRequest(
            document=request_html, format="docx"
        )
        response = self.words_api.convert_document(request_docx)
        return response

    async def convert_html_to_xlsx(self, db: AsyncSession, canvas_uuid: str):
        canvas = await self._get_canvas(db, canvas_uuid)
        temp_file_path = await self._get_temp_file(canvas)
        temp_xlsx_path = None

        try:
            cells_api = CellsApi(
                self.client_id, self.client_secret, "v3.0", "https://api.aspose.cloud"
            )

            request = PutConvertWorkbookRequest(temp_file_path, format="xlsx")
            kwargs = {"_return_http_data_only": True, "_preload_content": True}
            response = cells_api.put_convert_workbook_with_http_info(request, **kwargs)

            # Create a temporary file to store the XLSX content
            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as temp_xlsx:
                temp_xlsx_path = temp_xlsx.name
                shutil.copy2(response, temp_xlsx.name)
                with open(temp_xlsx.name, "rb") as f:
                    content = f.read()

            return content

        except Exception as e:
            logger.error(f"Error converting HTML to XLSX: {e}")
            raise HTTPException(
                status_code=500, detail="Error converting HTML to XLSX"
            ) from e
        finally:
            # Clean up temporary files
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            if temp_xlsx_path and os.path.exists(temp_xlsx_path):
                os.remove(temp_xlsx_path)
