from dataclasses import dataclass
from typing import Optional

from error.error_code import ErrorCode
from error.service_exception import ServiceException
from services.schemas.supervisor_chat import (
    SupervisorChatMessage,
    SupervisorChatRequest,
)
from services.supervisor_base import SupervisorBase
from sqlalchemy.ext.asyncio import AsyncSession


@dataclass
class SupervisorSync(SupervisorBase):
    def __init__(
        self,
        *,
        db: AsyncSession,
        chat_info: SupervisorChatRequest,
        user_info: Optional[dict],
    ):
        super().__init__(db=db, chat_info=chat_info, user_info=user_info)

    async def execute(self):
        try:
            data = None
            data = await self._response.json()
            view_messages = list(data[0].values())[0]["view_messages"]
            response_content = ""
            for dic in view_messages:
                response_content += (
                    f"**{list(dic.keys())[0]}**:\n{list(dic.values())[0]}\n\n"
                )

            await self._create_message(
                id=self._ai_message_id,
                parent_id=self._user_message.id,
                chat_id=self._chat_info.chat_id,
                task_agent_id=self._task_agent_id,
                expert_agent_id=self._expert_agent_id,
                role="assistant",
                type="chat",
                content=response_content,
                content_metadata="",
            )

            # await self._create_state(
            #     message_id=self._ai_message_id,
            #     state=list(data[-1].values())[0],
            # )

            new_chat_message = SupervisorChatMessage(
                id=self._ai_message_id,
                role="assistant",
                content=response_content,
                parent_id=self._user_message.id,
            )
            self._chat_info.messages.append(new_chat_message)

            return {
                "chat_id": self._chat_info.chat_id,
                "uuid": self._ai_message_id,
                "messages": [message.dict() for message in self._chat_info.messages],
            }
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Error processing response: {str(e)}",
            )


class SupervisorGeneralChatSync(SupervisorSync):
    """슈퍼 에이전트 채팅용 SupervisorSync"""

    # def _determine_chat_type(self) -> str:
    #     return "SuperAgentChat"

    async def async_init(self):
        """초기화 후 chat_type 업데이트"""
        await super().async_init()
        # await self._update_chat_type()


class SupervisorExpertChatSync(SupervisorSync):
    """에이전트 채팅용 SupervisorSync"""

    # def _determine_chat_type(self) -> str:
    #     return "ExpertAgentChat"

    async def async_init(self):
        """초기화 후 chat_type 업데이트"""
        await super().async_init()
        # await self._update_chat_type()


class SupervisorAIChatSync(SupervisorSync):
    """AI 채팅용 SupervisorSync"""

    def _determine_chat_type(self) -> str:
        return "AIChat"
