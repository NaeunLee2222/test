from pydantic import BaseModel


class UsageDetail(BaseModel):
    id: int
    user_id: int
    org_id: int
    user_limit: int
    org_limit: int
    query_text_limit: int
    answer_token_limit: int


class UsageCreate(BaseModel):
    user_id: int
    org_id: int
    user_limit: int
    org_limit: int
    query_text_limit: int
    answer_token_limit: int


class UsageUpdate(BaseModel):
    user_limit: int
    org_limit: int
    query_text_limit: int
    answer_token_limit: int
