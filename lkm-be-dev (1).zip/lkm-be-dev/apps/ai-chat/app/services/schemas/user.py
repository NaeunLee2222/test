from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class UserCreateRequest(BaseModel):
    email: str = Field(..., description="사용자 이메일 주소", example="user@skax.com")
    password: str = Field(
        ..., description="계정 비밀번호 (해싱되어 저장됨)", example="!skax12345"
    )
    username: Optional[str] = Field(None, description="사용자 이름", example="홍길동")
    organization_id: Optional[int] = Field(None, description="소속 조직 ID", example=42)
    team_id: Optional[int] = Field(None, description="소속 팀 ID", example=42)
    role: str = Field(..., description="사용자 역할 (admin, user 등)", example="user")
    is_activated: bool = Field(..., description="사용자 활성화 여부", example=True)


class UserUpdateRequest(BaseModel):
    username: Optional[str] = Field(
        None, description="변경할 사용자 이름", example="김철수"
    )
    email: Optional[str] = Field(
        None, description="변경할 사용자 이메일 주소", example="user@skax.skax"
    )
    organization_id: Optional[int] = Field(
        None, description="변경할 소속 조직 ID", example=42
    )
    team_id: Optional[int] = Field(None, description="변경할 소속 팀 ID", example=42)
    password: Optional[str] = Field(
        None, description="변경할 비밀번호", example="!skax1234"
    )
    role: Optional[str] = Field(None, description="변경할 사용자 역할", example="admin")
    is_activated: Optional[bool] = Field(
        None, description="변경할 사용자 활성화 여부", example=True
    )


class UserBase(BaseModel):
    email: str
    username: Optional[str] = None
    password: str
    organization_id: Optional[int] = None
    team_id: Optional[int] = None
    role: str
    is_activated: bool = True


class UserUpdate(BaseModel):
    id: int = None
    email: Optional[str] = None
    username: Optional[str] = None
    organization_id: Optional[int] = None
    team_id: Optional[int] = None
    role: Optional[str] = None
    is_activated: bool = True


class PasswordUpdateRequest(BaseModel):
    current_password: str = Field(
        ..., description="현재 비밀번호", example="!skax12345"
    )
    new_password: str = Field(..., description="새 비밀번호", example="!skax1234")


# === 내부 처리용 모델 (DB와 연계) ===


class UserCreate(BaseModel):
    email: str
    username: Optional[str] = None
    password: str
    organization_id: Optional[int] = None
    team_id: Optional[int] = None
    role: str
    is_activated: bool = True


class UserPasswordUpdate(BaseModel):
    id: int
    # email: str
    password: str


# === 응답 모델 (API 응답용) ===


class UserResponse(BaseModel):
    id: int = Field(..., description="사용자 고유 ID", example=42)
    email: str = Field(..., description="사용자 이메일 주소", example="user@skax.com")
    username: Optional[str] = Field(None, description="사용자 이름", example="홍길동")
    organization_id: Optional[int] = Field(None, description="소속 조직 ID", example=42)
    team_id: Optional[int] = Field(None, description="소속 팀 ID", example=42)
    role: str = Field(..., description="사용자 역할", example="user")
    created_at: datetime = Field(
        ..., description="계정 생성 시간", example="2025-05-19T09:30:00"
    )
    updated_at: Optional[datetime] = Field(
        None, description="계정 최종 수정 시간", example="2025-05-19T09:30:00"
    )
    is_activated: bool = Field(..., description="사용자 활성화 여부", example=True)

    class Config:
        from_attributes = True


class UserListResponse(BaseModel):
    users: List[UserResponse]
    total: int
    skip: int
    limit: int
    order: Optional[str] = "id_asc"


### 유저 설정 관련 모델


class UserPreference(BaseModel):
    id: int
    user_id: Optional[int] = None
    agent_id: Optional[int] = None
    predefined_prompt: Optional[str] = ""
    temperature: float
    use_memory: bool

    class Config:
        from_attributes = True


class UserMemory(BaseModel):
    id: int
    user_id: int
    agent_id: int
    contents: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class UserMemoryRequest(BaseModel):
    user_id: int
    agent_id: int
    contents: str


class UserMemoryUpdateRequest(BaseModel):
    contents: str


class ApiResponse(BaseModel):
    status_code: int
    detail: str
