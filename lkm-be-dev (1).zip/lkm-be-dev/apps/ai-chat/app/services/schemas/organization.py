from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, Field


# === Organization 요청 스키마 ===

class OrganizationCreateRequest(BaseModel):
    name: str = Field(
        ...,
        description="회사명",
        example="SK C&C"
    )
    description: Optional[str] = Field(
        None,
        description="조직에 대한 설명",
        example="SK C&C"
    )


class OrganizationUpdateRequest(BaseModel):
    name: Optional[str] = Field(
        None,
        description="변경할 조직 이름",
        example="SK AX"
    )
    description: Optional[str] = Field(
        None,
        description="변경할 조직 설명",
        example="SK AX로 바뀜"
    )


# === Team 요청 스키마 ===

class TeamCreateRequest(BaseModel):
    name: str = Field(
        ...,
        description="팀 이름",
        example="AI혁신팀"
    )
    organization_id: int = Field(
        ...,
        description="소속 조직 ID",
        example=42
    )
    description: Optional[str] = Field(
        None,
        description="팀에 대한 설명",
        example="AI혁신팀"
    )


class TeamUpdateRequest(BaseModel):
    name: Optional[str] = Field(
        None,
        description="변경할 팀 이름",
        example="AI Copilot 팀"
    )
    organization_id: Optional[int] = Field(
        None,
        description="변경할 소속 조직 ID",
        example=42
    )
    description: Optional[str] = Field(
        None,
        description="변경할 팀 설명",
        example="AI Copilot팀"
    )


# === 내부 처리용 모델 ===

class OrganizationCreate(BaseModel):
    name: str
    description: Optional[str] = None


class OrganizationUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class TeamCreate(BaseModel):
    name: str
    organization_id: int
    description: Optional[str] = None


class TeamUpdate(BaseModel):
    name: Optional[str] = None
    organization_id: Optional[int] = None
    description: Optional[str] = None


# === 응답 모델 ===

class OrganizationResponse(BaseModel):
    id: int = Field(
        ...,
        description="조직 고유 ID",
        example=42
    )
    name: str = Field(
        ...,
        description="회사명",
        example="SK C&C"
    )
    description: Optional[str] = Field(
        None,
        description="조직에 대한 설명",
        example="SK C&C"
    )
    created_at: datetime = Field(
        ...,
        description="조직 생성 시간",
        example="2025-05-19T09:30:00"
    )
    updated_at: Optional[datetime] = Field(
        None,
        description="조직 최종 수정 시간",
        example="2025-05-19T09:30:00"
    )

    class Config:
        from_attributes = True


class TeamResponse(BaseModel):
    id: int = Field(
        ...,
        description="팀 고유 ID",
        example=42
    )
    name: str = Field(
        ...,
        description="팀 이름",
        example="AI혁신팀"
    )
    organization_id: int = Field(
        ...,
        description="소속 조직 ID",
        example=42
    )
    description: Optional[str] = Field(
        None,
        description="팀에 대한 설명",
        example="AI혁신팀"
    )
    created_at: datetime = Field(
        ...,
        description="팀 생성 시간",
        example="2025-05-19T09:30:00"
    )
    updated_at: Optional[datetime] = Field(
        None,
        description="팀 최종 수정 시간",
        example="2025-05-19T09:30:00"
    )

    class Config:
        from_attributes = True


# === 확장 응답 모델 (중첩 정보) ===

class OrganizationWithTeamsResponse(OrganizationResponse):
    teams: List[TeamResponse] = Field(
        default_factory=list,
        description="조직에 속한 팀 목록"
    )