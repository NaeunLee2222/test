from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel


class ChatTaskAgentStateBase(BaseModel):
    state: Optional[Dict[str, Any]] = None


class ChatTaskAgentStateCreate(ChatTaskAgentStateBase):
    chat_message_id: str


class ChatTaskAgentStateUpdate(BaseModel):
    state: Optional[Dict[str, Any]] = None


class ChatTaskAgentState(ChatTaskAgentStateBase):
    chat_message_id: str
    created_at: datetime

    class Config:
        from_attributes = True
