from datetime import datetime
from enum import Enum
from typing import Dict, Optional

from pydantic import BaseModel


# 공통 필드를 포함한 ApiSpecBase 정의
class TaskAgentBase(BaseModel):
    task_agent_name: Optional[str] = None
    task_agent_url: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = True


# ApiSpec 생성 요청 스키마
class TaskAgentCreate(TaskAgentBase):
    task_agent_name: str
    task_agent_url: str
    description: str


# ApiSpec 읽기 스키마
class TaskAgentRead(TaskAgentBase):
    id: int
    task_agent_name: str
    task_agent_url: str
    description: str
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# ApiSpec 업데이트 스키마
class TaskAgentUpdate(TaskAgentBase):
    pass  # ApiSpecBase의 모든 필드를 Optional로 상속받음
