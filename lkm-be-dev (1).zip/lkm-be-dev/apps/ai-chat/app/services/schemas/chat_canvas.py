from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

### 기본 모델 ###


class CanvasBase(BaseModel):
    """문서 기본 정보"""

    chat_id: str = Field(..., description="캔버스가 속한 채팅 ID", example="uuid")
    title: Optional[str] = Field(None, description="캔버스 제목", example="기획서")


class CanvasResponse(CanvasBase):
    """문서 조회 응답 모델"""

    model_config = ConfigDict(
        from_attributes=True,
        str_strip_whitespace=True,
    )

    uuid: UUID = Field(
        ..., description="캔버스 UUID", example="b7e2c1c2-1a2b-4c3d-9e4f-5a6b7c8d9e0f"
    )
    current_version: int = Field(..., description="최신 버전 번호", example=1, gt=0)
    created_at: datetime = Field(
        ..., description="생성 시간", example="2023-07-15T10:30:00"
    )
    updated_at: Optional[datetime] = Field(
        None, description="수정 시간", example="2023-07-16T14:45:00"
    )
    type: str = Field(..., description="캔버스 타입", example="canvas")

    content: Optional[str] = Field(None, description="캔버스 내용")


### 문서 델타(버전) ###


class CanvasDeltaBase(BaseModel):
    """문서 델타(버전) 기본 정보"""

    diff: List[Dict[str, Any]] = Field(
        ...,
        description="문서 변경점 이력 리스트 (각 항목에 delta와 raw_delta 포함)",
        example=[
            {
                "delta": {"ops": [{"insert": "Hello world!\n"}]},
                "raw_delta": {
                    "rawDelta": {
                        "0": {"children": {"0": {"text": ["", " 1"]}, "_t": "a"}},
                        "_t": "a",
                    }
                },
            }
        ],
    )


class CanvasDeltaResponse(CanvasDeltaBase):
    """문서 델타(버전) 응답 모델"""

    model_config = ConfigDict(
        from_attributes=True,
        str_strip_whitespace=True,
    )

    canvas_uuid: str = Field(
        ..., description="문서 UUID", example="b7e2c1c2-1a2b-4c3d-9e4f-5a6b7c8d9e0f"
    )
    version: int = Field(..., description="문서 델타 버전", example=2)
    created_at: datetime = Field(
        ..., description="문서 델타 생성 시간", example="2023-07-15T10:35:00"
    )


### API 요청 모델 ###


class CanvasCreateRequest(BaseModel):
    """캔버스 생성 요청 모델"""

    chat_id: str = Field(..., description="캔버스가 속한 채팅 ID", example="uuid")
    title: Optional[str] = Field(None, description="캔버스 제목", example="기획서")
    content: str = Field(
        ...,
        description="초기 캔버스 내용",
        example="# 새로운 캔버스\n\n이 캔버스는 초기 버전입니다.",
    )
    file_extension: Optional[str] = Field(
        "docx", description="파일 다운로드 형식", example="docx"
    )
    version: Optional[int] = Field(1, description="캔버스 버전", gt=0, example=1)
    type: Optional[str] = Field("canvas", description="캔버스 타입", example="canvas")


class CanvasUpdateRequest(BaseModel):
    """캔버스 업데이트 요청 모델"""

    title: Optional[str] = Field(
        None, description="업데이트할 캔버스 제목", example="수정된 기획서"
    )
    content: str = Field(
        ...,
        description="업데이트할 캔버스 내용",
        example="# 수정된 캔버스\n\n이 캔버스는 업데이트되었습니다.",
    )
    version: Optional[int] = Field(
        None,
        description="업데이트할 버전 (현재 버전 + 1). 지정되지 않으면 현재 버전 + 1",
        gt=0,
        example=2,
    )

    diff: List[Dict[str, Any]] = Field(
        ...,
        description="버전 변경 이력 리스트 (각 항목에 delta와 raw_delta 포함)",
        example=[
            {
                "delta": {"ops": [{"insert": "수정된 내용\n"}]},
                "raw_delta": {
                    "rawDelta": {
                        "0": {"children": {"0": {"text": ["", " 1"]}, "_t": "a"}},
                        "_t": "a",
                    }
                },
            }
        ],
    )


class CanvasDeltaCreateRequest(BaseModel):
    """새 델타(버전) 생성 요청 모델"""

    diff: List[Dict[str, Any]] = Field(
        ...,
        description="새 델타(버전) 이력 리스트 (각 항목에 delta와 raw_delta 포함)",
        example=[
            {
                "delta": {"ops": [{"insert": "수정된 내용!\n"}]},
                "raw_delta": {
                    "0": {"children": {"0": {"text": ["수정된", " 내용"]}, "_t": "a"}},
                    "_t": "a",
                },
            }
        ],
    )


### API 응답 모델 ###


class CanvasWithDelta(BaseModel):
    """문서와 단일 델타(버전) 응답 모델"""

    canvas: CanvasResponse = Field(..., description="문서 정보")
    delta: CanvasDeltaResponse = Field(..., description="문서의 현재 델타(버전)")


class CanvasWithDeltaList(BaseModel):
    """문서와 모든 델타(버전) 응답 모델"""

    canvas: CanvasResponse = Field(..., description="문서 정보")
    deltas: List[CanvasDeltaResponse] = Field(..., description="모든 버전의 델타 목록")


class CanvasDeltaListResponse(BaseModel):
    """문서 델타 목록 응답 모델 (페이징 지원)"""

    canvas_uuid: str = Field(..., description="문서 UUID")
    deltas: List[CanvasDeltaResponse] = Field(..., description="델타 목록")
    total: int = Field(..., description="전체 델타 개수")
    skip: int = Field(..., description="건너뛴 개수")
    limit: int = Field(..., description="가져온 개수")


class CanvasListResponse(BaseModel):
    """채팅별 문서 목록 응답 모델"""

    chat_id: Optional[str] = Field(None, description="채팅 ID", example="uuid")
    canvases: List[CanvasResponse] = Field(..., description="문서 목록")
    total: int = Field(..., description="전체 문서 수", example=2)
    skip: Optional[int] = Field(None, description="건너뛴 레코드 수")
    limit: Optional[int] = Field(None, description="조회된 레코드 수")
    title: Optional[str] = Field(None, description="문서 제목")
