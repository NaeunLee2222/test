from typing import Optional

from pydantic import BaseModel, Field


class DocBase(BaseModel):
    user_id: int = Field(..., description="채팅 소유자의 사용자 ID", example=42)
    chat_id: str = Field(
        ..., description="문서가 업로드된 채팅 ID", example="some-uuid-string"
    )
    original_filename: str = Field(
        ..., description="원본 문서 이름", example="test.pdf"
    )
    uuid_filename: str = Field(
        ..., description="UUID 파일 이름", example="a1b2c3d4.pdf"
    )
    file_type: Optional[str] = Field(
        None, description="파일 타입", example="application/pdf"
    )
    index_name: Optional[str] = Field(
        None, description="AZURE_AI_SEARCH_INDEX", example="lkmdev250430"
    )
    state: Optional[str] = Field(
        "UPLOAD",
        description="file state. UPLOAD, WAIT, READY, FAILURE, DELETED. Defaults to 'UPLOAD'",
        example="UPLOAD",
    )
    blob_uri: Optional[str] = Field(
        None, description="blob uri that file uploaded", example="/data/test.pdf"
    )


class DocCreate(DocBase):
    pass


class DocState(BaseModel):
    doc_id: int
    original_filename: str
    state: str
