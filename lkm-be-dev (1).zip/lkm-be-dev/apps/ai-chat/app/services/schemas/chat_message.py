from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field


# 툴 호출 정보
class ToolCall(BaseModel):
    tool_id: int = Field(..., description="도구 ID", example=1)
    tool_name: str = Field(..., description="도구 이름", example="File Uploader")
    tool_description: str = Field(
        ..., description="도구 설명", example="File Uploader 도구입니다"
    )
    tool_status: str = Field(..., description="도구 실행 상태", example="success")
    tool_order: int = Field(..., description="도구 실행 순서", example=1)
    tool_output: str = Field(
        ..., description="도구 실행 결과", example="파일 분석 결과"
    )


# 액션 정보
class Action(BaseModel):
    action_id: int = Field(..., description="액션 ID", example=1)
    action_name: str = Field(..., description="액션 이름", example="문서분석")
    action_description: str = Field(
        ..., description="액션 설명", example="업무 절차서를 통해 업무의 핵심요소 파악"
    )
    action_status: str = Field(..., description="액션 상태", example="success")
    action_order: int = Field(..., description="액션 순서", example=1)
    tool_calls: List[ToolCall] = Field(
        default_factory=list, description="액션에서 사용된 도구 목록"
    )


# 스텝 정보
class Step(BaseModel):
    step_id: int = Field(..., description="스텝 ID", example=1)
    step_name: str = Field(..., description="스텝 이름", example="의도분석")
    step_description: str = Field(
        ..., description="스텝 설명", example="사용자 요청의 의도를 파악합니다"
    )
    step_status: str = Field(..., description="스텝 상태", example="success")
    step_order: int = Field(..., description="스텝 순서", example=1)
    actions: List[Action] = Field(
        default_factory=list, description="스텝에서 실행된 액션 목록"
    )


# 에이전트 실행 정보
class AgentExecutionInfo(BaseModel):
    agent_id: int = Field(..., description="에이전트 ID", example=1)
    execution_steps: List[Step] = Field(
        default_factory=list, description="에이전트 실행 단계 목록"
    )


# 캔버스 정보
class CanvasInfo(BaseModel):
    canvas_uuid: str = Field(..., description="캔버스 UUID", example="123e4567-e89b-12d3-a456-426614174000")
    canvas_name: str = Field(..., description="캔버스 이름", example="RFQ 초안")
    canvas_description: str = Field(
        ..., description="캔버스 설명", example="RFQ 문서 초안입니다"
    )
    canvas_version: int = Field(..., description="캔버스 버전", example=1)


# 메타데이터 통합 모델
class ContentMetadata(BaseModel):
    agent_execution_information: Optional[AgentExecutionInfo] = Field(
        None, description="에이전트 실행 정보"
    )
    canvas_information: Optional[CanvasInfo] = Field(None, description="캔버스 정보")
    # 필요한 다른 메타데이터 필드도 여기에 추가 가능
    additional_info: Optional[Dict[str, Any]] = Field(
        None, description="기타 추가 정보"
    )


class ChatMessageContentBase(BaseModel):
    parent_id: Optional[str] = Field(
        None, description="부모 메시지 ID (답변인 경우)", example=None
    )
    content: str = Field(
        ..., description="메시지 내용", example="RFQ 문서를 작성해주세요."
    )
    role: str = Field(
        ..., description="메시지 역할 (user, assistant, system)", example="user"
    )
    content_metadata: Optional[Union[ContentMetadata, str]] = Field(
        None, description="메시지 부가정보 (에이전트 실행 정보, 캔버스 정보 등)"
    )
    attachment: Optional[str] = Field(
        None, description="첨부파일 정보", example="uploads/documents/rfq_sample.pdf"
    )


class ChatMessageBase(ChatMessageContentBase):
    chat_id: str = Field(
        ..., description="채팅 ID", example="f231ddac-1ced-4e9f-bfd3-9c02d211a917"
    )


class ChatMessageCreateRequest(ChatMessageContentBase):
    pass


class ChatMessageUpdate(BaseModel):
    content: Optional[str] = None
    content_metadata: Optional[ContentMetadata] = None
    attachment: Optional[str] = None


class ChatMessage(ChatMessageBase):
    id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ChatMessagePatchRequest(BaseModel):
    content: Optional[str] = Field(
        None,
        description="수정할 메시지 내용",
        example="업데이트된 RFQ 문서 작성 요청입니다.",
    )
    content_metadata: Optional[ContentMetadata] = Field(
        None, description="수정할 메시지 부가정보"
    )
    attachment: Optional[str] = Field(
        None,
        description="수정할 첨부파일 정보",
        example="uploads/documents/updated_rfq_sample.pdf",
    )


class ChatMessageBulkRequest(BaseModel):
    messages: list[ChatMessage]


class ChatMessageResponse(ChatMessage):
    pass


class ChatMessageListResponse(BaseModel):
    items: list[ChatMessage]
    total: int


class MessageFeedback(Enum):
    LIKE = "like"
    DISLIKE = "dislike"

class ChatMessageFeedbackResponse(BaseModel):
    id: int
    chat_message_id: str
    feedback: MessageFeedback
    created_at: Optional[datetime] = None

class ChatMessageFeedbackRequest(BaseModel):
    chat_message_id: str
    feedback: MessageFeedback = Field(
        ..., description="피드백 유형 (like 또는 dislike)", example="like"
    )
