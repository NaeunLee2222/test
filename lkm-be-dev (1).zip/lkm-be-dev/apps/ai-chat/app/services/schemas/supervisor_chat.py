from typing import Optional

from core.config import get_setting
from core.utils.email_parsing import (
    has_user_search_pattern,
    transform_user_search_pattern_email,
)
from pydantic import BaseModel, model_validator

settings = get_setting()


class SupervisorChatMessage(BaseModel):
    parent_id: Optional[str] = None
    # TODO: uuid로 변경 예정
    id: str
    role: str
    content: str


class SupervisorChatRequest(BaseModel):
    chat_id: str
    messages: list[SupervisorChatMessage]
    child_id: str
    is_stream: bool = False
    task_agent_id: Optional[int] = None
    expert_agent_id: Optional[int] = None
    canvas: Optional[str] = None

    @model_validator(mode="after")
    def validate_messages(
        cls, model: "SupervisorChatRequest"
    ) -> "SupervisorChatRequest":
        messages = model.messages
        if messages:
            last_message = messages[-1]
            if last_message.role == "user" and has_user_search_pattern(
                last_message.content
            ):
                last_message.content = transform_user_search_pattern_email(
                    last_message.content
                )
        return model


class SupervisorGeneralChatRequest(BaseModel):
    chat_id: str
    messages: list[SupervisorChatMessage]
    child_id: str
    is_stream: bool = False
    tool_group_ids: list[int] = []
    canvas: Optional[str] = None

    @model_validator(mode="after")
    def validate_messages(
        cls, model: "SupervisorGeneralChatRequest"
    ) -> "SupervisorGeneralChatRequest":
        messages = model.messages
        if messages:
            last_message = messages[-1]
            if last_message.role == "user" and has_user_search_pattern(
                last_message.content
            ):
                last_message.content = transform_user_search_pattern_email(
                    last_message.content
                )
        return model


# TODO: 사용여부 확인 필요
class SupervisorInput(BaseModel):
    model: str
    messages: list[SupervisorChatMessage]  # 메시지 구조를 더 명확하게 지정
    max_tokens: int = None
    temperature: float = 0.1
    stop: list = None
    n: int = 1
    stream: bool = False
