from typing import Optional

from pydantic import BaseModel, Field


class UserInfo(BaseModel):
    user_id: Optional[int] = None
    email: Optional[str] = None
    username: Optional[str] = None
    org_name: Optional[str] = None
    team_name: Optional[str] = None
    role: Optional[str] = None
    organization_id: Optional[int] = None
    team_id: Optional[int] = None


class LoginRequest(BaseModel):
    email: str = Field(..., description="이메일", example="user@skax.com")
    password: str = Field(..., description="비밀번호", example="!skax12345")
