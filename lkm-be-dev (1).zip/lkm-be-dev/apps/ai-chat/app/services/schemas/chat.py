from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class ChatBase(BaseModel):
    user_id: int = Field(..., description="채팅 소유자의 사용자 ID", example=42)
    agent_id: Optional[int] = Field(
        None, description="채팅에 연결된 에이전트 ID", example=45
    )
    title: Optional[str] = Field(
        None, description="채팅 제목", example="RFQ 문서 작성 프로젝트"
    )
    model: Optional[str] = Field(None, description="사용된 AI 모델", example="gpt4o")
    config: Optional[dict] = Field(
        None,
        description="채팅 설정 정보, workflow studio의 검증 챗인지, 일반 chat인지, expert agent를 쓰는 chat인지 구분",
        example={"chat_mode": "workflow_studio"},
    )


class Chat(ChatBase):
    id: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    chat_type: Optional[str] = Field(
        None,
        description="채팅 타입",
        example="AIChat",
    )

    class Config:
        from_attributes = True


class ChatListResponse(BaseModel):
    chat_list: List[Chat]
    total: int
    skip: int
    limit: int


class ChatCreate(ChatBase):
    pass


class ChatCreateWithId(ChatCreate):
    id: Optional[str] = Field(
        None,
        description="지정할 채팅 ID (특수한 경우만 사용)",
        example="0196ddf6-d828-722f-8d91-fb98c6cf1c12",
    )
    chat_type: Optional[str] = Field(
        "AIChat",
        description="채팅 타입 (내부적으로 사용, 기본값: AIChat)",
        example="AIChat",
    )


class ChatUpdate(ChatBase):
    id: str = Field(
        ...,
        description="업데이트할 채팅 ID",
        example="0196ddf6-d828-722f-8d91-fb98c6cf1c12",
    )


class ChatPatchRequest(BaseModel):
    title: Optional[str] = Field(
        None, description="변경할 채팅 제목", example="수정된 RFQ 문서 작성 프로젝트"
    )
