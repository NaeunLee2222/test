from typing import List, Optional

from client.task_agent_client import TaskAgentClient
from core.config import get_setting
from database.crud.chat import CRUDChat
from database.crud.chat_message import CRUDChatMessage, CRUDChatMessageFeedback
from database.models.chat import Chat as DBChat
from database.models.chat import ChatMessage
from database.models.chat import ChatMessageFeedback as DBChatMessageFeedback
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from langchain_core.prompts import PromptTemplate
from langchain_openai import AzureChatOpenAI
from services.schemas.chat import Chat, ChatCreateWithId, ChatUpdate
from services.schemas.chat_message import (
    ChatMessageCreateRequest,
    ChatMessageFeedbackRequest,
    ChatMessageFeedbackResponse,
    ChatMessagePatchRequest,
)
from sqlalchemy import delete
from sqlalchemy.ext.asyncio import AsyncSession

settings = get_setting()
crud_chat = CRUDChat()
crud_chat_message = CRUDChatMessage()
crud_chat_message_feedback = CRUDChatMessageFeedback()
task_agent_client = TaskAgentClient()


async def get_chat_by_user_id(
    db: AsyncSession, *, user_id: int, skip: int, limit: int, sort: str, order: str
):

    try:
        chat_list, total = await crud_chat.get_chat_by_user_id(
            db=db, user_id=user_id, skip=skip, limit=limit, sort=sort, order=order
        )
        if not chat_list:
            return (
                [],
                0,
            )  # Return an empty list and total count of 0 if no chats are found

        chatbase_list = [
            Chat(
                id=chat.id,
                agent_id=chat.agent_id,
                title=(
                    chat.title if chat.title and chat.title.strip() else "새로운 채팅"
                ),
                user_id=chat.user_id,
                config=chat.config,
                updated_at=chat.updated_at,
                created_at=chat.created_at,
                chat_type=chat.chat_type,
            )
            for chat in chat_list
        ]
        return chatbase_list, total

    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to retrieve chats, {str(e)}",
        )


async def get_chat_by_chat_id(db: AsyncSession, *, chat_id: str):
    try:
        chat = await crud_chat.get(db, id=chat_id)
        if not chat:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Chat with id {chat_id} not found",
            )
        return chat
    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get chat, {str(e)}",
        )


async def get_chat_with_agent_name(db: AsyncSession, *, chat_id: str):
    """Optimized chat retrieval with agent name - single database call for chat"""
    try:
        chat = await get_chat_by_chat_id(db, chat_id=chat_id)

        # External API call for agent data (non-blocking)
        agent_data = await task_agent_client.get_agent_detail(chat.agent_id)
        agent = agent_data.get("agent") if agent_data else None
        agent_name = agent.get("name", "Unknown Agent") if agent else "Unknown Agent"
        usage_scope = agent.get("usage_scope") if agent else None

        result = {
            "id": chat.id,
            "agent_id": chat.agent_id,
            "title": chat.title,
            "user_id": chat.user_id,
            "config": chat.config,
            "updated_at": chat.updated_at,
            "created_at": chat.created_at,
            "agent_name": agent_name,
            "usage_scope": usage_scope,
        }
        return result
    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get chat with agent name, {str(e)}",
        )


async def create_chat(db: AsyncSession, *, chat_data: ChatCreateWithId):
    try:
        chat_data_dict = chat_data.model_dump()
        # Todo: 추후 기본 채팅 타입 설정 필요
        chat_data_dict["chat_type"] = chat_data.chat_type
        return await crud_chat.create_without_refresh(db, chat_data_dict)
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to create chat, {str(e)}",
        )


async def update_chat(db: AsyncSession, *, chat_data: ChatUpdate):
    try:
        return await crud_chat.update(db, chat_data)
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to update chat, {str(e)}",
        )


async def update_chat_title(
    db: AsyncSession, *, chat_id: str, title: Optional[str] = None
):
    try:
        # Get existing chat first
        existing_chat = await crud_chat.get(db, id=chat_id)
        if not existing_chat:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Chat with id {chat_id} not found",
            )

        # Update using CRUD function
        update_data = {"title": title}
        updated_chat = await crud_chat.update(
            db, db_obj=existing_chat, obj_in=update_data
        )
        return updated_chat
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to update chat title, {str(e)}",
        )


async def get_chat_by_id(db: AsyncSession, *, id: int):
    try:
        return await crud_chat.get(db, id)
    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get chat, {str(e)}",
        )


async def delete_chat(db: AsyncSession, *, id: str) -> DBChat:
    try:
        # Single database call to get chat
        db_chat = await crud_chat.get(db, id)
        if not db_chat:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Chat with ID '{id}' not found",
            )

        # Bulk delete messages and chat in single transaction
        await crud_chat_message.delete_chat_messages_by_chat_id(db, id)
        await crud_chat.delete(db, id=id)
        await db.commit()

        return db_chat

    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to delete chat, {str(e)}",
        )


async def delete_all_user_chat_histories(db: AsyncSession, *, user_id: int):
    try:
        # 1. 사용자의 모든 채팅 목록 조회
        user_chats, total = await crud_chat.get_chat_by_user_id(
            db, user_id=user_id, skip=0, limit=1000000, sort="created_at", order="asc"
        )
        deleted_count = 0

        # Process in batches to avoid long transactions
        batch_size = 50
        for i in range(0, len(user_chats), batch_size):
            batch = user_chats[i : i + batch_size]

            # Delete messages and chats in batch
            for chat in batch:
                # Use bulk delete for messages
                await db.execute(
                    delete(ChatMessage).where(ChatMessage.chat_id == str(chat.id))
                )
                # Delete chat
                await db.execute(delete(DBChat).where(DBChat.id == chat.id))
            deleted_count += len(batch)

            # Commit batch to avoid long transactions
            await db.commit()

        return deleted_count

    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to delete user chat histories, {str(e)}",
        )


async def get_chat_messages(db: AsyncSession, *, chat_id: str) -> List[ChatMessage]:
    try:
        messages = await crud_chat_message.get_chat_messages_by_chat_id(db, chat_id)
        await db.commit()
        return messages
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get chat messages, {str(e)}",
        )


async def create_message(
    db: AsyncSession, *, chat_id: str, message_data: ChatMessageCreateRequest
) -> ChatMessage:
    try:
        # Validate chat exists in single query
        chat = await crud_chat.get(db, id=chat_id)
        if not chat:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Chat with id {chat_id} not found",
            )

        # Prepare message data
        message_dict = message_data.model_dump()
        message_dict["chat_id"] = chat_id

        # Handle content_metadata
        if message_dict.get("content_metadata") == "":
            message_dict["content_metadata"] = None

        # Create message
        db_message = await crud_chat_message.create(db, message_dict)
        return db_message

    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to create message, {str(e)}",
        )


async def get_message(db: AsyncSession, *, message_id: str) -> ChatMessage:
    try:
        message = await crud_chat_message.get(db, id=message_id)
        if not message:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Message with id {message_id} not found",
            )
        await db.commit()
        return message
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get message, {str(e)}",
        )


async def update_message(
    db: AsyncSession, *, message_id: int, message_data: ChatMessagePatchRequest
):
    try:
        # Get existing message
        existing_message = await crud_chat_message.get(db, id=message_id)
        if not existing_message:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Message with id {message_id} not found",
            )

        # 메시지 업데이트를 위한 데이터 준비
        update_data = {}

        if message_data.content is not None:
            update_data["content"] = message_data.content

        if message_data.attachment is not None:
            update_data["attachment"] = message_data.attachment

        if message_data.content_metadata is not None:
            # Pydantic 모델을 딕셔너리로 변환
            update_data["content_metadata"] = message_data.content_metadata.model_dump(
                exclude_none=True
            )

        # 업데이트 수행
        updated_message = await crud_chat_message.update(
            db, db_obj=existing_message, obj_in=update_data
        )
        return updated_message

    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to update message, {str(e)}",
        )


async def delete_message(db: AsyncSession, *, message_id: str):
    try:
        message = await crud_chat_message.get(db, id=message_id)
        if not message:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Message with id {message_id} not found",
            )

        return await crud_chat_message.delete(db, id=message_id)
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to delete message, {str(e)}",
        )


class ChatMessageFeedbackService:
    def __init__(self):
        self.crud_chat_message_feedback = CRUDChatMessageFeedback()
        self.crud_chat_message = CRUDChatMessage()

    async def add_message_feedback(
        self, db: AsyncSession, feedback_data: ChatMessageFeedbackRequest
    ) -> ChatMessageFeedbackRequest:
        try:
            # 기존 피드백이 있는지 확인

            existing_feedback = await self.crud_chat_message_feedback.get_message_feedback_by_message_id(
                db, message_id=feedback_data.chat_message_id
            )
            if existing_feedback:
                # 기존 피드백 반환 (No Update)
                return existing_feedback
            return await self.crud_chat_message_feedback.create_message_feedback(
                db, feedback_data
            )
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to add message feedback, {str(e)}",
            )

    async def get_all_message_feedback_by_chat_id(
        self, db: AsyncSession, chat_id: str
    ) -> List[DBChatMessageFeedback]:
        """Optimized feedback retrieval for chat with batch processing"""
        try:
            # Get all messages for chat
            messages = await crud_chat_message.get_chat_messages_by_chat_id(db, chat_id)
            if not messages:
                return []

            # Get feedback for all messages in batch
            feedback_list = []
            for message in messages:
                feedback = await self.crud_chat_message_feedback.get_message_feedback_by_message_id(
                    db, message.id
                )
                if feedback:
                    feedback_list.append(
                        ChatMessageFeedbackResponse(
                            id=feedback.id,
                            chat_message_id=feedback.chat_message_id,
                            feedback=feedback.feedback,
                            created_at=feedback.created_at,
                        )
                    )

            return feedback_list
        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get message feedback, {str(e)}",
            )

    async def get_message_feedback(
        self, db: AsyncSession, message_id: str
    ) -> Optional[DBChatMessageFeedback]:
        try:
            feedback = await self.crud_chat_message_feedback.get_message_feedback_by_message_id(
                db, message_id=message_id
            )
        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get message feedback, {str(e)}",
            )

    async def delete_message_feedback(
        self, db: AsyncSession, message_feedback_id: str, message_id: str
    ) -> dict:
        existing_feedback = await self.crud_chat_message_feedback.get_message_feedback(
            db, id=message_feedback_id
        )
        if not existing_feedback:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Feedback with id {message_feedback_id} not found",
            )
        elif existing_feedback.chat_message_id != message_id:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.NOT_DEFINED,
                detail=f"Feedback with id {message_feedback_id} does not match message_id {message_id}",
            )
        try:
            await self.crud_chat_message_feedback.delete(db, id=message_feedback_id)
        except ServiceException as se:
            await db.rollback()
            raise se
        except Exception as e:
            await db.rollback()
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to delete message feedback, {str(e)}",
            )


class ChatTitleService:
    def __init__(self):
        self.llm = AzureChatOpenAI(
            model=settings.OPENAI_MODEL,
            temperature=0,
            api_key=settings.OPENAI_API_KEY,
            api_version=settings.OPENAI_API_VERSION,
            azure_endpoint=settings.OPENAI_ENDPOINT,
            azure_deployment=settings.OPENAI_DEPLOYMENT,
        )

    async def create_chat_title(self, db: AsyncSession, *, chat_id: str, content: str):
        try:
            chat = await crud_chat.get(db, id=chat_id)
            if not chat:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"Chat with id {chat_id} not found",
                )

            # 프롬프트 템플릿 정의
            chat_title_prompt = """
            You are an AI that generates concise and informative titles for chat conversations.

            Guidelines:
            - Detect the input language (Korean or English).
            - If the user's input is in Korean, respond in Korean.
            - If the user's input is in English, respond in English.
            - Do not include quotation marks or any extra explanation.
            - Just return a short title, maximum 10 words.

            User input:
            {content}

            Generate only the title based on the above.
            """

            prompt = PromptTemplate(
                template=chat_title_prompt,
                input_variables=["content"],
            )
            chain = prompt | self.llm
            response = chain.invoke({"content": content})

            title = response.content.strip()

            await update_chat_title(db, chat_id=chat_id, title=title)
            return title

        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to create chat title, {str(e)}",
            )
