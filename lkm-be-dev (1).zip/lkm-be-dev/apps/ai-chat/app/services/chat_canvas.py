import difflib
import uuid
from typing import Any, Dict, Optional, Union

from database.crud.chat import CRUDChat
from database.crud.chat_canvas import CRUDCanvas, CRUDCanvasDelta
from database.models.chat import CanvasDelta, ChatCanvas
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from services.schemas.chat_canvas import (
    CanvasCreateRequest,
    CanvasDeltaListResponse,
    CanvasDeltaResponse,
    CanvasListResponse,
    CanvasResponse,
    CanvasUpdateRequest,
    CanvasWithDelta,
    CanvasWithDeltaList,
)
from sqlalchemy.ext.asyncio import AsyncSession

crud_chat = CRUDChat()
crud_canvas = CRUDCanvas()
crud_canvas_delta = CRUDCanvasDelta()


async def create_canvas(
    db: AsyncSession, *, canvas_data: CanvasCreateRequest
) -> CanvasResponse:
    """새 문서 생성"""
    try:
        # 챗 존재여부 검증
        # chat = await crud_chat.get(db, id=canvas_data.chat_id)
        # if not chat:
        #     raise ServiceException(
        #         status_code=404,
        #         error_code=ErrorCode.RESOURCE_NOT_FOUND,
        #         detail=f"Chat with id {canvas_data.chat_id} not found. Cannot create canvas for non-existent chat."
        #     )

        # 1. 새 문서 생성
        canvas_dict = {
            "chat_id": canvas_data.chat_id,
            "uuid": str(uuid.uuid4()),
            "title": canvas_data.title,
            "content": canvas_data.content,
            "type": canvas_data.type,
            "file_extension": canvas_data.file_extension,
            "current_version": canvas_data.version,  # 첫 버전은 항상 1
        }

        new_canvas: ChatCanvas = await crud_canvas.create(db, canvas_dict)

        return CanvasResponse.model_validate(new_canvas)
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to create canvas, {str(e)}",
        )


async def get_canvases_by_chat_id(
    db: AsyncSession, *, chat_id: str
) -> CanvasListResponse:
    """채팅에 속한 모든 문서 목록 조회"""
    try:
        # 1. 모든 문서 조회
        canvases = await crud_canvas.get_canvases_by_chat_id(db, chat_id)

        return CanvasListResponse(
            chat_id=chat_id, canvases=canvases, total=len(canvases)
        )
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get canvases, {str(e)}",
        )


async def get_canvas_by_uuid(
    db: AsyncSession, *, canvas_uuid: str, deltas: bool = False
) -> Union[CanvasWithDeltaList, CanvasResponse]:
    """특정 문서의 특정 버전 조회 (버전 미지정시 최신 버전)"""
    try:
        # 1. 문서 조회
        canvas: ChatCanvas = await crud_canvas.get_canvas(db, canvas_uuid=canvas_uuid)
        if not canvas:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Canvas with uuid {canvas_uuid} not found",
            )

        # 3. 델타 조회
        if deltas:
            deltas = await crud_canvas_delta.get_deltas_by_canvas_uuid(
                db, canvas_uuid=canvas_uuid
            )
            return CanvasWithDeltaList(canvas=canvas, deltas=deltas)
        else:
            return CanvasResponse.model_validate(canvas)
    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get canvas, {str(e)}",
        )


async def get_canvas_diff(
    db: AsyncSession, *, canvas_uuid: str, skip: int = 0, limit: int = 20
) -> CanvasDeltaListResponse:
    """문서의 모든 버전 변경사항(delta) 조회 (버전 역순, 페이징 지원)

    Args:
        db: 데이터베이스 세션
        canvas_uuid: 문서 UUID
        skip: 건너뛸 개수
        limit: 가져올 개수

    Returns:
        CanvasDeltaListResponse: 문서 변경사항 목록 정보

    Raises:
        ServiceException: 문서를 찾을 수 없는 경우
    """

    if canvas_uuid == "simple_chat_result":
        return CanvasDeltaListResponse(
            canvas_uuid=canvas_uuid,
            deltas=[],
            total=0,
            skip=skip,
            limit=limit,
        )
    try:
        # 1. 문서 존재 여부 확인
        canvas = await crud_canvas.get_canvas(db, canvas_uuid=canvas_uuid)
        if not canvas:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Canvas with uuid {canvas_uuid} not found",
            )

        # 2. 페이징된 델타 목록 조회 (버전 역순)
        deltas, total = await crud_canvas_delta.get_deltas_by_canvas_uuid_paginated(
            db, canvas_uuid=canvas_uuid, skip=skip, limit=limit
        )

        # 3. 델타 목록을 응답 모델로 변환
        delta_responses = [
            CanvasDeltaResponse.model_validate(delta) for delta in deltas
        ]

        # 4. 페이징 정보 포함한 응답 반환
        return CanvasDeltaListResponse(
            canvas_uuid=canvas_uuid,
            deltas=delta_responses,
            total=total,
            skip=skip,
            limit=limit,
        )
    except ServiceException as se:
        raise se
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get canvas deltas, {str(e)}",
        )


async def update_canvas(
    db: AsyncSession, *, canvas_uuid: str, update_data: CanvasUpdateRequest
) -> CanvasWithDelta:
    """캔버스 업데이트 (새 델타 생성)"""
    try:
        # 1. 문서 정보 조회
        canvas: ChatCanvas = await crud_canvas.get_canvas(db, canvas_uuid=canvas_uuid)
        if not canvas:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Canvas with uuid {canvas_uuid} not found",
            )

        # 2. 버전 검증
        if update_data.version is None:
            update_data.version = canvas.current_version + 1
        elif update_data.version != canvas.current_version + 1:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail=f"Invalid version. Expected version {canvas.current_version + 1}, got {update_data.version}",
            )

        # # 3. 이전 버전 내용 가져오기 (diff 계산용)
        # prev_content = canvas.content
        # new_content = update_data.content

        # # 4. 라인 기반 diff 계산
        # diff_result = await _compute_line_based_diff(prev_content, new_content)

        # diff 데이터 검증 (리스트이고 각 항목에 delta와 raw_delta 포함)
        if not update_data.diff or not isinstance(update_data.diff, list):
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.OFFICIAL_UPDATE_DENIED,
                detail="diff must be a non-empty list",
            )

        # 각 diff 항목에 delta와 raw_delta가 있는지 검증
        for i, diff_item in enumerate(update_data.diff):
            if not diff_item.get("delta") or not diff_item.get("raw_delta"):
                raise ServiceException(
                    status_code=400,
                    error_code=ErrorCode.OFFICIAL_UPDATE_DENIED,
                    detail=f"diff item {i} must contain both 'delta' and 'raw_delta'",
                )

        # 5. 새 델타 생성
        delta_data = {
            "canvas_uuid": canvas_uuid,
            "version": update_data.version,
            "diff": update_data.diff,  # 이제 delta와 raw_delta를 포함한 전체 diff 구조
        }
        new_delta: CanvasDelta = await crud_canvas_delta.create(db, delta_data)

        # 6. canvas 업데이트
        update_dict = {
            "current_version": update_data.version,
            "content": update_data.content,
        }
        if update_data.title is not None:
            update_dict["title"] = update_data.title

        await crud_canvas.update(
            db,
            db_obj=canvas,
            obj_in=update_dict,
        )

        return CanvasWithDelta(canvas=canvas, delta=new_delta)
    except ServiceException as se:
        await db.rollback()
        raise se
    except Exception as e:
        await db.rollback()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to update canvas, {str(e)}",
        )


async def _compute_line_based_diff(
    old_content: str, new_content: str
) -> Dict[str, Any]:
    """라인 기반으로 콘텐츠 비교

    # Return Example
    ```
    {
        "line_changes": [
            {
                "type": "removed",
                "content": "    <li>운영 대시보드 반응속도 3.1초 → 1.2초로 개선</li>",
                "line_number": 112
            },
            {
                "type": "removed",
                "content": "    <h3>요약</h3>",
                "line_number": 122
            },
            {
                "type": "added",
                "content": "    <h4>요약</h4>",
                "line_number": 124
            },
            {
                "type": "added",
                "content": "  <div>",
                "line_number": 133
            },
            {
                "type": "added",
                "content": "  안녕하세요",
                "line_number": 134
            }
        ]
    }
    ```
    """
    try:
        # 1. 라인 단위로 분할
        old_lines = old_content.splitlines()
        new_lines = new_content.splitlines()

        # 2. difflib으로 라인별 차이점 파악
        diff = list(difflib.ndiff(old_lines, new_lines))

        # 3. 변경 타입별로 그룹화
        changes = []
        line_changes = []

        # 변경된 라인 추적
        for i, line in enumerate(diff):
            if line.startswith("- "):  # 삭제된 라인
                line_changes.append(
                    {
                        "type": "removed",
                        "line_number": i,
                        "content": line[2:],  # '- ' 제거
                    }
                )
            elif line.startswith("+ "):  # 추가된 라인
                line_changes.append(
                    {
                        "type": "added",
                        "line_number": i,
                        "content": line[2:],  # '+ ' 제거
                    }
                )
            elif line.startswith("? "):  # diff 정보 (무시)
                continue

        # 4. 연속된 변경사항 그룹화 (변경 블록 식별)
        change_blocks = []
        current_block = {"start": -1, "end": -1, "old_lines": [], "new_lines": []}

        for i, line in enumerate(diff):
            if line.startswith("- ") or line.startswith("+ "):
                # 새 블록 시작
                if current_block["start"] == -1:
                    current_block["start"] = i

                # 라인 추가
                if line.startswith("- "):
                    current_block["old_lines"].append(line[2:])
                else:
                    current_block["new_lines"].append(line[2:])

                current_block["end"] = i
            elif line.startswith("? "):
                # diff 정보 무시
                continue
            else:  # 변경 없는 라인
                # 현재 블록이 있으면 저장하고 초기화
                if current_block["start"] != -1:
                    change_blocks.append(current_block)
                    current_block = {
                        "start": -1,
                        "end": -1,
                        "old_lines": [],
                        "new_lines": [],
                    }

        # 마지막 블록 처리
        if current_block["start"] != -1:
            change_blocks.append(current_block)

        return {
            "line_changes": line_changes,
        }
    except Exception as e:
        # 오류 발생 시 기본 텍스트 diff로 대체
        return {
            "error": str(e),
            "text_diff": list(
                difflib.unified_diff(
                    old_content.splitlines(), new_content.splitlines(), lineterm=""
                )
            ),
        }


async def get_canvas_by_user_id(
    db: AsyncSession,
    *,
    user_id: int,
    skip: int,
    limit: int,
    order: Optional[str] = None,
    title: Optional[str] = None,
    type: Optional[str] = None,
) -> CanvasListResponse:
    """사용자 ID에 해당하는 모든 문서 목록 조회 (Chat과 조인하여 해당 유저의 채팅에 속한 캔버스만 조회)"""
    try:
        # 1. Chat 테이블과 조인하여 해당 유저의 채팅에 속한 모든 캔버스 조회
        canvases = await crud_canvas.get_canvases_by_user_id_with_chat_join(
            db,
            user_id=user_id,
            skip=skip,
            limit=limit,
            order=order,
            title=title,
            type=type,
        )
        n_total = await crud_canvas.get_total_canvas_by_user_id(
            db=db, user_id=user_id, type=type, title=title
        )

        return CanvasListResponse(
            canvases=canvases,
            total=n_total,
            skip=skip,
            limit=limit,
            title=title,
        )
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to get canvases, {str(e)}",
        )


async def delete_canvas(db: AsyncSession, *, canvas_uuid: str) -> bool:
    """캔버스 삭제"""
    try:
        await crud_canvas.delete_by_uuid(db, canvas_uuid=canvas_uuid)
        await crud_canvas_delta.delete_by_canvas_uuid(db, canvas_uuid=canvas_uuid)
        return True
    except Exception as e:
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            detail=f"Failed to delete canvas",
        )
