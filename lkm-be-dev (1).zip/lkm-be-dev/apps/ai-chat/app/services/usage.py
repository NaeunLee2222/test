from database.crud.usage import CRUDUsage
from sqlalchemy.ext.asyncio import AsyncSession
from services.schemas.usage import UsageDetail, UsageUpdate, UsageCreate
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from database.models.usage import Usage
from database.crud.user import CRUDOrganization


class UsageService:
    def __init__(self):
        self.crud_usage = CRUDUsage()
        self.crud_organization = CRUDOrganization()

    async def get_usage_by_user_id(self, db: AsyncSession, user_id: int) -> UsageDetail:
        usage = await self.crud_usage.get_usage_by_user_id(db, user_id)
        if not usage:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="Usage not found",
            )
        usage_detail = UsageDetail(
            id=usage.id,
            user_id=usage.user_id,
            org_id=usage.org_id,
            user_limit=usage.user_limit,
            org_limit=usage.org_limit,
            query_text_limit=usage.query_text_limit,
            answer_token_limit=usage.answer_token_limit,
        )
        return usage_detail

    async def create_usage(
        self, db: AsyncSession, usage_create: UsageCreate
    ) -> UsageDetail:
        existing_usage = await self.crud_usage.get_usage_by_user_id(
            db, usage_create.user_id
        )
        if existing_usage:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.DUPLICATE_ENTITY,
                detail="Usage already exists",
            )
        org = await self.crud_organization.get_organization_by_id(
            db, usage_create.org_id
        )
        if not org:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="Organization not found",
            )

        usage = Usage(
            user_id=usage_create.user_id,
            org_id=usage_create.org_id,
            user_limit=usage_create.user_limit,
            org_limit=usage_create.org_limit,
            query_text_limit=usage_create.query_text_limit,
            answer_token_limit=usage_create.answer_token_limit,
        )
        usage = await self.crud_usage.create_usage(db, usage)
        usage_detail = UsageDetail(
            id=usage.id,
            user_id=usage.user_id,
            org_id=usage.org_id,
            user_limit=usage.user_limit,
            org_limit=usage.org_limit,
            query_text_limit=usage.query_text_limit,
            answer_token_limit=usage.answer_token_limit,
        )
        return usage_detail

    async def update_usage(
        self, db: AsyncSession, user_id: int, usage_update: UsageUpdate
    ) -> UsageDetail:
        existing_usage = await self.get_usage_by_user_id(db, user_id)
        if not existing_usage:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="Usage not found",
            )
        usage = await self.crud_usage.update_usage(db, user_id, usage_update)
        return UsageDetail(
            id=usage.id,
            user_id=usage.user_id,
            org_id=usage.org_id,
            user_limit=usage.user_limit,
            org_limit=usage.org_limit,
            query_text_limit=usage.query_text_limit,
            answer_token_limit=usage.answer_token_limit,
        )
