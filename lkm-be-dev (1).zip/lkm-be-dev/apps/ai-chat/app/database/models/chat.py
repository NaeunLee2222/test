import uuid

from database.base import Base
from sqlalchemy import JSON, Column, DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import BIGINT, JSONB
from sqlalchemy.sql import func


class Chat(Base):
    __tablename__ = "chats"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(Integer, nullable=False)
    agent_id = Column(Integer, nullable=True)
    title = Column(Text, nullable=True)
    model = Column(String(50), nullable=True)  # 정해지면 Enum으로 변경
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    config = Column(
        JSON,
        nullable=True,
        comment="챗 쪽의 Chat인지 명장이 만들면서 검증하는 Chat 쪽인지 구분",
    )
    chat_type = Column(
        Enum(
            "AIChat",
            "AISlideChat",
            "SuperAgentChat",
            "ExpertAgentChat",
            name="chat_type",
        ),
    )


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    chat_id = Column(String(36), nullable=False)
    parent_id = Column(
        String(36), nullable=True
    )  # 부모 메시지의 id, 재생성 버저닝을 위한 column
    content = Column(Text, nullable=True)
    role = Column(
        Enum("user", "assistant", "system", name="chat_message_role"), nullable=False
    )
    content_metadata = Column(
        JSON,
        nullable=True,
        comment="agent가 수행한 작업에 대한 정보 + canvas 정보를 담아줘야함.",
    )
    """
    {
        "agent_execution_information":{
            "agent_id": 1,
            "execution_steps":[
                {
                    "step_id": 1,
                    "step_name": "step1",
                    "step_description": "step1 description",
                    "step_status": "success",
                    "step_order": 1,
                    "actions":[
                        {
                            "action_id": 1,
                            "action_name": "action1",
                            "action_description": "action1 description",
                            "action_status": "success",
                            "action_order": 1,
                            "tool_calls" : [
                                {
                                    "tool_id": 1,
                                    "tool_name": "tool1",
                                    "tool_description": "tool1 description",
                                    "tool_status": "success",
                                    "tool_order": 1,
                                    "tool_output": "tool1 output"
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        "canvas_information":{
            "canvas_id": 1,
            "canvas_name": "canvas1",
            "canvas_description": "canvas1 description",
            "canvas_version": 1
        }
    }
    """
    attachment = Column(
        Text, nullable=True
    )  # 외부 파일 경로로 처리할건지? 그러면 Table 추가해야함.
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class ChatMessageFeedback(Base):
    __tablename__ = "chat_message_feedbacks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_message_id = Column(String(36), nullable=False)
    feedback = Column(
        Enum("like", "dislike", name="chat_message_feedback"), nullable=False
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ChatCanvas(Base):
    __tablename__ = "chat_canvas"

    uuid = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    chat_id = Column(String(36), nullable=False)
    title = Column(String(100), nullable=True)
    content = Column(Text, nullable=True)
    file_extension = Column(
        String(10), nullable=True, comment="다운로드할 파일 형식 (docx, xlsx 등)"
    )
    current_version = Column(BIGINT, nullable=False)
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    type = Column(String(15), nullable=False)


class CanvasDelta(Base):
    __tablename__ = "canvas_deltas"

    id = Column(BIGINT, primary_key=True, autoincrement=True)
    canvas_uuid = Column(String(36), ForeignKey("chat_canvas.uuid"), nullable=False)
    diff = Column(
        JSONB, nullable=False, comment="delta와 raw_delta 리스트를 포함하는 JSON"
    )
    version = Column(BIGINT, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
