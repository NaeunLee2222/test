from database.base import Base
from sqlalchemy import JSON, Column, DateTime, String
from sqlalchemy.sql import func


class ChatTaskAgentState(Base):
    __tablename__ = "chat_task_agent_states"

    chat_message_id = Column(String, primary_key=True)
    state = Column(JSON, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
