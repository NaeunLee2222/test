from database.base import Base
from sqlalchemy import Column, DateTime, Integer, String, Text
from sqlalchemy.sql import func


class ChatDocuments(Base):
    __tablename__ = "chat_documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, nullable=False)
    chat_id = Column(String(36), nullable=False)

    original_filename = Column(String(255), nullable=False)
    uuid_filename = Column(String(64), nullable=False)
    file_type = Column(String(255), nullable=True)
    state = Column(
        String(50), nullable=False, default="UPLOAD"
    )  # UPLOAD, WAIT, READY, FAILURE, DELETED

    index_name = Column(Text, nullable=True)
    blob_uri = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
