from database.base import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text
from sqlalchemy.sql import func


class TaskAgent(Base):
    __tablename__ = "task_agents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_agent_name = Column(String(100), unique=True, nullable=False)
    task_agent_url = Column(String(255), unique=False, nullable=False)
    description = Column(Text)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
