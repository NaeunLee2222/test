from database.models.chat import Chat, ChatMessage  # 모델 임포트
from sqlalchemy import event
from sqlalchemy.sql import func


@event.listens_for(ChatMessage, "after_insert")
def update_chat_updated_at(mapper, connection, target):
    connection.execute(
        Chat.__table__.update()
        .where(Chat.id == target.chat_id)
        .values(updated_at=func.now())
    )
