from database.crud.base import CRUDBaseAsync
from database.models.usage import Usage
from sqlalchemy.ext.asyncio import AsyncSession

from sqlalchemy import select
from typing import Union
from services.schemas.usage import UsageDetail, UsageUpdate, UsageCreate


class CRUDUsage(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Usage)

    async def get_usage_by_user_id(
        self, db: AsyncSession, user_id: int
    ) -> Union[Usage, None]:
        usage_query = select(Usage).filter(Usage.user_id == user_id)
        usage_result = await db.execute(usage_query)
        usage = usage_result.scalar_one_or_none()
        return usage

    async def create_usage(self, db: AsyncSession, usage: Usage) -> Usage:
        db.add(usage)
        await db.commit()
        await db.refresh(usage)
        return usage

    async def update_usage(
        self, db: AsyncSession, user_id: int, usage_update: UsageUpdate
    ) -> Usage:
        try:
            existing_usage = await self.get_usage_by_user_id(db, user_id)
            if not existing_usage:
                return None

            existing_usage.user_limit = usage_update.user_limit
            existing_usage.org_limit = usage_update.org_limit
            existing_usage.query_text_limit = usage_update.query_text_limit
            existing_usage.answer_token_limit = usage_update.answer_token_limit
            db.add(existing_usage)
            await db.commit()
            await db.refresh(existing_usage)
            return existing_usage
        except Exception as e:
            await db.rollback()
            raise e
