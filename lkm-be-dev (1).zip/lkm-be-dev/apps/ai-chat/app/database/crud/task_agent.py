from typing import Optional

from database.models.task_agent import TaskAgent
from services.schemas.task_agent import TaskAgentCreate, TaskAgentUpdate
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select


# 비동기 ApiSpec 생성
async def create_task_agent(db: AsyncSession, task_agent: TaskAgentCreate):
    db_task_agent = TaskAgent(
        task_agent_name=task_agent.task_agent_name,
        task_agent_url=task_agent.task_agent_url,
        description=task_agent.description,
    )
    db.add(db_task_agent)
    await db.commit()  # 비동기 커밋
    await db.refresh(db_task_agent)  # 비동기 refresh
    return db_task_agent


# 비동기 ApiSpec 리스트 조회
async def get_task_agent(db: AsyncSession, task_agent_id: int):
    result = await db.execute(select(TaskAgent).filter(TaskAgent.id == task_agent_id))
    task_agent = result.scalar_one_or_none()  # 단일 결과만 가져옴
    return task_agent


# 비동기 ApiSpec 리스트 조회, 선택적으로 service_category 필터링
async def get_task_agents(
    db: AsyncSession,
    skip: int = 0,
    limit: int = 10,
    task_agent_name: Optional[str] = None,
) -> TaskAgent:
    query = select(TaskAgent)

    if task_agent_name:
        query = query.where(TaskAgent.task_agent_name == task_agent_name)

    result = await db.execute(query.offset(skip).limit(limit))
    return result.scalars().all()


# async def get_task_agent(db: AsyncSession, api_spec_id: int):
#     result = await db.execute(select(TaskAgent).where(TaskAgent.id == api_spec_id))
#     return result.scalars().first()


# 비동기 ApiSpec 업데이트
async def update_task_agent(
    db: AsyncSession, task_agent_id: int, task_agent_update: TaskAgentUpdate
):
    try:
        db_task_agent = await get_task_agent(db, task_agent_id)
        if not db_task_agent:
            return None

        update_data = task_agent_update.dict(exclude_unset=True)

        # update_data를 사용하여 db_task_agent 업데이트
        for key, value in update_data.items():
            if hasattr(db_task_agent, key):
                setattr(db_task_agent, key, value)

        await db.commit()
        await db.refresh(db_task_agent)
        return db_task_agent
    except Exception as e:
        await db.rollback()
        raise e


# 비동기 ApiSpec 삭제
async def delete_task_agent(db: AsyncSession, task_agent_id: int):
    try:
        db_task_agent = await get_task_agent(db, task_agent_id)
        if not db_task_agent:
            return False

        await db.delete(db_task_agent)
        await db.commit()
        return True
    except Exception as e:
        await db.rollback()
        raise e
