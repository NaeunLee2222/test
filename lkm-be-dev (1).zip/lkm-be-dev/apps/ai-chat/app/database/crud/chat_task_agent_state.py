from database.models.chat_task_agent_state import ChatTaskAgentState
from services.schemas.chat_task_agent_state import (
    ChatTaskAgentStateCreate,
    ChatTaskAgentStateUpdate,
)
from sqlalchemy import delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select


# Create a new chat task agent state
async def create_chat_task_agent_state(
    db: AsyncSession, state: ChatTaskAgentStateCreate
):
    db_state = ChatTaskAgentState(
        chat_message_id=state.chat_message_id,
        state=state.state,
    )
    db.add(db_state)
    await db.commit()
    await db.refresh(db_state)
    return db_state


# Get a chat task agent state by chat_message_uuid
async def get_chat_task_agent_state(db: AsyncSession, chat_message_id: str):
    result = await db.execute(
        select(ChatTaskAgentState).filter(
            ChatTaskAgentState.chat_message_id == chat_message_id
        )
    )
    return result.scalars().first()


# Update an existing chat task agent state
async def update_chat_task_agent_state(
    db: AsyncSession, chat_message_id: str, state_update: ChatTaskAgentStateUpdate
):
    db_state = await get_chat_task_agent_state(db, chat_message_id)
    if not db_state:
        return None
    for var, value in vars(state_update).items():
        setattr(db_state, var, value) if value is not None else None
    await db.commit()
    await db.refresh(db_state)
    return db_state


# Delete a chat task agent state
async def delete_chat_task_agent_state(db: AsyncSession, chat_message_id: str):
    db_state = await get_chat_task_agent_state(db, chat_message_id)
    if db_state:
        await db.execute(
            delete(ChatTaskAgentState).filter(
                ChatTaskAgentState.chat_message_id == chat_message_id
            )
        )
        await db.commit()
    return db_state
