from database.crud.base import CRUDBaseAsync
from database.models.chat_documents import ChatDocuments
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select


class CRUDDocuments(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ChatDocuments)

    async def get_document_with_chatid(
        self, db: AsyncSession, chat_id: str, doc_id: int
    ):
        """chat ID와 document ID로 document 상태 조회"""
        query = select(ChatDocuments).filter(
            ChatDocuments.chat_id == chat_id, ChatDocuments.id == doc_id
        )
        result = await db.execute(query)
        return result.scalars().first()
