from core.log.logging import get_logging
from database.crud.base import CRUDBaseAsync
from database.models.chat import Chat
from services.schemas.chat import ChatCreateWithId
from sqlalchemy import func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

logger = get_logging()


class CRUDChat(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Chat)

    async def get_chat_by_user_id(
        self,
        db: AsyncSession,
        user_id: int,
        skip: int,
        limit: int,
        sort: str,
        order: str,
    ):
        chat_query = (
            select(Chat)
            .filter(Chat.user_id == user_id)
            .order_by(
                getattr(Chat, sort).desc().nulls_last()
                if order == "desc"
                else getattr(Chat, sort).asc().nulls_last()
            )
            .offset(skip)
            .limit(limit)
        )
        chat_result = await db.execute(chat_query)
        chats = chat_result.scalars().all()

        total_query = (
            select(func.count()).select_from(Chat).filter(Chat.user_id == user_id)
        )
        total_result = await db.execute(total_query)
        total = total_result.scalar_one()

        return chats, total

    async def get_or_create_chat(
        self,
        db: AsyncSession,
        chat_data: ChatCreateWithId,
    ):
        try:
            # 먼저 기존 채팅방이 있는지 확인
            result = await db.execute(select(Chat).filter(Chat.id == chat_data.id))
            db_chat = result.scalars().first()
            logger.info(f"existing chat: {db_chat}")

            # 채팅방이 없으면 새로 생성
            if db_chat is None:
                db_chat = Chat(
                    id=chat_data.id,
                    user_id=chat_data.user_id,
                    title=chat_data.title,
                    model=chat_data.model,
                    config=chat_data.config,
                    chat_type=chat_data.chat_type,
                )
                db.add(db_chat)
                await db.commit()
                await db.refresh(db_chat)
                logger.info(f"new chat: {db_chat}")
            else:
                # 채팅방이 존재하면, SELECT 로 시작된 트랜잭션을 커밋합니다.
                await db.commit()

            return db_chat
        except Exception:
            await db.rollback()
            raise

    # async def update_chat_type(
    #     self,
    #     db: AsyncSession,
    #     chat_id: str,
    #     chat_type: str,
    # ):
    #     """채팅의 chat_type을 업데이트합니다."""
    #     try:
    #         result = await db.execute(select(Chat).filter(Chat.id == chat_id))
    #         db_chat = result.scalars().first()

    #         if db_chat and db_chat.chat_type != chat_type:
    #             db_chat.chat_type = chat_type
    #             await db.commit()
    #             await db.refresh(db_chat)
    #             logger.info(f"Chat type updated to {chat_type} for chat {chat_id}")

    #         return db_chat
    #     except Exception as e:
    #         logger.error(f"Failed to update chat type: {e}")
    #         await db.rollback()
    #         raise
