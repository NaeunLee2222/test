import aiohttp
from core.config import get_setting
from core.log.logging import get_logging

logger = get_logging()
setting = get_setting()


class APIExpertAgent:
    def __init__(self):
        if setting.ENVIRONMENT == "LOCAL":
            url = f"http://localhost:8030/task-agent/"
        else:
            url = "http://task-agent:8030/task-agent/"
        self.base_url = "http://task-agent:8030/task-agent/"  # url
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
            "Accept": "application/json",
        }

    async def get_expert_agent_by_id(self, agent_id: int):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url=f"{self.base_url}agents/{agent_id}", headers=self.headers
                ) as response:
                    response.raise_for_status()
                    return await response.json()
        except Exception as e:
            logger.error(f"Error getting expert agent: {e}")
            return False
