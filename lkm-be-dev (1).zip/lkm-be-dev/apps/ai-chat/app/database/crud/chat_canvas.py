from typing import List, Optional

from core.log.logging import get_logging
from database.crud.base import CRUDBaseAsync
from database.models.chat import CanvasDelta, Chat, ChatCanvas
from sqlalchemy import delete, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

logger = get_logging()


class CRUDCanvas(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ChatCanvas)

    async def get_canvases_by_chat_id(
        self, db: AsyncSession, chat_id: str
    ) -> List[ChatCanvas]:
        """채팅 ID로 모든 캔버스 조회"""
        result = await db.execute(
            select(ChatCanvas)
            .filter(ChatCanvas.chat_id == chat_id)
            .order_by(ChatCanvas.created_at.desc())
        )
        return result.scalars().all()

    async def get_canvas(
        self, db: AsyncSession, canvas_uuid: str
    ) -> Optional[ChatCanvas]:
        result = await db.execute(
            select(ChatCanvas).filter(ChatCanvas.uuid == canvas_uuid)
        )
        return result.scalars().first()

    async def get_total_canvas_by_user_id(
        self,
        db: AsyncSession,
        user_id: int,
        type: Optional[str] = None,
        title: Optional[str] = None,
    ) -> int:
        stmt = (
            select(ChatCanvas)
            .join(Chat, ChatCanvas.chat_id == Chat.id)
            .where(Chat.user_id == user_id)
        )
        if type is not None:
            stmt = stmt.where(ChatCanvas.type == type)
        if title is not None:
            stmt = stmt.where(ChatCanvas.title.ilike(f"%{title}%"))
        result = await db.execute(stmt)
        total = len(list(result.scalars().all()))
        logger.info(f"total: {total}")
        return total

    async def get_canvases_by_user_id_with_chat_join(
        self,
        db: AsyncSession,
        *,
        user_id: int,
        skip: int = 0,
        limit: int = 20,
        order: Optional[str] = None,
        title: Optional[str] = None,
        type: Optional[str] = None,
    ) -> List[ChatCanvas]:
        """사용자 ID로 캔버스 조회 (Chat 테이블과 조인하여 해당 유저의 채팅에 속한 캔버스만 조회)"""
        stmt = (
            select(ChatCanvas)
            .join(Chat, ChatCanvas.chat_id == Chat.id)
            .where(Chat.user_id == user_id)
        )

        # 제목 필터링
        if title is not None:
            stmt = stmt.where(ChatCanvas.title.ilike(f"%{title}%"))
        # 타입 필터링 - 정확한 값 매칭으로 변경
        if type is not None:
            stmt = stmt.where(ChatCanvas.type == type)
        # 정렬
        if order is not None:
            if order == "title_asc":
                stmt = stmt.order_by(ChatCanvas.title.asc())
            elif order == "title_desc":
                stmt = stmt.order_by(ChatCanvas.title.desc())
            elif order == "latest":
                stmt = stmt.order_by(ChatCanvas.updated_at.desc())
        else:
            # 기본 정렬: 최신순
            stmt = stmt.order_by(ChatCanvas.updated_at.desc())

        # 페이징은 모든 필터링과 정렬 후에 적용
        stmt = stmt.offset(skip).limit(limit)

        result = await db.execute(stmt)
        return list(result.scalars().all())

    async def delete_by_uuid(self, db: AsyncSession, canvas_uuid: str) -> None:
        """캔버스 UUID로 캔버스 삭제"""
        await db.execute(delete(ChatCanvas).filter(ChatCanvas.uuid == canvas_uuid))
        await db.commit()


class CRUDCanvasDelta(CRUDBaseAsync):
    def __init__(self):
        super().__init__(CanvasDelta)

    async def get_deltas_by_canvas_uuid(
        self, db: AsyncSession, canvas_uuid: str
    ) -> List[CanvasDelta]:
        """캔버스 UUID로 모든 델타 조회"""
        result = await db.execute(
            select(CanvasDelta)
            .filter(CanvasDelta.canvas_uuid == canvas_uuid)
            .order_by(CanvasDelta.version)
        )
        return result.scalars().all()

    async def get_deltas_by_canvas_uuid_paginated(
        self, db: AsyncSession, canvas_uuid: str, skip: int = 0, limit: int = 20
    ) -> tuple[List[CanvasDelta], int]:
        """캔버스 UUID로 델타 조회 (버전 역순, 페이징 지원)"""
        # 전체 개수 조회 (더 효율적인 count 쿼리)
        count_result = await db.execute(
            select(func.count(CanvasDelta.id)).filter(
                CanvasDelta.canvas_uuid == canvas_uuid
            )
        )
        total = count_result.scalar() or 0

        # 페이징된 결과 조회 (버전 역순)
        result = await db.execute(
            select(CanvasDelta)
            .filter(CanvasDelta.canvas_uuid == canvas_uuid)
            .order_by(CanvasDelta.version.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all(), total

    async def get_delta(
        self, db: AsyncSession, canvas_uuid: str, version: int
    ) -> Optional[CanvasDelta]:
        result = await db.execute(
            select(CanvasDelta).filter(
                CanvasDelta.canvas_uuid == canvas_uuid, CanvasDelta.version == version
            )
        )
        return result.scalars().first()

    async def delete_by_canvas_uuid(self, db: AsyncSession, canvas_uuid: str) -> None:
        """캔버스 UUID로 모든 델타 삭제"""
        await db.execute(
            delete(CanvasDelta).filter(CanvasDelta.canvas_uuid == canvas_uuid)
        )
        await db.commit()
