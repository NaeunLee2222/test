from typing import List

from core.log.logging import get_logging
from core.security import get_password_hash
from database.crud.base import CRUDBaseAsync
from database.models.user import Organization, Team, User, UserMemory, UserPreference
from services.schemas.user import (
    UserCreate,
    UserMemoryUpdateRequest,
    UserPasswordUpdate,
    UserUpdate,
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

logger = get_logging()


class CRUDUser(CRUDBaseAsync):
    def __init__(self):
        super().__init__(User)

    async def get_user_by_user_id(self, db: AsyncSession, user_id: int):
        result = await db.execute(select(User).filter(User.id == user_id))
        return result.scalars().first()

    async def get_user_by_email(self, db: AsyncSession, email: str):
        result = await db.execute(select(User).filter(User.email == email))
        return result.scalars().first()

    async def get_multi_filtered_user(
        self,
        db: AsyncSession,
        *,
        skip: int = 0,
        limit: int = 100,
        search: str = None,
        is_activated: bool = None,
        role: str = None,
        order: str = None,
    ):
        query = select(User)

        if search:
            query = query.filter(
                (User.email.ilike(f"%{search}%")) | (User.username.ilike(f"%{search}%"))
            )

        if is_activated is not None:
            query = query.filter(User.is_activated == is_activated)
        if role:
            query = query.filter(User.role == role)

        # Get total count before pagination
        count_query = select(User)
        if search:
            count_query = count_query.filter(
                (User.email.ilike(f"%{search}%")) | (User.username.ilike(f"%{search}%"))
            )
        if is_activated is not None:
            count_query = count_query.filter(User.is_activated == is_activated)
        if role:
            count_query = count_query.filter(User.role == role)

        total_result = await db.execute(count_query)
        total = len(total_result.scalars().all())

        # Apply ordering and pagination
        if order == "name_asc":
            query = query.order_by(User.username.asc())
        elif order == "name_desc":
            query = query.order_by(User.username.desc())
        elif order == "org_asc":
            query = query.order_by(User.organization_id.asc())
        elif order == "org_desc":
            query = query.order_by(User.organization_id.desc())
        else:
            query = query.order_by(User.id.asc())
        query = query.offset(skip).limit(limit)

        result = await db.execute(query)
        return result.scalars().all(), total

    async def get_all_users(self, db: AsyncSession) -> List[User]:
        result = await db.execute(select(User).order_by(User.id))
        return result.scalars().all()

    async def create_user(self, db: AsyncSession, user: UserCreate) -> User:
        db_user = User(
            email=user.email,
            username=user.username,
            hashed_password=get_password_hash(user.password),
            organization_id=user.organization_id,
            team_id=user.team_id,
            role=user.role,
            is_activated=user.is_activated,
        )
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        return db_user

    async def update_user(self, db: AsyncSession, user: UserUpdate) -> User:
        db_user = await self.get_user_by_user_id(db, user.id)
        # db_user = await self.get_user_by_email(db, user.email)
        # if not db_user:
        #     return None

        update_data = user.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_user, field, value)

        await db.commit()
        await db.refresh(db_user)

        return db_user

    async def update_user_password(
        self, db: AsyncSession, user: UserPasswordUpdate
    ) -> User:
        db_user = await self.get_user_by_user_id(db, user.id)
        if not db_user:
            return None

        db_user.hashed_password = get_password_hash(user.password)
        await db.commit()
        await db.refresh(db_user)

        return db_user


class CRUDOrganization(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Organization)

    async def get_organization_by_name(self, db: AsyncSession, name: str):
        result = await db.execute(
            select(Organization).filter(Organization.name == name)
        )
        return result.scalars().first()

    async def get_organization_by_id(self, db: AsyncSession, id: int):
        result = await db.execute(select(Organization).filter(Organization.id == id))
        return result.scalars().first()

    async def get_all_organizations(self, db: AsyncSession) -> List[Organization]:
        result = await db.execute(select(Organization))
        return result.scalars().all()


class CRUDTeam(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Team)

    async def get_teams_by_organization_id(
        self, db: AsyncSession, organization_id: int
    ):
        result = await db.execute(
            select(Team)
            .filter(Team.organization_id == organization_id)
            .order_by(Team.name)
        )
        return result.scalars().all()

    async def get_team_by_name(self, db: AsyncSession, name: str):
        result = await db.execute(select(Team).filter(Team.name == name))
        return result.scalars().first()


class CRUDUserPreference(CRUDBaseAsync):
    def __init__(self):
        super().__init__(UserPreference)

    async def get_user_preference(
        self, db: AsyncSession, user_id: int, agent_id: int
    ) -> UserPreference:
        result = await db.execute(
            select(UserPreference).filter(
                UserPreference.user_id == user_id, UserPreference.agent_id == agent_id
            )
        )
        user_preference = result.scalars().first()
        return user_preference

    async def get_user_preference_by_id(
        self, db: AsyncSession, user_preference_id: int
    ) -> UserPreference:
        result = await db.execute(
            select(UserPreference).filter(UserPreference.id == user_preference_id)
        )
        user_preference = result.scalars().first()
        return user_preference

    async def create_user_preference(
        self, db: AsyncSession, user_id: int, agent_id: int
    ) -> UserPreference:
        # 기본 (유저,에이전트) 설정 생성
        # predefined_prompt 기본값은 Null로 설정
        user_preference = UserPreference(user_id=user_id, agent_id=agent_id)
        db.add(user_preference)
        await db.commit()
        await db.refresh(user_preference)
        return user_preference

    async def update_user_preference(
        self, db: AsyncSession, user_preference: UserPreference
    ) -> UserPreference:
        # 기존 (유저,에이전트) 설정 유무 확인
        existing_user_preference = await self.get_user_preference_by_id(
            db, user_preference.id
        )
        # 업데이트
        update_fields = {"predefined_prompt", "temperature", "use_memory"}
        for field in update_fields:
            if (
                hasattr(user_preference, field)
                and getattr(user_preference, field) is not None
                and getattr(user_preference, field) != ""
            ):
                setattr(
                    existing_user_preference, field, getattr(user_preference, field)
                )

        await db.commit()
        await db.refresh(existing_user_preference)
        return existing_user_preference

    async def get_user_preference_by_user_id(
        self, db: AsyncSession, user_id: int
    ) -> List[UserPreference]:
        ## 유저의 모든 설정 조회
        ## 언젠가 필요할까봐
        result = await db.execute(
            select(UserPreference).filter(UserPreference.user_id == user_id)
        )
        return result.scalars().all()

    async def delete_user_preference(
        self, db: AsyncSession, user_id: int, agent_id: int
    ):
        result = await db.execute(
            select(UserPreference).filter(
                UserPreference.user_id == user_id, UserPreference.agent_id == agent_id
            )
        )
        user_preference = result.scalars().first()
        if not user_preference:
            return False
        await db.delete(user_preference)
        await db.commit()
        return True


class CRUDUserMemory(CRUDBaseAsync):
    def __init__(self):
        super().__init__(UserMemory)

    async def get_user_memory_by_id(self, db: AsyncSession, user_memory_id: int):
        result = await db.execute(
            select(UserMemory).filter(UserMemory.id == user_memory_id)
        )
        return result.scalars().first()

    async def get_user_memory(self, db: AsyncSession, user_id: int, agent_id: int):
        result = await db.execute(
            select(UserMemory).filter(
                UserMemory.user_id == user_id, UserMemory.agent_id == agent_id
            )
        )
        return result.scalars().all()

    async def get_user_memory_by_user_id(self, db: AsyncSession, user_id: int):
        result = await db.execute(
            select(UserMemory).filter(UserMemory.user_id == user_id)
        )
        return result.scalars().all()

    async def create_user_memory(
        self, db: AsyncSession, user_id: int, agent_id: int, contents: str
    ):
        user_memory = UserMemory(user_id=user_id, agent_id=agent_id, contents=contents)
        db.add(user_memory)
        await db.commit()
        await db.refresh(user_memory)
        return user_memory

    async def update_user_memory(
        self,
        db: AsyncSession,
        user_memory_id: int,
        user_memory: UserMemoryUpdateRequest,
    ):
        # 기존 메모리 조회
        existing_user_memory = await self.get_user_memory_by_id(db, user_memory_id)
        logger.info(f"existing_user_memory: {existing_user_memory}")

        update_fields = {"contents"}
        for field in update_fields:
            if (
                hasattr(user_memory, field)
                and getattr(user_memory, field) is not None
                and getattr(user_memory, field) != ""
            ):
                setattr(existing_user_memory, field, getattr(user_memory, field))

        await db.commit()
        await db.refresh(existing_user_memory)
        return existing_user_memory

    async def delete_user_memory(self, db: AsyncSession, user_memory_id: int):
        # 기존 메모리 조회
        existing_user_memory = await self.get_user_memory_by_id(db, user_memory_id)
        if not existing_user_memory:
            return False

        await db.delete(existing_user_memory)
        await db.commit()
        return True

    async def delete_all_user_memory(
        self, db: AsyncSession, user_id: int, agent_id: int
    ):
        # 기존 메모리 조회
        existing_user_memory = await self.get_user_memory(db, user_id, agent_id)
        if existing_user_memory:
            for memory in existing_user_memory:
                await db.delete(memory)
            await db.commit()
        return True
