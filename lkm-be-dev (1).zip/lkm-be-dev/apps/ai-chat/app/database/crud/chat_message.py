from typing import List, Optional

from core.log.logging import get_logging
from database.crud.base import CRUDBaseAsync
from database.models.chat import ChatMessage, ChatMessageFeedback
from services.schemas.chat_message import ChatMessageFeedbackRequest
from sqlalchemy import asc, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

logger = get_logging()


class CRUDChatMessage(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ChatMessage)

    # Get all chat messages for a chat room
    async def get_chat_messages_by_chat_id(
        self, db: AsyncSession, chat_id: str, skip: int = 0
    ) -> List[ChatMessage]:
        result = await db.execute(
            select(ChatMessage)
            .filter(ChatMessage.chat_id == chat_id)
            .order_by(asc(ChatMessage.created_at))  # 날짜 오름차순 정렬
            .offset(skip)
        )
        return list(result.scalars().all())

    # Delete all chat messages for a chat room
    async def delete_chat_messages_by_chat_id(
        self, db: AsyncSession, chat_id: str
    ) -> List[ChatMessage]:
        db_chat_messages = await self.get_chat_messages_by_chat_id(db, chat_id)
        if db_chat_messages:
            # Use bulk delete instead of individual deletes
            await db.execute(delete(ChatMessage).where(ChatMessage.chat_id == chat_id))
            await db.commit()
        return db_chat_messages


class CRUDChatMessageFeedback(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ChatMessageFeedback)

    async def get_message_feedback(
        self, db: AsyncSession, id: int
    ) -> Optional[ChatMessageFeedback]:
        result = await db.execute(
            select(ChatMessageFeedback).filter(ChatMessageFeedback.id == id)
        )
        return result.scalars().first()

    async def get_message_feedback_by_message_id(
        self, db: AsyncSession, message_id: str
    ) -> Optional[ChatMessageFeedback]:
        result = await db.execute(
            select(ChatMessageFeedback).filter(
                ChatMessageFeedback.chat_message_id == message_id
            )
        )
        return result.scalars().first()

    async def create_message_feedback(
        self, db: AsyncSession, feedback_data: ChatMessageFeedbackRequest
    ) -> ChatMessageFeedback:
        return await self.create(
            db,
            {
                "chat_message_id": feedback_data.chat_message_id,
                "feedback": feedback_data.feedback.value,
            },
        )
