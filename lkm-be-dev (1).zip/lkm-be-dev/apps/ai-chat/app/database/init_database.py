from core.config import get_setting
from core.log.logging import get_logging
from database.base import Base
from database.session import async_engine

settings = get_setting()
logger = get_logging()


async def initialize_database() -> None:
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info(f"Connected to database: {async_engine.url}")


async def close_database_connections() -> None:
    await async_engine.dispose()
