from sqlalchemy.ext.declarative import declarative_base

# SQLAlchemy Base 모델
Base = declarative_base()
