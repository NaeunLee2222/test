import jwt
from core.config import get_setting
from core.log.logging import get_logging
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from redis import StrictRedis
from redis.sentinel import Sentinel
from services.schemas.auth import UserInfo

settings = get_setting()
logger = get_logging()

security = HTTPBearer(auto_error=False)


def get_redis():
    if settings.REDIS_USE_SENTINEL:
        # Redis Sentinel을 통한 연결
        sentinel = Sentinel(
            [(settings.REDIS_SENTINEL_HOST, settings.REDIS_SENTINEL_PORT)],
            password=settings.REDIS_SENTINEL_PASSWORD,
            decode_responses=True,
        )
        r = sentinel.master_for(
            settings.REDIS_SENTINEL_MASTER_NAME,
            password=settings.REDIS_ACCESS_KEY,
            db=settings.REDIS_USER_INFO_DB,
        )
    else:
        # 직접 Redis 연결
        r = StrictRedis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            password=settings.REDIS_ACCESS_KEY,
            ssl=settings.REDIS_USE_SSL,
            ssl_cert_reqs="none",
            decode_responses=True,
        )

    try:
        yield r
    finally:
        r.close()


async def validate_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
) -> UserInfo:
    try:

        if not credentials or not credentials.credentials:
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.NO_TOKEN,
                detail="Authentication failed. Please log in again.",
            )

        token = credentials.credentials

        # JWT 토큰 검증 및 페이로드 추출
        try:
            payload = jwt.decode(
                token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM]
            )

            # token_type 확인
            if payload.get("token_type") != "access":
                raise ServiceException(
                    status_code=401,
                    error_code=ErrorCode.INVALID_AUTH,
                    detail="Invalid token type",
                )

        except jwt.ExpiredSignatureError:
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.TOKEN_EXPIRED,
                detail="Token has expired",
            )
        except jwt.PyJWTError:
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.INVALID_AUTH,
                detail="Invalid token",
            )

        # JWT 페이로드에서 사용자 정보 반환
        user_info = UserInfo.model_validate(payload)
        return user_info

    except Exception as e:
        logger.error(f"인증 처리 중 오류 발생: {str(e)}")
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail="인증에 실패했습니다. 다시 로그인해주세요.",
        )
