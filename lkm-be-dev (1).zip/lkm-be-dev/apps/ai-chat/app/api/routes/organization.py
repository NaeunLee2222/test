from typing import List
from database.crud.user import CRUDOrganization, CRUDTeam
from database.session import get_async_db
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import APIRouter, Depends
from services.schemas.organization import (
    OrganizationCreateRequest, OrganizationCreate, 
    OrganizationUpdateRequest, OrganizationUpdate,
    OrganizationResponse, TeamResponse,
    TeamCreateRequest, TeamCreate,
    TeamUpdateRequest, TeamUpdate,
    OrganizationWithTeamsResponse
)
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()

crud_organization = CRUDOrganization()
crud_team = CRUDTeam()


# === 조직(Organization) API ===

@router.post("/", response_model=OrganizationResponse, summary="Create a new organization")
async def create_organization(
    org_data: OrganizationCreateRequest,
    db: AsyncSession = Depends(get_async_db),
):
    """새로운 조직을 생성합니다."""

    # 중복 체크
    existing_org = await crud_organization.get_organization_by_name(db, org_data.name)
    if existing_org:
        raise ServiceException(
            status_code=400,
            error_code=ErrorCode.DUPLICATE_ENTITY,
            detail="이미 존재하는 조직명입니다."
        )

    # 생성 요청을 내부 모델로 변환
    org_create = OrganizationCreate(
        name=org_data.name,
        description=org_data.description
    )

    # 조직 생성
    organization = await crud_organization.create(db, obj_in=org_create.model_dump())
    return organization

@router.get("/all", response_model=List[OrganizationResponse], summary="Get all organizations")
async def get_all_organizations(
    db: AsyncSession = Depends(get_async_db),
):
    """모든 조직 목록을 가져옵니다."""
    organizations = await crud_organization.get_all_organizations(db)
    return organizations

@router.get("/{org_id}", response_model=OrganizationResponse, summary="Get organization by ID")
async def get_organization(
    org_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    """조직 정보를 가져옵니다."""
    organization = await crud_organization.get(db, org_id)
    if not organization:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="조직을 찾을 수 없습니다."
        )

    return organization

@router.get("/{org_id}/with-teams", response_model=OrganizationWithTeamsResponse, summary="Get organization with teams")
async def get_organization_with_teams(
    org_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    """조직 정보와 소속 팀 목록을 함께 가져옵니다."""
    organization = await crud_organization.get(db, org_id)
    if not organization:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="조직을 찾을 수 없습니다."
        )

    teams = await crud_team.get_teams_by_organization_id(db, org_id)

    # 확장된 응답 생성
    result = OrganizationWithTeamsResponse.model_validate(organization)
    result.teams = teams

    return result


@router.put("/{org_id}", response_model=OrganizationResponse, summary="Update organization")
async def update_organization(
    org_id: int,
    org_data: OrganizationUpdateRequest,
    db: AsyncSession = Depends(get_async_db),
):
    """조직 정보를 업데이트합니다."""

    # 존재 여부 확인
    existing_org = await crud_organization.get(db, org_id)
    if not existing_org:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="조직을 찾을 수 없습니다."
        )

    # 업데이트 요청을 내부 모델로 변환
    org_update = OrganizationUpdate(**org_data.model_dump(exclude_unset=True))

    # 조직 업데이트
    updated_org = await crud_organization.update(db, db_obj=existing_org, obj_in=org_update.model_dump())
    return updated_org


@router.delete("/{org_id}", summary="Delete organization")
async def delete_organization(
    org_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    """조직을 삭제합니다."""

    # 존재 여부 확인
    existing_org = await crud_organization.get(db, org_id)
    if not existing_org:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="조직을 찾을 수 없습니다."
        )

    # 조직 삭제
    await crud_organization.delete(db, id=org_id)

    return {"message": "조직이 성공적으로 삭제되었습니다."}


# === 팀(Team) API ===

@router.post("/teams", response_model=TeamResponse, summary="Create a new team")
async def create_team(
    team_data: TeamCreateRequest,
    db: AsyncSession = Depends(get_async_db),
):
    """새로운 팀을 생성합니다."""

    # 조직 존재 여부 확인
    organization = await crud_organization.get(db, team_data.organization_id)
    if not organization:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="소속 조직을 찾을 수 없습니다."
        )

    # 동일 조직 내 중복 팀명 체크
    existing_team = await crud_team.get_team_by_name(db, team_data.name)
    if existing_team and existing_team.organization_id == team_data.organization_id:
        raise ServiceException(
            status_code=400,
            error_code=ErrorCode.DUPLICATE_ENTITY,
            detail="해당 조직에 이미 존재하는 팀명입니다."
        )

    # 생성 요청을 내부 모델로 변환
    team_create = TeamCreate(
        name=team_data.name,
        organization_id=team_data.organization_id,
        description=team_data.description
    )

    # 팀 생성
    team = await crud_team.create(db, obj_in=team_create.model_dump())
    return team


@router.get("/teams/{team_id}", response_model=TeamResponse, summary="Get team by ID")
async def get_team(
    team_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    """팀 정보를 가져옵니다."""
    team = await crud_team.get(db, team_id)
    if not team:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="팀을 찾을 수 없습니다."
        )

    return team


@router.put("/teams/{team_id}", response_model=TeamResponse, summary="Update team")
async def update_team(
    team_id: int,
    team_data: TeamUpdateRequest,
    db: AsyncSession = Depends(get_async_db),
):
    """팀 정보를 업데이트합니다."""

    # 존재 여부 확인
    existing_team = await crud_team.get(db, team_id)
    if not existing_team:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="팀을 찾을 수 없습니다."
        )

    # 조직 변경 시 존재 여부 확인
    if team_data.organization_id is not None:
        organization = await crud_organization.get(db, team_data.organization_id)
        if not organization:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="변경하려는 소속 조직을 찾을 수 없습니다."
            )

    # 업데이트 요청을 내부 모델로 변환
    team_update = TeamUpdate(**team_data.model_dump(exclude_unset=True))

    # 팀 업데이트
    updated_team = await crud_team.update(db, db_obj=existing_team, obj_in=team_update.model_dump())
    return updated_team


@router.delete("/teams/{team_id}", summary="Delete team")
async def delete_team(
    team_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    """팀을 삭제합니다."""

    # 존재 여부 확인
    existing_team = await crud_team.get(db, team_id)
    if not existing_team:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="팀을 찾을 수 없습니다."
        )

    # 팀 삭제
    await crud_team.delete(db, id=team_id)

    return {"message": "팀이 성공적으로 삭제되었습니다."}