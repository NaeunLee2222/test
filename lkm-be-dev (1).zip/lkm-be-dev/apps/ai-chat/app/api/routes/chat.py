import aiohttp
from core.config import get_setting
from core.log.logging import get_logging
from core.utils.model import get_model_names as get_model_names_service
from database.session import get_async_db
from fastapi import APIRouter, Body, Depends, HTTPException, Path, Query
from fastapi.responses import JSONResponse
from services import chat
from services.chat import ChatMessageFeedbackService, ChatTitleService
from services.schemas.chat import (
    Chat,
    ChatCreateWithId,
    ChatListResponse,
    ChatPatchRequest,
)
from services.schemas.chat_message import (
    ChatMessage,
    ChatMessageCreateRequest,
    ChatMessageFeedbackRequest,
    ChatMessageFeedbackResponse,
    ChatMessagePatchRequest,
)
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()
router = APIRouter()
settings = get_setting()

chat_message_feedback_service = ChatMessageFeedbackService()
chat_title_service = ChatTitleService()


@router.get("/models", summary="Return available LLM model information")
async def get_model_names():
    """
    사용 가능한 LLM 모델 정보 반환

    Returns:
    - List[dict]: 사용 가능한 LLM 모델 정보 리스트 (name, description 포함)
    """
    try:
        model_names = get_model_names_service()
        return JSONResponse(content=model_names)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Chat 관련 API
# TODO Filtering 추가 (Config 바탕으로 Agent 제작용 검증 Chat인지 그냥 Chat인지 구분)
@router.get(
    "", response_model=ChatListResponse, summary="Retrieve chat history by user"
)
async def get_chat_by_user_id(
    user_id: int,
    # user_info: UserInfo = Depends(validate_user),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    sort: str = Query(
        "updated_at",
        enum=["created_at", "updated_at"],
        description="정렬 기준: 생성일/수정일",
    ),
    order: str = Query(
        "desc",
        enum=["asc", "desc"],
    ),
    db: AsyncSession = Depends(get_async_db),
):
    """
    유저의 채팅 목록 조회

    Query Args:
    - user_id: 유저 id

    Returns:
    - ChatList: 유저의 채팅 목록
    """
    chat_list, total = await chat.get_chat_by_user_id(
        db=db, user_id=user_id, skip=skip, limit=limit, sort=sort, order=order
    )
    return ChatListResponse(chat_list=chat_list, total=total, skip=skip, limit=limit)


@router.get("/{chat_id}")
async def get_chat_by_chat_id(
    chat_id: str,
    db: AsyncSession = Depends(get_async_db),
):
    return await chat.get_chat_with_agent_name(db=db, chat_id=chat_id)


@router.post("", response_model=Chat, summary="Create a new chat")
async def create_new_chat(
    chat_create: ChatCreateWithId,
    # user_info: Optional[UserInfo] = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    Create a new chat.
    """

    # todo 추후 task_agent_id를 input으로 받아야함.
    if settings.TASK_AGENT_ROUTE == "DEV":
        task_agent_base_url = "http://task-agent:8030/task-agent/"
    else:
        task_agent_base_url = "http://localhost:8030/task-agent/"

    task_agent_url = task_agent_base_url + "use_count_up"

    # expert_agent_id를 query string으로 추가하여 요청

    if chat_create.agent_id:
        async with aiohttp.ClientSession() as session:
            await session.post(
                task_agent_url, params={"expert_agent_id": chat_create.agent_id}
            )

    new_chat = await chat.create_chat(db=db, chat_data=chat_create)
    return new_chat


@router.delete("/all", summary="Delete all chat histories for a user")
async def delete_all_chat_histories(
    user_id: int,
    # user_info: Optional[UserInfo] = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    Delete all chat histories for a specific user.
    """
    deleted_count = await chat.delete_all_user_chat_histories(db=db, user_id=user_id)
    return {"success": True, "deleted_count": deleted_count}


@router.delete("/{chat_id}", summary="Delete a specific chat history")
async def delete_chat_history(
    chat_id: str,
    # user_info: Optional[UserInfo] = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 채팅 히스토리 삭제

    Path Args:
    - chat_id: 삭제할 채팅 ID

    Returns:
    - 삭제 성공 여부
    """
    del_chat = await chat.delete_chat(db=db, id=chat_id)
    return {"success": True, "chat_id": del_chat.id}


@router.post("/{chat_id}", summary="Create chat title")
async def create_chat_title(
    chat_id: str = Path(..., description="Chat ID"),
    content: str = Body(..., embed=True, description="User의 첫 번째 메시지"),
    db: AsyncSession = Depends(get_async_db),
):
    return await chat_title_service.create_chat_title(
        db=db, chat_id=chat_id, content=content
    )


@router.patch("/{chat_id}", summary="Update chat history title")
async def update_chat_history_title(
    chat_id: str,
    chat_update: ChatPatchRequest,
    # user_info: Optional[UserInfo] = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 채팅 히스토리 제목 수정

    Path Args:
    - chat_id: 수정할 채팅 히스토리 ID

    Body Args:
    - title: 새로운 채팅 히스토리 제목

    Returns:
    - 수정된 채팅 히스토리
    """
    return await chat.update_chat_title(db, chat_id=chat_id, title=chat_update.title)


@router.get("/{chat_id}/messages", summary="Retrieve chat messages")
async def get_chat_messages(
    chat_id: str,
    # user_info: Optional[UserInfo] = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 채팅 메시지 조회

    Path Args:
    - chat_id: 조회할 채팅 ID

    Returns:
    - 특정 채팅 메시지 목록
    """
    message_list = await chat.get_chat_messages(db=db, chat_id=chat_id)
    return message_list


# 메시지 생성
@router.post(
    "/{chat_id}/messages",
    response_model=ChatMessage,
    summary="Create a new chat message",
)
async def create_chat_message_api(
    chat_id: str,
    message: ChatMessageCreateRequest,
    # user_info: UserInfo = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    DB에 chat message 추가

    Path Args:
    - **chat_id**: 현재 진행중인 채팅 ID

    Body Args:
    - content: 메시지 내용
    - role: 메시지 역할 (user, assistant, system)
    - content_metadata: 메세지에 들어가는 부가정보
        sample = {
            "agent_execution_information":{
                "agent_id": 1,
                "execution_steps":[
                    {
                        "step_id": 1,
                        "step_name": "step1",
                        "step_description": "step1 description",
                        "step_status": "success",
                        "step_order": 1,
                        "actions":[
                            {
                                "action_id": 1,
                                "action_name": "action1",
                                "action_description": "action1 description",
                                "action_status": "success",
                                "action_order": 1,
                                "tool_calls" : [
                                    {
                                        "tool_id": 1,
                                        "tool_name": "tool1",
                                        "tool_description": "tool1 description",
                                        "tool_status": "success",
                                        "tool_order": 1,
                                        "tool_output": "tool1 output"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            "canvas_information":{
                "canvas_id": 1,
                "canvas_name": "canvas1",
                "canvas_description": "canvas1 description",
                "canvas_version": 1
            }
        }
    - attachment: 첨부파일 관련 나중에 삭제될 듯?

    Returns:
    - ChatMessage: 생성된 채팅 메시지
    """
    return await chat.create_message(db=db, chat_id=chat_id, message_data=message)


# 메시지 상세 조회
@router.get(
    "/{chat_id}/messages/{message_id}",
    response_model=ChatMessage,
    summary="Get a specific chat message",
)
async def get_chat_message_api(
    chat_id: str,
    message_id: str,
    db: AsyncSession = Depends(get_async_db),
):
    """
    Get a specific chat message by ID.

    Path Args:
    - chat_id: 조회할 채팅 ID
    - message_id: 조회할 메시지 ID

    Returns:
    - 특정 채팅 메시지
    """
    return await chat.get_message(db=db, message_id=message_id)


# 메시지 업데이트
@router.patch(
    "/{chat_id}/messages/{message_id}",
    response_model=ChatMessage,
    summary="Update a chat message",
)
async def update_chat_message_api(
    chat_id: str,
    message_id: str,
    message_update: ChatMessagePatchRequest,
    db: AsyncSession = Depends(get_async_db),
):
    """
    메시지 업데이트

    Path Args:
    - chat_id: 수정할 채팅 ID
    - message_id: 수정할 메시지 ID

    Body Args: 모두 Optional
    - content: 새로운 메시지 내용
    - content_metadata: 새로운 메시지 부가정보
        - agent_execution_information: 에이전트 실행 정보
        - canvas_information: 캔버스 정보
        - additional_info: 기타 추가 정보
    - attachment: 새로운 첨부파일 정보

    Returns:
    - 수정된 메시지
    """
    # 메시지가 해당 채팅에 속하는지 확인하는 로직 추가
    message = await chat.get_message(db=db, message_id=message_id)
    if not message or message.chat_id != chat_id:
        raise HTTPException(
            status_code=404,
            detail="Message not found or does not belong to the specified chat",
        )

    return await chat.update_message(
        db=db, message_id=message_id, message_data=message_update
    )


# 메시지 삭제
@router.delete("/{chat_id}/messages/{message_id}", summary="Delete a chat message")
async def delete_chat_message_api(
    chat_id: str,
    message_id: str,
    db: AsyncSession = Depends(get_async_db),
):
    """
    Delete a chat message.

    Path Args:
    - chat_id: 삭제할 채팅 ID
    - message_id: 삭제할 메시지 ID

    Returns:
    - 삭제 성공 여부
    """
    await chat.delete_message(db=db, message_id=message_id)
    return {"success": True, "message_id": message_id}


@router.post(
    "/messages/feedback",
    response_model=ChatMessageFeedbackResponse,
    summary="Add feedback to a chat message",
)
async def add_message_feedback(
    feedback_request: ChatMessageFeedbackRequest,
    db: AsyncSession = Depends(get_async_db),
):
    """
    메시지 피드백 추가

    Body Args:
    - chat_message_id: 피드백을 추가할 메시지 ID
    - feedback: 피드백 타입 (like or dislike)

    Returns:
    - ChatMessageFeedback: 생성된 피드백
    """
    return await chat_message_feedback_service.add_message_feedback(
        db=db, feedback_data=feedback_request
    )


# 메시지 피드백 조회 API
@router.get(
    "/messages/feedback/{chat_id}",
    response_model=list[ChatMessageFeedbackResponse],
    summary="Get feedback for a chat message",
)
async def get_message_feedback(
    chat_id: str,
    db: AsyncSession = Depends(get_async_db),
):
    """
    메시지 피드백 조회

    Path Args:
    - chat_id: 조회할 채팅 ID

    Returns:
    - List[ChatMessageFeedbackResponse]: 메시지 피드백 리스트
    """
    return await chat_message_feedback_service.get_all_message_feedback_by_chat_id(
        db=db, chat_id=chat_id
    )


@router.delete(
    "/messages/{message_id}/feedback/{message_feedback_id}",
    summary="Delete a message feedback",
)
async def delete_message_feedback(
    message_id: str,
    message_feedback_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    """
    메시지 피드백 삭제

    Path Args:
    - message_id: 삭제할 메시지 ID
    - message_feedback_id: 삭제할 메시지 피드백 ID
    """
    result = await chat_message_feedback_service.delete_message_feedback(
        db=db, message_feedback_id=message_feedback_id, message_id=message_id
    )
    return result
