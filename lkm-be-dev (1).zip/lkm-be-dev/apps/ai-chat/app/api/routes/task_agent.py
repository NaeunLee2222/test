from typing import List, Optional

from database.crud.task_agent import (
    create_task_agent,
    delete_task_agent,
    get_task_agent,
    get_task_agents,
    update_task_agent,
)
from database.session import get_async_db
from fastapi import APIRouter, Depends, HTTPException
from services.schemas.task_agent import TaskAgentCreate, TaskAgentRead, TaskAgentUpdate
from sqlalchemy.ext.asyncio import AsyncSession

task_agent_router = APIRouter()


# 1. ApiSpec 생성
@task_agent_router.post("/", response_model=TaskAgentRead)
async def create_task_agent_api(
    task_agent: TaskAgentCreate, db: AsyncSession = Depends(get_async_db)
):
    # create_task_agent은 비동기 함수이므로 await를 사용하여 실제 값을 반환해야 합니다.
    created_task_agent = await create_task_agent(db, task_agent)
    return created_task_agent


# 2. 모든 ApiSpec 리스트 조회
@task_agent_router.get("/", response_model=List[TaskAgentRead])
async def read_task_agents(
    # skip: int = 0,
    # limit: int = 10,
    task_agent_name: Optional[str] = None,
    db: AsyncSession = Depends(get_async_db),
):
    task_agents = await get_task_agents(db=db, task_agent_name=task_agent_name)
    return task_agents


# 3. 특정 ApiSpec 조회
@task_agent_router.get("/{task_agent_id}", response_model=TaskAgentRead)
async def read_task_agent(task_agent_id: int, db: AsyncSession = Depends(get_async_db)):
    task_agent = await get_task_agent(db=db, task_agent_id=task_agent_id)
    if not task_agent:
        raise HTTPException(status_code=404, detail="Task Agent not found")
    return task_agent


# 4. ApiSpec 업데이트
@task_agent_router.put("/{task_agent_id}", response_model=TaskAgentRead)
async def update_task_agent_api(
    task_agent_id: int,
    task_agent: TaskAgentUpdate,
    db: AsyncSession = Depends(get_async_db),
):
    updated_task_agent = await update_task_agent(
        db=db, task_agent_id=task_agent_id, task_agent_update=task_agent
    )
    if not updated_task_agent:
        raise HTTPException(status_code=404, detail="Task Agent not found")
    return updated_task_agent


# 5. ApiSpec 삭제
@task_agent_router.delete("/{task_agent_id}", response_model=dict)
async def delete_task_agent_api(
    task_agent_id: int, db: AsyncSession = Depends(get_async_db)
):
    deleted = await delete_task_agent(db=db, task_agent_id=task_agent_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Task Agent not found")
    return {"detail": "Task Agent deleted successfully"}
