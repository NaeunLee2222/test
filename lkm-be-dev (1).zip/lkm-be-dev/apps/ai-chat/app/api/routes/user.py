# from api.deps import validate_user
from typing import Optional

from database.crud.user import CRUDUser
from database.session import get_async_db
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import APIRouter, Depends, Query
from services.schemas.user import (
    UserCreate,
    UserCreateRequest,
    UserListResponse,
    UserPasswordUpdate,
    UserResponse,
    UserUpdate,
    UserUpdateRequest,
)
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()

crud_user = CRUDUser()


# 유저 생성 API
@router.post("/", response_model=UserResponse, summary="Create a new user")
async def create_user(
    user_data: UserCreateRequest,
    db: AsyncSession = Depends(get_async_db),
    # current_user: UserInfo = Depends(validate_user)
):
    """새로운 사용자 생성 API"""
    """
    # 뭔가 정해지면 Role 기반으로 제한
    # 권한 체크
    if current_user.role != "admin":
        raise ServiceException(
            status_code=403,
            error_code=ErrorCode.ACCESS_DENIED,
            detail="관리자만 사용자를 생성할 수 있습니다."
        )
    """
    # 이메일 중복 체크
    existing_user = await crud_user.get_user_by_email(db, user_data.email)
    if existing_user:
        raise ServiceException(
            status_code=400,
            error_code=ErrorCode.DUPLICATE_ENTITY,
            detail="이미 존재하는 이메일입니다.",
        )

    user_create = UserCreate(
        email=user_data.email,
        password=user_data.password,
        username=user_data.username,
        organization_id=user_data.organization_id,
        team_id=user_data.team_id,
        role=user_data.role,
        is_activated=user_data.is_activated,
    )

    # 사용자 생성
    user = await crud_user.create_user(db, user_create)
    return user


# 유저 조회 API
@router.get("/", response_model=UserResponse, summary="Get user by id or email")
async def get_user(
    id: Optional[int] = None,
    email: Optional[str] = None,
    db: AsyncSession = Depends(get_async_db),
):
    if id:
        user = await crud_user.get_user_by_user_id(db, id)
    elif email:
        user = await crud_user.get_user_by_email(db, email)
    else:
        raise ServiceException(
            status_code=400,
            error_code=ErrorCode.INVALID_REQUEST,
            detail="id 또는 email 중 하나를 입력해주세요.",
        )

    return user


# 모든 유저 조회 API
@router.get("/all", response_model=UserListResponse, summary="Get all users")
async def get_all_users(
    db: AsyncSession = Depends(get_async_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    is_activated: Optional[bool] = Query(None),
    role: Optional[str] = Query(
        None,
        enum=["admin", "user"],
        description="권한: 관리자/사용자",
    ),
    order: Optional[str] = Query(
        None,
        enum=["name_asc", "name_desc", "org_asc", "org_desc", "id_asc"],
        description="정렬 방식: 이름 오름차순/이름 내림차순/조직 오름차순/조직 내림차순 설정하지 않을 경우 id순",
    ),
):
    """모든 사용자 목록을 조회합니다.

    - 이메일, 사용자 이름으로 검색 필터링 가능
    - 활성화 여부로 필터링 가능
    - 사용자 권한으로 필터링 가능
    - 페이지네이션 지원 (skip, limit)
    - 다양한 정렬 방식 지원 (이름, 조직별)
    - 전체 사용자 수 반환
    """
    users, total = await crud_user.get_multi_filtered_user(
        db,
        skip=skip,
        limit=limit,
        search=search,
        is_activated=is_activated,
        role=role,
        order=order,
    )

    return UserListResponse(
        users=users, total=total, skip=skip, limit=limit, order=order
    )


# 유저 조회 API
@router.get("/{email}", response_model=UserResponse, summary="Get user by email")
async def get_user_by_email(
    email: str,
    db: AsyncSession = Depends(get_async_db),
    # current_user: UserInfo = Depends(validate_user)
):
    """
    # 자신의 정보 또는 관리자만 조회 가능
    if current_user.email != email and current_user.role != "admin":
        raise ServiceException(
            status_code=403,
            error_code=ErrorCode.FORBIDDEN,
            detail="다른 사용자 정보를 조회할 권한이 없습니다."
        )
    """
    user = await crud_user.get_user_by_email(db, email)
    if not user:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="사용자를 찾을 수 없습니다.",
        )

    return user


# 유저 업데이트 API
@router.put("/{id}", response_model=UserResponse, summary="Update user")
async def update_user(
    id: int,
    user_data: UserUpdateRequest,
    db: AsyncSession = Depends(get_async_db),
    # current_user: UserInfo = Depends(validate_user)
):
    """사용자 정보를 업데이트합니다."""
    """
    # 자신의 정보 또는 관리자만 업데이트 가능
    if current_user.email != email:# and current_user.role != "admin":
        raise ServiceException(
            status_code=403,
            error_code=ErrorCode.ACCESS_DENIED,
            detail="다른 사용자 정보를 수정할 권한이 없습니다."
        )
    """

    # 기존 유저 존재 여부 확인
    existing_user = await crud_user.get_user_by_user_id(db, id)
    if not existing_user:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="사용자를 찾을 수 없습니다.",
        )

    # 이메일 중복 체크 (원래 이메일과 다른 경우에만)
    original_user = await crud_user.get_user_by_user_id(db, id)
    if original_user.email != user_data.email:
        existing_user = await crud_user.get_user_by_email(db, user_data.email)
        if existing_user:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.DUPLICATE_ENTITY,
                detail="이미 존재하는 이메일입니다.",
            )

    # UserUpdateRequest → UserUpdate 변환 및 이메일 추가
    user_update = UserUpdate(
        id=id,
        email=user_data.email,
        username=user_data.username,
        organization_id=user_data.organization_id,
        team_id=user_data.team_id,
        role=user_data.role,
        is_activated=user_data.is_activated,
    )

    # 사용자 업데이트
    updated_user = await crud_user.update_user(db, user_update)

    is_password_updated = user_data.password is not None
    if is_password_updated:
        user_password_update = UserPasswordUpdate(id=id, password=user_data.password)
        await crud_user.update_user_password(db, user_password_update)

    return updated_user


# 유저 삭제 API
@router.delete("/{id}", summary="Delete user by user id")
async def delete_user(
    id: int,
    db: AsyncSession = Depends(get_async_db),
    # current_user: UserInfo = Depends(validate_user)
):
    """
    # 관리자만 삭제 가능
    if current_user.role != "admin":
        raise ServiceException(
            status_code=403,
            error_code=ErrorCode.ACCESS_DENIED,
            detail="관리자만 사용자를 삭제할 수 있습니다."
        )
    """

    # 기존 유저 존재 여부 확인
    existing_user = await crud_user.get_user_by_user_id(db, id)
    if not existing_user:
        raise ServiceException(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            detail="사용자를 찾을 수 없습니다.",
        )

    # 사용자 삭제
    await crud_user.delete(db=db, id=existing_user.id)

    return {"message": "사용자가 성공적으로 삭제되었습니다."}
