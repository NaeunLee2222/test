import time

from api.deps import get_redis, validate_user
from core.config import get_setting
from core.log.logging import get_logging
from core.security import (
    create_access_token,
    create_access_token_from_refresh_token,
    create_refresh_token,
    delete_refresh_token,
    verify_password,
)
from database.session import get_async_db
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import APIRouter, Depends, Request, Response
from redis import Redis
from services.schemas.auth import LoginRequest, UserInfo
from services.user import UserService
from sqlalchemy.ext.asyncio import AsyncSession

settings = get_setting()
logger = get_logging()
router = APIRouter()

user_service = UserService()


@router.post(
    "/login",
    summary="Get user info from common API and return access token",
)
async def login(
    body: LoginRequest,
    response: Response,
    db: AsyncSession = Depends(get_async_db),
    redis: Redis = Depends(get_redis),
) -> dict:

    try:
        user = await user_service.get_user_by_email(db, body.email)
        if user is None:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="User not found",
            )

        if not verify_password(body.password, user.hashed_password):
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.INVALID_AUTH,
                detail="Invalid password",
            )

        if user.organization_id is not None and user.team_id is not None:
            org_name, team_name = await user_service.get_company_info(
                db, user.organization_id, user.team_id
            )
        else:
            org_name = None
            team_name = None

        user_info = UserInfo(
            user_id=user.id,
            email=user.email,
            username=user.username,
            org_name=org_name,
            team_name=team_name,
            role=user.role,
            organization_id=user.organization_id,
            team_id=user.team_id,
        )

        # 토큰 생성하기
        iat = time.time()
        access_token = create_access_token(user_info, iat)
        refresh_token, refresh_jti = create_refresh_token(user_info, iat)

        redis.setex(
            f"refresh_token:{refresh_jti}",
            settings.REFRESH_TOKEN_EXPIRE_TIME,
            user_info.model_dump_json(),
        )

        # access token과 refresh token을 HTTP-only cookie로 설정
        response.set_cookie(
            key="access_token",
            value=access_token,
            max_age=settings.TOKEN_EXPIRE_TIME,
            httponly=True,
        )

        response.set_cookie(
            key="refresh_token",
            value=refresh_token,
            max_age=settings.REFRESH_TOKEN_EXPIRE_TIME,
            httponly=True,
        )

        access_token_exp_time = int(iat + settings.TOKEN_EXPIRE_TIME)
        refresh_token_exp_time = int(iat + settings.REFRESH_TOKEN_EXPIRE_TIME)
        return {
            "access_token_exp": access_token_exp_time,
            "refresh_token_exp": refresh_token_exp_time,
            "user": user_info.model_dump(),
        }

    except Exception as e:
        logger.error(str(e))
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail=str(e),
        )


@router.post("/logout")
async def logout(
    request: Request,
    response: Response,
    redis: Redis = Depends(get_redis),
):
    try:
        # 쿠키에서 refresh token 가져오기
        refresh_token = request.cookies.get("refresh_token")

        # refresh token cookie 삭제
        response.delete_cookie(key="refresh_token")

        delete_refresh_token(refresh_token, redis)

        return {"logout": True}

    except Exception as e:
        logger.error(f"로그아웃 처리 중 오류 발생: {str(e)}")
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail=str(e),
        )


@router.post("/refresh")
async def refresh(
    request: Request,
    response: Response,
    redis: Redis = Depends(get_redis),
):
    # cookie에서 refresh token 가져오기
    refresh_token = request.cookies.get("refresh_token")

    if not refresh_token:
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail="Refresh token not found in cookies",
        )

    user_info, access_token, new_refresh_token = create_access_token_from_refresh_token(
        refresh_token, redis
    )

    # 새로운 refresh token

    response.set_cookie(
        key="access_token",
        value=access_token,
        max_age=settings.TOKEN_EXPIRE_TIME,
        httponly=True,
    )

    response.set_cookie(
        key="refresh_token",
        value=new_refresh_token,
        max_age=settings.REFRESH_TOKEN_EXPIRE_TIME,
        httponly=True,
    )

    access_token_exp_time = int(time.time() + settings.TOKEN_EXPIRE_TIME)
    refresh_token_exp_time = int(time.time() + settings.REFRESH_TOKEN_EXPIRE_TIME)

    return {
        "access_token_exp": access_token_exp_time,
        "refresh_token_exp": refresh_token_exp_time,
    }


@router.get("/protected")
async def protected_endpoint_sample(user: UserInfo = Depends(validate_user)):
    return {
        "user": user.model_dump(),
    }
