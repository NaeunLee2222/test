import time

from core.config import get_setting
from fastapi import APIRouter
from database.session import get_pool_status

settings = get_setting()
health_router = APIRouter(tags=["Health"])


@health_router.get("/health", summary="Health Check")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": time.time(),
    }


@health_router.get("/pool-status", summary="Pool Status")
async def pool_status():
    return get_pool_status()
