import traceback
from typing import List

from celery import Celery
from core.config import get_setting
from core.log.logging import get_logging
from core.utils.documents import upload_documents
from core.utils.files import normalize_unicode_files
from database.session import get_async_db
from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile
from services import documents
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()
logger = get_logging()
settings = get_setting()


def make_celery(app_name=__name__):
    if settings.REDIS_USE_SENTINEL:
        # Redis Sentinel을 통한 연결
        sentinel_host = settings.REDIS_SENTINEL_HOST
        sentinel_port = settings.REDIS_SENTINEL_PORT
        master_name = settings.REDIS_SENTINEL_MASTER_NAME
        password = settings.C_REDIS_ACCESS_KEY or settings.REDIS_ACCESS_KEY
        
        # Celery에서 Sentinel을 사용하기 위한 URL 형식
        connection_url = f"sentinel://:{password}@{sentinel_host}:{sentinel_port}/0?master_name={master_name}"
        logger.info(f"Connected to Redis Sentinel on {connection_url}")
    else:
        # 직접 Redis 연결
        if settings.C_REDIS_USE_SSL:
            connection_url = f"rediss://:{settings.C_REDIS_ACCESS_KEY}@{settings.C_REDIS_HOST}:{settings.C_REDIS_PORT}/{settings.C_REDIS_DB}?ssl_cert_reqs=required"
        else:
            connection_url = f"redis://:{settings.C_REDIS_ACCESS_KEY}@{settings.C_REDIS_HOST}:{settings.C_REDIS_PORT}/{settings.C_REDIS_DB}"
        logger.info(f"Connected to Redis on {connection_url}")

    backend = connection_url
    broker = connection_url
    cel = Celery(app_name, backend=backend, broker=broker)

    cel.conf.broker_transport_options = {
        "max_retries": 1,
        "interval_start": 0,
        "interval_step": 0.2,
        "interval_max": 0.5,
    }

    cel.conf.redis_backend_health_check_interval = 30
    cel.conf.broker_connection_retry = True
    cel.conf.broker_connection_max_retires = 3

    return cel


celery_app = make_celery("DocManager")


@router.post(
    "/upload",
    description="채팅 파일 업로드",
)
async def upload_doc(
    # user_info: Optional[dict] = Depends(get_user_info_from_token),
    user_id: int = Form(None),
    chat_id: str = Form(None),
    files: List[UploadFile] = Depends(normalize_unicode_files),
    db: AsyncSession = Depends(get_async_db),
):
    # validate_files_uploads(files)
    try:
        # user_id = user_info.get("user_id")
        if user_id is None:
            raise HTTPException(
                status_code=500, detail="Required Parameter is not defined. - User ID"
            )

        # TODO: 추후 index 확장 할 경우,
        # index_name = get_index_name_with_hash(mybox_name) 처럼 해쉬화
        index_name = settings.AZURE_AI_SEARCH_INDEX
        result = [
            doc
            async for doc in upload_documents(
                user_id=user_id,
                chat_id=chat_id,
                search_index_name=index_name,
                files=files,
                db=db,
                celery_app=celery_app,
            )
        ]

        docs = [{"id": doc["file"].id, "state": doc["state"]} for doc in result]
        return docs

    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing the document."
        )


@router.get("/{doc_id}", description="업로드 파일 상태 조회")
async def get_document(
    # user_info: Optional[dict] = Depends(get_user_info_from_token),
    user_id: int,
    chat_id: str,
    doc_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    # user_id = user_info.get("user_id")
    if user_id is None:
        raise HTTPException(
            status_code=500, detail="Required Parameter is not defined. - User ID"
        )
    try:
        return {
            "documents": await documents.get_document_with_chatid(
                db, chat_id=chat_id, doc_id=doc_id
            )
        }
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(500, str(e))
