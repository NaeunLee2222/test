from typing import Optional, Union

from database.session import get_async_db
from fastapi import APIRouter, Depends, Query
from services import chat_canvas
from services.schemas.chat_canvas import (
    CanvasCreateRequest,
    CanvasDeltaListResponse,
    CanvasListResponse,
    CanvasResponse,
    CanvasUpdateRequest,
    CanvasWithDelta,
    CanvasWithDeltaList,
)
from services.schemas.user import ApiResponse
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()


@router.post("", response_model=CanvasResponse, summary="Create a new document")
async def create_canvas(
    canvas_data: CanvasCreateRequest,
    # user_info: UserInfo = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    새 문서 생성

    Body Args:
    - chat_id: 문서가 속한 채팅 ID
    - title: 문서 제목
    - content: 초기 내용

    Returns:
    - DocumentWithDelta: 생성된 문서 정보와 첫 델타 내용
    """
    return await chat_canvas.create_canvas(db=db, canvas_data=canvas_data)


# 현재 Chat 내에 있는 모든 Document 조회
@router.get(
    "/by-chat/{chat_id}",
    response_model=CanvasListResponse,
    summary="Get document list for a chat",
)
async def get_canvas_by_chat_id(
    chat_id: str,
    # user_info: UserInfo = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    채팅에 속한 모든 문서 목록 조회

    Path Args:
    - chat_id: 채팅 ID


    Returns:
    - DocumentList: 문서 목록 (include_deltas=True인 경우 document delta 포함)
    """
    return await chat_canvas.get_canvases_by_chat_id(db=db, chat_id=chat_id)


@router.get(
    "/{canvas_uuid}",
    response_model=Union[CanvasResponse, CanvasWithDeltaList],
    summary="Get document by UUID",
)
async def get_canvas_by_uuid(
    canvas_uuid: str,
    # deltas: bool = Query(False, description="델타 정보 포함 여부"),
    # user_info: UserInfo = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 문서 조회

    Path Args:
    - canvas_uuid: 문서 UUID

    Query Args:
    - deltas: 델타 정보 포함 여부 (기본: False)

    Returns:
    - deltas가 True면: CanvasWithDeltaList (모든 버전 포함)
    - deltas가 False면: Canvas (단일 버전)
    """
    return await chat_canvas.get_canvas_by_uuid(
        db=db, canvas_uuid=canvas_uuid, deltas=False
    )


@router.put(
    "/{canvas_uuid}", response_model=CanvasWithDelta, summary="Update a document"
)
async def update_canvas(
    canvas_uuid: str,
    update_data: CanvasUpdateRequest,
    # user_info: UserInfo = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    문서 업데이트

    Path Args:
    - canvas_uuid: 문서 UUID

    Body Args:
    - title: 업데이트할 제목 (선택)
    - content: 업데이트할 내용 (선택)
    - version: 업데이트할 버전

    Returns:
    - CanvasWithDelta: 업데이트된 문서 정보와 델타 내용
    """
    return await chat_canvas.update_canvas(
        db=db, canvas_uuid=canvas_uuid, update_data=update_data
    )


@router.get(
    "/{canvas_uuid}/diff",
    response_model=CanvasDeltaListResponse,
    summary="Get document diff list by version (with pagination)",
)
async def get_canvas_diff(
    canvas_uuid: str,
    skip: int = Query(0, ge=0, description="건너뛸 개수"),
    limit: int = Query(20, ge=1, le=100, description="가져올 개수"),
    # user_info: UserInfo = Depends(validate_user),
    db: AsyncSession = Depends(get_async_db),
):
    """
    문서의 모든 버전 차이 조회 (버전 역순, 페이징 지원)

    Path Args:
    - canvas_uuid: 문서 UUID

    Query Args:
    - skip: 건너뛸 개수 (기본: 0)
    - limit: 가져올 개수 (기본: 20, 최대: 100)

    Returns:
    - CanvasDeltaListResponse: 문서 변경사항 목록 정보 (버전 역순으로 정렬)
    """
    return await chat_canvas.get_canvas_diff(
        db=db, canvas_uuid=canvas_uuid, skip=skip, limit=limit
    )


@router.get("/canvas/{user_id}")
async def get_canvas_by_user_id(
    user_id: int,  # todo 토큰으로 변경,
    title: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    order: Optional[str] = Query(
        None,
        enum=["title_asc", "title_desc", "popularity", "latest"],
        description="정렬 방식: 제목 오름차순/제목 내림차순/인기순/최신순",
    ),
    type: Optional[str] = Query(None, description="문서 타입"),
    db: AsyncSession = Depends(get_async_db),
):
    return await chat_canvas.get_canvas_by_user_id(
        db=db,
        user_id=user_id,
        skip=skip,
        limit=limit,
        order=order,
        title=title,
        type=type,
    )


@router.delete("/{canvas_uuid}")
async def delete_canvas(
    canvas_uuid: str,
    db: AsyncSession = Depends(get_async_db),
):
    flag = await chat_canvas.delete_canvas(db=db, canvas_uuid=canvas_uuid)
    if flag:
        return ApiResponse(status_code=200, detail="Canvas deleted successfully")
    else:
        return ApiResponse(status_code=404, detail="Canvas not found")
