from io import BytesIO

from core.config import get_setting
from core.log.logging import get_logging
from database.session import get_async_db
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from services.aspose_cloud import AsposeCloudService
from sqlalchemy.ext.asyncio import AsyncSession

settings = get_setting()
logger = get_logging()
router = APIRouter()


@router.post(
    "/html-to-pdf",
    summary="Convert HTML to PDF",
)
async def html_to_pdf(
    canvas_uuid: str,
    db: AsyncSession = Depends(get_async_db),
):
    response = await AsposeCloudService().convert_html_to_pdf(db, canvas_uuid)
    return StreamingResponse(
        BytesIO(response),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={canvas_uuid}.pdf"},
    )


@router.post(
    "/html-to-docx",
    summary="Convert HTML to DOCX",
)
async def html_to_docx(
    canvas_uuid: str,
    db: AsyncSession = Depends(get_async_db),
):
    response = await AsposeCloudService().convert_html_to_docx(db, canvas_uuid)
    return StreamingResponse(
        BytesIO(response),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename={canvas_uuid}.docx"},
    )


@router.post(
    "/html-to-xlsx",
    summary="Convert HTML to XLSX",
)
async def html_to_xlsx(
    canvas_uuid: str,
    db: AsyncSession = Depends(get_async_db),
):
    response = await AsposeCloudService().convert_html_to_xlsx(db, canvas_uuid)
    return StreamingResponse(
        BytesIO(response),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={canvas_uuid}.xlsx"},
    )


# @router.post(
#     "/html-download",
#     summary="Download HTML",
# )
# async def html_download(
#     canvas_uuid: str,
#     db: AsyncSession = Depends(get_async_db),
# ):
#     return await AsposeCloudService().convert_html_to_pdf(canvas_uuid)
