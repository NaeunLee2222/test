from database.session import get_async_db
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from services.usage import UsageService
from services.schemas.usage import UsageDetail, UsageUpdate, UsageCreate


from core.config import get_setting
from core.log.logging import get_logging

logger = get_logging()
settings = get_setting()

router = APIRouter()

usage_service = UsageService()


@router.get("/usage")
async def get_usage(
    user_id: int,
    db: AsyncSession = Depends(get_async_db),
):
    return await usage_service.get_usage_by_user_id(db, user_id)


@router.post("/usage")
async def create_usage(
    usage_create: UsageCreate,
    db: AsyncSession = Depends(get_async_db),
):
    return await usage_service.create_usage(db, usage_create)


@router.put("/usage")
async def update_usage(
    user_id: int,
    usage_update: UsageUpdate,
    db: AsyncSession = Depends(get_async_db),
):
    return await usage_service.update_usage(db, user_id, usage_update)
