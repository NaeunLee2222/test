from typing import List
from core.config import get_setting
from core.log.logging import get_logging
from services.schemas.user import (
    ApiResponse,
    UserMemory,
    UserPreference,
    UserMemoryRequest,
    UserMemoryUpdateRequest,
)
from services.preferences import UserPreferenceService, UserMemoryService
from error.service_exception import ServiceException
from database.session import get_async_db
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession


logger = get_logging()
settings = get_setting()
router = APIRouter()

user_preference_service = UserPreferenceService()
user_memory_service = UserMemoryService()
## 유저 설정 조회


@router.get("/user_preference", response_model=UserPreference)
async def get_user_preference(
    user_id: int, agent_id: int, db: AsyncSession = Depends(get_async_db)
):
    try:
        user_preference = await user_preference_service.get_user_preference(
            user_id=user_id, agent_id=agent_id, db=db
        )
    except HTTPException as e:
        logger.info(f"Error getting user preference: {e}")
        raise e
    except Exception as e:
        logger.error(f"Error getting user preference: {e}")
        raise HTTPException(status_code=500, detail="Error getting user preference")

    return user_preference


@router.post("/user_preference", response_model=UserPreference)
async def create_user_preference(
    user_id: int, agent_id: int, db: AsyncSession = Depends(get_async_db)
):
    try:
        user_preference = await user_preference_service.create_user_preference(
            user_id=user_id, agent_id=agent_id, db=db
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error creating user preference: {e}")
        raise HTTPException(status_code=500, detail="Error creating user preference")

    return user_preference


@router.put("/user_preference", response_model=UserPreference)
async def update_user_preference(
    user_preference: UserPreference, db: AsyncSession = Depends(get_async_db)
):
    try:
        user_preference = await user_preference_service.update_user_preference(
            user_preference=user_preference, db=db
        )

    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error updating user preference: {e}")
        raise HTTPException(status_code=500, detail="Error updating user preference")
    return user_preference


@router.delete("/user_preference", response_model=ApiResponse)
async def delete_user_preference(
    user_id: int, agent_id: int, db: AsyncSession = Depends(get_async_db)
):
    try:
        user_preference = await user_preference_service.delete_user_preference(
            user_id=user_id, agent_id=agent_id, db=db
        )
    except HTTPException as e:
        raise e
    return ApiResponse(status_code=200, detail="User preference deleted successfully")


## 유저 메모리 조회


@router.get("/user_memory/", response_model=List[UserMemory])
async def get_user_memory(
    user_id: int, agent_id: int, db: AsyncSession = Depends(get_async_db)
):
    try:
        user_memory = await user_memory_service.get_memories_by_user_agent(
            user_id=user_id, agent_id=agent_id, db=db
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error getting user memory: {e}")
        raise HTTPException(status_code=500, detail="Error getting user memory")

    return user_memory


@router.post("/user_memory", response_model=UserMemory)
async def create_user_memory(
    user_memory_request: UserMemoryRequest, db: AsyncSession = Depends(get_async_db)
):
    try:
        user_memory = await user_memory_service.create_user_memory(
            user_memory_request=user_memory_request, db=db
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error creating user memory: {e}")
        raise HTTPException(status_code=500, detail="Error creating user memory")

    return user_memory


@router.put("/user_memory/{user_memory_id}", response_model=UserMemory)
async def update_user_memory(
    user_memory_id: int,
    user_memory_update_request: UserMemoryUpdateRequest,
    db: AsyncSession = Depends(get_async_db),
):
    try:
        user_memory = await user_memory_service.update_user_memory(
            user_memory_id=user_memory_id,
            user_memory_update_request=user_memory_update_request,
            db=db,
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error updating user memory: {e}")
        raise HTTPException(status_code=500, detail="Error updating user memory")
    return user_memory


@router.delete("/user_memory", response_model=ApiResponse)
async def delete_user_memory(
    user_memory_id: int, db: AsyncSession = Depends(get_async_db)
):
    try:
        await user_memory_service.delete_user_memory(
            user_memory_id=user_memory_id, db=db
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error deleting user memory: {e}")
        raise HTTPException(status_code=500, detail="Error deleting user memory")

    return ApiResponse(status_code=200, detail="User memory deleted successfully")


@router.delete("/user_memory/all", response_model=ApiResponse)
async def delete_all_user_memory(
    user_id: int, agent_id: int, db: AsyncSession = Depends(get_async_db)
):
    try:
        await user_memory_service.delete_all_user_memory(
            user_id=user_id, agent_id=agent_id, db=db
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error deleting all user memory: {e}")
        raise HTTPException(status_code=500, detail="Error deleting all user memory")

    return ApiResponse(status_code=200, detail="All user memory deleted successfully")
