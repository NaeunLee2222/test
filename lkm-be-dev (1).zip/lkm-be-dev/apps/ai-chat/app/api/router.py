from api.routes import (
    aspose,
    auth,
    chat,
    chat_canvas,
    chat_documents,
    organization,
    preference,
    supervisor,
    task_agent,
    user,
    usage,
)
from fastapi import APIRouter

api_router = APIRouter()

api_router.include_router(
    task_agent.task_agent_router, prefix="/agent-manager", tags=["TaskAgent"]
)

api_router.include_router(
    supervisor.supervisor_router, prefix="/supervisor", tags=["Supervisor"]
)

api_router.include_router(
    organization.router, prefix="/organization", tags=["Organization"]
)

api_router.include_router(chat.router, prefix="/chats", tags=["Chat History"])
api_router.include_router(user.router, prefix="/user", tags=["User"])

api_router.include_router(auth.router, prefix="/auth", tags=["Auth"])

api_router.include_router(
    chat_documents.router, prefix="/chat_documents", tags=["Chat Documents"]
)

api_router.include_router(chat_canvas.router, prefix="/canvas", tags=["Canvas"])

api_router.include_router(preference.router, prefix="/preference", tags=["Preference"])

api_router.include_router(aspose.router, prefix="/aspose", tags=["Aspose"])

api_router.include_router(usage.router, prefix="/usage", tags=["Usage"])
