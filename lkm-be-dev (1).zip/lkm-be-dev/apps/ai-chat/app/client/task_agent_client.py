import httpx
from core.config import get_setting

settings = get_setting()


class TaskAgentClient:
    def __init__(self):
        if settings.TASK_AGENT_ROUTE == "DEV":
            self.base_url = "http://task-agent:8030"
        else:
            self.base_url = "http://localhost:8030"

    async def get_agent_detail(self, agent_id: int):
        """
        에이전트 상세 정보를 조회합니다.

        Args:
            agent_id: 에이전트 ID (required)
            user_id: 사용자 ID (optional, default: 1)

        Returns:
            dict: 에이전트 상세 정보 또는 빈 딕셔너리
        """
        url = f"{self.base_url}/task-agent/agents/{agent_id}/simple"
        params = {}

        async with httpx.AsyncClient() as client:
            response = await client.get(url, params=params)
            if response.status_code == 200:
                return response.json()
            else:
                return {}
