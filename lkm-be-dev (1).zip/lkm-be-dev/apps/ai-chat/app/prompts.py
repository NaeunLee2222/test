API_CHOOSE_PROMPT = """Look at the user query and the list of APIs, and select the most appropriate API to handle the user query. 
You must answer as a JSON format fitting with selected API's schema, filling in the fields as needed. If it's optional, you can skip it.
Answer would be like below:
{{
    "name": f"sample_api",
    "endpoint": f"http://example.com/api/",
    "description": f"This is a sample API",
    "service_category": "Sample",
    "method": "POST",
    "params": {{"id": 1351}},
    "body": {{"field1": "example", "field2": 1234}},
    "headers": None,
    "response_format": {{"result": "string"}},
    "rate_limit": 100,
}}


### API Specifications:
{context}


### User query:
{query}


### Answer:
"""

DATA_CONFIRM_PROMPT = """Look at the user query and the data provided, and determine if the data is related to the user's request.
Answer should be 'yes' or 'no'. 'yes' if the data is related, 'no' if it is not.


### User query: 
{query}


### Data: 
{data}"""

QUERY_REGENERATE_SYSTEM = """You a question re-writer that converts an input question to a better version that is optimized for choose api.
Look at the input and try to reason about the underlying semantic intent / meaning"""

QUERY_REGENERATE_HUMAN = """Here is the initial question: \n\n {query} \n Formulate an improved question.
- API LIST
{data}"""
