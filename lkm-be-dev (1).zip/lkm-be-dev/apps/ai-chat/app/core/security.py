import time
import uuid
from typing import Optional

import jwt
from api.deps import get_redis
from core.config import get_setting
from core.log.logging import get_logging
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import Depends, HTTPException, Request, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from passlib.context import CryptContext
from redis import Redis
from services.schemas.auth import UserInfo

settings = get_setting()
logger = get_logging()

security = HTTPBearer(auto_error=False)
pwd_context = CryptContext(schemes=["bcrypt"])


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    return pwd_context.hash(password)


async def get_token_from_header(request: Request) -> str:
    credentials: HTTPAuthorizationCredentials = await security(request)
    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=401,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return credentials.credentials


async def verify_access_token(token: str) -> dict:
    try:
        # JWT 검증
        payload = jwt.decode(
            token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM]
        )

        # token_type 확인
        if payload.get("token_type") != "access":
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.INVALID_AUTH,
                detail="Invalid token type",
            )

        return payload
    except jwt.ExpiredSignatureError:
        logger.error("Token has expired")
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.TOKEN_EXPIRED,
            detail=("Token has expired"),
        )
    except jwt.PyJWTError:
        logger.error("Invalid token")
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail=("Invalid token"),
        )


async def get_user_info_from_token(
    credentials: HTTPAuthorizationCredentials = Security(security),
    redis: Redis = Depends(get_redis),
) -> Optional[UserInfo]:
    """토큰에서 사용자 정보 가져오기"""

    if not credentials or not credentials.credentials:
        if settings.ENVIRONMENT == "LOCAL":
            logger.warning("No token provided, returning None")
            return None
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.NO_TOKEN,
            detail="Authentication required",
        )

    token = credentials.credentials

    # 토큰 검증
    payload = await verify_access_token(token)

    # JWT 페이로드에서 사용자 정보 가져오기
    user_info = UserInfo.model_validate(payload)
    return user_info


def create_access_token(user_info: UserInfo, iat: float) -> str:
    exp = iat + settings.TOKEN_EXPIRE_TIME
    payload = {
        "service": "ai-chat",
        "exp": exp,
        "iat": iat,
        "user_id": user_info.user_id,
        "email": user_info.email,
        "username": user_info.username,
        "org_name": user_info.org_name,
        "team_name": user_info.team_name,
        "role": user_info.role,
        "organization_id": user_info.organization_id,
        "team_id": user_info.team_id,
        "token_type": "access",
    }
    token = jwt.encode(
        payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM
    )
    return token


def create_refresh_token(user_info: UserInfo, iat: float) -> tuple[str, str]:
    """
    Refresh token을 생성하고 고유 식별자(jti)를 반환합니다.
    Returns: (refresh_token, jti)
    """
    exp = iat + settings.REFRESH_TOKEN_EXPIRE_TIME
    jti = str(uuid.uuid4())  # 고유 식별자 생성

    payload = {
        "service": "ai-chat",
        "exp": exp,
        "iat": iat,
        "email": user_info.email,
        "token_type": "refresh",
        "jti": jti,  # JWT ID 추가
    }
    token = jwt.encode(
        payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM
    )
    return token, jti


def create_access_token_from_refresh_token(
    refresh_token: str, redis: Redis = Depends(get_redis)
) -> str:
    try:
        # 1. refresh token 검증
        payload = jwt.decode(
            refresh_token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM]
        )

        # 2. token type 확인
        if payload.get("token_type") != "refresh":
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.INVALID_AUTH,
                detail="Invalid token type",
            )

        # 3. JTI 추출
        jti = payload.get("jti")
        if not jti:
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.INVALID_AUTH,
                detail="Invalid token format - missing jti",
            )

        # 4. Redis에서 사용자 정보 조회 (JTI를 키로 사용)
        redis_key = f"refresh_token:{jti}"
        user_data = redis.get(redis_key)

        if not user_data:
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.TOKEN_EXPIRED,
                detail="Refresh token has been revoked or expired",
            )

        # 5. 사용자 정보 복원
        user_info = UserInfo.model_validate_json(user_data)

        # 6. 새로운 access token 생성
        new_iat = time.time()
        access_token = create_access_token(user_info, new_iat)

        # 7. 새로운 refresh token 생성
        new_refresh_token, new_jti = create_refresh_token(user_info, new_iat)

        # 8. Redis에 새로운 refresh token 저장
        redis.setex(
            f"refresh_token:{new_jti}",
            settings.REFRESH_TOKEN_EXPIRE_TIME,
            user_info.model_dump_json(),
        )

        # 9. 기존 refresh token 삭제 (새 토큰 저장 후)
        redis.delete(redis_key)

        return user_info, access_token, new_refresh_token

    except jwt.ExpiredSignatureError:
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.TOKEN_EXPIRED,
            detail="Refresh token has expired",
        )
    except jwt.InvalidTokenError:
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail="Invalid refresh token",
        )


def delete_refresh_token(refresh_token: str, redis: Redis = Depends(get_redis)) -> bool:
    if not refresh_token:
        return True  # 토큰이 없으면 삭제할 것도 없음

    try:
        # 1. refresh token 검증
        payload = jwt.decode(
            refresh_token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM]
        )

        # 2. token type 확인
        if payload.get("token_type") != "refresh":
            logger.warning("Invalid token type during refresh token deletion")
            return False

        # 3. JTI 추출
        jti = payload.get("jti")
        if not jti:
            logger.warning("Missing jti during refresh token deletion")
            return False

        # 4. Redis에서 refresh token 삭제
        redis.delete(f"refresh_token:{jti}")
        return True

    except jwt.PyJWTError:
        # 토큰이 유효하지 않아도 에러를 발생시키지 않음 (로그아웃은 성공해야 함)
        logger.warning("Invalid refresh token during deletion")
        return False
