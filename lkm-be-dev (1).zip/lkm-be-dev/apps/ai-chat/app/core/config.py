from functools import lru_cache
from pathlib import Path
from typing import Any, Optional

from pydantic import ValidationInfo, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ENV_FILE = Path(__file__).resolve().parent.parent / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        env_file_encoding="utf-8",
        # extra="ignore",
        extra="allow",
    )

    # APP SETTINGs
    APP_NAME: str = "ai-chat"
    AI_CHAT_APP_PORT: int = 8010
    ENVIRONMENT: str = "LOCAL"
    TASK_AGENT_ROUTE: str = ""
    AI_CHAT_WORKER_NUM: int = 1
    CELERY_WORKER: int = 2

    URI_PREFIX: str = "/ai-chat"
    DATA_PATH: str = "/data"

    LOG_LEVEL: str = "DEBUG"
    LOG_PATH: str = "/logs/ai-chat"

    COMPANY: str = "SKCC"

    SK_AI_PLATFORM_ENABLED: bool = False
    SK_AI_PLATFORM_URL: str = ""
    SK_AI_PLATFORM_API_KEY: str = ""
    SK_AI_PLATFORM_CHAT_MODEL_NAME: str = ""

    # REDIS SETTINGs
    REDIS_HOST: str = ""
    REDIS_PORT: int = 6379
    REDIS_ACCESS_KEY: str = ""
    REDIS_USE_SSL: bool = False

    # Redis Sentinel 설정
    REDIS_SENTINEL_HOST: str = ""
    REDIS_SENTINEL_PORT: int = 26379
    REDIS_SENTINEL_PASSWORD: str = ""
    REDIS_SENTINEL_MASTER_NAME: str = ""
    REDIS_USE_SENTINEL: bool = True

    REDIS_USER_INFO_DB: int = 1  # 사용자 정보용 DB (환경변수로 변경 가능)
    # REDIS_CELERY_DB: int = 1  # celery task 캐싱용 DB

    ## Celery Redis
    C_REDIS_HOST: Optional[str] = None

    @field_validator("C_REDIS_HOST")
    def set_celery_redis_host(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, str):
            return v
        return values.data["REDIS_HOST"]

    C_REDIS_PORT: Optional[int] = None

    @field_validator("C_REDIS_PORT")
    def set_celery_redis_port(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, int):
            return v
        return values.data["REDIS_PORT"]

    C_REDIS_ACCESS_KEY: Optional[str] = None

    @field_validator("C_REDIS_ACCESS_KEY")
    def set_celery_redis_key(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, str):
            return v
        return values.data["REDIS_ACCESS_KEY"]

    C_REDIS_USE_SSL: Optional[bool] = None

    @field_validator("C_REDIS_USE_SSL")
    def set_celery_redis_ssl(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, bool):
            return v
        return values.data["REDIS_USE_SSL"]

    C_REDIS_DB: int = 1  # Celery용 DB (환경변수로 변경 가능)

    # DB SETTINGs
    DB_ENGINE: str = "postgres"
    DB_USER: str
    DB_PASSWORD: str
    DB_HOST: str
    DB_PORT: int
    DB_NAME: str
    DB_SCHEMA_NAME: str = "ai_chat"
    DB_SSL_CA: Optional[str] = None
    SQLALCHEMY_DATABASE_URL: Optional[str] = None
    DB_POOL_SIZE: int = 50
    DB_POOL_MAX_OVERFLOW: int = 30
    DB_POOL_RECYCLE: int = 14400

    SYSTEM_USER_ID: str = "admin"
    SYSTEM_USER_EMAIL: str = ""
    SYSTEM_USER_NAME: str = "admin"
    SYSTEM_USER_TOKEN: str = "admin"

    @field_validator("SQLALCHEMY_DATABASE_URL")
    def assemble_db_connection(cls, v: Optional[str], values: ValidationInfo) -> Any:
        if isinstance(v, str):
            return v
        preset = {
            "mysql": "mysql+aiomysql://{username}:{password}@{host}:{port}/{dbname}",
            "postgres": "postgresql+psycopg://{username}:{password}@{host}:{port}/{dbname}?options=-csearch_path%3D{schema}",
        }
        return preset[values.data["DB_ENGINE"]].format(
            username=values.data["DB_USER"],
            password=values.data["DB_PASSWORD"],
            host=values.data["DB_HOST"],
            port=values.data["DB_PORT"],
            dbname=values.data["DB_NAME"],
            schema=values.data["DB_SCHEMA_NAME"],
        )

    OPENAI_ENDPOINT: str = "https://ai-core-openai-llm.openai.azure.com/"
    OPENAI_API_VERSION: str = "2024-05-13"
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o"
    OPENAI_DEPLOYMENT: str = ""

    EMBEDDING_ENDPOINT: str
    EMBEDDING_KEY: str
    EMBEDDING_MODEL_NAME: str = "text-embedding-3-large"
    EMBEDDING_DEPLOYMENT: str

    AZURE_AI_SEARCH_ENDPOINT: str = "https://infratf-cog.search.windows.net"
    AZURE_AI_SEARCH_KEY: str = ""
    AZURE_AI_SEARCH_INDEX: str = "lkmdev250430"

    AZURE_DOCINTELLIGENCE_ENDPOINT: str
    AZURE_DOCINTELLIGENCE_KEY: str

    CMMN_API_URI: str = ""
    CMMN_API_KEY: str = ""

    # URI : 내부 통신 엔드포인트
    # URL : 외부(사용자) 접근용
    AI_CHAT_URI: str = "http://ai-chat:8010"
    GBAA_CHAT_URL: str = ""

    AIMM_API_URI: str = ""
    AIMM_API_KEY: str = ""

    LANGFUSE_HOST: str = "localhost"
    LANGFUSE_SECRET_KEY: str = ""
    LANGFUSE_PUBLIC_KEY: str = ""

    # 보안관련
    JWT_SECRET_KEY: str = ""
    JWT_ALGORITHM: str = "HS256"
    REDIS_TOKEN_PREFIX: str = "token:"
    TOKEN_EXPIRE_TIME: int = 60 * 60 * 24  # 24 hours
    REFRESH_TOKEN_EXPIRE_TIME: int = 60 * 60 * 24 * 7  # 7 days

    STATIC_PATH: str = str(Path(__file__).resolve().parent.parent / "static")

    # Aspose Cloud
    ASPOSE_CLOUD_CLIENT_ID: str = ""
    ASPOSE_CLOUD_CLIENT_SECRET: str = ""


@lru_cache()
def get_setting():
    return Settings()
