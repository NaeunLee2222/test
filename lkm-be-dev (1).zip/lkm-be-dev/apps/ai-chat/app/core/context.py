from contextvars import ContextVar
from typing import Optional

from services.schemas.auth import UserInfo

user_info_ctx: ContextVar[Optional[UserInfo]] = ContextVar("user_info", default=None)
transaction_id_ctx: ContextVar[str] = ContextVar("transaction_id", default="")


def get_current_user_info() -> UserInfo:
    if user_info_ctx.get() is None:
        return UserInfo(user_id="")
    else:
        return user_info_ctx.get()


def get_transaction_id() -> str:
    return transaction_id_ctx.get()
