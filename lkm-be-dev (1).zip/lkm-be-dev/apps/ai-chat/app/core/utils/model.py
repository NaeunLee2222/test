from core.log.logging import get_logging
from core.utils.stream import StreamHandler
from core.utils.token_cost import TokenCostProcess
from langchain_openai import AzureChatOpenAI
from pathlib import Path
import json
from core.config import get_setting

logger = get_logging()
settings = get_setting()


def get_model(kind, deployment, model, endpoint, api_version, api_key, **param):
    cost_process = TokenCostProcess()
    logger.info(
        f"[get_model] with params ... \ndeployment:{deployment}\nmodel:{model}\nendpoint:{endpoint}\napi_version:{api_version}"
    )
    if kind == "AzureChatOpenAI":
        llm = AzureChatOpenAI(
            azure_deployment=deployment,
            azure_endpoint=endpoint,
            api_version=api_version,
            api_key=api_key,
            n=1,
            temperature=0,
            max_tokens=None,
            tiktoken_model_name=model,
            model=model,
            timeout=None,
            verbose=True,
            streaming=True,
            callbacks=[
                StreamHandler(
                    model,
                    cost_process,
                )
            ],
        )
    else:
        raise Exception(f"Invalid model kind: {kind}")
    return llm, cost_process

def get_model_names():
    try:
        models_path = Path(settings.STATIC_PATH) / "models.json"
        with open(models_path, "r", encoding="utf-8") as f:
            models = json.load(f)
        return [{"name": model["name"], "description": model["description"]} for model in models]
    except Exception as e:
        raise RuntimeError(f"Failed to load model names: {str(e)}")
