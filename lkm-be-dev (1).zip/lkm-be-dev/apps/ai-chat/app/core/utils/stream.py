import queue
import time
from typing import Any, Dict, List

import tiktoken
from core.log.logging import get_logging
from langchain.callbacks.base import BaseCallbackHandler
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

logger = get_logging()


class ThreadedGenerator:
    def __init__(self):
        self.queue = queue.Queue()

    def __iter__(self):
        return self

    def __next__(self):
        item = self.queue.get()
        if item is StopIteration:
            raise item
        return item

    def send(self, data):
        self.queue.put(data)

    def close(self):
        self.queue.put(StopIteration)


class ChainStreamHandler(StreamingStdOutCallbackHandler):
    def __init__(self, gen, model, token_cost_process):
        super().__init__()
        self.gen = gen
        self.start_time = time.time()
        self.first_time = None
        self.end_time = None
        self.model = model
        self.token_cost_process = token_cost_process

    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> None:
        encoding = tiktoken.encoding_for_model(self.model)

        if self.token_cost_process == None:
            return

        for prompt in prompts:
            self.token_cost_process.sum_prompt_tokens(len(encoding.encode(prompt)))

    def on_llm_new_token(self, token: str, **kwargs):
        if self.first_time is None:
            self.first_time = time.time()

        # self.gen.send(json.dumps({"type": "token", "data": token}) + '\n') if token else None
        self.token_cost_process.sum_completion_tokens(1)

    def on_llm_end(self, response, **kwargs):
        self.token_cost_process.sum_successful_requests(1)
        self.end_time = time.time()


class StreamHandler(BaseCallbackHandler):
    def __init__(
        self,
        model,
        token_cost_process,
        initial_text="",
        delay=0.01,
    ):
        self.model = model
        self.start_time = time.time()
        self.first_time = None
        self.end_time = None
        self.text = initial_text
        self.delay = delay  # 추가된 지연 시간
        self.token_cost_process = token_cost_process

    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> None:
        try:
            encoding = tiktoken.encoding_for_model(self.model)
        except Exception as e:
            logger.error(f"Error in encoding_for_model: {e}")
            encoding = tiktoken.encoding_for_model("gpt-3.5-turbo")

        if self.token_cost_process is None:
            return
        for prompt in prompts:
            # logger.debug(f"On LLM Start: \n{prompt}")
            self.token_cost_process.sum_prompt_tokens(len(encoding.encode(prompt)))

    def on_llm_new_token(self, token: str, **kwargs) -> None:
        self.text += token

        if self.first_time is None:
            self.first_time = time.time()

        self.token_cost_process.sum_completion_tokens(1)

        time.sleep(self.delay)

    def on_llm_end(self, response, **kwargs):
        self.token_cost_process.sum_successful_requests(1)
        self.end_time = time.time()

    def reset_text(self):
        # 스트림의 텍스트를 초기화하는 메서드
        self.text = ""
