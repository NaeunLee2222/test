import aiohttp
import requests
from core.config import get_setting
from core.log.logging import get_logging

settings = get_setting()
logger = get_logging()

header_user = {
    "Authorization": settings.SYSTEM_USER_TOKEN,
    "id": settings.SYSTEM_USER_ID,
    "email": settings.SYSTEM_USER_EMAIL,
    "name": settings.SYSTEM_USER_NAME,
}


async def http_arequest(method, endpoint, header=None, param=None, payload=None):
    async with aiohttp.ClientSession() as session:
        headers = {"Content-Type": "application/json", **(header or {})}
        try:
            if method.lower() == "get":
                async with session.get(
                    endpoint, headers=headers, params=param
                ) as response:
                    return await response.json()
            elif method.lower() == "post":
                async with session.post(
                    endpoint, headers=headers, json=payload
                ) as response:
                    return await response.json()
            # 다른 HTTP 메서드에 대한 처리도 추가
            elif method.lower() == "put":
                async with session.put(
                    endpoint, headers=headers, json=payload
                ) as response:
                    return await response.json()
            elif method.lower() == "delete":
                async with session.delete(
                    endpoint, headers=headers, json=payload
                ) as response:
                    return await response.json()

            if response.status == 200:
                return await response.json()
            else:
                logger.error(
                    f"HTTP request failed: {response.status} {await response.text()}"
                )
                raise Exception("Failed to request")
        except aiohttp.ClientError as e:
            logger.error(f"HTTP request failed: {str(e)}")
            raise


def http_request(
    method: str, endpoint: str, header: dict | None, param: dict | None, payload: dict
):
    try:
        if param:
            endpoint = endpoint.format(**param)

        if header is None:
            header = header_user

        if method == "post":
            logger.info(f"[http_request] post requests uri: {endpoint} body: {payload}")
            response = requests.post(endpoint, headers=header_user, json=payload)
        elif method == "put":
            logger.info(f"[http_request] put requests uri: {endpoint} body: {payload}")
            response = requests.put(endpoint, headers=header_user, json=payload)
        elif method == "get":
            logger.info(f"[http_request] get requests uri: {endpoint} body: {payload}")
            response = requests.get(endpoint, headers=header_user)
        elif method == "delete":
            logger.info(
                f"[http_request]delete requests uri: {endpoint} body: {payload}"
            )
            response = requests.delete(endpoint, headers=header_user, json=payload)

        if response.status_code == 200:
            logger.info("request successful")
            return response.text
        else:
            logger.info(f"Failed to request: {response.text}")
            raise Exception(f"Failed to requests")
    except:
        raise
