import tiktoken

EMBEDDING_MODEL_COST_PER_1K_TOKENS = {
    "text-ada-001": 0.0004,
    "ada": 0.0004,
    "text-babbage-001": 0.0005,
    "babbage": 0.0005,
    "text-curie-001": 0.002,
    "curie": 0.002,
    "text-davinci-003": 0.02,
    "text-davinci-002": 0.02,
    "code-davinci-002": 0.02,
    "text-embedding-3-small": 0.00002,  # Per 1,000 tokens 0.00002
    "text-embedding-3-large": 0.00013,  # Per 1,000 tokens 0.00013
    "text-embedding-ada-002": 0.0001,  # Per 1,000 tokens 0.0001
}
READ_COST_PER_PAGES = {
    "document-intelligence-read": 0.0015,
    "document-intelligence-prebuilt": 0.01,
}
CHAT_MODEL_COST_PER_1K_TOKENS = {
    "gpt-4": {
        "input": 0.03,
        "output": 0.06,
    },
    "gpt-4o": {
        "input": 0.005,
        "output": 0.015,
    },
    "gpt-4-0314": {
        "input": 0.03,
        "output": 0.06,
    },
    "gpt-4-32k": {
        "input": 0.06,
        "output": 0.12,
    },
    "gpt-4-32k-0314": {
        "input": 0.06,
        "output": 0.12,
    },
    "gpt-3.5-turbo": {
        "input": 0.0005,
        "output": 0.0015,
    },
    "gpt-3.5-turbo-0301": {
        "input": 0.002,
        "output": 0.002,
    },
    "text-ada-001": {
        "input": 0.0004,
        "output": 0.0004,
    },
    "ada": {
        "input": 0.0004,
        "output": 0.0004,
    },
    "text-babbage-001": {
        "input": 0.0005,
        "output": 0.0005,
    },
    "babbage": {
        "input": 0.0005,
        "output": 0.0005,
    },
    "text-curie-001": {
        "input": 0.002,
        "output": 0.002,
    },
    "curie": {
        "input": 0.002,
        "output": 0.002,
    },
    "text-davinci-003": {
        "input": 0.02,
        "output": 0.02,
    },
    "text-davinci-002": {
        "input": 0.02,
        "output": 0.02,
    },
    "code-davinci-002": {
        "input": 0.02,
        "output": 0.02,
    },
    "default": {
        "input": 0.03,
        "output": 0.03,
    },
}


class Token:
    prompt: int = 0
    completion: int = 0


class CostProcess:
    """cost calculate (USD)"""

    embedding_tokens: int = 0
    token_cost: float = 0
    read_cost: float = 0
    chat_prompt_tokens: float = 0
    chat_completion_tokens: float = 0
    chat_successful_requests: int = 0
    chat_token_cost: float = 0

    def sum_prompt_tokens(self, prompt_tokens: int = 0):
        self.chat_prompt_tokens += prompt_tokens

    def sum_completion_tokens(self, completion_tokens: int = 0):
        self.chat_completion_tokens += completion_tokens

    def sum_successful_requests(self, requests: int):
        self.chat_successful_requests = self.chat_successful_requests + requests

    def get_token_cnt(self, model: str, text: str):
        tokenizer = tiktoken.encoding_for_model(model)
        return len(tokenizer.encode(text))

    def get_embedding_token_cost(self, model: str, tokens: int):
        self.embedding_tokens = self.embedding_tokens + tokens
        cost = EMBEDDING_MODEL_COST_PER_1K_TOKENS[model] * tokens / 1000
        self.token_cost = self.token_cost + cost
        return self.token_cost

    def estimate_embedding_token_cost_with_planetext(self, model: str, text: str):
        tokens = self.get_token_cnt(model, text)
        cost = EMBEDDING_MODEL_COST_PER_1K_TOKENS[model] * tokens / 1000
        return cost

    def get_embedding_token_cost_with_plaintext(self, model: str, text: str):
        tokens = self.get_token_cnt(model, text)
        self.embedding_tokens = self.embedding_tokens + tokens
        cost = EMBEDDING_MODEL_COST_PER_1K_TOKENS[model] * tokens / 1000
        self.token_cost = self.token_cost + cost
        return self.token_cost

    def get_document_read_cost(self, reader: str, pages: int):
        cost = READ_COST_PER_PAGES[reader] * pages
        self.read_cost = self.read_cost + cost
        return self.read_cost

    def estimate_document_read_cost(self, reader: str, pages: int):
        cost = READ_COST_PER_PAGES[reader] * pages
        return cost

    def calculate_openai_total_cost_for_model(self, model: str) -> float:
        """USD"""
        model_cost = CHAT_MODEL_COST_PER_1K_TOKENS.get(model)
        if not model_cost:
            model_cost = CHAT_MODEL_COST_PER_1K_TOKENS["default"]

        input_cost = model_cost["input"] * self.chat_prompt_tokens / 1000
        output_cost = model_cost["output"] * self.chat_completion_tokens / 1000
        self.chat_token_cost = input_cost + output_cost

        return self.chat_token_cost

    def get_cost(self):
        return self.read_cost + self.token_cost + self.chat_token_cost

    def sum(self, target: "CostProcess"):
        if target:
            self.embedding_tokens += target.embedding_tokens
            self.token_cost += target.token_cost
            self.read_cost += target.read_cost
            self.chat_prompt_tokens += target.chat_prompt_tokens
            self.chat_completion_tokens += target.chat_completion_tokens
            self.chat_successful_requests += target.chat_successful_requests
            self.chat_token_cost += target.chat_token_cost
        return self
