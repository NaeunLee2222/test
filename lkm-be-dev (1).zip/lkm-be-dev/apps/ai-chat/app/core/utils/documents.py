import os
import uuid
from typing import List

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.celery import check_celery_health
from fastapi import HTTPException, UploadFile
from services import documents
from services.schemas.documents import DocCreate
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()
settings = get_setting()


async def upload_documents(
    user_id: int,
    chat_id: str,
    search_index_name: str,
    files: List[UploadFile],
    db: AsyncSession,
    celery_app,
):
    # local_file_handler = LocalFileHandler(
    #     settings.DOCUMENT_PATH, settings.MAX_FILE_SIZE
    # )
    for file in files:
        document = None
        try:
            # file save
            # TODO: mount 폴더 및 blob storage에 저장
            _, f_ext = os.path.splitext(file.filename)
            uuid_filename = f"{uuid.uuid4().hex}{f_ext}"

            file_content = await file.read()
            filepath = os.path.join(settings.DATA_PATH, uuid_filename)
            with open(filepath, "wb") as f:
                f.write(file_content)

            document = await documents.create_document(
                db=db,
                doc_data=DocCreate(
                    user_id=user_id,
                    chat_id=chat_id,
                    original_filename=file.filename,
                    uuid_filename=uuid_filename,
                    file_type=file.content_type,
                    index_name=search_index_name,
                ),
            )

            # celery health check
            if not check_celery_health(celery_app):
                raise HTTPException(
                    status_code=400,
                    detail="Celery is not available. Please try again later.",
                )
            task = celery_app.send_task(
                "embedding_chat_document",
                args=[
                    document.id,
                    uuid_filename,
                ],
            )
            logger.info(
                f"TASK [upload_documents {document.id}] state: {task.state}, ready: {task.ready()}"
            )
            if task.state == "FAILURE":
                await documents.update_document_state(
                    db, doc_id=document.id, state="FAILURE"
                )
                yield {"state": "FAILURE", "file": document}
            else:
                await documents.update_document_state(
                    db, doc_id=document.id, state="WAIT"
                )
                yield {"state": "WAIT", "file": document}
        except Exception as e:
            logger.error(
                f"[upload_documents] Error while processing file {file.filename}"
            )
            if document:
                await documents.update_document_state(
                    db, doc_id=document.id, state="FAILURE"
                )
                yield {"state": "FAILURE", "file": document}
                logger.error(str(e))
