import re

from core.config import get_setting

settings = get_setting()


def parsing_email(email: str):
    if not email:
        return None
    if "@" in email:
        return email.split("@")[0]
    return email


def make_email(id: str):
    if "@" in id:
        return id
    return id + get_company_email()


def get_company_email():
    postfix = None
    if settings.COMPANY == "SKCC":
        postfix = "@skcc.com"
    return postfix


def transform_company_email(email: str) -> str:
    """
    Transform email domain based on company settings
    """
    if email and email.endswith("sk.com"):
        if settings.COMPANY == "SKT":
            return email.replace("sk.com", "sktelecom.com")
        elif settings.COMPANY == "SKCC":
            return email.replace("sk.com", "skcc.com")
    return email


def has_user_search_pattern(content: str) -> bool:
    """
    Check if the content contains user search pattern: @name(id/email)
    Example pattern: @홍길동(P19111/user.name.sk.com)

    Args:
        content (str): Text to check for user search patterns

    Returns:
        bool: True if pattern exists, False otherwise
    """
    pattern = r"@[^(]+\([^/]+/[^)]+\)"
    return bool(re.search(pattern, content))


def transform_user_search_pattern_email(content: str) -> str:
    """
    Transform email domain in user search pattern: @name(id/email)
    Example: @홍길동(P19111/username@sk.com) -> @홍길동(P19111/username@sktelecom.com)

    Args:
        content (str): Text containing user search patterns

    Returns:
        str: Text with transformed email domains in user search patterns
    """
    pattern = r"@[^(]+\([^/]+/([^)]+)\)"
    matches = re.finditer(pattern, content)

    for match in matches:
        full_pattern = match.group(0)
        email = match.group(1)
        transformed_email = transform_company_email(email)
        replaced = full_pattern.replace(email, transformed_email)
        content = content.replace(full_pattern, replaced)

    return content
