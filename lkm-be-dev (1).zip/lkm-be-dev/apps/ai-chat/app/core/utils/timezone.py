from datetime import datetime, timedelta, timezone


def convert_timezone(original_time):
    # UTC 날짜 문자열을 Python datetime 객체로 변환
    utc_time = datetime.strptime(original_time, "%Y-%m-%dT%H:%M:%S.%fZ")

    # UTC+9 (한국 시간)으로 변환
    kst_time = utc_time.replace(tzinfo=timezone.utc).astimezone(
        timezone(timedelta(hours=9))
    )

    # 원하는 포맷으로 변환 (예: "2025-01-23 20:16:42")
    formatted_kst_time = kst_time.strftime("%Y-%m-%d %H:%M:%S")

    return formatted_kst_time
