import time
from typing import Dict, List
from core.log.logging import get_logging

logger = get_logging()


def check_celery_health(celery_app, max_retries=3, delay=5):
    for attempt in range(1, max_retries + 1):
        try:
            inspect = celery_app.control.inspect()
            availability: List[Dict] = inspect.ping()
            logger.info(f"inspect.ping(): {availability}")
            if any(server.get("ok") == "pong" for server in availability.values()):
                logger.info("Celery health check passed.")
                return True

            logger.info(
                f"Celery health check attempt {attempt} failed. Retrying in {delay} seconds..."
            )
        except Exception as e:
            logger.error(f"Celery health check attempt {attempt} failed: {str(e)}")
            time.sleep(delay)

    logger.error("Celery is not available after retries.")
    return False
