from core.log.logging import get_logging
from core.utils.state import State

logger = get_logging()


def store_token(state: State, cost_process, tiktoken_model_name, agent_name):
    logger.info(f"[{agent_name}] >> store_token")
    prompt_tokens = cost_process.prompt_tokens
    completion_tokens = cost_process.completion_tokens
    cost = cost_process.calculate_openai_total_cost_for_model(tiktoken_model_name)
    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "cost": cost,
    }
