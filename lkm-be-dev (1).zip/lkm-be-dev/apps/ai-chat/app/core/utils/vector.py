import re
import traceback
from typing import List, Dict
from datetime import datetime, timedelta

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import SearchIndex
from azure.search.documents.models import VectorizedQuery

from concurrent.futures import ThreadPoolExecutor, as_completed

from core.utils.docintelligence import Page
from core.log.logging import get_logging

logger = get_logging()


class VectorApproach:
    def __init__(
        self,
        search_index: str,
        search_endpoint: str,
        search_key: str,
        embedding_approach,
    ):
        self.search_index = search_index
        self.search_endpoint = search_endpoint
        self.search_key = search_key
        self.embedding_approach = embedding_approach

    def get_search_client(self):
        logger.debug(f"Making {self.search_endpoint} client...")
        return SearchClient(
            self.search_endpoint, self.search_index, AzureKeyCredential(self.search_key)
        )

    def embedding_section(
        self, search_client: SearchClient, user_id, index: int, page: Page
    ) -> int:
        document = {
            "id": f"{user_id}-{page.metadata.get('doc_id')}-page-{page.metadata.get('page_num')}-{index}",
            "content": page.page_content,
            "content_vector": self.embedding_approach.embed_query(
                text=page.page_content
            ),
            "sourcepage": f"{page.metadata.get('filename')}"
            + (f"#page={page.metadata.get('page_num')}"),
            "sourcefile": page.metadata.get('filename'),
            "sourcefile_id": page.metadata.get('doc_id'),
            "created_at": datetime.utcnow(),
            "user_id": f"{user_id}",
        }
        search_client.upload_documents([document])
        return index

    def upload_pages(self, user_id, pages: List[Page]):
        """
        upload pages to azure search
        """
        succeed = True
        with self.get_search_client() as search_client:
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = [
                    executor.submit(
                        self.embedding_section, search_client, user_id, i, page
                    )
                    for i, page in enumerate(pages)
                ]
                for future in as_completed(futures):
                    try:
                        result = future.result()
                    except Exception as e:
                        logger.error(f"An error occurred: {e}")
                        succeed = False
        logger.info(f"embedding complete")
        return succeed

    # TODO: vector search
    # def create_filter(self, user_key: str | None, doc_ids: List[int]):
    #     filter = f"(userid eq '{user_key}')" if user_key is not None else ""
    #     if doc_ids is not None:
    #         docs_filter = ""
    #         for id in doc_ids:
    #             if docs_filter:
    #                 docs_filter += " or "
    #             docs_filter += f"sourcefileid eq {id}"
    #         if filter:
    #             filter += " and "
    #         filter = filter + "(" + docs_filter + ")"
    #     return filter

    # def search_vector(self, user_key: str | None, doc_ids: List[int], query, n):
    #     if not self.embedding_approach:
    #         raise ServiceException(
    #             400, ErrorCode.NOT_DEFINED, "There is no embedding model."
    #         )
    #     search_client = self.get_search_client()
    #     if user_key == "mybox":
    #         user_key = None
    #     filter = self.create_filter(user_key, doc_ids)
    #     embedding = self.embedding_approach.generate_embeddings(text=query)
    #     vector_query = VectorizedQuery(
    #         vector=embedding, k_nearest_neighbors=n, fields="content_vector"
    #     )

    #     docs = search_client.search(
    #         search_text=query,
    #         filter=filter,
    #         vector_queries=[vector_query],
    #         top=n,
    #         select=["sourcepage", "content", "userid", "sourcefileid"],
    #     )

    #     return [
    #         {
    #             "file_name": f"{doc['sourcefileid']}/{doc['sourcepage']}",
    #             "content": doc["content"],
    #         }
    #         for doc in docs
    #     ]
