import time
import traceback
import uuid

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.cost import CostProcess
from database.session import AsyncSessionLocal
from sqlalchemy.orm import Session, scoped_session

sess = scoped_session(AsyncSessionLocal)
settings = get_setting()
logger = get_logging()


async def action_tasks(
    txid: str,
    db: Session,
    redis,
    cost_process: CostProcess,
):
    """
    Args:
        txid (str): txid
        db (Session): db session
        cost_process (CostProcess): cost process
    """
    if not txid:
        txid = uuid.uuid4().hex
    logger.info(f"[{txid}] ACTION_TASK: action_task start.")

    try:
        time_step0 = time.time()

        ## STEP1 : (ex) Call Action Flow
        logger.info(f"[{txid}] STEP1: ")
        time_step1 = time.time()

    except Exception as e:
        logger.error(f"[{txid}] ACTION_TASK: error.")
        logger.error(e)
        traceback.print_exc()
    finally:
        # cost 계산
        cost = cost_process.get_cost()
        logger.info(f"[{txid}] ACTION_TASK: cost : {cost}")
    elapsed_time = time.time() - time_step0
    logger.info(f"[{txid}] ACTION_TASK: action_task tooks {elapsed_time} seconds.")
