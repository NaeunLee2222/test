import core.utils.pricing_per_model as Pricing
import tiktoken
from core.log.logging import get_logging

logger = get_logging()


class TokenCostProcess:
    model_name: str = ""
    total_tokens: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    token_cost: float = 0
    successful_requests: int = 0

    def __init__(self):
        self.tokens = {}

    def get_token_cnt(self, model: str, ask: str):
        try:
            tokenizer = tiktoken.encoding_for_model(model)
        except Exception as e:
            logger.error(e)
            tokenizer = tiktoken.encoding_for_model("gpt-4o")
        return len(tokenizer.encode(ask))

    def sum_prompt_tokens(self, prompt_tokens: int = 0):
        self.prompt_tokens += prompt_tokens

    def sum_completion_tokens(self, completion_tokens: int = 0):
        self.completion_tokens += completion_tokens

    def sum_successful_requests(self, requests: int):
        self.successful_requests = self.successful_requests + requests

    def calculate_openai_total_cost_for_model(self, model: str | None) -> float:
        """USD"""
        if not model:
            model = "gpt-4o"
        model_cost = Pricing.MODEL_COST_PER_1K_TOKENS.get(model)
        if not model_cost:
            logger.error(
                f"MODEL_COST_PER_1K_TOKENS for {model} is not specified.  Please add the cost for the model in MODEL_COST_PER_1K_TOKENS dictionary."
            )
            model_cost = Pricing.MODEL_COST_PER_1K_TOKENS["default"]

        input_cost = model_cost["input"] * self.prompt_tokens / 1000
        output_cost = model_cost["output"] * self.completion_tokens / 1000
        token_cost = input_cost + output_cost
        self.token_cost = token_cost

        return self.token_cost
