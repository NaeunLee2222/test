import json
import os
from pathlib import Path


class ConfigLoader:
    BASE_DIR = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    CONFIG_DIR = BASE_DIR / "settings"

    @classmethod
    def load_settings_json(cls, filename: str) -> dict:
        return cls._load_json(cls.CONFIG_DIR / filename)

    @staticmethod
    def _load_json(filepath: Path) -> dict:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
