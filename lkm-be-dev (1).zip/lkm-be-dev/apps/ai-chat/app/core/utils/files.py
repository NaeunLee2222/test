from typing import List
import unicodedata
from fastapi import UploadFile


def normalize_unicode_files(
    files: list[UploadFile],
) -> List[UploadFile]:
    """normalize filename
    Output:
        RFQ [sample]/v1 (draft).pdf -> RFQ_samplev1_draft.pdf

    """

    def convert_filename(file: UploadFile):
        file.filename = file.filename.translate(
            str.maketrans(
                {"#": "", "/": "", "[": "", "]": "", "(": "", ")": "", " ": "_"}
            )
        )
        file.filename = unicodedata.normalize("NFC", file.filename)
        return file

    return list(map(convert_filename, files))


# TODO: filesize, fileformat, filecount
# MAX_TOTAL_FILE_SIZE_BYTES = LocalFileHandler.file_size_to_int(
#     settings.MAX_TOTAL_FILE_SIZE
# )

# def validate_files_uploads(files: List[UploadFile]) -> bool:
#     """
#     Validates a list of files for upload.

#     This function checks each file in the provided list to ensure it meets the specified constraints:
#     - The number of files does not exceed `MAX_FILE_COUNT`.
#     - The total size of all files combined does not exceed `MAX_TOTAL_FILE_SIZE_MB`.

#     Parameters:
#     file_list (list): A list of file objects to be validated.

#     Returns:
#     bool: True if all files meet the constraints, False otherwise.
#     """
#     try:
#         if len(files) > settings.MAX_FILE_COUNT:
#             raise ServiceException(
#                 status_code=400,
#                 error_code=ErrorCode.FILE_LIMIT_EXCEEDED,
#                 detail=f"Exceed the maximum limit of file count. {settings.MAX_FILE_COUNT}",
#             )

#         total_size: int = 0
#         for file in files:
#             total_size += file.size
#             if total_size > MAX_TOTAL_FILE_SIZE_BYTES:
#                 raise ServiceException(
#                     status_code=400,
#                     error_code=ErrorCode.FILE_LIMIT_EXCEEDED,
#                     detail=f"Exceed the maximum limit of total file size. {MAX_TOTAL_FILE_SIZE_BYTES}",
#                 )
#         return True
#     except ServiceException:
#         raise
#     except Exception as e:
#         logger.error(str(e))
#         traceback.print_exc()
#         raise ServiceException(
#             status_code=500,
#             error_code=ErrorCode.UNEXPECTED_ERROR,
#             detail=str(e),
#         )
