import asyncio
import json

from core.config import get_setting
from core.log.logging import get_logging

import redis

settings = get_setting()
logger = get_logging()


async def consume_messages(r, stream_name, group_name, consumer_name, process_message):
    try:
        # 소비자 그룹 생성 (이미 존재하는 경우 무시)
        try:
            r.xgroup_create(stream_name, group_name, id="0", mkstream=True)
        except redis.RedisError as e:
            if "BUSYGROUP Consumer Group name already exists" in str(e):
                logger.info(
                    f"Consumer group '{group_name}' already exists for stream '{stream_name}'"
                )
            else:
                logger.error(f"Unexpected Redis error: {e}")
                raise

        while True:
            try:
                messages = r.xreadgroup(
                    group_name, consumer_name, {stream_name: ">"}, count=1, block=0
                )

                if messages:
                    for _, message_list in messages:
                        for message_id, message in message_list:
                            message_data = json.loads(message[b"message"])
                            process_message(message_data)

                            r.xack(stream_name, group_name, message_id)

                await asyncio.sleep(0.01)
            except Exception as e:
                logger.error(f"Error processing message: {e}")
    except Exception as e:
        logger.error(f"Error in consumer: {e}")


def produce_message(r, stream_name, message):
    try:
        message_json = json.dumps(message)
        message_id = r.xadd(stream_name, {"message": message_json})
        logger.debug(f"Message added to stream {stream_name} with ID: {message_id}")
        return message_id
    except Exception as e:
        logger.error(f"Error producing message: {e}")
