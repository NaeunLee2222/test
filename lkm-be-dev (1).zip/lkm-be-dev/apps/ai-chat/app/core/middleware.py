import logging
import time
import uuid
from typing import Callable

from core.config import get_setting
from core.context import transaction_id_ctx, user_info_ctx
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

settings = get_setting()


class UserInfoMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        token = user_info_ctx.set(None)
        try:
            response = await call_next(request)
            return response
        finally:
            user_info_ctx.reset(token)


class LoggingMiddleware(BaseHTTPMiddleware):
    # 로깅 제외할 경로 정의
    EXCLUDE_PATHS = {"/health"}

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if request.url.path in self.EXCLUDE_PATHS:
            return await call_next(request)

        transaction_id = str(uuid.uuid4())
        token = transaction_id_ctx.set(transaction_id)
        start_time = time.time()
        logger = logging.getLogger(settings.APP_NAME)

        try:
            body = None
            if request.method in ["POST", "PUT", "PATCH"]:
                try:
                    body = await request.json()
                except:
                    body = await request.body()

            headers = {
                "user-agent": request.headers.get("user-agent"),
                "accept": request.headers.get("accept"),
                "content-type": request.headers.get("content-type"),
                "authorization": request.headers.get("authorization"),
            }
            log_dict = {
                "method": request.method,
                "path": request.url.path,
                "query_params": dict(request.query_params),
                "headers": headers,
            }
            logger.info(f"API Request Started: {log_dict}")
            logger.debug(f"Request Body: {body}")

            response = await call_next(request)
            process_time = time.time() - start_time
            logger.info(
                f"API Request Completed: {log_dict}, status_code={response.status_code}, process_time={process_time:.3f}s"
            )

            return response
        finally:
            transaction_id_ctx.reset(token)
