# ENV

<!-- |Name|Type|Default|Description| -->
<!-- |---|---|---|---| -->

# Local RUN

## main applcation

```
python3 -m venv venv
source venv/bin/activate
pip3 install -r app/requirements.txt
python3 app/main.py
```

## celery worker application

### 1. Setting redis for communicate with local celery worker

#### local 에서 docker 로 redis 띄우기

```
docker run --name redis -v $(pwd)/redis:/data -p 6379:6379 -d redis --save "" --requirepass "mypassword"
docker exec -it redis bash
> redis-cli
127.0.0.1:6379> config set requirepass mypassword
OK
127.0.0.1:6379> config set save ""
OK
127.0.0.1:6379> auth mypassword
OK

127.0.0.1:6379> exit
root@aab09f02cf99:/data# exit
exit
```

redis connection 설정 변경

```
vi .env

C_REDIS_HOST=localhost
C_REDIS_PORT=6379
C_REDIS_ACCESS_KEY=mypassword
C_REDIS_USE_SSL=False
```

### 2. Run celery worker

open new terminal and execute

```
# open new terminal
source venv/bin/activate
set -a; source .env; set +a;
cd app
celery -A worker worker --loglevel=info
```

<!-- # Build & RUN

VERSION=1.0.0

## main applcation

### build

```
docker build -t skccaichatbot.azurecr.io/sk-chat-docs-svc:$VERSION .
```

### local PC 에서 run

```
docker run -v ./localfile -it -p 8030:8030 --env-file=../.env -d skccaichatbot.azurecr.io/sk-chat-docs-svc:$VERSION
```

### image push

```
docker push skccaichatbot.azurecr.io/sk-chat-docs-svc:$VERSION
```

### demo VM에서 신규 이미지로 run

```
docker pull skccaichatbot.azurecr.io/sk-chat-docs-svc:$VERSION
docker compose up -d
```

## celery worker applciation

### build

```
docker build -f Dockerfile.worker -t skccaichatbot.azurecr.io/sk-chat-docs-celery:$VERSION  .
```

### local PC 에서 run

```
docker run -it --env-file=../.env -d skccaichatbot.azurecr.io/{sk-chat-docs-celery}:$VERSION
```
