from contextvars import ContextVar
from typing import Any, Dict, Optional

from services.schemas.user.user_info import UserInfo

user_info_ctx: ContextVar[Optional[UserInfo]] = ContextVar("user_info", default=None)
transaction_id_ctx: ContextVar[str] = ContextVar("transaction_id", default="")
chat_message_id_ctx: ContextVar[str] = ContextVar("chat_message_id", default="")


def get_current_user_info() -> UserInfo:
    if user_info_ctx.get() is None:
        return UserInfo(user_id="")
    else:
        return user_info_ctx.get()


def get_transaction_id() -> str:
    return transaction_id_ctx.get()


def get_chat_message_id() -> str:
    return chat_message_id_ctx.get()


def set_chat_contexts(
    user_info: Optional[UserInfo], last_user_chat_message: Dict[str, Any]
) -> None:
    user_info_ctx.set(user_info)
    chat_message_id_ctx.set(last_user_chat_message.get("id"))
