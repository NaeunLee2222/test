from typing import Any, Dict

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class APIClient:
    """API 호출을 위한 공통 클라이언트"""

    def __init__(
        self,
        timeout: tuple[int, int] = (5, 15),
        max_retries: int = 3,
        retry_delay: float = 0.5,
        status_forcelist: tuple = (500, 502, 503, 504),
    ):
        """
        Args:
            timeout (tuple[int, int]): (연결 타임아웃, 읽기 타임아웃)
            max_retries (int): 최대 재시도 횟수
            retry_delay (float): 재시도 간 대기 시간 계수
            status_forcelist (tuple): 재시도할 HTTP 상태 코드 목록
        """
        self.timeout = timeout
        self.session = self._create_retry_session(
            max_retries, retry_delay, status_forcelist
        )

    def _create_retry_session(
        self, retries: int, backoff_factor: float, status_forcelist: tuple
    ) -> requests.Session:
        """재시도 설정이 포함된 세션 생성"""
        session = requests.Session()
        retry_strategy = Retry(
            total=retries,
            backoff_factor=backoff_factor,
            status_forcelist=status_forcelist,
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str] = None,
        **kwargs: Any,
    ) -> Any:
        """
        API 요청 수행

        Args:
            method (str): HTTP 메서드
            url (str): 요청 URL
            headers (Dict[str, str], optional): HTTP 헤더
            **kwargs: requests 라이브러리에 전달할 추가 인자

        Returns:
            Any: API 응답 데이터

        Raises:
            requests.Timeout: 타임아웃 발생 시
            requests.RequestException: API 호출 실패 시
        """
        try:
            response = self.session.request(
                method=method, url=url, headers=headers, timeout=self.timeout, **kwargs
            )
            response.raise_for_status()
            return response.json()
        except requests.Timeout as e:
            raise requests.Timeout(
                f"요청 시간 초과 (타임아웃: {self.timeout}초): {str(e)}"
            )
        except requests.RequestException as e:
            raise requests.RequestException(f"API 호출 실패: {str(e)}")
        finally:
            self.session.close()
