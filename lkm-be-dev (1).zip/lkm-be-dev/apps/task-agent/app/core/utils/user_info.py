import json
from datetime import datetime, timedelta
from time import time
from typing import Any, Dict

import jwt
import pytz
import redis
import requests

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.api_client import APIClient
from core.utils.auth import get_ms_access_token
from core.utils.redis_client import get_redis_client
from services.company.company_service_factory import CompanyServiceFactory

settings = get_setting()
logger = get_logging()
redis_client = get_redis_client()


class UserInfo:
    def __init__(self, user_id: str):
        self.user_id = user_id

    def update(self, info_dict: dict) -> None:
        for key, value in info_dict.items():
            setattr(self, key, value)

    def to_dict(self) -> dict:
        return {key: value for key, value in self.__dict__.items()}


def get_detailed_user_info(
    user_id: int, username: str = "", user_email: str = ""
) -> UserInfo:
    """사용자의 상세 정보를 조회. 캐시(Redis)에서 먼저 조회하고, 없으면 API를 통해 정보를 가져옴"""
    user_info = UserInfo(user_id)
    if redis_client:
        cached_info = get_cached_user_info(redis_client, user_info.user_id)
        if cached_info:
            user_info.update(cached_info)
            return user_info

    # Redis 사용 불가 또는 캐시가 없는 경우 API 호출
    detailed_user_info = get_user_info_from_api(user_id, username, user_email)
    if detailed_user_info:
        user_info.update(detailed_user_info)
        if redis_client:  # Redis가 사용 가능한 경우에만 캐싱 시도
            try:
                cache_user_info(redis_client, user_info.user_id, user_info)
            except Exception as e:
                logger.error(f"사용자 정보 캐싱 실패: {e}")

    return user_info


def get_cached_user_info(redis_client: redis.Redis, user_id: str) -> dict:
    """Redis에서 사용자 정보 조회"""
    if not redis_client:
        return None

    try:
        cached_data = redis_client.get(f"user_info:{user_id}")
        if cached_data:
            return json.loads(cached_data)
        return None
    except Exception as e:
        logger.error(f"Redis 조회 중 에러 발생: {e}")
        return None


def cache_user_info(
    redis_client: redis.Redis, user_id: str, user_info: UserInfo
) -> None:
    """Redis에 사용자 정보 저장"""
    if not redis_client:
        return
    try:
        ttl_seconds = _get_ttl_seconds()
        redis_client.setex(
            f"ai_chat: user_info:{user_id}",
            ttl_seconds,
            json.dumps(user_info.to_dict()),
        )
    except Exception as e:
        logger.error(f"Redis 저장 중 에러 발생: {e}")
        return


def _get_ttl_seconds(target_hour: int = 4) -> int:
    """n시 까지 남은 초를 계산"""
    timezone = pytz.timezone("Asia/Seoul")
    now = datetime.now(timezone)
    next_day = now + timedelta(days=1)
    next_expiry = next_day.replace(hour=target_hour, minute=0, second=0, microsecond=0)

    # 현재 시간이 N시 이전이면 오늘 N시로 설정
    if now.hour < target_hour:
        next_expiry = now.replace(hour=target_hour, minute=0, second=0, microsecond=0)

    # 현재 timestamp와 만료 timestamp의 차이를 초 단위로 계산
    current_timestamp = datetime.now(timezone).timestamp()
    expiry_timestamp = next_expiry.timestamp()
    ttl_seconds = int(expiry_timestamp - current_timestamp)

    return ttl_seconds


def _is_token_expired(token: str) -> bool:
    """JWT 토큰의 만료 여부 확인"""
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        # 30초 버퍼 설정
        return decoded["exp"] - time() < 30
    except Exception as e:
        logger.error(f"토큰 만료 확인 중 에러 발생: {e}")
        return True


def _get_token_ttl(token: str) -> int:
    """JWT 토큰의 남은 유효 시간(초) 계산"""
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        ttl = decoded["exp"] - time()
        return max(int(ttl), 0)
    except Exception as e:
        logger.error(f"토큰 TTL 계산 중 에러 발생: {e}")
        return 0


def _request_new_ms_token() -> str:
    """Microsoft OAuth 토큰 새로 요청"""

    url = f"https://login.microsoftonline.com/{settings.MS_TENANT_ID}/oauth2/v2.0/token"

    data = {
        "client_id": settings.MS_CLIENT_ID,
        "scope": "https://graph.microsoft.com/.default",
        "client_secret": settings.MS_CLIENT_SECRET,
        "grant_type": "client_credentials",
    }

    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    try:
        response = requests.post(url, data=data, headers=headers)
        response.raise_for_status()  # HTTP 에러 체크
        return response.json().get("access_token")
    except Exception as e:
        logger.error(f"MS 토큰 발급 중 에러 발생: {e}")
        return None


def _request_new_onspace_token(username: str, password: str) -> str:
    """Onspace 토큰 새로 요청"""

    url = "https://onspace.sk.com/websvc/token"

    data = {
        "username": username,
        "password": password,
        "grant_type": "password",
    }

    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    try:
        response = requests.post(url, data=data, headers=headers)
        response.raise_for_status()  # HTTP 에러 체크
        return response.json().get("access_token")
    except Exception as e:
        logger.error(f"Onspace 토큰 발급 중 에러 발생: {e}")
        return None


def get_dummy_user_info(user_id: str) -> Dict[str, Any]:
    """로컬 환경용 더미 유저 정보 반환"""
    if user_id == "P199332":
        return {
            "username": "황소윤",
            "email": "skt.P199332@partner.sktelecom.com",
            "officeId": 1,
            "officeName": "SK T-타워",
            "floorId": 13,
            "floorName": "19층",
            "calendarId": "AQMkAGVjYjNjOTgyLTlmM2YtNDgwZi1hMmQ3LTRlMTlkMGNiNTdjYQBGAAAD6a1VLBYb5EuXmuaaZyieNAcAzaiFaIY8bkyj7LewAVRMJgAAAgEGAAAA1sX1NT3XmUqb66IUUGLqLQAAAVnWOAAAAA==",
        }
    return {
        "username": "김지환",
        "email": "10861@skcc.com",
        "officeId": 1,
        "officeName": "SK T-타워",
        "floorId": 3,
        "floorName": "4층",
        "calendarId": "AAMkADQ2NGFmMzIzLWI4NDQtNGZjMi04NzlhLWU3MzMyZGE3MzZiMQBGAAAAAACFeHSHLEbISKUMRvrKXXX3BwDSSjCQXsU8Qo5GTutAriEPAAAAAAEGAACjEgVAIjCxRYYqZmI35xoFAAAIb0xoAAA=",
    }


def get_default_working_location() -> Dict[str, Any]:
    """기본 근무지 정보 반환"""
    return {
        "officeId": 1,
        "officeName": "SK T-타워",
        "floorId": 13,
        "floorName": "19층",
    }


def get_user_info_from_api(
    user_id: int, username: str = "", user_email: str = ""
) -> dict:
    """
    주어진 사번 정보 바탕으로 필요한 API 에서 유저 정보 획득
    """
    if settings.ENVIRONMENT == "LOCAL":
        return get_dummy_user_info(user_id)

    company_service = CompanyServiceFactory.get_service(settings.COMPANY)
    ms_access_token = get_ms_access_token()

    # 캘린더 ID 조회
    calendar_id = ""
    try:
        calendar_id = get_calendar_id(
            user_email=user_email,
            access_token=ms_access_token,
            timeout=(5, 10),
            max_retries=2,
            retry_delay=0.5,
        )
    except Exception as e:
        logger.error(f"사용자 기본 캘린더 정보 조회 에러: {str(e)}")

    # 근무지 정보 조회
    user_working_location = {}
    try:
        user_working_location = company_service.get_user_working_location(user_id)
    except Exception as e:
        logger.error(f"사용자 기본 근무지 정보 조회 에러: {str(e)}")
        user_working_location = get_default_working_location()

    return {
        **user_working_location,
        "calendarId": calendar_id,
        "email": user_email,
        "username": username,
    }


def get_calendar_id(
    user_email: str,
    access_token: str,
    timeout: tuple[int, int] = (5, 15),
    max_retries: int = 3,
    retry_delay: float = 0.5,
) -> str:
    """
    사용자의 기본 캘린더 ID를 조회하는 함수

    Args:
        user_email (str): 사용자의 이메일 주소
        access_token (str): Microsoft Graph API 접근 토큰
        timeout (tuple[int, int]): (연결 타임아웃, 읽기 타임아웃)
        max_retries (int): 최대 재시도 횟수
        retry_delay (float): 재시도 간 대기 시간 계수

    Returns:
        str: 사용자의 기본 캘린더 ID
    """
    api_client = APIClient(timeout, max_retries, retry_delay)

    try:
        calendar_data = api_client.request(
            method="GET",
            url=f"https://graph.microsoft.com/v1.0/users/{user_email}/calendar",
            headers={"Authorization": f"Bearer {access_token}"},
        )

        if not calendar_data.get("id"):
            raise ValueError("캘린더 ID가 응답 데이터에 존재하지 않습니다.")

        return calendar_data["id"]

    except (KeyError, TypeError) as e:
        raise ValueError(f"응답 데이터 형식 오류: {str(e)}")
