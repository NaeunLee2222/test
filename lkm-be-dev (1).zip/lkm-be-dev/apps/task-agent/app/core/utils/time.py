from datetime import datetime

import pytz

from core.config import get_setting
from core.log.logging import get_logging

settings = get_setting()
logger = get_logging()


def get_kor_nowtime() -> str:
    """요일을 포함한 한국 기준 현재시간 반환"""
    # 한국 시간대 설정
    korea_tz = pytz.timezone("Asia/Seoul")
    date = datetime.now(korea_tz)

    # 한글 요일 매핑
    weekday_korean = {
        0: "월요일",
        1: "화요일",
        2: "수요일",
        3: "목요일",
        4: "금요일",
        5: "토요일",
        6: "일요일",
    }

    # 날짜, 시간, 요일 포함하여 포맷팅
    return (
        f"{date.strftime('%Y-%m-%d %H:%M:%S')} {weekday_korean[date.weekday()]} (KST)"
    )
