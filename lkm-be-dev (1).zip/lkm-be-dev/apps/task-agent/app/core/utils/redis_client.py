import redis
from redis.sentinel import Sentinel

from core.config import get_setting
from core.log.logging import get_logging

logger = get_logging()
settings = get_setting()


def get_redis_client() -> redis.Redis:
    """Redis 클라이언트 생성 및 연결 상태 확인"""
    try:
        if settings.REDIS_USE_SENTINEL:
            # Redis Sentinel을 통한 연결
            sentinel = Sentinel(
                [(settings.REDIS_SENTINEL_HOST, settings.REDIS_SENTINEL_PORT)],
                password=settings.REDIS_SENTINEL_PASSWORD,
                decode_responses=True,
            )
            client = sentinel.master_for(
                settings.REDIS_SENTINEL_MASTER_NAME,
                password=settings.REDIS_ACCESS_KEY,
                db=settings.REDIS_USER_INFO_DB,
            )
        else:
            # 직접 Redis 연결
            client = redis.Redis(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                db=settings.REDIS_USER_INFO_DB,
                password=settings.REDIS_ACCESS_KEY,
                ssl=settings.REDIS_USE_SSL,
                decode_responses=True,
                socket_timeout=1,
                socket_connect_timeout=1,
            )
        # ping으로 연결 상태 확인
        client.ping()
        return client
    except (redis.ConnectionError, redis.TimeoutError) as e:
        logger.error(f"Redis 연결 실패: {e}")
        return None
