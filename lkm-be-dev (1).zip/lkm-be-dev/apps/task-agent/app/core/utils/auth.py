from time import time
from typing import Optional

import jwt
import requests

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.redis_client import get_redis_client

settings = get_setting()
logger = get_logging()
redis_client = get_redis_client()


class TokenManager:
    """토큰 관리 클래스"""

    @staticmethod
    def get_ms_access_token() -> Optional[str]:
        """Microsoft OAuth 토큰 발급 및 관리"""
        if redis_client:
            cached_token = redis_client.get("ms_access_token")
            if cached_token and not TokenManager._is_token_expired(cached_token):
                return cached_token

        token = TokenManager._request_new_ms_token()
        if token and redis_client:
            ttl = TokenManager._get_token_ttl(token)
            if ttl > 0:
                redis_client.setex("ms_access_token", ttl, token)
        return token

    @staticmethod
    def get_onspace_access_token() -> Optional[str]:
        """Onspace 토큰 발급 및 관리"""

        token = TokenManager._request_new_onspace_token(
            settings.ONSPACE_USER_ID, settings.ONSPACE_USER_PASSWORD
        )
        return token

    @staticmethod
    def _is_token_expired(token: str) -> bool:
        """JWT 토큰의 만료 여부 확인"""
        try:
            decoded = jwt.decode(token, options={"verify_signature": False})
            # 30초 버퍼 설정
            return decoded["exp"] - time() < 30
        except Exception as e:
            logger.error(f"토큰 만료 확인 중 에러 발생: {e}")
            return True

    @staticmethod
    def _get_token_ttl(token: str) -> int:
        """JWT 토큰의 남은 유효 시간(초) 계산"""
        try:
            decoded = jwt.decode(token, options={"verify_signature": False})
            ttl = decoded["exp"] - time()
            return max(int(ttl), 0)
        except Exception as e:
            logger.error(f"토큰 TTL 계산 중 에러 발생: {e}")
            return 0

    @staticmethod
    def _request_new_ms_token() -> Optional[str]:
        """Microsoft OAuth 토큰 새로 요청"""
        url = f"https://login.microsoftonline.com/{settings.MS_TENANT_ID}/oauth2/v2.0/token"
        data = {
            "client_id": settings.MS_CLIENT_ID,
            "scope": "https://graph.microsoft.com/.default",
            "client_secret": settings.MS_CLIENT_SECRET,
            "grant_type": "client_credentials",
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            response = requests.post(url, data=data, headers=headers)
            response.raise_for_status()
            return response.json().get("access_token")
        except Exception as e:
            logger.error(f"MS 토큰 발급 중 에러 발생: {e}")
            return None

    @staticmethod
    def _request_new_onspace_token(username: str, password: str) -> Optional[str]:
        """Onspace 토큰 새로 요청"""
        url = "https://onspace.sk.com/websvc/token"
        data = {
            "username": username,
            "password": password,
            "grant_type": "password",
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            response = requests.post(url, data=data, headers=headers)
            response.raise_for_status()
            return response.json().get("access_token")
        except Exception as e:
            logger.error(f"Onspace 토큰 발급 중 에러 발생: {e}")
            return None


# 외부에서 사용할 함수들
def get_ms_access_token() -> Optional[str]:
    return TokenManager.get_ms_access_token()


def get_onspace_access_token() -> Optional[str]:
    return TokenManager.get_onspace_access_token()
