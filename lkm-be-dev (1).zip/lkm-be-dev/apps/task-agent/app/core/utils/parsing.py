import json
import re
from typing import List, Tuple

import pandas as pd

from core.config import get_setting
from core.log.logging import get_logging

logger = get_logging()
settings = get_setting()


def get_first_and_last_10(my_list: List[str]) -> List[str]:
    if len(my_list) == 0:
        return []  # 빈 리스트 처리

    if len(my_list) <= 10:
        return my_list  # 리스트 길이가 10 이하일 경우 전체 리스트 반환

    # 첫 번째 요소 + 마지막 10개 요소
    result = [my_list[0]] + my_list[-10:]
    return result


def extract_json(text: str) -> dict:
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        json_str = match.group()
        try:
            data = json.loads(json_str)
            return data
        except json.JSONDecodeError:
            logger.error("유효한 JSON 형식이 아닙니다.")
            return None
    else:
        logger.error("JSON 형식의 데이터를 찾을 수 없습니다.")
        return None


def chat2text(history: List[Tuple[str, str]]) -> str:
    history_text = ""
    for i in history:
        history_text += f"{i[0]} : {i[1]}\n"
    return history_text


def rows_as_text(dataframe: pd.DataFrame) -> str:
    text = "\n".join(
        ", ".join(
            f"{col}: {row[col]}" for col in dataframe.columns
        )  # 각 컬럼 이름과 값을 조합
        for _, row in dataframe.iterrows()
    )
    return text
