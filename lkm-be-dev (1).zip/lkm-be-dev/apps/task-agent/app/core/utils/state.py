import operator
from typing import Annotated, Any, Dict, List, Optional

from typing_extensions import TypedDict

from services.schemas.stream import StreamMessage

STATE_MESSAGE_KEY = [
    "state_init",
    "executor",
    "planner",
    "reporter",
    "router",
    "manager",
    "retry_executor",
]


def merge_dicts(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Recursively merge two dictionaries.
    For nested dictionaries, it performs a deep merge.
    For other types, values from dict2 override those from dict1.
    """
    result = dict1.copy()
    for key, value in dict2.items():
        if isinstance(value, dict) and key in result and isinstance(result[key], dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    return result


class State(TypedDict, total=False):
    # messages: Annotated[List[BaseMessage], add_messages]
    messages: List[Dict]
    context: str
    result: bool
    question: str
    next: str
    prompt_tokens: Annotated[float, operator.add]
    completion_tokens: Annotated[float, operator.add]
    cost: Annotated[float, operator.add]
    params: Annotated[Dict[str, Any], merge_dicts]
    debug: Dict[str, Any]


def process_message(
    message: Dict[str, Any], message_key: str, message_type: str, state: Dict[str, Any]
) -> Optional[StreamMessage]:
    """
    단일 메시지를 처리하여 StreamMessage로 변환합니다.
    """
    ai_message = message.get(message_key)
    if ai_message is None:
        return None

    if isinstance(ai_message, list):
        ai_message = " ".join(ai_message)

    return StreamMessage(type=message_type, content=ai_message, state=state)


def make_stream_message(state: dict) -> Optional[List[StreamMessage]]:
    """
    state 딕셔너리를 StreamMessage 리스트로 변환합니다.
    마지막에 추가된 view_message만 처리합니다.
    """
    stream_messages = []

    for key in STATE_MESSAGE_KEY:
        root = state.get(key)
        if not root:
            continue

        view_messages = root.get("view_messages", [])
        if not view_messages:
            continue

        for view_message in view_messages:
            # view_message가 None이면 건너뛰기
            if view_message is None:
                continue
            # last_view_message는 {'plan_start': {'content': '1', 'description': None}} 형태
            for message_type, message_data in view_message.items():
                if not message_data:
                    continue

                content = ""
                description = ""
                key = ""
                title = ""

                if isinstance(message_data, dict):
                    content = message_data.get("content", "") or ""
                    description = message_data.get("description", "") or ""
                    key = message_data.get("key", "") or ""
                    title = message_data.get("title", "") or ""
                else:
                    content = str(message_data)
                    description = ""
                    key = ""
                    title = ""

                # StreamMessage 생성
                stream_message = StreamMessage(
                    type=message_type,
                    content=content,
                    state=root.get("messages", {}),
                    description=description,
                    key=key,
                    title=title,
                )
                stream_messages.append(stream_message)

    return stream_messages if stream_messages else None
