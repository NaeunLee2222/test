from typing import Optional, Union

from langchain_anthropic import ChatAnthropic
from langchain_openai import AzureChatOpenAI, ChatOpenAI

from core.config import get_setting
from core.context import get_current_user_info, get_transaction_id
from core.log.logging import get_logging

logger = get_logging()
settings = get_setting()


def patch_usage_metadata():
    try:
        import langchain_anthropic.chat_models as chat_models
        from langchain_core.messages.ai import UsageMetadata

        def safe_create_usage_metadata(anthropic_usage):
            if anthropic_usage is None:
                return None

            try:
                input_tokens = getattr(anthropic_usage, "input_tokens", None)
                output_tokens = getattr(anthropic_usage, "output_tokens", None)
                cache_creation_input_tokens = getattr(
                    anthropic_usage, "cache_creation_input_tokens", None
                )
                cache_read_input_tokens = getattr(
                    anthropic_usage, "cache_read_input_tokens", None
                )

                input_tokens = input_tokens if input_tokens is not None else 0
                output_tokens = output_tokens if output_tokens is not None else 0
                cache_creation_input_tokens = (
                    cache_creation_input_tokens
                    if cache_creation_input_tokens is not None
                    else 0
                )
                cache_read_input_tokens = (
                    cache_read_input_tokens
                    if cache_read_input_tokens is not None
                    else 0
                )

                return UsageMetadata(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                    input_token_details={
                        "cache_read": cache_read_input_tokens,
                        "cache_creation": cache_creation_input_tokens,
                    },
                )
            except Exception as e:
                logger.error(f"Usage metadata 생성 실패: {e}")
                return UsageMetadata(input_tokens=0, output_tokens=0, total_tokens=0)

        chat_models._create_usage_metadata = safe_create_usage_metadata

    except Exception as e:
        raise e


# 패치 먼저 적용
patch_usage_metadata()
import httpx
import anthropic
from functools import cached_property


class CustomChatAnthropic(ChatAnthropic):
    """SSL 우회가 적용된 ChatAnthropic"""

    @cached_property
    def _client(self) -> anthropic.Client:
        """SSL 검증 비활성화된 클라이언트"""
        client_params = self._client_params

        # SSL 검증 비활성화된 httpx 클라이언트 생성
        http_client = httpx.Client(
            base_url=client_params.get("base_url", "https://api.anthropic.com"),
            timeout=client_params.get("timeout", 60.0),
            verify=False,  # SSL 검증 완전 비활성화
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
        )

        params = {
            **client_params,
            "http_client": http_client,
        }

        return anthropic.Client(**params)

    @cached_property
    def _async_client(self) -> anthropic.AsyncClient:
        """SSL 검증 비활성화된 비동기 클라이언트"""
        client_params = self._client_params

        # SSL 검증 비활성화된 async httpx 클라이언트 생성
        http_client = httpx.AsyncClient(
            base_url=client_params.get("base_url", "https://api.anthropic.com"),
            timeout=client_params.get("timeout", 60.0),
            verify=False,  # SSL 검증 완전 비활성화
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
        )

        params = {
            **client_params,
            "http_client": http_client,
        }

        return anthropic.AsyncClient(**params)


def get_model(
    user_id: Optional[str] = None,
) -> Union[ChatOpenAI, AzureChatOpenAI, ChatAnthropic]:
    if settings.SK_AI_PLATFORM_ENABLED:
        llm = ChatOpenAI(
            api_key=settings.SK_AI_PLATFORM_API_KEY,
            base_url=settings.SK_AI_PLATFORM_URL,
            model=settings.SK_AI_PLATFORM_CHAT_MODEL_NAME,
            n=1,
            temperature=0,
            max_tokens=None,
            verbose=False,
            streaming=True,
            default_headers={
                "aip-user": f"{get_current_user_info().department}/{get_current_user_info().user_id}",
                "aip-app-id": f"{settings.COMPANY.lower()}-{settings.APP_NAME}-app-{settings.ENVIRONMENT.lower()}",
                "aip-transaction-id": get_transaction_id(),
            },
        )
    elif user_id == "65536":
        llm = CustomChatAnthropic(
            api_key=settings.ANTHROPIC_API_KEY,
            model="claude-sonnet-4-20250514",
            max_tokens=16000,
            verbose=False,
        )

    elif user_id == "1360":
        llm = CustomChatAnthropic(
            api_key=settings.ANTHROPIC_API_KEY,
            model="claude-3-7-sonnet-20250219",
            max_tokens=16000,
            verbose=False,
        )
    else:
        llm = AzureChatOpenAI(
            azure_deployment=settings.OPENAI_DEPLOYMENT,
            azure_endpoint=settings.OPENAI_ENDPOINT,
            api_version=settings.OPENAI_API_VERSION,
            api_key=settings.OPENAI_API_KEY,
            n=1,
            temperature=0,
            max_tokens=None,
            model=settings.OPENAI_MODEL,
            verbose=True,
            streaming=True,
        )

    return llm


langfuse_handler = None
try:
    from langfuse.callback import CallbackHandler

    if all(
        hasattr(settings, attr) and getattr(settings, attr)
        for attr in ["LANGFUSE_HOST", "LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY"]
    ):
        langfuse_handler = CallbackHandler(
            secret_key=settings.LANGFUSE_SECRET_KEY,
            public_key=settings.LANGFUSE_PUBLIC_KEY,
            host=settings.LANGFUSE_HOST,
        )
except ImportError:
    pass


def get_llm_config(session_id: Optional[int] = None) -> dict:
    """Generate LLM config with or without langfuse handler"""
    if langfuse_handler and session_id:
        return {
            "callbacks": [langfuse_handler],
            "metadata": {"langfuse_session_id": session_id},
        }
    return {}
