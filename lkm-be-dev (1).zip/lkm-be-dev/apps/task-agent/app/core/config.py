from functools import lru_cache
from pathlib import Path
from typing import Any, Optional

from pydantic import ValidationInfo, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ENV_FILE = Path(__file__).resolve().parent.parent / ".env"
if not ENV_FILE.exists():
    ENV_FILE = Path(__file__).resolve().parent.parent.parent / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        env_file_encoding="utf-8",
        # extra="ignore",
        extra="allow",
    )

    # APP SETTINGs
    APP_NAME: str = "task-agent"
    TASK_AGENT_APP_PORT: str = "8030"
    AI_CHAT_APP_PORT: str = "8020"
    WEB_SEARCH_AGENT_APP_PORT: str = "8040"
    SIMULATOR_APP_PORT: str = "9010"
    ENVIRONMENT: str = "LOCAL"
    TASK_AGENT_ROUTE: str = ""
    TASK_AGENT_WORKER_NUM: int = 1
    CELERY_WORKER: int = 2

    # Mockup Settings
    USE_MOCKUP: bool = True

    URI_PREFIX: str = "/task-agent"
    DATA_PATH: str = "/data"

    LOG_LEVEL: str = "DEBUG"
    LOG_PATH: str = "/logs/task-agent"
    BASE_DIR: str = "/app/shared_data"

    COMPANY: str = "SKCC"

    ONSPACE_USER_ID: str = ""
    ONSPACE_USER_PASSWORD: str = ""

    SK_AI_PLATFORM_ENABLED: bool = False
    SK_AI_PLATFORM_URL: str = ""
    SK_AI_PLATFORM_API_KEY: str = ""
    SK_AI_PLATFORM_CHAT_MODEL_NAME: str = ""

    # REDIS SETTINGs
    REDIS_HOST: str = ""
    REDIS_PORT: int = 6379
    REDIS_ACCESS_KEY: str = ""
    REDIS_USE_SSL: bool = False

    # Redis Sentinel 설정
    REDIS_SENTINEL_HOST: str = ""
    REDIS_SENTINEL_PORT: int = 26379
    REDIS_SENTINEL_PASSWORD: str = ""
    REDIS_SENTINEL_MASTER_NAME: str = ""
    REDIS_USE_SENTINEL: bool = True

    REDIS_USER_INFO_DB: int = 1  # 사용자 정보용 DB (환경변수로 변경 가능)

    ## Celery Redis
    C_REDIS_HOST: Optional[str] = None

    # MCP SETTINGs
    MCP_SERVER_URL: str = ""

    @field_validator("C_REDIS_HOST")
    def set_celery_redis_host(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, str):
            return v
        return values.data["REDIS_HOST"]

    C_REDIS_PORT: Optional[int] = None

    @field_validator("C_REDIS_PORT")
    def set_celery_redis_port(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, int):
            return v
        return values.data["REDIS_PORT"]

    C_REDIS_ACCESS_KEY: Optional[str] = None

    @field_validator("C_REDIS_ACCESS_KEY")
    def set_celery_redis_key(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, str):
            return v
        return values.data["REDIS_ACCESS_KEY"]

    C_REDIS_USE_SSL: Optional[bool] = None

    @field_validator("C_REDIS_USE_SSL")
    def set_celery_redis_ssl(cls, v, values: ValidationInfo) -> Any:
        if isinstance(v, bool):
            return v
        return values.data["REDIS_USE_SSL"]

    C_REDIS_DB: int = 0

    # DB SETTINGs
    DB_ENGINE: str = "postgres"
    DB_USER: str
    DB_PASSWORD: str
    DB_HOST: str
    DB_PORT: int
    DB_NAME: str
    DB_SCHEMA_NAME: str = "ai_chat"
    DB_SSL_CA: Optional[str] = None
    SQLALCHEMY_DATABASE_URL: Optional[str] = None
    DB_POOL_SIZE: int = 50
    DB_POOL_MAX_OVERFLOW: int = 30
    DB_POOL_RECYCLE: int = 14400

    @field_validator("SQLALCHEMY_DATABASE_URL")
    def assemble_db_connection(cls, v: Optional[str], values: ValidationInfo) -> Any:
        if isinstance(v, str):
            return v
        preset = {
            "mysql": "mysql+aiomysql://{username}:{password}@{host}:{port}/{dbname}",
            "postgres": "postgresql+psycopg://{username}:{password}@{host}:{port}/{dbname}?options=-csearch_path%3D{schema}",
        }
        return preset[values.data["DB_ENGINE"]].format(
            username=values.data["DB_USER"],
            password=values.data["DB_PASSWORD"],
            host=values.data["DB_HOST"],
            port=values.data["DB_PORT"],
            dbname=values.data["DB_NAME"],
            schema=values.data["DB_SCHEMA_NAME"],
        )

    OPENAI_ENDPOINT: str = "https://ai-core-openai-llm.openai.azure.com/"
    OPENAI_API_VERSION: str = "2024-05-13"
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o"
    OPENAI_DEPLOYMENT: str = ""
    o3_MODEL: str = "o3-mini"
    o3_API_KEY: str = ""
    o3_ENDPOINT: str = ""

    MEETING_ROOM_LEGACY_API_KEY: str = ""

    BING_ENDPOINT: str = "https://api.bing.microsoft.com/v7.0/search"
    BING_API_KEY: str = ""

    LANGFUSE_HOST: str = "loacalhost"
    LANGFUSE_SECRET_KEY: str = ""
    LANGFUSE_PUBLIC_KEY: str = ""

    MS_TENANT_ID: str = ""
    MS_CLIENT_ID: str = ""
    MS_CLIENT_SECRET: str = ""

    # URI : 내부 통신 엔드포인트
    # URL : 외부(사용자) 접근용
    AI_CHAT_URI: str = "http://ai-chat:8010"
    GBAA_CHAT_URL: str = ""
    FILE_MANAGER_URI: str = "http://file-manager:8020"

    PROMPT_API_SPEC_DB_SYNC_ENABLED: bool = False

    # 파일 업로드 관련 설정
    FILE_UPLOAD_DIR: str = f"{DATA_PATH}/uploads"
    ALLOWED_FILE_TYPES: list = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/msword",
        "application/vnd.ms-excel",
        "text/plain",
        "application/json",
    ]
    MAX_UPLOAD_SIZE: int = 20 * 1024 * 1024  # 20MB
    FILE_PATH_PERMISSIONS: int = 0o755  # 파일 권한 (rwxr-xr-)

    GOOGLE_SEARCH_KEY: str = ""
    GOOGLE_CX: str = ""

    BING_SEARCH_ENDPOINT: str = ""
    BING_SEARCH_KEY: str = ""

    ANTHROPIC_API_KEY: str = ""


@lru_cache()
def get_setting() -> Settings:
    return Settings()
