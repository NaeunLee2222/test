import calendar
import time
from datetime import datetime
from functools import lru_cache

import jwt

from core.config import get_setting

settings = get_setting()


@lru_cache()
def get_rsa_key(filename: str) -> str:
    try:
        with open(filename, "r") as f:
            key = f.read()
            return key
    except Exception as e:
        raise


def get_current_user(token: str) -> dict:
    try:
        key = get_rsa_key(settings.KEYPATH)  # "public.pem"
        decoded = jwt.decode(token, key, algorithms=["RS256"])
        exp: int = decoded.get("exp")
        if time.time() > exp:
            raise Exception("Expired Token")
        user_id = decoded.get("oid")
        email = decoded.get("unique_name")
        name = decoded.get("name")
        role = decoded.get("role")
        return {"user_id": user_id, "email": email, "username": name, "role": role}
    except Exception as e:
        raise


def get_orchestration_jwt_token(user_id: str) -> str:
    now = datetime.utcnow()
    token = jwt.encode(
        {
            "client_id": user_id,
            "username": "",
            "group_id": "1",
            "vertical_service": "task-agent",
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "expires_in": 60,
            "exp": calendar.timegm(now.utctimetuple()) + 3600,
        },
        "secret",
        algorithm="HS256",
    )
    return token


import bcrypt


# 비밀번호 해싱
def hash_password(plain_password: str) -> str:
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(plain_password.encode("utf-8"), salt).decode("utf-8")


# 비밀번호 검증
def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(
        plain_password.encode("utf-8"), hashed_password.encode("utf-8")
    )
