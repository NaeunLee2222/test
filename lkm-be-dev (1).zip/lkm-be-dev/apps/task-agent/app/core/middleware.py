import logging
import time
import uuid
from typing import Callable

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

from core.config import get_setting
from core.context import chat_message_id_ctx, transaction_id_ctx, user_info_ctx

settings = get_setting()


class ChatMessageMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        user_info_token = user_info_ctx.set(None)
        chat_message_id_token = chat_message_id_ctx.set("")
        try:
            response = await call_next(request)
            return response
        finally:
            user_info_ctx.reset(user_info_token)
            chat_message_id_ctx.reset(chat_message_id_token)


class LoggingMiddleware(BaseHTTPMiddleware):
    # 로깅 제외할 경로 정의
    EXCLUDE_PATHS = {"/health"}

    async def dispatch(
        self,
        request: Request,
        call_next: Callable,
    ) -> Response:
        if request.url.path in self.EXCLUDE_PATHS:
            return await call_next(request)

        transaction_id = request.headers.get("x-transaction-id", str(uuid.uuid4()))
        token = transaction_id_ctx.set(transaction_id)

        start_time = time.time()
        logger = logging.getLogger(settings.APP_NAME)

        try:
            body = None
            if request.method in ["POST", "PUT", "PATCH"]:
                try:
                    body = await request.json()
                except:
                    body = await request.body()

            headers = {
                "user-agent": request.headers.get("user-agent"),
                "accept": request.headers.get("accept"),
                "content-type": request.headers.get("content-type"),
                "authorization": request.headers.get("authorization"),
            }
            log_dict = {
                "method": request.method,
                "path": request.url.path,
                "query_params": dict(request.query_params),
                "headers": headers,
            }
            logger.info(f"API Request Started: {log_dict}")
            logger.debug(f"Request Body: {body}")

            response = await call_next(request)
            process_time = time.time() - start_time
            logger.info(
                f"API Request Completed: {log_dict}, status_code={response.status_code}, process_time={process_time:.3f}s"
            )

            return response
        finally:
            transaction_id_ctx.reset(token)
