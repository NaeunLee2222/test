from typing import Any, Dict

from fastapi import HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from core.config import get_setting
from core.context import get_current_user_info, set_chat_contexts
from core.llm import get_async_model
from core.log.logging import get_logging
from database.session import get_async_db_by_schema_name
from services.agent.meeting_room_agent import MeetingRoomAgent
from services.chat_service import ChatService
from services.schemas.meeting_room.request import SupervisorRequestBody

settings = get_setting()
logger = get_logging()


class ExpertAgentHandler:
    def __init__(self):
        self.chat_service = ChatService()

    async def _get_expert_agent_graph(
        self, db: AsyncSession, user_id: str = None, stream: bool = False
    ) -> Any:
        """회의실 에이전트 그래프 생성"""
        llm = await get_async_model(db, "gbaa-agent-ms")
        return MeetingRoomAgent(llm=llm, agent_select="meeting_room").get_graph(
            db=db, stream=stream
        )

    async def _get_db_and_graph(
        self, company_code: str, user_id: str = None, stream: bool = False
    ) -> tuple[AsyncSession, Any]:
        """데이터베이스 연결 및 그래프 생성"""
        async for db in get_async_db_by_schema_name(company_code):
            graph = await self._get_meeting_room_graph(db, user_id, stream)
            return db, graph
        raise HTTPException(status_code=500, detail="Failed to connect to database")

    async def _handle_supervisor_request(
        self, request: SupervisorRequestBody, stream: bool
    ) -> StreamingResponse:
        """supervisor 요청 처리"""
        request.state["chat_id"] = request.chat_id
        set_chat_contexts(request.user_info, request.chat_id, request.input_data[-1])

        if stream:
            _, graph = await self._get_db_and_graph(
                get_current_user_info().company_code,
                request.user_info.user_id,
                stream=True,
            )
            return StreamingResponse(
                self.chat_service.supervisor_chat_completions_stream(
                    request.input_data, request.state, request.user_info, graph
                ),
                media_type="text/event-stream",
            )
        else:
            _, graph = await self._get_db_and_graph(
                get_current_user_info().company_code,
                request.user_info.user_id,
                stream=False,
            )
            return StreamingResponse(
                self.chat_service.supervisor_chat_completions(
                    request.input_data, request.state, request.user_info, graph
                ),
                media_type="text/event-stream",
            )

    async def handle_meeting_room_agent(
        self, input_data: Any, id: int
    ) -> Dict[str, Any]:
        """회의실 에이전트 단독 실행 처리"""
        _, graph = await self._get_db_and_graph("None")
        return await self.chat_service.chat_completions(input_data, id, graph)

    def get_available_models(self) -> Dict[str, Any]:
        """사용 가능한 모델 목록 조회"""
        return self.meeting_room_service.get_available_models()

    async def reserve_and_notify(
        self,
        room_id: int,
        user_id: str,
        reservation: Dict[str, Any],
        request: Any,
        db: AsyncSession,
    ) -> Dict[str, Any]:
        """회의실 예약 및 참석자 알림 처리"""
        return await self.meeting_room_service.reserve_and_notify(
            room_id, user_id, reservation, request, db
        )

    async def start_coordinate(
        self, company_code: str, request_data: Any, basic_info: Any, db: AsyncSession
    ) -> Dict[str, Any]:
        logger.info(
            f"Company code (meeting_room_handler.start_coordinate) {company_code}"
        )
        """회의실 조율 시작"""
        return await self.meeting_room_service.start_coordinate(
            company_code, request_data, basic_info, db
        )

    async def start_coordinate_vote(
        self, company_code: str, request_data: Any, db: AsyncSession
    ) -> Dict[str, Any]:
        """회의실 조율 투표 시작"""
        return await self.meeting_room_service.start_coordinate_vote(
            company_code, request_data, db
        )
