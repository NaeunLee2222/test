from typing import List

from sqlalchemy import text
from sqlalchemy.orm import Session

from core.log.logging import get_logging
from database.crud.base import CRUDBase
from database.models.api_spec.api_spec import ApiSpec

logger = get_logging()


class CRUDApiSpec(CRUDBase):
    def __init__(self):
        super().__init__(ApiSpec)

    def get_enabled_tools(self, db: Session) -> List[ApiSpec]:
        return db.query(self.model).filter(self.model.is_tool_enabled == True).all()

    def bulk_upsert(self, db: Session, specs: List[dict]) -> List[ApiSpec]:
        """API specs 전체 교체"""
        try:
            # 테이블의 모든 데이터 삭제
            logger.info("Deleting all existing api specs")
            db.execute(
                text(
                    f"TRUNCATE TABLE {self.model.__tablename__} RESTART IDENTITY CASCADE"
                )
            )

            # 새로운 데이터 bulk insert
            new_specs = [self.model(**spec) for spec in specs]
            logger.info(f"Creating {len(new_specs)} new api specs")
            db.bulk_save_objects(new_specs)

            db.commit()
            return specs

        except Exception as e:
            db.rollback()
            logger.error(f"Error in bulk upsert: {e}")
            raise
