from typing import Optional

from sqlalchemy import JSON
from sqlalchemy.orm import Session

from core.log.logging import get_logging
from database.crud.base import CRUDBase
from database.models.tool_call import ToolCall

logger = get_logging()


class CRUDToolCall(CRUDBase):
    def __init__(self):
        super().__init__(ToolCall)

    def upsert_tool_call(
        self, db: Session, tool_call: ToolCall, response: Optional[JSON] = None
    ) -> ToolCall:
        try:
            if tool_call.id and response:
                return self.update(db, db_obj=tool_call, obj_in={"response": response})
            else:
                tool_call_data = {
                    column.name: getattr(tool_call, column.name)
                    for column in tool_call.__table__.columns
                }
                return self.create(db, obj_in=tool_call_data)
        except Exception as e:
            logger.error(f"Error upserting tool_call {e}")
            raise
