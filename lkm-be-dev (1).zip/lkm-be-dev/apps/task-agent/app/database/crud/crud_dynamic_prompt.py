import json
from typing import List, Type

from sqlalchemy import Table, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import DeclarativeBase, Session

from core.log.logging import get_logging
from database.crud.base import CRUDBase
from database.models.prompt.dynamic_prompt import (
    DynamicPrompt,
    DynamicPromptCondition,
    DynamicPromptSnippet,
)

logger = get_logging()


class CRUDDynamicPromptBase(CRUDBase):
    def __init__(self, model: Type[DeclarativeBase]):
        super().__init__(model)
        self.json_path = ""

    def bulk_upsert(self, db: Session, specs: List[dict]) -> List[dict]:
        """전체 데이터 교체"""
        try:
            # 모든 데이터 삭제 (DynamicPrompt 먼저)
            if self.model == DynamicPrompt:
                logger.info("Deleting all existing Dynamic Prompts")
                db.execute(
                    text(
                        f"TRUNCATE TABLE {self.model.__tablename__} RESTART IDENTITY CASCADE"
                    )
                )
            elif self.model in [DynamicPromptCondition, DynamicPromptSnippet]:
                # DynamicPrompt 테이블의 데이터를 먼저 삭제
                logger.info("Deleting all existing Dynamic Prompts first")
                db.execute(
                    text(f"TRUNCATE TABLE dynamic_prompt RESTART IDENTITY CASCADE")
                )

                logger.info(f"Deleting all existing {self.model.__name__}")
                db.execute(
                    text(
                        f"TRUNCATE TABLE {self.model.__tablename__} RESTART IDENTITY CASCADE"
                    )
                )

            # 새로운 데이터 bulk insert
            new_records = [self.model(**spec) for spec in specs]
            logger.info(
                f"Bulk creating {len(new_records)} {self.model.__name__} records"
            )
            db.bulk_save_objects(new_records)

            db.commit()
            return specs

        except Exception as e:
            db.rollback()
            logger.error(f"Error in bulk upsert: {e}")
            raise

    def _upsert(self, db: Session, table: Table, spec: dict) -> None:
        try:
            db.execute(table.insert().values(spec))
            db.commit()
        except IntegrityError:
            db.rollback()
            stmt = table.update().where(table.c.id == spec["id"]).values(spec)
            db.execute(stmt)
            db.commit()

    def sync_from_json(self, db: Session) -> List:
        try:
            with open(self.json_path, "r") as f:
                specs = json.load(f)
            return self.bulk_upsert(db, specs)
        except Exception as e:
            logger.error(f"Error syncing dynamic prompts from json: {e}")
            raise

    def list_all(self, db: Session) -> List[DynamicPrompt]:
        try:
            return self.get_multi(db)
        except Exception as e:
            logger.error(f"Error listing dynamic prompts: {e}")
            raise


class CRUDDynamicPrompt(CRUDDynamicPromptBase):
    def __init__(self):
        super().__init__(DynamicPrompt)
        self.json_path = "/app/core/settings/dynamic_prompt/dynamic_prompt.json"


class CRUDDynamicPromptCondition(CRUDDynamicPromptBase):
    def __init__(self):
        super().__init__(DynamicPromptCondition)
        self.json_path = (
            "/app/core/settings/dynamic_prompt/dynamic_prompt_condition.json"
        )


class CRUDDynamicPromptSnippet(CRUDDynamicPromptBase):
    def __init__(self):
        super().__init__(DynamicPromptSnippet)
        self.json_path = "/app/core/settings/dynamic_prompt/dynamic_prompt_snippet.json"
