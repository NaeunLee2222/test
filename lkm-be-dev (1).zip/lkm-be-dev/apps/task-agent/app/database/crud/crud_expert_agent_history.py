from typing import List, Optional

from sqlalchemy import Column, Integer, MetaData, String, Table, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from core.log.logging import get_logging
from database.crud.base import CRUDBaseAsync
from database.models.expert_agent.expert_agent import ExpertAgentHistory
from services.schemas.expert_agent.response import AgentHistory

logger = get_logging()


class CRUDExpertAgentHistory(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ExpertAgentHistory)

    async def create_agent_history(
        self,
        db: AsyncSession,
        expert_agent_id: int,
        modified_user_id: Optional[int] = None,
        description: Optional[str] = None,
    ) -> ExpertAgentHistory:
        agent_history = ExpertAgentHistory(
            expert_agent_id=expert_agent_id,
            modified_user_id=modified_user_id,
            description=description,
        )
        db.add(agent_history)
        await db.commit()
        return agent_history

    async def get_agent_history(
        self,
        db: AsyncSession,
        expert_agent_id: int,
        skip: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> List[AgentHistory]:
        # Create users table reference with explicit column definitions
        metadata = MetaData()
        users = Table(
            "users",
            metadata,
            Column("id", Integer, primary_key=True),
            Column("username", String),
        )

        # Create alias for users table
        modified_users = users.alias("modified_users")

        # Base query with users join
        stmt = (
            select(
                ExpertAgentHistory,
                func.coalesce(modified_users.c.username, "Unknown").label("user_name"),
            )
            .join(
                modified_users,
                ExpertAgentHistory.modified_user_id == modified_users.c.id,
                isouter=True,
            )
            .where(ExpertAgentHistory.expert_agent_id == expert_agent_id)
        )

        if skip is not None:
            stmt = stmt.offset(skip)
        if limit is not None:
            stmt = stmt.limit(limit)

        result = await db.execute(stmt)
        rows = result.all()

        # Convert database models to Pydantic models
        return [
            AgentHistory(
                expert_agent_id=row.ExpertAgentHistory.expert_agent_id,
                modified_user_id=row.ExpertAgentHistory.modified_user_id,
                modified_user_name=row.user_name,
                description=row.ExpertAgentHistory.description,
                created_at=row.ExpertAgentHistory.created_at,
                updated_at=row.ExpertAgentHistory.updated_at,
            )
            for row in rows
        ]

    async def delete_agent_history(
        self,
        db: AsyncSession,
        expert_agent_id: int,
        auto_commit: bool = True,
    ) -> bool:
        stmt = select(ExpertAgentHistory).where(
            ExpertAgentHistory.expert_agent_id == expert_agent_id,
        )
        result = await db.execute(stmt)
        agent_histories = result.scalars().all()

        for agent_history in agent_histories:
            await db.delete(agent_history)
        if auto_commit:
            await db.commit()
        return True
