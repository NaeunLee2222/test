import os
import uuid

from typing import Optional, Tuple, List, Optional
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from database.models.expert_agent.expert_agent import (
    ProcedureDocument,
)
from database.crud.base import CRUDBaseAsync
from core.log.logging import get_logging
from core.config import get_setting

logger = get_logging()
settings = get_setting()


class CRUDProcedureDocument(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ProcedureDocument)

    async def create_with_file(
        self,
        db: AsyncSession,
        original_filename: str,
        file_type: str,
        uploaded_user_id: int,
        file_content: bytes,
        expert_agent_id: Optional[int] = None,
    ) -> Tuple[ProcedureDocument, str]:
        """
        파일을 저장하고 문서 정보를 DB에 저장합니다.

        Returns:
            Tuple[ProcedureDocument, str]: 생성된 문서 객체와 파일 경로를 반환합니다.
        """
        # UUID 파일명 생성
        filename = f"{uuid.uuid4()}{os.path.splitext(original_filename)[1]}"

        # 파일 경로 생성
        # FILE_UPLOAD_DIR은 main.py에서 생성했으므로 안전하게 사용
        file_path = os.path.join(settings.FILE_UPLOAD_DIR, filename)

        # 파일 저장
        with open(file_path, "wb") as f:
            f.write(file_content)

        # DB에 문서 정보 저장
        document_data = {
            "expert_agent_id": expert_agent_id,
            "uploaded_user_id": uploaded_user_id,
            "filename": filename,
            "original_filename": original_filename,
            "file_type": file_type,
            "status": "active",
        }

        document = await self.create(db, obj_in=document_data)
        return document, file_path

    async def get_by_agent_id(
        self, db: AsyncSession, agent_id: int
    ) -> List[ProcedureDocument]:
        """에이전트 ID로 연결된 문서를 조회합니다."""
        stmt = select(ProcedureDocument).where(
            ProcedureDocument.expert_agent_id == agent_id,
            ProcedureDocument.status == "active",
        )
        result = await db.execute(stmt)
        return result.scalars().all()

    async def delete_file(
        self, db: AsyncSession, document_id: int, auto_commit: bool = True
    ) -> bool:
        """
        문서를 소프트 삭제하고 연결된 파일을 삭제합니다.

        Returns:
            bool: 삭제 성공 여부
        """
        try:
            # 문서 조회
            document = await db.get(ProcedureDocument, document_id)
            if not document:
                return False

            # 파일 경로 생성
            file_path = os.path.join(settings.FILE_UPLOAD_DIR, document.filename)

            # 파일 존재 확인 및 삭제
            if os.path.exists(file_path):
                os.remove(file_path)

            # 문서 상태 업데이트
            document.status = "deleted"
            db.add(document)
            if auto_commit:
                await db.commit()
                await db.refresh(document)

            return True
        except Exception as e:
            logger.error(f"Error deleting file: {e}")
            return False

    async def get_file_path(self, db: AsyncSession, document_id: int) -> Optional[str]:
        """문서 ID로 파일 경로를 조회합니다."""
        document = await db.get(ProcedureDocument, document_id)
        if not document or document.status == "deleted":
            return None

        return os.path.join(settings.FILE_UPLOAD_DIR, document.filename)
