from typing import List, Optional

from sqlalchemy import text
from sqlalchemy.orm import Session

from core.log.logging import get_logging
from database.crud.base import CRUDBase
from database.models.prompt.prompt import Prompt

logger = get_logging()


class CRUDPrompt(CRUDBase):
    """프롬프트 저장소"""

    def __init__(self):
        super().__init__(Prompt)

    def get_by_name(self, db: Session, name: str) -> Optional[Prompt]:
        """이름으로 프롬프트 조회"""
        return db.query(self.model).filter(self.model.prompt_name == name).first()

    def bulk_upsert(self, db: Session, prompts: List[dict]) -> List[Prompt]:
        """Prompts 전체 교체"""
        try:
            # 테이블의 모든 데이터 삭제
            logger.info("Deleting all existing prompts")
            db.execute(
                text(
                    f"TRUNCATE TABLE {self.model.__tablename__} RESTART IDENTITY CASCADE"
                )
            )

            # 새로운 데이터 bulk insert
            new_prompts = [self.model(**prompt) for prompt in prompts]
            logger.info(f"Creating {len(new_prompts)} new prompts")
            db.bulk_save_objects(new_prompts)

            db.commit()
            return prompts

        except Exception as e:
            db.rollback()
            logger.error(f"Error in bulk upsert: {e}")
            raise

    def list_all(self, db: Session) -> List[Prompt]:
        """모든 프롬프트 조회"""
        try:
            return self.get_multi(db)
        except Exception as e:
            logger.error(f"Error listing prompts: {e}")
            raise
