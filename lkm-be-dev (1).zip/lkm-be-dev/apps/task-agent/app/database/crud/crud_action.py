from database.models.expert_agent.expert_agent import (
    Action,
    ActionToolRelationship
    )
from database.crud.base import CRUDBase
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Any, Dict, List, Optional

class CRUDAction(CRUDBase):
    def __init__(self):
        super().__init__(Action)
        
class CRUDActionToolRelationship(CRUDBase):
    def __init__(self):
        super().__init__(ActionToolRelationship)

    async def get_action_tool_relationships_by_action_ids(self, db: AsyncSession, action_ids: List[int]) -> List[ActionToolRelationship]:
        tool_relationships_stmt = (
            select(ActionToolRelationship)
            .where(ActionToolRelationship.action_id.in_(action_ids))
        )
        tool_relationships_result = await db.execute(tool_relationships_stmt)
        tool_relationships = tool_relationships_result.scalars().all()
        return tool_relationships