from typing import Any, Dict, List, Optional

from fastapi import HTTPException
from requests import Session
from sqlalchemy import (
    Column,
    Integer,
    MetaData,
    String,
    Table,
    and_,
    delete,
    or_,
    select,
    update,
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import func

from core.config import get_setting
from core.log.logging import get_logging
from database.crud.base import CRUDBase, CRUDBaseAsync
from database.crud.crud_procedure_document import CRUDProcedureDocument
from database.models.expert_agent.expert_agent import (
    Action,
    ActionToolRelationship,
    ChatStarter,
    ExpertAgent,
    GeneralAgentInstruction,
    GeneralAgentInstructionTool,
    ProcedureDocument,
    Step,
    Tool,
    ToolGroup,
    ToolGroupToolRelationship,
)
from services.schemas.expert_agent.agent_model import (
    ActionWithTools,
    ExpertAgentDetail,
    StepWithActions,
    ToolSchema,
    UpdateAgentPayload,
)
from services.schemas.expert_agent.request import (
    UpdateActionRequest,
    UpdateChatStarterRequest,
)
from services.schemas.expert_agent.response import AdminAgentListItem

logger = get_logging()

setting = get_setting()


class CRUDExpertAgent(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ExpertAgent)

    async def get_agent_count(
        self, db: AsyncSession, *, name: Optional[str] = None, **filters
    ) -> int:
        stmt = select(func.count()).select_from(self.model)
        # 조건 빌딩
        conditions = self._build_conditions(name=name, **filters)
        if conditions:
            stmt = stmt.where(and_(*conditions))

        result = await db.execute(stmt)
        return result.scalar()

    async def get_agent_by_id(
        self, db: AsyncSession, agent_id: int
    ) -> Optional[ExpertAgent]:
        """
        ID로 Agent 정보를 가져옵니다.
        """
        stmt = select(ExpertAgent).where(ExpertAgent.id == agent_id)
        result = await db.execute(stmt)
        return result.scalars().first()

    async def get_steps_by_agent_id(
        self, db: AsyncSession, agent_id: int
    ) -> List[Step]:
        """
        Agent의 Step 정보를 가져옵니다.
        """
        steps_stmt = (
            select(Step).where(Step.expert_agent_id == agent_id).order_by(Step.order)
        )
        result = await db.execute(steps_stmt)
        return result.scalars().all()

    async def get_actions_by_step_ids(
        self, db: AsyncSession, step_ids: List[int]
    ) -> List[Action]:
        """
        Step ID 리스트에 해당하는 Action 정보를 가져옵니다.
        """
        actions_stmt = (
            select(Action)
            .where(Action.step_id.in_(step_ids))
            .order_by(Action.step_id, Action.order)
        )
        result = await db.execute(actions_stmt)
        return result.scalars().all()

    async def get_agent_detail(
        self, db: AsyncSession, agent_id: int
    ) -> Optional[ExpertAgentDetail]:
        """
        Agent의 Step, Action, Tool 까지의 모든 구조 상세정보를 가져옵니다.
        """
        try:
            # 1. ID로 Agent 가져오기
            agent = await db.get(ExpertAgent, agent_id)
            if not agent:
                return None

            # 2. 모든 관련 데이터를 한 번에 조회
            # Step -> Action -> Tool 관계를 한 번에 가져오기
            steps_stmt = (
                select(Step)
                .where(Step.expert_agent_id == agent_id)
                .order_by(Step.order)
            )
            steps_result = await db.execute(steps_stmt)
            steps = steps_result.scalars().all()
            step_ids = [step.id for step in steps]

            # 3. 모든 Actions 한 번에 조회
            actions_stmt = (
                select(Action)
                .where(Action.step_id.in_(step_ids))
                .order_by(Action.step_id, Action.order)
            )
            actions_result = await db.execute(actions_stmt)
            actions = actions_result.scalars().all()

            # 4. Step ID별로 Action 그룹핑
            actions_by_step = {}
            action_ids = []
            for action in actions:
                if action.step_id not in actions_by_step:
                    actions_by_step[action.step_id] = []
                actions_by_step[action.step_id].append(action)
                action_ids.append(action.id)

            # 5. 모든 Tool 관계 한 번에 조회
            if action_ids:
                tool_relationships_stmt = select(ActionToolRelationship).where(
                    ActionToolRelationship.action_id.in_(action_ids)
                )
                tool_relationships_result = await db.execute(tool_relationships_stmt)
                tool_relationships = tool_relationships_result.scalars().all()

                # Action ID별로 Tool ID 그룹핑
                tools_by_action = {}
                all_tool_ids = set()
                for rel in tool_relationships:
                    if rel.action_id not in tools_by_action:
                        tools_by_action[rel.action_id] = []
                    tools_by_action[rel.action_id].append(rel.tool_id)
                    all_tool_ids.add(rel.tool_id)

                # 6. 모든 Tool 한 번에 조회
                if all_tool_ids:
                    tools_stmt = select(Tool).where(Tool.id.in_(all_tool_ids))
                    tools_result = await db.execute(tools_stmt)
                    tools = tools_result.scalars().all()

                    # Tool ID별로 Tool 객체 매핑
                    tools_by_id = {tool.id: tool for tool in tools}
                else:
                    tools_by_id = {}
            else:
                tools_by_action = {}
                tools_by_id = {}

            # 7. 데이터 조립
            steps_with_actions = []
            for step in steps:
                step_actions = actions_by_step.get(step.id, [])

                actions_with_tools = []
                for action in step_actions:
                    # 해당 Action의 Tool들 가져오기
                    action_tool_ids = tools_by_action.get(action.id, [])
                    tool_infos = [
                        ToolSchema(
                            id=tools_by_id[tool_id].id,
                            name=tools_by_id[tool_id].name,
                            description=tools_by_id[tool_id].description,
                            type=tools_by_id[tool_id].type,
                            icon_path=tools_by_id[tool_id].icon_path,
                            config=tools_by_id[tool_id].config,
                            created_at=tools_by_id[tool_id].created_at,
                            updated_at=tools_by_id[tool_id].updated_at,
                            tool_group_id=tools_by_id[tool_id].tool_group_id,
                            tool_group_name=tools_by_id[tool_id].tool_group_name,
                        )
                        for tool_id in action_tool_ids
                        if tool_id in tools_by_id
                    ]

                    action_with_tools = ActionWithTools(
                        id=action.id,
                        step_id=action.step_id,
                        name=action.name,
                        description=action.description,
                        order=action.order,
                        tools=tool_infos,
                    )
                    actions_with_tools.append(action_with_tools)

                step_with_actions = StepWithActions(
                    id=step.id,
                    expert_agent_id=step.expert_agent_id,
                    name=step.name,
                    description=step.description,
                    order=step.order,
                    created_at=step.created_at,
                    updated_at=step.updated_at,
                    actions=actions_with_tools,
                )
                steps_with_actions.append(step_with_actions)

            # 에이전트 상세 스키마 생성
            agent_detail = ExpertAgentDetail(
                id=agent.id,
                name=agent.name,
                description=agent.description,
                category=agent.category,
                usage_scope=agent.usage_scope,
                org_id=agent.org_id,
                team_id=agent.team_id,
                use_count=agent.use_count,
                review_status=agent.review_status,
                reject_description=agent.reject_description,
                agent_type=agent.agent_type,
                created_user_id=agent.created_user_id,
                created_at=agent.created_at,
                updated_at=agent.updated_at,
                steps=steps_with_actions,
            )
            return agent_detail

        except Exception as e:
            logger.error(f"Error getting agent detail: {e}")
            raise

    async def create_general_agent_instruction(
        self,
        db: AsyncSession,
        expert_agent_id: int,
        instruction: str,
        tools: Optional[List[int]] = None,
    ) -> GeneralAgentInstruction:
        """
        General Agent의 instruction과 tool 관계를 생성합니다.
        기존 instruction이 있는 경우 삭제하고 새로 생성합니다.
        """
        try:
            # 기존 instruction 조회
            stmt = select(GeneralAgentInstruction).where(
                GeneralAgentInstruction.expert_agent_id == expert_agent_id
            )
            result = await db.execute(stmt)
            existing_instruction = result.scalars().first()

            if existing_instruction:
                tool_delete_stmt = delete(GeneralAgentInstructionTool).where(
                    GeneralAgentInstructionTool.expert_agent_instruction_id.in_(
                        select(GeneralAgentInstruction.id).where(
                            GeneralAgentInstruction.expert_agent_id == expert_agent_id
                        )
                    )
                )
                await db.execute(tool_delete_stmt)
                logger.info(f"기존 tool 관계 삭제 완료")

                # 기존 instruction 삭제
                await db.delete(existing_instruction)
                await db.flush()

            # 새로운 instruction 생성
            general_agent_instruction = GeneralAgentInstruction(
                expert_agent_id=expert_agent_id,
                instruction=instruction,
            )
            db.add(general_agent_instruction)
            await db.flush()

            # tools가 None이 아니고 빈 리스트가 아닐 때만 tool 관계 생성
            if tools:
                tool_relationships = [
                    GeneralAgentInstructionTool(
                        expert_agent_instruction_id=general_agent_instruction.id,
                        tool_id=tool_id,
                    )
                    for tool_id in tools
                ]
                db.add_all(tool_relationships)

            await db.commit()
            await db.refresh(general_agent_instruction)
            return general_agent_instruction

        except Exception as e:
            await db.rollback()
            logger.error(f"Error creating/updating general agent instruction: {str(e)}")
            raise

    async def update_general_agent_instruction(
        self,
        db: AsyncSession,
        expert_agent_id: int,
        instruction: str,
        tools: Optional[List[int]] = None,
    ) -> GeneralAgentInstruction:
        """
        General Agent의 instruction과 tool 관계를 업데이트합니다.
        """
        try:
            # 기존 instruction 조회
            stmt = select(GeneralAgentInstruction).where(
                GeneralAgentInstruction.expert_agent_id == expert_agent_id
            )
            result = await db.execute(stmt)
            instruction_obj = result.scalars().first()

            if instruction_obj:
                # 기존 instruction 업데이트
                instruction_obj.instruction = instruction
                await db.flush()

                # 기존 tool 관계 삭제
                delete_stmt = select(GeneralAgentInstructionTool).where(
                    GeneralAgentInstructionTool.expert_agent_instruction_id
                    == instruction_obj.id
                )
                result = await db.execute(delete_stmt)
                existing_tools = result.scalars().all()
                for tool in existing_tools:
                    await db.delete(tool)

                # 새로운 tool 관계 생성
                if tools:
                    tool_relationships = [
                        GeneralAgentInstructionTool(
                            expert_agent_instruction_id=instruction_obj.id,
                            tool_id=tool_id,
                        )
                        for tool_id in tools
                    ]
                    db.add_all(tool_relationships)
            else:
                # 새로운 instruction 생성
                instruction_obj = await self.create_general_agent_instruction(
                    db, expert_agent_id, instruction, tools
                )

            await db.commit()
            await db.refresh(instruction_obj)
            return instruction_obj

        except Exception as e:
            logger.error(f"Error updating general agent instruction: {e}")
            await db.rollback()
            raise

    async def delete_general_agent_instruction(
        self, db: AsyncSession, expert_agent_id: int, auto_commit: bool = True
    ) -> bool:
        """
        General Agent의 instruction과 tool 관계를 삭제합니다.
        """
        try:
            # 기존 instruction 조회
            stmt = select(GeneralAgentInstruction).where(
                GeneralAgentInstruction.expert_agent_id == expert_agent_id
            )
            result = await db.execute(stmt)
            instruction = result.scalars().first()

            if instruction:
                # 먼저 관련된 tool 관계를 삭제
                delete_tools_stmt = delete(GeneralAgentInstructionTool).where(
                    GeneralAgentInstructionTool.expert_agent_instruction_id
                    == instruction.id
                )
                await db.execute(delete_tools_stmt)

                # GeneralAgentInstruction 삭제
                await db.delete(instruction)
                if auto_commit:
                    await db.commit()
                return True

            return False

        except Exception as e:
            logger.error(f"Error deleting general agent instruction: {e}")
            if auto_commit:
                await db.rollback()
            raise

    async def create_agent_with_details(
        self, db: AsyncSession, agent_detail: ExpertAgentDetail
    ) -> ExpertAgentDetail:
        """
        ExpertAgentDetail 정보를 받아 관련된 모든 데이터(Agent, Step, Action, Tool)를 생성합니다.
        일반 agent의 경우 step과 action을 생성하지 않습니다.
        """
        try:
            # 1. Agent 생성
            agent_data = {
                "name": agent_detail.name,
                "description": agent_detail.description,
                "category": agent_detail.category,
                "usage_scope": agent_detail.usage_scope,
                "org_id": agent_detail.org_id,
                "team_id": agent_detail.team_id,
                "created_user_id": agent_detail.created_user_id,
                "use_count": agent_detail.use_count,
                "review_status": agent_detail.review_status,
                "agent_type": agent_detail.agent_type,
            }
            new_agent: ExpertAgent = await self.create(db, obj_in=agent_data)

            # 2. Pro Agent인 경우에만 Step, Action, Tool 생성
            if new_agent.agent_type == "pro":
                crud_step = CRUDStep()
                crud_action = CRUDActionAsync()
                crud_tool = CRUDTool()
                crud_relation = CRUDActionToolRelationship()

                steps_data = []
                actions_data = []
                tools_data = []
                step_action_mapping = []  # step과 action 간의 관계 매핑
                action_tool_mapping = []  # action과 tool 간의 관계 매핑

                for step_idx, step_data in enumerate(agent_detail.steps):
                    step_obj = {
                        "expert_agent_id": new_agent.id,
                        "name": step_data.name,
                        "description": step_data.description,
                        "order": step_data.order,
                    }
                    steps_data.append(step_obj)

                    for action_idx, action_data in enumerate(step_data.actions):
                        action_obj = {
                            "name": action_data.name,
                            "description": action_data.description,
                            "order": action_data.order,
                        }
                        actions_data.append(action_obj)
                        step_action_mapping.append(
                            {
                                "step_idx": step_idx,
                                "action_idx": len(actions_data)
                                - 1,  # actions_data에서의 실제 인덱스
                            }
                        )

                        for tool_data in action_data.tools:
                            tool_obj = {
                                "name": tool_data.name,
                                "description": tool_data.description,
                                "type": tool_data.type,
                                "icon_path": tool_data.icon_path,
                                "config": tool_data.config,
                            }
                            tools_data.append(tool_obj)
                            action_tool_mapping.append(
                                {
                                    "action_idx": len(actions_data) - 1,
                                    "tool_name": tool_data.name,
                                }
                            )

                created_steps = []
                if steps_data:
                    created_steps = await crud_step.create_all(db, obj_in=steps_data)
                created_actions = []
                if actions_data:
                    for sam in step_action_mapping:
                        step_idx = sam["step_idx"]
                        action_idx = sam["action_idx"]
                        actions_data[action_idx]["step_id"] = created_steps[step_idx].id
                    created_actions = await crud_action.create_all(
                        db, obj_in=actions_data
                    )  # 한번에 생성

                created_tools_map = {}
                if tools_data:
                    tool_names = list(set(tool["name"] for tool in tools_data))
                    existing_tools_stmt = select(Tool).where(Tool.name.in_(tool_names))
                    existing_tools_result = await db.execute(existing_tools_stmt)
                    existing_tools = {
                        tool.name: tool
                        for tool in existing_tools_result.scalars().all()
                    }

                    new_tools_data = []  # 새로 만들 도구 리스트
                    for tool_data in tools_data:
                        if tool_data["name"] not in existing_tools:
                            new_tools_data.append(tool_data)
                        created_tools_map[tool_data["name"]] = existing_tools.get(
                            tool_data["name"]
                        )

                    unique_new_tools = []  # 중복제거
                    seen_names = set()
                    for tool_data in new_tools_data:
                        if tool_data["name"] not in seen_names:
                            unique_new_tools.append(tool_data)
                            seen_names.add(tool_data["name"])

                    if unique_new_tools:
                        new_created_tools = await crud_tool.create_all(
                            db, obj_in=unique_new_tools
                        )
                        for tool in new_created_tools:
                            created_tools_map[tool.name] = tool

                relations_data = []
                for mapping in action_tool_mapping:
                    action_idx = mapping["action_idx"]
                    tool_name = mapping["tool_name"]

                    if tool_name in created_tools_map and created_tools_map[tool_name]:
                        relation_obj = {
                            "action_id": created_actions[action_idx].id,
                            "tool_id": created_tools_map[tool_name].id,
                        }
                        relations_data.append(relation_obj)

                if relations_data:
                    await crud_relation.create_all(db, obj_in=relations_data)
                await db.commit()

            # 3. General Agent인 경우 추가 정보 저장
            if new_agent.agent_type == "general":
                # tools 추출 시 None 값 필터링
                tool_ids = []
                if hasattr(agent_detail, "steps"):
                    for step in agent_detail.steps:
                        for action in step.actions:
                            for tool in action.tools:
                                if tool and tool.id is not None:
                                    tool_ids.append(tool.id)

                await self.create_general_agent_instruction(
                    db=db,
                    expert_agent_id=new_agent.id,
                    instruction=agent_detail.description,
                    tools=tool_ids if tool_ids else None,
                )

            # 4. 생성된 Agent의 상세 정보 조회
            return await self.get_agent_detail(db, new_agent.id)

        except Exception as e:
            logger.error(f"Error creating agent with details: {e}")
            raise

    async def delete_agent_with_document(self, db: AsyncSession, agent_id: int) -> bool:
        """
        에이전트와 관련된 모든 데이터(Step, Action, Tool, 문서)를 삭제합니다.

        Returns:
            bool: 삭제 성공 여부
        """
        try:
            # 에이전트 존재 확인
            agent = await db.get(ExpertAgent, agent_id)
            if not agent:
                return False

            # 1. General Agent인 경우 관련 데이터 삭제
            if agent.agent_type == "general":
                await self.delete_general_agent_instruction(
                    db, agent_id, auto_commit=False
                )

            # 2. 연결된 문서 찾기
            crud_procedure_document = CRUDProcedureDocument()

            document_stmt = select(ProcedureDocument).where(
                ProcedureDocument.expert_agent_id == agent_id,
                ProcedureDocument.status == "active",
            )
            result = await db.execute(document_stmt)
            documents = result.scalars().all()

            # 3. 문서가 있으면 deleted 상태로 변경
            for document in documents:
                # 문서 파일 삭제 처리 (status를 deleted로 변경)
                await crud_procedure_document.delete_file(
                    db, document.id, auto_commit=False
                )

            # 4. 에이전트 관련 컨텐츠(Step, Action, Tool) 삭제
            await self.delete_agent_contents(db, agent_id, auto_commit=False)

            # 5. 에이전트 삭제
            await self.delete(db, id=agent_id, auto_commit=False)
            await db.commit()
            return True

        except Exception as e:
            logger.error(f"Error deleting agent with document: {e}")
            return False

    async def delete_agent_contents_pro(self, db: AsyncSession, agent_id: int):
        """에이전트의 모든 하위 구조를 효율적으로 삭제"""

        try:
            # 1. ActionToolRelationship 삭제 (가장 하위 관계부터)
            await db.execute(
                delete(ActionToolRelationship).where(
                    ActionToolRelationship.action_id.in_(
                        select(Action.id).where(
                            Action.step_id.in_(
                                select(Step.id).where(Step.expert_agent_id == agent_id)
                            )
                        )
                    )
                )
            )

            # 2. Action 삭제
            await db.execute(
                delete(Action).where(
                    Action.step_id.in_(
                        select(Step.id).where(Step.expert_agent_id == agent_id)
                    )
                )
            )

            # 3. Step 삭제
            await db.execute(delete(Step).where(Step.expert_agent_id == agent_id))

            await db.commit()

        except Exception as e:
            await db.rollback()
            raise e

    async def delete_agent_contents(
        self, db: AsyncSession, agent_id: int, auto_commit: bool = True
    ) -> None:
        # 1. 에이전트에 속한 모든 스텝 가져오기
        steps_stmt = select(Step).where(Step.expert_agent_id == agent_id)
        steps_result = await db.execute(steps_stmt)
        steps = steps_result.scalars().all()

        for step in steps:
            # 2. 각 스텝에 속한 액션 가져오기
            actions_stmt = select(Action).where(Action.step_id == step.id)
            actions_result = await db.execute(actions_stmt)
            actions = actions_result.scalars().all()

            for action in actions:
                # 3. 각 액션에 연결된 툴 관계 삭제
                relationship_stmt = select(ActionToolRelationship).where(
                    ActionToolRelationship.action_id == action.id
                )
                relationship_result = await db.execute(relationship_stmt)
                relationships = relationship_result.scalars().all()

                for relationship in relationships:
                    await db.delete(relationship)

                # 4. 액션 삭제
                await db.delete(action)

            # 5. 스텝 삭제
            await db.delete(step)

        if auto_commit:
            await db.commit()

    async def update_agent_with_details(
        self, db: AsyncSession, agent_id: int, agent_detail: UpdateAgentPayload
    ) -> ExpertAgentDetail:
        """
        기존 에이전트의 모든 정보(Step, Action, Tool 포함)를 업데이트합니다.
        일반 agent의 경우 step과 action을 업데이트하지 않습니다.
        """
        try:
            # 1. 에이전트 존재 확인
            agent = await db.get(ExpertAgent, agent_id)
            if not agent:
                return None

            # 2. 기본 에이전트 정보 업데이트
            agent_data = {
                "name": agent_detail.name,
                "administer_id": agent_detail.administer_id,
                "description": agent_detail.description,
                "category": agent_detail.category,
                "usage_scope": agent_detail.usage_scope,
                "org_id": agent_detail.org_id,
                "team_id": agent_detail.team_id,
                "review_status": agent_detail.review_status,
                "agent_type": agent_detail.agent_type,
            }

            # review_status에 따른 timestamp 업데이트
            if agent_detail.review_status == "submitted":
                agent_data["registered_at"] = func.now()
            elif agent_detail.review_status in ["rejected", "deployed"]:
                agent_data["reviewed_at"] = func.now()

            await self.update(db, db_obj=agent, obj_in=agent_data)

            # 3. Pro Agent인 경우에만 Step, Action, Tool 업데이트
            if agent_detail.agent_type == "pro":
                # 기존 하위 구조(Step, Action, Tool 관계) 삭제
                await self.delete_agent_contents(db, agent_id=agent_id)

                # Step, Action, Tool 재생성
                crud_step = CRUDStep()
                crud_action = CRUDActionAsync()
                crud_tool = CRUDTool()
                crud_relation = CRUDActionToolRelationship()

                for step_data in agent_detail.steps:
                    # Step 생성
                    step_obj = {
                        "expert_agent_id": agent_id,
                        "name": step_data.name,
                        "description": step_data.description,
                        "order": step_data.order,
                    }
                    new_step: Step = await crud_step.create(db, obj_in=step_obj)

                    # Action 및 Tool 생성
                    for action_data in step_data.actions:
                        action_obj = {
                            "step_id": new_step.id,
                            "name": action_data.name,
                            "description": action_data.description,
                            "order": action_data.order,
                        }
                        new_action: Action = await crud_action.create(
                            db, obj_in=action_obj
                        )

                        # Tool 생성 및 연결
                        for tool_data in action_data.tools:
                            tool_obj = {
                                "name": tool_data.name,
                                "description": tool_data.description,
                                "type": tool_data.type,
                                "icon_path": tool_data.icon_path,
                                "config": tool_data.config,
                            }

                            # 동일 이름의 Tool이 있으면 재사용, 없으면 생성
                            tool_stmt = select(Tool).where(Tool.name == tool_data.name)
                            tool_result = await db.execute(tool_stmt)
                            existing_tool = tool_result.scalars().first()

                            if existing_tool:
                                new_tool = existing_tool
                            else:
                                new_tool = await crud_tool.create(db, obj_in=tool_obj)

                            # Action과 Tool 연결
                            relation_obj = {
                                "action_id": new_action.id,
                                "tool_id": new_tool.id,
                            }
                            await crud_relation.create(db, obj_in=relation_obj)

            # 4. General Agent인 경우 추가 정보 업데이트
            if agent_detail.agent_type == "general":
                # tools 추출 시 None 값 필터링
                tool_ids = []
                if hasattr(agent_detail, "steps"):
                    for step in agent_detail.steps:
                        for action in step.actions:
                            for tool in action.tools:
                                # Tool 객체에서 id 속성이 없는 경우 name으로 조회
                                if tool and tool.name:
                                    tool_stmt = select(Tool).where(
                                        Tool.name == tool.name
                                    )
                                    tool_result = await db.execute(tool_stmt)
                                    existing_tool = tool_result.scalars().first()
                                    if existing_tool:
                                        tool_ids.append(existing_tool.id)

                await self.update_general_agent_instruction(
                    db=db,
                    expert_agent_id=agent_id,
                    instruction=agent_detail.description,
                    tools=tool_ids if tool_ids else None,
                )

            # 5. 업데이트된 에이전트 상세 정보 조회
            return await self.get_agent_detail(db, agent_id)

        except Exception as e:
            logger.error(f"Error updating agent with details: {e}")
            await db.rollback()  # 오류 시 롤백
            raise

    async def update_agent_activation(
        self, db: AsyncSession, agent_id: int, is_activated: bool
    ) -> bool:
        agent = await db.get(ExpertAgent, agent_id)
        agent.is_activated = is_activated
        await db.commit()
        return agent.is_activated

    def get_agent_info(self, db: Session, agent_id: int) -> Dict[str, Any]:
        agent_info = db.query(ExpertAgent).filter(ExpertAgent.id == agent_id).first()
        return agent_info

    async def use_count_up(self, db: AsyncSession, agent_id: int) -> Dict[str, Any]:
        agent = await db.get(ExpertAgent, agent_id)

        if not agent:
            return None

        agent.use_count += 1
        await db.commit()
        await db.refresh(agent)

        return agent.use_count

    async def get_multi_filtered_by_user_id(
        self,
        db: AsyncSession,
        *,
        skip: int = 0,
        limit: int = 100,
        order: Optional[str] = None,
        name: Optional[str] = None,
        user_id: Optional[int] = None,
        **filters,
    ) -> List[Any]:
        stmt = select(self.model)

        if user_id is not None:
            stmt = stmt.where(self.model.created_user_id == user_id)

        # 조건 빌딩
        conditions = self._build_conditions(name=name, user_id=user_id, **filters)
        if conditions:
            stmt = stmt.where(and_(*conditions))

        # 정렬 적용
        order_clause = self._get_order_clause(order)
        if order_clause is not None:
            stmt = stmt.order_by(order_clause)

        stmt = stmt.offset(skip).limit(limit)

        result = await db.execute(stmt)
        return result.scalars().all()

    # Admin용 에이전트 목록 조회
    async def get_multi_filtered_admin(
        self, db: AsyncSession, *, skip: int = 0, limit: int = 100, **filters
    ) -> List[Any]:
        # Create users table reference with explicit column definitions
        metadata = MetaData()
        users = Table(
            "users",
            metadata,
            Column("id", Integer, primary_key=True),
            Column("username", String),
        )

        # Create aliases for users table
        applicant_users = users.alias("applicant_users")
        admin_users = users.alias("admin_users")

        # Base query with users join for both applicant and admin
        stmt = (
            select(
                self.model,
                func.coalesce(applicant_users.c.username, "Unknown").label("user_name"),
                func.coalesce(admin_users.c.username, "Unknown").label("admin_name"),
            )
            .join(
                applicant_users,
                self.model.created_user_id == applicant_users.c.id,
                isouter=True,
            )
            .join(
                admin_users, self.model.administer_id == admin_users.c.id, isouter=True
            )
        )

        conditions = []

        if filters.get("name"):
            conditions.append(self.model.name.ilike(f"%{filters['name']}%"))

        # agent_type 필터링
        if filters.get("agent_type"):
            conditions.append(self.model.agent_type == filters["agent_type"])

        # 기간 필터링
        if filters.get("start_date") and filters.get("end_date"):
            date_conditions = []
            if not filters.get("date_type") or filters["date_type"] == "registered_at":
                date_conditions.append(
                    self.model.registered_at.between(
                        filters["start_date"], filters["end_date"]
                    )
                )
            if not filters.get("date_type") or filters["date_type"] == "reviewed_at":
                date_conditions.append(
                    self.model.reviewed_at.between(
                        filters["start_date"], filters["end_date"]
                    )
                )
            if date_conditions:
                conditions.append(or_(*date_conditions))

        # 상태 필터링
        if filters.get("review_status"):
            conditions.append(self.model.review_status == filters["review_status"])
        else:
            conditions.append(
                self.model.review_status.in_(["submitted", "deployed", "rejected"])
            )

        # 공개 범위 필터링
        if filters.get("usage_scope"):
            conditions.append(self.model.usage_scope == filters["usage_scope"])

        # 활성화 여부 필터링
        if filters.get("is_activated") is not None:
            conditions.append(self.model.is_activated == filters["is_activated"])

        # 검색어 필터링 (신청자/에이전트 명)
        if filters.get("search"):
            search_term = f"%{filters['search']}%"
            conditions.append(
                or_(
                    self.model.name.ilike(search_term),
                    func.lower(applicant_users.c.username).ilike(
                        func.lower(search_term)
                    ),
                )
            )

        # 조건 적용
        if conditions:
            stmt = stmt.where(and_(*conditions))

        # 정렬
        if filters.get("order_by"):
            if filters["order_by"] == "user_name":
                stmt = stmt.order_by(
                    func.lower(applicant_users.c.username).desc()
                    if filters.get("order_direction") == "desc"
                    else func.lower(applicant_users.c.username).asc()
                )
            else:
                order_field = getattr(self.model, filters["order_by"], None)
                if order_field is not None:
                    stmt = stmt.order_by(
                        order_field.desc()
                        if filters.get("order_direction") == "desc"
                        else order_field.asc()
                    )

        # 페이지네이션
        stmt = stmt.offset(skip).limit(limit)

        # 쿼리 실행
        result = await db.execute(stmt)
        agents = result.all()

        # 결과 변환
        agent_list = []
        for agent, user_name, admin_name in agents:
            agent_list.append(
                AdminAgentListItem(
                    id=agent.id,
                    name=agent.name,
                    user_name=user_name,
                    usage_scope=agent.usage_scope,
                    is_activated=agent.is_activated,
                    admin_name=admin_name,
                    agent_type=agent.agent_type,
                    review_status=agent.review_status,
                    registered_at=agent.registered_at,
                    reviewed_at=agent.reviewed_at,
                )
            )

        # 전체 개수 조회
        count_stmt = select(func.count()).select_from(self.model)
        if conditions:
            count_stmt = count_stmt.where(and_(*conditions))
        total = await db.scalar(count_stmt)

        # 필터링 된 것 중 각 상태별 개수 조회
        submitted_count = await db.scalar(
            count_stmt.where(self.model.review_status == "submitted")
        )
        deployed_count = await db.scalar(
            count_stmt.where(self.model.review_status == "deployed")
        )
        rejected_count = await db.scalar(
            count_stmt.where(self.model.review_status == "rejected")
        )

        return (agent_list, total, submitted_count, deployed_count, rejected_count)

    async def get_general_agent_detail(
        self, db: AsyncSession, agent_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        일반 agent의 상세 정보를 조회합니다.
        agent 정보, instruction, tools를 포함합니다.
        """
        try:
            # 1. Agent 기본 정보 조회
            agent_detail = await self.get_agent_detail(db, agent_id)
            if not agent_detail or agent_detail.agent_type != "general":
                return None

            # 2. Instruction 조회
            stmt = select(GeneralAgentInstruction).where(
                GeneralAgentInstruction.expert_agent_id == agent_id
            )
            result = await db.execute(stmt)
            instruction = result.scalars().first()

            # 3. Tools 조회
            tools = []
            if instruction:
                tool_stmt = (
                    select(
                        Tool,
                        ToolGroup.id.label("tool_group_id"),
                        ToolGroup.name.label("tool_group_name"),
                    )
                    .join(
                        GeneralAgentInstructionTool,
                        Tool.id == GeneralAgentInstructionTool.tool_id,
                    )
                    .join(
                        ToolGroupToolRelationship,
                        Tool.id == ToolGroupToolRelationship.tool_id,
                    )
                    .join(
                        ToolGroup,
                        ToolGroupToolRelationship.tool_group_id == ToolGroup.id,
                    )
                    .where(
                        GeneralAgentInstructionTool.expert_agent_instruction_id
                        == instruction.id
                    )
                )
                result = await db.execute(tool_stmt)
                tools = result.all()

            return {
                "agent": agent_detail,
                "instruction": instruction.instruction if instruction else None,
                "tools": (
                    [
                        ToolSchema(
                            id=tool.id,
                            name=tool.name,
                            description=tool.description,
                            type=tool.type,
                            icon_path=tool.icon_path,
                            config=tool.config,
                            created_at=tool.created_at,
                            updated_at=tool.updated_at,
                            tool_group_id=tool_group_id,
                            tool_group_name=tool_group_name,
                        )
                        for tool, tool_group_id, tool_group_name in tools
                    ]
                    if tools
                    else None
                ),
            }

        except Exception as e:
            logger.error(f"Error getting general agent detail: {e}")
            raise

    async def update_agent_timestamp(
        self, db: AsyncSession, agent_id: int, timestamp_type: str
    ) -> bool:
        try:
            stmt = (
                update(ExpertAgent)
                .where(ExpertAgent.id == agent_id)
                .values(**{timestamp_type: func.now()})
            )
            result = await db.execute(stmt)
            return result.rowcount > 0
        except Exception as e:
            logger.error(f"Error updating agent timestamp: {e}")
            raise


class CRUDStep(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Step)

    # 다른 방식으로 구현하고 싶다면 아래 코드를 사용할 수도 있습니다 (JOIN 활용)
    def get_steps_with_join(self, db: Session, agent_id: int) -> List[Dict[str, Any]]:
        """
        JOIN을 활용하여 단계와 액션 정보를 한 번에 조회하는 버전
        """
        # 단계와 액션을 JOIN하여 한 번에 조회
        query = (
            db.query(Step, Action)
            .join(Action, Step.id == Action.step_id, isouter=True)
            .filter(Step.expert_agent_id == agent_id)
            .order_by(Step.order, Action.order)
        )

        results = query.all()

        # 결과를 단계별로 그룹화
        steps_dict = {}
        for step, action in results:
            if step.id not in steps_dict:
                steps_dict[step.id] = {
                    "id": step.id,
                    "name": step.name,
                    "description": step.description,
                    "order": step.order,
                    "actions": [],
                }

            # 액션이 있는 경우에만 추가 (LEFT OUTER JOIN이므로 None일 수 있음)
            if action is not None:
                steps_dict[step.id]["actions"].append(
                    {
                        "id": action.id,
                        "name": action.name,
                        "description": action.description,
                        "order": action.order,
                    }
                )

        # 단계 순서대로 결과 리스트 생성
        result = [
            steps_dict[step_id]
            for step_id in sorted(
                steps_dict.keys(), key=lambda x: steps_dict[x]["order"]
            )
        ]
        return result

    async def get_search_steps_with_actions(
        self, db: AsyncSession, step_name: str
    ) -> List[Dict[str, Any]]:
        """
        단계 이름으로 부분 검색하여 액션과 도구 정보를 반환
        기존 함수들을 조합해서 구현
        """
        try:
            # 1. Step 이름으로 검색
            steps_stmt = (
                select(Step)
                .where(Step.name.ilike(f"%{step_name.strip()}%"))
                .order_by(Step.order)
            )
            steps_result = await db.execute(steps_stmt)
            steps = steps_result.scalars().all()

            if not steps:
                return []

            # 2. Step ID들로 Action 조회
            step_ids = [step.id for step in steps]
            crud_expert_agent = CRUDExpertAgent()
            actions = await crud_expert_agent.get_actions_by_step_ids(db, step_ids)

            # 3. Action ID들로 Tool 관계 조회
            action_ids = [action.id for action in actions]
            crud_relation = CRUDActionToolRelationship()
            tool_relationships = (
                await crud_relation.get_action_tool_relationships_by_action_ids(
                    db, action_ids
                )
            )

            # 4. Tool ID들로 Tool 조회
            tool_ids = [rel.tool_id for rel in tool_relationships]
            crud_tool = CRUDTool()
            tools = await crud_tool.get_tools_by_ids(db, tool_ids) if tool_ids else []

            # 5. 데이터 조립
            # Tool ID별로 Tool 객체 매핑
            tools_by_id = {tool.id: tool for tool in tools}

            # Action ID별로 Tool ID 그룹핑
            tools_by_action = {}
            for rel in tool_relationships:
                if rel.action_id not in tools_by_action:
                    tools_by_action[rel.action_id] = []
                tools_by_action[rel.action_id].append(rel.tool_id)

            # Step ID별로 Action 그룹핑
            actions_by_step = {}
            for action in actions:
                if action.step_id not in actions_by_step:
                    actions_by_step[action.step_id] = []
                actions_by_step[action.step_id].append(action)

            # 6. 결과 구성
            result = []
            for step in steps:
                step_actions = actions_by_step.get(step.id, [])

                actions_list = []
                for action in step_actions:
                    # 해당 Action의 Tool들 가져오기
                    action_tool_ids = tools_by_action.get(action.id, [])
                    tools_list = []

                    for tool_id in action_tool_ids:
                        if tool_id in tools_by_id:
                            tool = tools_by_id[tool_id]
                            tool_dict = {
                                "id": tool.id,
                                "name": tool.name,
                                "description": tool.description,
                                "type": tool.type,
                                "config": tool.config,
                                "endpoint": getattr(tool, "endpoint", None),
                                "tool_group_id": getattr(tool, "tool_group_id", None),
                                "tool_group_name": getattr(
                                    tool, "tool_group_name", None
                                ),
                            }
                            tools_list.append(tool_dict)

                    action_dict = {
                        "id": action.id,
                        "name": action.name,
                        "description": action.description,
                        "order": action.order,
                        "step_id": action.step_id,
                        "tools": tools_list,
                    }
                    actions_list.append(action_dict)

                # Action을 order로 정렬
                actions_list.sort(key=lambda x: x["order"])

                step_dict = {
                    "id": step.id,
                    "name": step.name,
                    "description": step.description,
                    "order": step.order,
                    "expert_agent_id": step.expert_agent_id,
                    "actions": actions_list,
                }
                result.append(step_dict)

            return result

        except Exception as e:
            logger.error(f"Error in get_search_steps_with_actions: {e}")
            raise


class CRUDActionAsync(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Action)


class CRUDAction(CRUDBase):
    def __init__(self):
        super().__init__(Action)

    def get_actions_with_tools(
        self, db: Session, action_ids: List[int]
    ) -> List[Dict[str, Any]]:
        """
        액션 ID 리스트를 받아서 각 액션에 연결된 도구 정보를 포함하여 반환
        """
        query = (
            db.query(Action, Tool)
            .join(ActionToolRelationship, Action.id == ActionToolRelationship.action_id)
            .join(Tool, Tool.id == ActionToolRelationship.tool_id)
            .filter(Action.id.in_(action_ids))
            .order_by(Action.order)
        )

        results = db.execute(query)

        # 결과를 액션별로 그룹화
        actions_dict = {}
        for action, tool in results:
            if action.id not in actions_dict:
                tool_dict = {
                    "id": tool.id,
                    "name": tool.name,
                    "description": tool.description,
                    "type": tool.type,
                    "config": tool.config,
                    "endpoint": tool.endpoint,
                }
                actions_dict[action.id] = {
                    "id": action.id,
                    "name": action.name,
                    "description": action.description,
                    "order": action.order,
                    "tool": tool_dict,
                }

        # 액션 ID 순서대로 결과 리스트 생성
        return [
            actions_dict[action_id]
            for action_id in action_ids
            if action_id in actions_dict
        ]

    def get_search_actions_with_tools(
        self, db: Session, action_name: str
    ) -> List[Dict[str, Any]]:
        """
        액션 이름으로 부분 검색하여 도구 정보를 반환
        기존 함수들을 조합해서 구현
        """
        try:
            # 1. Action 이름으로 검색
            actions_query = (
                db.query(Action)
                .filter(Action.name.ilike(f"%{action_name.strip()}%"))
                .order_by(Action.order)
            )
            actions = actions_query.all()

            if not actions:
                return []

            # 2. Action ID들로 Tool 관계 조회
            action_ids = [action.id for action in actions]
            tool_relationships = (
                db.query(ActionToolRelationship)
                .filter(ActionToolRelationship.action_id.in_(action_ids))
                .all()
            )

            # 3. Tool ID들로 Tool 조회 (tool_group 정보 포함)
            tool_ids = [rel.tool_id for rel in tool_relationships]
            if tool_ids:
                tools_query = (
                    db.query(
                        Tool,
                        ToolGroup.id.label("tool_group_id"),
                        ToolGroup.name.label("tool_group_name"),
                    )
                    .outerjoin(
                        ToolGroupToolRelationship,
                        Tool.id == ToolGroupToolRelationship.tool_id,
                    )
                    .outerjoin(
                        ToolGroup,
                        ToolGroupToolRelationship.tool_group_id == ToolGroup.id,
                    )
                    .filter(Tool.id.in_(tool_ids))
                )
                tool_results = tools_query.all()

                # Tool ID별로 Tool 객체 매핑
                tools_by_id = {}
                for tool, tool_group_id, tool_group_name in tool_results:
                    tools_by_id[tool.id] = {
                        "tool": tool,
                        "tool_group_id": tool_group_id,
                        "tool_group_name": tool_group_name,
                    }
            else:
                tools_by_id = {}

            # 4. Action ID별로 Tool ID 그룹핑
            tools_by_action = {}
            for rel in tool_relationships:
                if rel.action_id not in tools_by_action:
                    tools_by_action[rel.action_id] = []
                tools_by_action[rel.action_id].append(rel.tool_id)

            # 5. 결과 구성
            result = []
            for action in actions:
                # 해당 Action의 Tool들 가져오기
                action_tool_ids = tools_by_action.get(action.id, [])
                tools_list = []

                for tool_id in action_tool_ids:
                    if tool_id in tools_by_id:
                        tool_info = tools_by_id[tool_id]
                        tool = tool_info["tool"]
                        tool_dict = {
                            "id": tool.id,
                            "name": tool.name,
                            "description": tool.description,
                            "type": tool.type,
                            "config": tool.config,
                            "endpoint": getattr(tool, "endpoint", None),
                            "tool_group_id": tool_info["tool_group_id"],
                            "tool_group_name": tool_info["tool_group_name"],
                        }
                        tools_list.append(tool_dict)

                action_dict = {
                    "id": action.id,
                    "name": action.name,
                    "description": action.description,
                    "order": action.order,
                    "step_id": action.step_id,
                    "tools": tools_list,
                }
                result.append(action_dict)

            return result

        except Exception as e:
            logger.error(f"Error in get_search_actions_with_tools: {e}")
            raise

    def get_action_info(self, db: Session, action_id: int) -> ActionWithTools:
        action = db.query(Action).filter(Action.id == action_id).first()
        if not action:
            raise HTTPException(status_code=404, detail="Action not found")

        # Action에 연결된 Tool 관계 가져오기
        tool_relationships = (
            db.query(ActionToolRelationship)
            .filter(ActionToolRelationship.action_id == action.id)
            .all()
        )

        tool_ids = [rel.tool_id for rel in tool_relationships]
        tools_data = []
        if tool_ids:
            tools = db.query(Tool).filter(Tool.id.in_(tool_ids)).all()
            for tool in tools:
                try:
                    tool_group_relationship = (
                        db.query(ToolGroupToolRelationship)
                        .filter(ToolGroupToolRelationship.tool_id == tool.id)
                        .first()
                    )
                    if tool_group_relationship:
                        tool_group_id = tool_group_relationship.tool_group_id
                    else:
                        tool_group_id = None
                except Exception as e:
                    logger.error(
                        f"No tool group relationship found for tool: {tool.id}"
                    )
                    tool_group_id = None
                tools_data.append(
                    ToolSchema(
                        id=tool.id,
                        name=tool.name,
                        description=tool.description,
                        type=tool.type,
                        icon_path=tool.icon_path,
                        config=tool.config,
                        created_at=tool.created_at,
                        updated_at=tool.updated_at,
                        tool_group_id=tool_group_id,
                    )
                )

        return ActionWithTools(
            id=action.id,
            step_id=action.step_id,
            name=action.name,
            description=action.description,
            order=action.order,
            tools=tools_data,
        )

    def update_action(
        self, db: Session, action_id: int, action_info: UpdateActionRequest
    ) -> ActionWithTools:
        action = db.query(Action).filter(Action.id == action_id).first()
        if not action:
            raise HTTPException(status_code=404, detail="Action not found")

        action.name = action_info.name
        action.description = action_info.description

        # tool_id가 action_info에 제공되었는지 확인 (UpdateActionRequest에 tool_id가 Optional[int]로 있다고 가정)
        if hasattr(action_info, "tool_id") and action_info.tool_id is not None:
            # 기존 ActionToolRelationship 삭제
            db.query(ActionToolRelationship).filter(
                ActionToolRelationship.action_id == action_id
            ).delete()

        # 새 ActionToolRelationship 생성
        new_relationship = ActionToolRelationship(
            action_id=action_id, tool_id=action_info.tool_id
        )
        db.add(new_relationship)

        db.commit()
        db.refresh(action)

        # 업데이트된 Action 정보와 Tool 정보를 함께 반환
        return self.get_action_info(db, action_id)


class CRUDChatStarter(CRUDBase):
    def __init__(self):
        super().__init__(ChatStarter)

    def get_all_chat_starter(self, db: Session) -> List[ChatStarter]:
        return db.query(ChatStarter).all()

    def get_chat_starter_by_agent_id(
        self, db: Session, agent_id: int
    ) -> List[ChatStarter]:
        return db.query(ChatStarter).filter(ChatStarter.agent_id == agent_id).all()

    async def create_chat_starter(
        self, db: AsyncSession, chat_starter: List[ChatStarter]
    ) -> List[ChatStarter]:
        db.add_all(chat_starter)
        await db.commit()
        return chat_starter

    async def create_all_chat_starter(
        self, db: AsyncSession, chat_starters: List[ChatStarter]
    ) -> List[ChatStarter]:
        db.add_all(chat_starters)
        await db.commit()
        return chat_starters

    async def update_chat_starter(
        self, db: AsyncSession, chat_starters: List[UpdateChatStarterRequest]
    ) -> List[ChatStarter]:
        for chat_starter in chat_starters:
            existing_chat_starter = (
                (
                    await db.execute(
                        select(ChatStarter).filter(ChatStarter.id == chat_starter.id)
                    )
                )
                .scalars()
                .first()
            )
            # Update the starter field using the model's setter
            existing_chat_starter.starter = str(chat_starter.starter)
            await db.commit()
            await db.refresh(existing_chat_starter)
        if not existing_chat_starter:
            raise HTTPException(
                status_code=404, detail=f"Chat starter not found: id={chat_starter.id}"
            )
        return existing_chat_starter

    async def delete_chat_starter(
        self, db: AsyncSession, chat_starter: ChatStarter
    ) -> ChatStarter:
        existing_chat_starter = (
            (
                await db.execute(
                    select(ChatStarter).filter(ChatStarter.id == chat_starter.id)
                )
            )
            .scalars()
            .first()
        )
        if not existing_chat_starter:
            raise HTTPException(
                status_code=404, detail=f"Chat starter not found: id={chat_starter.id}"
            )

        await db.delete(existing_chat_starter)
        await db.commit()
        return existing_chat_starter

    async def delete_chat_starter_by_agent_id(
        self, db: AsyncSession, agent_id: int, auto_commit: bool = True
    ) -> bool:
        chat_starter_stmt = select(ChatStarter).where(
            ChatStarter.agent_id == agent_id,
        )
        result = await db.execute(chat_starter_stmt)
        chat_starters = result.scalars().all()
        for chat_starter in chat_starters:
            await db.delete(chat_starter)
        if auto_commit:
            await db.commit()
        return True


class CRUDTool(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Tool)

    async def get_tools_by_ids(self, db: AsyncSession, tool_ids: List[int]):
        stmt = (
            select(
                Tool,
                ToolGroup.id.label("tool_group_id"),
                ToolGroup.name.label("tool_group_name"),
            )
            .select_from(Tool)
            .outerjoin(
                ToolGroupToolRelationship,
                Tool.id == ToolGroupToolRelationship.tool_id,
            )
            .outerjoin(
                ToolGroup, ToolGroupToolRelationship.tool_group_id == ToolGroup.id
            )
            .where(Tool.id.in_(tool_ids))
        )
        result = await db.execute(stmt)
        rows = result.all()

        tools = []
        for row in rows:
            tool = row.Tool
            tool.tool_group_id = row.tool_group_id
            tool.tool_group_name = row.tool_group_name
            tools.append(tool)

        return tools

    async def get_tools_by_names(self, db: AsyncSession, tool_names: List[str]):
        stmt = (
            select(
                Tool,
                ToolGroup.id.label("tool_group_id"),
                ToolGroup.name.label("tool_group_name"),
            )
            .select_from(Tool)
            .outerjoin(
                ToolGroupToolRelationship,
                Tool.id == ToolGroupToolRelationship.tool_id,
            )
            .outerjoin(
                ToolGroup, ToolGroupToolRelationship.tool_group_id == ToolGroup.id
            )
            .where(Tool.name.in_(tool_names))
        )
        result = await db.execute(stmt)
        rows = result.all()

        tools = []
        for row in rows:
            tool = row.Tool
            tool.tool_group_id = row.tool_group_id
            tool.tool_group_name = row.tool_group_name
            tools.append(tool)

        return tools


class CRUDActionToolRelationship(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ActionToolRelationship)

    async def get_action_tool_relationships_by_action_ids(
        self, db: AsyncSession, action_ids: List[int]
    ) -> List[ActionToolRelationship]:
        action_tool_relationships_stmt = select(ActionToolRelationship).where(
            ActionToolRelationship.action_id.in_(action_ids)
        )
        action_tool_relationships_result = await db.execute(
            action_tool_relationships_stmt
        )
        action_tool_relationships = action_tool_relationships_result.scalars().all()
        return action_tool_relationships


class CRUDGeneralAgentInstruction(CRUDBaseAsync):
    def __init__(self):
        super().__init__(GeneralAgentInstruction)


class CRUDGeneralAgentInstructionTool(CRUDBaseAsync):
    def __init__(self):
        super().__init__(GeneralAgentInstructionTool)
