from fastapi import HTTPException
import aiohttp
from core.config import get_setting
from core.log.logging import get_logging

setting = get_setting()
logger = get_logging()


class CRUDAIChat:
    def __init__(self):
        if setting.TASK_AGENT_ROUTE == "LOCAL":
            url = f"http://localhost:8010/ai-chat/"
        else:
            url = "http://ai-chat:8010/ai-chat/"

        self.url = url
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
            "Accept": "application/json",
        }

    async def create_user_agent_preference(self, user_id: int, agent_id: int):
        """
        Create user agent preference by calling the preference service
        """

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url=f"{self.url}preference/user_preference",
                    params={"user_id": user_id, "agent_id": agent_id},
                    headers=self.headers,
                ) as response:
                    if response.status >= 400:
                        raise HTTPException(
                            status_code=response.status, detail=await response.text()
                        )
                    return await response.json()
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error calling preference service: {e}")
            raise HTTPException(
                status_code=500, detail=f"Error calling preference service"
            )

    async def delete_user_agent_preference(self, user_id: int, agent_id: int):
        """
        Delete user agent preference by calling the preference service
        """

        try:
            async with aiohttp.ClientSession() as session:
                async with session.delete(
                    url=f"{self.url}preference/user_preference",
                    params={"user_id": user_id, "agent_id": agent_id},
                    headers=self.headers,
                ) as response:
                    if response.status >= 400:
                        raise HTTPException(
                            status_code=response.status, detail=await response.text()
                        )
                    return await response.json()
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error calling preference service: {e}")
            raise HTTPException(
                status_code=500, detail=f"Error calling preference service"
            )

    async def delete_all_user_memory(self, user_id: int, agent_id: int):
        """
        Delete all user memory by calling the memory service
        """

        try:
            async with aiohttp.ClientSession() as session:
                async with session.delete(
                    url=f"{self.url}preference/user_memory/all",
                    params={"user_id": user_id, "agent_id": agent_id},
                    headers=self.headers,
                ) as response:
                    if response.status >= 400:
                        raise HTTPException(
                            status_code=response.status, detail=await response.text()
                        )
                    return await response.json()
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error calling memory service: {e}")
            raise HTTPException(status_code=500, detail=f"Error calling memory service")
