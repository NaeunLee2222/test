import json
from datetime import datetime
from typing import List, Optional

from langchain_mcp_adapters.client import MultiServerMCPClient
from sqlalchemy import and_, literal, select
from sqlalchemy.orm import Session

from core.log.logging import get_logging
from database.crud.base import CRUDBase
from database.models.expert_agent.expert_agent import (
    Tool,
    ToolGroup,
    ToolGroupToolRelationship,
)
from services.schemas.expert_agent.agent_model import ToolDetail, ToolGroupDetail

logger = get_logging()

TRANSPORT = ["stdio", "sse", "websocket", "streamable_http"]


class CRUDToolSync(CRUDBase):
    def __init__(self):
        super().__init__(Tool)

    def get_tools(
        self,
        db: Session,
        tool_group_id: Optional[int | None] = None,
        tool_name: Optional[str | None] = None,
        tool_id: Optional[int | None] = None,
        is_visible: Optional[bool | None] = None,
    ) -> List[ToolDetail]:
        # Tool과 ToolGroup을 조인하여 tool_group 정보를 함께 가져옴
        if tool_group_id:
            # 특정 그룹의 도구들만 가져오기
            stmt = (
                select(
                    Tool,
                    literal(tool_group_id).label("tool_group_id"),  # 고정값
                    ToolGroup.name.label("tool_group_name"),
                )
                .select_from(Tool)
                .join(
                    ToolGroupToolRelationship,
                    Tool.id == ToolGroupToolRelationship.tool_id,
                )
                .join(
                    ToolGroup, ToolGroupToolRelationship.tool_group_id == ToolGroup.id
                )
                .where(ToolGroupToolRelationship.tool_group_id == tool_group_id)
            )
        else:
            # 모든 도구와 그룹 관계 가져오기
            stmt = (
                select(
                    Tool,
                    ToolGroup.id.label("tool_group_id"),
                    ToolGroup.name.label("tool_group_name"),
                )
                .select_from(Tool)
                .outerjoin(
                    ToolGroupToolRelationship,
                    Tool.id == ToolGroupToolRelationship.tool_id,
                )
                .outerjoin(
                    ToolGroup, ToolGroupToolRelationship.tool_group_id == ToolGroup.id
                )
            )

        # 필터링 조건들
        where_conditions = []

        if tool_id:
            where_conditions.append(Tool.id == tool_id)

        if tool_name:
            where_conditions.append(Tool.name.ilike(f"%{tool_name}%"))

        if is_visible is not None:
            where_conditions.append(Tool.is_visible == is_visible)

        if where_conditions:
            stmt = stmt.where(and_(*where_conditions))

        # 결과 반환
        all_tools = db.execute(stmt).all()

        result = []
        for tool_data in all_tools:
            logger.info(f"tool_data: {tool_data}")
            tool = tool_data[0]  # Tool 객체
            tool_group_id = tool_data[1]  # tool_group_id
            tool_group_name = tool_data[2]  # tool_group_name

            # config가 이미 dict인 경우 그대로 사용
            config = tool.config if isinstance(tool.config, dict) else {}

            result.append(
                ToolDetail(
                    id=tool.id,
                    name=tool.name,
                    description=tool.description,
                    type=tool.type,
                    config=config,
                    created_at=tool.created_at,
                    updated_at=tool.updated_at,
                    endpoint=str(tool.endpoint),
                    tool_group_id=tool_group_id,
                    tool_group_name=tool_group_name,
                    is_visible=tool.is_visible,
                )
            )

        return result

    def get_tool_groups(self, db: Session) -> List[ToolGroupDetail]:
        all_tool_groups = db.query(ToolGroup).order_by(ToolGroup.id).all()
        result = [
            ToolGroupDetail(
                id=tool_group.id,
                name=tool_group.name,
                description=tool_group.description,
                created_at=tool_group.created_at,
                updated_at=tool_group.updated_at,
                is_visible=tool_group.is_visible,
            )
            for tool_group in all_tool_groups
        ]
        return sorted(result, key=lambda x: x.name)

    # tool_group_id로 도구 목록 조회
    def get_tools_by_tool_group_id(
        self, db: Session, tool_group_id: int
    ) -> List[ToolDetail]:
        tools_with_group = (
            db.query(
                Tool,
                ToolGroup.id.label("tool_group_id"),
                ToolGroup.name.label("tool_group_name"),
            )
            .join(
                ToolGroupToolRelationship, Tool.id == ToolGroupToolRelationship.tool_id
            )
            .join(ToolGroup, ToolGroupToolRelationship.tool_group_id == ToolGroup.id)
            .filter(ToolGroupToolRelationship.tool_group_id == tool_group_id)
            .all()
        )

        result = []
        for _tool, _tool_group_id, _tool_group_name in tools_with_group:
            # config가 이미 dict인 경우 그대로 사용
            config = _tool.config if isinstance(_tool.config, dict) else {}

            result.append(
                ToolDetail(
                    id=_tool.id,
                    name=_tool.name,
                    description=_tool.description,
                    endpoint=str(_tool.endpoint),
                    config=config,
                    type=_tool.type,
                    is_visible=_tool.is_visible,
                    tool_group_id=_tool_group_id,
                    tool_group_name=_tool_group_name,
                )
            )
        return sorted(result, key=lambda x: x.id)

    def get_tool_by_id(self, db: Session, tool_id: int) -> ToolDetail:
        tool_with_relationship = (
            db.query(Tool, ToolGroupToolRelationship, ToolGroup)
            .join(
                ToolGroupToolRelationship, Tool.id == ToolGroupToolRelationship.tool_id
            )
            .join(ToolGroup, ToolGroupToolRelationship.tool_group_id == ToolGroup.id)
            .filter(Tool.id == tool_id)
            .first()
        )
        if tool_with_relationship is None:
            raise ValueError(f"Tool with id {tool_id} does not exist")

        tool, relationship, tool_group = tool_with_relationship
        return ToolDetail(
            id=tool.id,
            name=tool.name,
            description=tool.description,
            endpoint=str(tool.endpoint),
            config=tool.config,
            type=tool.type,
            is_visible=tool.is_visible,
            created_at=tool.created_at,
            updated_at=tool.updated_at,
            tool_group_id=relationship.tool_group_id,
            tool_group_name=tool_group.name,
        )

    def add_tool(
        self,
        db: Session,
        name: str,
        description: str,
        type: str,
        config: dict,
        endpoint: str,
        is_visible: bool,
    ):
        try:
            new_tool = Tool(
                name=name,
                description=description,
                type=type,
                config=config,
                endpoint=endpoint,
                is_visible=is_visible,
            )
            db.add(new_tool)
            db.commit()
            return new_tool
        except Exception as e:
            db.rollback()
            logger.error(f"Error adding tool: {e}")
            raise

    async def save_mcp_tool(
        self, db: Session, url: str, transport: str, is_visible: Optional[bool] = True
    ):
        try:
            mcp_server = {}

            if transport not in TRANSPORT:
                raise ValueError(
                    f"지원하지 않는 transport 타입입니다. 지원되는 타입: {', '.join(TRANSPORT)}"
                )

            mcp_server["url"] = url
            mcp_server["transport"] = transport

            # 새로운 도구 목록 생성
            new_tools: List[Tool] = []
            added_tool_names = []

            server = {"tool": mcp_server}

            client = MultiServerMCPClient(server)
            tools = await client.get_tools()

            # 기존 도구 이름 목록을 한 번에 조회
            existing_tool_names = [tool.name for tool in db.query(Tool.name).all()]

            for tool in tools:
                if tool.name not in existing_tool_names:
                    if hasattr(tool.args_schema, "model_json_schema"):
                        # Pydantic 모델인 경우
                        args_schema_dict = tool.args_schema.model_json_schema()
                    elif isinstance(tool.args_schema, dict):
                        # 이미 딕셔너리인 경우
                        args_schema_dict = tool.args_schema
                    else:
                        # 기타 경우 빈 딕셔너리로 처리
                        args_schema_dict = {}

                    config_json = args_schema_dict
                    endpoint_str = str(mcp_server)

                    new_tool = Tool(
                        name=tool.name,
                        description=tool.description,
                        type="mcp",
                        config=config_json,
                        endpoint=endpoint_str,  # endpoint를 문자열로 저장
                        is_visible=is_visible,
                    )
                    new_tools.append(new_tool)
                    added_tool_names.append(tool.name)

            # Bulk insert 수행 - 단일 트랜잭션으로 처리
            if new_tools:
                db.bulk_save_objects(new_tools, return_defaults=True)
                db.commit()

            for tool in new_tools:
                logger.info(f"new_tools: {tool.id}")

            # 직렬화 가능한 형태로 반환
            return new_tools
        except Exception as e:
            db.rollback()
            logger.error(f"Error saving MCP tools: {e}")
            raise

    def save_tool_direct(
        self,
        db: Session,
        url: str,
        transport: str,
        timeout: Optional[int],
        tool_name: str,
    ):
        mcp_server = {}

        if transport not in TRANSPORT:
            raise ValueError(f"Invalid transport type. Must be one of {TRANSPORT}")

        mcp_server["url"] = url
        mcp_server["transport"] = transport

        # 기존 도구 이름 목록 조회
        existing_tool = db.query(Tool).filter(Tool.name == tool_name).first()
        if existing_tool:
            return {
                "message": f"Tool '{tool_name}' already exists",
                "tool_name": tool_name,
            }

        server = {"tool": mcp_server}
        client = MultiServerMCPClient(server)
        tools = client.get_tools()

        # 특정 도구 찾기
        target_tool = None
        for tool in tools:
            if tool.name == tool_name:
                target_tool = tool
                break

        if not target_tool:
            return {
                "message": f"Tool '{tool_name}' not found in MCP server",
                "tool_name": tool_name,
            }

        if hasattr(target_tool.args_schema, "model_json_schema"):
            # Pydantic 모델인 경우
            args_schema_dict = target_tool.args_schema.model_json_schema()
        elif isinstance(target_tool.args_schema, dict):
            # 이미 딕셔너리인 경우
            args_schema_dict = target_tool.args_schema
        else:
            # 기타 경우 빈 딕셔너리로 처리
            args_schema_dict = {}

        config_json = json.dumps(args_schema_dict)
        endpoint_str = str(mcp_server)

        # 새 도구 생성
        new_tool = Tool(
            name=target_tool.name,
            description=target_tool.description,
            type="mcp",
            config=config_json,
            endpoint=endpoint_str,  # endpoint를 문자열로 저장
        )

        db.add(new_tool)
        db.commit()

        return {
            "message": f"Tool '{tool_name}' added successfully",
            "tool_name": tool_name,
        }

    def delete_tool(self, db: Session, tool_id: int):
        try:
            exist_tool = db.query(Tool).filter(Tool.id == tool_id).first()

            if exist_tool is None:
                raise ValueError(f"Tool with id {tool_id} does not exist")

            # 도구 그룹 관계를 한 번에 조회하여 배치 삭제
            tool_group_tool_relationships = (
                db.query(ToolGroupToolRelationship)
                .filter(ToolGroupToolRelationship.tool_id == tool_id)
                .all()
            )

            # 배치 삭제 수행
            for relationship in tool_group_tool_relationships:
                db.delete(relationship)

            db.delete(exist_tool)
            db.commit()

            return {"message": f"Tool with id {tool_id} has been deleted successfully"}
        except Exception as e:
            db.rollback()
            logger.error(f"Error deleting tool: {e}")
            raise e

    def create_tool_group(
        self, db: Session, name: str, description: str, is_visible: bool
    ) -> ToolGroupDetail:
        new_tool_group = ToolGroup(
            name=name,
            description=description,
            is_visible=is_visible,
        )
        db.add(new_tool_group)
        db.commit()
        db.refresh(new_tool_group)
        return ToolGroupDetail(
            id=new_tool_group.id,
            name=new_tool_group.name,
            description=new_tool_group.description,
            created_at=new_tool_group.created_at,
            updated_at=new_tool_group.updated_at,
            is_visible=new_tool_group.is_visible,
        )

    def get_tool_group_by_id(self, db: Session, tool_group_id: int) -> ToolGroupDetail:
        tool_group = db.query(ToolGroup).filter(ToolGroup.id == tool_group_id).first()
        if tool_group is None:
            raise ValueError(f"Tool group with id {tool_group_id} does not exist")
        return ToolGroupDetail(
            id=tool_group.id,
            name=tool_group.name,
            description=tool_group.description,
            created_at=tool_group.created_at,
            updated_at=tool_group.updated_at,
            is_visible=tool_group.is_visible,
        )

    def get_tool_group_by_name(
        self, db: Session, tool_group_name: str
    ) -> ToolGroupDetail:
        tool_group = (
            db.query(ToolGroup).filter(ToolGroup.name == tool_group_name).first()
        )
        if tool_group is None:
            raise ValueError(f"Tool group with name {tool_group_name} does not exist")
        return ToolGroupDetail(
            id=tool_group.id,
            name=tool_group.name,
            description=tool_group.description,
            created_at=tool_group.created_at,
            updated_at=tool_group.updated_at,
            is_visible=tool_group.is_visible,
        )

    def register_tool_to_tool_group_by_id(
        self, db: Session, tool_group_id: int, tool_id: int
    ):
        # tool_group_id 존재 여부 확인
        tool_group = db.query(ToolGroup).filter(ToolGroup.id == tool_group_id).first()
        if tool_group is None:
            raise ValueError(f"Tool group with id {tool_group_id} does not exist")

        # tool_id 존재 여부 확인
        tool = db.query(Tool).filter(Tool.id == tool_id).first()
        if tool is None:
            raise ValueError(f"Tool with id {tool_id} does not exist")

        tool_group_tool_relationship = ToolGroupToolRelationship(
            tool_group_id=tool_group_id,
            tool_id=tool_id,
        )
        db.add(tool_group_tool_relationship)
        db.commit()
        return {
            "message": f"Tool '{tool_id}' registered to tool group '{tool_group_id}' successfully",
            "tool_group_id": tool_group_id,
            "tool_id": tool_id,
        }

    def register_mcp_tool_bulk(
        self, db: Session, tool_group_id: int, tool_ids: List[int]
    ):
        try:
            # 모든 관계를 한 번에 생성
            relationships = [
                ToolGroupToolRelationship(
                    tool_group_id=tool_group_id,
                    tool_id=tool_id,
                )
                for tool_id in tool_ids
            ]

            # 배치 추가
            db.add_all(relationships)
            db.commit()
            return True
        except Exception as e:
            db.rollback()
            logger.error(f"Error registering MCP tools bulk: {e}")
            raise e

    def delete_relationship_by_id(
        self, db: Session, tool_group_tool_relationship_id: int
    ):
        tool_group_tool_relationship = (
            db.query(ToolGroupToolRelationship)
            .filter(ToolGroupToolRelationship.id == tool_group_tool_relationship_id)
            .first()
        )

        if tool_group_tool_relationship is None:
            raise ValueError(
                f"Tool group tool relationship with id {tool_group_tool_relationship_id} does not exist"
            )

        db.delete(tool_group_tool_relationship)
        db.commit()
        return {
            "message": f"Tool group tool relationship with id {tool_group_tool_relationship_id} has been deleted successfully",
        }

    def delete_tool_group(self, db: Session, tool_group_id: int):
        """최적화된 도구 그룹 삭제 - 배치 처리로 트랜잭션 효율성 향상"""
        try:
            # tool_group_id 존재 여부 확인
            tool_group = (
                db.query(ToolGroup).filter(ToolGroup.id == tool_group_id).first()
            )
            if tool_group is None:
                raise ValueError(f"Tool group with id {tool_group_id} does not exist")

            # tool_group_id와 연결된 모든 관계를 한 번에 조회하여 배치 삭제
            tool_group_tool_relationships = (
                db.query(ToolGroupToolRelationship)
                .filter(ToolGroupToolRelationship.tool_group_id == tool_group_id)
                .all()
            )

            # 배치 삭제 수행
            for relationship in tool_group_tool_relationships:
                db.delete(relationship)

            db.delete(tool_group)
            db.commit()

            return {
                "message": f"Tool group with id {tool_group_id} has been deleted successfully",
            }
        except Exception as e:
            db.rollback()
            logger.error(f"Error deleting tool group: {e}")
            raise

    def update_tool(self, db: Session, tool_detail: ToolDetail):
        tool = db.query(Tool).filter(Tool.id == tool_detail.id).first()
        if tool is None:
            raise ValueError(f"Tool with id {tool_detail.id} does not exist")

        if tool_detail.name:
            tool.name = tool_detail.name
        if tool_detail.description:
            tool.description = tool_detail.description
        if tool_detail.type:
            tool.type = tool_detail.type
        if tool_detail.config:
            tool.config = tool_detail.config
        if tool_detail.endpoint:
            tool.endpoint = tool_detail.endpoint
        if tool_detail.is_visible is not None:
            tool.is_visible = tool_detail.is_visible
        tool.updated_at = datetime.now()

        db.commit()
        return tool

    # tool의 소속 그룹 변경시
    def update_tool_group_relationship(
        self, db: Session, tool_group_id: int, tool_id: int
    ):

        # tool_id 존재 여부 확인
        tool = db.query(Tool).filter(Tool.id == tool_id).first()
        if tool is None:
            raise ValueError(f"Tool with id {tool_id} does not exist")

        # tool_group_id 존재 여부 확인
        tool_group = db.query(ToolGroup).filter(ToolGroup.id == tool_group_id).first()
        if tool_group is None:
            raise ValueError(f"Tool group with id {tool_group_id} does not exist")

        old_tool_group_tool_relationship = (
            db.query(ToolGroupToolRelationship)
            .filter(ToolGroupToolRelationship.tool_id == tool_id)
            .first()
        )

        # 기존 관계가 없는 경우 새로 등록
        if old_tool_group_tool_relationship is None:
            logger.info(f"Tool with id {tool_id} is not associated with any tool group")

            tool_group_tool_relationship = ToolGroupToolRelationship(
                tool_group_id=tool_group_id, tool_id=tool_id
            )
            db.add(tool_group_tool_relationship)
            db.commit()
            return {
                "message": f"Tool '{tool_id}' registered to tool group '{tool_group_id}' successfully",
                "tool_group_id": tool_group_id,
                "tool_id": tool_id,
            }

        else:
            # 기존 관계가 있는 경우 관계 변경
            old_tool_group_tool_relationship.tool_group_id = tool_group_id
            db.commit()
            return {
                "message": f"Tool '{tool_id}' updated to tool group '{tool_group_id}' successfully",
            }

    def update_tool_group(
        self, db: Session, tool_group_detail: ToolGroupDetail
    ) -> ToolGroupDetail:
        tool_group = (
            db.query(ToolGroup).filter(ToolGroup.id == tool_group_detail.id).first()
        )
        if tool_group is None:
            raise ValueError(
                f"Tool group with id {tool_group_detail.id} does not exist"
            )

        if tool_group_detail.name:
            tool_group.name = tool_group_detail.name
        if tool_group_detail.description:
            tool_group.description = tool_group_detail.description
        if tool_group_detail.is_visible is not None:
            tool_group.is_visible = tool_group_detail.is_visible
        tool_group.updated_at = datetime.now()
        db.commit()
        return tool_group
