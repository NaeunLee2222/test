from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session
from sqlalchemy.sql import func


class CRUDBase:
    def __init__(self, model):
        self.model = model

    def create(self, db: Session, obj_in: Dict[str, Any]) -> Any:
        db_obj = self.model(**obj_in)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def create_all(self, db: Session, obj_in: List[Dict[str, Any]]) -> List[Any]:
        try:
            db_objs = [self.model(**obj) for obj in obj_in]
            db.add_all(db_objs)
            db.commit()
            return db_objs
        except Exception as e:
            db.rollback()
            raise

    async def acreate_all(
        self, db: AsyncSession, obj_in: List[Dict[str, Any]]
    ) -> List[Any]:
        try:
            db_objs = [self.model(**obj) for obj in obj_in]
            db.add_all(db_objs)
            await db.flush()
            return db_objs
        except Exception as e:
            await db.rollback()
            raise

    def get(self, db: Session, id: Any) -> Any:
        return db.query(self.model).filter(self.model.id == id).first()

    def get_multi(self, db: Session, *, skip: int = 0, limit: int = 100) -> List[Any]:
        return db.query(self.model).offset(skip).limit(limit).all()

    def update(self, db: Session, *, db_obj, obj_in: Dict[str, Any]) -> Any:
        try:
            for field in obj_in:
                if hasattr(db_obj, field):
                    setattr(db_obj, field, obj_in[field])
            db.add(db_obj)
            db.commit()
            db.refresh(db_obj)
            return db_obj
        except Exception as e:
            db.rollback()
            raise

    def delete(self, db: Session, *, id: Any) -> Any:
        try:
            obj = db.query(self.model).get(id)
            if obj:
                db.delete(obj)
                db.commit()
            return obj
        except Exception as e:
            db.rollback()
            raise


class CRUDBaseAsync:
    def __init__(self, model):
        self.model = model

    def _build_conditions(
        self,
        name: Optional[str] = None,
        **filters,
    ) -> List:
        conditions = []

        if name:
            conditions.append(self.model.name.ilike(f"%{name}%"))

        for column, value in filters.items():
            if value is not None and hasattr(self.model, column):
                conditions.append(getattr(self.model, column) == value)

        return conditions

    def _get_order_clause(self, order: Optional[str]):
        if not order:
            return None

        order_mapping = {
            "name_asc": self.model.name.asc(),
            "name_desc": self.model.name.desc(),
        }

        # 조건부 정렬 추가
        if order == "popularity" and hasattr(self.model, "use_count"):
            return self.model.use_count.desc()
        elif (
            order == "latest"
            and hasattr(self.model, "updated_at")
            and hasattr(self.model, "created_at")
        ):
            return func.coalesce(self.model.created_at, self.model.updated_at).desc()

        return order_mapping.get(order)

    async def create(self, db: AsyncSession, obj_in: Dict[str, Any]) -> Any:
        try:
            db_obj = self.model(**obj_in)
            db.add(db_obj)
            await db.commit()
            await db.refresh(db_obj)
            return db_obj
        except Exception as e:
            await db.rollback()
            raise

    async def acreate_all(
        self, db: AsyncSession, obj_in: List[Dict[str, Any]]
    ) -> List[Any]:
        try:
            db_objs = [self.model(**obj) for obj in obj_in]
            db.add_all(db_objs)
            await db.flush()
            return db_objs
        except Exception as e:
            await db.rollback()
            raise

    async def get(self, db: AsyncSession, id: Any) -> Any:
        stmt = select(self.model).where(self.model.id == id)
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_multi(
        self, db: AsyncSession, *, skip: int = 0, limit: int = 100
    ) -> List[Any]:
        stmt = select(self.model).offset(skip).limit(limit)
        result = await db.execute(stmt)
        return result.scalars().all()

    async def update(self, db: AsyncSession, *, db_obj, obj_in: Dict[str, Any]) -> Any:
        try:
            for field in obj_in:
                if hasattr(db_obj, field):
                    setattr(db_obj, field, obj_in[field])
            db.add(db_obj)
            await db.commit()
            await db.refresh(db_obj)
            return db_obj
        except Exception as e:
            await db.rollback()
            raise

    async def delete(
        self, db: AsyncSession, *, id: Any, auto_commit: bool = True
    ) -> Any:
        try:
            stmt = select(self.model).where(self.model.id == id)
            result = await db.execute(stmt)
            obj = result.scalar_one_or_none()
            if obj:
                await db.delete(obj)
                if auto_commit:
                    await db.commit()
            return obj
        except Exception as e:
            if auto_commit:
                await db.rollback()
            raise
