from sqlalchemy.ext.declarative import declarative_base

# SQLAlchemy Base 모델
Base = declarative_base()

# 예전 GBAA Table들 init 안되도록 하기
MockBase = declarative_base()