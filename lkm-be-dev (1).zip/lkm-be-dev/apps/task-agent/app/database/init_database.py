from core.config import get_setting
from core.log.logging import get_logging
from database.base import Base
from database.session import db_engine
from scripts.sync_api_specs import sync_api_specs
from scripts.sync_dynamic_prompts import sync_dynamic_prompts
from scripts.sync_prompts import sync_prompts

settings = get_setting()
logger = get_logging()


async def initialize_database() -> None:
    async with db_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info(f"Connected to database: {db_engine.url}")


async def close_database_connections() -> None:
    await db_engine.dispose()


def sync_prompts_api_specs() -> None:
    sync_all_prompts()
    sync_company_api_specs()


def sync_all_prompts() -> None:
    try:
        sync_prompts()
        sync_dynamic_prompts()
        logger.info("Successfully synced prompts")
    except Exception as e:
        logger.error(f"Error syncing prompts: {e}")


def sync_company_api_specs() -> None:
    try:
        sync_api_specs()
        logger.info("Successfully synced api specs")
    except Exception as e:
        logger.error(f"Error syncing api specs: {e}")
