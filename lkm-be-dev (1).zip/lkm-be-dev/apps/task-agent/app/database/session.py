import ssl
from typing import AsyncGenerator, Generator

from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import Session, sessionmaker

from core.config import get_setting

settings = get_setting()

# SSL 설정
ssl_ca = settings.DB_SSL_CA
ssl_context = ssl.create_default_context(cafile=ssl_ca) if ssl_ca else None

# 동기/비동기 DB URL 설정
sync_db_url = settings.SQLALCHEMY_DATABASE_URL.replace(
    "postgresql+asyncpg", "postgresql"
)

# 비동기 엔진 설정
async_engine = create_async_engine(
    settings.SQLALCHEMY_DATABASE_URL,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_POOL_MAX_OVERFLOW,
    pool_recycle=settings.DB_POOL_RECYCLE,
    # connect_args={"ssl": ssl_context},
)


# 동기 엔진 설정
sync_engine = create_engine(
    sync_db_url,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_POOL_MAX_OVERFLOW,
    pool_recycle=settings.DB_POOL_RECYCLE,
    # connect_args={"ssl": ssl_context} if ssl_context else {},
)

db_engine = async_engine

# 세션 팩토리 설정
AsyncSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,  # 커밋 후 객체 만료 방지
)

SyncSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=sync_engine,
    expire_on_commit=False,  # 커밋 후 객체 만료 방지
)


async def get_async_db() -> AsyncGenerator[AsyncSession, None]:
    """비동기 DB 세션을 제공하는 의존성 주입 함수"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            # 예외 발생 시 롤백
            await session.rollback()
            raise
        finally:
            # 세션 정리 보장
            await session.close()


def get_db() -> Generator[Session, None, None]:
    """동기 DB 세션을 제공하는 의존성 주입 함수"""
    db = SyncSessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        # 예외 발생 시 롤백
        db.rollback()
        raise
    finally:
        # 세션 정리 보장
        db.close()
