from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.sql import func

from database.base import Base


class ExpertAgent(Base):
    __tablename__ = "expert_agents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    created_user_id = Column(Integer, nullable=False)
    administer_id = Column(Integer)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    category = Column(String(255))
    usage_scope = Column(Enum("public", "org", "personal", name="usage_scope"))
    use_count = Column(Integer, default=0)
    review_status = Column(
        Enum(
            "pending",
            "saved",
            "testing",
            "submitted",
            "deployed",
            "rejected",
            name="review_status",
        )
    )
    reject_description = Column(Text, nullable=True)
    agent_type = Column(Enum("pro", "general", name="agent_type"))
    org_id = Column(Integer)
    team_id = Column(Integer)
    is_activated = Column(Boolean, default=True)
    registered_at = Column(DateTime(timezone=True), nullable=True)
    reviewed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Step(Base):
    __tablename__ = "steps"

    id = Column(Integer, primary_key=True, autoincrement=True)
    expert_agent_id = Column(Integer, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    order = Column(Integer, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Action(Base):
    __tablename__ = "actions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    step_id = Column(Integer, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    order = Column(Integer, nullable=False)


class Tool(Base):
    __tablename__ = "tools"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    type = Column(String(255))  # 정해지면 Enum으로 변경
    icon_path = Column(String(255))
    config = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    endpoint = Column(String(255))
    is_visible = Column(Boolean, default=True)
    is_visible = Column(Boolean, default=True)


class ToolGroup(Base):
    __tablename__ = "tool_groups"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    is_visible = Column(Boolean, default=True)
    is_visible = Column(Boolean, default=True)


class ToolGroupToolRelationship(Base):
    __tablename__ = "tool_group_tool_relationship"

    id = Column(Integer, primary_key=True, autoincrement=True)
    tool_group_id = Column(Integer, nullable=False)
    tool_id = Column(Integer, nullable=False)


class ActionToolRelationship(Base):
    __tablename__ = "action_tool_relationship"

    id = Column(Integer, primary_key=True, autoincrement=True)
    action_id = Column(Integer, nullable=False)
    tool_id = Column(Integer, nullable=False)


class ProcedureDocument(Base):
    __tablename__ = "procedure_documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    expert_agent_id = Column(Integer, nullable=True)  # 없어도 됨 나중에 연결
    uploaded_user_id = Column(Integer, nullable=False)
    filename = Column(String(64), nullable=False)  # UUID 파일명
    original_filename = Column(String(255), nullable=False)  # 원본 파일명
    file_type = Column(String(255), nullable=False)
    status = Column(Enum("active", "deleted", name="procedure_document_status"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class GeneralAgentInstruction(Base):
    __tablename__ = "general_agent_instructions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    expert_agent_id = Column(
        Integer,
        ForeignKey("expert_agents.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    instruction = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class GeneralAgentInstructionTool(Base):
    __tablename__ = "general_agent_instruction_tools"

    id = Column(Integer, primary_key=True, autoincrement=True)
    expert_agent_instruction_id = Column(
        Integer, ForeignKey("general_agent_instructions.id"), nullable=False
    )
    tool_id = Column(
        Integer, ForeignKey("tools.id", ondelete="CASCADE"), nullable=False
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ChatStarter(Base):
    __tablename__ = "chat_starters"

    id = Column(Integer, primary_key=True, autoincrement=True)
    agent_id = Column(Integer, nullable=False)
    starter = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class ExpertAgentHistory(Base):
    __tablename__ = "expert_agent_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    expert_agent_id = Column(Integer, nullable=False)
    modified_user_id = Column(Integer)
    description = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
