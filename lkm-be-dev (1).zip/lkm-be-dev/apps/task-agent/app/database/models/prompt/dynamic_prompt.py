from sqlalchemy import ARRAY, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from database.base import MockBase


class DynamicPrompt(MockBase):
    __tablename__ = "dynamic_prompt"

    id = Column(Integer, primary_key=True)
    condition = Column(
        String, ForeignKey("dynamic_prompt_condition.condition"), nullable=False
    )
    prompt_snippet_title = Column(
        String,
        ForeignKey("dynamic_prompt_snippet.prompt_snippet_title"),
        nullable=False,
    )
    node = Column(ARRAY(String), nullable=False)
    position = Column(String, nullable=False)
    agent = Column(String, nullable=False)
    company = Column(String, nullable=False)
    # 관계 설정
    condition_relation = relationship(
        "DynamicPromptCondition", back_populates="dynamic_prompts"
    )
    prompt_snippet_relation = relationship(
        "DynamicPromptSnippet", back_populates="dynamic_prompts"
    )

    def __repr__(self):
        return (
            f"<DynamicPrompt(id={self.id}, node={self.node}, position={self.position})>"
        )


class DynamicPromptCondition(MockBase):
    __tablename__ = "dynamic_prompt_condition"

    id = Column(Integer, primary_key=True)
    condition = Column(String, unique=True, nullable=False)  # unique 제약조건 추가
    description = Column(String)

    # dynamic_prompts와의 관계 설정
    dynamic_prompts = relationship("DynamicPrompt", back_populates="condition_relation")

    def __repr__(self):
        return f"<DynamicPromptCondition(id={self.id}, condition={self.condition}, agent={self.agent})>"


class DynamicPromptSnippet(MockBase):
    __tablename__ = "dynamic_prompt_snippet"

    id = Column(Integer, primary_key=True)
    prompt_snippet_title = Column(
        String, unique=True, nullable=False
    )  # unique 제약조건 추가
    prompt_snippet = Column(String, nullable=False)
    description = Column(String)
    company = Column(String, nullable=False)
    # dynamic_prompts와의 관계 설정
    dynamic_prompts = relationship(
        "DynamicPrompt", back_populates="prompt_snippet_relation"
    )

    def __repr__(self):
        return (
            f"<DynamicPromptSnippet(id={self.id}, title={self.prompt_snippet_title})>"
        )
