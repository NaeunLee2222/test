from sqlalchemy import Column, DateTime, Integer, String, func

from database.base import MockBase, Base


class Prompt(Base):
    __tablename__ = "prompts"

    id = Column(Integer, primary_key=True, autoincrement=True)  # 자동 증가 기본 키
    prompt_name = Column(String, nullable=False)  # 프롬프트 이름 (NULL 불가)
    prompt_text = Column(String, nullable=False)  # 프롬프트 내용 (NULL 불가)
    created_at = Column(DateTime, default=func.now())  # 생성 일자 (기본값: 현재 시간)
    updated_at = Column(
        DateTime, default=func.now(), onupdate=func.now()
    )  # 업데이트 일자 (기본값: 현재 시간, 수정 시 자동 업데이트)

    def __repr__(self):
        return f"<Prompt(id={self.id}, prompt_name={self.prompt_name}, prompt_text={self.prompt_text})>"
