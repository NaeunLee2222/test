from sqlalchemy import JSON, Boolean, Column, DateTime, Enum, Integer, String
from sqlalchemy.sql import func

from database.base import MockBase


class ApiSpec(MockBase):
    __tablename__ = "api_specs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    is_tool_enabled = Column(Boolean, default=True)
    service_category = Column(String(100))
    endpoint = Column(String(255), nullable=False)
    description = Column(String(500))
    method = Column(
        Enum("GET", "POST", "PUT", "DELETE", "PATCH", name="http_method"),
        nullable=False,
    )
    params = Column(JSON)
    body = Column(JSON)
    headers = Column(JSON)
    response_format = Column(JSON)
    rate_limit = Column(Integer)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
