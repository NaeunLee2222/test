from sqlalchemy import JSON, Column, DateTime, Integer, String
from sqlalchemy.sql import func

from database.base import MockBase


class ToolCall(MockBase):
    __tablename__ = "tool_calls"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(36), nullable=False)
    chat_message_id = Column(String(36), nullable=False)
    tool_name = Column(String(100), nullable=False)
    tool_service_category = Column(String(100))
    transaction_id = Column(String(36), nullable=False)
    request = Column(JSON)
    response = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
