from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from database.crud.crud_api_spec import CRUDApiSpec
from database.session import get_async_db
from services.schemas.api_spec import ApiSpecCreate, ApiSpecRead, ApiSpecUpdate

router = APIRouter()


@router.post("/bulk", response_model=List[ApiSpecRead])
async def create_api_specs_bulk(
    api_specs: List[ApiSpecCreate], db: AsyncSession = Depends(get_async_db)
) -> List[ApiSpecRead]:
    crud_api_spec = CRUDApiSpec()
    created_specs = []
    try:
        for api_spec in api_specs:
            created_api_spec = await crud_api_spec.create(db, api_spec)
            if created_api_spec is None:
                raise HTTPException(
                    status_code=500, detail="Failed to create an API spec."
                )
            created_specs.append(created_api_spec)
        return created_specs
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=500, detail=f"Error creating API specs: {str(e)}"
        )


# 1. ApiSpec 생성
@router.post("/", response_model=ApiSpecRead)
async def create_api_spec_api(
    api_spec: ApiSpecCreate, db: AsyncSession = Depends(get_async_db)
) -> ApiSpecRead:
    crud_api_spec = CRUDApiSpec()
    # create_api_spec은 비동기 함수이므로 await를 사용하여 실제 값을 반환해야 합니다.
    created_api_spec = await crud_api_spec.create(db, api_spec)
    return created_api_spec


# 2. 모든 ApiSpec 리스트 조회
@router.get("/", response_model=List[ApiSpecRead])
async def read_api_specs(
    skip: int = 0,
    limit: int = 10,
    service_category: Optional[str] = None,
    db: AsyncSession = Depends(get_async_db),
) -> List[ApiSpecRead]:
    crud_api_spec = CRUDApiSpec()
    api_specs = await crud_api_spec.get_multi(
        db=db, skip=skip, limit=limit, service_category=service_category
    )
    return api_specs


# 3. 특정 ApiSpec 조회
@router.get("/{api_spec_id}", response_model=ApiSpecRead)
async def read_api_spec(
    api_spec_id: int, db: AsyncSession = Depends(get_async_db)
) -> ApiSpecRead:
    crud_api_spec = CRUDApiSpec()
    api_spec = await crud_api_spec.get(db=db, id=api_spec_id)
    if not api_spec:
        raise HTTPException(status_code=404, detail="API Spec not found")
    return api_spec


# 4. ApiSpec 업데이트
@router.put("/{api_spec_id}", response_model=ApiSpecRead)
async def update_api_spec_api(
    api_spec_id: int,
    api_spec: ApiSpecUpdate,
    db: AsyncSession = Depends(get_async_db),
) -> ApiSpecRead:
    crud_api_spec = CRUDApiSpec()
    updated_api_spec = await crud_api_spec.update(
        db=db, api_spec_id=api_spec_id, api_spec_update=api_spec
    )
    if not updated_api_spec:
        raise HTTPException(status_code=404, detail="API Spec not found")
    return updated_api_spec


# 5. ApiSpec 삭제
@router.delete("/{api_spec_id}", response_model=dict)
async def delete_api_spec_api(
    api_spec_id: int, db: AsyncSession = Depends(get_async_db)
) -> dict:
    crud_api_spec = CRUDApiSpec()
    deleted = await crud_api_spec.delete(db=db, id=api_spec_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="API Spec not found")
    return {"detail": "API Spec deleted successfully"}
