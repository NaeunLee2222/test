from typing import Dict, Union

from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from core.config import get_setting
from services.chat_service import ChatService
from services.schemas.chat.request import OpenAIRequest
from services.schemas.chat.response import OpenAIResponse

router = APIRouter()
settings = get_setting()


@router.get("/models")
async def get_models() -> Dict:
    """사용 가능한 모델 목록을 반환"""
    return {"data": ChatService.get_available_models()}


@router.post("/chat/completions", response_model=OpenAIResponse)
async def chat_completions(
    request: OpenAIRequest, id: str
) -> Union[OpenAIResponse, StreamingResponse]:
    chat_service = ChatService()

    if request.stream:
        return StreamingResponse(
            chat_service.generate_stream_response(request, id),
            media_type="text/event-stream",
        )

    return await chat_service.generate_chat_response(request, id)
