import traceback
from typing import Optional

from fastapi import (
    APIRouter,
    Body,
    Depends,
    File,
    Form,
    HTTPException,
    Path,
    Query,
    UploadFile,
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session

from api.deps import get_expert_agent_builder, get_general_agent_builder
from core.config import get_setting
from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from database.crud.crud_ai_chat import CRUDAIChat
from database.crud.crud_expert_agent import (
    CRUDAction,
    CRUDActionToolRelationship,
    CRUDChatStarter,
    CRUDExpertAgent,
    CRUDStep,
    CRUDTool,
)
from database.crud.crud_procedure_document import CRUDProcedureDocument
from database.models.expert_agent.expert_agent import (
    ChatStarter,
)
from database.session import get_async_db, get_db
from services.agent.expert_agent_builder import ExpertAgentBuilder
from services.agent.general_agent_builder import GeneralAgentBuilder
from services.expert_agent_service import ExpertAgentService
from services.file_service import FileService
from services.schemas.expert_agent.agent_model import ExpertAgentDetail
from services.schemas.expert_agent.request import (
    CreateAgentWithStepsRequest,
    UpdateActionRequest,
    UpdateAgentRequest,
)
from services.schemas.expert_agent.response import (
    ActionWithToolsResponse,
    AgentDetailResponse,
    AgentListResponse,
    AgentSimpleDetailResponse,
    ApiResponse,
    ChatStarterResponse,
    GeneralAgentDetailResponse,
    StepActionRecommendationResponse,
    StepWithActionsResponse,
    ToolListResponse,
    UseCountResponse,
)
from services.user_service import UserService

router = APIRouter(tags=["Expert Agent CRUD"])
settings = get_setting()
logger = get_logging()

crud_expert_agent = CRUDExpertAgent()
crud_step = CRUDStep()
crud_action = CRUDAction()
crud_tool = CRUDTool()
crud_action_tool_relationship = CRUDActionToolRelationship()
crud_procedure_document = CRUDProcedureDocument()
crud_chat_starter = CRUDChatStarter()
crud_ai_chat = CRUDAIChat()

file_service = FileService()
expert_agent_service = ExpertAgentService()
user_service = UserService()


# Step 검색 -> Action, Tool 조회
@router.get(
    "/search_step_name/actions",
    response_model=StepWithActionsResponse,
    description="Step 이름으로 검색하여 Actions와 Tools를 조회합니다.",
)
async def search_step_actions(
    search_step_name: str = Query(
        "", description="검색할 Step의 이름 (부분 검색 가능, 빈칸 시 전체 조회)"
    ),
    # exact_match: bool = Query(False, description="정확히 일치하는 검색 여부"),
    db: AsyncSession = Depends(get_async_db),
) -> StepWithActionsResponse:
    try:
        steps = await crud_step.get_search_steps_with_actions(db, search_step_name)

        return StepWithActionsResponse(steps=steps)
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail="An error occurred while processing the search_step_name/actions request",
        )


# Action 검색 -> Tool 조회
@router.get(
    "/search_action_name/tools",
    response_model=ActionWithToolsResponse,
    description="Action 이름으로 검색하여 Tools를 조회합니다.",
)
def search_action_tools(
    search_action_name: str = Query(
        "", description="검색할 Action의 이름 (부분 검색 가능, 빈칸 시 전체 조회)"
    ),
    # exact_match: bool = Query(False, description="정확히 일치하는 검색 여부"),
    db: Session = Depends(get_db),
) -> ActionWithToolsResponse:
    try:
        actions = crud_action.get_search_actions_with_tools(db, search_action_name)

        return ActionWithToolsResponse(actions=actions)
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing GET tool"
        )


# User Info Header 등 추가될 예정
@router.get(
    "/agents",
    response_model=AgentListResponse,
    description="에이전트 목록을 조회합니다.",
)
async def get_agents(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    name: Optional[str] = None,
    usage_scope: Optional[str] = Query(None, enum=["public", "org", "personal"]),
    review_status: Optional[str] = Query(
        None, enum=["pending", "saved", "testing", "submitted", "deployed", "rejected"]
    ),
    reject_description: Optional[str] = None,
    agent_type: Optional[str] = Query(None, enum=["pro", "general"]),
    order: Optional[str] = Query(
        None,
        enum=["name_asc", "name_desc", "popularity", "latest"],
        description="정렬 방식: 이름 오름차순/이름 내림차순/인기순/최신순",
    ),
    db: AsyncSession = Depends(get_async_db),
) -> AgentListResponse:
    try:
        # 차후 필터링 로직 추가하기, org_id, team_id, user_id 등
        # Category나 usage_scope는 프론트서 쓸 수도 있음, 그냥 남겨만 둠 일단 백엔드는 전체 반환하는 것으로
        agents = await crud_expert_agent.get_multi_filtered_by_user_id(
            db,
            skip=skip,
            limit=limit,
            order=order,
            name=name,
            usage_scope=usage_scope,
            review_status=review_status,
            reject_description=reject_description,
            agent_type=agent_type,
        )
        total = await crud_expert_agent.get_agent_count(
            db,
            name=name,
            usage_scope=usage_scope,
            review_status=review_status,
            reject_description=reject_description,
            agent_type=agent_type,
        )
        return AgentListResponse(
            agents=agents,
            total=total,
            skip=skip,
            limit=limit,
            order=order,
            name=name,
            usage_scope=usage_scope,
            review_status=review_status,
            reject_description=reject_description,
            agent_type=agent_type,
        )
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing GET agents"
        )


# User Info Header 등 추가될 예정
@router.get(
    "/agents/{agent_id}",
    response_model=AgentDetailResponse,
    description="에이전트 상세 정보를 조회합니다.",
)
async def get_agent_detail(
    agent_id: int = Path(..., ge=1),
    user_id: int = 1,
    db: AsyncSession = Depends(get_async_db),
) -> AgentDetailResponse:
    try:
        agent_detail = await expert_agent_service.get_agent_detail(db, agent_id)
        if not agent_detail:
            raise HTTPException(status_code=404, detail="Agent not found")

        try:
            if agent_detail.id:
                await crud_ai_chat.create_user_agent_preference(
                    user_id=user_id,
                    agent_id=agent_detail.id,
                )
        except HTTPException as e:
            logger.info(f"e: {e}")
            logger.info(f"e.status_code: {e.status_code}")
            logger.info(e.status_code == 400)
            if e.status_code == 400:
                # 이미 preference 존재하므로 생성x
                pass
            else:
                raise e

        return AgentDetailResponse(
            agent=agent_detail,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the agent detail GET on agent_id : {agent_id}",
        )


@router.get(
    "/agents/{agent_id}/simple",
    response_model=AgentSimpleDetailResponse,
    description="에이전트 기본 정보를 조회합니다. (Step 정보 제외)",
)
async def get_agent_simple_detail(
    agent_id: int = Path(..., ge=1),
    user_id: int = 1,
    db: AsyncSession = Depends(get_async_db),
) -> AgentSimpleDetailResponse:
    try:
        agent_simple_detail = await expert_agent_service.get_agent_simple_detail(
            db, agent_id
        )
        if not agent_simple_detail:
            raise HTTPException(status_code=404, detail="Agent not found")

        try:
            if agent_simple_detail.id:
                await crud_ai_chat.create_user_agent_preference(
                    user_id=user_id,
                    agent_id=agent_simple_detail.id,
                )
        except HTTPException as e:
            logger.info(f"e: {e}")
            logger.info(f"e.status_code: {e.status_code}")
            logger.info(e.status_code == 400)
            if e.status_code == 400:
                # 이미 preference 존재하므로 생성x
                pass
            else:
                raise e

        return AgentSimpleDetailResponse(
            agent=agent_simple_detail,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while processing the agent simple detail GET on agent_id : {agent_id}",
        )


@router.post(
    "/agents",
    response_model=AgentDetailResponse,
    description="에이전트를 생성합니다. (Step 정보만 필요, Action/Tool은 자동 생성, AG-02-04)",
)
async def create_agent(
    request: CreateAgentWithStepsRequest,
    db: AsyncSession = Depends(get_async_db),
) -> AgentDetailResponse:
    try:
        # TODO Request ID 값들 타입 변경 (any -> int)

        # 2. 입력 데이터를 기반으로 Agent 모델 생성
        agent_detail = ExpertAgentDetail(
            name=request.agent.name,
            description=request.agent.description,
            category=request.agent.category,
            usage_scope=request.agent.usage_scope,
            org_id=request.agent.org_id,
            team_id=request.agent.team_id,
            created_user_id=request.created_user_id,
            use_count=request.agent.use_count,
            review_status=request.agent.review_status,
            agent_type=request.agent.agent_type,
            steps=request.steps,
        )

        # 3. DB 저장
        if request.agent.agent_type == "pro":
            saved_agent_detail = await expert_agent_service.create_pro_agent(
                db, agent_detail
            )
        elif request.agent.agent_type == "general":
            saved_agent_detail = await expert_agent_service.create_general_agent(
                db, agent_detail
            )
            if request.general_agent_instruction and saved_agent_detail.id:
                _ = await expert_agent_service.create_general_agent_instruction(
                    db=db,
                    expert_agent_id=saved_agent_detail.id,
                    instruction=request.general_agent_instruction.instruction,
                    tools=request.general_agent_instruction.tool_ids,
                )

        # 5. 문서 연결 (있는 경우)
        if request.document_id:
            document = await crud_procedure_document.get(db, id=request.document_id)
            if not document:
                raise HTTPException(
                    status_code=404, detail="연결할 문서를 찾을 수 없습니다"
                )

            # 문서에 에이전트 ID 연결
            await crud_procedure_document.update(
                db, db_obj=document, obj_in={"expert_agent_id": saved_agent_detail.id}
            )

        # 6. agent 설정 생성
        if saved_agent_detail.created_user_id and saved_agent_detail.id:
            await crud_ai_chat.create_user_agent_preference(
                user_id=saved_agent_detail.created_user_id,
                agent_id=saved_agent_detail.id,
            )

        # 7. 챗봇 시작 메시지 생성
        if request.chat_starters:
            await crud_chat_starter.create_all_chat_starter(
                db,
                [
                    ChatStarter(agent_id=saved_agent_detail.id, starter=starter)
                    for starter in request.chat_starters
                ],
            )

        await db.commit()
        return AgentDetailResponse(
            success=True,
            message=f"{request.agent.name} Agent 생성 완료",
            agent=saved_agent_detail,
        )

    except HTTPException:
        await db.rollback()
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"Error creating agent: {e}")
        raise HTTPException(
            status_code=500, detail="에이전트 생성 중 오류가 발생했습니다."
        )


@router.put(
    "/agents/{agent_id}",
    response_model=AgentDetailResponse,
    description="에이전트를 수정합니다. (임시저장 포함, 전체 데이터 업데이트)",
)
async def update_agent(
    agent_id: int = Path(..., ge=1),
    request: UpdateAgentRequest = Body(...),
    db: AsyncSession = Depends(get_async_db),
) -> AgentDetailResponse:
    logger.info(f"request: {request}")
    try:
        # 에이전트 업데이트

        if request.agent.agent_type == "pro":
            updated_agent_detail = await expert_agent_service.update_pro_agent(
                db, agent_id, request.agent
            )
        elif request.agent.agent_type == "general":
            updated_agent_detail = await expert_agent_service.update_general_agent(
                db, agent_id, request.agent
            )
        logger.info(f"updated_agent_detail: {updated_agent_detail}")

        if not updated_agent_detail:
            raise HTTPException(status_code=404, detail="에이전트를 찾을 수 없습니다")

        # General Agent인 경우 instruction 업데이트
        if request.agent.agent_type == "general" and request.general_agent_instruction:
            await expert_agent_service.update_general_agent_instruction(
                db=db,
                expert_agent_id=agent_id,
                instruction=request.general_agent_instruction.instruction,
                tools=request.general_agent_instruction.tool_ids,
            )

        logger.info(
            f"request.general_agent_instruction: {request.general_agent_instruction}"
        )
        if request.chat_starters:
            logger.info(f"request.chat_starters: {request.chat_starters}")
            await crud_chat_starter.update_chat_starter(
                db=db, chat_starters=request.chat_starters
            )

        if request.agent.review_status and request.agent.review_status in [
            "submitted",
            "deployed",
            "rejected",
        ]:
            await expert_agent_service.update_agent_timestamp(
                db, agent_id, request.agent.review_status
            )

        await db.commit()
        await db.refresh(updated_agent_detail)

        # todo 임시로직. agent step을 조회해
        agent_detail = await expert_agent_service.get_agent_detail(db, agent_id)
        if not agent_detail:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail="Failed to retrieve agent details after update.",
            )

        return AgentDetailResponse(
            success=True,
            message=f"{updated_agent_detail.name} 에이전트가 성공적으로 업데이트되었습니다",
            agent=agent_detail,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating agent {agent_id}: {str(e)}")
        logger.error(f"Request data: {request}")
        traceback.print_exc()
        await db.rollback()  # 에러 발생 시 롤백
        raise HTTPException(
            status_code=500,
            detail=f"에이전트 업데이트 중 오류가 발생했습니다: {str(e)}",
        )


@router.delete(
    "/agents/{agent_id}",
    response_model=ApiResponse,
    description="에이전트를 삭제합니다.",
)
async def delete_agent(
    agent_id: int = Path(..., ge=1),
    db: AsyncSession = Depends(get_async_db),
) -> ApiResponse:
    try:
        # 에이전트 및 관련 데이터 삭제 (문서 포함)
        delete_success = await expert_agent_service.delete_agent_with_document(
            db, agent_id
        )

        if not delete_success:
            raise HTTPException(status_code=404, detail="에이전트를 찾을 수 없습니다")

        return ApiResponse(
            success=True,
            message=f"에이전트 ID: {agent_id} 및 관련 데이터가 성공적으로 삭제되었습니다",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"에이전트 삭제 중 오류 발생")


# @router.post(
#     "/recommend-steps",
#     response_model=StepRecommendationResponse,
#     description="에이전트 이름, 설명, 문서를 기반으로 Agent의 Step을 추천합니다.",
# )
# async def recommend_steps(
#     request: RecommendStepsRequest = Body(...),
#     db: AsyncSession = Depends(get_async_db),
#     expert_agent_builder: ExpertAgentBuilder = Depends(get_expert_agent_builder),
# ) -> StepRecommendationResponse:
#     try:
#         file_path = None

#         # 문서 ID가 제공된 경우 해당 문서 정보 확인
#         if request.document_id:
#             document = await crud_procedure_document.get(db, id=request.document_id)
#             if not document:
#                 raise HTTPException(status_code=404, detail="문서를 찾을 수 없습니다")

#             # 파일 경로 조회
#             file_path = await crud_procedure_document.get_file_path(db, document.id)
#             if not file_path:
#                 raise HTTPException(
#                     status_code=404, detail="문서 파일을 찾을 수 없습니다"
#                 )

#         # 스텝 추천 (Background Task 고려)
#         recommended_steps = await expert_agent_builder.recommend_steps(
#             name=request.name, description=request.description, file_path=file_path
#         )

#         return StepRecommendationResponse(
#             success=True,
#             message="스텝 추천이 완료되었습니다",
#             document_id=request.document_id,
#             steps=recommended_steps,
#         )

#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(e)
#         traceback.print_exc()
#         raise HTTPException(status_code=500, detail=f"스텝 추천 중 오류 발생")


# @router.get(
#     "/tools",
#     response_model=ToolListResponse,
#     description="모든 도구 목록을 조회합니다.",
# )
# async def get_tools(
#     db: AsyncSession = Depends(get_async_db),
# ) -> ToolListResponse:
#     try:
#         tools = await crud_tool.get_multi(db)
#         return ToolListResponse(
#             success=True, message="모든 도구 목록을 조회했습니다", tools=tools
#         )
#     except Exception as e:
#         logger.error(e)
#         traceback.print_exc()
#         raise HTTPException(
#             status_code=500, detail="모든 도구 목록을 조회하는 중 오류 발생"
#         )


@router.post("/use_count_up")
async def use_count_up(
    expert_agent_id: int, db: AsyncSession = Depends(get_async_db)
) -> UseCountResponse:
    """
    사용 횟수를 증가시키는 API
    """
    try:
        agent_use_count = await crud_expert_agent.use_count_up(db, expert_agent_id)

        if not agent_use_count:
            raise HTTPException(status_code=404, detail="없는 에이전트 목록입니다.")

        await db.commit()

        return UseCountResponse(
            success=True,
            message="agent 사용 횟수가 증가합니다.",
            expert_agent_id=expert_agent_id,
            use_count=agent_use_count,
        )
    except HTTPException:
        await db.rollback()
        raise
    except Exception as e:
        await db.rollback()
        logger.error(e)
        raise HTTPException(status_code=500, detail="사용 횟수 증가 중 오류 발생")


@router.get(
    "/my_agents",
    response_model=AgentListResponse,
    description="에이전트 목록을 조회합니다.",
)
async def get_my_agents(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    user_id: Optional[int] = None,
    order: Optional[str] = Query(
        None, enum=["name_asc", "name_desc", "popularity", "latest"]
    ),
    name: Optional[str] = None,
    # user_info: Optional[UserInfo] = Depends(get_user_info_from_token),
    db: AsyncSession = Depends(get_async_db),
) -> AgentListResponse:
    try:
        # 차후 필터링 로직 추가하기, org_id, team_id, user_id 등
        # Category나 usage_scope는 프론트서 쓸 수도 있음, 그냥 남겨만 둠 일단 백엔드는 전체 반환하는 것으로
        agents = await crud_expert_agent.get_multi_filtered_by_user_id(
            db,
            skip=skip,
            limit=limit,
            order=order,
            name=name,
            user_id=user_id,
        )

        total = await crud_expert_agent.get_agent_count(
            db,
            name=name,
            created_user_id=user_id,
        )

        filtered_agents = []
        for agent in agents:
            if agent.id not in [95, 108, 116]:
                filtered_agents.append(agent)
            else:
                continue

        return AgentListResponse(
            agents=filtered_agents,
            total=total,
            skip=skip,
            limit=limit,
            order=order,
            name=name,
        )
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing GET agents"
        )


@router.post("/instruction_ai")
async def make_instruction(
    agent_name: str = Form(..., description="에이전트 이름"),
    agent_description: str = Form(..., description="에이전트 설명"),
    file: Optional[UploadFile] = File(None, description="업로드할 파일"),
    general_agent_builder: GeneralAgentBuilder = Depends(get_general_agent_builder),
) -> ApiResponse:
    try:
        file_content = None
        if file:
            validation = await file_service.validate_file(file)
            if validation:
                raise HTTPException(**validation)
            upload_result = await file_service.read_document(file)
            if isinstance(upload_result, dict):
                raise HTTPException(**upload_result)
            file_content = upload_result

        # 임시 응답
        instruction = general_agent_builder.make_instruction(
            agent_name=agent_name,
            agent_description=agent_description,
            file_content=file_content,
        )

        return ApiResponse(success=True, message=str(instruction))

    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="Instruction 생성 중 오류가 발생했습니다."
        )


@router.post("/recommend_tools")
async def recommend_tool(
    agent_name: str = Form(..., description="에이전트 이름"),
    agent_description: str = Form(..., description="에이전트 설명"),
    instruction: str = Form(...),
    file: Optional[UploadFile] = File(None, description="업로드할 파일"),
    general_agent_builder: GeneralAgentBuilder = Depends(get_general_agent_builder),
    db: Session = Depends(get_db),
) -> ToolListResponse:
    try:
        file_content = None
        if file:
            validation = await file_service.validate_file(file)
            if validation:
                raise HTTPException(**validation)
            upload_result = await file_service.read_document(file)
            if isinstance(upload_result, dict):
                raise HTTPException(**upload_result)
            file_content = upload_result

        # 도구 추천
        tools = general_agent_builder.recommend_tools(
            db=db,
            agent_name=agent_name,
            agent_description=agent_description,
            instruction=instruction,
            file_content=file_content,
        )

        return ToolListResponse(
            success=True, message="도구 추천이 완료되었습니다", tools=tools
        )

    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail="tool 추천 중 오류가 발생했습니다.")


@router.get(
    "/agents/{agent_id}/general",
    response_model=GeneralAgentDetailResponse,
    description="일반 agent의 상세 정보를 조회합니다. (instruction과 tools 포함)",
)
async def get_general_agent_detail(
    agent_id: int = Path(..., ge=1),
    db: AsyncSession = Depends(get_async_db),
) -> GeneralAgentDetailResponse:
    try:
        agent_detail = await crud_expert_agent.get_general_agent_detail(db, agent_id)
        if not agent_detail:
            raise HTTPException(status_code=404, detail="일반 agent를 찾을 수 없습니다")

        return GeneralAgentDetailResponse(
            success=True, message="일반 agent 상세 정보 조회 성공", **agent_detail
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail=f"일반 agent 상세 정보 조회 중 오류 발생: {str(e)}"
        )


@router.post(
    "/recommend_step_action",
    response_model=StepActionRecommendationResponse,
    description="에이전트 이름, 설명, 문서를 기반으로 Step과 Action을 함께 추천합니다.",
)
async def recommend_step_action(
    agent_name: str = Form(..., description="에이전트 이름"),
    agent_description: str = Form(..., description="에이전트 설명"),
    file: Optional[UploadFile] = File(None, description="업로드할 파일"),
    expert_agent_builder: ExpertAgentBuilder = Depends(get_expert_agent_builder),
    db: Session = Depends(get_db),
) -> StepActionRecommendationResponse:
    try:
        file_content = None
        if file:

            # validation = await file_service.validate_file(file)
            # if validation:
            #     raise HTTPException(**validation)
            upload_result = await file_service.read_document(file)
            if isinstance(upload_result, dict):
                raise HTTPException(**upload_result)
            file_content = upload_result

        # Step과 Action 추천
        steps = await expert_agent_builder.recommend_step_action(
            db=db,
            agent_name=agent_name,
            agent_description=agent_description,
            file_content=file_content,
        )

        return StepActionRecommendationResponse(
            success=True,
            message="Step과 Action 추천이 완료되었습니다",
            steps=steps,
        )

    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="Step과 Action 추천 중 오류가 발생했습니다."
        )


@router.get("/get_chat_starter", response_model=ChatStarterResponse)
def get_chat_starter(agent_id: int, db: Session = Depends(get_db)):
    try:
        starter_list = crud_chat_starter.get_chat_starter_by_agent_id(db, agent_id)

        return ChatStarterResponse(
            starter=[starter.starter for starter in starter_list]
        )
    except Exception as e:
        logger.error(e)
        raise HTTPException(
            status_code=500, detail="챗봇 시작 메시지 조회 중 오류가 발생했습니다."
        )


@router.post("/create_chat_starter")
async def create_chat_starter(
    agent_id: int,
    starter: str = Form(..., description="챗봇 시작 메시지"),
    db: AsyncSession = Depends(get_async_db),
):
    try:
        await crud_chat_starter.create_chat_starter(
            db, ChatStarter(agent_id=agent_id, starter=starter)
        )
        return ApiResponse(success=True, message="챗봇 시작 메시지 생성 성공")
    except Exception as e:
        await db.rollback()
        logger.error(e)
        raise HTTPException(
            status_code=500, detail="챗봇 시작 메시지 생성 중 오류가 발생했습니다."
        )


@router.delete("/delete_chat_starter")
async def delete_chat_starter(
    starter_id: int, db: AsyncSession = Depends(get_async_db)
):
    try:
        await crud_chat_starter.delete_chat_starter(db, ChatStarter(id=starter_id))
        return ApiResponse(success=True, message="챗봇 시작 메시지 삭제 성공")
    except Exception as e:
        await db.rollback()
        logger.error(e)
        raise HTTPException(
            status_code=500, detail="챗봇 시작 메시지 삭제 중 오류가 발생했습니다."
        )


@router.post("/upload_knowledge_document")
async def upload_knowledge_document(
    file: UploadFile = File(..., description="업로드할 파일"),
    db: Session = Depends(get_db),
):
    try:
        validation = await file_service.validate_file(file)
        if validation:
            raise HTTPException(**validation)
        upload_result = await file_service.read_document(file)
        if isinstance(upload_result, dict):
            raise HTTPException(**upload_result)
        file_content = upload_result

        return ApiResponse(success=True, message="문서 업로드 성공")
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="문서 업로드 중 오류가 발생했습니다."
        )


@router.get("/action_info")
def get_action_info(
    action_id: int,
    db: Session = Depends(get_db),
):
    action_info = crud_action.get_action_info(db, action_id)
    return action_info


@router.post("/action_info")
def update_action_info(
    action_id: int,
    action_info: UpdateActionRequest,
    db: Session = Depends(get_db),
):
    action_info = crud_action.update_action(db, action_id, action_info)
    return action_info
