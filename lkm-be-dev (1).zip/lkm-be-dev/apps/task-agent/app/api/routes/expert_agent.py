import asyncio

# 로거 import 추가
import logging
import time
import uuid
from typing import Any, AsyncGenerator, Dict

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from client.canvas_create_client import CanvasCreateClient
from client.mcp_mindmap_client import McpMindmapClient
from core.context import set_chat_contexts
from core.llm import get_model
from database.session import get_async_db
from services.agent.expert_agent_v2 import ExpertAgent
from services.agent.state import State
from services.chat_service import ChatService

# General Agent import 추가
from services.general_agent.general_agent_service import (
    EnhancedFrontendEventCallback,
    EnhancedMCPReActAgentWithHierarchicalPlanning,
    QueryComplexity,
    RoutingDecision,
)
from services.schemas.chat.request import (
    ChatInput,
    SupervisorRequestBody,
)
from services.schemas.chat.response import (
    ModelsResponse,
    OpenAIResponse,
)
from services.schemas.user.user_info import UserInfo

logger = logging.getLogger(__name__)

router = APIRouter()

# General Agent 인스턴스 (전역으로 관리)
enhanced_mcp_agent: EnhancedMCPReActAgentWithHierarchicalPlanning | None = None


async def get_general_agent() -> EnhancedMCPReActAgentWithHierarchicalPlanning:
    """General Agent 인스턴스를 가져오거나 초기화"""
    global enhanced_mcp_agent
    if enhanced_mcp_agent is None:
        enhanced_mcp_agent = EnhancedMCPReActAgentWithHierarchicalPlanning()
        await enhanced_mcp_agent.initialize()
    return enhanced_mcp_agent


class GeneralAgentGraphWrapper:
    """
    General Agent의 이벤트 스트림을 ChatService와 호환되도록 래핑하는 클래스.
    LangGraph의 'graph' 객체처럼 동작하여 astream 메서드를 제공합니다.
    enhanced_chat_with_auto_routing의 자동 라우팅 로직을 통합합니다.
    """

    def __init__(
        self,
        agent: EnhancedMCPReActAgentWithHierarchicalPlanning,
        chat_id: str,
        user_message: str,
    ):
        self.agent = agent
        self.chat_id = chat_id
        self.user_message = user_message

    async def astream(
        self, state: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        enhanced_chat_with_auto_routing의 자동 라우팅 로직을 사용하여
        쿼리를 자동 분석하고 적절한 처리 방식으로 라우팅합니다.
        """
        try:
            # 이벤트 큐와 콜백 생성
            event_queue = asyncio.Queue()
            callback = EnhancedFrontendEventCallback(
                self.chat_id, event_queue, self.agent.scenario_logger
            )

            # 시작 이벤트 즉시 전송
            start_event = {
                "executor": {
                    "view_messages": [
                        {
                            "START": {
                                "content": "🔧 React Agent로 처리를 시작합니다",
                                "description": "쿼리 분석 및 도구 기반 처리 준비 중...",
                                "key": "react_start",
                                "id": self.chat_id,
                            }
                        }
                    ],
                    "messages": {},
                }
            }
            yield start_event

            await asyncio.sleep(2)
            # 🔥 분석 중 이벤트 즉시 전송
            analyzing_event = {
                "executor": {
                    "view_messages": [
                        {
                            "THINKING": {
                                "content": "쿼리 복잡도 분석 중입니다.",
                                "description": "적절한 처리 방식을 결정하기 위해 쿼리를 분석하고 있습니다",
                                "key": "complexity_analysis",
                                "id": self.chat_id,
                                "title": "쿼리 복잡도 분석 중입니다.",
                            }
                        }
                    ],
                    "messages": {},
                }
            }
            yield analyzing_event

            await asyncio.sleep(2)
            # 쿼리 분석 - await 제거
            # 1. 쿼리 분석 (AWAIT 수정 - 중요!)
            if hasattr(self.agent, "enhanced_query_analyzer") and hasattr(
                self.agent.enhanced_query_analyzer, "analyze_query_complexity"
            ):
                # analyze_query_complexity는 sync 메서드임
                routing_decision = (
                    self.agent.enhanced_query_analyzer.analyze_query_complexity(
                        self.user_message
                    )
                )
            else:
                # 폴백: 기본 분석기 사용
                if hasattr(self.agent, "query_analyzer") and self.agent.query_analyzer:
                    basic_analysis = self.agent.query_analyzer.analyze_query(
                        self.user_message
                    )
                    complexity_mapping = {
                        "simple": QueryComplexity.SIMPLE_CHAT,
                        "medium": QueryComplexity.SIMPLE_TOOL,
                        "complex": QueryComplexity.COMPLEX_TOOL,
                    }
                    routing_decision = RoutingDecision(
                        complexity=complexity_mapping.get(
                            basic_analysis.complexity, QueryComplexity.SIMPLE_TOOL
                        ),
                        confidence=0.7,
                        reasoning=f"폴백 분석: {basic_analysis.query_type}",
                        recommended_approach="react_pattern",
                        estimated_steps=basic_analysis.estimated_steps,
                        requires_planning=False,
                    )
                else:
                    # 기본 라우팅 결정
                    routing_decision = RoutingDecision(
                        complexity=QueryComplexity.SIMPLE_TOOL,
                        confidence=0.5,
                        reasoning="기본 라우팅 (분석기 없음)",
                        recommended_approach="react_pattern",
                        estimated_steps=1,
                        requires_planning=False,
                    )

            # 🔥 라우팅 결정 이벤트 즉시 전송
            complexity_name = {
                QueryComplexity.SIMPLE_CHAT: "단순 대화",
                QueryComplexity.SIMPLE_TOOL: "단순 도구",
                QueryComplexity.COMPLEX_TOOL: "복합 도구",
            }.get(routing_decision.complexity, "알 수 없음")

            routing_event = {
                "executor": {
                    "view_messages": [
                        {
                            "ROUTING": {
                                "content": f"사용자 질의를 분석중입니다 : {complexity_name} 패턴",
                                "description": f"신뢰도: {routing_decision.confidence:.2f}",
                                "key": "auto_routing_decision",
                                "id": self.chat_id,
                                "title": f"자동 라우팅 완료: {complexity_name} 패턴",
                            }
                        }
                    ],
                    "messages": {},
                }
            }
            yield routing_event

            await asyncio.sleep(2)
            # ✅ 핵심 수정: 백그라운드 태스크로 React Agent 실행
            agent_task = None
            result = None

            # 라우팅 결정에 따른 처리
            if routing_decision.complexity == QueryComplexity.SIMPLE_CHAT:
                # General Agent로 처리
                processing_event = {
                    "executor": {
                        "view_messages": [
                            {
                                "WORKFLOW": {
                                    "content": "단순 대화로 분류되어 LLM이 직접 응답합니다.",
                                    "description": "단순 대화로 분류되어 도구 사용 없이 LLM 직접 응답",
                                    "key": "general_agent_start",
                                    "id": self.chat_id,
                                    "title": "단순 대화로 분류되어 LLM이 직접 응답합니다.",
                                }
                            }
                        ],
                        "messages": {},
                    }
                }
                yield processing_event

                if hasattr(self.agent, "_handle_simple_chat"):
                    agent_task = asyncio.create_task(
                        self.agent._handle_simple_chat(
                            self.chat_id, self.user_message, callback
                        )
                    )
                else:
                    # 메서드가 없으면 기본 처리
                    result = {
                        "content": f"단순 대화 처리: {self.user_message}",
                        "description": "기본 처리",
                    }

            else:  # SIMPLE_TOOL or COMPLEX_TOOL
                # React Agent로 처리
                processing_type = (
                    "단순 도구"
                    if routing_decision.complexity == QueryComplexity.SIMPLE_TOOL
                    else "복합 도구"
                )

                if routing_decision.complexity == QueryComplexity.SIMPLE_TOOL:
                    if hasattr(self.agent, "_handle_simple_tool_usage"):
                        agent_task = asyncio.create_task(
                            self.agent._handle_simple_tool_usage(
                                self.chat_id,
                                self.user_message,
                                routing_decision,
                                callback,
                            )
                        )
                    else:
                        # 메서드가 없으면 기본 처리
                        result = {
                            "content": f"Simple tool 처리: {self.user_message}",
                            "description": "기본 처리",
                        }
                else:
                    if hasattr(self.agent, "_handle_complex_tool_usage"):
                        agent_task = asyncio.create_task(
                            self.agent._handle_complex_tool_usage(
                                self.chat_id,
                                self.user_message,
                                routing_decision,
                                callback,
                            )
                        )
                    else:
                        # 메서드가 없으면 기본 처리
                        result = {
                            "content": f"Complex tool 처리: {self.user_message}",
                            "description": "기본 처리",
                        }

            # ✅ 실시간 이벤트 스트리밍: agent_task와 event_queue를 병렬 처리
            if agent_task:
                event_count = 0
                max_events = 100  # 무한 루프 방지

                while not agent_task.done() and event_count < max_events:
                    try:
                        # 0.1초마다 이벤트 큐 확인
                        event = await asyncio.wait_for(event_queue.get(), timeout=0.1)
                        # 이벤트를 executor 구조로 래핑
                        # wrapped_event = {
                        #     "executor": {
                        #         "view_messages": [
                        #             {
                        #                 event.get("type"): {
                        #                     "content": event.get("content"),
                        #                     "description": event.get("description"),
                        #                     "key": event.get("key"),
                        #                     "id": self.chat_id,
                        #                 }
                        #             }
                        #         ],
                        #         "messages": {},
                        #     }
                        # }
                        yield event
                        event_count += 1
                    except asyncio.TimeoutError:
                        # 타임아웃은 정상 - 계속 진행
                        continue
                    except Exception as e:
                        logger.error(f"이벤트 스트리밍 오류: {e}")
                        break

                # Agent 작업 완료 대기
                try:
                    result = await agent_task
                except Exception as e:
                    logger.error(f"React Agent 실행 오류: {e}")
                    error_event = {
                        "executor": {
                            "view_messages": [
                                {
                                    "ERROR": {
                                        "content": f"React Agent 처리 중 오류: {str(e)}",
                                        "description": "도구 기반 처리 중 시스템 오류 발생",
                                        "key": "react_error",
                                        "id": self.chat_id,
                                        "title": "react_error",
                                    }
                                }
                            ],
                            "messages": {},
                        }
                    }
                    yield error_event
                    return

            # ✅ 남은 이벤트들 모두 전송
            remaining_events = 0
            while not event_queue.empty() and remaining_events < 50:
                try:
                    event = event_queue.get_nowait()
                    # wrapped_event = {
                    #     "executor": {
                    #         "view_messages": [{
                    #             event.get("type"): {
                    #                 "content": event.get("content"),
                    #                 "description": event.get("description"),
                    #                 "key": event.get("key"),
                    #                 "id": self.chat_id,
                    #             }
                    #         }],
                    #         "messages": {},
                    #     }
                    # }
                    yield event
                    remaining_events += 1
                except asyncio.QueueEmpty:
                    break

            # ✅ THINKING 이벤트 추가 (PLAN_COMPLETE 이후, CANVAS 이전)
            if routing_decision.complexity != QueryComplexity.SIMPLE_CHAT:
                thinking_event = {
                    "executor": {
                        "view_messages": [
                            {
                                "THINKING": {
                                    "content": "💭 실행 결과를 정리하고 최종 응답을 생성하고 있습니다...",
                                    "description": "수집된 정보를 종합하여 사용자 친화적인 형태로 변환 중",
                                    "key": "result_synthesis",
                                    "id": self.chat_id,
                                    "title": "react_result_synthesis",
                                }
                            }
                        ],
                        "messages": {},
                    }
                }
                yield thinking_event

            # 결과 이벤트 전송
            if result and result.get("content"):
                canvas_create_client = CanvasCreateClient()
                canvas_uuid = await canvas_create_client.create_canvas(
                    chat_id=self.chat_id,
                    title=(
                        result["summary"] if "summary" in result else "react_result"
                    ),
                    content=result["content"],
                )

                canvas_event = {
                    "executor": {
                        "view_messages": [
                            {
                                "CANVAS": {
                                    "content": result["content"],
                                    "description": result.get(
                                        "description", "React Agent 처리 완료"
                                    ),
                                    "key": canvas_uuid,
                                    "id": self.chat_id,
                                    "title": "canvas_result",
                                }
                            }
                        ],
                        "messages": {},
                    }
                }
                yield canvas_event

                mcp_mindmap_client = McpMindmapClient()
                mindmap_response = await mcp_mindmap_client.create_mindmap(
                    result["content"]
                )

                mindmap_event = {
                    "executor": {
                        "view_messages": [
                            {
                                "GRAPH": {
                                    "content": mindmap_response,
                                    "description": "Mindmap 생성 완료",
                                    "key": str(uuid.uuid4()),
                                    "id": self.chat_id,
                                    "title": "graph_result",
                                }
                            }
                        ],
                        "messages": {},
                    }
                }
                yield mindmap_event

            agent_type = (
                "General Agent"
                if routing_decision.complexity == QueryComplexity.SIMPLE_CHAT
                else "React Agent"
            )

            # 종료 이벤트
            end_event = {
                "executor": {
                    "view_messages": [
                        {
                            "END": {
                                "content": f"Agent ({agent_type}) 처리 완료 되었습니다.",
                                "description": f"복잡도: {complexity_name} | 신뢰도: {routing_decision.confidence:.2f} | 접근방식: {routing_decision.recommended_approach}",
                                "key": "auto_routing_complete",
                                "id": self.chat_id,
                                "title": f"Agent ({agent_type}) 처리 완료 되었습니다.",
                            }
                        }
                    ],
                    "messages": {},
                }
            }
            yield end_event

        except Exception as e:
            logger.error(f"React Agent 스트리밍 처리 오류: {e}")
            error_event = {
                "executor": {
                    "view_messages": [
                        {
                            "ERROR": {
                                "content": f"React Agent 처리 중 치명적 오류: {str(e)}",
                                "description": "시스템 오류로 인한 처리 중단",
                                "key": "react_fatal_error",
                                "id": self.chat_id,
                                "title": "react_fatal_error",
                            }
                        }
                    ],
                    "messages": {},
                }
            }
            yield error_event

        finally:
            if result and result.get("summary") == "오류 발생":
                canvas_create_client = CanvasCreateClient()
                await canvas_create_client.delete_canvas(canvas_uuid)

    def stream(self, state: Dict[str, Any]):
        """동기식 스트리밍은 현재 지원하지 않습니다."""
        raise NotImplementedError(
            "Sync streaming is not implemented for General Agent wrapper."
        )


@router.post("/supervisor/chat")
async def expert_agent_with_supervisor(
    request: SupervisorRequestBody,
    stream: bool = True,
    db: AsyncSession = Depends(get_async_db),
) -> Any:
    """
    supervisor 를 통해 Expert Agent를 구동할 때 사용
    """
    try:
        chat_service = ChatService()

        # State 초기화 - None 체크 추가
        if request.state is None:
            state = State()
        else:
            # State는 TypedDict이므로 직접 생성
            state = State()
            state.update(request.state)

        # chat_id 설정 (필수 필드이므로 기본값 제공)
        if hasattr(state, "__setitem__"):
            state["chat_id"] = request.chat_id or "default_chat_id"
        else:
            # 다른 방식으로 설정
            setattr(state, "chat_id", request.chat_id or "default_chat_id")

        if request.user_info and request.input_data:
            set_chat_contexts(request.user_info, request.input_data[-1])

        # user_id를 str로 변환
        user_id_str = (
            str(request.user_info.user_id)
            if request.user_info and request.user_info.user_id
            else None
        )

        # 모델 타입 체크 및 변환
        llm_model = get_model(user_id_str)
        # ChatAnthropic을 사용하는 경우 다른 처리 필요할 수 있음
        # 현재는 타입 무시하고 진행
        graph = await ExpertAgent(
            llm=llm_model,  # type: ignore
            agent_id=request.expert_agent_id or 0,
            canvas=request.canvas or "",
        ).get_graph(db, stream)

        # user_info가 None인 경우 기본값 설정
        user_info = request.user_info or UserInfo(
            user_id=0, email="default@example.com", username="기본 사용자"
        )

        if request.stream:
            return StreamingResponse(
                chat_service.supervisor_chat_completions_stream(
                    request.input_data or [], state, user_info, graph
                ),
                media_type="text/event-stream",
            )
        else:
            return await chat_service.supervisor_chat_completions(
                request.input_data or [], state, user_info, graph
            )
    except Exception as e:
        logger.error(f"Expert agent supervisor error: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/supervisor/general/chat")
async def general_agent_with_supervisor(
    request: SupervisorRequestBody,
    db: AsyncSession = Depends(get_async_db),
) -> Any:
    """
    supervisor를 통해 General Agent를 구동할 때 사용 (chat_service 사용)
    enhanced_chat_with_auto_routing의 자동 라우팅 로직을 적용합니다.
    """
    try:
        chat_service = ChatService()

        if not request.input_data:
            raise HTTPException(status_code=400, detail="input_data is required")

        user_message = request.input_data[-1].get("content", "")
        chat_id = request.chat_id or f"general_{int(time.time())}"

        # State 초기화 - None 체크 추가
        if request.state is None:
            state = State()
        else:
            state = State()
            state.update(request.state)

        # chat_id 설정
        if hasattr(state, "__setitem__"):
            state["chat_id"] = chat_id
        else:
            setattr(state, "chat_id", chat_id)

        if request.input_data and request.user_info:
            set_chat_contexts(request.user_info, request.input_data[-1])

        agent = await get_general_agent()

        # user_info가 None인 경우 기본값 설정
        user_info = request.user_info or UserInfo(
            user_id=0, email="default@example.com", username="기본 사용자"
        )

        # 스트리밍 응답
        if request.stream:
            # 자동 라우팅 로직이 적용된 GeneralAgentGraphWrapper 사용
            graph = GeneralAgentGraphWrapper(agent, chat_id, user_message)
            return StreamingResponse(
                chat_service.supervisor_chat_completions_stream(
                    request.input_data, state, user_info, graph  # type: ignore
                ),
                media_type="text/event-stream",
            )
        else:
            # 비스트리밍 응답의 경우도 자동 라우팅 로직 적용
            try:
                # 쿼리 분석
                if hasattr(agent, "enhanced_query_analyzer") and hasattr(
                    agent.enhanced_query_analyzer, "analyze_query_complexity"
                ):
                    routing_decision = (
                        agent.enhanced_query_analyzer.analyze_query_complexity(
                            user_message
                        )
                    )
                else:
                    # 폴백 로직
                    from services.general_agent.general_agent_service import (
                        QueryComplexity,
                        RoutingDecision,
                    )

                    if hasattr(agent, "query_analyzer") and agent.query_analyzer:
                        basic_analysis = agent.query_analyzer.analyze_query(
                            user_message
                        )
                        complexity_mapping = {
                            "simple": QueryComplexity.SIMPLE_CHAT,
                            "medium": QueryComplexity.SIMPLE_TOOL,
                            "complex": QueryComplexity.COMPLEX_TOOL,
                        }
                        routing_decision = RoutingDecision(
                            complexity=complexity_mapping.get(
                                basic_analysis.complexity, QueryComplexity.SIMPLE_TOOL
                            ),
                            confidence=0.7,
                            reasoning=f"폴백 분석: {basic_analysis.query_type}",
                            recommended_approach="react_pattern",
                            estimated_steps=basic_analysis.estimated_steps,
                            requires_planning=False,
                        )
                    else:
                        routing_decision = RoutingDecision(
                            complexity=QueryComplexity.SIMPLE_CHAT,
                            confidence=0.5,
                            reasoning="기본 채팅 처리",
                            recommended_approach="simple_chat",
                            estimated_steps=1,
                            requires_planning=False,
                        )

                # 라우팅에 따른 처리
                from services.general_agent.general_agent_service import QueryComplexity

                events = []
                final_content = ""

                # 라우팅 정보 이벤트 추가
                routing_event = {
                    "type": "ROUTING",
                    "content": f"🎯 자동 라우팅: {routing_decision.complexity.value}",
                    "description": f"신뢰도: {routing_decision.confidence:.2f} | {routing_decision.reasoning}",
                    "key": "auto_routing_decision",
                }
                events.append(routing_event)

                if routing_decision.complexity == QueryComplexity.SIMPLE_CHAT:
                    # General Agent로 처리 - 직접 구현
                    try:
                        from langchain_core.messages import HumanMessage

                        chat_prompt = f"""당신은 친근하고 도움이 되는 AI 어시스턴트입니다.

사용자의 메시지: {user_message}

다음과 같이 응답해주세요:
1. 친근하고 자연스러운 톤으로 대화하세요
2. 사용자의 감정이나 상황을 고려해서 응답하세요
3. 필요하다면 추가 질문을 통해 더 도움을 드릴 수 있음을 알려주세요
4. 구체적인 작업이 필요하다면 어떤 도움을 드릴 수 있는지 설명해주세요"""

                        # model이 None이 아닌지 확인
                        if hasattr(agent, "model") and agent.model:
                            response = await agent.model.ainvoke(
                                [HumanMessage(content=chat_prompt)]
                            )
                            final_content = (
                                response.content
                                if hasattr(response, "content")
                                else str(response)
                            )
                        else:
                            final_content = f"죄송합니다. 모델이 초기화되지 않았습니다."
                    except Exception as e:
                        final_content = (
                            f"죄송합니다. 처리 중 오류가 발생했습니다: {str(e)}"
                        )
                else:
                    # React Agent로 처리
                    import asyncio

                    from services.general_agent.general_agent_service import (
                        EnhancedFrontendEventCallback,
                    )

                    event_queue = asyncio.Queue()
                    callback = EnhancedFrontendEventCallback(
                        chat_id, event_queue, agent.scenario_logger
                    )

                    try:
                        if routing_decision.complexity == QueryComplexity.SIMPLE_TOOL:
                            if hasattr(agent, "_handle_simple_tool_usage"):
                                result = await agent._handle_simple_tool_usage(
                                    chat_id, user_message, routing_decision, callback
                                )
                            else:
                                result = {
                                    "content": f"Simple tool 처리: {user_message}"
                                }
                        else:
                            if hasattr(agent, "_handle_complex_tool_usage"):
                                result = await agent._handle_complex_tool_usage(
                                    chat_id, user_message, routing_decision, callback
                                )
                            else:
                                result = {
                                    "content": f"Complex tool 처리: {user_message}"
                                }

                        # 이벤트 큐의 이벤트들을 events에 추가
                        while not event_queue.empty():
                            try:
                                event = event_queue.get_nowait()
                                events.append(event)
                            except asyncio.QueueEmpty:
                                break

                        final_content = (
                            result.get("content", "처리 완료")
                            if result
                            else "처리 중 오류 발생"
                        )
                    except Exception as e:
                        final_content = f"도구 처리 중 오류가 발생했습니다: {str(e)}"
                        events.append(
                            {
                                "type": "ERROR",
                                "content": f"도구 처리 오류: {str(e)}",
                                "description": "React Agent 처리 실패",
                                "key": "tool_processing_error",
                            }
                        )

                canvas_create_client = CanvasCreateClient()
                uuid = await canvas_create_client.create_canvas(
                    chat_id=chat_id,
                    title="general_result",
                    content=str(final_content),
                )

                # 최종 이벤트 추가
                completion_event = {
                    "type": "CANVAS",
                    "content": final_content,
                    "description": f"자동 라우팅 완료: {routing_decision.complexity.value}",
                    "key": uuid,
                }
                events.append(completion_event)

                return {
                    "response": final_content,
                    "chat_id": chat_id,
                    "events": events,
                    "metadata": {
                        "agent_type": "general",
                        "routing_enabled": True,
                        "routing_decision": routing_decision.complexity.value,
                        "confidence": routing_decision.confidence,
                        "event_count": len(events),
                    },
                }

            except Exception as e:
                return {
                    "response": f"General Agent 자동 라우팅 처리 중 오류가 발생했습니다: {str(e)}",
                    "chat_id": chat_id,
                    "events": [
                        {
                            "type": "ERROR",
                            "content": f"자동 라우팅 오류: {str(e)}",
                            "description": "시스템 오류로 인한 라우팅 실패",
                            "key": "auto_routing_error",
                        }
                    ],
                    "metadata": {"agent_type": "general", "error": str(e)},
                }
    except Exception as e:
        logger.error(f"General agent supervisor error: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/chat/completions", response_model=OpenAIResponse)
async def expert_agent_response(
    input_data: ChatInput, db: AsyncSession = Depends(get_async_db)
) -> Dict[str, Any]:
    """OpenWebUI 등을 통해 Expert Agent만 단독으로 구동해서 사용할 때 사용 - 최적화된 트랜잭션 관리"""
    try:
        id = f"chatcmpl-{int(time.time())}"
        chat_service = ChatService()

        # 모델 타입 체크 및 변환
        llm_model = get_model()
        graph = await ExpertAgent(
            llm=llm_model, agent_id=1, canvas=""  # type: ignore
        ).get_graph(db=db, stream=False)

        # OpenAIRequest 형태로 변환
        from services.schemas.chat.request import OpenAIRequest

        openai_request = OpenAIRequest(
            model=input_data.model,
            messages=input_data.messages,
            stream=False,
            temperature=getattr(input_data, "temperature", 0.0),
            max_tokens=getattr(input_data, "max_tokens", None),
        )
        return await chat_service.chat_completions(openai_request, id, graph)
    except Exception as e:
        logger.error(f"Expert agent response error: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/models", response_model=ModelsResponse)
async def list_models() -> ModelsResponse:
    """
    사용 가능한 모델 목록을 반환
    """
    try:
        chat_service = ChatService()
        from services.schemas.chat.response import ModelData

        # 모델 데이터를 ModelData 형태로 변환
        model_list = chat_service.get_available_models()
        model_data_list = []

        for model in model_list:
            try:
                # 각 모델에 대해 ModelData 인스턴스 생성
                from services.schemas.chat.response import ModelPermission

                permission = ModelPermission(
                    id=model.get("id", "unknown"),
                    created=model.get("created", 0),
                    organization="*",
                )

                model_data = ModelData(
                    id=model.get("id", "unknown"),
                    object=model.get("object", "model"),
                    created=model.get("created", 0),
                    owned_by=model.get("owned_by", "system"),
                    permission=[permission],
                    root=model.get("id", "unknown"),
                )
                model_data_list.append(model_data)
            except Exception as e:
                # 모델 파싱 에러가 있어도 계속 진행
                logger.warning(f"Model parsing error: {e}")
                continue

        return ModelsResponse(data=model_data_list)
    except Exception as e:
        logger.error(f"List models error: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
