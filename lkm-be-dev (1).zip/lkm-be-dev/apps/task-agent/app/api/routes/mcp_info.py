import requests
from fastapi import APIRouter, HTTPException

from core.config import get_setting

settings = get_setting()
router = APIRouter(tags=["MCP Info"])

mcp_server_url = settings.MCP_SERVER_URL


@router.get("/mcp-routers", summary="MCP Routers")
async def get_mcp_info():
    if not mcp_server_url:
        raise HTTPException(
            status_code=500,
            detail="MCP_SERVER_URL is not configured. Please set the MCP_SERVER_URL environment variable.",
        )

    try:
        response = requests.get(f"{mcp_server_url}/mcp-routers")
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to connect to MCP server at {mcp_server_url}: {str(e)}",
        )


@router.get("/mcp-tools")
async def get_mcp_tool_info(
    server_name: str,
):
    if not mcp_server_url:
        raise HTTPException(
            status_code=500,
            detail="MCP_SERVER_URL is not configured. Please set the MCP_SERVER_URL environment variable.",
        )

    try:
        response = requests.post(
            f"{mcp_server_url}/{server_name}/mcp/",
            headers={
                "Content-Type": "application/json; charset=utf-8",
                "Accept": "application/json, text/event-stream",
                "Accept-Charset": "utf-8",
            },
            json={"jsonrpc": "2.0", "id": 1, "method": "tools/list"},
        )
        response.raise_for_status()

        response.encoding = "utf-8"

        content = response.text
        if content.startswith("event: message"):
            lines = content.split("\n")
            for line in lines:
                if line.startswith("data: "):
                    json_data = line[6:]
                    import json

                    return json.loads(json_data)

        return response.json()
    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to connect to MCP server at {mcp_server_url}: {str(e)}",
        )
