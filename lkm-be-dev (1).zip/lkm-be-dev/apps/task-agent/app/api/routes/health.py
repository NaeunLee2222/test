import time
from typing import Any, Dict

from fastapi import APIRouter

from core.config import get_setting

settings = get_setting()
router = APIRouter(tags=["Health"])


@router.get("/health", summary="Health Check")
async def health_check() -> Dict[str, Any]:
    return {
        "status": "healthy",
        "timestamp": time.time(),
    }
