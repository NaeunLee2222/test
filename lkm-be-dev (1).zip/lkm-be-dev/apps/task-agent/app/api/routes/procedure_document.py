from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Path
from sqlalchemy.ext.asyncio import AsyncSession

from database.session import get_async_db
from database.crud.crud_procedure_document import CRUDProcedureDocument
from services.schemas.expert_agent.procedure_document import ProcedureDocumentResponse, ProcedureDocumentSchema
from services.schemas.expert_agent.response import DocumentUploadResponse, ApiResponse

from core.config import get_setting
from core.log.logging import get_logging

router = APIRouter(tags=["업무절차서 CRUD"])
settings = get_setting()
logger = get_logging()

crud_procedure_document = CRUDProcedureDocument()

@router.post(
    "/documents",
    response_model=DocumentUploadResponse,
    description="업무 절차서를 업로드합니다."
)
async def upload_document(
    file: UploadFile = File(...),
    uploaded_user_id: int = Form(...),
    db: AsyncSession = Depends(get_async_db)
) -> DocumentUploadResponse:
    try:
        # 파일 타입 검사
        if file.content_type not in settings.ALLOWED_FILE_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"허용되지 않는 파일 타입입니다. 허용된 타입: {settings.ALLOWED_FILE_TYPES}\n현재 타입: {file.content_type}"
            )
        
        # 파일 크기 검사
        contents = await file.read()
        file_size = len(contents)
        if file_size > settings.MAX_UPLOAD_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"파일 크기가 최대 허용 크기를 초과합니다. ({file_size} bytes / {settings.MAX_UPLOAD_SIZE} bytes)"
            )
        
        # 문서 생성 및 파일 저장 (agent_id 없이)
        document, file_path = await crud_procedure_document.create_with_file(
            db=db,
            expert_agent_id=None,  # expert_agent_id는 None으로 설정
            original_filename=file.filename,
            file_type=file.content_type,
            uploaded_user_id=uploaded_user_id,
            file_content=contents
        )
        
        return DocumentUploadResponse(
            success=True,
            message="문서 업로드 완료",
            document=document,
            file_path=file_path,
            original_filename=file.filename,
            file_size=file_size
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        raise HTTPException(
            status_code=500,
            detail=f"문서 업로드 중 오류 발생"
        )

@router.get(
    "/documents/{document_id}",
    response_model=ProcedureDocumentResponse,
    description="문서 정보를 조회합니다."
)
async def get_document(
    document_id: int = Path(..., ge=1),
    db: AsyncSession = Depends(get_async_db)
) -> ProcedureDocumentResponse:
    try:
        document = await crud_procedure_document.get(db, id=document_id)
        if not document:
            raise HTTPException(status_code=404, detail="문서를 찾을 수 없습니다")
        
        file_path = await crud_procedure_document.get_file_path(db, document.id)
        if not file_path:
            raise HTTPException(status_code=404, detail="문서 파일을 찾을 수 없습니다")
        
        return ProcedureDocumentResponse(
            document=document,
            file_path=file_path
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        raise HTTPException(
            status_code=500,
            detail=f"문서 조회 중 오류 발생"
        )

@router.delete(
    "/documents/{document_id}",
    response_model=ApiResponse,
    description="문서를 삭제합니다."
)
async def delete_document(
    document_id: int = Path(..., ge=1),
    db: AsyncSession = Depends(get_async_db)
) -> ApiResponse:
    try:
        delete_success = await crud_procedure_document.delete_file(db, document_id)
        if not delete_success:
            raise HTTPException(status_code=404, detail="문서 삭제 실패")
        
        return ApiResponse(
            success=True,
            message=f"문서 삭제 완료"
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        raise HTTPException(
            status_code=500,
            detail=f"문서 삭제 중 오류 발생"
        )