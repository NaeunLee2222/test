import traceback
from datetime import date
from typing import Optional

from fastapi import (
    APIRouter,
    Body,
    Depends,
    HTTPException,
    Path,
    Query,
)
from sqlalchemy.ext.asyncio import AsyncSession

from core.config import get_setting
from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from database.crud.crud_expert_agent import CRUDExpertAgent
from database.crud.crud_expert_agent_history import CRUDExpertAgentHistory
from database.session import get_async_db
from services.schemas.expert_agent.request import CreateAgentHistoryRequest
from services.schemas.expert_agent.response import (
    AdminAgentListResponse,
    AdminDeployedAgentListResponse,
    AgentActivationResponse,
    AgentHistoryResponse,
    ApiResponse,
)

router = APIRouter()
settings = get_setting()
logger = get_logging()

crud_expert_agent_history = CRUDExpertAgentHistory()
crud_expert_agent = CRUDExpertAgent()


@router.post(
    "/action-api",
    description="Action API 정보 등록",
)
def add_action_api() -> None:
    try:
        logger.info("")
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing the request."
        )


@router.get(
    "/agents",
    response_model=AdminAgentListResponse,
    description="에이전트 목록을 조회합니다. (Admin용)",
)
async def get_agents(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    agent_type: Optional[str] = Query(None, enum=["pro", "general"]),
    date_type: Optional[str] = Query(None, enum=["registered_at", "reviewed_at"]),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    review_status: Optional[str] = Query(
        None, enum=["submitted", "deployed", "rejected"]
    ),
    search: Optional[str] = Query(None),
    order_by: Optional[str] = Query(
        None, enum=["id", "username", "review_status", "registered_at", "reviewed_at"]
    ),
    order_direction: Optional[str] = Query(None, enum=["asc", "desc"]),
    db: AsyncSession = Depends(get_async_db),
) -> AdminAgentListResponse:
    try:
        agents, total, submitted_count, deployed_count, rejected_count = (
            await crud_expert_agent.get_multi_filtered_admin(
                db,
                skip=skip,
                limit=limit,
                agent_type=agent_type,
                date_type=date_type,
                start_date=start_date,
                end_date=end_date,
                review_status=review_status,
                search=search,
                order_by=order_by,
                order_direction=order_direction,
            )
        )

        return AdminAgentListResponse(
            success=True,
            total=total,
            agents=agents,
            skip=skip,
            limit=limit,
            submitted_count=submitted_count,
            deployed_count=deployed_count,
            rejected_count=rejected_count,
        )
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing the request."
        )


@router.get(
    "/agents/deployed",
    response_model=AdminDeployedAgentListResponse,
    description="배포된 에이전트 목록을 조회합니다. (Admin용)",
)
async def get_deployed_agents(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    agent_type: Optional[str] = Query(None, enum=["pro", "general"]),
    usage_scope: Optional[str] = Query(None, enum=["public", "org", "personal"]),
    is_activated: Optional[bool] = Query(None),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    search: Optional[str] = Query(None),
    order_by: Optional[str] = Query(
        None, enum=["id", "user_name", "admin_name", "reviewed_at"]
    ),
    order_direction: Optional[str] = Query(None, enum=["asc", "desc"]),
    db: AsyncSession = Depends(get_async_db),
) -> AdminDeployedAgentListResponse:
    try:
        agents, total, submitted_count, deployed_count, rejected_count = (
            await crud_expert_agent.get_multi_filtered_admin(
                db,
                skip=skip,
                limit=limit,
                review_status="deployed",
                agent_type=agent_type,
                usage_scope=usage_scope,
                is_activated=is_activated,
                start_date=start_date,
                end_date=end_date,
                search=search,
                order_by=order_by,
                order_direction=order_direction,
            )
        )

        return AdminDeployedAgentListResponse(
            success=True,
            agents=agents,
            total=total,
            skip=skip,
            limit=limit,
        )

    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing the request."
        )


@router.post(
    "/agents/{agent_id}/history",
    response_model=ApiResponse,
    description="에이전트 수정 이력을 생성합니다.",
)
async def create_agent_history(
    request: CreateAgentHistoryRequest,
    agent_id: int = Path(..., ge=1),
    db: AsyncSession = Depends(get_async_db),
) -> ApiResponse:
    try:
        await crud_expert_agent_history.create_agent_history(
            db,
            expert_agent_id=agent_id,
            modified_user_id=request.modified_user_id,
            description=request.description,
        )
        return ApiResponse(
            success=True,
            message="Agent history created successfully",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing the request."
        )


@router.get(
    "/agents/{agent_id}/history",
    description="에이전트 수정 이력을 조회합니다.",
    response_model=AgentHistoryResponse,
)
async def get_agent_history(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    agent_id: int = Path(..., ge=1),
    db: AsyncSession = Depends(get_async_db),
) -> AgentHistoryResponse:
    try:
        agent_history = await crud_expert_agent_history.get_agent_history(
            db,
            expert_agent_id=agent_id,
            skip=skip,
            limit=limit,
        )
        return AgentHistoryResponse(
            success=True,
            agent_history=agent_history,
            skip=skip,
            limit=limit,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500, detail="An error occurred while processing the request."
        )


@router.patch(
    "/agents/{agent_id}/activation",
    description="에이전트 활성화 상태를 변경합니다.",
    response_model=AgentActivationResponse,
)
async def update_agent_activation(
    agent_id: int = Path(..., ge=1),
    is_activated: bool = Body(..., embed=True, description="활성화 상태"),
    db: AsyncSession = Depends(get_async_db),
) -> AgentActivationResponse:
    try:
        agent = await crud_expert_agent.get_agent_by_id(db, agent_id)
        if not agent:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                src="task-agent",
                detail=f"Agent with id {agent_id} not found",
            )

        await crud_expert_agent.update_agent_activation(db, agent_id, is_activated)
        return AgentActivationResponse(
            success=True,
            message="Agent activation updated successfully",
            agent_id=agent_id,
            is_activated=is_activated,
        )

    except ServiceException:
        raise
    except Exception as e:
        logger.error(e)
        traceback.print_exc()
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.UNEXPECTED_ERROR,
            src="task-agent",
            detail="An error occurred while processing the request.",
        )
