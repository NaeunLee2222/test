import time
from typing import Any, Dict

from fastapi import APIRouter, HTTPException
from starlette.responses import StreamingResponse

from core.context import set_chat_contexts
from core.llm import get_model
from services.agent.chat_with_web_agent import ChatWithWebAgent
from services.chat_service import ChatService
from services.schemas.chat.request import (
    ChatWithWebInput,
    SupervisorRequestBody,
)
from services.schemas.chat.response import ChatWithWebResponse, ModelsResponse

router = APIRouter()


@router.post("/supervisor/chat")
async def chat_with_web_agent_with_supervisor(
    request: SupervisorRequestBody,
) -> Dict[str, Any]:
    """
    supervisor를 통해 웹 채팅 에이전트를 구동할 때 사용
    """
    chat_service = ChatService()
    request.state["chat_id"] = request.chat_id
    set_chat_contexts(request.user_info, request.input_data[-1])
    graph = ChatWithWebAgent(llm=get_model(request.user_info.user_id)).get_graph()

    if request.stream:
        return StreamingResponse(
            chat_service.supervisor_chat_completions_stream(
                request.input_data,
                request.state,
                request.user_info,
                graph,
            ),
            media_type="text/event-stream",
        )
    else:
        response = await chat_service.supervisor_chat_completions(
            request.input_data, request.state, request.user_info, graph
        )
        return response


@router.post("/chat/completions", response_model=ChatWithWebResponse)
async def chat_with_web_agent_response(input_data: ChatWithWebInput) -> Dict[str, Any]:
    """OpenWebUI 등을 통해 chat with web agent만 단독으로 구동해서 사용할 때 사용"""
    try:
        id = int(time.time())
        chat_service = ChatService()
        graph = ChatWithWebAgent(llm=get_model()).get_graph()
        return await chat_service.chat_completions(input_data, id, graph)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/models", response_model=ModelsResponse)
async def list_models() -> ModelsResponse:
    """
    사용 가능한 모델 목록을 반환
    """
    chat_service = ChatService()
    return ModelsResponse(data=chat_service.get_available_models())
