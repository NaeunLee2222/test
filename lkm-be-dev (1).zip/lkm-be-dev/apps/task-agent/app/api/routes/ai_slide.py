from typing import Any, Optional
from fastapi import APIRouter, File, UploadFile
from fastapi.responses import StreamingResponse
from services.ai_slide_service import AiSlideService
from core.log.logging import get_logging
from services.tools.statistic_tool import StatisticTool
from services.tools.websearch_tool import WebSearchTool

logger = get_logging()

router = APIRouter()

ai_slide_service = AiSlideService()
statistic_tool = StatisticTool()
web_search_tool = WebSearchTool()

from pydantic import BaseModel


class ApiResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Any] = None


class AiSlideRequest(BaseModel):
    query: str
    stream: bool = True
    child_id: str = ""


@router.post("/stream")
async def ai_slide(request: AiSlideRequest):

    # import io
    # import pandas as pd
    # from services.tools.temp_get_file import get_file

    # df = get_file()
    try:

        return StreamingResponse(
            ai_slide_service.slide_completions_stream(request.query, request.child_id),
            media_type="text/event-stream",
            # headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
        )
    except Exception as e:
        logger.error(f"Error streaming AI slide: {e}")
        raise e
