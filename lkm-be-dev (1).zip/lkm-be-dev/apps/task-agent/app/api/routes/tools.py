from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from core.log.logging import get_logging
from database.crud.crud_tool import CRUDToolSync
from database.session import get_db
from services.schemas.expert_agent.agent_model import (
    ToolDetail,
    ToolGroupDetail,
    ToolGroupForUpdate,
    UpdateToolGroupRelationship,
)
from services.schemas.expert_agent.response import (
    ApiResponse,
    ToolDetailListResponse,
    ToolGroupListResponse,
    ToolListResponse,
)
from services.schemas.tool.request import (
    MCPToolAddRequest,
    ToolAddRequest,
    ToolDetailUpdateRequest,
    ToolGroupAddRequest,
)

from services.tool_service import ToolService

router = APIRouter(tags=["tools"])


logger = get_logging()
crud_tool = CRUDToolSync()
tool_service = ToolService()


@router.get("/tools", response_model=ToolDetailListResponse)
def get_tools(
    db: Session = Depends(get_db),
    tool_group_id: Optional[int | None] = None,
    tool_name: Optional[str | None] = None,
    tool_id: Optional[int | None] = None,
    is_visible: Optional[bool | None] = None,
) -> ToolDetailListResponse:
    try:
        # tools = crud_tool.get_tools(db, tool_group_id, tool_name, tool_id, is_visible)

        return tool_service.get_tool_list(
            db,
            tool_group_id=tool_group_id,
            tool_name=tool_name,
            tool_id=tool_id,
            is_visible=is_visible,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=500, detail=f"툴 목록 조회 중 오류 발생")


@router.get("/tool/{tool_id}", response_model=ToolDetail)
def get_tool(tool_id: int, db: Session = Depends(get_db)) -> ToolDetail:
    try:
        tool = tool_service.get_tool(db, tool_id)
        return tool
    except HTTPException:
        raise


@router.post("/tool", response_model=ToolDetail)
def add_tool(
    tool_add_request: ToolAddRequest,
    db: Session = Depends(get_db),
) -> ToolDetail:
    try:
        tool = tool_service.add_tool(db, tool_add_request)
        return tool
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding tool: {e}")
        raise HTTPException(status_code=500, detail=f"툴 추가 중 오류 발생")


@router.delete("/tool/{tool_id}", response_model=ApiResponse)
def delete_tool(tool_id: int, db: Session = Depends(get_db)) -> ApiResponse:
    try:
        tool_service.delete_tool(db, tool_id)
        return ApiResponse(success=True, message="툴 삭제 성공")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting tool: {e}")
        raise HTTPException(status_code=500, detail=f"툴 삭제 중 오류 발생")


### 이건 추후에 return 변경 필요
# @router.post("/add/mcp_tool")
# async def save_mcp_tool_bulk(
#     save_mcp_request: MCPToolAddRequest, db: Session = Depends(get_db)
# ):
#     return await crud_tool.save_mcp_tool(
#         db,
#         url=save_mcp_request.url,
#         transport=save_mcp_request.transport,
#         is_visible=save_mcp_request.is_visible,
#     )


@router.post("/tool/mcp-bulk")
async def add_mcp_tool_bulk(
    save_mcp_request: MCPToolAddRequest, db: Session = Depends(get_db)
) -> List[ToolDetail]:
    try:
        return await tool_service.add_mcp_tool_bulk(db, save_mcp_request)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding MCP tools bulk: {e}")
        raise HTTPException(status_code=500, detail=f"MCP 도구 배치 추가 중 오류 발생")


@router.delete("/tool")
async def delete_tool(tool_id: int, db: Session = Depends(get_db)) -> ApiResponse:
    try:
        return await tool_service.delete_tool(db, tool_id)
    except HTTPException:
        raise


@router.post("/tool_group", response_model=ToolGroupDetail)
def add_tool_group(
    tool_group_add_request: ToolGroupAddRequest, db: Session = Depends(get_db)
) -> ToolGroupDetail:
    try:
        tool_group = tool_service.add_tool_group(
            db,
            tool_group=tool_group_add_request,
        )
        return tool_group
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding tool group: {e}")
        raise HTTPException(status_code=500, detail=f"툴 그룹 생성 중 오류 발생")


# @router.post("/add/tool_groups_relationship", response_model=ApiResponse)
# def add_tool_groups_relationship(
#     tool_group_id: int, tool_id: int, db: Session = Depends(get_db)
# ) -> ApiResponse:
#     try:
#         result = crud_tool.register_tool_to_tool_group_by_id(
#             db, tool_group_id=tool_group_id, tool_id=tool_id
#         )
#         return ApiResponse(success=True, message=result["message"])
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(e)
#         raise HTTPException(status_code=500, detail=f"툴 그룹 관계 생성 중 오류 발생")


@router.get("/tool_groups", response_model=ToolGroupListResponse)
def get_tool_groups(db: Session = Depends(get_db)):
    try:
        tool_groups = tool_service.get_tool_groups(db)
        return ToolGroupListResponse(tool_groups=tool_groups)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=500, detail=f"툴 그룹 목록 조회 중 오류 발생")


@router.get("/tool_groups/{tool_group_id}", response_model=List[ToolDetail])
def get_tools_by_tool_group_id(
    tool_group_id: int, db: Session = Depends(get_db)
) -> List[ToolDetail]:
    try:
        tools: List[ToolDetail] = tool_service.get_tools_by_tool_group_id(
            db, tool_group_id=tool_group_id
        )
        return tools
    except HTTPException:
        raise
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=500, detail=f"툴 그룹 목록 조회 중 오류 발생")


# @router.delete(
#     "/tool_group_tool_relationship/{tool_group_tool_relationship_id}",
#     response_model=ApiResponse,
# )
# def delete_tool_group_tool_relationship(
#     tool_group_tool_relationship_id: int, db: Session = Depends(get_db)
# ) -> ApiResponse:
#     try:
#         result = crud_tool.delete_relationship_by_id(
#             db, tool_group_tool_relationship_id
#         )
#         return ApiResponse(success=True, message=result["message"])
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(e)
#         raise HTTPException(status_code=500, detail=f"툴 그룹 관계 삭제 중 오류 발생")


@router.delete("/tool_group/{tool_group_id}", response_model=ApiResponse)
def delete_tool_group(tool_group_id: int, db: Session = Depends(get_db)) -> ApiResponse:
    try:
        tool_service.delete_tool_group(db, tool_group_id)
        return ApiResponse(success=True, message="툴 그룹 삭제 성공")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting tool group: {e}")
        raise HTTPException(status_code=500, detail=f"툴 그룹 삭제 중 오류 발생")


@router.put("/tool/{tool_id}", response_model=ToolDetail)
def update_tool_detail(
    tool_id: int,
    tool_detail_update_request: ToolDetailUpdateRequest,
    db: Session = Depends(get_db),
) -> ToolDetail:
    try:
        tool_detail = tool_service.update_tool(db, tool_id, tool_detail_update_request)
        return tool_detail
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating tool: {e}")
        raise HTTPException(status_code=500, detail=f"툴 상세 수정 중 오류 발생")


@router.put("/update/tool_group", response_model=ToolGroupDetail)
def update_tool_group(
    tool_group_for_update: ToolGroupForUpdate,
    db: Session = Depends(get_db),
) -> ToolGroupDetail:
    try:
        tool_group_detail = tool_service.update_tool_group(db, tool_group_for_update)
        return tool_group_detail
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating tool group: {e}")
        raise HTTPException(status_code=500, detail=f"툴 그룹 수정 중 오류 발생")


@router.put("/update/tool_group_relationship", response_model=ApiResponse)
def update_tool_group_relationship(
    update_tool_group_relationship: UpdateToolGroupRelationship,
    db: Session = Depends(get_db),
) -> ApiResponse:
    try:
        tool_service.update_tool_group_relationship(
            db,
            tool_group_id=update_tool_group_relationship.tool_group_id,
            tool_id=update_tool_group_relationship.tool_id,
        )
        return ApiResponse(success=True, message="툴 그룹 관계 수정 성공")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating tool group relationship: {e}")
        raise HTTPException(status_code=500, detail=f"툴 그룹 관계 수정 중 오류 발생")
