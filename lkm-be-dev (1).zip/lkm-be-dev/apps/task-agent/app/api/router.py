from fastapi import APIRouter

from api.routes import (
    admin,
    agent_studio,
    ai_slide,
    api_spec,
    chat_with_web,
    expert_agent,
    expert_agent_before,
    mcp_info,
    procedure_document,
    tools,
)

api_router = APIRouter()

# 나중에 정해지면 prefix로 agent-studio 붙여도 좋을 것 같습니다.
api_router.include_router(agent_studio.router)
api_router.include_router(procedure_document.router)
api_router.include_router(admin.router, prefix="/admin", tags=["Admin"])
api_router.include_router(api_spec.router, prefix="/api-specs", tags=["ApiSpec"])
api_router.include_router(
    expert_agent.router, prefix="/expert-agent", tags=["ExpertAgent"]
)
api_router.include_router(
    expert_agent_before.router,
    prefix="/expert-agent-before",
    tags=["ExpertAgentBefore"],
)

api_router.include_router(
    chat_with_web.router, prefix="/chat-with-web", tags=["Chat_With_Web"]
)

api_router.include_router(tools.router)
api_router.include_router(mcp_info.router)
api_router.include_router(ai_slide.router, prefix="/ai-slide", tags=["AiSlide"])
