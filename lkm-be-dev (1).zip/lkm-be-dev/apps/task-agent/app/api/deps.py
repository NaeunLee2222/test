from core.config import get_setting

settings = get_setting()

from langchain_openai import AzureChatOpenAI

from services.agent.expert_agent_builder import ExpertAgentBuilder
from services.agent.general_agent_builder import GeneralAgentBuilder


def get_expert_agent_builder():
    llm = AzureChatOpenAI(
        azure_deployment=settings.OPENAI_DEPLOYMENT,
        azure_endpoint=settings.OPENAI_ENDPOINT,
        api_version=settings.OPENAI_API_VERSION,
        api_key=settings.OPENAI_API_KEY,
        model=settings.OPENAI_MODEL,
        temperature=0,
    )
    return ExpertAgentBuilder(llm)


def get_general_agent_builder():
    llm = AzureChatOpenAI(
        azure_deployment=settings.OPENAI_DEPLOYMENT,
        azure_endpoint=settings.OPENAI_ENDPOINT,
        api_version=settings.OPENAI_API_VERSION,
        api_key=settings.OPENAI_API_KEY,
        model=settings.OPENAI_MODEL,
        temperature=0,
    )

    return GeneralAgentBuilder(llm)
