import os
import sys
from typing import Optional

from pydantic import BaseModel, Field

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.tools.factory.api_tool import ApiTool


class DummyArgsSchema(BaseModel):
    userEmail: str = Field(..., description="사용자의 e-mail")
    eventId: str = Field(..., description="이벤트 ID")


class DummyApiTool(ApiTool):
    name: str = "test_tool"
    description: str = "Test tool"
    service_category: str = "test"
    args_schema: type[BaseModel] = DummyArgsSchema
    endpoint: str = "https://api.test.com/users/{userEmail}/events/{eventId}"
    method: str = "PATCH"
    params_schema: Optional[dict] = {
        "userEmail": {
            "type": "string",
            "required": True,
            "description": "사용자의 e-mail",
        },
        "eventId": {"type": "string", "required": True, "description": "이벤트 ID"},
    }


def test_format_endpoint_with_encoded_values() -> None:
    """URL 인코딩된 값들이 올바르게 처리되는지 테스트"""
    tool = DummyApiTool()
    test_cases = [
        # 기본 케이스
        {
            "params": {"userEmail": "test@example.com", "eventId": "simple-id"},
            "expected": "https://api.test.com/users/test%40example.com/events/simple-id",  # @를 %40으로 인코딩
        },
        # 이미 인코딩된 슬래시를 포함한 케이스
        {
            "params": {
                "userEmail": "test@example.com",
                "eventId": "AAMkAGVmMDEzMTM4LTZmYWUtNDdkNC1hMDZiLTU1OGY5OTZhYmY4OAFRAAgI1snaIDaAAEYAAAAA%2FrYQRZI9PE2RnpWJ5UXPKQEAM%2BL9WAAAA%3D",
            },
            "expected": "https://api.test.com/users/test%40example.com/events/AAMkAGVmMDEzMTM4LTZmYWUtNDdkNC1hMDZiLTU1OGY5OTZhYmY4OAFRAAgI1snaIDaAAEYAAAAA%2FrYQRZI9PE2RnpWJ5UXPKQEAM%2BL9WAAAA%3D",
        },
        # 특수문자를 포함한 케이스
        {
            "params": {
                "userEmail": "test+user@example.com",
                "eventId": "test/id with spaces",
            },
            "expected": "https://api.test.com/users/test%2Buser%40example.com/events/test%2Fid%20with%20spaces",
        },
        # 한글을 포함한 케이스
        {
            "params": {"userEmail": "test@example.com", "eventId": "회의/미팅"},
            "expected": "https://api.test.com/users/test%40example.com/events/%ED%9A%8C%EC%9D%98%2F%EB%AF%B8%ED%8C%85",
        },
    ]

    for case in test_cases:
        result = tool._format_endpoint(tool.endpoint, case["params"])
        assert result == case["expected"], (
            f"Failed for params: {case['params']}\nExpected: {case['expected']}\nGot: {result}"
        )
