import httpx

from core.config import get_setting

settings = get_setting()


class ChatDocumentClient:

    def __init__(self):
        if settings.TASK_AGENT_ROUTE == "DEV":
            self.base_url = "http://file-manager:8020"
        else:
            self.base_url = "http://localhost:8020"

    async def get_document_state(self, doc_id: int):
        url = f"{self.base_url}/file-manager/chat_documents/document/{doc_id}/state"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            if response.status_code == 200:
                return response.json()
            else:
                return {}

    async def vector_search(self, chat_id: str, query: str, n: int = 5):
        url = f"{self.base_url}/file-manager/chat_documents/{chat_id}/search"
        async with httpx.AsyncClient() as client:
            response = await client.get(url, params={"query": query, "n": n})
            if response.status_code == 200:
                return response.json()
            else:
                return []

    async def vector_search_by_doc_id(self, doc_id: int, query: str, n: int = 5):
        """특정 문서 ID로 vector search를 수행합니다."""
        url = f"{self.base_url}/file-manager/chat_documents/document/{doc_id}/search"
        async with httpx.AsyncClient() as client:
            response = await client.get(url, params={"query": query, "n": n})
            if response.status_code == 200:
                return response.json()
            else:
                return []

    async def get_chat_documents(self, chat_id: str):
        url = f"{self.base_url}/file-manager/chat_documents/{chat_id}"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            if response.status_code == 200:
                return response.json()
            else:
                return {}

    async def get_chat_documents_summary(self, chat_id: str):
        url = f"{self.base_url}/file-manager/chat_documents/{chat_id}/summary"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            if response.status_code == 200:
                result = response.json()

                # doc_id: 내용 형태의 리스트로 변환
                summary_list = []
                for doc_id, content in result.items():
                    summary_list.append({"id": doc_id, "summary": content})
                return summary_list
            else:
                return []
