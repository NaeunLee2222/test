from langchain_mcp_adapters.client import MultiServerMCPClient


class McpMindmapClient:
    def __init__(self):
        self.client = MultiServerMCPClient(
            {
                "mindmap": {
                    "transport": "streamable_http",
                    "url": "http://20.39.194.194:8050/mindmap/mcp",
                },
            }
        )

    async def create_mindmap(self, query: str):
        tools = await self.client.get_tools()
        mindmap_tool = None
        for tool in tools:
            if tool.name == "generate_mindmap":
                mindmap_tool = tool
                break

        mindmap_response = await mindmap_tool.ainvoke({"query": query})
        return mindmap_response
