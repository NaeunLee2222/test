import httpx

from core.config import get_setting

settings = get_setting()


class AgentDocumentClient:
    def __init__(self):
        if settings.TASK_AGENT_ROUTE == "DEV":
            self.base_url = "http://file-manager:8020"
        else:
            self.base_url = "http://localhost:8020"

    async def get_agent_document_state(self, agent_id: int):
        url = f"{self.base_url}/file-manager/agent_documents/document/{agent_id}/state"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            if response.status_code == 200:
                return response.json()
            else:
                return []

    async def vector_search(self, agent_id: int, query: str, n: int = 5):
        url = f"{self.base_url}/file-manager/agent_documents/{agent_id}/search"
        async with httpx.AsyncClient() as client:
            response = await client.get(url, params={"query": query, "n": n})
            if response.status_code == 200:
                return response.json()
            else:
                return []

    async def vector_search_by_doc_id(self, doc_id: int, query: str, n: int = 5):
        """특정 문서 ID로 vector search를 수행합니다."""
        url = f"{self.base_url}/file-manager/agent_documents/document/{doc_id}/search"
        async with httpx.AsyncClient() as client:
            response = await client.get(url, params={"query": query, "n": n})
            if response.status_code == 200:
                return response.json()
            else:
                return []

    async def get_agent_documents(self, agent_id: int):
        url = f"{self.base_url}/file-manager/agent_documents/{agent_id}"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            if response.status_code == 200:
                return response.json()
            else:
                return []

    async def get_agent_documents_summary(self, agent_id: int):
        url = f"{self.base_url}/file-manager/agent_documents/{agent_id}/summary"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            if response.status_code == 200:
                result = response.json()

                summary_list = []
                for doc_id, content in result.items():
                    summary_list.append({"id": doc_id, "summary": content})
                return summary_list
            else:
                return []
