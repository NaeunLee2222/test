import logging

import aiohttp

from core.config import get_setting

settings = get_setting()
logger = logging.getLogger(__name__)


class CanvasCreateClient:
    def __init__(self):
        if settings.TASK_AGENT_ROUTE == "DEV":
            self.base_url = "http://ai-chat:8010/ai-chat"
        else:
            self.base_url = "http://localhost:8010/ai-chat"

    async def create_canvas(
        self,
        chat_id: str,
        title: str,
        content: str,
        file_extension: str = "html",
        canvas_type: str = "canvas",
        version: int = 1,
    ):
        """Canvas API를 호출하여 새로운 캔버스를 생성합니다."""
        uuid = ""
        try:
            canvas_data = {
                "chat_id": chat_id,
                "title": title,
                "content": content,
                "file_extension": file_extension,
                "type": canvas_type,
                "version": version,
            }

            canvas_url = f"{self.base_url}/canvas"

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    canvas_url,
                    json=canvas_data,
                ) as response_client:
                    response_client_data = await response_client.json()
                    print(f"Canvas API 응답: {response_client_data}")
                    if response_client.status == 200:
                        if "uuid" in response_client_data:
                            uuid = response_client_data["uuid"]
        except Exception as e:
            print(f"Canvas API 호출 중 예외 발생: {str(e)}")
            logger.error(f"[CanvasCreateClient] Canvas API error: {str(e)}")
            return ""

        return uuid

    async def delete_canvas(self, canvas_uuid: str):
        """Canvas API를 호출하여 캔버스를 삭제합니다."""
        try:
            canvas_url = f"{self.base_url}/canvas/{canvas_uuid}"

            async with aiohttp.ClientSession() as session:
                async with session.delete(
                    canvas_url,
                ) as response_client:
                    response_client_data = await response_client.json()
                    print(f"Canvas API 응답: {response_client_data}")
                    if response_client.status == 200:
                        return True
        except Exception as e:
            print(f"Canvas API 호출 중 예외 발생: {str(e)}")
            logger.error(f"[CanvasCreateClient] Canvas API error: {str(e)}")
            return ""

        return False
