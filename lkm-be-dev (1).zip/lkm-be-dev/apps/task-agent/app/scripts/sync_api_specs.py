import json
import os
import sys
from typing import List

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from core.config import get_setting
from core.log.logging import get_logging
from database.crud.crud_api_spec import CRUDApiSpec
from database.models.api_spec.api_spec import ApiSpec
from database.session import get_db

logger = get_logging()
settings = get_setting()

# env: LOCAL, DEV, STG, ROD
API_SPECS = {
    "COMMON": {
        "ALL": [
            "/app/core/settings/schedule_api_spec.json",
            "/app/core/settings/todo_api_spec.json",
        ]
    },
    "SKCC": {"ALL": ["/app/core/settings/skcc_meeting_room_api_spec.json"]},
    "SKT": {
        "LOCAL": ["/app/core/settings/skt_dev_meeting_room_api_spec.json"],
        "DEV": ["/app/core/settings/skt_dev_meeting_room_api_spec.json"],
        "STG": ["/app/core/settings/skt_prd_meeting_room_api_spec.json"],
        "PROD": ["/app/core/settings/skt_prd_meeting_room_api_spec.json"],
    },
}


def get_api_specs(json_paths: List[str]) -> List[ApiSpec]:
    api_specs: List[ApiSpec] = []
    for json_path in json_paths:
        with open(json_path, "r") as f:
            specs = json.load(f)
        api_specs.extend(specs)

    if not api_specs:
        raise ValueError("API specs list is empty")

    # 개발 환경 엔드포인트 수정
    if settings.ENVIRONMENT == "LOCAL":
        for spec in api_specs:
            if (
                "endpoint" in spec
                and "meetingroomifdev.sktelecom.com" in spec["endpoint"]
            ):
                spec["endpoint"] = spec["endpoint"].replace(
                    "meetingroomifdev.sktelecom.com",
                    f"host.docker.internal:{settings.SIMULATOR_APP_PORT}",
                )

    return api_specs


def get_api_paths(company: str) -> List[str]:
    api_paths: List[str] = []
    if "ALL" in API_SPECS[company]:
        api_paths.extend(API_SPECS[company]["ALL"])

    env = settings.ENVIRONMENT
    if env in API_SPECS[company]:
        api_paths.extend(API_SPECS[company][env])

    return api_paths


def sync_api_specs() -> None:
    """API specs 동기화"""
    db = next(get_db())
    try:
        api_specs_json_paths: List[str] = []
        api_specs_json_paths.extend(get_api_paths("COMMON"))
        api_specs_json_paths.extend(get_api_paths(settings.COMPANY))

        api_specs = get_api_specs(api_specs_json_paths)

        crud_api_spec = CRUDApiSpec()
        crud_api_spec.bulk_upsert(db, api_specs)

    except Exception as e:
        logger.error(f"Failed to sync api specs: {e}")
        raise
    finally:
        db.close()


def main() -> None:
    try:
        sync_api_specs()
        print("Successfully synced api specs")
    except Exception as e:
        print(f"Error syncing api specs: {e}")
        exit(1)


if __name__ == "__main__":
    main()
