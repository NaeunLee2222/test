import inspect
from typing import Dict, List

from sqlalchemy.orm import Session

from core.log.logging import get_logging
from core.prompts import templates
from database.crud.crud_prompt import CRUDPrompt
from database.models.prompt.prompt import Prompt
from database.session import get_db

logger = get_logging()


def register_prompts_to_db(db: Session) -> List[Prompt]:
    """DB에 Prompts 등록"""

    # templates 모듈의 모든 문자열 속성 가져오기
    prompt_templates: Dict[str, str] = {
        name: value
        for name, value in inspect.getmembers(
            templates, lambda a: not inspect.isroutine(a)
        )
        if not name.startswith("__") and isinstance(value, str)
    }

    if not prompt_templates:
        raise ValueError("Prompts list is empty")

    prompts: List[dict] = []

    for name, text in prompt_templates.items():
        prompts.append({"prompt_name": name, "prompt_text": text})

    crud_prompt = CRUDPrompt()
    return crud_prompt.bulk_upsert(db, prompts)


def sync_prompts() -> List[Prompt]:
    """프롬프트 동기화"""
    db = next(get_db())
    try:
        register_prompts_to_db(db)
    except Exception as e:
        logger.error(f"Failed to sync prompts: {e}")
        raise
    finally:
        db.close()


def main() -> None:
    try:
        sync_prompts()
        print("Successfully synced prompts")
    except Exception as e:
        print(f"Error syncing prompts: {e}")
        exit(1)


if __name__ == "__main__":
    main()
