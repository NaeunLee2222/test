import os
import sys
from typing import List

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.log.logging import get_logging
from database.crud.crud_dynamic_prompt import (
    CRUDDynamicPrompt,
    CRUDDynamicPromptCondition,
    CRUDDynamicPromptSnippet,
)
from database.models.prompt.dynamic_prompt import DynamicPrompt
from database.session import get_db

logger = get_logging()


def sync_dynamic_prompts() -> List[DynamicPrompt]:
    """동적 프롬프트 동기화"""
    db = next(get_db())
    try:
        crud_condition = CRUDDynamicPromptCondition()
        crud_snippet = CRUDDynamicPromptSnippet()
        crud_dynamic_prompt = CRUDDynamicPrompt()

        logger.info("Starting dynamic prompts sync")

        # 참조되는 테이블 데이터 먼저 동기화
        logger.info("Syncing conditions and snippets")
        crud_condition.sync_from_json(db)
        crud_snippet.sync_from_json(db)

        # DynamicPrompt 데이터 동기화
        logger.info("Syncing dynamic prompts")
        prompts = crud_dynamic_prompt.sync_from_json(db)

        logger.info("Successfully completed dynamic prompts sync")
        return prompts
    except Exception as e:
        logger.error(f"Failed to sync dynamic prompts: {e}")
        raise
    finally:
        db.close()


def main() -> None:
    try:
        sync_dynamic_prompts()
        print("Successfully synced dynamic prompts")
    except Exception as e:
        print(f"Error syncing dynamic prompts: {e}")
        exit(1)


if __name__ == "__main__":
    main()
