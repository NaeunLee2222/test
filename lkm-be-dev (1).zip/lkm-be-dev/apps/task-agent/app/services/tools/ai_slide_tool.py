import json
from typing import Any, AsyncGenerator, Dict, List, Optional
from fastapi import HTTPException
from core.errors.exceptions import ServiceException

from langchain.tools import BaseTool
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableConfig
from pydantic import BaseModel, Field
from client.canvas_create_client import CanvasCreateClient
from core.llm import get_model
from core.log.logging import get_logging
from services.prompt.ai_slide_prompt import (
    CONTENTS_LIST_SLIDE_PROMPT,
    CONTENTS_SLIDE_PROMPT,
    FINAL_SLIDE_PROMPT,
    SYSTEM_PROMPT,
    TITLE_SLIDE_PROMPT,
    _create_slide_prompts,
)

logger = get_logging()


class ArgsSchema(BaseModel):
    report_content: str = Field(..., description="프레젠테이션으로 변환할 보고서 내용")
    primary_color: str = Field(default="#005BAC", description="PPT의 기본 색상")
    accent_color: str = Field(default="#E60012", description="PPT의 강조 색상")
    session_id: str = Field(default="", description="세션 ID (백엔드 추적용)")
    config: Optional[RunnableConfig] = Field(
        default=None, description="Runnable 설정 (이벤트 스트리밍용)"
    )


class Config:
    arbitrary_types_allowed = True  # 임의 타입 허용


content_theme_mapping = {
    "tech": {
        "keywords": ["ai", "인공지능", "digital", "디지털", "tech", "기술"],
        "theme": {
            "theme": "tech",
            "background_pattern": "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)",
            "visual_style": "네온 액센트, 회로 패턴, 미래적 디자인",
        },
    },
    "corporate": {
        "keywords": ["business", "비즈니스", "corporate", "기업", "경영"],
        "theme": {
            "theme": "corporate",
            "background_pattern": "linear-gradient(135deg, #1e40af 0%, #1e3a8a 50%, #1e293b 100%)",
            "visual_style": "전문적인 블루, 깔끔한 그라데이션",
        },
    },
    "medical": {
        "keywords": ["medical", "의료", "health", "hospital", "medicine"],
        "theme": {
            "theme": "medical",
            "background_pattern": "linear-gradient(135deg, #f8fafc 0%, #e0f2fe 50%, #b3e5fc 100%)",
            "visual_style": "깔끔한 화이트/블루, 의료 테마",
        },
    },
    "finance": {
        "keywords": ["finance", "금융", "investment", "투자"],
        "theme": {
            "theme": "finance",
            "background_pattern": "linear-gradient(135deg, #065f46 0%, #047857 50%, #10b981 100%)",
            "visual_style": "보수적인 그린, 전문적 스타일링",
        },
    },
}


class Report2PPTStreamingTool(BaseTool):
    """실시간 스트리밍으로 보고서를 프레젠테이션으로 변환하는 Langchain Tool"""

    name: str = "report_to_presentation_streaming"
    description: str = (
        "입력된 보고서 내용을 기반으로 실시간 스트리밍으로 프레젠테이션을 생성하고 백엔드 서버로 전송합니다."
    )

    def __init__(self):
        super().__init__()

    def _run(self, **kwargs) -> str:
        """동기 실행은 지원하지 않음"""
        raise NotImplementedError("이 툴은 비동기 실행만 지원합니다.")

    @staticmethod
    def _split_text_intelligently(text: str, num_sections: int) -> List[str]:
        """텍스트를 목차 수에 맞게 지능적으로 분할"""
        total_length = len(text)
        chunk_size = max(1000, total_length // num_sections)

        chunks = []
        for i in range(num_sections):
            start = i * chunk_size
            end = min((i + 1) * chunk_size, total_length)
            chunks.append(text[start:end])

        return chunks

    @staticmethod
    def _analyze_content_for_chart_selection(content: str) -> Dict[str, Any]:
        """내용 분석을 통한 최적 차트 타입 및 레이아웃 결정 (4가지 차트만 사용)"""
        content_lower = content.lower()
        allowed_charts = ["line", "bar", "pie", "doughnut"]
        chart_recommendations = []
        layout_pattern = "좌우 분할"

        # 시계열 데이터 → 꺾은선 그래프
        time_keywords = [
            "년도",
            "연도",
            "월별",
            "분기",
            "시간",
            "추세",
            "변화",
            "성장",
            "증가",
            "감소",
        ]
        if any(keyword in content_lower for keyword in time_keywords):
            chart_recommendations.append("line")
            layout_pattern = "상하 분할"

        # 비교 데이터 → 막대 그래프
        comparison_keywords = [
            "비교",
            "대비",
            "vs",
            "차이",
            "순위",
            "랭킹",
            "상위",
            "하위",
        ]
        if any(keyword in content_lower for keyword in comparison_keywords):
            chart_recommendations.append("bar")
            layout_pattern = "좌우 분할"

        # 구성/비율 데이터 → 원형/도넛 그래프
        ratio_keywords = ["비율", "점유율", "구성", "분포", "할당", "%", "퍼센트"]
        if any(keyword in content_lower for keyword in ratio_keywords):
            chart_recommendations.extend(["pie", "doughnut"])
            layout_pattern = "중앙 집중"

        # 분포/빈도 데이터 → 막대 그래프
        distribution_keywords = ["분포", "빈도", "히스토그램", "구간", "범위"]
        if any(keyword in content_lower for keyword in distribution_keywords):
            chart_recommendations.append("bar")
            layout_pattern = "좌우 분할"

        # 성과/지표 데이터 → 막대 그래프
        performance_keywords = ["성과", "kpi", "지표", "목표", "달성", "효율", "생산성"]
        if any(keyword in content_lower for keyword in performance_keywords):
            chart_recommendations.append("bar")
            layout_pattern = "대시보드"

        # 프로세스/단계 데이터 → 꺾은선/막대 그래프
        process_keywords = ["단계", "프로세스", "절차", "과정", "순서", "플로우"]
        if any(keyword in content_lower for keyword in process_keywords):
            chart_recommendations.extend(["line", "bar"])
            layout_pattern = "타임라인"

        # 기본값 설정
        if not chart_recommendations:
            chart_recommendations = ["bar", "line"]

        # 허용된 차트만 필터링하고 중복 제거
        chart_recommendations = [
            chart for chart in chart_recommendations if chart in allowed_charts
        ]
        chart_recommendations = list(set(chart_recommendations))[:2]

        if not chart_recommendations:
            chart_recommendations = ["bar"]

        return {
            "primary_chart": chart_recommendations[0],
            "secondary_charts": chart_recommendations[1:],
            "layout_pattern": layout_pattern,
            "chart_count": min(len(chart_recommendations), 2),
        }

    @staticmethod
    def _determine_enhanced_slide_type(content: str, title: str) -> str:
        """내용과 제목을 분석하여 향상된 슬라이드 타입 결정"""
        content_lower = content.lower()
        title_lower = title.lower()

        # SWOT 분석 키워드
        swot_keywords = ["swot", "강점", "약점", "기회", "위협"]
        if any(keyword in content_lower + title_lower for keyword in swot_keywords):
            return "SWOT 분석 (4분할 카드 레이아웃)"

        # 프로세스 관련 키워드
        process_keywords = ["프로세스", "단계", "절차", "과정", "로드맵"]
        if any(keyword in content_lower + title_lower for keyword in process_keywords):
            return "프로세스 타임라인 (단계별 플로우)"

        # 일정/계획 관련 키워드
        schedule_keywords = ["일정", "계획", "스케줄"]
        if any(keyword in content_lower + title_lower for keyword in schedule_keywords):
            return "로드맵/간트 차트 (Chart.js)"

        # 데이터 분석 관련 키워드
        data_keywords = ["데이터", "수치", "통계", "비율", "분석"]
        if any(keyword in content_lower + title_lower for keyword in data_keywords):
            return "데이터 시각화 (차트와 인포그래픽)"

        # 비교 분석 관련 키워드
        comparison_keywords = ["비교", "벤치마킹", "대비"]
        if any(
            keyword in content_lower + title_lower for keyword in comparison_keywords
        ):
            return "비교 분석 (테이블과 차트 조합)"

        # 결론/요약 관련 키워드
        conclusion_keywords = ["결론", "요약", "정리"]
        if any(
            keyword in content_lower + title_lower for keyword in conclusion_keywords
        ):
            return "결론 요약 (핵심 포인트 카드)"

        # 기본값
        return "핵심 포인트 (아이콘 기반 레이아웃)"

    @staticmethod
    def _analyze_content_theme(content: str) -> Dict[str, Any]:
        """콘텐츠 테마 분석"""
        content_lower = content.lower()
        for _, data in content_theme_mapping.items():
            if any(keyword in content_lower for keyword in data["keywords"]):
                return data["theme"]
        return content_theme_mapping["corporate"]["theme"]

    @staticmethod
    def _style_vars(
        primary_color: str, accent_color: str, theme: Dict[str, Any]
    ) -> str:
        return f"""
        PRIMARY_COLOR: {primary_color}
        ACCENT_COLOR: {accent_color}
        THEME: {theme['theme']}
        BACKGROUND_PATTERN: {theme['background_pattern']}
        VISUAL_STYLE: {theme['visual_style']}
        """

    async def stream_slides(
        self,
        query: str,
        report: str,
        agenda_items: List[str],
        primary_color: str,
        accent_color: str,
        statistic_result: Optional[str] = None,
        chat_id: str = "",
        **kwargs,
    ) -> AsyncGenerator[Optional[Dict[str, Any]], None]:
        """실시간 스트리밍으로 슬라이드를 생성하는 제너레이터"""
        start_statement = {
            "type": "STEP_START",
            "content": None,
            "description": "프레젠테이션 생성을 시작합니다.",
            "key": "",
            "id": chat_id,
        }
        end_statement = {
            "type": "STEP_END",
            "content": None,
            "description": "프레젠테이션 생성 완료",
            "key": "",
            "id": chat_id,
        }

        try:
            # 초기 설정 및 프롬프트 생성
            try:
                report += statistic_result if statistic_result else ""

                theme = self._analyze_content_theme(report)
                style_vars = self._style_vars(primary_color, accent_color, theme)

                # 레이아웃 패턴 순환 리스트
                layout_patterns = [
                    "좌우 분할",
                    "상하 분할",
                    "격자형",
                    "중앙 집중",
                    "타임라인",
                    "대시보드",
                ]
                slide_prompts = [
                    TITLE_SLIDE_PROMPT.format(
                        report=report[:2000], style_vars=style_vars
                    ),
                ]
                agenda_list = "\n".join(
                    [f"{i+1}. {item}" for i, item in enumerate(agenda_items)]
                )
                slide_prompts.append(
                    CONTENTS_LIST_SLIDE_PROMPT.format(
                        agenda_list=agenda_list, style_vars=style_vars
                    )
                )

                text_chunks = self._split_text_intelligently(report, len(agenda_items))
                for i, (agenda_item, chunk) in enumerate(
                    zip(agenda_items, text_chunks), 3
                ):
                    # 내용 기반 차트 및 레이아웃 분석
                    chart_analysis = self._analyze_content_for_chart_selection(chunk)
                    slide_type = self._determine_enhanced_slide_type(chunk, agenda_item)

                    # 레이아웃 패턴 순환 적용
                    layout_pattern = layout_patterns[(i - 3) % len(layout_patterns)]

                    slide_prompts.append(
                        CONTENTS_SLIDE_PROMPT.format(
                            i=i,
                            agenda_item=agenda_item,
                            slide_type=slide_type,
                            chunk=chunk,
                            style_vars=style_vars,
                            chart_analysis_primary_chart=chart_analysis[
                                "primary_chart"
                            ],
                            chart_analysis_secondary_charts=", ".join(
                                chart_analysis["secondary_charts"]
                            ),
                            chart_analysis_chart_count=chart_analysis["chart_count"],
                            layout_pattern=layout_pattern,
                        )
                    )

                final_slide_num = len(slide_prompts) + 1
                final_layout = layout_patterns[
                    (final_slide_num - 3) % len(layout_patterns)
                ]

                slide_prompts.append(
                    FINAL_SLIDE_PROMPT.format(
                        report=report[-2000:],
                        agenda_list=agenda_list,
                        style_vars=style_vars,
                        final_layout=final_layout,
                        final_slide_num=final_slide_num,
                    )
                )

                system_prompt = SYSTEM_PROMPT.replace(
                    "{{primary_color}}", primary_color
                ).replace("{{accent_color}}", accent_color)

                model = get_model(user_id="1360")
                parser = StrOutputParser()

                logger.info(
                    f"슬라이드 생성 초기화 완료 - 총 {len(slide_prompts)}개 슬라이드 예정"
                )

            except Exception as e:
                logger.error(f"슬라이드 생성 초기화 실패: {e}", exc_info=True)
                error_statement = {
                    "type": "ERROR",
                    "content": f"슬라이드 생성 초기화 실패: {str(e)}",
                    "description": "프레젠테이션 초기 설정 중 오류 발생",
                    "key": "initialization_error",
                    "id": chat_id,
                    "step": "initialization",
                    "slide_number": 0,
                }
                yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"

            else:
                # 초기화가 성공한 경우에만 슬라이드 생성 진행
                yield f"data: {json.dumps(start_statement, ensure_ascii=False)}\n\n"
                from time import time

                canvas_create_client = CanvasCreateClient()

                for i, slide_prompt in enumerate(slide_prompts, 1):
                    start_time = time()

                    try:
                        # 1. 프롬프트 생성 단계
                        try:
                            prompt = ChatPromptTemplate.from_messages(
                                [
                                    (
                                        "system",
                                        system_prompt.replace("{", "{{").replace(
                                            "}", "}}"
                                        ),
                                    ),
                                    ("user", slide_prompt),
                                ]
                            )
                            logger.info(f"[slide {i}] 프롬프트 생성 완료")
                        except Exception as e:
                            logger.error(
                                f"[slide {i}] 프롬프트 생성 실패: {e}", exc_info=True
                            )
                            error_statement = {
                                "type": "ERROR",
                                "content": f"프롬프트 생성 실패: {str(e)}",
                                "description": f"슬라이드 {i} 프롬프트 생성 중 오류 발생",
                                "key": "prompt_generation_error",
                                "id": chat_id,
                                "step": "prompt_generation",
                                "slide_number": i,
                            }
                            yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"
                            break

                        # 2. LLM 체인 생성 및 실행 단계
                        try:
                            chain = prompt | model | parser
                            stream = chain.astream_events(
                                {"input": slide_prompt}, version="v1"
                            )
                            content = ""

                            async for event in stream:
                                if event["event"] == "on_chat_model_stream":
                                    chunk = event["data"]["chunk"]
                                    if hasattr(chunk, "content") and chunk.content:
                                        content += chunk.content

                            slides = _parse_slides(content)
                            logger.info(f"[slide {i}] First generation done")

                            if not slides or len(slides) == 0:
                                raise ValueError("슬라이드 파싱 결과가 비어있습니다")

                            slide_content = slides[0]["html"]

                        except HTTPException as e:
                            logger.error(
                                f"[slide {i}] LLM 체인 HTTPException: {e.detail}",
                                exc_info=True,
                            )
                            error_statement = {
                                "type": "ERROR",
                                "content": f"LLM HTTP 오류: {e.detail}",
                                "description": f"슬라이드 {i} LLM 처리 중 HTTP 오류 발생",
                                "key": "llm_http_error",
                                "id": chat_id,
                                "step": "llm_generation",
                                "slide_number": i,
                            }
                            yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"
                            raise e

                        except Exception as e:
                            logger.error(
                                f"[slide {i}] LLM 체인 기타 오류: {e}", exc_info=True
                            )
                            error_statement = {
                                "type": "ERROR",
                                "content": f"LLM 기타 오류: {str(e)}",
                                "description": f"슬라이드 {i} LLM 처리 중 예상치 못한 오류 발생",
                                "key": "llm_unexpected_error",
                                "id": chat_id,
                                "step": "llm_generation",
                                "slide_number": i,
                            }
                            yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"
                            raise e

                        # 3. Validation 단계
                        try:
                            from services.tools.react_agent_for_slide import (
                                OverallScoreCalculator,
                            )

                            validator = OverallScoreCalculator()
                            validation = validator._run(slide_content)
                            logger.info(f"[slide {i}] Validation 완료")
                        except Exception as e:
                            logger.error(
                                f"[slide {i}] Validation 오류: {e}", exc_info=True
                            )
                            error_statement = {
                                "type": "ERROR",
                                "content": f"Validation 오류: {str(e)}",
                                "description": f"슬라이드 {i} 검증 중 오류 발생",
                                "key": "validation_error",
                                "id": chat_id,
                                "step": "validation",
                                "slide_number": i,
                            }
                            yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"
                            break

                        # 4. Validation LLM 보정 단계
                        try:
                            validation_model = get_model(user_id="1360")
                            validation_prompt = ChatPromptTemplate.from_messages(
                                [
                                    (
                                        "system",
                                        "You are a helpful assistant that corrects HTML slides. You will correct the HTML slide to meet the user's request and return the corrected HTML slide.",
                                    ),
                                    (
                                        "user",
                                        """
                            Here is the HTML slide:
                            {html_content}

                            Here is the validation results:
                            {validation_results}

                            Here is the user's request:
                            {user_request}

                            Please correct the HTML slide and return the corrected HTML slide.
                            """,
                                    ),
                                ]
                            )

                            parser = StrOutputParser()
                            validation_chain = (
                                validation_prompt | validation_model | parser
                            )

                            # invoke 호출
                            result = validation_chain.invoke(
                                {
                                    "html_content": slide_content,
                                    "validation_results": validation,
                                    "user_request": slide_prompt,
                                }
                            )
                            slides = _parse_slides(result)

                            if not slides or len(slides) == 0:
                                logger.warning(
                                    f"[slide {i}] Validation LLM 파싱 실패, 원본 슬라이드 사용"
                                )
                                # 원본 슬라이드 사용
                            else:
                                slide_content = slides[0]["html"]

                            logger.info(f"[slide {i}] Validation LLM 보정 완료")

                        except HTTPException as e:
                            logger.error(
                                f"[slide {i}] Validation LLM HTTPException: {e.detail}",
                                exc_info=True,
                            )
                            error_statement = {
                                "type": "ERROR",
                                "content": f"Validation LLM HTTP 오류: {e.detail}",
                                "description": f"슬라이드 {i} 검증 LLM 처리 중 HTTP 오류 발생",
                                "key": "validation_llm_http_error",
                                "id": chat_id,
                                "step": "validation_llm",
                                "slide_number": i,
                            }
                            yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"
                            raise e
                        except Exception as e:
                            logger.error(
                                f"[slide {i}] Validation LLM 기타 오류: {e}",
                                exc_info=True,
                            )
                            error_statement = {
                                "type": "ERROR",
                                "content": f"Validation LLM 기타 오류: {str(e)}",
                                "description": f"슬라이드 {i} 검증 LLM 처리 중 예상치 못한 오류 발생",
                                "key": "validation_llm_unexpected_error",
                                "id": chat_id,
                                "step": "validation_llm",
                                "slide_number": i,
                            }
                            yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"
                            raise e

                        # 5. 정상 결과 전송
                        progress_statement = {
                            "type": "AI_SLIDE",
                            "content": slide_content,
                            "description": "슬라이드 생성 중",
                            "key": "",
                            "id": chat_id,
                            "title": "프레젠테이션",
                        }
                        yield f"data: {json.dumps(progress_statement, ensure_ascii=False)}\n\n"
                        title = (
                            f"{query[:90]}...-{i}"
                            if len(query) > 90
                            else f"{query}-{i}"
                        )
                        uuid = await canvas_create_client.create_canvas(
                            chat_id=chat_id,
                            title=title,
                            content=slide_content,
                            canvas_type="ai_slide",
                        )
                        end_time = time()
                        logger.info(f"uuid: {uuid}")
                        logger.info(
                            f"[slide {i}] 완료 - 소요시간: {end_time - start_time:.2f}초"
                        )

                    except Exception as e:
                        # 최상위 예외 처리 - 예상치 못한 모든 오류
                        logger.error(
                            f"[slide {i}] 최상위 예외 발생: {e}", exc_info=True
                        )
                        error_statement = {
                            "type": "ERROR",
                            "content": f"슬라이드 생성 중 예상치 못한 오류: {str(e)}",
                            "description": f"슬라이드 {i} 생성 중 시스템 오류 발생",
                            "key": "system_error",
                            "id": chat_id,
                            "step": "unknown",
                            "slide_number": i,
                        }
                        yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"
                        break

                yield f"data: {json.dumps(end_statement, ensure_ascii=False)}\n\n"

        except Exception as e:
            # 함수 전체 최상위 예외 처리
            logger.error(f"stream_slides 함수 전체 예외 발생: {e}", exc_info=True)
            error_statement = {
                "type": "ERROR",
                "content": f"프레젠테이션 생성 중 시스템 오류: {str(e)}",
                "description": "프레젠테이션 생성 시스템에서 예상치 못한 오류가 발생했습니다",
                "key": "system_critical_error",
                "id": chat_id,
                "step": "system",
                "slide_number": 0,
            }
            yield f"data: {json.dumps(error_statement, ensure_ascii=False)}\n\n"

    async def slides(
        self,
        text: str,
        primary_color: str,
        accent_color: str,
        **kwargs,
    ) -> List[Dict[str, Any]]:
        """슬라이드를 생성하는 제너레이터"""
        result = []

        system_prompt = SYSTEM_PROMPT.format(
            primary_hex=primary_color, accent_hex=accent_color
        )
        slide_prompts = _create_slide_prompts(text, primary_color, accent_color)
        prompt = ChatPromptTemplate.from_template(system_prompt + "\n\nUser: {input}")

        parser = StrOutputParser()
        # with disable_ssl_verification():
        model = get_model(user_id="1360")

        for i, slide_prompt in enumerate(slide_prompts, 1):
            chain = prompt | model | parser
            chain.invoke({"input": slide_prompt})
            result.append(
                {
                    "slide_number": i,
                    "content": chain.output,
                }
            )

        return result


def _parse_slides(full_text: str) -> List[Dict[str, Any]]:
    """개선된 슬라이드 파싱: 다양한 형식의 응답을 처리"""
    slides = []
    current_slide = None
    current_thinking = None
    current_code = None
    in_code_block = False

    lines = full_text.split("\n")
    i = 0

    logger.info(
        f"파싱 시작 - 전체 텍스트 길이: {len(full_text)}, 라인 수: {len(lines)}"
    )

    while i < len(lines):
        line = lines[i].strip()

        # 슬라이드 시작 감지 (더 유연한 패턴)
        if (
            line.startswith("### Slide")
            or line.startswith("## Slide")
            or line.startswith("# Slide")
            or (
                "Slide" in line
                and any(char in line for char in [str(i) for i in range(1, 10)])
            )
        ):
            # 이전 슬라이드 저장
            if current_slide and current_code:
                slide_data = {
                    "title": current_slide,
                    "thinking": (
                        current_thinking
                        if current_thinking
                        else "향상된 슬라이드 생성됨"
                    ),
                    "html": current_code.strip(),
                }
                slides.append(slide_data)
                logger.info(f"슬라이드 파싱 완료: {current_slide}")

            # 새 슬라이드 시작
            current_slide = (
                line.replace("###", "").replace("##", "").replace("#", "").strip()
            )
            current_thinking = None
            current_code = None
            in_code_block = False
            logger.info(f"새 슬라이드 시작: {current_slide}")

        # thinking 감지 (더 유연한 패턴)
        elif (
            line.startswith("**thinking**:")
            or line.startswith("**thinking**")
            or line.startswith("thinking:")
            or "thinking" in line.lower()
        ):
            current_thinking = (
                line.replace("**thinking**:", "")
                .replace("**thinking**", "")
                .replace("thinking:", "")
                .replace("**", "")
                .strip()
            )
            logger.debug(f"thinking 발견: {current_thinking[:100]}...")

        # HTML 코드 블록 시작 감지 (개선된 패턴)
        elif (
            line.startswith("```html")
            or line.startswith("```HTML")
            or line.startswith("**code**:")
            or line.startswith("<!DOCTYPE html")
        ):
            in_code_block = True
            current_code = ""
            if line.startswith("<!DOCTYPE html"):
                current_code = line + "\n"
            logger.debug(f"HTML 코드 블록 시작 감지: {line[:50]}...")

        # 일반 코드 블록 (```만) 처리 - HTML인지 확인
        elif line.startswith("```") and not in_code_block:
            # 다음 몇 줄을 미리 확인해서 HTML인지 판단
            for j in range(i + 1, min(i + 5, len(lines))):
                if j < len(lines) and "<!DOCTYPE html" in lines[j]:
                    in_code_block = True
                    current_code = ""
                    logger.debug(f"HTML 감지된 일반 코드 블록 시작: {line}")
                    break

        # 코드 블록 끝
        elif line.startswith("```") and in_code_block:
            in_code_block = False
            logger.debug("HTML 코드 블록 종료")

        # HTML이 직접 시작되는 경우 (코드 블록 없이)
        elif line.startswith("<!DOCTYPE html") and not in_code_block:
            in_code_block = True
            current_code = line + "\n"
            logger.debug("HTML 직접 시작 감지 (코드 블록 없음)")

        # 코드 블록 내부
        elif in_code_block and current_code is not None:
            current_code += line + "\n"
            # HTML 종료 태그 감지
            if line.strip() == "</html>":
                logger.debug("HTML 종료 태그 감지")

        i += 1

    # 마지막 슬라이드 저장
    if current_slide and current_code:
        slide_data = {
            "title": current_slide,
            "thinking": (
                current_thinking if current_thinking else "향상된 슬라이드 생성됨"
            ),
            "html": current_code.strip(),
        }
        slides.append(slide_data)
        logger.info(f"마지막 슬라이드 파싱 완료: {current_slide}")
    elif current_slide and not current_code:
        logger.warning(f"슬라이드 '{current_slide}' 감지되었으나 HTML 코드가 없음")
        logger.warning(f"in_code_block 상태: {in_code_block}")
        logger.warning(f"current_code 길이: {len(current_code) if current_code else 0}")

    # 슬라이드가 없는 경우 다른 방법들 시도
    if len(slides) == 0:
        logger.info("표준 파싱 실패, 대안 방법 시도")

        # 1. HTML 직접 추출 시도
        if "<!DOCTYPE html" in full_text:
            logger.info("HTML 직접 추출 시도")
            html_start = full_text.find("<!DOCTYPE html")
            if html_start >= 0:
                html_end = full_text.find("</html>", html_start)
                if html_end >= 0:
                    html_content = full_text[html_start : html_end + 7]
                    slide_data = {
                        "title": "생성된 슬라이드",
                        "thinking": "전체 HTML에서 추출됨",
                        "html": html_content,
                    }
                    slides.append(slide_data)
                    logger.info("HTML 직접 추출 성공")

        # 2. 마크다운 응답을 HTML로 변환하는 시도 (현재 비활성화)
        # elif "**슬라이드 제목:**" in full_text or "**Slide Title:**" in full_text:
        #     logger.info("마크다운 응답을 HTML로 변환 시도")
        #     # 마크다운 변환 기능은 추후 구현 예정

    logger.info(f"총 {len(slides)}개 슬라이드 파싱 완료")

    # 디버그 정보 출력
    for i, slide in enumerate(slides):
        logger.info(
            f"슬라이드 {i+1}: 제목='{slide['title']}', HTML 길이={len(slide['html'])}"
        )

    return slides
