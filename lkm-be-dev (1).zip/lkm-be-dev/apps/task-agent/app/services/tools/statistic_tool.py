from typing import AsyncGenerator, Optional, Dict, Any
import pandas as pd
from core.llm import get_model
from services.tools.react_agent_for_statistics import (
    create_statistical_analysis_agent,
    get_all_statistical_tools,
)

from langchain_core.callbacks import AsyncCallbackHandler, BaseCallbackHandler
from core.log.logging import get_logging
import json
from time import sleep
import random

logger = get_logging()


def print_event(**kwargs):
    event = {
        **kwargs,
    }
    sleep(random.random() * 3)
    return f"event: data\ndata: {json.dumps(event, ensure_ascii=False)}\n\n"


import re


def extract_korean_thoughts(text) -> str:
    # "Thought: " 패턴을 찾아서 한국어 부분만 추출
    thought_pattern = r"Thought:\s*([^A-Za-z\n]*?)(?=\n\nAction:|\nAction:|$)"

    thoughts = re.findall(thought_pattern, text, re.DOTALL)

    korean_thoughts = []
    for thought in thoughts:
        # 줄바꿈 정리하고 공백 정리
        cleaned = thought.strip().replace("\n", " ")
        cleaned = re.sub(r"\s+", " ", cleaned)  # 연속 공백 제거

        if cleaned and any(
            ord(char) > 127 for char in cleaned
        ):  # 한국어 포함 여부 확인
            korean_thoughts.append(cleaned)

    return "\n".join(korean_thoughts)


class AnalysisCallbackHandler(AsyncCallbackHandler):
    def __init__(self):
        self.steps = []
        self.current_step = ""

    async def on_llm_start(self, serialized, prompts, **kwargs):
        model_name = serialized.get("name", "LLM")
        self.current_step = f"{model_name} 분석 중..."

    async def on_llm_end(self, response, **kwargs):
        # LLMResult 객체에서 올바르게 텍스트 추출
        try:
            if hasattr(response, "generations") and response.generations:
                # 첫 번째 generation의 텍스트 추출
                first_generation = response.generations[0][0]
                if hasattr(first_generation, "text"):
                    text = first_generation.text
                elif hasattr(first_generation, "message"):
                    text = first_generation.message.content
                else:
                    text = str(first_generation)

                cleaned_output = self._clean_output(text)
                self.steps.append(cleaned_output)
        except Exception as e:
            logger.error(f"Error processing LLM output: {e}")

    def _clean_output(self, raw_output):
        # 원시 출력을 깔끔하게 정리
        if isinstance(raw_output, str):
            return raw_output[:100]
        return str(raw_output)[:100]


class StatisticTool:
    def __init__(self):
        self.callback = AnalysisCallbackHandler()
        self.contents = ""
        self.tool_description = {}

    async def get_statistic(
        self,
        query: str,
        report: str,
        agenda_items: list,
        data: pd.DataFrame,
        chat_id: str,
    ) -> AsyncGenerator[Optional[Dict[str, Any]], None]:

        yield print_event(
            type="PLAN_START",
            content="자료 분석을 시작합니다.",
            description="통계 전문 에이전트 호출",
            key="plan_start",
            id=chat_id,
        )
        yield print_event(
            type="STEP_START",
            content="파일 업로드 완료",
            description="파일명 : Brent_Oil_Prices.csv",
            key="step_start",
            id=chat_id,
        )
        yield print_event(
            type="ACTION_START",
            content="통계 도구 리스트 작성",
            description="평균, 중앙값, 표준편차, 최솟값, 최댓값, 사분위수, ...",
            key="action_start",
            id=chat_id,
        )

        yield print_event(
            type="ACTION_SUCCESS",
            content="자료 분석 에이전트를 완료했습니다.",
            description="",
            key="action_success",
            id=chat_id,
        )
        yield print_event(
            type="STEP_END",
            content="자료 분석 에이전트를 완료했습니다.",
            description="",
            key="step_end",
            id=chat_id,
        )

        yield print_event(
            type="PLAN_END",
            content="자료 분석을 완료했습니다.",
            description="자료 분석을 완료했습니다.",
            key="plan_end",
            id=chat_id,
        )
        tools = get_all_statistical_tools(data)
        self.tool_descriptions = {tool.name: tool.description for tool in tools}
        llm = get_model(user_id="1360")

        # 3. Agent 생성 (도구에 데이터 바인딩)
        agent = create_statistical_analysis_agent(llm, data)

        # 4. 분석 실행
        logger.info("Statistic Tool Start")
        result = agent.astream_events(
            {
                "input": query,
                "data_title": "Brent Oil Prices",
                "data_shape": data.shape[0],
                "data_cols": data.shape[1],
                "columns": ", ".join(data.columns),
                "report": report,
                "agenda_items": agenda_items,
            },
            config={"callbacks": [self.callback]},
            version="v2",
        )

        contents = ""
        async for event in result:
            if event["event"] == "on_chat_model_start":
                contents = ""
            elif event["event"] == "on_chat_model_stream":
                chunk = event["data"]["chunk"]
                if hasattr(chunk, "content") and chunk.content:
                    contents += chunk.content
                    self.contents += chunk.content
            elif event["event"] == "on_chat_model_end":
                if "Invalid Format" not in contents:
                    contents = extract_korean_thoughts(contents)
                else:
                    contents = "도구 사용 중 오류 발생. 다시 시도합니다."

                if contents:
                    progress_statement = {
                        "type": "CANVAS",
                        "content": contents,  # [:100] + "...",
                        "description": "자료 분석 중",
                        "key": "data_analysis",
                        "id": chat_id,
                        "title": "자료 분석",
                    }
                    contents = ""
                    yield print_event(**progress_statement)
                else:
                    contents = ""
            elif event["event"] == "on_tool_start":
                tool_name = event["name"]
                tool_description = self.tool_descriptions.get(tool_name, "데이터 분석")
                progress_statement = {
                    "type": "CANVAS",
                    "content": f"{tool_description}",  # [:100] + "...",
                    "description": "슬라이드 생성 중",
                    "key": "",
                    "id": chat_id,
                    "title": "도구 사용",
                }
                yield print_event(**progress_statement)
            # 도구 완료 이벤트
            elif event["event"] == "on_tool_end":
                tool_name = event["name"]
                output = event["data"]["output"]
                # 출력 내용을 요약해서 스트림
                summary = (
                    str(output)[:200] + "..." if len(str(output)) > 200 else str(output)
                )
                progress_statement = {
                    "type": "CANVAS",
                    "content": f"완료: {summary}",  # [:100] + "...",
                    "description": "슬라이드 생성 중",
                    "key": "",
                    "id": chat_id,
                    "title": "도구 사용",
                }
                yield print_event(**progress_statement)
            else:
                pass

        # return {"success": True, "query": query, "result": result["output"]}
