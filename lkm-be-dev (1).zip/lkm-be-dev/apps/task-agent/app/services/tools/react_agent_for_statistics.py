import warnings

import numpy as np
import pandas as pd
from langchain.agents import AgentExecutor, create_react_agent
from langchain.tools import BaseTool
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field
from scipy import stats
from scipy.stats import jarque_bera, kurtosis, shapiro, skew

warnings.filterwarnings("ignore")


class DataFrameInput(BaseModel):
    df: pd.DataFrame = Field(description="분석할 pandas DataFrame")

    class Config:
        arbitrary_types_allowed = True


class BasicDescriptiveStatsTool(BaseTool):
    name: str = "basic_descriptive_stats"
    description: str = (
        "평균, 중앙값, 표준편차, 최솟값, 최댓값, 사분위수 등 기본 기술통계량을 계산합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            numeric_cols = self.data.select_dtypes(include=[np.number]).columns

            if len(numeric_cols) == 0:
                return "수치형 변수가 없습니다."

            result = "기본 기술통계량 분석 결과:\n"
            result += f"수치형 변수 개수: {len(numeric_cols)}개\n\n"

            for col in numeric_cols:
                data = self.data[col].dropna()
                if len(data) == 0:
                    continue

                result += f"{col}:\n"
                result += f"  개수: {len(data)}\n"
                result += f"  평균: {np.mean(data):.4f}\n"
                result += f"  중앙값: {np.median(data):.4f}\n"
                result += f"  표준편차: {np.std(data, ddof=1):.4f}\n"
                result += f"  최솟값: {np.min(data):.4f}\n"
                result += f"  최댓값: {np.max(data):.4f}\n"
                result += f"  범위: {np.max(data) - np.min(data):.4f}\n"
                result += f"  1분위수: {np.percentile(data, 25):.4f}\n"
                result += f"  3분위수: {np.percentile(data, 75):.4f}\n"
                result += f"  사분위범위: {np.percentile(data, 75) - np.percentile(data, 25):.4f}\n\n"

            return result

        except Exception as e:
            return f"기본 통계량 계산 중 오류: {str(e)}"


class DistributionAnalysisTool(BaseTool):
    name: str = "distribution_analysis"
    description: str = (
        "데이터의 분포 특성을 분석합니다. 왜도, 첨도, 정규성 검정(Shapiro-Wilk, Jarque-Bera)을 수행합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            numeric_cols = self.data.select_dtypes(include=[np.number]).columns

            if len(numeric_cols) == 0:
                return "수치형 변수가 없습니다."

            result = "분포 분석 결과:\n\n"

            for col in numeric_cols:
                data = self.data[col].dropna()
                if len(data) < 3:
                    continue

                skewness = skew(data)
                kurt = kurtosis(data)

                result += f"{col}:\n"
                result += f"  왜도: {skewness:.4f} "

                if abs(skewness) < 0.5:
                    result += "(대칭적)\n"
                elif skewness > 0:
                    result += "(우편향)\n"
                else:
                    result += "(좌편향)\n"

                result += f"  첨도: {kurt:.4f} "
                if kurt > 0:
                    result += "(정규분포보다 뾰족함)\n"
                else:
                    result += "(정규분포보다 평평함)\n"

                # 정규성 검정
                if len(data) >= 8:
                    if len(data) <= 5000:
                        shapiro_stat, shapiro_p = shapiro(data)
                        result += f"  Shapiro-Wilk 검정: 통계량={shapiro_stat:.4f}, p-value={shapiro_p:.4f}"
                        result += (
                            f" ({'정규분포' if shapiro_p > 0.05 else '비정규분포'})\n"
                        )

                    jb_stat, jb_p = jarque_bera(data)
                    result += (
                        f"  Jarque-Bera 검정: 통계량={jb_stat:.4f}, p-value={jb_p:.4f}"
                    )
                    result += f" ({'정규분포' if jb_p > 0.05 else '비정규분포'})\n"
                else:
                    result += "  샘플 크기가 작아 정규성 검정 불가\n"

                result += "\n"

            return result

        except Exception as e:
            return f"분포 분석 중 오류: {str(e)}"


class CorrelationAnalysisTool(BaseTool):
    name: str = "correlation_analysis"
    description: str = (
        "변수 간 상관관계를 분석합니다. 피어슨과 스피어만 상관계수를 계산하고 강한 상관관계를 식별합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            numeric_cols = self.data.select_dtypes(include=[np.number]).columns

            if len(numeric_cols) < 2:
                return "상관관계 분석을 위해 최소 2개의 수치형 변수가 필요합니다."

            clean_df = self.data[numeric_cols].dropna()

            if len(clean_df) < 2:
                return "유효한 데이터가 부족합니다."

            result = "상관관계 분석 결과:\n\n"

            # 피어슨 상관계수
            pearson_corr = np.corrcoef(clean_df.T)

            # 스피어만 상관계수
            spearman_result = stats.spearmanr(clean_df)
            if hasattr(spearman_result, "correlation"):
                spearman_corr = spearman_result.correlation
            else:
                spearman_corr = spearman_result[0]

            # 강한 상관관계 찾기
            strong_correlations = []
            n_cols = len(numeric_cols)

            result += "강한 상관관계 (|r| > 0.7):\n"

            for i in range(n_cols):
                for j in range(i + 1, n_cols):
                    pearson_val = pearson_corr[i, j]

                    # 스피어만 상관계수 처리
                    if isinstance(spearman_corr, np.ndarray):
                        spearman_val = spearman_corr[i, j]
                    else:
                        spearman_val = spearman_corr

                    if abs(pearson_val) > 0.7:
                        strength = "매우 강함" if abs(pearson_val) > 0.9 else "강함"
                        result += f"  • {numeric_cols[i]} ↔ {numeric_cols[j]}: "
                        result += f"피어슨={pearson_val:.4f} ({strength})\n"
                        strong_correlations.append(
                            (numeric_cols[i], numeric_cols[j], pearson_val)
                        )

            if not strong_correlations:
                result += "  강한 상관관계가 발견되지 않았습니다.\n"

            result += "\n상관계수 매트릭스 (피어슨):\n"
            result += "변수명".ljust(15)
            for col in numeric_cols:
                result += f"{col[:8]:>10}"
            result += "\n"

            for i, col1 in enumerate(numeric_cols):
                result += f"{col1[:14]:15}"
                for j, col2 in enumerate(numeric_cols):
                    result += f"{pearson_corr[i, j]:10.3f}"
                result += "\n"

            return result

        except Exception as e:
            return f"상관관계 분석 중 오류: {str(e)}"


class OutlierAnalysisTool(BaseTool):
    name: str = "outlier_analysis"
    description: str = (
        "이상치를 탐지합니다. IQR 방법, Z-score 방법, Modified Z-score 방법을 사용하여 이상치를 식별합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            numeric_cols = self.data.select_dtypes(include=[np.number]).columns

            if len(numeric_cols) == 0:
                return "수치형 변수가 없습니다."

            result = "이상치 분석 결과:\n\n"

            for col in numeric_cols:
                data = self.data[col].dropna()
                if len(data) < 4:
                    continue

                result += f"{col}:\n"

                # IQR 방법
                q1 = np.percentile(data, 25)
                q3 = np.percentile(data, 75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr

                iqr_outliers = data[(data < lower_bound) | (data > upper_bound)]
                iqr_percentage = (len(iqr_outliers) / len(data)) * 100

                result += f"  IQR 방법: {len(iqr_outliers)}개 ({iqr_percentage:.2f}%)\n"
                result += f"    정상범위: [{lower_bound:.4f}, {upper_bound:.4f}]\n"

                # Z-score 방법
                data_array = data.values if hasattr(data, "values") else np.array(data)
                if len(data_array) > 1:
                    z_scores = np.abs(
                        (data_array - np.mean(data_array)) / np.std(data_array, ddof=1)
                    )
                    z_outliers = data[z_scores > 3]
                    z_percentage = (len(z_outliers) / len(data)) * 100
                else:
                    z_outliers = pd.Series(dtype=data.dtype)
                    z_percentage = 0

                result += f"  Z-score 방법: {len(z_outliers)}개 ({z_percentage:.2f}%)\n"

                # Modified Z-score 방법
                median = np.median(data)
                mad = np.median(np.abs(data - median))
                if mad != 0:
                    modified_z_scores = 0.6745 * (data - median) / mad
                    modified_z_outliers = data[np.abs(modified_z_scores) > 3.5]
                    modified_z_percentage = (len(modified_z_outliers) / len(data)) * 100

                    result += f"  Modified Z-score 방법: {len(modified_z_outliers)}개 ({modified_z_percentage:.2f}%)\n"

                # 종합 평가
                avg_outlier_pct = np.mean([iqr_percentage, z_percentage])
                if avg_outlier_pct > 10:
                    result += "  높은 이상치 비율 - 데이터 검토 필요\n"
                elif avg_outlier_pct > 5:
                    result += "  보통 수준의 이상치 - 주의 관찰\n"
                else:
                    result += "  낮은 이상치 비율\n"

                result += "\n"

            return result

        except Exception as e:
            return f"이상치 분석 중 오류: {str(e)}"


class VarianceAnalysisTool(BaseTool):
    name: str = "variance_analysis"
    description: str = (
        "데이터의 분산과 변동성을 분석합니다. 분산, 표준편차, 변동계수를 계산합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            numeric_cols = self.data.select_dtypes(include=[np.number]).columns

            if len(numeric_cols) == 0:
                return "수치형 변수가 없습니다."

            result = "분산 분석 결과:\n\n"

            for col in numeric_cols:
                data = self.data[col].dropna()
                if len(data) < 2:
                    continue

                variance = np.var(data, ddof=1)
                std_dev = np.std(data, ddof=1)
                mean = np.mean(data)

                # 변동계수 (Coefficient of Variation)
                cv = (std_dev / mean) * 100 if mean != 0 else 0

                result += f"{col}:\n"
                result += f"  분산: {variance:.4f}\n"
                result += f"  표준편차: {std_dev:.4f}\n"
                result += f"  평균: {mean:.4f}\n"
                result += f"  변동계수: {cv:.2f}%\n"

                # 변동성 해석
                if cv < 15:
                    variability = "낮은 변동성 (안정적)"
                elif cv < 30:
                    variability = "보통 변동성"
                else:
                    variability = "높은 변동성 (불안정)"

                result += f"  변동성 평가: {variability}\n\n"

            return result

        except Exception as e:
            return f"분산 분석 중 오류: {str(e)}"


class PercentileAnalysisTool(BaseTool):
    name: str = "percentile_analysis"
    description: str = (
        "데이터의 백분위수를 분석합니다. 5, 10, 25, 50, 75, 90, 95, 99백분위수를 계산합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            numeric_cols = self.data.select_dtypes(include=[np.number]).columns

            if len(numeric_cols) == 0:
                return "수치형 변수가 없습니다."

            result = "백분위수 분석 결과:\n\n"
            percentiles = [5, 10, 25, 50, 75, 90, 95, 99]

            for col in numeric_cols:
                data = self.data[col].dropna()
                if len(data) == 0:
                    continue

                result += f"{col}:\n"

                for p in percentiles:
                    value = np.percentile(data, p)
                    result += f"  {p:2d}백분위수: {value:10.4f}\n"

                # 백분위수 간격 분석
                q1 = np.percentile(data, 25)
                q2 = np.percentile(data, 50)
                q3 = np.percentile(data, 75)

                iqr = q3 - q1
                q1_q2_range = q2 - q1
                q2_q3_range = q3 - q2

                result += f"  사분위범위(IQR): {iqr:.4f}\n"
                result += f"  Q1-Q2 범위: {q1_q2_range:.4f}\n"
                result += f"  Q2-Q3 범위: {q2_q3_range:.4f}\n"

                # 분포 대칭성
                if abs(q1_q2_range - q2_q3_range) < 0.1 * iqr:
                    symmetry = "대칭적 분포"
                elif q1_q2_range > q2_q3_range:
                    symmetry = "좌편향 분포"
                else:
                    symmetry = "우편향 분포"

                result += f"  분포 대칭성: {symmetry}\n\n"

            return result

        except Exception as e:
            return f"백분위수 분석 중 오류: {str(e)}"


class MissingValueAnalysisTool(BaseTool):
    name: str = "missing_value_analysis"
    description: str = (
        "결측치를 분석합니다. 각 변수별 결측치 개수, 비율, 심각도를 평가합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            result = "결측치 분석 결과:\n\n"
            total_rows = len(self.data)

            result += f"전체 데이터 행 수: {total_rows}\n"
            result += f"전체 변수 개수: {len(self.data.columns)}\n\n"

            missing_summary = []

            for col in self.data.columns:
                missing_count = self.data[col].isnull().sum()
                missing_percentage = (missing_count / total_rows) * 100

                # 심각도 평가
                if missing_percentage == 0:
                    severity = "없음"
                elif missing_percentage < 5:
                    severity = "낮음"
                elif missing_percentage < 20:
                    severity = "보통"
                elif missing_percentage < 50:
                    severity = "높음"
                else:
                    severity = "매우 높음"

                missing_summary.append(
                    (col, missing_count, missing_percentage, severity)
                )

            # 결측치가 있는 변수들 먼저 표시
            missing_vars = [item for item in missing_summary if item[1] > 0]
            no_missing_vars = [item for item in missing_summary if item[1] == 0]

            if missing_vars:
                result += "결측치가 있는 변수들:\n"
                for col, count, pct, severity in sorted(
                    missing_vars, key=lambda x: x[2], reverse=True
                ):
                    result += f"  {col}: {count}개 ({pct:.2f}%) - {severity}\n"
                result += "\n"

            if no_missing_vars:
                result += f"결측치가 없는 변수: {len(no_missing_vars)}개\n"
                if len(no_missing_vars) <= 10:
                    var_names = [item[0] for item in no_missing_vars]
                    result += f"   {', '.join(var_names)}\n"
                result += "\n"

            # 전체 요약
            total_missing = sum(item[1] for item in missing_summary)
            total_cells = total_rows * len(self.data.columns)
            overall_missing_pct = (total_missing / total_cells) * 100

            result += "전체 요약:\n"
            result += f"  전체 결측치: {total_missing}개\n"
            result += f"  전체 셀 수: {total_cells}개\n"
            result += f"  전체 결측치 비율: {overall_missing_pct:.2f}%\n"

            # 권장사항
            result += "\n권장사항:\n"
            high_missing_vars = [item for item in missing_vars if item[2] > 20]

            if not missing_vars:
                result += "  결측치 처리가 필요하지 않습니다.\n"
            elif high_missing_vars:
                result += "  높은 결측치 비율 변수들의 삭제를 고려하세요.\n"
                result += "  결측치 대체 방법(평균, 중앙값, 최빈값 등)을 검토하세요.\n"
            else:
                result += "  대부분의 결측치 비율이 양호합니다.\n"
                result += "  간단한 대체 방법으로 처리 가능합니다.\n"

            return result

        except Exception as e:
            return f"결측치 분석 중 오류: {str(e)}"


class DataTypeAnalysisTool(BaseTool):
    name: str = "data_type_analysis"
    description: str = (
        "데이터 타입을 분석합니다. 각 변수의 데이터 타입, 고유값 개수, 메모리 사용량을 분석합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            result = "데이터 타입 분석 결과:\n\n"

            # 전체 요약
            numeric_cols = len(self.data.select_dtypes(include=[np.number]).columns)
            categorical_cols = len(self.data.select_dtypes(include=["object"]).columns)
            datetime_cols = len(self.data.select_dtypes(include=["datetime"]).columns)
            boolean_cols = len(self.data.select_dtypes(include=["bool"]).columns)

            result += "데이터 타입 요약:\n"
            result += f"  전체 변수: {len(self.data.columns)}개\n"
            result += f"  수치형 변수: {numeric_cols}개\n"
            result += f"  범주형 변수: {categorical_cols}개\n"
            result += f"  날짜/시간 변수: {datetime_cols}개\n"
            result += f"  불린 변수: {boolean_cols}개\n\n"

            # 변수별 상세 정보
            result += "변수별 상세 정보:\n"

            for col in self.data.columns:
                col_data = self.data[col].dropna()
                data_type = str(self.data[col].dtype)
                unique_count = self.data[col].nunique()
                unique_percentage = (unique_count / len(self.data)) * 100
                memory_usage = self.data[col].memory_usage(deep=True)

                result += f"  {col}:\n"
                result += f"    데이터 타입: {data_type}\n"
                result += (
                    f"    고유값 개수: {unique_count}개 ({unique_percentage:.1f}%)\n"
                )
                result += f"    메모리 사용량: {memory_usage:,} bytes\n"

                # 추가 정보
                if self.data[col].dtype in ["int64", "float64", "int32", "float32"]:
                    is_integer = self.data[col].dtype in ["int64", "int32"]

                    # 소수점 포함 여부 확인
                    numeric_data = self.data[col].dropna()
                    if len(numeric_data) > 0:
                        has_decimals = not all(
                            x == int(x) if pd.notnull(x) else True for x in numeric_data
                        )
                    else:
                        has_decimals = False

                    result += f"    정수형: {'예' if is_integer else '아니오'}\n"
                    result += f"    소수점 포함: {'예' if has_decimals else '아니오'}\n"

                # 카디널리티 분석
                if unique_percentage < 5:
                    cardinality = "낮음 (범주형 가능)"
                elif unique_percentage < 50:
                    cardinality = "보통"
                else:
                    cardinality = "높음 (연속형)"

                result += f"    카디널리티: {cardinality}\n"

                # 샘플 값 표시 (범주형인 경우)
                if data_type == "object" and unique_count <= 10:
                    sample_values = self.data[col].value_counts().head(5).index.tolist()
                    result += f"    주요 값: {', '.join(map(str, sample_values))}\n"

                result += "\n"

            # 메모리 사용량 요약
            total_memory = self.data.memory_usage(deep=True).sum()
            result += f"전체 메모리 사용량: {total_memory:,} bytes ({total_memory/1024/1024:.2f} MB)\n"

            # 최적화 제안
            result += "\n최적화 제안:\n"
            optimization_suggestions = []

            for col in self.data.columns:
                if self.data[col].dtype == "object":
                    unique_ratio = self.data[col].nunique() / len(self.data)
                    if unique_ratio < 0.5:
                        optimization_suggestions.append(
                            f"  • {col}: category 타입으로 변환 고려"
                        )

                elif self.data[col].dtype == "int64":
                    max_val = self.data[col].max()
                    min_val = self.data[col].min()
                    if min_val >= 0 and max_val < 256:
                        optimization_suggestions.append(f"  • {col}: uint8로 변환 가능")
                    elif min_val >= -128 and max_val < 128:
                        optimization_suggestions.append(f"  • {col}: int8로 변환 가능")

                elif self.data[col].dtype == "float64":
                    optimization_suggestions.append(f"  • {col}: float32로 변환 고려")

            if optimization_suggestions:
                result += "\n".join(optimization_suggestions) + "\n"
            else:
                result += "  현재 데이터 타입이 적절합니다.\n"

            return result

        except Exception as e:
            return f"데이터 타입 분석 중 오류: {str(e)}"


class CentralTendencyAnalysisTool(BaseTool):
    name: str = "central_tendency_analysis"
    description: str = (
        "중심경향성을 분석합니다. 산술평균, 중앙값, 최빈값, 절단평균, 기하평균, 조화평균을 계산합니다."
    )
    data: pd.DataFrame = None

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.data = data

    def _run(self, input: str = "") -> str:
        try:
            if self.data is None:
                return "데이터가 없습니다."

            numeric_cols = self.data.select_dtypes(include=[np.number]).columns

            if len(numeric_cols) == 0:
                return "수치형 변수가 없습니다."

            result = "중심경향성 분석 결과:\n\n"

            for col in numeric_cols:
                data = self.data[col].dropna()
                if len(data) == 0:
                    continue

                mean = np.mean(data)
                median = np.median(data)

                # 최빈값 계산
                mode_result = stats.mode(data, keepdims=True)
                modal_value = mode_result.mode[0]
                mode_count = mode_result.count[0]

                # 절단평균 (상하위 10% 제거)
                trimmed_mean = stats.trim_mean(data, 0.2)

                result += f"{col}:\n"
                result += f"  산술평균: {mean:.4f}\n"
                result += f"  중앙값: {median:.4f}\n"
                result += f"  최빈값: {modal_value:.4f} (빈도: {mode_count})\n"
                result += f"  절단평균 (20% trim): {trimmed_mean:.4f}\n"

                # 기하평균과 조화평균 (양수 데이터만)
                if np.all(data > 0):
                    geometric_mean = stats.gmean(data)
                    harmonic_mean = stats.hmean(data)
                    result += f"  기하평균: {geometric_mean:.4f}\n"
                    result += f"  조화평균: {harmonic_mean:.4f}\n"
                else:
                    result += f"  기하평균: 계산불가 (음수 또는 0 포함)\n"
                    result += f"  조화평균: 계산불가 (음수 또는 0 포함)\n"

                # 평균과 중앙값 차이 분석
                mean_median_diff = abs(mean - median)
                std_dev = np.std(data, ddof=1)

                result += f"  평균-중앙값 차이: {mean_median_diff:.4f}\n"

                # 분포 대칭성 평가
                if mean_median_diff < 0.1 * std_dev:
                    symmetry = "대칭적 분포"
                elif mean > median:
                    symmetry = "우편향 분포 (평균 > 중앙값)"
                else:
                    symmetry = "좌편향 분포 (평균 < 중앙값)"

                result += f"  분포 대칭성: {symmetry}\n"

                # 중심경향성 측도 간 비교
                result += f"\n  중심경향성 측도 간 비교:\n"
                # 평균 vs 중앙값
                if abs(mean - median) / std_dev < 0.1:
                    result += f"    평균 ≈ 중앙값: 대칭적 분포, 두 측도 모두 적절\n"
                elif mean > median:
                    result += f"    평균 > 중앙값: 우편향, 중앙값이 더 대표적\n"
                else:
                    result += f"    평균 < 중앙값: 좌편향, 중앙값이 더 대표적\n"

                # 최빈값의 대표성
                mode_frequency_ratio = mode_count / len(data)
                if mode_frequency_ratio > 0.1:
                    result += f"    최빈값 대표성: 높음 (전체의 {mode_frequency_ratio*100:.1f}%)\n"
                else:
                    result += f"    최빈값 대표성: 낮음 (전체의 {mode_frequency_ratio*100:.1f}%)\n"

                # 절단평균의 효과
                trim_effect = abs(mean - trimmed_mean)
                if trim_effect > 0.05 * std_dev:
                    result += f"    절단평균 효과: 큼 (이상치 영향 존재)\n"
                else:
                    result += f"    절단평균 효과: 작음 (이상치 영향 미미)\n"

                result += "\n"

            return result

        except Exception as e:
            return f"중심경향성 분석 중 오류: {str(e)}"


# 모든 도구를 리스트로 제공하는 함수
def get_all_statistical_tools(data: pd.DataFrame):
    """모든 통계 분석 도구들을 반환"""
    return [
        BasicDescriptiveStatsTool(data),
        DistributionAnalysisTool(data),
        CorrelationAnalysisTool(data),
        OutlierAnalysisTool(data),
        VarianceAnalysisTool(data),
        PercentileAnalysisTool(data),
        MissingValueAnalysisTool(data),
        DataTypeAnalysisTool(data),
        CentralTendencyAnalysisTool(data),
    ]


# 업데이트된 Agent 생성 함수
def create_statistical_analysis_agent(llm, data: pd.DataFrame):
    """LLM + 데이터로 Agent 생성"""
    tools = get_all_statistical_tools(data)

    prompt = PromptTemplate(
        template="""You are a Korean-speaking data analysis expert. All explanations must be in Korean, but use the exact format below.

CRITICAL: Use EXACT keywords - Thought, Action, Action Input, Observation
IMPORTANT: Do NOT use the same tool twice. Check your previous actions before choosing a tool.

MANDATORY FORMAT:
Thought: [한국어로 분석 계획 설명 - 이미 사용한 도구는 다시 사용하지 마세요]
Action: [선택한 도구명, 도구명만 정확히 작성해주세요]
Action Input: ""
Observation: [도구 결과가 여기에 나타남, 도구 결과는 한국어로 작성해주세요]

ANALYSIS STRATEGY:
1. Start with basic_descriptive_stats to understand the data
2. Choose additional tools based on data characteristics:
    - If multiple numeric columns: correlation_analysis
    - Always check: outlier_analysis
    - If needed: distribution_analysis, variance_analysis, etc.
3. Use 3-5 different tools total (no repeats)
4. MANDATORY: After using 3-5 tools, you MUST provide Final Answer

CRITICAL RULE: 
- Check what tools you already used in {agent_scratchpad}
- Never repeat the same Action
- Choose tools that provide meaningful insights for the question
- MANDATORY: After using 3-5 different tools, IMMEDIATELY provide Final Answer
- DO NOT continue using more tools after 5 tools - STOP and provide Final Answer

Data: 
Title : {data_title}
{data_shape} rows × {data_cols} columns
Columns: {columns}

Question: {input}
Pre-written Report: {report}
Pre-written Agenda: {agenda_items}

Available Tools: {tools}
Tool names: {tool_names}

CRITICAL: Use each tool only ONCE. After 3-5 tools, you MUST provide Final Answer using EXACT format:

MANDATORY FINAL ANSWER FORMAT:
Final Answer: 
=== 보강된 보고서 ===
[기존 보고서에 데이터 분석 결과와 구체적 수치, 통계적 인사이트를 추가한 보강된 보고서 내용을 여기에 작성]

=== 보강된 아젠다 ===
1. [구체적인 PPT 슬라이드 제목 1]
2. [구체적인 PPT 슬라이드 제목 2]
3. [구체적인 PPT 슬라이드 제목 3]
4. [구체적인 PPT 슬라이드 제목 4]
5. [구체적인 PPT 슬라이드 제목 5]
6. [구체적인 PPT 슬라이드 제목 6]
7. [구체적인 PPT 슬라이드 제목 7]
8. [구체적인 PPT 슬라이드 제목 8]

{agent_scratchpad}""",
        input_variables=[
            "input",
            "tools",
            "tool_names",
            "agent_scratchpad",
            "report",
            "agenda_items",
            "data_title",
        ],
        partial_variables={
            "data_title": "분석 데이터",
            "data_shape": data.shape[0],
            "data_cols": data.shape[1],
            "columns": ", ".join(data.columns),
        },
    )

    agent = create_react_agent(llm, tools, prompt)
    return AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        max_iterations=8,
        max_execution_time=120,
        handle_parsing_errors=True,
        early_stopping_method="generate",
    )
