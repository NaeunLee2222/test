#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Docx Processing LangChain Tools
Provides various operations for docx documents, including querying, adding, modifying, deleting, and font style settings
Implemented using python-docx and LangChain
"""

import logging
import os
import tempfile
import traceback
from typing import List, Optional

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from langchain.tools import tool

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(
            os.path.join(tempfile.gettempdir(), "docx_langchain_tools.log")
        ),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("DocxLangChainTools")

# Create a state file for restoring state
CURRENT_DOC_FILE = os.path.join(tempfile.gettempdir(), "docx_langchain_current_doc.txt")


class DocxProcessor:
    """Class for processing Docx documents, implementing various document operations"""

    def __init__(self):
        self.documents = {}  # Store opened documents
        self.current_document = None
        self.current_file_path = None

        # Try to load current document from state file
        self._load_current_document()

    def _load_current_document(self):
        """Load current document from state file"""
        if not os.path.exists(CURRENT_DOC_FILE):
            return False

        try:
            with open(CURRENT_DOC_FILE, "r", encoding="utf-8") as f:
                file_path = f.read().strip()

            if file_path and os.path.exists(file_path):
                try:
                    self.current_file_path = file_path
                    self.current_document = Document(file_path)
                    self.documents[file_path] = self.current_document
                    return True
                except Exception as e:
                    logger.error(f"Failed to load document at {file_path}: {e}")
                    # Delete invalid state file to prevent future loading attempts
                    try:
                        os.remove(CURRENT_DOC_FILE)
                        logger.info(
                            f"Removed invalid state file pointing to {file_path}"
                        )
                    except Exception as e_remove:
                        logger.error(f"Failed to remove state file: {e_remove}")
            else:
                # Delete invalid state file if path is empty or file doesn't exist
                try:
                    os.remove(CURRENT_DOC_FILE)
                    logger.info(
                        "Removed invalid state file with non-existent document path"
                    )
                except Exception as e_remove:
                    logger.error(f"Failed to remove state file: {e_remove}")
        except Exception as e:
            logger.error(f"Failed to load current document: {e}")
            # Delete corrupted state file
            try:
                os.remove(CURRENT_DOC_FILE)
                logger.info("Removed corrupted state file")
            except Exception as e_remove:
                logger.error(f"Failed to remove state file: {e_remove}")

        return False

    def _save_current_document(self):
        """Save current document path to state file"""
        if not self.current_file_path:
            return False

        try:
            with open(CURRENT_DOC_FILE, "w", encoding="utf-8") as f:
                f.write(self.current_file_path)
            return True
        except Exception as e:
            logger.error(f"Failed to save current document path: {e}")

        return False

    def save_state(self):
        """Save processor state"""
        # Save current document
        if self.current_document and self.current_file_path:
            try:
                self.current_document.save(self.current_file_path)
                self._save_current_document()
            except Exception as e:
                logger.error(f"Failed to save current document: {e}")

    def load_state(self):
        """Load processor state"""
        self._load_current_document()


# Create global processor instance
processor = DocxProcessor()


# LangChain Tools for Docx Processing


@tool("create_document")
def create_document(file_path: str) -> str:
    """
    Create a new Word document

    Parameters:
        file_path: Document save path

    Returns:
        Success or error message
    """
    try:
        processor.current_document = Document()
        processor.current_file_path = file_path
        processor.documents[file_path] = processor.current_document

        # Save document
        processor.current_document.save(file_path)

        return f"Document created successfully: {file_path}"
    except Exception as e:
        error_msg = f"Failed to create document: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("open_document")
def open_document(file_path: str) -> str:
    """
    Open an existing Word document

    Parameters:
        file_path: Path to the document to open

    Returns:
        Success or error message
    """
    try:
        if not os.path.exists(file_path):
            create_document(file_path)

        processor.current_document = Document(file_path)
        processor.current_file_path = file_path
        processor.documents[file_path] = processor.current_document

        return f"Document opened successfully: {file_path}"
    except Exception as e:
        error_msg = f"Failed to open document: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("save_document")
def save_document() -> str:
    """
    Save the currently open Word document to the original file (update the original file)

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        if not processor.current_file_path:
            return "Current document has not been saved before, please use save_as_document to specify a save path"

        # Save to original file path
        processor.current_document.save(processor.current_file_path)

        return f"Document saved successfully to original file: {processor.current_file_path}"
    except Exception as e:
        error_msg = f"Failed to save document: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("add_paragraph")
def add_paragraph(
    text: str,
    bold: bool = False,
    italic: bool = False,
    underline: bool = False,
    font_size: Optional[int] = None,
    font_name: Optional[str] = None,
    color: Optional[str] = None,
    alignment: Optional[str] = None,
) -> str:
    """
    Add paragraph text to document

    Parameters:
        text: Paragraph text content
        bold: Whether to bold
        italic: Whether to italicize
        underline: Whether to underline
        font_size: Font size (points)
        font_name: Font name
        color: Text color (format: #FF0000)
        alignment: Alignment (left, center, right, justify)

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        # Add paragraph
        paragraph = processor.current_document.add_paragraph(text)

        # Apply additional formatting
        if paragraph.runs:
            run = paragraph.runs[0]
            run.bold = bold
            run.italic = italic
            run.underline = underline

            # Set font size
            if font_size:
                run.font.size = Pt(font_size)

            # Set font name
            if font_name:
                run.font.name = font_name
                # Set East Asian font
                run._element.rPr.rFonts.set(qn("w:eastAsia"), font_name)

            # Set font color
            if color and color.startswith("#") and len(color) == 7:
                r = int(color[1:3], 16)
                g = int(color[3:5], 16)
                b = int(color[5:7], 16)
                run.font.color.rgb = RGBColor(r, g, b)

        # Set alignment
        if alignment:
            if alignment == "left":
                paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
            elif alignment == "center":
                paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            elif alignment == "right":
                paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
            elif alignment == "justify":
                paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.JUSTIFY

        return "Paragraph added"
    except Exception as e:
        error_msg = f"Failed to add paragraph: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("add_heading")
def add_heading(text: str, level: int) -> str:
    """
    Add heading to document

    Parameters:
        text: Heading text
        level: Heading level (1-9)

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        processor.current_document.add_heading(text, level=level)

        return f"Added level {level} heading"
    except Exception as e:
        error_msg = f"Failed to add heading: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("add_table")
def add_table(rows: int, cols: int, data: Optional[List[List[str]]] = None) -> str:
    """
    Add table to document

    Parameters:
        rows: Number of rows
        cols: Number of columns
        data: Table data, two-dimensional array

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        table = processor.current_document.add_table(
            rows=rows, cols=cols, style="Table Grid"
        )

        # Fill table data
        if data:
            for i, row_data in enumerate(data):
                if i < rows:
                    row = table.rows[i]
                    for j, cell_text in enumerate(row_data):
                        if j < cols:
                            row.cells[j].text = str(cell_text)

        return f"Added {rows}x{cols} table"
    except Exception as e:
        error_msg = f"Failed to add table: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("get_document_info")
def get_document_info() -> str:
    """
    Get document information, including paragraph count, table count, styles, etc.

    Returns:
        Document information or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        # Get basic document information
        sections_count = len(doc.sections)
        paragraphs_count = len(doc.paragraphs)
        tables_count = len(doc.tables)

        # Get style list
        paragraph_styles = []
        for style in doc.styles:
            if style.type == WD_STYLE_TYPE.PARAGRAPH:
                paragraph_styles.append(style.name)

        # Build information string
        info = f"Document path: {processor.current_file_path}\n"
        info += f"Section count: {sections_count}\n"
        info += f"Paragraph count: {paragraphs_count}\n"
        info += f"Table count: {tables_count}\n"
        info += f"Available paragraph styles: {', '.join(paragraph_styles[:10])}..."

        return info
    except Exception as e:
        error_msg = f"Failed to get document information: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("search_text")
def search_text(keyword: str) -> str:
    """
    Search for text in the document

    Parameters:
        keyword: Keyword to search for

    Returns:
        Search results or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document
        results = []

        # Search in paragraphs
        for i, paragraph in enumerate(doc.paragraphs):
            if keyword in paragraph.text:
                results.append(
                    {"type": "paragraph", "index": i, "text": paragraph.text}
                )

        # Search in tables
        for t_idx, table in enumerate(doc.tables):
            for r_idx, row in enumerate(table.rows):
                for c_idx, cell in enumerate(row.cells):
                    if keyword in cell.text:
                        results.append(
                            {
                                "type": "table cell",
                                "table_index": t_idx,
                                "row": r_idx,
                                "column": c_idx,
                                "text": cell.text,
                            }
                        )

        if not results:
            return f"Keyword '{keyword}' not found"

        # Build response
        response = f"Found {len(results)} occurrences of '{keyword}':\n\n"
        for idx, result in enumerate(results):
            response += f"{idx + 1}. {result['type']} "
            if result["type"] == "paragraph":
                response += f"index {result['index']}: {result['text'][:100]}"
                if len(result["text"]) > 100:
                    response += "..."
                response += "\n"
            else:
                response += f"in table {result['table_index']} at cell ({result['row']},{result['column']}): {result['text'][:100]}"
                if len(result["text"]) > 100:
                    response += "..."
                response += "\n"

        return response
    except Exception as e:
        error_msg = f"Failed to search text: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("search_and_replace")
def search_and_replace(
    keyword: str, replace_with: str, preview_only: bool = False
) -> str:
    """
    Search and replace text in the document, providing detailed replacement information and preview options

    Parameters:
        keyword: Keyword to search for
        replace_with: Text to replace with
        preview_only: Whether to only preview without actually replacing, default is False

    Returns:
        Replacement results or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document
        results = []

        # Search in paragraphs
        for i, paragraph in enumerate(doc.paragraphs):
            if keyword in paragraph.text:
                # Save original text and replaced text
                original_text = paragraph.text
                replaced_text = original_text.replace(keyword, replace_with)
                results.append(
                    {
                        "type": "paragraph",
                        "index": i,
                        "original": original_text,
                        "replaced": replaced_text,
                        "count": original_text.count(keyword),
                    }
                )

                # If not in preview mode, perform replacement
                if not preview_only:
                    paragraph.text = replaced_text

        # Search in tables
        for t_idx, table in enumerate(doc.tables):
            for r_idx, row in enumerate(table.rows):
                for c_idx, cell in enumerate(row.cells):
                    if keyword in cell.text:
                        # Save original text and replaced text
                        original_text = cell.text
                        replaced_text = original_text.replace(keyword, replace_with)
                        results.append(
                            {
                                "type": "table cell",
                                "table_index": t_idx,
                                "row": r_idx,
                                "column": c_idx,
                                "original": original_text,
                                "replaced": replaced_text,
                                "count": original_text.count(keyword),
                            }
                        )

                        # If not in preview mode, perform replacement
                        if not preview_only:
                            # Replace all paragraphs in the cell with the replaced text
                            for para in cell.paragraphs:
                                if keyword in para.text:
                                    para.text = para.text.replace(keyword, replace_with)

        if not results:
            return f"Keyword '{keyword}' not found"

        # Calculate total replacements
        total_replacements = sum(item["count"] for item in results)

        # Build response
        action_word = "Preview" if preview_only else "Replace"
        response = f"{action_word} '{keyword}' with '{replace_with}', found {len(results)} locations, {total_replacements} occurrences:\n\n"

        for idx, result in enumerate(results):
            response += f"{idx + 1}. In {result['type']} "
            if result["type"] == "paragraph":
                response += f"index {result['index']} {action_word.lower()}ing {result['count']} times:\n"
            else:
                response += f"table {result['table_index']} at cell ({result['row']},{result['column']}) {action_word.lower()}ing {result['count']} times:\n"

            # Display original and replaced text snippets (context)
            max_display = 50
            if len(result["original"]) > max_display * 2:
                # Find keyword position and display surrounding text
                start_pos = result["original"].find(keyword)
                start_pos = max(0, start_pos - max_display)
                excerpt_original = (
                    "..."
                    + result["original"][start_pos : start_pos + max_display * 2]
                    + "..."
                )
                excerpt_replaced = (
                    "..."
                    + result["replaced"][start_pos : start_pos + max_display * 2]
                    + "..."
                )
            else:
                excerpt_original = result["original"]
                excerpt_replaced = result["replaced"]

            response += f"  Original: {excerpt_original}\n"
            response += f"  Replaced: {excerpt_replaced}\n\n"

        if preview_only:
            response += "This is a preview of replacements. No actual changes were made. To execute replacements, set preview_only to False."
        else:
            response += "Replacements completed successfully."

        return response
    except Exception as e:
        error_msg = f"Search and replace failed: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("merge_table_cells")
def merge_table_cells(
    table_index: int, start_row: int, start_col: int, end_row: int, end_col: int
) -> str:
    """
    Merge table cells

    Parameters:
        table_index: Table index
        start_row: Start row index
        start_col: Start column index
        end_row: End row index
        end_col: End column index

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        if not doc.tables:
            return "No tables in document"

        if table_index < 0 or table_index >= len(doc.tables):
            return f"Table index out of range: {table_index}, document has {len(doc.tables)} tables"

        table = doc.tables[table_index]

        # Check if row and column indices are valid
        if start_row < 0 or start_row >= len(table.rows):
            return f"Start row index out of range: {start_row}, table has {len(table.rows)} rows"

        if start_col < 0 or start_col >= len(table.columns):
            return f"Start column index out of range: {start_col}, table has {len(table.columns)} columns"

        if end_row < start_row or end_row >= len(table.rows):
            return f"End row index invalid: {end_row}, should be between {start_row} and {len(table.rows) - 1}"

        if end_col < start_col or end_col >= len(table.columns):
            return f"End column index invalid: {end_col}, should be between {start_col} and {len(table.columns) - 1}"

        # Get start and end cells
        start_cell = table.cell(start_row, start_col)
        end_cell = table.cell(end_row, end_col)

        # Merge cells
        start_cell.merge(end_cell)

        return f"Merged cells in table {table_index} from ({start_row},{start_col}) to ({end_row},{end_col})"
    except Exception as e:
        error_msg = f"Failed to merge table cells: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("add_table_row")
def add_table_row(table_index: int, data: Optional[List[str]] = None) -> str:
    """
    Add a row to table

    Parameters:
        table_index: Table index
        data: Row data in list format

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        if not doc.tables:
            return "No tables in document"

        if table_index < 0 or table_index >= len(doc.tables):
            return f"Table index out of range: {table_index}, document has {len(doc.tables)} tables"

        table = doc.tables[table_index]

        # Add new row
        new_row = table.add_row()

        # Fill row data
        if data:
            for i, cell_text in enumerate(data):
                if i < len(new_row.cells):
                    new_row.cells[i].text = str(cell_text)

        return f"Added new row to table {table_index}"
    except Exception as e:
        error_msg = f"Failed to add table row: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("edit_table_cell")
def edit_table_cell(table_index: int, row_index: int, col_index: int, text: str) -> str:
    """
    Edit table cell content

    Parameters:
        table_index: Table index
        row_index: Row index
        col_index: Column index
        text: Cell text

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        if not doc.tables:
            return "No tables in document"

        if table_index < 0 or table_index >= len(doc.tables):
            return f"Table index out of range: {table_index}, document has {len(doc.tables)} tables"

        table = doc.tables[table_index]

        if row_index < 0 or row_index >= len(table.rows):
            return (
                f"Row index out of range: {row_index}, table has {len(table.rows)} rows"
            )

        if col_index < 0 or col_index >= len(table.columns):
            return f"Column index out of range: {col_index}, table has {len(table.columns)} columns"

        # Modify cell content
        table.cell(row_index, col_index).text = text

        return (
            f"Cell ({row_index}, {col_index}) in table {table_index} has been modified"
        )
    except Exception as e:
        error_msg = f"Failed to edit table cell: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("add_page_break")
def add_page_break() -> str:
    """
    Add page break

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        processor.current_document.add_page_break()

        return "Page break added"
    except Exception as e:
        error_msg = f"Failed to add page break: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("set_page_margins")
def set_page_margins(
    top: Optional[float] = None,
    bottom: Optional[float] = None,
    left: Optional[float] = None,
    right: Optional[float] = None,
) -> str:
    """
    Set page margins

    Parameters:
        top: Top margin (cm)
        bottom: Bottom margin (cm)
        left: Left margin (cm)
        right: Right margin (cm)

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        # Get current section (default to use first section)
        section = doc.sections[0]

        # Set page margins
        if top is not None:
            section.top_margin = Cm(top)
        if bottom is not None:
            section.bottom_margin = Cm(bottom)
        if left is not None:
            section.left_margin = Cm(left)
        if right is not None:
            section.right_margin = Cm(right)

        return "Page margins set"
    except Exception as e:
        error_msg = f"Failed to set page margins: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("save_as_document")
def save_as_document(new_file_path: str) -> str:
    """
    Save current document as a new file

    Parameters:
        new_file_path: Path to save the new file

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        # Save as new file
        processor.current_document.save(new_file_path)

        # Update current file path
        processor.current_file_path = new_file_path
        processor.documents[new_file_path] = processor.current_document

        return f"Document saved as: {new_file_path}"
    except Exception as e:
        error_msg = f"Failed to save document: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("delete_paragraph")
def delete_paragraph(paragraph_index: int) -> str:
    """
    Delete specified paragraph from document

    Parameters:
        paragraph_index: Paragraph index to delete

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        if paragraph_index < 0 or paragraph_index >= len(doc.paragraphs):
            return f"Paragraph index out of range: {paragraph_index}, document has {len(doc.paragraphs)} paragraphs"

        # python-docx does not provide a direct method to delete a paragraph, use XML operations
        paragraph = doc.paragraphs[paragraph_index]
        p = paragraph._element
        p.getparent().remove(p)
        # Delete paragraph object reference for garbage collection
        paragraph._p = None
        paragraph._element = None

        return f"Paragraph {paragraph_index} deleted"
    except Exception as e:
        error_msg = f"Failed to delete paragraph: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("replace_section")
def replace_section(
    section_title: str, new_content: List[str], preserve_title: bool = True
) -> str:
    """
    Find specified title in document and replace content under that title, keeping original position, format, and style

    Parameters:
        section_title: Title text to find
        new_content: New content list, each element is a paragraph
        preserve_title: Whether to keep original title, default is True

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        # Find title position
        title_index = -1
        for i, paragraph in enumerate(doc.paragraphs):
            if section_title in paragraph.text:
                title_index = i
                break

        if title_index == -1:
            return f"Title not found: '{section_title}'"

        # Determine end position of that section (next same or higher level title)
        end_index = len(doc.paragraphs)
        title_style = doc.paragraphs[title_index].style

        for i in range(title_index + 1, len(doc.paragraphs)):
            # If next same level or higher level title found, set as end position
            if doc.paragraphs[i].style.name.startswith("Heading") and (
                doc.paragraphs[i].style.name <= title_style.name
                or doc.paragraphs[i].style == title_style
            ):
                end_index = i
                break

        # Save original paragraph style and format information
        original_styles = []
        for i in range(
            start_delete := (title_index + (1 if preserve_title else 0)),
            min(end_index, start_delete + len(new_content)),
        ):
            if i < len(doc.paragraphs):
                para = doc.paragraphs[i]
                style_info = {
                    "style": para.style,
                    "alignment": para.alignment,
                    "runs": [],
                }

                # Save each run format
                for run in para.runs:
                    run_info = {
                        "bold": run.bold,
                        "italic": run.italic,
                        "underline": run.underline,
                        "font_size": run.font.size,
                        "font_name": run.font.name,
                        "color": run.font.color.rgb if run.font.color.rgb else None,
                    }
                    style_info["runs"].append(run_info)

                original_styles.append(style_info)
            else:
                # If original paragraph count is insufficient, use last paragraph style
                if original_styles:
                    original_styles.append(original_styles[-1])
                else:
                    # If no original style, use default style
                    original_styles.append(
                        {"style": None, "alignment": None, "runs": []}
                    )

        # If original style count is insufficient, use last style to fill
        while len(original_styles) < len(new_content):
            if original_styles:
                original_styles.append(original_styles[-1])
            else:
                original_styles.append({"style": None, "alignment": None, "runs": []})

        # Record insert position
        insert_position = start_delete

        # Delete from end to avoid index change
        for i in range(end_index - 1, start_delete - 1, -1):
            p = doc.paragraphs[i]._element
            p.getparent().remove(p)

        # Add new content, apply original format
        for i, content in enumerate(reversed(new_content)):
            # Create new paragraph
            p = doc.add_paragraph()

            # Apply original paragraph style
            style_info = original_styles[len(new_content) - i - 1]
            if style_info["style"]:
                p.style = style_info["style"]
            if style_info["alignment"] is not None:
                p.alignment = style_info["alignment"]

            # Add text and apply format
            if style_info["runs"] and len(style_info["runs"]) > 0:
                # If multiple runs, try to keep format
                # Simplified processing: Add entire content to a run, apply format from first run
                run = p.add_run(content)
                run_info = style_info["runs"][0]

                run.bold = run_info["bold"]
                run.italic = run_info["italic"]
                run.underline = run_info["underline"]

                if run_info["font_size"]:
                    run.font.size = run_info["font_size"]

                if run_info["font_name"]:
                    run.font.name = run_info["font_name"]
                    # Set East Asian font
                    run._element.rPr.rFonts.set(qn("w:eastAsia"), run_info["font_name"])

                if run_info["color"]:
                    run.font.color.rgb = run_info["color"]
            else:
                # If no run information, add text directly
                p.text = content

            # Move new paragraph to correct position
            doc._body._body.insert(insert_position, p._p)

            # Delete original added paragraph (at end of document)
            doc._body._body.remove(doc.paragraphs[-1]._p)

        return f"Replaced content under title '{section_title}', keeping original format and style"
    except Exception as e:
        error_msg = f"Failed to replace content: {str(e)}"
        logger.error(error_msg)
        traceback.print_exc()  # Print detailed error information
        return error_msg


@tool("edit_section_by_keyword")
def edit_section_by_keyword(
    keyword: str, new_content: List[str], section_range: int = 3
) -> str:
    """
    Find paragraphs containing specified keyword and replace them and their surrounding content, keeping original position, format, and style

    Parameters:
        keyword: Keyword to find
        new_content: New content list, each element is a paragraph
        section_range: Surrounding paragraph range to replace, default is 3

    Returns:
        Success or error message
    """
    try:
        if not processor.current_document:
            return "No document is open"

        doc = processor.current_document

        # Find keyword position
        keyword_indices = []
        for i, paragraph in enumerate(doc.paragraphs):
            if keyword in paragraph.text:
                keyword_indices.append(i)

        if not keyword_indices:
            return f"Keyword not found: '{keyword}'"

        # Use first match
        keyword_index = keyword_indices[0]

        # Determine paragraph range to replace
        start_index = max(0, keyword_index - section_range)
        end_index = min(len(doc.paragraphs), keyword_index + section_range + 1)

        # Save original paragraph style and format information
        original_styles = []
        for i in range(start_index, min(end_index, start_index + len(new_content))):
            if i < len(doc.paragraphs):
                para = doc.paragraphs[i]
                style_info = {
                    "style": para.style,
                    "alignment": para.alignment,
                    "runs": [],
                }

                # Save each run format
                for run in para.runs:
                    run_info = {
                        "bold": run.bold,
                        "italic": run.italic,
                        "underline": run.underline,
                        "font_size": run.font.size,
                        "font_name": run.font.name,
                        "color": run.font.color.rgb if run.font.color.rgb else None,
                    }
                    style_info["runs"].append(run_info)

                original_styles.append(style_info)
            else:
                # If original paragraph count is insufficient, use last paragraph style
                if original_styles:
                    original_styles.append(original_styles[-1])
                else:
                    # If no original style, use default style
                    original_styles.append(
                        {"style": None, "alignment": None, "runs": []}
                    )

        # If original style count is insufficient, use last style to fill
        while len(original_styles) < len(new_content):
            if original_styles:
                original_styles.append(original_styles[-1])
            else:
                original_styles.append({"style": None, "alignment": None, "runs": []})

        # Record insert position
        insert_position = start_index

        # Delete from end to avoid index change
        for i in range(end_index - 1, start_index - 1, -1):
            p = doc.paragraphs[i]._element
            p.getparent().remove(p)

        # Add new content, apply original format
        for i, content in enumerate(reversed(new_content)):
            # Create new paragraph
            p = doc.add_paragraph()

            # Apply original paragraph style
            style_info = original_styles[len(new_content) - i - 1]
            if style_info["style"]:
                p.style = style_info["style"]
            if style_info["alignment"] is not None:
                p.alignment = style_info["alignment"]

            # Add text and apply format
            if style_info["runs"] and len(style_info["runs"]) > 0:
                # If multiple runs, try to keep format
                # Simplified processing: Add entire content to a run, apply format from first run
                run = p.add_run(content)
                run_info = style_info["runs"][0]

                run.bold = run_info["bold"]
                run.italic = run_info["italic"]
                run.underline = run_info["underline"]

                if run_info["font_size"]:
                    run.font.size = run_info["font_size"]

                if run_info["font_name"]:
                    run.font.name = run_info["font_name"]
                    # Set East Asian font
                    run._element.rPr.rFonts.set(qn("w:eastAsia"), run_info["font_name"])

                if run_info["color"]:
                    run.font.color.rgb = run_info["color"]
            else:
                # If no run information, add text directly
                p.text = content

            # Move new paragraph to correct position
            doc._body._body.insert(insert_position, p._p)

            # Delete original added paragraph (at end of document)
            doc._body._body.remove(doc.paragraphs[-1]._p)

        return f"Replaced paragraphs containing keyword '{keyword}' and their surrounding content, keeping original format and style"
    except Exception as e:
        error_msg = f"Failed to replace content: {str(e)}"
        logger.error(error_msg)
        traceback.print_exc()  # Print detailed error information
        return error_msg


# Document OCR 도구
@tool("ocr_document")
def ocr_document(
    file_path: str, language: str = "eng+kor", output_file: Optional[str] = None
) -> str:
    """
    PDF나 이미지 문서에서 OCR을 사용하여 텍스트를 추출합니다.

    Parameters:
        file_path: OCR 처리할 문서 경로
        language: OCR 언어 코드 (기본값: eng+kor)
        output_file: 추출한 텍스트를 저장할 파일 경로 (선택사항)

    Returns:
        추출된 텍스트 또는 오류 메시지
    """
    try:
        # 파일 존재 여부 확인
        if not os.path.exists(file_path):
            return f"오류: {file_path} 파일을 찾을 수 없습니다."

        # 파일 확장자로 처리 방법 결정
        file_ext = os.path.splitext(file_path)[1].lower()

        extracted_text = ""

        if file_ext in [".pdf"]:
            # PDF 처리
            try:
                import pdf2image
                import pytesseract

                # PDF를 이미지로 변환
                images = pdf2image.convert_from_path(file_path)

                # 각 페이지를 OCR 처리
                full_text = []
                for i, img in enumerate(images):
                    # OCR 처리
                    page_text = pytesseract.image_to_string(img, lang=language)
                    full_text.append(f"--- 페이지 {i + 1} ---\n{page_text}")

                extracted_text = "\n\n".join(full_text)

            except ImportError:
                return "PDF OCR 처리를 위해 pdf2image와 pytesseract 라이브러리가 필요합니다."

        elif file_ext in [".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"]:
            # 이미지 처리
            try:
                import pytesseract
                from PIL import Image

                # 이미지 로드
                img = Image.open(file_path)

                # OCR 처리
                extracted_text = pytesseract.image_to_string(img, lang=language)

            except ImportError:
                return "이미지 OCR 처리를 위해 pytesseract 라이브러리가 필요합니다."

        else:
            return f"지원하지 않는 파일 형식입니다: {file_ext}"

        # 결과 저장 (선택사항)
        if output_file:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(extracted_text)
            return f"OCR 처리가 완료되었습니다. 결과가 {output_file}에 저장되었습니다."

        return extracted_text

    except Exception as e:
        error_msg = f"OCR 처리 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("detect_document_language")
def detect_document_language(text: str) -> str:
    """
    문서 텍스트의 언어를 감지합니다.

    Parameters:
        text: 언어 감지할 텍스트

    Returns:
        감지된 언어와 신뢰도
    """
    try:
        # 언어 감지를 위한 임포트
        try:
            from langdetect import DetectorFactory, detect

            # 결과 일관성을 위해 시드 설정
            DetectorFactory.seed = 0
        except ImportError:
            return "언어 감지를 위해 langdetect 라이브러리가 필요합니다."

        # 텍스트가 비어있는지 확인
        if not text.strip():
            return "텍스트가 비어있어서 언어를 감지할 수 없습니다."

        # 언어 감지
        lang_code = detect(text)

        # 언어 코드를 이름으로 변환 (주요 언어만)
        language_names = {
            "ko": "한국어 (Korean)",
            "en": "영어 (English)",
            "ja": "일본어 (Japanese)",
            "zh-cn": "중국어 간체 (Chinese Simplified)",
            "zh-tw": "중국어 번체 (Chinese Traditional)",
            "fr": "프랑스어 (French)",
            "de": "독일어 (German)",
            "es": "스페인어 (Spanish)",
            "ru": "러시아어 (Russian)",
            "it": "이탈리아어 (Italian)",
            "vi": "베트남어 (Vietnamese)",
            "th": "태국어 (Thai)",
            "ar": "아랍어 (Arabic)",
        }

        language_name = language_names.get(lang_code, f"알 수 없음 (코드: {lang_code})")

        return f"감지된 언어: {language_name}"

    except Exception as e:
        error_msg = f"언어 감지 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("improve_document_formatting")
def improve_document_formatting() -> str:
    """
    현재 열린 문서의 서식을 개선합니다. 제목 스타일, 여백, 글꼴, 단락 간격 등을 조정합니다.

    Returns:
        서식 개선 결과 또는 오류 메시지
    """
    try:
        if not processor.current_document:
            return "열린 문서가 없습니다."

        doc = processor.current_document

        # 1. 일관된 제목 스타일 적용
        heading_count = 0
        for paragraph in doc.paragraphs:
            # 제목으로 보이는 문단 감지 (짧고, 마침표가 없으며, 대문자로 시작)
            text = paragraph.text.strip()
            if (
                len(text) < 100
                and text
                and "." not in text[:10]
                and (text[0].isupper() or text[0].isdigit())
                and not paragraph.style.name.startswith("Heading")
            ):
                # 문단 길이로 제목 레벨 추정
                if len(text) < 30:
                    paragraph.style = "Heading 1"
                    heading_count += 1
                elif len(text) < 60:
                    paragraph.style = "Heading 2"
                    heading_count += 1

        # 2. 페이지 여백 개선 (가독성 향상을 위한 여백 조정)
        for section in doc.sections:
            section.top_margin = Cm(2.5)
            section.bottom_margin = Cm(2.5)
            section.left_margin = Cm(2.5)
            section.right_margin = Cm(2.5)

        # 3. 글꼴 및 크기 조정 (일관성 향상)
        default_font = "맑은 고딕"  # 또는 Arial, Calibri 등
        default_size = Pt(11)

        for paragraph in doc.paragraphs:
            for run in paragraph.runs:
                run.font.name = default_font
                # 동아시아 언어용 글꼴 설정
                run._element.rPr.rFonts.set(qn("w:eastAsia"), default_font)

                # 제목이 아닌 경우에만 글꼴 크기 변경
                if not paragraph.style.name.startswith("Heading"):
                    run.font.size = default_size

        # 4. 표 서식 개선
        for table in doc.tables:
            table.style = "Table Grid"

            # 모든 셀 테두리 및 여백 조정
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        paragraph.paragraph_format.space_after = Pt(6)

        return f"문서 서식 개선 완료: {heading_count}개의 제목 스타일 적용, 여백 조정, 글꼴 통일화 및 표 서식 개선"

    except Exception as e:
        error_msg = f"문서 서식 개선 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool("extract_document_metadata")
def extract_document_metadata(file_path: Optional[str] = None) -> str:
    """
    문서 메타데이터를 추출합니다.

    Parameters:
        file_path: 메타데이터를 추출할 문서 경로 (선택사항, 없으면 현재 열린 문서 사용)

    Returns:
        추출된 메타데이터 또는 오류 메시지
    """
    try:
        doc = None

        # 파일 경로가 지정된 경우 해당 파일 사용
        if file_path:
            if not os.path.exists(file_path):
                return f"오류: {file_path} 파일을 찾을 수 없습니다."

            doc = Document(file_path)
        else:
            # 현재 열린 문서 사용
            if not processor.current_document:
                return "열린 문서가 없습니다."

            doc = processor.current_document

        # 기본 메타데이터 추출
        metadata = {}

        # 문서 통계 정보
        metadata["paragraphs_count"] = len(doc.paragraphs)
        metadata["sections_count"] = len(doc.sections)
        metadata["tables_count"] = len(doc.tables)

        # 텍스트 양 분석
        text_content = "\n".join([p.text for p in doc.paragraphs])
        metadata["characters_count"] = len(text_content)
        metadata["words_count"] = len(text_content.split())

        # 스타일 분석
        styles_count = {}
        for paragraph in doc.paragraphs:
            style_name = paragraph.style.name
            styles_count[style_name] = styles_count.get(style_name, 0) + 1

        # 가장 많이 사용된 스타일 상위 5개
        top_styles = sorted(styles_count.items(), key=lambda x: x[1], reverse=True)[:5]
        metadata["top_styles"] = top_styles

        # 문서 내용 분석 (제목, 구조 등)
        headings = []
        for paragraph in doc.paragraphs:
            if paragraph.style.name.startswith("Heading"):
                headings.append(
                    {
                        "level": int(paragraph.style.name.split()[-1])
                        if paragraph.style.name[-1].isdigit()
                        else 0,
                        "text": paragraph.text,
                    }
                )

        metadata["headings_count"] = len(headings)
        metadata["headings"] = headings[:10]  # 처음 10개 제목만 표시

        # 결과 출력을 위한 문자열 생성
        result = "# 문서 메타데이터 분석\n\n"

        result += "## 기본 정보\n"
        result += f"- 문단 수: {metadata['paragraphs_count']}\n"
        result += f"- 섹션 수: {metadata['sections_count']}\n"
        result += f"- 표 수: {metadata['tables_count']}\n"
        result += f"- 글자 수: {metadata['characters_count']}\n"
        result += f"- 단어 수: {metadata['words_count']}\n\n"

        result += "## 스타일 분석\n"
        result += "가장 많이 사용된 스타일 (상위 5개):\n"
        for style, count in metadata["top_styles"]:
            result += f"- {style}: {count}개 문단\n"
        result += "\n"

        result += "## 문서 구조\n"
        result += f"제목 수: {metadata['headings_count']}\n"

        if metadata["headings"]:
            result += "주요 제목 구조 (처음 10개):\n"
            for heading in metadata["headings"]:
                indent = "  " * heading["level"]
                result += f"{indent}- {heading['text']}\n"

        return result

    except Exception as e:
        error_msg = f"메타데이터 추출 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg


def get_documentation_tools() -> dict:
    """문서 처리 도구 목록을 반환합니다."""
    return {
        "create_document": create_document,
        "open_document": open_document,
        "save_document": save_document,
        "add_paragraph": add_paragraph,
        "add_heading": add_heading,
        "add_table": add_table,
        "get_document_info": get_document_info,
        "search_text": search_text,
        "search_and_replace": search_and_replace,
        "merge_table_cells": merge_table_cells,
        "add_table_row": add_table_row,
        "edit_table_cell": edit_table_cell,
        "add_page_break": add_page_break,
        "set_page_margins": set_page_margins,
        "save_as_document": save_as_document,
        "delete_paragraph": delete_paragraph,
        "replace_section": replace_section,
        "edit_section_by_keyword": edit_section_by_keyword,
        "ocr_document": ocr_document,
        "detect_document_language": detect_document_language,
        "improve_document_formatting": improve_document_formatting,
        "extract_document_metadata": extract_document_metadata,
    }


# 사용 예시
if __name__ == "__main__":
    from langchain.agents import AgentType, initialize_agent
    from langchain.llms import OpenAI

    # LLM 설정
    llm = OpenAI(temperature=0)

    # 도구 초기화
    tools = get_docx_tools()

    # 에이전트 초기화
    agent = initialize_agent(
        tools,
        llm,
        agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
        verbose=True,
    )

    # 에이전트 실행 예시
    result = agent.run(
        "새 문서를 만들고, '제목' 헤딩을 추가한 다음, '이것은 테스트 문단입니다.'라는 문단을 추가해 주세요."
    )
    print(result)
