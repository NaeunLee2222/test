from langchain.tools import tool


@tool
def startMeetingRecording() -> dict:
    """
    회의록 작성을 위한 녹음을 시작합니다. 유저의 요청에 '회의록 녹음' 에 대한 요청이 명확하게 존재하는 경우에만 사용합니다. 그 외에는 절대 사용하지 않습니다.
    """
    try:
        response = {
            "status": "success",
            "message": "회의록 작성을 위한 녹음을 시작합니다.",
        }
        return response
    except Exception as e:
        return {"status": "error", "error_message": str(e)}


# TODO: 실제 로직 구현
@tool
def getMeetingRecording() -> None:
    """
    저장된 회의록을 불러옵니다.
    """
    return
