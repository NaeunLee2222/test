from enum import Enum
from typing import Any, Dict, List, Optional

import requests
from langchain.tools import BaseTool
from pydantic import BaseModel, Field

from core.config import get_setting
from core.log.logging import get_logging
from database.crud.crud_tool_call import CRUDToolCall
from database.models.tool_call import ToolCall
from database.session import SyncSessionLocal
from services.tool_call_service import create_tool_call

logger = get_logging()
settings = get_setting()


class MeetingTypeEnum(str, Enum):
    offline = "offline"
    teams = "teams"
    zoom = "zoom"
    googleMeet = "googleMeet"
    meetUs = "meetUs"


class AttendTypeEnum(str, Enum):
    none = "none"
    offline = "offline"
    online = "online"


class ParticipantTypeEnum(str, Enum):
    requiredAttendees = "requiredAttendees"
    optionalAttendees = "optionalAttendees"
    organizer = "organizer"


class AttendeeUserInfo(BaseModel):
    userId: str = Field(..., description="사용자 ID (사번, 로그인 ID)")
    userName: Optional[str] = Field(None, description="사용자 이름")
    displayName: Optional[str] = Field(
        None, description="사용자 표시 이름 (사용자이름/부서이름)"
    )
    deptId: Optional[str] = Field(None, description="사용자 부서 ID")
    deptName: Optional[str] = Field(None, description="사용자 부서 표시이름")
    email: Optional[str] = Field(None, description="사용자 메일주소")
    phoneNumber: Optional[str] = Field(None, description="사용자 전화번호")


class Attendee(BaseModel):
    userInfo: AttendeeUserInfo = Field(..., description="참석자 정보")
    attendType: AttendTypeEnum = Field(
        ..., description="참석 방법 (지정되지 않음, 대면, 비대면)"
    )
    participantType: ParticipantTypeEnum = Field(
        ..., description="회의 참석자 구분 (필수참석자, 선택참석자, 주최자)"
    )


class ReservationSchema(BaseModel):
    start: str = Field(..., description="예약 시작 시간")
    end: str = Field(..., description="예약 종료 시간")
    meetingType: MeetingTypeEnum = Field(..., description="회의 형식")
    joinDescription: Optional[str] = Field(None, description="참가 URL이 포함된 정보")
    # TODO: createMeetingroomReservation API 를 API DB에 다시 추가하고, 해당 API spec으로 default값을 관리
    subject: str = Field(..., description="회의 제목 (Default: 업무 협의)")
    description: Optional[str] = Field(None, description="회의 설명")
    attendees: Optional[List[Attendee]] = Field(None, description="회의 참석자 리스트")


class MeetingReserveAndNotifyInput(BaseModel):
    roomId: str = Field(..., description="회의실 번호")
    userId: str = Field(..., description="사용자 아이디")
    reservation: ReservationSchema = Field(
        ...,
        description=("회의실 예약 API 호출을 위한 params. "),
    )


class MeetingReserveAndNotifyTool(BaseTool):
    name: str = "meeting_reserve_and_notify"
    description: str = """Reserves a meeting room and notifies attendees."""

    def __init__(self):
        super().__init__(args_schema=MeetingReserveAndNotifyInput)

    def func(
        self, roomId: int, userId: str, reservation: ReservationSchema
    ) -> Dict[str, Any]:
        """
        Synchronously reserves a meeting room and notifies attendees.
        """
        logger.info("#### Meeting Reserve and Notify Start by run ####")
        logger.info(f"Room ID: {roomId}, User ID: {userId}, Reservation: {reservation}")

        headers = {
            "accept": "application/json",
            "Authorization": settings.MEETING_ROOM_LEGACY_API_KEY,
        }
        response = self._make_reservation(roomId, userId, reservation, headers)
        if response.status_code == 200:
            self._notify_attendees(userId, reservation.dict(), headers)
        return response.json()

    def _run(
        self, roomId: int, userId: str, reservation: ReservationSchema
    ) -> Dict[str, Any]:
        """
        Synchronously reserves a meeting room and notifies attendees.
        """
        logger.info("#### Meeting Reserve and Notify Start by run ####")
        logger.info(f"Room ID: {roomId}, User ID: {userId}, Reservation: {reservation}")

        headers = {
            "accept": "application/json",
            "Authorization": settings.MEETING_ROOM_LEGACY_API_KEY,
        }
        response = self._make_reservation(roomId, userId, reservation.dict(), headers)
        if response.json().get("success") == True:
            self._notify_attendees(userId, reservation.dict(), headers)
        return response.json()

    # def _get_session(self) -> AsyncSession:
    #     """
    #     Create and return a database session using get_async_db.
    #     """
    #     return next(get_db())

    # def _fetch_api_spec(self, api_name: str) -> Dict[str, Any]:
    #     """
    #     Fetch API specification dynamically using the CRUD function.
    #     """
    #     session = self._get_session()
    #     try:
    #         # Use asyncio.run to call the async function in sync context
    #         api_spec = asyncio.run(get_api_spec_by_name(db=session, name=api_name))
    #         if not api_spec:
    #             raise ValueError(f"API specification for {api_name} not found.")
    #         return api_spec
    #     finally:
    #         session.close()

    def _make_reservation(
        self,
        roomId: int,
        userId: str,
        reservation: Dict[str, Any],
        headers: Dict[str, str],
    ) -> requests.Response:
        """
        Make a reservation request.
        """
        # api_spec = self._fetch_api_spec(
        #     api_name="createMeetingRoomReservation(not used)"
        # )
        # reservation_url = api_spec.endpoint.format(roomId=roomId, userId=userId)
        if settings.ENVIRONMENT == "DEV":
            reservation_url = f"http://meetingroomifdev.sktelecom.com/api/v1/meeting/reserveRoom/{roomId}/{userId}"
        else:
            reservation_url = f"http://meetingroomif.sktelecom.com/api/v1/meeting/reserveRoom/{roomId}/{userId}"

        with SyncSessionLocal() as db:
            crud_tool_call = CRUDToolCall()
            tool_call: ToolCall = create_tool_call(
                tool_name="createMeetingRoomReservation",
                tool_service_category="meetingroom",
                request_params=f"roomId: {roomId}, userId: {userId}",
                request_body=reservation,
            )
            created_tool_call = crud_tool_call.upsert_tool_call(db, tool_call)

            logger.info(
                f"API Request - {'createMeetingRoomReservation'} | Method: {'POST'} | Endpoint: {reservation_url} | Headers: {headers} | Params: {f'roomId: {roomId}, userId: {userId}'} | Body: {reservation}"
            )

            response = requests.request(
                method="POST",
                url=reservation_url,
                json=reservation,
                headers=headers,
                timeout=(5, 10),
            )

            logger.info(
                f"API Response - {'createMeetingRoomReservation'} | Status: {response.status_code} | Headers: {dict(response.headers)} | Body: {response.text}"
            )

            response.raise_for_status()
            response_data = response.json()

            crud_tool_call.upsert_tool_call(db, created_tool_call, response_data)

            if response.status_code != 200:
                logger.error(
                    f"Room reservation failed with status {response.status_code}"
                )
                # raise HTTPException(
                #     status_code=response.status_code,
                #     detail=f"Room reservation failed: {response.text}",
                # )
            return response

    # 회의 알림 발송 로직
    def _notify_attendees(
        self, userId: str, reservation: Dict[str, Any], headers: Dict[str, str]
    ) -> None:
        """
        Notifies additional attendees.
        """
        attendees = reservation.get("attendees", [])
        if not attendees:
            return

        for attendee in attendees:
            user_info = attendee.get("userInfo", {})
            participant_type = attendee.get("participantType")
            attendee_id = user_info["userId"]
            if attendee_id != userId and participant_type != "organizer":
                notification_url = f"{settings.AI_CHAT_URI}/api/v1/chats/{attendee_id}/message-notification"
                message = f"You are invited to the meeting: {reservation.get('subject')} from {reservation.get('start')} to {reservation.get('end')}."
                if reservation.get("joinDescription"):
                    message += f" Join details: {reservation['joinDescription']}"
                notification_payload = {
                    "chat_id": "",
                    "noti_type": "simple",
                    "message": message,
                    "notification": {  # notification 필드를 맞춰서 요청
                        "chat_id": "",
                        "noti_type": "simple",
                        "message": message,
                    },
                }
                try:
                    notification_response = requests.request(
                        method="POST",
                        url=notification_url,
                        json=notification_payload,
                        headers=headers,
                    )
                    notification_response.raise_for_status()
                except requests.RequestException as e:
                    logger.error(f"Failed to notify user {attendee_id}: {e}")


# Instantiate the tool
meeting_reserve_and_notify_tool = MeetingReserveAndNotifyTool()
