import ast
from ast import literal_eval
from typing import Any, Dict, Optional, Union

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import AzureChatOpenAI, ChatOpenAI

from client.agent_document_client import AgentDocumentClient
from client.chat_document_client import ChatDocumentClient
from core.log.logging import get_logging
from services.prompt.parameter_converter_prompt import (
    RETRY_SYSTEM_PROMPT,
    SYSTEM_PROMPT,
    USER_PROMPT_TEMPLATE,
    USER_PROMPT_TEMPLATE_RETRY,
    USER_PROMPT_TEMPLATE_RETRY_WITH_DOCUMENT,
    USER_PROMPT_TEMPLATE_WITH_DOCUMENT,
)
from services.prompt.search_query_prompt import (
    SEARCH_QUERY_SYSTEM_PROMPT,
    SEARCH_QUERY_USER_PROMPT_TEMPLATE,
)

logger = get_logging()


class ToolError:
    """도구 실행 실패를 나타내는 객체"""

    def __init__(self, message: str, tool_name: str = None, tool_type: str = None):
        self.message = message
        self.tool_name = tool_name
        self.tool_type = tool_type

    def to_dict(self):
        """JSON serialization을 위한 딕셔너리 변환"""
        return {
            "success": False,
            "error": self.message,
            "message": self.message,
            "tool_name": self.tool_name,
            "tool_type": self.tool_type,
        }


class ToolExecutor:
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        self.llm = llm

    async def _execute_mcp_tool(
        self, tool_info: dict, converted_params: dict = {}
    ) -> Any:
        """MCP 도구 실행"""
        try:
            result = await self._get_mcp_response(tool_info, converted_params)

            # MCP 결과 처리 및 직렬화
            if isinstance(result, str):
                try:
                    # 문자열이 JSON인지 확인하고 파싱 시도
                    import json

                    parsed_result = json.loads(result)

                    # 이미 success 또는 error 필드가 있는 경우 그대로 사용
                    if isinstance(parsed_result, dict) and (
                        "success" in parsed_result or "error" in parsed_result
                    ):
                        return parsed_result
                    else:
                        # success/error 필드가 없는 경우 성공으로 간주하고 추가
                        return {
                            "success": True,
                            "data": parsed_result,
                            "message": "MCP 도구 실행 성공",
                        }
                except (json.JSONDecodeError, TypeError):
                    # JSON 파싱 실패시 문자열을 성공 결과로 감싸기
                    return {
                        "success": True,
                        "data": result,
                        "message": "MCP 도구 실행 성공",
                    }
            elif isinstance(result, dict):
                # 딕셔너리인 경우 success 또는 error 필드 확인
                if "success" in result or "error" in result:
                    # 이미 성공/실패 정보가 있으면 그대로 반환
                    return result
                else:
                    # success/error 필드가 없는 경우 성공으로 간주
                    result["success"] = True
                    if "message" not in result:
                        result["message"] = "MCP 도구 실행 성공"
                    return result
            else:
                # 다른 타입인 경우 성공으로 간주하고 딕셔너리로 감싸기
                return {
                    "success": True,
                    "data": result,
                    "message": "MCP 도구 실행 성공",
                }

        except Exception as e:
            error_message = f"MCP 도구 실행 중 오류 발생: {str(e)}"
            logger.error(f"[Executor] {error_message}")
            return {
                "success": False,
                "error": error_message,
                "message": error_message,
                "tool_name": tool_info.get("name"),
                "tool_type": "mcp",
            }

    def _execute_langchain_tool(
        self, tool_info: dict, converted_params: dict = {}
    ) -> Any:
        """Langchain 도구 실행"""
        try:
            if len(tool_info["config"].get("parameters", [])) == 0:
                tool = self.get_function_tool(tool_info)
                result = tool.invoke(input={})
            else:
                logger.info(
                    f"[Executor] Running LangChain tool with params: {converted_params}"
                )
                tool = self.get_function_tool(tool_info)
                result = tool.invoke(converted_params)

            # 결과 직렬화
            return {
                "success": True,
                "data": result,
                "message": "Langchain 도구 실행 성공",
            }

        except Exception as e:
            error_message = f"Langchain 도구 실행 중 오류 발생: {str(e)}"
            logger.error(f"[Executor] {error_message}")
            return {
                "success": False,
                "error": error_message,
                "message": error_message,
                "tool_name": tool_info.get("name"),
                "tool_type": "langchain",
            }

    def _execute_api_tool(self, tool_info: dict, converted_params: dict = {}) -> Any:
        """API 호출 도구 실행"""
        try:
            logger.info(f"[Executor] Running API tool with params: {converted_params}")

            # TODO: 실제 API 호출 구현 필요
            # 현재는 임시로 성공 결과 반환
            if not converted_params:
                return {
                    "success": False,
                    "error": "API 호출에 필요한 파라미터가 없습니다",
                    "message": "API 호출에 필요한 파라미터가 없습니다",
                    "tool_name": tool_info.get("name"),
                    "tool_type": "api",
                }

            # 결과 직렬화
            return {
                "success": True,
                "data": "API 호출 결과",
                "message": "API 도구 실행 성공",
            }

        except Exception as e:
            error_message = f"API 도구 실행 중 오류 발생: {str(e)}"
            logger.error(f"[Executor] {error_message}")
            return {
                "success": False,
                "error": error_message,
                "message": error_message,
                "tool_name": tool_info.get("name"),
                "tool_type": "api",
            }

    def _execute_llm_tool(self, tool_info: dict, converted_params: dict = {}) -> Any:
        """LLM 도구 실행"""
        try:
            logger.info(f"[Executor] Running LLM tool with params: {converted_params}")

            tool = tool_info.get("tool", {})

            # LLM 도구는 structured_output과 함께 invoke 메서드 사용
            if hasattr(tool, "output_format"):
                structured_llm = self.llm.with_structured_output(tool.output_format)
                result = structured_llm.invoke(
                    input=converted_params,
                    config={"configurable": {"session_id": "default"}},
                )
            else:
                # 일반 LLM 도구는 기본 invoke 사용
                result = self.llm.invoke(
                    input=converted_params,
                    config={"configurable": {"session_id": "default"}},
                )

            # 결과 직렬화
            return {
                "success": True,
                "data": result,
                "message": "LLM 도구 실행 성공",
            }

        except Exception as e:
            error_message = f"LLM 도구 실행 중 오류 발생: {str(e)}"
            logger.error(f"[Executor] {error_message}")
            return {
                "success": False,
                "error": error_message,
                "message": error_message,
                "tool_name": tool_info.get("name"),
                "tool_type": "llm",
            }

    def get_function_tool(self, tool_info: dict) -> Any:
        """도구 정보로부터 실제 도구 객체를 가져오기"""
        tool_name = tool_info.get("name")
        try:
            if tool_name in self.available_tools:
                return self.available_tools[tool_name]
            else:
                return None  # 도구를 찾을 수 없을 때는 None 반환
        except Exception as e:
            logger.error(f"[Executor] Error getting tool {tool_name}: {str(e)}")
            return None

    async def _get_mcp_response(
        self, tool_info: Dict[str, Any], converted_params: dict
    ):
        # endpoint가 문자열인지 확인하고 올바른 형태의 딕셔너리를 생성
        endpoints = {}

        endpoints[tool_info["name"]] = literal_eval(tool_info["endpoint"])

        # 변경된 endpoints 딕셔너리를 사용
        client = MultiServerMCPClient(endpoints)
        tools = await client.get_tools()
        now_tool = [tool for tool in tools if tool.name == tool_info["name"]][0]
        tool_description = now_tool.description
        tool_parameters = now_tool.args_schema

        logger.info(f"[Executor] Tool description: {tool_description}")
        logger.info(f"[Executor] Tool parameters: {tool_parameters}")

        result = await now_tool.ainvoke(converted_params)

        return result

    async def _generate_search_query(
        self,
        tool_info: dict,
        action_description: str,
        user_query: str,
    ) -> str:
        """
        도구 정보와 사용자 질의를 분석하여 RAG 검색에 최적화된 쿼리를 생성합니다.

        Args:
            tool_info: 도구 정보
            action_description: 실행할 작업 설명
            user_query: 사용자 질의
            session_id: 세션 ID

        Returns:
            최적화된 검색 쿼리 문자열
        """
        try:
            # 도구 정보 추출
            tool_name = tool_info.get("name", "")
            tool_config = tool_info.get("config", {})
            tool_description = tool_info.get("description", "")

            # 파라미터 정보 추출
            if isinstance(tool_config, dict):
                tool_parameters = tool_config.get("parameters", [])
                required_params = tool_config.get("required", [])
            else:
                tool_parameters = []
                required_params = []

            # 분리된 프롬프트 사용
            query_optimization_prompt = SEARCH_QUERY_USER_PROMPT_TEMPLATE.format(
                tool_name=tool_name,
                tool_description=tool_description,
                action_description=action_description,
                user_query=user_query,
                tool_parameters=tool_parameters,
                required_params=required_params,
            )

            # LLM을 통해 최적화된 검색 쿼리 생성
            chat_messages = [
                ("system", SEARCH_QUERY_SYSTEM_PROMPT),
                ("human", query_optimization_prompt),
            ]

            try:
                response = await self.llm.ainvoke(chat_messages)
            except Exception as llm_error:
                logger.warning(f"[Executor] LLM call failed: {str(llm_error)}")
                return user_query
            optimized_query = response.content

            # 생성된 쿼리가 문자열인지 확인하고 정리
            if isinstance(optimized_query, str):
                # 불필요한 따옴표나 줄바꿈 제거
                optimized_query = optimized_query.strip().strip('"').strip("'")
                logger.info(
                    f"[Executor] Generated optimized search query: {optimized_query}"
                )
                return optimized_query
            else:
                logger.warning(
                    f"[Executor] Invalid query type, using original user query"
                )
                return user_query

        except Exception as e:
            logger.warning(
                f"[Executor] Failed to generate optimized search query: {str(e)}"
            )
            # 쿼리 생성에 실패한 경우 원본 사용자 질의 반환
            return user_query

    async def execute_tool(self, tool_info: dict, converted_params: dict) -> Any:
        """도구 타입에 따른 실행"""
        # 도구 타입별 실행 함수 매핑
        tool_executors = {
            "mcp": self._execute_mcp_tool,
            "langchain": self._execute_langchain_tool,
            "api": self._execute_api_tool,
            "llm": self._execute_llm_tool,
        }

        try:
            tool_type = tool_info["type"]
            if tool_type in tool_executors:
                logger.info(
                    f"[Executor] Executing {tool_type.upper()} tool: {tool_info['name']}"
                )
                if tool_type == "mcp":
                    return await tool_executors[tool_type](tool_info, converted_params)
                else:
                    return tool_executors[tool_type](tool_info, converted_params)

            # 타입이 없는 경우 에러 발생
            else:
                logger.info(f"[Executor] 알 수 없는 도구 타입: {tool_type}")
                return {
                    "success": False,
                    "error": f"알 수 없는 도구 타입: {tool_type}",
                    "message": f"알 수 없는 도구 타입: {tool_type}",
                    "tool_name": tool_info.get("name"),
                    "tool_type": tool_type,
                }

        except Exception as e:
            error_message = f"도구 실행 중 오류 발생: {str(e)}"
            logger.error(f"[Executor] {error_message}")
            return {
                "success": False,
                "error": error_message,
                "message": error_message,
                "tool_name": tool_info.get("name"),
                "tool_type": tool_info.get("type"),
            }

    async def convert_parameters(
        self,
        tool_info: dict,
        action_description: str,
        history_info: str,
        user_query: str,
        messages_list: list,
        tool_document_mapping: dict,
        chat_id: Optional[str] = None,
        agent_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        # 도구의 설명 및 파라미터 정보 추출
        tool_description = tool_info.get("description", "")
        param_descriptions = {}

        # 파라미터 정보 문자열 구성
        tool_parameters_info = tool_info["config"]
        # LLM을 통한 파라미터 형식 변환
        system_prompt = SYSTEM_PROMPT
        user_prompt = USER_PROMPT_TEMPLATE

        user_prompt_with_document = USER_PROMPT_TEMPLATE_WITH_DOCUMENT

        # rag를 해야되는 경우
        if tool_document_mapping[tool_info["name"]]:

            agent_document_client = AgentDocumentClient()
            chat_document_client = ChatDocumentClient()

            # 최적화된 검색 쿼리 생성
            optimized_search_query = await self._generate_search_query(
                tool_info, action_description, user_query
            )

            logger.info(f"[Executor] Using search query: {optimized_search_query}")

            if agent_id and tool_document_mapping[tool_info["name"]]["agent_documents"]:
                agent_documents = await agent_document_client.vector_search(
                    agent_id,
                    optimized_search_query,
                )
            else:
                agent_documents = ""

            if chat_id and tool_document_mapping[tool_info["name"]]["chat_documents"]:
                chat_documents = await chat_document_client.vector_search(
                    chat_id,
                    optimized_search_query,
                )
            else:
                chat_documents = ""

            retrieved_documents = str(agent_documents) + str(chat_documents)

            user_prompt = user_prompt_with_document.format(
                tool_name=tool_info["name"],
                tool_description=tool_description,
                action_description=action_description,
                tool_parameters_info=tool_parameters_info,
                history_info=history_info,
                user_query=user_query,
                messages_list=messages_list,
                retrieved_documents=retrieved_documents,
            )

        # rag를 하지 않아도 되는 경우
        else:
            user_prompt = user_prompt.format(
                tool_name=tool_info["name"],
                tool_description=tool_description,
                action_description=action_description,
                tool_parameters_info=tool_parameters_info,
                history_info=history_info,
                user_query=user_query,
                messages_list=messages_list,
            )

        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]

        # LLM 호출하여 파라미터 변환
        logger.info(f"[Executor] Converting parameters for {tool_info['name']}")
        try:
            # 파라미터 메타데이터 확인
            if isinstance(tool_parameters_info, str):
                try:
                    import json

                    tool_parameters_info = json.loads(tool_parameters_info)
                except json.JSONDecodeError as e:
                    logger.error(
                        f"[Executor] Failed to parse tool_parameters_info JSON: {str(e)}"
                    )
                    tool_parameters_info = {}

            param_metadata = (
                tool_parameters_info.get("properties", {})
                if isinstance(tool_parameters_info, dict)
                else {}
            )

            if param_metadata:
                # 메타데이터만 있고 값이 없는 경우 LLM으로 변환
                try:
                    response = self.llm.invoke(chat_messages)
                    formatted_params_str = response.content
                except Exception as llm_error:
                    logger.warning(
                        f"[Executor] LLM parameter conversion failed: {str(llm_error)}"
                    )
                    return {}

                # 응답 로깅 (디버깅용)
                logger.info(f"[Executor] Raw LLM response: {formatted_params_str}")

                # 응답 전처리 - 'json' 제거 및 코드 블록 정리
                if isinstance(formatted_params_str, str):
                    # 'json' 접두사 제거
                    if formatted_params_str.strip().lower().startswith("json"):
                        formatted_params_str = formatted_params_str.strip()[4:].strip()
                        logger.info(f"[Executor] Removed 'json' prefix")

                    # 코드 블록 제거
                    if "```" in formatted_params_str:
                        parts = formatted_params_str.split("```")
                        if len(parts) >= 3:  # 코드 블록이 있는 경우
                            # 코드 블록 내용만 사용
                            code_content = parts[1]
                            # 언어 지정자 제거 (예: json, python 등)
                            if "\n" in code_content:
                                first_line, rest = code_content.split("\n", 1)
                                if first_line.strip() in ["json", "python", ""]:
                                    code_content = rest
                            formatted_params_str = code_content.strip()
                            logger.info(f"[Executor] Extracted content from code block")

                # 변환된 파라미터를 딕셔너리로 파싱
                if isinstance(formatted_params_str, str):
                    formatted_params = ast.literal_eval(formatted_params_str)
                else:
                    logger.warning(
                        f"[Executor] Invalid formatted_params_str type: {type(formatted_params_str)}"
                    )
                    return {}

                # None 값을 가진 필드 제거
                formatted_params = {
                    k: v for k, v in formatted_params.items() if v is not None
                }

                logger.info(
                    f"[Executor] Converted parameters from metadata: {formatted_params}"
                )
                return formatted_params
        except Exception as e:
            logger.warning(f"[Executor] Failed to convert parameters: {str(e)}")
            return {}

        # 기본값 반환 (모든 경로에서 값 반환 보장)
        return {}

    async def convert_parameters_for_retry(
        self,
        tool_info: dict,
        action: dict,
        failure_info: dict,
        retry_count: int,
        history_info: str,
        user_query: str,
        messages_list: list,
        tool_document_mapping: dict,
        state: Optional[dict] = None,
        chat_id: Optional[str] = None,
        agent_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        """재시도를 위한 파라미터 변환"""

        logger.info(
            f"[Executor] Converting parameters for retry - tool: {tool_info.get('name')}, attempt: {retry_count}"
        )

        # 도구 정보 추출
        tool_description = tool_info.get("description", "")
        tool_parameters_info = tool_info["config"]

        # 실패 정보 추출
        failure_reason = failure_info.get("failure_reason", "Unknown error")
        original_params = failure_info.get("converted_params", {})

        # 재시도용 액션 설명 생성
        retry_action_description = f"""
재시도 실행 - {action.get('name', 'Unknown Action')}
액션 설명: {action.get('description', 'No description')}

이전 실패 정보:
- 실패 이유: {failure_reason}
- 이전 파라미터: {original_params}
- 재시도 횟수: {retry_count}

이번에는 실패 원인을 고려하여 정확한 파라미터를 생성해주세요.
        """.strip()

        # 기본 시스템 프롬프트
        system_prompt = RETRY_SYSTEM_PROMPT
        user_prompt = USER_PROMPT_TEMPLATE_RETRY
        user_prompt_with_document = USER_PROMPT_TEMPLATE_RETRY_WITH_DOCUMENT

        # RAG 검색이 필요한 경우
        if tool_document_mapping.get(tool_info["name"]):
            agent_document_client = AgentDocumentClient()
            chat_document_client = ChatDocumentClient()

            # 검색 쿼리 생성
            optimized_search_query = await self._generate_search_query(
                tool_info, retry_action_description, user_query
            )

            logger.info(f"[Executor] Retry search query: {optimized_search_query}")

            # 에이전트 문서 검색
            if agent_id and tool_document_mapping[tool_info["name"]]["agent_documents"]:
                agent_documents = await agent_document_client.vector_search(
                    agent_id, optimized_search_query
                )
            else:
                agent_documents = ""

            # 채팅 문서 검색
            if chat_id and tool_document_mapping[tool_info["name"]]["chat_documents"]:
                chat_documents = await chat_document_client.vector_search(
                    chat_id, optimized_search_query
                )
            else:
                chat_documents = ""

            retrieved_documents = str(agent_documents) + str(chat_documents)

            user_prompt = user_prompt_with_document.format(
                tool_name=tool_info["name"],
                tool_description=tool_description,
                action_description=retry_action_description,
                tool_parameters_info=tool_parameters_info,
                history_info=history_info,
                user_query=user_query,
                messages_list=messages_list,
                retrieved_documents=retrieved_documents,
                failure_reason=failure_reason,
                original_params=original_params,
                retry_count=retry_count,
            )

        # RAG 검색이 필요하지 않은 경우
        else:
            user_prompt = user_prompt.format(
                tool_name=tool_info["name"],
                tool_description=tool_description,
                action_description=retry_action_description,
                tool_parameters_info=tool_parameters_info,
                history_info=history_info,
                user_query=user_query,
                messages_list=messages_list,
                failure_reason=failure_reason,
                original_params=original_params,
                retry_count=retry_count,
            )

        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]

        # LLM 호출하여 파라미터 변환
        try:
            # 파라미터 메타데이터 확인
            if isinstance(tool_parameters_info, str):
                try:
                    import json

                    tool_parameters_info = json.loads(tool_parameters_info)
                except json.JSONDecodeError as e:
                    logger.error(
                        f"[Executor] Failed to parse tool_parameters_info JSON: {str(e)}"
                    )
                    tool_parameters_info = {}

            param_metadata = (
                tool_parameters_info.get("properties", {})
                if isinstance(tool_parameters_info, dict)
                else {}
            )

            if param_metadata:
                try:
                    response = await self.llm.ainvoke(chat_messages)
                    formatted_params_str = response.content
                except Exception as llm_error:
                    logger.warning(
                        f"[Executor] LLM parameter conversion failed: {str(llm_error)}"
                    )
                    return {}

                # 응답 로깅 (디버깅용)
                logger.info(f"[Executor] Raw LLM response: {formatted_params_str}")

                # 응답 전처리 - 'json' 제거 및 코드 블록 정리
                if isinstance(formatted_params_str, str):
                    # 'json' 접두사 제거
                    if formatted_params_str.strip().lower().startswith("json"):
                        formatted_params_str = formatted_params_str.strip()[4:].strip()

                    # 코드 블록 제거
                    if "```" in formatted_params_str:
                        parts = formatted_params_str.split("```")
                        if len(parts) >= 3:
                            code_content = parts[1]
                            # 언어 지정자 제거
                            if "\n" in code_content:
                                first_line, rest = code_content.split("\n", 1)
                                if first_line.strip() in ["json", "python", ""]:
                                    code_content = rest
                            formatted_params_str = code_content.strip()

                # 변환된 파라미터를 딕셔너리로 파싱
                if isinstance(formatted_params_str, str):
                    formatted_params = ast.literal_eval(formatted_params_str)
                else:
                    logger.warning(
                        f"[Executor] Invalid formatted_params_str type: {type(formatted_params_str)}"
                    )
                    return {}

                # None 값을 가진 필드 제거
                formatted_params = {
                    k: v for k, v in formatted_params.items() if v is not None
                }

                logger.info(
                    f"[Executor] Retry parameters converted: {formatted_params}"
                )
                return formatted_params

        except Exception as e:
            logger.warning(f"[Executor] Failed to convert retry parameters: {str(e)}")
            return {}

        # 기본값 반환
        return {}
