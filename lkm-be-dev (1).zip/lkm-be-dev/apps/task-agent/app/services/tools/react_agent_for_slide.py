from langchain.agents import AgentExecutor, create_react_agent
from langchain.tools import BaseTool
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field
from typing import Type
import re
from bs4 import BeautifulSoup


correction_prompt = """
You are a helpful assistant that corrects HTML slides.
You will be given a HTML slide, validation results, and a user's request.
You need to correct the HTML slide to meet the user's request.

Here is the HTML slide:
[HTML_CONTENT]

Here is the validation results:
[VALIDATION_RESULTS]

You need to correct the HTML slide to meet the user's request.
You need to return the corrected HTML slide.

return the corrected HTML slide.
"""


class HTMLInput(BaseModel):
    html_content: str = Field(description="검증할 HTML 콘텐츠")


class SlideHTMLInput(BaseModel):
    html_content: str = Field(description="검증할 HTML 콘텐츠")
    slide_number: int = Field(default=1, description="슬라이드 번호")


# 1. 콘텐츠 블록 검증 도구
class ContentBlockValidator(BaseTool):
    name: str = "content_block_validator"
    description: str = (
        "HTML에서 콘텐츠 블록이 최소 3-4개 이상 있는지 검증하고, 각 블록이 제목+설명+수치+하이라이트 구조를 갖는지 확인합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")

            # 콘텐츠 블록 찾기
            content_blocks = soup.find_all(
                ["div", "section", "article"],
                class_=re.compile(r"card|block|item|container|timeline"),
            )

            block_count = len(content_blocks)

            # 각 블록의 구성 요소 분석
            detailed_analysis = []
            for i, block in enumerate(content_blocks):
                has_title = bool(block.find(["h1", "h2", "h3", "h4", "h5", "h6"]))
                has_description = len(block.get_text(strip=True)) > 50
                has_statistics = bool(
                    re.search(
                        r"\d+%|\d+\.\d+|\d+조|\d+억|\d+만|\d+천", block.get_text()
                    )
                )
                has_highlight = bool(
                    block.find(
                        class_=re.compile(r"highlight|emphasis|strong|accent|key")
                    )
                )

                detailed_analysis.append(
                    {
                        "block": i + 1,
                        "title": "✅" if has_title else "❌",
                        "description": "✅" if has_description else "❌",
                        "statistics": "✅" if has_statistics else "❌",
                        "highlight": "✅" if has_highlight else "❌",
                    }
                )

            # 결과 포맷팅
            result = f"📦 콘텐츠 블록 검증 결과:\n"
            result += f"총 블록 수: {block_count}개\n"
            result += (
                f"최소 요구사항(3개): {'✅ 충족' if block_count >= 3 else '❌ 미달'}\n"
            )
            result += f"권장 요구사항(4개): {'✅ 충족' if block_count >= 4 else '❌ 미달'}\n\n"

            result += "블록별 구성 요소 분석:\n"
            for analysis in detailed_analysis:
                result += f"블록 {analysis['block']}: 제목{analysis['title']} 설명{analysis['description']} 수치{analysis['statistics']} 강조{analysis['highlight']}\n"

            if block_count < 3:
                result += f"\n⚠️ 개선 필요: 최소 {3-block_count}개 블록 추가 필요"

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 2. 텍스트 커버리지 검증 도구
class TextCoverageValidator(BaseTool):
    name: str = "text_coverage_validator"
    description: str = (
        "슬라이드의 텍스트 영역이 95% 이상 채워져 있는지 검증하고, 빈 공간이 있는지 확인합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")

            # 슬라이드 요소 찾기
            slide_element = soup.find(class_=re.compile(r"slide"))
            if not slide_element:
                return "❌ 슬라이드 요소를 찾을 수 없음"

            # 전체 텍스트 추출
            total_text = slide_element.get_text(strip=True)
            text_length = len(total_text)

            # 단어 수 계산
            word_count = len(total_text.split())

            # 95% 채우기 기준 (1280x720 기준)
            min_chars = 1500  # 최소 문자 수
            min_words = 200  # 최소 단어 수

            # 커버리지 계산
            char_coverage = min((text_length / min_chars) * 100, 100)
            word_coverage = min((word_count / min_words) * 100, 100)

            result = f"📝 텍스트 커버리지 검증 결과:\n"
            result += f"총 문자 수: {text_length}자\n"
            result += f"총 단어 수: {word_count}개\n"
            result += f"문자 커버리지: {char_coverage:.1f}%\n"
            result += f"단어 커버리지: {word_coverage:.1f}%\n"
            result += (
                f"95% 요구사항: {'✅ 충족' if char_coverage >= 95 else '❌ 미달'}\n"
            )

            # 빈 공간 분석
            empty_divs = soup.find_all("div", string=re.compile(r"^\s*$"))
            if empty_divs:
                result += f"\n⚠️ {len(empty_divs)}개의 빈 div 요소 발견"

            if char_coverage < 95:
                needed_chars = min_chars - text_length
                result += f"\n💡 개선 방안: 약 {needed_chars}자 추가 필요"

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 3. 플레이스홀더 검증 도구
class PlaceholderValidator(BaseTool):
    name: str = "placeholder_validator"
    description: str = (
        "HTML에 플레이스홀더 텍스트가 있는지 검사하고, 실제 콘텐츠가 사용되었는지 확인합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")
            total_text = soup.get_text().lower()

            # 플레이스홀더 패턴들
            placeholder_patterns = [
                (r"lorem ipsum", "Lorem Ipsum 더미 텍스트"),
                (r"placeholder", "플레이스홀더 텍스트"),
                (r"sample text", "샘플 텍스트"),
                (r"dummy text", "더미 텍스트"),
                (r"your content here", "콘텐츠 입력 안내"),
                (r"add content", "콘텐츠 추가 안내"),
                (r"insert text", "텍스트 삽입 안내"),
                (r"테스트.*내용", "테스트 내용"),
                (r"예시.*텍스트", "예시 텍스트"),
                (r"샘플.*데이터", "샘플 데이터"),
                (r"임시.*내용", "임시 내용"),
            ]

            found_placeholders = []
            for pattern, description in placeholder_patterns:
                matches = re.findall(pattern, total_text)
                if matches:
                    found_placeholders.append(
                        {
                            "type": description,
                            "matches": len(matches),
                            "examples": matches[:3],  # 최대 3개 예시
                        }
                    )

            result = f"🔍 플레이스홀더 검증 결과:\n"

            if not found_placeholders:
                result += "✅ 플레이스홀더 없음 - 실제 콘텐츠 사용\n"
            else:
                result += f"❌ {len(found_placeholders)}종류의 플레이스홀더 발견:\n\n"
                for placeholder in found_placeholders:
                    result += f"• {placeholder['type']}: {placeholder['matches']}개\n"
                    if placeholder["examples"]:
                        result += f"  예시: {', '.join(placeholder['examples'][:2])}\n"

                result += "\n💡 개선 방안: 모든 플레이스홀더를 실제 콘텐츠로 교체 필요"

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 4. 아이콘 검증 도구
class IconValidator(BaseTool):
    name: str = "icon_validator"
    description: str = "각 텍스트 블록에 관련 아이콘이 포함되어 있는지 검증합니다."
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")

            # 아이콘 요소 찾기
            icons = soup.find_all("i", class_=re.compile(r"fa|icon"))

            # 텍스트 블록 찾기
            text_blocks = soup.find_all(
                ["div", "section", "article"],
                class_=re.compile(r"card|block|item|timeline"),
            )

            # 각 블록별 아이콘 유무 확인
            blocks_with_icons = 0
            block_analysis = []

            for i, block in enumerate(text_blocks):
                block_icons = block.find_all("i", class_=re.compile(r"fa|icon"))
                has_icon = len(block_icons) > 0
                if has_icon:
                    blocks_with_icons += 1

                # 아이콘 타입 분석
                icon_types = []
                for icon in block_icons:
                    classes = icon.get("class", [])
                    icon_name = " ".join(
                        [cls for cls in classes if cls.startswith("fa-")]
                    )
                    if icon_name:
                        icon_types.append(icon_name)

                block_analysis.append(
                    {
                        "block": i + 1,
                        "has_icon": has_icon,
                        "icon_count": len(block_icons),
                        "icon_types": icon_types,
                    }
                )

            # 커버리지 계산
            icon_coverage = (
                (blocks_with_icons / len(text_blocks)) * 100 if text_blocks else 0
            )

            result = f"🎨 아이콘 검증 결과:\n"
            result += f"총 아이콘 수: {len(icons)}개\n"
            result += f"총 텍스트 블록: {len(text_blocks)}개\n"
            result += f"아이콘이 있는 블록: {blocks_with_icons}개\n"
            result += f"아이콘 커버리지: {icon_coverage:.1f}%\n"
            result += f"요구사항(80% 이상): {'✅ 충족' if icon_coverage >= 80 else '❌ 미달'}\n\n"

            result += "블록별 아이콘 분석:\n"
            for analysis in block_analysis:
                status = "✅" if analysis["has_icon"] else "❌"
                result += (
                    f"블록 {analysis['block']}: {status} ({analysis['icon_count']}개)"
                )
                if analysis["icon_types"]:
                    result += f" - {', '.join(analysis['icon_types'][:2])}"
                result += "\n"

            if icon_coverage < 80:
                missing_blocks = len(text_blocks) - blocks_with_icons
                result += f"\n💡 개선 방안: {missing_blocks}개 블록에 아이콘 추가 필요"

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 5. 리스트 아이템 검증 도구
class ListItemValidator(BaseTool):
    name: str = "list_item_validator"
    description: str = (
        "리스트 아이템이 4-6개 범위에 있고, 각각 상세 설명을 포함하는지 검증합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")

            # 리스트 요소들 찾기
            lists = soup.find_all(["ul", "ol"])
            all_items = soup.find_all("li")

            result = f"📋 리스트 아이템 검증 결과:\n"
            result += f"총 리스트 수: {len(lists)}개\n"
            result += f"총 아이템 수: {len(all_items)}개\n"

            # 각 리스트별 분석
            list_analysis = []
            for i, ul_ol in enumerate(lists):
                items = ul_ol.find_all("li")
                item_details = []

                for item in items:
                    text = item.get_text(strip=True)
                    has_detail = len(text) > 30  # 상세 설명 기준
                    item_details.append(
                        {
                            "text": text[:50] + "..." if len(text) > 50 else text,
                            "length": len(text),
                            "has_detail": has_detail,
                        }
                    )

                items_with_detail = sum(
                    1 for item in item_details if item["has_detail"]
                )

                list_info = {
                    "list_num": i + 1,
                    "item_count": len(items),
                    "meets_minimum": len(items) >= 4,
                    "meets_maximum": len(items) <= 6,
                    "items_with_detail": items_with_detail,
                    "detail_ratio": (
                        (items_with_detail / len(items)) * 100 if items else 0
                    ),
                    "items": item_details,
                }
                list_analysis.append(list_info)

            # 전체 평가
            total_items = len(all_items)
            meets_count_req = 4 <= total_items <= 6

            result += f"아이템 수 요구사항(4-6개): {'✅ 충족' if meets_count_req else '❌ 미달'}\n\n"

            # 리스트별 상세 분석
            for analysis in list_analysis:
                result += f"리스트 {analysis['list_num']}:\n"
                result += f"  아이템 수: {analysis['item_count']}개\n"
                result += f"  상세 설명 비율: {analysis['detail_ratio']:.1f}%\n"
                result += f"  수량 기준: {'✅' if analysis['meets_minimum'] and analysis['meets_maximum'] else '❌'}\n"

                # 각 아이템 미리보기
                for j, item in enumerate(analysis["items"][:3]):  # 최대 3개만 표시
                    detail_status = "✅" if item["has_detail"] else "❌"
                    result += f"    {j+1}. {detail_status} {item['text']} ({item['length']}자)\n"

                if len(analysis["items"]) > 3:
                    result += f"    ... 외 {len(analysis['items'])-3}개\n"
                result += "\n"

            # 개선 방안
            if not meets_count_req:
                if total_items < 4:
                    result += f"💡 개선 방안: {4-total_items}개 아이템 추가 필요\n"
                elif total_items > 6:
                    result += f"💡 개선 방안: {total_items-6}개 아이템 제거 필요\n"

            # 상세 설명 부족한 아이템 체크
            items_needing_detail = []
            for analysis in list_analysis:
                for item in analysis["items"]:
                    if not item["has_detail"]:
                        items_needing_detail.append(item["text"])

            if items_needing_detail:
                result += (
                    f"💡 상세 설명 추가 필요: {len(items_needing_detail)}개 아이템\n"
                )

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 6. 빈 요소 검증 도구
class EmptyElementValidator(BaseTool):
    name: str = "empty_element_validator"
    description: str = (
        "HTML에서 빈 내용을 가진 요소가 있는지 검사하고, 모든 요소가 의미있는 내용을 가지고 있는지 확인합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")

            # 검사할 요소들
            content_elements = soup.find_all(
                [
                    "div",
                    "section",
                    "article",
                    "p",
                    "span",
                    "h1",
                    "h2",
                    "h3",
                    "h4",
                    "h5",
                    "h6",
                ]
            )

            empty_elements = []
            suspicious_elements = []

            for element in content_elements:
                text_content = element.get_text(strip=True)
                child_elements = element.find_all()

                # 완전히 빈 요소
                if not text_content and not child_elements:
                    empty_elements.append(
                        {
                            "tag": element.name,
                            "class": " ".join(element.get("class", [])),
                            "id": element.get("id", ""),
                            "location": str(element)[:100] + "...",
                        }
                    )

                # 의심스러운 요소 (텍스트가 너무 짧음)
                elif text_content and len(text_content) < 5:
                    suspicious_elements.append(
                        {
                            "tag": element.name,
                            "text": text_content,
                            "length": len(text_content),
                        }
                    )

            result = f"🔍 빈 요소 검증 결과:\n"
            result += f"검사한 요소 수: {len(content_elements)}개\n"
            result += f"빈 요소 수: {len(empty_elements)}개\n"
            result += f"의심스러운 요소 수: {len(suspicious_elements)}개\n"

            if not empty_elements and not suspicious_elements:
                result += "✅ 모든 요소가 적절한 내용을 포함\n"
            else:
                result += "❌ 문제 요소 발견\n\n"

                # 빈 요소 상세 정보
                if empty_elements:
                    result += "완전히 빈 요소들:\n"
                    for i, elem in enumerate(empty_elements[:5]):  # 최대 5개만 표시
                        result += f"  {i+1}. <{elem['tag']}> "
                        if elem["class"]:
                            result += f"class='{elem['class']}' "
                        if elem["id"]:
                            result += f"id='{elem['id']}' "
                        result += "\n"

                    if len(empty_elements) > 5:
                        result += f"  ... 외 {len(empty_elements)-5}개\n"
                    result += "\n"

                # 의심스러운 요소들
                if suspicious_elements:
                    result += "내용이 부족한 요소들:\n"
                    for i, elem in enumerate(suspicious_elements[:5]):
                        result += f"  {i+1}. <{elem['tag']}>: \"{elem['text']}\" ({elem['length']}자)\n"

                    if len(suspicious_elements) > 5:
                        result += f"  ... 외 {len(suspicious_elements)-5}개\n"

                result += "\n💡 개선 방안: 빈 요소 제거 또는 적절한 내용 추가"

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 7. Chart.js 검증 도구
class ChartJSValidator(BaseTool):
    name: str = "chartjs_validator"
    description: str = (
        "Chart.js 2.9.4 호환성, 필수 옵션, 차트 ID 패턴, 허용된 차트 타입을 검증합니다."
    )
    args_schema: Type[BaseModel] = SlideHTMLInput

    def _run(self, html_content: str, slide_number: int = 1) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")

            # Canvas 요소 찾기
            canvas_elements = soup.find_all("canvas")
            script_tag = soup.find("script")
            script_content = script_tag.get_text() if script_tag else ""

            result = f"📊 Chart.js 검증 결과:\n"
            result += f"차트 수: {len(canvas_elements)}개\n"

            if not canvas_elements:
                result += "ℹ️ 차트가 없음 - 차트가 필요한 경우 추가하세요\n"
                return result

            # 1. Chart.js 버전 확인
            version_check = "Chart.js/2.9.4" in html_content
            result += (
                f"Chart.js 2.9.4 버전: {'✅ 사용' if version_check else '❌ 미사용'}\n"
            )

            # 2. 필수 옵션 확인
            responsive_check = "responsive: true" in script_content
            aspect_ratio_check = "maintainAspectRatio: false" in script_content
            result += (
                f"responsive: true: {'✅ 설정' if responsive_check else '❌ 누락'}\n"
            )
            result += f"maintainAspectRatio: false: {'✅ 설정' if aspect_ratio_check else '❌ 누락'}\n"

            # 3. 허용된 차트 타입 확인
            allowed_types = ["line", "bar", "pie", "doughnut"]
            chart_types = re.findall(r"type:\s*['\"](\w+)['\"]", script_content)
            prohibited_types = [t for t in chart_types if t not in allowed_types]

            result += (
                f"차트 타입: {', '.join(chart_types) if chart_types else '없음'}\n"
            )
            if prohibited_types:
                result += f"❌ 금지된 차트 타입: {', '.join(prohibited_types)}\n"
            else:
                result += f"✅ 허용된 차트 타입만 사용\n"

            # 4. 차트 ID 패턴 확인
            result += "\n차트별 상세 분석:\n"
            id_issues = []

            for i, canvas in enumerate(canvas_elements):
                canvas_id = canvas.get("id", "")
                expected_id = f"chart{slide_number}_{i+1}"
                id_correct = canvas_id == expected_id

                result += f"  차트 {i+1}:\n"
                result += f"    ID: {canvas_id}\n"
                result += f"    예상 ID: {expected_id}\n"
                result += f"    ID 일치: {'✅' if id_correct else '❌'}\n"

                if not id_correct:
                    id_issues.append(f"차트 {i+1} ID 불일치")

                # 해당 차트의 JavaScript 코드 존재 확인
                chart_code_exists = f"getElementById('{canvas_id}')" in script_content
                result += f"    JavaScript 코드: {'✅ 존재' if chart_code_exists else '❌ 누락'}\n"

            # 5. 종합 평가
            total_checks = 3 + len(canvas_elements)  # 버전, 옵션들, ID 체크
            passed_checks = sum(
                [
                    version_check,
                    responsive_check,
                    aspect_ratio_check,
                    len(id_issues) == 0,
                ]
            )

            result += f"\n종합 점수: {passed_checks}/{total_checks}\n"

            # 개선 방안
            improvements = []
            if not version_check:
                improvements.append("Chart.js 2.9.4 버전 사용")
            if not responsive_check:
                improvements.append("responsive: true 옵션 추가")
            if not aspect_ratio_check:
                improvements.append("maintainAspectRatio: false 옵션 추가")
            if id_issues:
                improvements.append(f"차트 ID를 chart{slide_number}_N 패턴으로 수정")
            if prohibited_types:
                improvements.append(
                    f"차트 타입을 {', '.join(allowed_types)} 중 하나로 변경"
                )

            if improvements:
                result += f"\n💡 개선 필요사항:\n"
                for improvement in improvements:
                    result += f"  • {improvement}\n"
            else:
                result += "\n✅ 모든 Chart.js 요구사항 충족\n"

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 8. 레이아웃 및 크기 검증 도구
class LayoutSizeValidator(BaseTool):
    name: str = "layout_size_validator"
    description: str = (
        "1280x720px 크기 준수, 16:9 비율 오버플로우 방지, 다양한 레이아웃 사용을 검증합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            soup = BeautifulSoup(html_content, "html.parser")
            style_tag = soup.find("style")
            css_content = style_tag.get_text() if style_tag else ""

            result = f"📐 레이아웃 및 크기 검증 결과:\n"

            # 1. 슬라이드 크기 확인
            width_check = (
                "width: 1280px" in css_content or "width:1280px" in css_content
            )
            height_check = (
                "height: 720px" in css_content or "height:720px" in css_content
            )

            result += f"1280px 너비: {'✅ 설정' if width_check else '❌ 누락'}\n"
            result += f"720px 높이: {'✅ 설정' if height_check else '❌ 누락'}\n"

            # 2. 오버플로우 방지 확인
            overflow_hidden = (
                "overflow: hidden" in css_content or "overflow:hidden" in css_content
            )
            result += (
                f"오버플로우 방지: {'✅ 설정' if overflow_hidden else '❌ 누락'}\n"
            )

            # 3. 레이아웃 다양성 확인
            layout_patterns = {
                "CSS Grid": bool(
                    re.search(r"display:\s*grid|grid-template", css_content)
                ),
                "Flexbox": bool(re.search(r"display:\s*flex", css_content)),
                "Float": bool(re.search(r"float:\s*(left|right)", css_content)),
                "Position": bool(
                    re.search(r"position:\s*(absolute|relative|fixed)", css_content)
                ),
                "단순 좌우분할": bool(re.search(r"width:\s*50%", css_content)),
            }

            result += "\n레이아웃 기법 사용 현황:\n"
            used_layouts = []
            for layout, used in layout_patterns.items():
                status = "✅ 사용" if used else "❌ 미사용"
                result += f"  {layout}: {status}\n"
                if used:
                    used_layouts.append(layout)

            # 4. 레이아웃 다양성 평가
            layout_score = len(used_layouts)
            if layout_score >= 2:
                layout_diversity = "✅ 다양함"
            elif layout_score == 1 and "단순 좌우분할" not in used_layouts:
                layout_diversity = "⚠️ 보통"
            else:
                layout_diversity = "❌ 단조로움"

            result += f"\n레이아웃 다양성: {layout_diversity} ({layout_score}개 기법)\n"

            # 5. 반응형 설계 확인
            responsive_patterns = {
                "box-sizing": "box-sizing: border-box" in css_content,
                "상대단위": bool(re.search(r"(em|rem|%|vh|vw)", css_content)),
                "미디어쿼리": "@media" in css_content,
            }

            result += "\n반응형 설계 요소:\n"
            for pattern, used in responsive_patterns.items():
                status = "✅ 사용" if used else "❌ 미사용"
                result += f"  {pattern}: {status}\n"

            # 6. 종합 평가
            total_checks = 6  # 크기(2) + 오버플로우(1) + 레이아웃다양성(1) + 반응형(2)
            passed_checks = sum(
                [
                    width_check,
                    height_check,
                    overflow_hidden,
                    layout_score >= 2,
                    responsive_patterns["box-sizing"],
                    responsive_patterns["상대단위"]
                    or responsive_patterns["미디어쿼리"],
                ]
            )

            result += f"\n종합 점수: {passed_checks}/{total_checks}\n"

            # 개선 방안
            improvements = []
            if not width_check or not height_check:
                improvements.append("슬라이드 크기를 1280x720px로 설정")
            if not overflow_hidden:
                improvements.append("overflow: hidden 설정 추가")
            if layout_score < 2:
                improvements.append("Grid 또는 Flexbox 등 현대적 레이아웃 기법 사용")
            if not responsive_patterns["box-sizing"]:
                improvements.append("box-sizing: border-box 설정 추가")

            if improvements:
                result += f"\n💡 개선 필요사항:\n"
                for improvement in improvements:
                    result += f"  • {improvement}\n"
            else:
                result += "\n✅ 모든 레이아웃 요구사항 충족\n"

            return result

        except Exception as e:
            return f"❌ 검증 중 오류: {str(e)}"


# 9. 금지사항 검증 도구
class ProhibitedItemValidator(BaseTool):
    name: str = "prohibited_item_validator"
    description: str = (
        "금지된 요소들(좌우분할만 사용, 금지된 차트타입, 높이불일치 등)이 있는지 검증합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput


def _run(self, html_content: str) -> str:
    try:
        soup = BeautifulSoup(html_content, "html.parser")
        style_tag = soup.find("style")
        css_content = style_tag.get_text() if style_tag else ""
        script_tag = soup.find("script")
        script_content = script_tag.get_text() if script_tag else ""

        violations = []
        result = f"🚫 금지사항 검증 결과:\n"

        # 1. 좌우 분할 레이아웃만 사용하는지 확인
        has_grid = bool(re.search(r"display:\s*grid|grid-template", css_content))
        has_flex = bool(re.search(r"display:\s*flex", css_content))
        has_two_column = bool(re.search(r"width:\s*50%", css_content))

        if has_two_column and not has_grid and not has_flex:
            violations.append("좌우 분할 레이아웃만 사용 (다양한 레이아웃 필요)")

        # 2. 금지된 차트 타입 확인
        prohibited_chart_types = ["radar", "scatter", "bubble", "polarArea", "area"]
        found_prohibited = []
        for chart_type in prohibited_chart_types:
            if (
                f"type: '{chart_type}'" in script_content
                or f'type: "{chart_type}"' in script_content
            ):
                found_prohibited.append(chart_type)

        if found_prohibited:
            violations.append(f"금지된 차트 타입 사용: {', '.join(found_prohibited)}")

        # 3. 16:9 비율 오버플로우 확인
        if "overflow: hidden" not in css_content:
            violations.append("16:9 비율 오버플로우 방지 설정 없음")

        # 4. 높이 불일치 섹션 확인 (대략적 검사)
        if "height: 720px" not in css_content:
            violations.append("슬라이드 높이가 720px로 설정되지 않음")

        # 5. 내용과 무관한 차트 타입 사용 확인
        text_content = soup.get_text().lower()
        chart_types_in_script = re.findall(r"type:\s*['\"](\w+)['\"]", script_content)

        # 텍스트 내용과 차트 타입의 관련성 체크 (간단한 키워드 매칭)
        content_keywords = {
            "line": ["추세", "변화", "시간", "증가", "감소", "년도"],
            "bar": ["비교", "순위", "크기", "양", "개수", "점유율"],
            "pie": ["비율", "구성", "분포", "할당", "퍼센트", "%"],
            "doughnut": ["비율", "구성", "분포", "할당", "퍼센트", "%"],
        }

        irrelevant_charts = []
        for chart_type in chart_types_in_script:
            if chart_type in content_keywords:
                keywords = content_keywords[chart_type]
                if not any(keyword in text_content for keyword in keywords):
                    irrelevant_charts.append(chart_type)

        if irrelevant_charts:
            violations.append(
                f"내용과 무관한 차트 타입: {', '.join(irrelevant_charts)}"
            )

        # 6. 텍스트 영역 빈 공간 방치 확인
        empty_divs = soup.find_all("div", string=re.compile(r"^\s*$"))
        if len(empty_divs) > 2:  # 2개 초과시 문제로 판단
            violations.append(f"텍스트 영역 빈 공간 방치 ({len(empty_divs)}개 빈 div)")

        # 7. 빈 내용 요소 확인
        content_elements = soup.find_all(
            ["div", "section", "p", "span"],
            class_=re.compile(r"card|block|content"),
        )
        empty_content_elements = []
        for element in content_elements:
            if not element.get_text(strip=True) and not element.find_all(
                ["img", "canvas", "svg"]
            ):
                empty_content_elements.append(element.name)

        if empty_content_elements:
            violations.append(f"빈 내용 요소 존재 ({len(empty_content_elements)}개)")

        # 결과 출력
        if not violations:
            result += "✅ 금지사항 없음 - 모든 규칙 준수\n"
        else:
            result += f"❌ {len(violations)}개 위반사항 발견:\n\n"
            for i, violation in enumerate(violations, 1):
                result += f"  {i}. {violation}\n"

            result += "\n💡 개선 방안:\n"
            improvements = {
                "좌우 분할": "CSS Grid 또는 Flexbox 사용",
                "금지된 차트": "line, bar, pie, doughnut 중 하나 사용",
                "오버플로우": "overflow: hidden 설정 추가",
                "높이": "슬라이드 높이를 720px로 설정",
                "무관한 차트": "콘텐츠에 맞는 차트 타입 선택",
                "빈 공간": "모든 영역에 의미있는 콘텐츠 배치",
                "빈 내용": "모든 요소에 적절한 내용 추가",
            }

            for violation in violations:
                for key, improvement in improvements.items():
                    if key in violation:
                        result += f"  • {improvement}\n"
                        break

        return result

    except Exception as e:
        return f"❌ 검증 중 오류: {str(e)}"


# 10. 종합 점수 계산 도구
class OverallScoreCalculator(BaseTool):
    name: str = "overall_score_calculator"
    description: str = (
        "모든 검증 결과를 종합하여 전체 점수와 우선순위별 개선사항을 제공합니다."
    )
    args_schema: Type[BaseModel] = HTMLInput

    def _run(self, html_content: str) -> str:
        try:
            # 각 검증 도구 실행
            tools = [
                ContentBlockValidator(),
                TextCoverageValidator(),
                PlaceholderValidator(),
                IconValidator(),
                ListItemValidator(),
                EmptyElementValidator(),
                LayoutSizeValidator(),
            ]

            total_score = 0
            max_score = 0

            result = f"종합 검증 결과\n"

            # 각 도구별 점수 계산
            category_scores = {}

            for tool in tools:
                tool_result = tool._run(html_content)
                tool_name = tool.name.replace("_", " ").title()

                # 간단한 점수 계산 (✅ 개수 vs ❌ 개수)
                passed = tool_result.count("✅")
                failed = tool_result.count("❌")
                total_checks = passed + failed

                if total_checks > 0:
                    score = (passed / total_checks) * 100
                else:
                    score = 100  # 검사할 항목이 없으면 만점

                category_scores[tool_name] = {
                    "score": score,
                    "passed": passed,
                    "failed": failed,
                    "total": total_checks,
                    "details": tool_result,
                }

                total_score += score
                max_score += 100

            # 전체 평균 점수
            overall_score = total_score / len(tools) if tools else 0

            result += f"🎯 전체 점수: {overall_score:.1f}/100\n"

            # 등급 계산
            if overall_score >= 90:
                grade = "A+ (우수)"
            elif overall_score >= 80:
                grade = "A (양호)"
            elif overall_score >= 70:
                grade = "B (보통)"
            elif overall_score >= 60:
                grade = "C (미흡)"
            else:
                grade = "D (부족)"

            result += f"등급: {grade}\n\n"

            # 카테고리별 점수 표시
            result += "카테고리별 점수:\n"
            sorted_categories = sorted(
                category_scores.items(), key=lambda x: x[1]["score"], reverse=True
            )

            for category, data in sorted_categories:
                result += f"  {category:20} {data['score']:5.1f}%\n"

            # 우선순위별 개선사항
            result += f"\n우선순위별 개선사항:\n"

            # 점수가 낮은 순서로 정렬
            low_score_categories = [
                (cat, data) for cat, data in sorted_categories if data["score"] < 80
            ]

            if not low_score_categories:
                result += "모든 카테고리가 우수한 점수입니다!\n"
            else:
                priority_levels = ["긴급", "중요", "일반"]

                for i, (category, data) in enumerate(low_score_categories[:3]):
                    if i < len(priority_levels):
                        priority = priority_levels[i]
                        result += f"\n{priority} - {category} ({data['score']:.1f}%):\n"

                        # 해당 카테고리의 상세 결과에서 개선사항 추출
                        details = data["details"]
                        if "💡" in details:
                            improvement_section = (
                                details.split("💡")[1] if "💡" in details else ""
                            )
                            if improvement_section:
                                lines = improvement_section.split("\n")[:3]  # 최대 3줄
                                for line in lines:
                                    if line.strip():
                                        result += f"    • {line.strip()}\n"

            # 강점 분석
            high_score_categories = [
                (cat, data) for cat, data in sorted_categories if data["score"] >= 90
            ]
            if high_score_categories:
                result += f"\n우수한 영역:\n"
                for category, data in high_score_categories[:3]:
                    result += f"  • {category}: {data['score']:.1f}%\n"

            # 다음 단계 제안

            return result

        except Exception as e:
            return f"❌ 종합 점수 계산 중 오류: {str(e)}"


# 모든 도구를 리스트로 제공
def get_all_validation_tools():
    """React Agent에서 사용할 모든 검증 도구들을 반환"""
    return [
        ContentBlockValidator(),
        TextCoverageValidator(),
        PlaceholderValidator(),
        IconValidator(),
        ListItemValidator(),
        EmptyElementValidator(),
        ChartJSValidator(),
        LayoutSizeValidator(),
    ]
