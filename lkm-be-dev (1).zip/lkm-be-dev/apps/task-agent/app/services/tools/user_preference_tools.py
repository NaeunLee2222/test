import json

import requests
from core.config import get_setting
from core.llm import get_model
from core.log.logging import get_logging
from langchain.tools import tool
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field

settings = get_setting()
logger = get_logging()
llm = get_model()


@tool("preferred_info")
def get_preferred_info(user_query: str) -> str:
    """
    선호 회의실 내용이 있을때, 선호 회의실 정보를 도출하는 도구입니다.
    Args:
        user_prompt: 사용자 질의(string)
    Returns:
        선호회의실 정보가 포함된 string
    """

    class PreferredInfo(BaseModel):
        """
        선호정보 입력값
        """

        user_id: str = Field(alias="user_id", description="사용자의 userid 사번")
        meetingroomid: str = Field(alias="meetingroomid", description="선호 회의실명")
        floorid: str = Field(alias="floorid", description="선호 층")
        time: str = Field(alias="time", description="선호 시간")

    structured_llm = llm.with_structured_output(PreferredInfo)

    systemprompt = """You need to identify user preference information from the given [User Query]. 
    The response should consist of only words, not sentences, and include values such as ID and time.
    Preferred time type must be 24-hour format.

    [User Query]
    {user_query}
    """
    prompt = PromptTemplate.from_template(systemprompt)
    chain = prompt | structured_llm
    result = chain.invoke({"user_query": user_query})
    logger.info(f"[Preferred Info]: {result}")
    res = send_profile_ai_chat(result)
    logger.info(f"[Preferred Info Response]: {res}")
    return result


def send_profile_ai_chat(data: str) -> str:
    try:
        response = requests.put(
            # f"{settings.AI_CHAT_HOST}:{settings.AI_CHAT_APP_PORT}/{data['user_id']}/profile",
            f"{settings.AI_CHAT_URI}/api/v1/user/{data['user_id']}/profile",
            json={"profile": str(data)},
            timeout=10,
        )
        (response.raise_for_status(),)  # HTTP 에러 체크
        return response.json()  # JSON 응답 반환
    except requests.exceptions.RequestException as e:
        logger.error(f"Request failed: {e}")
        return None


def preferred_info_format(data: str) -> str:
    # JSON 키 mapping
    key_mapping = {
        "user_id": "사번",
        "meetingroomid": "회의실명",
        "floorid": "층",
        "time": "시간",
    }

    # JSON string-> Python Dict
    if isinstance(data, str):
        try:
            # JSON 문자열인 경우 JSON으로 파싱
            data = json.loads(data)
        except json.JSONDecodeError:
            # 일반 문자열인 경우 그대로 반환
            return f"{data}"

    # Markdown
    markdown_output = "\n".join(
        f"- **{key_mapping.get(key, key)}**: {value if value else '정보 없음'}"
        for key, value in data.items()
    )

    return markdown_output
