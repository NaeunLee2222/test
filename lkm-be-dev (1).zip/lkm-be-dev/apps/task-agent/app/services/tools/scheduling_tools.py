from datetime import datetime
from typing import List

from langchain.tools import tool
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field

from core.config import get_setting
from core.llm import get_model
from services.tools.scheduling_utils import (
    available_checker,
    get_time_range,
    round_up_to_nearest_30,
    run_find_meeting_times,
    run_get_schedule,
)

settings = get_setting()
llm = get_model()


def get_common_free_times(now: datetime, attendees_schedule: str) -> str:
    class FreeTime(BaseModel):
        free_time: List[List[str]] = Field(
            description="일정에서 공통으로 빈 시간의 start_time과, end_time시간. 단, 현재 시간 기준."
        )
        # reason: str = Field(description="free_tim의 답변이 나온 이유")

    structured_llm = llm.with_structured_output(FreeTime)
    template = """Remember the current time is {now}.
    Given the working hours of 9:00 AM to 6:00 PM, and the status of attendees, extract the common free times. The statuses are as follows:

    Attendees Schedule:
    {attendees_schedule}

    Please calculate the common free times when both attendees are available during the working hours from 9:00 AM to 6:00 PM.
    The output should be only the common free times in the format: start time - end time.

    Common Free Times:
    """
    prompt = PromptTemplate.from_template(template)
    chain = prompt | structured_llm
    result = chain.invoke(
        {
            "now": now.replace(
                hour=now.time().hour + 1, minute=0, second=0, microsecond=0
            ),
            "attendees_schedule": attendees_schedule,
        }
    )
    result = result.model_dump()
    
    return result["free_time"]


def suggestion_llm(
    now,
    my_schedule: str,
    attendees: List[str],
    common_free_time: str,
    meeting_duration: int,
) -> str:
    template = """당신은 요청자와 참석자들의 일정을 고려하여 가장 빠른 회의 일정을 조율하는 스마트 어시스턴트입니다. 아래 정보를 바탕으로 최적의 일정을 제안하세요.

    [정보]
    - 요청자 일정: {my_schedule} (비어있다면, 모든 시간이 가능함)
    - 희망 회의 시간 (분): {meeting_duration}
    - 참석자 가능 시간: {common_free_time} (비어있다면, 모든 시간이 가능함)
    - 현재 시각: {now}
        
    [역할]
    1. 공통 가능한 시간대 찾기: 요청자와 참석자들의 공통 가능한 시간 중, 희망 회의 시간을 충족하는 가장 빠른 시간대를 선택하세요.
    (*날짜가 포함된 경우, 가독성을 높이기 위해 한국식으로 표기하세요. 예: 4월 3일 오후 3시 - 4시*)  
    2. 현재 시각 이후의 일정만 고려: 과거 시간은 제외하고, 오늘/내일 등의 일정도 반드시 현재 시각을 기준으로 판단할 것.
    3. 가장 빠른 일정 우선:
        - 가능한 시간이 여러 개라면 가장 이른 시간을 추천하세요.
        - 단, 시간이 30분 단위가 아닐 경우, 가장 가까운 다음 30분 단위(예: 14:33 → 15:00)로 조정하세요.
        - 회의 시간이 30분 이상 필요한 경우, 조정된 시작 시간 이후로 연속된 가능한 시간을 확보해야 합니다.
    4. 공통 가능한 시간이 없는 경우: 적절한 안내를 제공하고, 일정 조율을 위한 대안을 제시하세요.
    5. 사용자의 선택 유도:
        - 회의 일정을 확정할 때, '일정 등록'과 '회의실 예약' 중 원하는 옵션을 명확히 질문하세요.
        - '회의실 예약'을 선택하면 ‘일정 등록’이 자동 적용되므로, 둘 다 원하면 '회의실 예약'을 선택하도록 안내하세요.
        - 질문 형식은 더 자연스럽게 정리하세요.
    
    💡 [출력 형식 예시]
    
    📝 회의 참석자: {attendees}

    📅 가장 빠른 회의 가능 일정: [your answer]

    이 일정으로 📌 ‘일정 등록’만 하실까요, 아니면 🏢 ‘회의실 예약’까지 진행할까요?
    (참고: 회의실 예약을 하면 일정 등록도 자동 적용됩니다.)

    """
    prompt = PromptTemplate.from_template(template)
    chain = prompt | llm
    result = chain.invoke(
        {
            "now": now,
            "my_schedule": my_schedule,
            "attendees": attendees,
            "common_free_time": common_free_time,
            "meeting_duration": meeting_duration,
        }
    )
    return result.content


def paraphrase_llm(
    now,
    attendees: List[str],
    time_slots: List[str],
) -> str:
    template = """당신은 요청자와 참석자들의 일정을 고려하여 가장 빠른 회의 일정을 조율하는 스마트 어시스턴트입니다. 아래 정보를 바탕으로 최적의 일정을 제안하세요.

    [정보]
        - 참석자 가능 시간: {time_slots}
        - 현재 시각: {now}

    [역할]
    1. 날짜가 포함된 경우, 가독성을 높이기 위해 한국식으로 표기하세요. 예: 4월 3일 오후 3시 - 4시
    2. 현재 시각 이후의 일정만 고려: 과거 시간은 제외하고, 오늘/내일 등의 일정도 반드시 현재 시각을 기준으로 판단할 것.
    3. 가장 빠른 일정 우선:
        - 가능한 시간이 여러 개라면 가장 이른 시간을 추천하세요.
        - 단, 시간이 30분 단위가 아닐 경우, 가장 가까운 다음 30분 단위(예: 14:33 → 15:00)로 조정하세요.
        - 회의 시간이 30분 이상 필요한 경우, 조정된 시작 시간 이후로 연속된 가능한 시간을 확보해야 합니다.
    4. 사용자의 선택 유도:
        - 회의 일정을 확정할 때, '일정 등록'과 '회의실 예약' 중 원하는 옵션을 명확히 질문하세요.
        - '회의실 예약'을 선택하면 ‘일정 등록’이 자동 적용되므로, 둘 다 원하면 '회의실 예약'을 선택하도록 안내하세요.
        - 질문 형식은 더 자연스럽게 정리하세요.
    
    💡 [출력 형식 예시]
    
    사용자의 일정을 고려한 가장 빠른 회의 일정은 아래와 같습니다.
    
    📝 회의 참석자: {attendees}

    📅 가장 빠른 회의 가능 일정: [your answer]
                
    원하시는 시간대를 말씀해주시고, 📌 ‘일정 등록’만 하실지, 아니면 🏢 ‘회의실 예약’까지 진행할지 말씀해주세요.  
    (참고: 회의실 예약을 하면 일정 등록도 자동 적용됩니다.)

    """
    prompt = PromptTemplate.from_template(template)
    chain = prompt | llm
    result = chain.invoke(
        {
            "now": now,
            "attendees": attendees,
            "time_slots": time_slots,
        }
    )
    return result.content


@tool("meeting_scheduling", parse_docstring=True)
def langchain_run_scheduling(
    request_email: str,
    attendees: List[str],
    start_time_str: str,
    meeting_duration: int,
) -> str:
    """참여자의 일정을 보고 요청한 시간에 회의가 가능한지 조율하는 도구입니다.
    반드시 '조율' 이라는 키워드가 포함되어 있을 때에만 사용합니다.

    Args:
        request_email: 회의 주체자 email (string)
        attendees: 참석자 목록 (최소 1명 이상의 email list)
        start_time_str: 회의 시작 시간, (ISO 8601 날짜 및 시간 형식, 예) YYYY-MM-DDTHH:MM:SS)
        meeting_duration: 회의 시간 (분 단위, 기본값: 60)
    """

    request_time = datetime.fromisoformat(start_time_str)
    new_request_time = round_up_to_nearest_30(request_time)
    new_start_time_str = new_request_time.strftime("%Y-%m-%d %H:%M")
    now = datetime.now().replace(second=0, microsecond=0)
    # 오후 6시를 나타내는 time 객체
    six_pm = now.replace(
        year=request_time.year,
        month=request_time.month,
        day=request_time.day,
        hour=18,
        minute=0,
        second=0,
        microsecond=0,
    )
    # 오늘, 또는 내일 등으로 특정 시간을 언급 안했을 때, 요청 시간이 현재시간으로 들어감. 이부분 예외처리
    if request_time.replace(second=0, microsecond=0) == now:
        start_time, end_time = get_time_range(start_time_str, meeting_duration)
        new_start_time_str = start_time.strftime("%Y-%m-%d %H:%M")
        available, time_slots = run_find_meeting_times(
            request_email, attendees, start_time, end_time, meeting_duration
        )

        direct_flag, flag = available_checker(
            available, time_slots, request_time, meeting_duration
        )

        # 회의실 예약이 바로 가능하거나, 제안할 수 있는 시간이 있을 때 flag = True
        if flag:
            if direct_flag == 1:
                ans = f"""{new_start_time_str}에 일정 조율이 가능합니다.
                이 일정으로 📌 ‘일정 등록’만 하실까요, 아니면 🏢 ‘회의실 예약’까지 진행할까요?  
                (참고: 회의실 예약을 하면 일정 등록도 자동 적용됩니다.) """
                return ans
            elif direct_flag == 2:
                ans = paraphrase_llm(
                    now=now, attendees=attendees, time_slots=time_slots
                )
                return ans
        # 회의실 예약이 불가할 때, flag = False
        # 이때는, agent 가 요청자의 schedule 과 참여자들의 가능시간을 비교하여 요청자에게 역제안
        else:
            # 회의 참여자들의 일정 파악
            my_schedule, attendees_schedule = run_get_schedule(
                request_email, attendees, start_time, end_time, meeting_duration
            )
            common_free_times = get_common_free_times(now, attendees_schedule)
            suggestion = suggestion_llm(
                now, my_schedule, attendees, common_free_times, meeting_duration
            )
            return suggestion

    else:
        if request_time < now:
            ans = f"요청하신 {start_time_str}은 현재시간 이전 시간이므로, 예약이 불가합니다."
            return ans
        # request_time이 오후 6시를 넘는지 확인
        elif request_time > six_pm:
            ans = (
                f"요청하신 {start_time_str}은 퇴근시간 이후 이므로, 예약이 불가합니다."
            )
            return ans
        else:
            start_time, end_time = get_time_range(start_time_str, meeting_duration)
            new_start_time_str = start_time.strftime("%Y-%m-%d %H:%M")
            available, time_slots = run_find_meeting_times(
                request_email, attendees, start_time, end_time, meeting_duration
            )

            direct_flag, flag = available_checker(
                available, time_slots, request_time, meeting_duration
            )

            # 회의실 예약이 바로 가능하거나, 제안할 수 있는 시간이 있을 때 flag = True
            if flag:
                if direct_flag == 1:
                    ans = f"""{new_start_time_str}에 일정 조율이 가능합니다.
                    이 일정으로 📌 ‘일정 등록’만 하실까요, 아니면 🏢 ‘회의실 예약’까지 진행할까요?  
                    (참고: 회의실 예약을 하면 일정 등록도 자동 적용됩니다.) """
                    return ans
                elif direct_flag == 2:
                    ans = paraphrase_llm(
                        now=now, attendees=attendees, time_slots=time_slots
                    )
                    return ans
            # 회의실 예약이 불가할 때, flag = False
            # 이때는, agent 가 요청자의 schedule 과 참여자들의 가능시간을 비교하여 요청자에게 역제안
            else:
                # 회의 참여자들의 일정 파악
                my_schedule, attendees_schedule = run_get_schedule(
                    request_email, attendees, start_time, end_time, meeting_duration
                )
                common_free_times = get_common_free_times(now, attendees_schedule)
                suggestion = suggestion_llm(
                    now, my_schedule, attendees, common_free_times, meeting_duration
                )
                return suggestion


# # 사용 예시
# if __name__ == "__main__":
#     # user id
#     request_email = "10861@skcc.com"
#     # 본인 포함 미팅 참여자들
#     attendees = ["10780@skcc.com", "10861@skcc.com", "10272@skcc.com"]
#     # 희망 미팅 시작 시간
#     start_time_str = "2025-01-08T11:00:00"
#     # 미팅 진행 시간 (분단위) 및 가용성 뷰 간격 설정 (분 단위)
#     meeting_duration = 60
#     # time constraints
#     res = run_scheduling(request_email, attendees, start_time_str)

#     print(res)
