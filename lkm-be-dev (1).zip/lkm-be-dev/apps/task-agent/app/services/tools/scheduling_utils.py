from datetime import datetime, timedelta
from typing import Any, Dict, List, Tuple

import requests

from core.log.logging import get_logging
from core.utils.auth import get_ms_access_token

logger = get_logging()


def find_meeting_times(
    request_email: str,
    attendees: List[Dict[str, str]],
    start_time: datetime,
    end_time: datetime,
    timezone: str = "Asia/Seoul",
    meeting_duration: int = 60,
    minimum_attendee_percentage: int = 100,
    is_organizer_optional: bool = False,
) -> Dict:
    """
    Microsoft Graph API를 사용하여 가능한 미팅 시간을 찾는 함수

    Args:
        access_token (str): Microsoft Graph API 접근 토큰
        attendees (List[Dict]): 참석자 목록. 예: [{"name": "Alex", "email": "alex@example.com"}]
        start_time (datetime): 검색 시작 시간
        end_time (datetime): 검색 종료 시간
        timezone (str): 타임존 (기본값: "Asia/Seoul")
        meeting_duration (int): 미팅 시간 (ISO 8601 형식으로 변환 필요)
        location (Dict, optional): 장소 정보
        minimum_attendee_percentage (int): 최소 참석 가능 인원 비율 (1-100)
        is_organizer_optional (bool): 주최자 참석 필수 여부

    Returns:
        Dict: API 응답 결과
    """
    access_token = get_ms_access_token()
    # API endpoint
    url = f"https://graph.microsoft.com/v1.0/users/{request_email}/findMeetingTimes"

    # Headers 설정
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Prefer": f'outlook.timezone="{timezone}"',
        "Content-Type": "application/json",
    }

    # 참석자 데이터 구성
    formatted_attendees = [
        {
            "type": "required",
            "emailAddress": {"address": attendee},
        }
        for attendee in attendees
    ]

    # 기본 요청 데이터
    request_data = {
        "attendees": formatted_attendees,
        "timeConstraint": {
            "timeSlots": [
                {
                    "start": {"dateTime": start_time.isoformat(), "timeZone": timezone},
                    "end": {"dateTime": end_time.isoformat(), "timeZone": timezone},
                }
            ],
        },
        "meetingDuration": f"PT{meeting_duration}M",
        "returnSuggestionReasons": True,
        "minimumAttendeePercentage": minimum_attendee_percentage,
        "isOrganizerOptional": str(is_organizer_optional).lower(),
        "maxCandidates": 10,
    }

    # API 호출
    try:
        response = requests.post(url, headers=headers, json=request_data)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": f"API 호출 중 오류 발생: {str(e)}"}


def get_schedule(
    request_email: str,
    schedules: List[str],
    start_time: datetime,
    end_time: datetime,
    timezone: str = "Asia/Seoul",
    availability_view_interval: int = 60,
) -> Dict[str, Any]:
    """
    Microsoft Graph API의 getSchedule 엔드포인트를 호출하여 지정된 사용자들의 일정 정보를 가져오는 함수.

    Args:
        schedules (List[str]): 일정 정보를 조회할 사용자들의 이메일 주소 리스트.
        start_time (datetime): 일정 조회 시작 시간.
        end_time (datetime): 일정 조회 종료 시간.
        timezone (str, optional): 시간대 설정 (기본값: "Asia/Seoul").
        availability_view_interval (int, optional): 가용성 뷰 간격(분 단위, 기본값: 60).

    Returns:
        Dict[str, Any]: API 응답 데이터.

    Raises:
        Exception: API 호출 중 오류가 발생한 경우.
    """
    access_token = get_ms_access_token()
    url = f"https://graph.microsoft.com/v1.0/users/{request_email}/calendar/getSchedule"

    # 헤더 설정
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Prefer": f'outlook.timezone="{timezone}"',
        "Content-Type": "application/json",
    }

    # 요청 본문 구성
    request_body = {
        "schedules": schedules,
        "startTime": {"dateTime": start_time.isoformat(), "timeZone": timezone},
        "endTime": {"dateTime": end_time.isoformat(), "timeZone": timezone},
        "availabilityViewInterval": availability_view_interval,
    }

    try:
        response = requests.post(url, headers=headers, json=request_body)
        response.raise_for_status()  # HTTP 오류 발생 시 예외를 발생시킵니다.
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": f"API 호출 중 오류 발생: {str(e)}"}


def get_attendees_schedules(
    data: Dict[str, Any],
    attendees: List[str],
) -> Dict[str, Any]:
    """
    getSchedule API의 응답 데이터를 처리하는 함수.

    Args:
        data (Dict[str, Any]): getSchedule API의 응답 데이터.
        schedule_id : 나의 이메일 아이디

    Returns:
        Dict[str, Any]: 사용자별 가용성 정보.
    """
    meetings = []
    schedule_items = []

    for schedule_id in attendees:
        for schedule in data["value"]:
            if schedule.get("scheduleId") == schedule_id:
                schedule_items = schedule.get("scheduleItems", [])

        for item in schedule_items:
            if item.get("status", "") != "free":
                meeting = {
                    "attendee": schedule_id,
                    "subject": item.get("subject", "No Subject"),
                    "status": item.get("status", ""),
                    "start": item.get("start", {}).get("dateTime", ""),
                    "end": item.get("end", {}).get("dateTime", ""),
                }
                meetings.append(meeting)

    return meetings

def round_up_to_nearest_30(dt: datetime) -> datetime:
    """주어진 datetime을 가장 가까운 30분 단위로 올림"""
    minutes = dt.minute
    if minutes == 0 or minutes == 30:
        return dt.replace(second=0, microsecond=0)
    
    if minutes < 30:
        rounded_dt = dt.replace(minute=30, second=0, microsecond=0)
    else:
        rounded_dt = dt.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    
    return rounded_dt

def get_time_range(
    start_time_str: str, meeting_duration: int
) -> Tuple[datetime, datetime]:
    # 현재 시각과 날짜 가져오기
    now = datetime.now()
    start_time = datetime.fromisoformat(start_time_str)
    end_time = start_time + timedelta(minutes=meeting_duration)
    # 회의 날짜가 현재보다 미래 예정일때,
    if start_time.date() > now.date():
        # 미팅 제안은 해당일 9to6
        start_time = start_time.replace(hour=9, minute=0, second=0, microsecond=0)
        end_time = end_time.replace(hour=18, minute=0, second=0, microsecond=0)

    # 회의 날짜가 당일 또는 과거이면, 회의 시간 제안은 현재to퇴근시간
    else:
        start_time = round_up_to_nearest_30(now)
        end_time = now.replace(hour=18, minute=0, second=0, microsecond=0)

    logger.debug(f"[Scheduling] start_time: {start_time}, end_time: {end_time}")

    return start_time, end_time


def get_meeting_suggestions(data: Dict[str, Any]) -> Tuple[bool, List[List[str]]]:
    """
    주어진 딕셔너리에서 요청한 시간의 가능 여부와 meetingTimeSuggestions의 시작과 끝 시간을 추출합니다.

    Args:
        data (dict): Microsoft Graph API에서 반환된 meetingTimeSuggestionsResult 딕셔너리.

    Returns:
        tuple: (가능 여부 (bool), [[start, end], ...] 형식의 시간 리스트)
    """
    # 요청한 시간의 가능 여부 판단
    # emptySuggestionsReason이 비어있지 않으면 제안이 없다는 의미로 요청 시간이 불가능함
    is_available = not bool(data.get("emptySuggestionsReason"))

    time_slots = []
    for suggestion in data.get("meetingTimeSuggestions", []):
        start = suggestion["meetingTimeSlot"]["start"]["dateTime"]
        end = suggestion["meetingTimeSlot"]["end"]["dateTime"]
        time_slots.append([start, end])

    return is_available, time_slots


def run_get_schedule(
    request_email: str,
    attendees: List[str],
    start_time: datetime,
    end_time: datetime,
    meeting_duration: int,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    try:
        schedule_response = get_schedule(
            request_email=request_email,
            schedules=attendees,
            start_time=start_time,
            end_time=end_time,
            availability_view_interval=meeting_duration,
        )
        attendees.append(request_email)
        # 응답 데이터 처리
        attendees_schedule = get_attendees_schedules(schedule_response, attendees)
        my_schedule = [
            item for item in attendees_schedule if item.get("attendee") == request_email
        ]
        others_schedule = [
            item for item in attendees_schedule if item.get("attendee") != request_email
        ]
        logger.debug(f"[Scheduling] my_schedule: {my_schedule}")
        logger.debug(f"[Scheduling] others_schedule: {others_schedule}")
        return my_schedule, others_schedule

    except Exception as e:
        logger.error(f"[Scheduling] error: {str(e)}")
        return None, None


def run_find_meeting_times(
    request_email: str,
    attendees: List[str],
    start_time: datetime,
    end_time: datetime,
    meeting_duration: int,
) -> Tuple[int, bool]:
    try:
        # start_time이 오후 6시 이후인지 체크
        if start_time.hour > 18:
            return False, "time_out_of_range"

        result = find_meeting_times(
            request_email=request_email,
            attendees=attendees,
            start_time=start_time,
            end_time=end_time,
            meeting_duration=meeting_duration,
        )

        available, time_slots = get_meeting_suggestions(result)

        if len(time_slots) > 0:
            available = True
        else:
            available = False

        return available, time_slots

    except Exception as e:
        logger.error(f"[Scheduling] error: {str(e)}")
        return None, None


def available_checker(
    available: bool,
    time_slots: List[str],
    request_time: datetime,
    meeting_duration: int,
) -> Tuple[int, bool]:
    direct_flag = 0
    flag = False
    if available:
        flag = True
        meeting_end_time = request_time + timedelta(minutes=meeting_duration)
        if [
            request_time.isoformat() + ".0000000",
            meeting_end_time.isoformat() + ".0000000",
        ] in time_slots:
            direct_flag = 1
        else:
            direct_flag = 2
    else:
        flag = False
        direct_flag = 0

    return direct_flag, flag


# 사용 예시
# if __name__ == "__main__":
#     request_email = "10861@skcc.com"
#     attendees = ["10780@skcc.com", "10861@skcc.com", "10272@skcc.com"]
#     start_time_str = "2025-01-08T09:00:00"
#     meeting_duration = 60
#     start_time, end_time = get_time_range(start_time_str, meeting_duration)

#     available, time_slots = run_find_meeting_times(
#         request_email, attendees, start_time, end_time, meeting_duration
#     )
#     print(time_slots)
#     my_schedule, attendees_schedule = run_get_schedule(
#         request_email, attendees, start_time, end_time, meeting_duration
#     )
