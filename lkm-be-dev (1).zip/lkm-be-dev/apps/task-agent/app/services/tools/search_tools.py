from typing import Type

from core.config import get_setting
from langchain.tools import BaseTool
from langchain_community.utilities import BingSearchAPIWrapper
from pydantic import BaseModel, Field
from typing import Dict

settings = get_setting()

import requests


class MyBingSearch(BaseTool):
    """Bing 검색 도구"""
    class SearchInput(BaseModel):
        query: str = Field(description="should be a search query")

    name: str = "Searcher"
    description: str = "useful to search the internet.\n"
    args_schema: Type[BaseModel] = SearchInput
    k: int = 5

    def _run(self, query: str, freshness: str = "Week", count: int = 10) -> Dict:
        """
        Bing Search API를 사용하여 최신 검색 결과를 가져오는 함수.

        :param query: 검색어 (str)
        :param freshness: 검색 결과의 최신도 (str) - 'Day', 'Week', 'Month' 가능
        :param count: 가져올 검색 결과 개수 (int)
        :return: 검색 결과 JSON (dict)
        """
        headers = {"Ocp-Apim-Subscription-Key": settings.BING_API_KEY}
        params = {
            "q": query,
            "freshness": freshness,
            "count": count,
            "responseFilter": "Webpages",
            "mkt": "ko-KR",
        }

        response = requests.get(settings.BING_ENDPOINT, headers=headers, params=params)

        if response.status_code == 200:
            return response.json()
        else:
            return {"error": response.status_code, "message": response.text}

