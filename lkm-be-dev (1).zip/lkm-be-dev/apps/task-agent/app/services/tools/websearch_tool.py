import re
from typing import Any, List, Optional
import uuid
from langchain_core.tools import BaseTool
from core.log.logging import get_logging
from core.config import get_setting
from services.prompt.websearch_prompt import REPORT_STRUCTURE

logger = get_logging()
settings = get_setting()

try:
    import os, sys

    package_path = os.path.join(os.path.dirname(__file__), "open_deep_research", "src")
    if package_path not in sys.path:
        sys.path.insert(0, package_path)
    from langgraph.checkpoint.memory import MemorySaver
    from open_deep_research.graph import get_builder
except ImportError as e:
    logger.info(f"Warning: open_deep_research 모듈을 찾을 수 없습니다: {e}")
    builder = None

builder = get_builder()


class WebSearchTool(BaseTool):
    name: str = "web_search"
    description: str = "Search the web for information"
    graph: Optional[Any] = None

    def __init__(self):
        super().__init__()
        self.graph = None
        self._initialize_graph()

    def _initialize_graph(self):
        if builder is None:
            logger.warning(
                "open_deep_research 모듈이 없어 그래프를 초기화할 수 없습니다."
            )
            return

        try:
            memory = MemorySaver()
            self.graph = builder.compile(checkpointer=memory)
        except Exception as e:
            logger.error(f"그래프 초기화 실패: {e}")
            raise e

    @staticmethod
    def _get_search_api_config(search_api: str) -> dict:
        configurations = {
            "googlesearch": {
                "api_key": settings.GOOGLE_SEARCH_KEY,
                "cx": settings.GOOGLE_CX,
            },
            "bingsearch": {
                "api_key": settings.BING_SEARCH_KEY,
                "max_results": 10,
                "include_raw_content": True,
            },
        }
        return configurations.get(search_api, {})

    def _get_thread_config(self):
        """연구 스레드 설정 반환"""
        search_api = "bingsearch"
        search_api_config = self._get_search_api_config(search_api)

        model_provider = "azure_openai"
        model = settings.OPENAI_MODEL
        model_azure_endpoint = settings.OPENAI_ENDPOINT
        model_api_key = settings.OPENAI_API_KEY
        model_azure_deployment = settings.OPENAI_DEPLOYMENT
        model_api_version = settings.OPENAI_API_VERSION
        os.environ["AZURE_OPENAI_ENDPOINT"] = model_azure_endpoint

        return {
            "configurable": {
                "thread_id": str(uuid.uuid4()),
                "search_api": search_api,
                "search_api_config": search_api_config,
                "planner_provider": model_provider,
                "planner_model": model,
                "planner_azure_endpoint": model_azure_endpoint,
                "planner_api_key": model_api_key,
                "planner_azure_deployment": model_azure_deployment,
                "planner_api_version": model_api_version,
                "planner_model_kwargs": {},
                "writer_provider": model_provider,
                "writer_model": model,
                "writer_azure_endpoint": model_azure_endpoint,
                "writer_api_key": model_api_key,
                "writer_azure_deployment": model_azure_deployment,
                "writer_api_version": model_api_version,
                "writer_model_kwargs": {},
                "max_search_depth": 2,
                "report_structure": REPORT_STRUCTURE,
            }
        }

    def _run(self, query: str) -> str:
        """동기 실행은 지원하지 않음"""
        raise NotImplementedError("이 툴은 비동기 실행만 지원합니다.")

    async def _arun(self, research_topic: str) -> dict:
        """비동기 실행 - 웹 검색"""
        # 1단계: 웹 검색을 통한 보고서 생성
        report = await self._generate_report(research_topic)

        if not report:
            error_msg = "보고서 생성에 실패했습니다."

            return {"error": error_msg}

        agenda_items = await self._extract_agenda_from_report(report, research_topic)
        return {"report": report, "agenda_items": agenda_items}

    async def _generate_report(self, topic: str) -> str:
        thread = self._get_thread_config()
        await self.graph.ainvoke({"topic": topic}, thread, stream_mode="updates")
        final_state = self.graph.get_state(thread)
        report: str = final_state.values.get("final_report")
        return report

    async def _extract_agenda_from_report(
        self, report: str, research_topic: str
    ) -> List[str]:
        """보고서에서 목차 항목을 추출 (소스 관련 항목 제외)"""
        heading_patterns = [
            r"^#+\s+(.+)$",  # Markdown 헤딩
            r"^\d+\.\s+(.+)$",  # 숫자 리스트
            r"^[가-힣]+\)\s+(.+)$",  # 한글 번호 리스트
            r"^[A-Z]\.\s+(.+)$",  # 영문 리스트
        ]

        agenda_items = []
        lines = report.split("\n")

        # 제외할 키워드 리스트 (소스 관련)
        excluded_keywords = [
            "sources",
            "references",
            "참고문헌",
            "출처",
            "reference",
            "bibliography",
            "source",
            "참고자료",
            "인용",
            "citation",
            "참조",
        ]

        for line in lines:
            line = line.strip()
            if not line:
                continue

            for pattern in heading_patterns:
                match = re.match(pattern, line, re.MULTILINE)
                if match:
                    title = match.group(1).strip()
                    # 소스 관련 키워드가 포함된 제목은 제외
                    if any(
                        keyword.lower() in title.lower()
                        for keyword in excluded_keywords
                    ):
                        continue
                    if (
                        len(title) > 5 and title not in agenda_items
                    ):  # 너무 짧은 제목 제외
                        agenda_items.append(title)
                    break

        # 기본 목차가 추출되지 않은 경우 기본 구조 사용
        if len(agenda_items) < 4:
            topic_key = research_topic.split(",")[0].strip()
            agenda_items = [
                f"{topic_key} 개요 및 배경",
                f"{topic_key} 현황 분석",
                f"{topic_key} 핵심 이슈 및 과제",
                f"{topic_key} 솔루션 및 전략",
                f"{topic_key} 기대효과 및 ROI",
                "결론 및 향후 계획",
            ]

        # 최대 8개 항목으로 제한
        agenda_items = agenda_items[:8]
        return agenda_items
