from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type
from urllib.parse import quote, unquote

import requests
from langchain.tools import BaseTool
from langchain.tools.base import ToolException
from pydantic import BaseModel

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.auth import get_ms_access_token
from database.crud.crud_tool_call import CRUDToolCall
from database.models.tool_call import ToolCall
from database.session import SyncSessionLocal
from services.company.company_service_factory import CompanyServiceFactory
from services.tool_call_service import create_tool_call

logger = get_logging()
settings = get_setting()


class BaseApiTool(ABC):
    """모든 API Tool의 기본 클래스"""

    @abstractmethod
    def _run(self, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        pass


class ApiTool(BaseTool):
    name: str
    description: str
    service_category: str
    args_schema: Type[BaseModel]
    endpoint: str
    method: str
    params_schema: Optional[Dict[str, Any]] = None
    body_schema: Optional[Dict[str, Any]] = None
    response_schema: Optional[Dict[str, Any]] = None

    def _get_headers(self) -> Dict[str, str]:
        """요청 헤더를 생성합니다."""
        headers = {"accept": "application/json"}
        company_service = CompanyServiceFactory.get_service(settings.COMPANY)

        if self.service_category == "meetingroom":
            headers["Authorization"] = company_service.get_meeting_room_access_token()
        else:
            ms_token = get_ms_access_token()
            if ms_token:
                headers["Authorization"] = f"Bearer {ms_token}"
            else:
                logger.error("Failed to get MS access token")
                raise Exception("MS access token is required but not available")

        if self.name == "listEvents" or self.name == "listCalendarView":
            headers["Prefer"] = 'outlook.timezone="Asia/Seoul"'

        return headers

    def _run(self, **kwargs: Any) -> Dict[str, Any]:
        """
        API를 실행하고 결과를 반환합니다.
        """
        with SyncSessionLocal() as db:
            crud_tool_call = CRUDToolCall()
            created_tool_call = None
            try:
                params_data = {}
                body_data = {}
                path_params_data = {}

                if kwargs:
                    path_params = self._extract_path_params(self.endpoint)
                    if self.params_schema:
                        for k, v in kwargs.items():
                            if k in self.params_schema and v is not None:
                                if k in path_params:
                                    path_params_data[k] = v
                                else:
                                    params_data[k] = v

                    if self.body_schema:
                        body_data = {
                            k: self._convert_pydantic_to_dict(v)
                            for k, v in kwargs.items()
                            if k in self.body_schema and v is not None
                        }

                    # params나 body schema가 없는 경우, HTTP 메서드에 따라 처리
                    if not self.params_schema and not self.body_schema:
                        if self.method in ["GET", "DELETE"]:
                            params_data = {
                                k: v for k, v in kwargs.items() if v is not None
                            }
                        else:
                            body_data = {
                                k: v for k, v in kwargs.items() if v is not None
                            }

                formatted_endpoint = self._format_endpoint(
                    self.endpoint, path_params_data
                )

                tool_call: ToolCall = create_tool_call(
                    tool_name=self.name,
                    tool_service_category=self.service_category,
                    request_params=params_data,
                    request_body=body_data,
                )
                created_tool_call = crud_tool_call.upsert_tool_call(db, tool_call)

                logger.info(
                    f"API Request - {self.name} | Method: {self.method} | Endpoint: {formatted_endpoint} | Headers: {self._get_headers()} | Params: {params_data} | Body: {body_data}"
                )
                response = requests.request(
                    self.method,
                    formatted_endpoint,
                    params=params_data,
                    json=body_data,
                    headers=self._get_headers(),
                    timeout=(5, 30),  # API 응답이 없는 경우 대비
                )
                logger.info(
                    f"API Response - {self.name} | Status: {response.status_code} | Headers: {dict(response.headers)} | Body: {response.text}"
                )

                # DELETE 요청의 경우 response body 가 없으므로 별도 처리
                if self.method == "DELETE" and response.status_code == 204:
                    success_response = {
                        "status": "success",
                        "message": "Operation completed successfully",
                    }
                    crud_tool_call.upsert_tool_call(
                        db, created_tool_call, success_response
                    )
                    return success_response

                response.raise_for_status()
                response_data = response.json()

                crud_tool_call.upsert_tool_call(db, created_tool_call, response_data)

                result = {
                    "success": response_data.get(
                        "success", True
                    ),  # success 키가 없으면 True로 기본값 설정
                    "message": response_data.get(
                        "message", ""
                    ),  # message 키가 없으면 빈 문자열로 기본값 설정
                }

                # 데이터가 리스트인 경우
                if isinstance(response_data.get("data"), list):
                    result["data"] = {"items": response_data["data"]}
                # 데이터가 단일 객체인 경우
                elif "data" in response_data:
                    result["data"] = response_data["data"]
                # 그 외의 경우
                else:
                    result["data"] = response_data

                return result

            except Exception as e:
                if created_tool_call:
                    crud_tool_call.upsert_tool_call(
                        db, created_tool_call, {"error": str(e)}
                    )
                raise ToolException(f"Error in {self.name}: {str(e)}")

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        """Run the tool asynchronously."""
        raise NotImplementedError("ApiTool does not support async")

    def _extract_path_params(self, endpoint: str) -> List[str]:
        """엔드포인트에서 path parameter 이름들을 추출"""
        path_params = []
        parts = endpoint.split("/")
        for part in parts:
            if part.startswith("{") and part.endswith("}"):
                # {param_name} 형식에서 실제 파라미터 이름만 추출
                param_name = part[1:-1]
                path_params.append(param_name)
        return path_params

    def _format_endpoint(self, endpoint: str, path_params_data: Dict[str, Any]) -> str:
        """path parameter 값들을 사용하여 실제 엔드포인트 URL을 생성"""
        formatted_endpoint = endpoint
        for param_name, value in path_params_data.items():
            # 1회 디코딩 후 인코딩 하여 올바른 형식으로 변환
            try:
                decoded_value = unquote(str(value))
            except Exception:
                decoded_value = str(value)
            encoded_value = quote(decoded_value, safe="")
            formatted_endpoint = formatted_endpoint.replace(
                f"{{{param_name}}}", encoded_value
            )
        return formatted_endpoint

    def _convert_pydantic_to_dict(self, value: Any) -> Any:
        """Pydantic 모델을 딕셔너리로 재귀적으로 변환"""
        if isinstance(value, BaseModel):
            return {
                k: self._convert_pydantic_to_dict(v)
                for k, v in value.model_dump().items()
            }
        elif isinstance(value, dict):
            return {k: self._convert_pydantic_to_dict(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._convert_pydantic_to_dict(item) for item in value]
        return value
