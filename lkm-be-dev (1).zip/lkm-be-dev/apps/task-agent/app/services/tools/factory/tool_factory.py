from typing import Any, Dict, List, Optional, Tuple, Type

from langchain.tools import BaseTool
from pydantic import BaseModel, Field, create_model
from sqlalchemy import MetaData, Table, select
from sqlalchemy.orm import Session

from database.session import get_db
from services.tools.factory.api_tool import ApiTool

metadata = MetaData()


def create_pydantic_model(schema: Dict[str, Any], model_name: str) -> Type[BaseModel]:
    """
    중첩된 구조를 포함한 API 스키마로부터 Pydantic 모델을 생성
    """

    def process_property(prop_info: Any, prop_name: str) -> tuple:
        # prop_info가 dict가 아니면 처리
        if not isinstance(prop_info, dict):
            return Any, Field(None, description=f"Invalid schema for {prop_name}")

        type_mapping = {
            "string": str,
            "integer": int,
            "int": int,
            "number": float,
            "boolean": bool,
            "array": List,
            "object": Dict,
        }

        if prop_info.get("type") == "array" and "items" in prop_info:
            items_info = prop_info["items"]
            if isinstance(items_info, dict) and items_info.get("type") == "object":
                # 중첩된 객체 배열 처리
                item_model = create_pydantic_model(
                    {"type": "object", "properties": items_info.get("properties", {})},
                    f"{model_name}{prop_name.capitalize()}",
                )
                field_type = List[item_model]
            elif isinstance(items_info, dict):
                # 단순 배열 타입 처리
                field_type = List[
                    type_mapping.get(items_info.get("type", "string"), str)
                ]
            else:
                # `items` 필드가 예상하지 못한 값일 경우
                field_type = List[Any]
        elif prop_info.get("type") == "object" and "properties" in prop_info:
            # 중첩된 객체 처리
            nested_model = create_pydantic_model(
                {"type": "object", "properties": prop_info["properties"]},
                f"{model_name}{prop_name.capitalize()}",
            )
            field_type = Optional[nested_model]
        else:
            # 기본 타입 처리
            field_type = type_mapping.get(prop_info.get("type", "string"), str)

        # 필드 속성 처리
        required = prop_info.get("required", False)
        description = create_field_description(prop_info)

        if not required:
            field_type = Optional[field_type]

        return field_type, Field(None if not required else ..., description=description)

    # 모델 필드 생성
    fields = {}
    if not schema or "properties" not in schema:
        return create_model(model_name, __base__=BaseModel)

    for field_name, field_info in schema["properties"].items():
        field_type, field_def = process_property(field_info, field_name)
        fields[field_name] = (field_type, field_def)

    return create_model(model_name, **fields)


def create_api_tools(api_metadata_dict: dict, agent_name: str) -> Dict[str, BaseTool]:
    """
    API 메타데이터로부터 Tool 인스턴스를 생성
    """
    tools = {}
    for _, metadata in api_metadata_dict.items():
        for api_spec in metadata:
            name = api_spec["name"]
            description = api_spec["description"]
            endpoint = api_spec["endpoint"]
            method = api_spec["method"]
            service_category = api_spec.get("service_category", "meetingroom")
            params_schema = api_spec.get("params")
            body_schema = api_spec.get("body")

            combined_properties = {}
            if params_schema:
                combined_properties.update(params_schema)
            if body_schema:
                combined_properties.update(body_schema)

            input_schema = create_pydantic_model(
                {"type": "object", "properties": combined_properties},
                f"{name}Input",
            )

            # Tool 인스턴스 생성
            tool = ApiTool(
                name=name,
                description=description,
                args_schema=input_schema,
                endpoint=endpoint,
                method=method,
                params_schema=params_schema,
                body_schema=body_schema,
                service_category=service_category,
                response_schema=api_spec.get("response_format"),
            )
            tools[name] = tool

    return tools


def get_all_tables_data_sync(db: Session) -> dict:
    """동기 버전의 get_all_tables_data"""

    table_names = ["api_specs"]
    all_data = {}
    for table_name in table_names:
        table = Table(table_name, metadata, autoload_with=db.get_bind())
        if table_name == "api_specs":
            result = db.execute(
                select(table).where(table.c.is_tool_enabled == True)
            ).fetchall()
        else:
            result = db.execute(select(table)).fetchall()

        table_data = []
        for row in result:
            row_dict = dict(row._mapping)
            table_data.append(row_dict)

        all_data[table_name] = table_data

    return all_data


def make_api_tools_from_db(
    agent_name: str,
) -> Tuple[Dict[str, BaseTool], List[Dict[str, Any]]]:
    """
    데이터베이스에서 API 메타데이터를 가져와서 Tool을 생성합니다.
    """
    db = next(get_db())
    try:
        api_metadata_dict = get_all_tables_data_sync(db)
        tools = create_api_tools(api_metadata_dict, agent_name)
        return tools, api_metadata_dict[list(api_metadata_dict.keys())[0]]
    finally:
        db.close()


def create_field_description(prop_info: Dict[str, Any]) -> str:
    """
    Field에 대한 설명을 생성합니다.
    기본 설명과 default 값에 대한 설명을 포함합니다.
    """
    description = prop_info.get("description", "")
    default = prop_info.get("default")

    if default is not None:
        description = f"{description} (Default: {default})"

    if "format" in prop_info:
        description = f"{description} [Format: {prop_info['format']}]"

    if "enum" in prop_info:
        enum_values = ", ".join(str(v) for v in prop_info["enum"])
        description = f"{description} [Allowed values: {enum_values}]"

    return description.strip()


def create_api_spec_dict_from_tools(tools: Dict[str, BaseTool]) -> dict:
    """
    Langchain Tool들로부터 API 메타데이터 딕셔너리를 생성

    Args:
        tools (Dict[str, BaseTool]): API Tool들의 딕셔너리

    Returns:
        dict: API 메타데이터가 담긴 딕셔너리
    """
    api_specs = {}

    # 각 Tool을 순회하면서 API 스펙 생성
    for name, tool in tools.items():
        if not isinstance(tool, ApiTool):
            continue

        # Tool의 속성들로부터 API 스펙 생성
        api_spec = {
            "name": tool.name,
            "description": tool.description,
            "endpoint": tool.endpoint,
            "method": tool.method,
            "service_category": tool.service_category,
            "response_format": tool.response_schema,
        }

        # params_schema가 있는 경우 추가
        if tool.params_schema:
            api_spec["params"] = tool.params_schema

        # body_schema가 있는 경우 추가
        if tool.body_schema:
            api_spec["body"] = tool.body_schema

        # service_category를 키로 사용하여 api_specs에 추가
        service_category = tool.service_category
        if service_category not in api_specs:
            api_specs[service_category] = []
        api_specs[service_category].append(api_spec)

    return api_specs
