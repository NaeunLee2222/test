# v8.99
import asyncio
import hashlib
import json
import re
import time
from datetime import datetime
from zoneinfo import ZoneInfo

kst_now = datetime.now(ZoneInfo("Asia/Seoul"))
import hashlib
import logging
import os
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

from typing_extensions import Literal

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

# from langchain_qdrant import QdrantVectorStore
from langchain.schema import Document
from langchain_anthropic import ChatAnthropic
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_openai import AzureOpenAIEmbeddings, ChatOpenAI
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from pydantic import BaseModel

try:
    from langchain.schema import Document
    from langchain_core.vectorstores import InMemoryVectorStore

    LLM_ENRICHMENT_AVAILABLE = True
    logger.info("✅ LLM 보강 시스템 사용 가능")
except ImportError as e:
    logger.warning(f"❌ LLM 보강 라이브러리 가져오기 실패: {e}")
    LLM_ENRICHMENT_AVAILABLE = False

from dotenv import load_dotenv
from mem0 import Memory

# 환경 변수 로드
load_dotenv()

# MCP 가용성 확인
try:
    from langchain_mcp_adapters.client import MultiServerMCPClient
    from langgraph.checkpoint.memory import MemorySaver
    from langgraph.graph import END, START, StateGraph
    from langgraph.prebuilt import create_react_agent
    from typing_extensions import TypedDict

    MCP_AVAILABLE = True
    logger.info("✅ langchain-mcp-adapters 사용 가능")
except ImportError as e:
    logger.warning(f"❌ MCP 라이브러리 가져오기 실패: {e}")
    MCP_AVAILABLE = False

# =================================
# Enum 클래스 정의 (최상단)
# =================================


class EntityType(Enum):
    """엔티티 타입 정의"""

    SERVER_SUMMARY = "server_summary"
    TOOL = "tool"
    RESOURCE = "resource"
    PROMPT = "prompt"


class MessageType(Enum):
    START = "START"
    END = "END"
    PLAN_START = "PLAN_START"
    PLAN_COMPLETE = "PLAN_END"
    STEP_START = "STEP_START"
    STEP_COMPLETE = "STEP_END"
    ACTION_START = "ACTION_START"
    ACTION_SUCCESS = "ACTION_END"
    ACTION_FAIL = "ACTION_FAIL"
    ERROR = "ERROR"
    TOKEN = "TOKEN"
    CANVAS = "CANVAS"
    AI_SLIDE = "AI_SLIDE"
    THINKING = "THINKING"
    TOOL_THINKING = "TOOL_THINKING"
    ROUTING = "ROUTING"
    SERVER_SELECT = "SERVER_SELECT"
    WORKFLOW_START = "WORKFLOW"
    MCP_RECOMMENDATION = "MCP_RECOMMENDATION"


class QueryComplexity(Enum):
    """쿼리 복잡도 레벨"""

    SIMPLE_CHAT = "simple_chat"  # 단순 질문 (도구 사용 불필요)
    SIMPLE_TOOL = "simple_tool"  # 단순 도구 사용
    COMPLEX_TOOL = "complex_tool"  # 복합 도구 사용 (Hierarchical Planning 필요)


# =================================
# 개선된 워크플로우 상태 관리
# =================================


class WorkflowPhase(Enum):
    """워크플로우 단계"""

    INITIALIZATION = "initialization"
    ANALYSIS = "analysis"
    ROUTING = "routing"
    PLANNING = "planning"
    EXECUTION = "execution"
    SYNTHESIS = "synthesis"
    COMPLETION = "completion"


class StepStatus(Enum):
    """단계 상태"""

    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


# =================================
# 데이터 클래스 정의
# =================================


@dataclass
class WorkflowStep:
    """워크플로우 단계 정보"""

    step_id: str
    step_number: int
    name: str
    description: str
    phase: WorkflowPhase
    status: StepStatus
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    duration: Optional[float] = None
    substeps: List["WorkflowStep"] = None
    error_message: Optional[str] = None

    def __post_init__(self):
        if self.substeps is None:
            self.substeps = []


@dataclass
class RoutingDecision:
    """라우팅 결정 결과"""

    complexity: QueryComplexity
    confidence: float
    reasoning: str
    recommended_approach: str
    estimated_steps: int
    requires_planning: bool


@dataclass
class SubTask:
    """하위 작업 정의"""

    id: str
    name: str
    description: str
    required_tools: List[str]
    dependencies: List[str]  # 의존하는 하위 작업 ID들
    priority: int
    estimated_duration: int


@dataclass
class ExecutionPlan:
    """실행 계획"""

    plan_id: str
    query: str
    total_subtasks: int
    subtasks: List[SubTask]
    execution_order: List[str]  # 실행 순서 (subtask ID들)
    estimated_total_time: int
    fallback_strategy: str


@dataclass
class MCPMetadata:
    """MCP 서버의 메타데이터를 저장하는 데이터 클래스"""

    server_name: str
    description: str
    tools: List[Dict[str, Any]]
    resources: List[Dict[str, Any]]
    prompts: List[Dict[str, Any]]
    command: str
    args: List[str]
    server_info: Dict[str, Any]

    def to_text(self) -> str:
        """메타데이터를 텍스트로 변환하여 임베딩을 위한 문자열 생성"""
        text_parts = [
            f"Server: {self.server_name}",
            f"Description: {self.description}",
        ]

        if self.tools:
            text_parts.append("Tools:")
            for tool in self.tools:
                tool_desc = f"- {tool.get('name', 'Unknown')}: {tool.get('description', 'No description')}"
                if "inputSchema" in tool:
                    schema = tool["inputSchema"]
                    if "properties" in schema:
                        params = list(schema["properties"].keys())
                        tool_desc += f" (Parameters: {', '.join(params)})"
                text_parts.append(tool_desc)

        if self.resources:
            text_parts.append("Resources:")
            for resource in self.resources:
                text_parts.append(
                    f"- {resource.get('name', 'Unknown')}: {resource.get('description', 'No description')}"
                )

        if self.prompts:
            text_parts.append("Prompts:")
            for prompt in self.prompts:
                text_parts.append(
                    f"- {prompt.get('name', 'Unknown')}: {prompt.get('description', 'No description')}"
                )

        return "\n".join(text_parts)


@dataclass
class UnifiedMCPDocument:
    """통합 MCP 문서 클래스"""

    entity_type: EntityType
    server_name: str
    entity_name: str
    title: str
    description: str
    content: str
    category: str
    tags: List[str]
    parameters: List[str]
    use_cases: List[str]
    metadata: Dict[str, Any]

    def to_searchable_text(self) -> str:
        """검색 가능한 텍스트 생성"""
        text_parts = [
            f"Type: {self.entity_type.value}",
            f"Server: {self.server_name}",
            f"Name: {self.entity_name}",
            f"Title: {self.title}",
            f"Category: {self.category}",
            f"Description: {self.description}",
            f"Content: {self.content}",
        ]

        if self.tags:
            text_parts.append(f"Tags: {', '.join(self.tags)}")

        if self.parameters:
            text_parts.append(f"Parameters: {', '.join(self.parameters)}")

        if self.use_cases:
            text_parts.append(f"Use cases: {', '.join(self.use_cases)}")

        return "\n".join(text_parts)


@dataclass
class ToolRecommendation:
    """도구 추천 결과"""

    server_name: str
    tool_name: str
    score: float
    category: str
    description: str
    parameters: List[str]
    use_cases: List[str]
    confidence: float
    reason: str


@dataclass
class MCPRecommendationResult:
    """MCP 추천 전체 결과"""

    query: str
    recommended_servers: List[Dict[str, Any]]
    recommended_tools: List[ToolRecommendation]
    tool_sequence: List[Dict[str, Any]]
    confidence_score: float
    explanation: str


@dataclass
class EnrichedMCPMetadata:
    """LLM으로 보강된 MCP 메타데이터"""

    # 원본 정보
    original_server_name: str
    original_description: str
    original_tools: List[Dict[str, Any]]
    original_resources: List[Dict[str, Any]]
    original_prompts: List[Dict[str, Any]]

    # LLM 보강 정보
    enriched_server_description: str
    enriched_capabilities: List[str]
    enriched_use_cases: List[str]
    enriched_keywords: List[str]
    enriched_tools: List[Dict[str, Any]]

    # 메타 정보
    enrichment_timestamp: str
    enrichment_confidence: float
    enrichment_version: str = "1.0"


@dataclass
class EnrichmentStatus:
    """보강 프로세스 상태"""

    is_enrichment_enabled: bool
    total_servers: int
    enriched_servers: int
    failed_servers: int
    enrichment_progress: float
    last_enrichment_time: Optional[str]
    cache_size: int
    background_task_running: bool


# =================================
# Pydantic 모델 정의
# =================================


class WorkflowState(TypedDict):
    messages: List[BaseMessage]
    current_mcp_server: Optional[str]
    current_tool: Optional[str]
    selected_tools: List[str]
    routing_decision: Optional[str]
    step_counter: int
    failed_servers: List[str]
    workflow_type: str
    query_analysis: Dict[str, Any]


class QueryAnalysis(BaseModel):
    query_type: str
    complexity: str
    required_tools: List[str]
    preferred_servers: List[str]
    needs_realtime_data: bool
    estimated_steps: int
    system_info_type: Optional[str] = None


class ChatMessage(BaseModel):
    role: str
    content: str
    timestamp: Optional[datetime] = None


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    model: Optional[str] = "claude-3-5-sonnet-20241022"
    stream: Optional[bool] = True


class ChatResponse(BaseModel):
    response: str
    conversation_id: str
    events: Optional[List[Dict[str, Any]]] = None
    metadata: Optional[Dict[str, Any]] = None


class MCPRecommendationRequest(BaseModel):
    query: str
    max_servers: Optional[int] = 3
    max_tools: Optional[int] = 10


class EnrichmentStatusResponse(BaseModel):
    """보강 상태 응답 모델"""

    enrichment_enabled: bool
    total_servers: int
    enriched_servers: int
    failed_servers: int
    enrichment_progress: float
    last_enrichment_time: Optional[str]
    cache_size: int
    background_task_running: bool
    enriched_vector_store_ready: bool
    enriched_recommendation_system_ready: bool


class EnrichmentControlRequest(BaseModel):
    """보강 제어 요청 모델"""

    action: Literal["enable", "disable", "restart", "clear_cache"]
    force: Optional[bool] = False


# =================================
# 유틸리티 클래스
# =================================


class EventMessage:
    def __init__(
        self,
        chat_id: str,
        msg_type: MessageType,
        content: str,
        description: str,
        key: str = "",
    ):
        self.type = msg_type.value
        self.content = content
        self.description = description
        self.key = key
        self.id = chat_id

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "content": self.content,
            "description": self.description,
            "key": self.key,
            "id": self.id,
        }


# =================================
# 순차적 이벤트 관리자
# =================================


class SequentialEventManager:
    """순차적 이벤트 관리 및 워크플로우 제어"""

    def __init__(self, chat_id: str):
        self.chat_id = chat_id
        self.current_phase = WorkflowPhase.INITIALIZATION
        self.workflow_steps: List[WorkflowStep] = []
        self.step_counter = 0
        self.active_step: Optional[WorkflowStep] = None
        self.event_queue = asyncio.Queue()
        self.is_planning_active = False
        self.is_execution_active = False

        # 동기화를 위한 락
        self._step_lock = asyncio.Lock()

    async def start_workflow(self, workflow_type: str, query: str) -> Dict[str, Any]:
        """워크플로우 시작"""
        start_event = {
            "type": "START",
            "content": f"🚀 {workflow_type} 워크플로우 시작",
            "description": f"쿼리: {query}",
            "key": "workflow_start",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": 0,
        }
        await self._emit_event(start_event)
        return start_event

    async def advance_phase(
        self, new_phase: WorkflowPhase, description: str = ""
    ) -> Dict[str, Any]:
        """워크플로우 단계 진행"""
        async with self._step_lock:
            # 현재 활성 단계가 있으면 완료 처리
            if self.active_step and self.active_step.status == StepStatus.ACTIVE:
                await self._complete_current_step()

            self.current_phase = new_phase

            phase_event = {
                "type": "PHASE_TRANSITION",
                "content": f"🔄 {new_phase.value.title()} 단계 진입",
                "description": description or f"{new_phase.value} 단계를 시작합니다",
                "key": f"phase_{new_phase.value}",
                "id": self.chat_id,
                "phase": new_phase.value,
                "step_number": 0,
            }
            await self._emit_event(phase_event)
            return phase_event

    async def start_step(
        self, name: str, description: str, substeps: List[str] = None
    ) -> WorkflowStep:
        """새로운 단계 시작"""
        async with self._step_lock:
            # 현재 활성 단계 완료
            if self.active_step and self.active_step.status == StepStatus.ACTIVE:
                await self._complete_current_step()

            self.step_counter += 1
            step_id = f"step_{self.step_counter}"

            # 새로운 단계 생성
            new_step = WorkflowStep(
                step_id=step_id,
                step_number=self.step_counter,
                name=name,
                description=description,
                phase=self.current_phase,
                status=StepStatus.ACTIVE,
                start_time=kst_now,
            )

            # 하위 단계가 있는 경우 추가
            if substeps:
                for i, substep_name in enumerate(substeps, 1):
                    substep = WorkflowStep(
                        step_id=f"{step_id}_sub_{i}",
                        step_number=i,
                        name=substep_name,
                        description=f"{name}의 {i}번째 하위 작업",
                        phase=self.current_phase,
                        status=StepStatus.PENDING,
                    )
                    new_step.substeps.append(substep)

            self.workflow_steps.append(new_step)
            self.active_step = new_step

            # 이벤트 발송
            step_event = {
                "type": "STEP_START",
                "content": f"📋 {self.step_counter}단계: {name} 시작",
                "description": description,
                "key": step_id,
                "id": self.chat_id,
                "phase": self.current_phase.value,
                "step_number": self.step_counter,
                "has_substeps": len(new_step.substeps) > 0,
                "total_substeps": len(new_step.substeps),
            }
            await self._emit_event(step_event)

            return new_step

    async def get_current_workflow_status(self) -> Dict[str, Any]:
        """현재 워크플로우 상태 반환"""
        return {
            "current_phase": self.current_phase.value,
            "total_steps": len(self.workflow_steps),
            "active_step": self.active_step.step_id if self.active_step else None,
            "step_counter": self.step_counter,
            "is_planning_active": self.is_planning_active,
            "is_execution_active": self.is_execution_active,
        }

    async def force_complete_active_step(self, success: bool = True, summary: str = ""):
        """현재 활성 단계 강제 완료"""
        if self.active_step and self.active_step.status == StepStatus.ACTIVE:
            await self._complete_current_step(success, summary)

    async def complete_step(
        self, success: bool = True, result_summary: str = "", error: str = ""
    ) -> Optional[Dict[str, Any]]:
        """현재 단계 완료"""
        async with self._step_lock:
            if not self.active_step:
                return None

            return await self._complete_current_step(success, result_summary, error)

    async def _complete_current_step(
        self, success: bool = True, result_summary: str = "", error: str = ""
    ) -> Dict[str, Any]:
        """현재 활성 단계를 완료 (내부 메서드)"""
        if not self.active_step:
            return None

        step = self.active_step
        step.end_time = kst_now
        step.duration = (step.end_time - step.start_time).total_seconds()
        step.status = StepStatus.COMPLETED if success else StepStatus.FAILED

        if error:
            step.error_message = error

        # 이벤트 발송
        status_icon = "✅" if success else "❌"
        status_text = "완료" if success else "실패"

        complete_event = {
            "type": "STEP_COMPLETE" if success else "STEP_FAILED",
            "content": f"{status_icon} {step.step_number}단계 {status_text}: {step.name}",
            "description": result_summary or error or f"{step.name} {status_text}",
            "key": f"{step.step_id}_complete",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": step.step_number,
            "duration": step.duration,
            "success": success,
        }
        await self._emit_event(complete_event)

        self.active_step = None
        return complete_event

    async def start_planning(self, plan_description: str = "") -> Dict[str, Any]:
        """계획 수립 시작 (PLAN_START 이벤트)"""
        if self.is_planning_active:
            return None  # 이미 계획 중

        self.is_planning_active = True

        plan_event = {
            "type": "PLAN_START",
            "content": "🧠 실행 계획 수립 중...",
            "description": plan_description
            or "사용자 요청을 분석하여 최적의 실행 계획을 수립합니다",
            "key": f"planning_start_{int(time.time())}",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": self.step_counter,
        }
        await self._emit_event(plan_event)
        return plan_event

    async def complete_planning(self, plan_details: str = "") -> Dict[str, Any]:
        """계획 수립 완료 (PLAN_COMPLETE 이벤트)"""
        if not self.is_planning_active:
            return None  # 계획이 시작되지 않았음

        self.is_planning_active = False

        complete_event = {
            "type": "PLAN_COMPLETE",
            "content": "📋 실행 계획 수립 완료",
            "description": plan_details or "실행 계획이 성공적으로 수립되었습니다",
            "key": f"planning_complete_{int(time.time())}",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": self.step_counter,
        }
        await self._emit_event(complete_event)
        return complete_event

    async def start_action(
        self, action_name: str, action_description: str
    ) -> Dict[str, Any]:
        """액션 시작"""
        action_event = {
            "type": "ACTION_START",
            "content": f"⚡ {action_name} 실행 중...",
            "description": action_description,
            "key": f"action_{action_name}_{int(time.time())}",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": self.step_counter,
            "parent_step": self.active_step.step_id if self.active_step else None,
        }
        await self._emit_event(action_event)
        return action_event

    async def complete_action(
        self, action_name: str, success: bool = True, result: str = "", error: str = ""
    ) -> Dict[str, Any]:
        """액션 완료"""
        status_icon = "✅" if success else "❌"
        status_text = "성공" if success else "실패"

        action_event = {
            "type": "ACTION_SUCCESS" if success else "ACTION_FAIL",
            "content": f"{status_icon} {action_name} 실행 {status_text}",
            "description": result or error,
            "key": f"action_{action_name}_complete_{int(time.time())}",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": self.step_counter,
            "parent_step": self.active_step.step_id if self.active_step else None,
            "success": success,
        }
        await self._emit_event(action_event)
        return action_event

    async def add_thinking(self, thought: str) -> Dict[str, Any]:
        """생각/처리 중 이벤트"""
        thinking_event = {
            "type": "THINKING",
            "content": f"💭 {thought}",
            "description": "처리 상태 업데이트",
            "key": f"thinking_{int(time.time())}",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": self.step_counter,
        }
        await self._emit_event(thinking_event)
        return thinking_event

    async def add_routing_decision(
        self, routing_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """라우팅 결정 이벤트"""
        routing_event = {
            "type": "ROUTING",
            "content": f"🧭 {routing_info.get('decision', '라우팅 결정 완료')}",
            "description": routing_info.get(
                "description", "최적의 처리 방식을 결정했습니다"
            ),
            "key": "routing_decision",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "step_number": 0,  # 라우팅은 단계 번호 없음
            "routing_data": routing_info,
        }
        await self._emit_event(routing_event)
        return routing_event

    async def end_workflow(
        self, success: bool = True, summary: str = ""
    ) -> Dict[str, Any]:
        """워크플로우 종료"""
        # 활성 단계가 있으면 완료 처리
        if self.active_step and self.active_step.status == StepStatus.ACTIVE:
            await self._complete_current_step(success)

        self.current_phase = WorkflowPhase.COMPLETION

        status_icon = "✅" if success else "❌"
        status_text = "완료" if success else "실패"

        end_event = {
            "type": "END",
            "content": f"{status_icon} 워크플로우 {status_text}",
            "description": summary
            or f"전체 {len(self.workflow_steps)}단계 처리 {status_text}",
            "key": "workflow_end",
            "id": self.chat_id,
            "phase": self.current_phase.value,
            "total_steps": len(self.workflow_steps),
            "success": success,
        }
        await self._emit_event(end_event)
        return end_event

    async def get_workflow_summary(self) -> Dict[str, Any]:
        """워크플로우 요약 정보"""
        completed_steps = [
            s for s in self.workflow_steps if s.status == StepStatus.COMPLETED
        ]
        failed_steps = [s for s in self.workflow_steps if s.status == StepStatus.FAILED]

        total_duration = sum(
            step.duration for step in self.workflow_steps if step.duration is not None
        )

        return {
            "total_steps": len(self.workflow_steps),
            "completed_steps": len(completed_steps),
            "failed_steps": len(failed_steps),
            "success_rate": (
                len(completed_steps) / len(self.workflow_steps) * 100
                if self.workflow_steps
                else 0
            ),
            "total_duration": total_duration,
            "current_phase": self.current_phase.value,
            "is_active": self.active_step is not None,
        }

    async def _emit_event(self, event: Dict[str, Any]):
        """이벤트 발송"""
        # 타임스탬프 추가
        event["created_at"] = kst_now.isoformat() + "Z"

        # 큐에 추가
        try:
            await self.event_queue.put(event)
        except Exception as e:
            print(f"이벤트 발송 실패: {e}")


# =================================
# 향상된 콜백 핸들러 (순차적 이벤트 관리 적용)
# =================================


class EnhancedSequentialCallback:
    """순차적 이벤트 관리를 사용하는 향상된 콜백"""

    def __init__(self, chat_id: str, scenario_logger=None):
        self.chat_id = chat_id
        self.scenario_logger = scenario_logger
        self.event_manager = SequentialEventManager(chat_id)

        # 기존 콜백과의 호환성을 위한 큐
        self.event_queue = self.event_manager.event_queue

    async def get_recent_events(self, count: int = 1) -> List[Dict[str, Any]]:
        """최근 이벤트들을 가져오기"""
        events = []
        retrieved = 0

        while not self.event_queue.empty() and retrieved < count:
            try:
                event = self.event_queue.get_nowait()
                events.append(event)
                retrieved += 1
            except asyncio.QueueEmpty:
                break

        return events

    async def get_all_remaining_events(self) -> List[Dict[str, Any]]:
        """남은 모든 이벤트들을 가져오기"""
        events = []

        while not self.event_queue.empty():
            try:
                event = self.event_queue.get_nowait()
                events.append(event)
            except asyncio.QueueEmpty:
                break

        return events

    async def start_workflow(self, workflow_type: str, query: str):
        """워크플로우 시작"""
        return await self.event_manager.start_workflow(workflow_type, query)

    async def set_analysis_phase(self):
        """분석 단계 설정"""
        return await self.event_manager.advance_phase(
            WorkflowPhase.ANALYSIS, "쿼리 분석 및 복잡도 판단 중..."
        )

    async def set_routing_phase(self):
        """라우팅 단계 설정"""
        return await self.event_manager.advance_phase(
            WorkflowPhase.ROUTING, "최적의 처리 방식 결정 중..."
        )

    async def set_planning_phase(self):
        """계획 단계 설정"""
        return await self.event_manager.advance_phase(
            WorkflowPhase.PLANNING, "실행 계획 수립 중..."
        )

    async def set_execution_phase(self):
        """실행 단계 설정"""
        return await self.event_manager.advance_phase(
            WorkflowPhase.EXECUTION, "계획된 작업 실행 중..."
        )

    async def set_synthesis_phase(self):
        """결과 종합 단계 설정"""
        return await self.event_manager.advance_phase(
            WorkflowPhase.SYNTHESIS, "실행 결과 종합 및 정리 중..."
        )

    async def start_step(self, name: str, description: str, substeps: List[str] = None):
        """단계 시작"""
        return await self.event_manager.start_step(name, description, substeps)

    async def complete_step(
        self, success: bool = True, summary: str = "", error: str = ""
    ):
        """단계 완료"""
        return await self.event_manager.complete_step(success, summary, error)

    async def start_planning(self, description: str = ""):
        """계획 수립 시작"""
        return await self.event_manager.start_planning(description)

    async def complete_planning(self, plan_details: str = ""):
        """계획 수립 완료"""
        return await self.event_manager.complete_planning(plan_details)

    async def add_routing_decision(self, routing_info: Dict[str, Any]):
        """라우팅 결정 추가"""
        return await self.event_manager.add_routing_decision(routing_info)

    async def start_action(self, action_name: str, description: str):
        """액션 시작"""
        return await self.event_manager.start_action(action_name, description)

    async def complete_action(
        self, action_name: str, success: bool = True, result: str = "", error: str = ""
    ):
        """액션 완료"""
        return await self.event_manager.complete_action(
            action_name, success, result, error
        )

    async def add_thinking(self, thought: str):
        """생각 과정 추가"""
        return await self.event_manager.add_thinking(thought)

    async def end_workflow(self, success: bool = True, summary: str = ""):
        """워크플로우 종료"""
        return await self.event_manager.end_workflow(success, summary)

    async def get_all_events(self) -> List[Dict[str, Any]]:
        """모든 이벤트 반환"""
        events = []
        while not self.event_queue.empty():
            try:
                event = self.event_queue.get_nowait()
                events.append(event)
            except asyncio.QueueEmpty:
                break
        return events


# =================================
# 메모리 관리 클래스
# =================================


class EnhancedMemoryManager:
    """Mem0 OpenMemory를 활용한 향상된 메모리 관리"""

    def __init__(self, config: Optional[Dict] = None):
        """
        Mem0 Memory 초기화
        config 예시:
        {
            "graph_store": {
                "provider": "neo4j",
                "config": {
                    "url": "neo4j://localhost:7687",
                    "username": "neo4j",
                    "password": "password"
                }
            },
            "vector_store": {
                "provider": "qdrant",
                "config": {
                    "host": "localhost",
                    "port": 6333
                }
            },
            "llm": {
                "provider": "openai",
                "config": {
                    "model": "gpt-4",
                    "api_key": "your-api-key"
                }
            }
        }
        """
        try:
            # 🔥 임베디드 Qdrant 설정으로 변경
            default_config = {
                "vector_store": {
                    "provider": "qdrant",
                    "config": {
                        # "location": ":memory:",  # 인메모리 모드
                        # 또는 로컬 파일 사용시:
                        "path": "./local_qdrant",
                        "collection_name": "mcp_agent_memory",
                    },
                }
            }

            # 🔥 Claude 사용 시 LLM 설정 변경
            if os.getenv("ANTHROPIC_API_KEY"):
                default_config["llm"] = {
                    "provider": "anthropic",
                    "config": {
                        "model": "claude-3-5-sonnet-20241022",  # 정확한 모델명
                        "api_key": os.getenv("ANTHROPIC_API_KEY"),
                        # response_format 파라미터 제거
                        "temperature": 0.1,
                        "max_tokens": 5000,
                    },
                }
            elif os.getenv("OPENAI_API_KEY"):
                # OpenAI 사용 시에만 response_format 사용
                default_config["llm"] = {
                    "provider": "openai",
                    "config": {
                        "model": "gpt-4",
                        "api_key": os.getenv("OPENAI_API_KEY"),
                        "response_format": {"type": "json_object"},  # OpenAI만 지원
                    },
                }
            else:
                # LLM 없이 벡터 검색만 사용
                logger.warning("⚠️ LLM API 키가 없어 메모리 검색 기능만 사용됩니다")

            final_config = config or default_config
            self.memory = Memory.from_config(final_config)
            self.enabled = True
            logger.info("✅ Mem0 OpenMemory 초기화 성공")

        except Exception as e:
            logger.warning(f"⚠️ Mem0 초기화 실패, 메모리 기능 비활성화: {e}")
            self.memory = None
            self.enabled = False

    def _get_embedded_qdrant_config(self) -> Dict:
        """임베디드 Qdrant 설정"""
        return {
            "vector_store": {
                "provider": "qdrant",
                "config": {
                    # "location": ":memory:",  # 인메모리
                    "path": "./local_qdrant",
                    "collection_name": "mcp_agent_memory",
                },
            },
            "llm": self._get_llm_config(),  # 기존 LLM 설정 메서드 사용
        }

    def _test_embedded_qdrant(self) -> bool:
        """임베디드 Qdrant 테스트"""
        try:
            from qdrant_client import QdrantClient

            # 간단한 연결 테스트
            test_client = QdrantClient(":memory:")

            # 테스트 컬렉션 생성해보기
            from qdrant_client.models import Distance, VectorParams

            test_client.create_collection(
                collection_name="test_collection",
                vectors_config=VectorParams(size=100, distance=Distance.COSINE),
            )

            # 테스트 컬렉션 삭제
            test_client.delete_collection("test_collection")

            logger.info("✅ 임베디드 Qdrant 테스트 성공")
            return True

        except ImportError:
            logger.warning("⚠️ qdrant-client가 설치되지 않음")
            return False
        except Exception as e:
            logger.warning(f"⚠️ 임베디드 Qdrant 테스트 실패: {e}")
            return False

    async def add_conversation_memory(
        self, user_id: str, message: str, response: str, metadata: Optional[Dict] = None
    ) -> Optional[str]:
        """대화 메모리 추가 - 에러 처리 강화"""
        if not self.enabled or not self.memory:
            logger.debug("메모리 시스템이 비활성화되어 저장을 건너뜁니다")
            return None

        try:
            conversation_text = f"User: {message}\nAssistant: {response}"

            # 메타데이터 보강
            enhanced_metadata = {
                "conversation_id": user_id,
                "timestamp": kst_now.isoformat(),
                "message_type": "conversation",
                **(metadata or {}),
            }

            # 🔥 Mem0 호출 시 예외 처리 강화
            result = self.memory.add(
                messages=[{"role": "user", "content": conversation_text}],
                user_id=user_id,
                metadata=enhanced_metadata,
            )

            logger.info(f"💾 대화 메모리 저장 성공: {user_id}")
            return result.get("memory_id") if result else None

        except Exception as e:
            # 🔥 특정 에러 타입별 처리
            error_msg = str(e)
            if "response_format" in error_msg:
                logger.error(
                    f"❌ 모델이 response_format를 지원하지 않음. Mem0 설정을 확인하세요: {e}"
                )
            elif "Invalid API key" in error_msg:
                logger.error(f"❌ API 키가 유효하지 않음: {e}")
            elif "rate limit" in error_msg.lower():
                logger.error(f"❌ API 호출 한도 초과: {e}")
            else:
                logger.error(f"❌ 대화 메모리 저장 실패: {e}")

            # 메모리 저장 실패 시 기능 비활성화
            self.enabled = False
            return None

    async def add_user_preference(
        self, user_id: str, preference: str, category: str = "general"
    ) -> Optional[str]:
        """사용자 선호도 메모리 추가"""
        if not self.enabled:
            return None

        try:
            result = self.memory.add(
                messages=[
                    {"role": "user", "content": f"User preference: {preference}"}
                ],
                user_id=user_id,
                metadata={
                    "type": "preference",
                    "category": category,
                    "timestamp": kst_now.isoformat(),
                },
            )

            logger.info(f"👤 사용자 선호도 저장: {user_id} - {category}")
            return result.get("memory_id") if result else None

        except Exception as e:
            logger.error(f"❌ 선호도 저장 실패: {e}")
            return None

    async def add_tool_usage_memory(
        self,
        user_id: str,
        tool_name: str,
        query: str,
        success: bool,
        result_summary: str,
    ) -> Optional[str]:
        """도구 사용 패턴 메모리 추가"""
        if not self.enabled:
            return None

        try:
            usage_text = f"Tool: {tool_name}, Query: {query}, Success: {success}, Result: {result_summary}"

            result = self.memory.add(
                messages=[{"role": "system", "content": usage_text}],
                user_id=user_id,
                metadata={
                    "type": "tool_usage",
                    "tool_name": tool_name,
                    "success": success,
                    "timestamp": kst_now.isoformat(),
                },
            )

            return result.get("memory_id") if result else None

        except Exception as e:
            logger.error(f"❌ 도구 사용 메모리 저장 실패: {e}")
            return None

    async def get_relevant_memories(
        self,
        user_id: str,
        query: str,
        limit: int = 5,
        memory_type: Optional[str] = None,
    ) -> List[Dict]:
        """관련 메모리 검색"""
        if not self.enabled:
            return []

        try:
            search_filters = {"user_id": user_id}
            if memory_type:
                search_filters["metadata.type"] = memory_type

            memories = self.memory.search(query=query, user_id=user_id, limit=limit)

            return memories if memories else []

        except Exception as e:
            logger.error(f"❌ 메모리 검색 실패: {e}")
            return []

    async def get_user_preferences(
        self, user_id: str, category: Optional[str] = None
    ) -> List[Dict]:
        """사용자 선호도 조회"""
        return await self.get_relevant_memories(
            user_id=user_id,
            query="user preferences",
            memory_type="preference",
            limit=10,
        )

    async def get_conversation_history(
        self, user_id: str, limit: int = 10
    ) -> List[Dict]:
        """대화 기록 조회"""
        return await self.get_relevant_memories(
            user_id=user_id,
            query="conversation history",
            memory_type="conversation",
            limit=limit,
        )

    async def update_memory(self, memory_id: str, new_content: str) -> bool:
        """메모리 업데이트"""
        if not self.enabled:
            return False

        try:
            result = self.memory.update(memory_id=memory_id, data=new_content)
            return bool(result)
        except Exception as e:
            logger.error(f"❌ 메모리 업데이트 실패: {e}")
            return False

    async def delete_memory(self, memory_id: str) -> bool:
        """메모리 삭제"""
        if not self.enabled:
            return False

        try:
            result = self.memory.delete(memory_id=memory_id)
            return bool(result)
        except Exception as e:
            logger.error(f"❌ 메모리 삭제 실패: {e}")
            return False

    async def get_memory_stats(self, user_id: str) -> Dict[str, Any]:
        """사용자 메모리 통계"""
        if not self.enabled:
            return {"enabled": False}

        try:
            all_memories = await self.get_relevant_memories(user_id, "", limit=100)

            stats = {
                "enabled": True,
                "total_memories": len(all_memories),
                "conversation_count": len(
                    [
                        m
                        for m in all_memories
                        if m.get("metadata", {}).get("type") == "conversation"
                    ]
                ),
                "preference_count": len(
                    [
                        m
                        for m in all_memories
                        if m.get("metadata", {}).get("type") == "preference"
                    ]
                ),
                "tool_usage_count": len(
                    [
                        m
                        for m in all_memories
                        if m.get("metadata", {}).get("type") == "tool_usage"
                    ]
                ),
                "last_interaction": (
                    max(
                        [
                            m.get("metadata", {}).get("timestamp", "")
                            for m in all_memories
                        ]
                    )
                    if all_memories
                    else None
                ),
            }

            return stats

        except Exception as e:
            logger.error(f"❌ 메모리 통계 조회 실패: {e}")
            return {"enabled": True, "error": str(e)}


class WorkflowPatternMemoryManager(EnhancedMemoryManager):
    """워크플로우 패턴 학습을 위한 확장 메모리 관리자"""

    async def add_workflow_execution_memory(
        self, user_id: str, workflow_data: Dict[str, Any]
    ):
        """완전한 워크플로우 실행 패턴 저장"""

        workflow_memory = {
            # 🔥 1. 사용자 의도 분석
            "original_query": workflow_data["query"],
            "parsed_intent": workflow_data["intent_analysis"],
            "query_complexity": workflow_data["complexity"],
            "expected_output_type": workflow_data["output_type"],
            # 🔥 2. 워크플로우 구조
            "workflow_pattern": {
                "pattern_type": workflow_data["pattern_type"],
                "logical_steps": workflow_data["logical_steps"],
                "step_dependencies": workflow_data["dependencies"],
                "parallel_executability": workflow_data["parallel_steps"],
            },
            # 🔥 3. 도구 조합 패턴
            "tool_combinations": workflow_data["tool_combinations"],
            "tool_sequence": workflow_data["execution_order"],
            "tool_success_chain": workflow_data["success_chain"],
            # 🔥 4. 실행 결과
            "execution_success": workflow_data["success"],
            "execution_time": workflow_data["total_time"],
            "step_timings": workflow_data["step_timings"],
            "quality_score": workflow_data["quality_score"],
            # 🔥 5. 실패 분석
            "failure_points": workflow_data.get("failures", []),
            "recovery_strategies": workflow_data.get("recovery", []),
            "alternative_approaches": workflow_data.get("alternatives", []),
        }

        return await self.add_conversation_memory(
            user_id=user_id,
            message=f"WORKFLOW_PATTERN: {workflow_data['query']}",
            response=json.dumps(workflow_memory),
            metadata={
                "memory_type": "workflow_pattern",
                "pattern_type": workflow_data["pattern_type"],
                "success": workflow_data["success"],
                "tools_count": len(workflow_data["tool_combinations"]),
                "steps_count": len(workflow_data["logical_steps"]),
                "timestamp": kst_now.isoformat(),
            },
        )


# =================================
# MCP 툴 정보 관련 클래스들 - 도구 관련 질문 처리
# =================================


class SystemInfoGenerator:
    """시스템 정보 응답 생성기"""

    def __init__(self, agent):
        self.agent = agent

    async def generate_system_info_response(
        self, info_type: str, query: str
    ) -> Dict[str, Any]:
        """시스템 정보 응답 생성"""
        if info_type == "capabilities":
            return await self._generate_capabilities_info()
        elif info_type == "tools":
            return await self._generate_tools_info()
        elif info_type == "help":
            return await self._generate_help_info()
        elif info_type == "status":
            return await self._generate_status_info()
        else:
            return await self._generate_general_info()

    async def _generate_capabilities_info(self) -> Dict[str, Any]:
        """시스템 기능 정보 생성"""
        capabilities = []

        # MCP 서버별 기능 분석
        if self.agent.mcp_vector_store:
            try:
                server_results = self.agent.mcp_vector_store.search_servers_only(
                    "", limit=10
                )
                for server in server_results:
                    server_info = {
                        "server_name": server["server_name"],
                        "description": server["description"],
                        "categories": server.get("tags", []),
                        "use_cases": server.get("use_cases", []),
                    }
                    capabilities.append(server_info)
            except Exception as e:
                logger.warning(f"서버 정보 조회 실패: {e}")

        # 도구별 기능 분석
        tool_categories = {}
        if self.agent.tools:
            for tool in self.agent.tools:
                tool_name = tool.name.lower()
                tool_desc = getattr(tool, "description", "").lower()
                combined_text = f"{tool_name} {tool_desc}"

                categories = []
                if any(
                    kw in combined_text
                    for kw in ["browser", "web", "scrape", "navigate"]
                ):
                    categories.append("🌐 웹 브라우징 및 자동화")
                if any(
                    kw in combined_text
                    for kw in ["search", "find", "query", "perplexity"]
                ):
                    categories.append("🔍 웹 검색 및 정보 수집")
                if any(kw in combined_text for kw in ["file", "read", "write", "save"]):
                    categories.append("📁 파일 관리 및 처리")
                if any(
                    kw in combined_text
                    for kw in ["command", "execute", "shell", "terminal"]
                ):
                    categories.append("💻 시스템 명령 실행")
                if any(
                    kw in combined_text for kw in ["api", "http", "github", "slack"]
                ):
                    categories.append("🔗 API 연동 및 외부 서비스")
                if any(kw in combined_text for kw in ["weather", "climate"]):
                    categories.append("🌤️ 날씨 정보")
                if any(kw in combined_text for kw in ["database", "sql", "mysql"]):
                    categories.append("🗄️ 데이터베이스 관리")

                for category in categories:
                    if category not in tool_categories:
                        tool_categories[category] = []
                    tool_categories[category].append(
                        {
                            "name": tool.name,
                            "description": getattr(
                                tool, "description", "No description"
                            ),
                        }
                    )

        # 응답 생성
        response_parts = [
            "## 🤖 Enhanced MCP Agent 시스템 정보\n",
            f"안녕하세요! 저는 **{len(self.agent.tools) if self.agent.tools else 0}개의 전문 도구**를 활용하여 다양한 작업을 수행할 수 있는 AI 어시스턴트입니다.\n",
        ]

        if capabilities:
            response_parts.append("### 🔧 사용 가능한 MCP 서버들:\n")
            for server in capabilities[:5]:  # 상위 5개만 표시
                response_parts.append(
                    f"**{server['server_name']}**: {server['description']}"
                )
                if server.get("use_cases"):
                    response_parts.append(
                        f"  - 주요 용도: {', '.join(server['use_cases'][:3])}"
                    )
                response_parts.append("")

        if tool_categories:
            response_parts.append("### 🛠️ 주요 기능 카테고리:\n")
            for category, tools in tool_categories.items():
                response_parts.append(f"**{category}**")
                for tool in tools[:3]:  # 각 카테고리당 3개씩만 표시
                    response_parts.append(
                        f"  - `{tool['name']}`: {tool['description'][:80]}{'...' if len(tool['description']) > 80 else ''}"
                    )
                if len(tools) > 3:
                    response_parts.append(f"  - ... 외 {len(tools) - 3}개 추가 도구")
                response_parts.append("")

        response_parts.extend(
            [
                "### 💡 사용 예시:",
                '- "naver.com에서 USB 케이블 검색해줘"',
                '- "오늘 날씨 어때?"',
                '- "최신 AI 뉴스 알려줘"',
                '- "파일을 읽고 요약해줘"',
                '- "GitHub 레포지토리 정보 조회해줘"\n',
                "구체적인 요청을 주시면 적절한 도구를 선택하여 최적의 결과를 제공해드리겠습니다! 🚀",
            ]
        )

        return {
            "content": "\n".join(response_parts),
            "description": "시스템 기능 정보 제공",
            "summary": f"{len(capabilities)}개 서버, {len(tool_categories)}개 카테고리 정보 제공",
        }

    async def _generate_tools_info(self) -> Dict[str, Any]:
        """도구 정보 상세 생성"""
        # 도구별 상세 정보 생성 로직
        response_parts = ["## 🔧 사용 가능한 도구 상세 목록\n"]

        if self.agent.tools:
            # 서버별로 그룹화
            server_tools = {}
            for tool in self.agent.tools:
                # 서버명 추출 (도구명에서)
                server_name = "기타"
                tool_name_lower = tool.name.lower()

                known_servers = [
                    "hyperbrowser",
                    "perplexity",
                    "weather",
                    "desktop",
                    "github",
                    "slack",
                    "filesystem",
                ]
                for server in known_servers:
                    if server in tool_name_lower:
                        server_name = server.capitalize()
                        break

                if server_name not in server_tools:
                    server_tools[server_name] = []
                server_tools[server_name].append(tool)

            # 서버별 도구 정보 출력
            for server_name, tools in server_tools.items():
                response_parts.append(f"### 🖥️ {server_name} 서버 ({len(tools)}개 도구)")
                for tool in tools:
                    description = getattr(
                        tool, "description", "No description available"
                    )
                    response_parts.append(f"- **{tool.name}**: {description}")
                response_parts.append("")

        response_parts.append(
            "각 도구는 특정 작업에 최적화되어 있으며, 요청에 따라 자동으로 선택됩니다."
        )

        return {
            "content": "\n".join(response_parts),
            "description": "도구 상세 정보 제공",
            "summary": f"총 {len(self.agent.tools) if self.agent.tools else 0}개 도구 정보",
        }


# =================================
# MCP 메타데이터 시스템 클래스들
# =================================


class MCPConfigLoader:
    """MCP 설정 파일을 로드하고 관리하는 클래스"""

    def __init__(self, config_path: str = "mcp_config.json"):
        self.config_path = config_path

    def load_config(self) -> Dict[str, Dict[str, Any]]:
        """MCP 설정 파일을 로드"""
        try:
            config_file = Path(self.config_path)
            if not config_file.exists():
                logger.error(f"Config file not found: {self.config_path}")
                return {}

            with open(config_file, "r", encoding="utf-8") as f:
                config = json.load(f)

            if "mcpServers" not in config:
                logger.error("Invalid config format: 'mcpServers' key not found")
                return {}

            mcp_servers = config["mcpServers"]
            logger.info(f"Loaded {len(mcp_servers)} MCP servers from config")

            return mcp_servers

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in config file: {e}")
            return {}
        except Exception as e:
            logger.error(f"Error loading config file: {e}")
            return {}


class MCPMetadataCollector:
    """MCP 서버들의 메타데이터를 수집하는 클래스"""

    def __init__(self, timeout: int = 30):
        self.timeout = timeout

    async def collect_server_metadata(
        self, server_name: str, command: str, args: List[str]
    ) -> Optional[MCPMetadata]:
        """개별 MCP 서버의 메타데이터를 수집 (개선된 버전)"""
        logger.info(f"🔍 {server_name} 서버 메타데이터 수집 시작")

        try:
            server_params = StdioServerParameters(command=command, args=args)

            async with stdio_client(server_params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()

                    server_info = {
                        "server_name": server_name,
                        "command": command,
                        "args": args,
                        "connection_time": kst_now.isoformat(),
                    }

                    # 도구 수집
                    tools = []
                    try:
                        tools_result = await session.list_tools()
                        if tools_result.tools:
                            for tool in tools_result.tools:
                                tool_dict = asdict(tool)
                                # 추가 메타데이터 보강
                                if (
                                    "description" not in tool_dict
                                    or not tool_dict["description"]
                                ):
                                    tool_dict["description"] = (
                                        f"Tool: {tool_dict.get('name', 'unknown')}"
                                    )

                                # inputSchema가 있으면 파라미터 정보 추출
                                if (
                                    "inputSchema" in tool_dict
                                    and tool_dict["inputSchema"]
                                ):
                                    schema = tool_dict["inputSchema"]
                                    if (
                                        isinstance(schema, dict)
                                        and "properties" in schema
                                    ):
                                        param_count = len(schema["properties"])
                                        tool_dict["_metadata"] = {
                                            "parameter_count": param_count,
                                            "has_schema": True,
                                            "parameters": list(
                                                schema["properties"].keys()
                                            ),
                                        }

                                tools.append(tool_dict)

                        logger.info(
                            f"  ✅ {server_name}: {len(tools)}개 도구 수집 완료"
                        )

                    except Exception as e:
                        logger.warning(f"  ⚠️ {server_name}: 도구 수집 실패 - {e}")

                    # 리소스 수집
                    resources = []
                    try:
                        resources_result = await session.list_resources()
                        if resources_result.resources:
                            resources = [
                                asdict(resource)
                                for resource in resources_result.resources
                            ]
                        logger.info(
                            f"  ✅ {server_name}: {len(resources)}개 리소스 수집 완료"
                        )
                    except Exception as e:
                        logger.warning(f"  ⚠️ {server_name}: 리소스 수집 실패 - {e}")

                    # 프롬프트 수집
                    prompts = []
                    try:
                        prompts_result = await session.list_prompts()
                        if prompts_result.prompts:
                            prompts = [
                                asdict(prompt) for prompt in prompts_result.prompts
                            ]
                        logger.info(
                            f"  ✅ {server_name}: {len(prompts)}개 프롬프트 수집 완료"
                        )
                    except Exception as e:
                        logger.warning(f"  ⚠️ {server_name}: 프롬프트 수집 실패 - {e}")

                    # 서버 설명 생성
                    description = f"MCP Server: {server_name}"
                    if tools:
                        tool_categories = set()
                        for tool in tools:
                            name = tool.get("name", "").lower()
                            desc = tool.get("description", "").lower()
                            if any(
                                kw in f"{name} {desc}"
                                for kw in ["search", "find", "query"]
                            ):
                                tool_categories.add("search")
                            if any(
                                kw in f"{name} {desc}"
                                for kw in ["browser", "web", "scrape"]
                            ):
                                tool_categories.add("web")
                            if any(
                                kw in f"{name} {desc}"
                                for kw in ["file", "read", "write"]
                            ):
                                tool_categories.add("file")
                            if any(
                                kw in f"{name} {desc}"
                                for kw in ["command", "execute", "shell"]
                            ):
                                tool_categories.add("system")

                        if tool_categories:
                            description += (
                                f" - Capabilities: {', '.join(sorted(tool_categories))}"
                            )

                    metadata = MCPMetadata(
                        server_name=server_name,
                        description=description,
                        tools=tools,
                        resources=resources,
                        prompts=prompts,
                        command=command,
                        args=args,
                        server_info=server_info,
                    )

                    logger.info(
                        f"✅ {server_name} 메타데이터 수집 성공: {len(tools)}개 도구, {len(resources)}개 리소스, {len(prompts)}개 프롬프트"
                    )
                    return metadata

        except Exception as e:
            logger.error(f"❌ {server_name} 메타데이터 수집 실패: {e}")
            return None


class UnifiedMCPVectorStore:
    """통합 MCP 벡터 스토어 - InMemoryVectorStore 기반으로 변경"""

    def __init__(self, collection_name: str = "unified_mcp"):
        self.collection_name = collection_name

        # Azure OpenAI Embeddings 초기화 (기존 설정 유지)
        self.embedding_model = AzureOpenAIEmbeddings(
            azure_endpoint=os.getenv(
                "AZURE_OPENAI_ENDPOINT",
                "https://skcc-atl-master-openai-01.openai.azure.com/",
            ),
            api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            openai_api_type="azure",
            deployment="text-embedding-3-small",
        )

        # InMemoryVectorStore 초기화
        self.db = None
        self._documents_metadata = {}  # 문서 메타데이터 저장용

    def setup_collection(self):
        """컬렉션 설정 - InMemoryVectorStore 초기화"""
        try:
            from langchain_core.vectorstores import InMemoryVectorStore

            self.db = InMemoryVectorStore(self.embedding_model)
            logger.info(f"InMemoryVectorStore 초기화 완료: {self.collection_name}")

        except Exception as e:
            logger.error(f"InMemoryVectorStore 설정 오류: {e}")
            raise

    def _classify_tool(self, tool: Dict[str, Any]) -> str:
        """도구 분류 (기존과 동일)"""
        name = tool.get("name", "").lower()
        description = tool.get("description", "").lower()

        if any(word in name + description for word in ["search", "query", "find"]):
            return "search"
        elif any(
            word in name + description
            for word in ["click", "navigate", "type", "automation"]
        ):
            return "automation"
        elif any(
            word in name + description for word in ["extract", "scrape", "get", "read"]
        ):
            return "data_extraction"
        elif any(
            word in name + description for word in ["screenshot", "capture", "image"]
        ):
            return "visual"
        elif any(
            word in name + description for word in ["write", "create", "generate"]
        ):
            return "content_creation"
        elif any(word in name + description for word in ["file", "save", "load"]):
            return "file_operations"
        else:
            return "utility"

    def _extract_use_cases(self, description: str) -> List[str]:
        """사용 사례 추출 (기존과 동일)"""
        use_cases = []
        description_lower = description.lower()

        use_case_patterns = {
            "web search": ["web", "search"],
            "task automation": ["automation", "automate"],
            "data extraction": ["extract", "scrape"],
            "visual capture": ["screenshot", "capture"],
            "web navigation": ["navigate", "browse"],
            "form interaction": ["form", "input", "fill"],
            "content creation": ["create", "generate", "write"],
            "data processing": ["process", "analyze"],
        }

        for use_case, keywords in use_case_patterns.items():
            if any(keyword in description_lower for keyword in keywords):
                use_cases.append(use_case)

        return use_cases if use_cases else ["general"]

    def store_unified_metadata(self, mcp_data: Dict[str, Any]):
        """통합 메타데이터 저장 - InMemoryVectorStore 사용"""
        if not self.db:
            logger.error(
                "InMemoryVectorStore가 초기화되지 않았습니다. setup_collection()을 먼저 호출하세요."
            )
            return

        texts = []
        metadatas = []
        doc_ids = []

        for server_name, metadata in mcp_data.items():
            try:
                # 서버 요약 문서 생성
                server_categories = set()
                server_tools = []

                tools = metadata.get("tools", [])
                for tool in tools:
                    category = self._classify_tool(tool)
                    server_categories.add(category)
                    server_tools.append(tool.get("name", "unknown"))

                server_content = f"""
                Server: {server_name}
                Description: {metadata.get('description', '')}
                Categories: {', '.join(server_categories)}
                Tools: {', '.join(server_tools)}
                Tool Count: {len(tools)}
                Resources: {len(metadata.get('resources', []))}
                Prompts: {len(metadata.get('prompts', []))}
                """

                server_doc = UnifiedMCPDocument(
                    entity_type=EntityType.SERVER_SUMMARY,
                    server_name=server_name,
                    entity_name=server_name,
                    title=f"{server_name} Server",
                    description=metadata.get("description", ""),
                    content=server_content.strip(),
                    category="server",
                    tags=list(server_categories),
                    parameters=[],
                    use_cases=self._extract_server_use_cases(metadata),
                    metadata={
                        "tool_count": len(tools),
                        "server_info": metadata.get("server_info", {}),
                    },
                )

                self._add_document_to_lists(server_doc, texts, metadatas, doc_ids)

                # 개별 도구 문서들 생성
                for tool in tools:
                    tool_doc = self._create_tool_document(server_name, tool)
                    self._add_document_to_lists(tool_doc, texts, metadatas, doc_ids)

                # 리소스 문서들 생성
                for resource in metadata.get("resources", []):
                    resource_doc = self._create_resource_document(server_name, resource)
                    self._add_document_to_lists(resource_doc, texts, metadatas, doc_ids)

                # 프롬프트 문서들 생성
                for prompt in metadata.get("prompts", []):
                    prompt_doc = self._create_prompt_document(server_name, prompt)
                    self._add_document_to_lists(prompt_doc, texts, metadatas, doc_ids)

            except Exception as e:
                logger.error(f"서버 {server_name} 처리 중 오류: {e}")

        # InMemoryVectorStore에 저장
        try:
            if texts:
                self.db.add_texts(texts=texts, metadatas=metadatas, ids=doc_ids)
                logger.info(f"InMemoryVectorStore에 {len(texts)}개 문서 저장 완료")

                # 메타데이터 별도 저장 (상세 검색용)
                for i, doc_id in enumerate(doc_ids):
                    self._documents_metadata[doc_id] = metadatas[i]

        except Exception as e:
            logger.error(f"InMemoryVectorStore 저장 오류: {e}")
            raise

    def _add_document_to_lists(
        self, doc: UnifiedMCPDocument, texts: List, metadatas: List, doc_ids: List
    ):
        """문서를 리스트에 추가"""
        texts.append(doc.to_searchable_text())
        metadatas.append(
            {
                "entity_type": doc.entity_type.value,
                "server_name": doc.server_name,
                "entity_name": doc.entity_name,
                "category": doc.category,
                "tags": json.dumps(doc.tags),
                "parameters": json.dumps(doc.parameters),
                "use_cases": json.dumps(doc.use_cases),
                "title": doc.title,
                "description": doc.description,
                "metadata": json.dumps(doc.metadata),
            }
        )

        doc_id = hashlib.md5(
            f"{doc.entity_type.value}_{doc.server_name}_{doc.entity_name}".encode()
        ).hexdigest()
        doc_ids.append(doc_id)

    def _create_tool_document(
        self, server_name: str, tool: Dict[str, Any]
    ) -> UnifiedMCPDocument:
        """도구 문서 생성 (기존과 동일)"""
        tool_name = tool.get("name", "unknown")
        description = tool.get("description", "")

        parameters = []
        if "inputSchema" in tool and "properties" in tool["inputSchema"]:
            for param_name, param_info in tool["inputSchema"]["properties"].items():
                param_desc = param_info.get("description", "")
                parameters.append(f"{param_name}: {param_desc}")

        category = self._classify_tool(tool)
        use_cases = self._extract_use_cases(description)

        tags = [category]
        if "automation" in description.lower():
            tags.append("automation")
        if "web" in description.lower():
            tags.append("web")
        if "browser" in description.lower():
            tags.append("browser")

        content = f"""
        Tool: {tool_name}
        Function: {description}
        Parameters: {len(tool.get('inputSchema', {}).get('properties', {}))} parameters
        Input schema: {json.dumps(tool.get('inputSchema', {}), indent=2)}
        """

        return UnifiedMCPDocument(
            entity_type=EntityType.TOOL,
            server_name=server_name,
            entity_name=tool_name,
            title=f"{tool_name} Tool",
            description=description,
            content=content.strip(),
            category=category,
            tags=tags,
            parameters=list(tool.get("inputSchema", {}).get("properties", {}).keys()),
            use_cases=use_cases,
            metadata={
                "input_schema": tool.get("inputSchema", {}),
                "parameter_details": parameters,
            },
        )

    def _create_resource_document(
        self, server_name: str, resource: Dict[str, Any]
    ) -> UnifiedMCPDocument:
        """리소스 문서 생성 (기존과 동일)"""
        resource_name = resource.get("name", "unknown")
        description = resource.get("description", "")
        uri = resource.get("uri", "")
        mime_type = resource.get("mimeType", "")

        content = f"""
        Resource: {resource_name}
        URI: {uri}
        MIME Type: {mime_type}
        Description: {description}
        """

        if "json" in mime_type.lower():
            category = "data"
        elif "html" in mime_type.lower():
            category = "web_content"
        elif "image" in mime_type.lower():
            category = "visual"
        else:
            category = "resource"

        tags = [category, "resource"]
        use_cases = ["data_access", "information_retrieval"]

        return UnifiedMCPDocument(
            entity_type=EntityType.RESOURCE,
            server_name=server_name,
            entity_name=resource_name,
            title=f"{resource_name} Resource",
            description=description,
            content=content.strip(),
            category=category,
            tags=tags,
            parameters=[],
            use_cases=use_cases,
            metadata={"uri": uri, "mime_type": mime_type},
        )

    def _create_prompt_document(
        self, server_name: str, prompt: Dict[str, Any]
    ) -> UnifiedMCPDocument:
        """프롬프트 문서 생성 (기존과 동일)"""
        prompt_name = prompt.get("name", "unknown")
        description = prompt.get("description", "")
        arguments = prompt.get("arguments", [])

        parameters = []
        for arg in arguments:
            arg_name = arg.get("name", "")
            arg_desc = arg.get("description", "")
            required = arg.get("required", False)
            parameters.append(
                f"{arg_name}: {arg_desc} ({'required' if required else 'optional'})"
            )

        content = f"""
        Prompt: {prompt_name}
        Description: {description}
        Arguments: {len(arguments)} arguments
        Argument details: {json.dumps(arguments, indent=2)}
        """

        tags = ["prompt", "template"]
        use_cases = ["content_generation", "task_automation"]

        return UnifiedMCPDocument(
            entity_type=EntityType.PROMPT,
            server_name=server_name,
            entity_name=prompt_name,
            title=f"{prompt_name} Prompt",
            description=description,
            content=content.strip(),
            category="prompt",
            tags=tags,
            parameters=[arg.get("name", "") for arg in arguments],
            use_cases=use_cases,
            metadata={"arguments": arguments, "parameter_details": parameters},
        )

    def _extract_server_use_cases(self, metadata: Dict[str, Any]) -> List[str]:
        """서버 사용 사례 추출 (기존과 동일)"""
        use_cases = set()

        for tool in metadata.get("tools", []):
            tool_use_cases = self._extract_use_cases(tool.get("description", ""))
            use_cases.update(tool_use_cases)

        return list(use_cases)

    def smart_search(
        self,
        query: str,
        entity_types: List[EntityType] = None,
        categories: List[str] = None,
        servers: List[str] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """스마트 검색 - InMemoryVectorStore 기반"""
        if not self.db:
            logger.error("InMemoryVectorStore가 초기화되지 않았습니다")
            return []

        try:
            # InMemoryVectorStore는 필터링을 자체적으로 지원하지 않으므로
            # 검색 후 필터링을 수행
            docs_with_scores = self.db.similarity_search_with_score(
                query, k=limit * 3
            )  # 여유분 확보

            results = []
            for doc, score in docs_with_scores:
                # 메타데이터에서 필터링 조건 확인
                metadata = doc.metadata

                # 엔티티 타입 필터링
                if entity_types:
                    if metadata.get("entity_type") not in [
                        et.value for et in entity_types
                    ]:
                        continue

                # 카테고리 필터링
                if categories:
                    if metadata.get("category") not in categories:
                        continue

                # 서버 필터링
                if servers:
                    if metadata.get("server_name") not in servers:
                        continue

                result = {
                    "entity_type": metadata.get("entity_type"),
                    "server_name": metadata.get("server_name"),
                    "entity_name": metadata.get("entity_name"),
                    "title": metadata.get("title"),
                    "description": metadata.get("description"),
                    "category": metadata.get("category"),
                    "score": 1
                    - score,  # InMemoryVectorStore는 거리를 반환하므로 유사도로 변환
                    "tags": json.loads(metadata.get("tags", "[]")),
                    "parameters": json.loads(metadata.get("parameters", "[]")),
                    "use_cases": json.loads(metadata.get("use_cases", "[]")),
                    "content": doc.page_content,
                }
                results.append(result)

                if len(results) >= limit:
                    break

            return results

        except Exception as e:
            logger.error(f"InMemoryVectorStore 검색 오류: {e}")
            return []

    def search_tools_only(
        self, query: str, limit: int = 10, servers: List[str] = None
    ) -> List[Dict[str, Any]]:
        """도구만 검색"""
        return self.smart_search(
            query, entity_types=[EntityType.TOOL], servers=servers, limit=limit
        )

    def search_servers_only(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """서버만 검색"""
        return self.smart_search(
            query, entity_types=[EntityType.SERVER_SUMMARY], limit=limit
        )

    def two_stage_search(
        self, query: str, top_servers: int = 3, top_tools: int = 10
    ) -> Dict[str, Any]:
        """2단계 검색: 서버 먼저, 그 다음 도구"""

        # 1단계: 관련 서버 검색
        relevant_servers = self.search_servers_only(query, limit=top_servers)

        if not relevant_servers:
            return {
                "servers": [],
                "tools": [],
                "search_summary": {
                    "query": query,
                    "servers_found": 0,
                    "tools_found": 0,
                },
            }

        # 2단계: 선택된 서버에서 도구 검색
        server_names = [server["server_name"] for server in relevant_servers]
        relevant_tools = self.search_tools_only(
            query, limit=top_tools, servers=server_names
        )

        return {
            "servers": relevant_servers,
            "tools": relevant_tools,
            "search_summary": {
                "query": query,
                "servers_found": len(relevant_servers),
                "tools_found": len(relevant_tools),
                "selected_servers": server_names,
            },
        }


class MCPRecommendationSystem:
    """MCP 도구 추천 시스템"""

    def __init__(self, vector_store: UnifiedMCPVectorStore):
        self.vector_store = vector_store
        self.tool_popularity = {}
        self.tool_success_rate = {}

        self.category_weights = {
            "search": 1.2,
            "automation": 1.3,
            "data_extraction": 1.1,
            "visual": 1.0,
            "content_creation": 0.9,
            "file_operations": 0.8,
            "utility": 0.7,
        }

        self.task_patterns = {
            "web_automation": [
                "navigate_to",
                "click_element",
                "type_text",
                "wait_for_element",
            ],
            "data_scraping": ["navigate_to", "extract_text", "screenshot"],
            "web_search": ["search", "follow_up"],
            "form_filling": ["navigate_to", "type_text", "click_element"],
            "visual_capture": ["navigate_to", "screenshot", "extract_text"],
        }

    async def recommend_tools(
        self, query: str, max_servers: int = 3, max_tools: int = 10
    ) -> MCPRecommendationResult:
        """사용자 쿼리에 대한 종합적인 도구 추천"""

        search_results = self.vector_store.two_stage_search(
            query, top_servers=max_servers, top_tools=max_tools * 2
        )

        query_intent = self._analyze_query_intent(query)

        enhanced_tools = self._enhance_tool_scores(
            search_results["tools"], query, query_intent
        )

        tool_sequence = self._recommend_tool_sequence(
            query, enhanced_tools, query_intent
        )

        confidence = self._calculate_confidence(search_results, enhanced_tools)

        explanation = self._generate_explanation(
            query, search_results, enhanced_tools, query_intent
        )

        final_tools = enhanced_tools[:max_tools]

        tool_recommendations = [
            ToolRecommendation(
                server_name=tool["server_name"],
                tool_name=tool["entity_name"],
                score=tool["enhanced_score"],
                category=tool["category"],
                description=tool["description"],
                parameters=tool["parameters"],
                use_cases=tool["use_cases"],
                confidence=tool.get("confidence", 0.8),
                reason=tool.get("reason", "Semantic similarity match"),
            )
            for tool in final_tools
        ]

        return MCPRecommendationResult(
            query=query,
            recommended_servers=search_results["servers"],
            recommended_tools=tool_recommendations,
            tool_sequence=tool_sequence,
            confidence_score=confidence,
            explanation=explanation,
        )

    def _analyze_query_intent(self, query: str) -> Dict[str, Any]:
        """쿼리 의도 분석"""
        query_lower = query.lower()

        intent = {
            "task_type": "unknown",
            "keywords": [],
            "action_verbs": [],
            "targets": [],
            "complexity": "simple",
        }

        if any(
            word in query_lower for word in ["search", "find", "look up", "research"]
        ):
            intent["task_type"] = "search"
        elif any(
            word in query_lower for word in ["click", "navigate", "automate", "browse"]
        ):
            intent["task_type"] = "automation"
        elif any(
            word in query_lower for word in ["extract", "scrape", "get data", "collect"]
        ):
            intent["task_type"] = "data_extraction"
        elif any(word in query_lower for word in ["screenshot", "capture", "image"]):
            intent["task_type"] = "visual_capture"
        elif any(word in query_lower for word in ["fill", "form", "input", "type"]):
            intent["task_type"] = "form_interaction"

        action_patterns = r"\b(click|navigate|search|extract|type|fill|take|capture|get|find|browse|automate)\b"
        intent["action_verbs"] = re.findall(action_patterns, query_lower)

        target_patterns = (
            r"\b(button|link|form|page|website|element|text|image|data|information)\b"
        )
        intent["targets"] = re.findall(target_patterns, query_lower)

        if (
            len(intent["action_verbs"]) > 2
            or "and" in query_lower
            or "then" in query_lower
        ):
            intent["complexity"] = "complex"
        elif len(intent["action_verbs"]) == 0:
            intent["complexity"] = "simple"
        else:
            intent["complexity"] = "medium"

        return intent

    def _enhance_tool_scores(
        self, tools: List[Dict], query: str, intent: Dict
    ) -> List[Dict]:
        """도구 점수 향상 및 순위 재조정"""
        enhanced_tools = []

        for tool in tools:
            enhanced_tool = tool.copy()
            base_score = tool["score"]

            category_weight = self.category_weights.get(tool["category"], 1.0)

            intent_bonus = 0
            if intent["task_type"] in tool.get("use_cases", []):
                intent_bonus = 0.3
            elif intent["task_type"] == tool["category"]:
                intent_bonus = 0.2

            keyword_bonus = 0
            tool_text = f"{tool['entity_name']} {tool['description']}".lower()
            for verb in intent["action_verbs"]:
                if verb in tool_text:
                    keyword_bonus += 0.1

            for target in intent["targets"]:
                if target in tool_text:
                    keyword_bonus += 0.05

            popularity_bonus = (
                self.tool_popularity.get(
                    f"{tool['server_name']}.{tool['entity_name']}", 0
                )
                * 0.1
            )

            success_bonus = (
                self.tool_success_rate.get(
                    f"{tool['server_name']}.{tool['entity_name']}", 0.5
                )
                * 0.2
            )

            enhanced_score = (
                base_score * category_weight
                + intent_bonus
                + keyword_bonus
                + popularity_bonus
                + success_bonus
            )

            enhanced_tool["enhanced_score"] = enhanced_score
            enhanced_tool["category_weight"] = category_weight
            enhanced_tool["intent_bonus"] = intent_bonus
            enhanced_tool["keyword_bonus"] = keyword_bonus

            confidence = min(0.95, base_score + intent_bonus + keyword_bonus)
            enhanced_tool["confidence"] = confidence

            reasons = []
            if intent_bonus > 0.15:
                reasons.append("Strong task type match")
            if keyword_bonus > 0.1:
                reasons.append("High keyword relevance")
            if popularity_bonus > 0.05:
                reasons.append("Popular tool")
            if not reasons:
                reasons.append("Semantic similarity")

            enhanced_tool["reason"] = ", ".join(reasons)

            enhanced_tools.append(enhanced_tool)

        enhanced_tools.sort(key=lambda x: x["enhanced_score"], reverse=True)

        return enhanced_tools

    def _recommend_tool_sequence(
        self, query: str, tools: List[Dict], intent: Dict
    ) -> List[Dict[str, Any]]:
        """작업에 필요한 도구 시퀀스 추천"""

        if intent["complexity"] == "simple":
            if tools:
                return [
                    {
                        "step": 1,
                        "tool": f"{tools[0]['server_name']}.{tools[0]['entity_name']}",
                        "purpose": tools[0]["description"],
                        "required": True,
                    }
                ]
            return []

        task_type = intent["task_type"]

        if task_type in self.task_patterns:
            pattern = self.task_patterns[task_type]
            sequence = []
            step = 1

            for pattern_tool in pattern:
                matching_tools = [
                    tool
                    for tool in tools
                    if pattern_tool in tool["entity_name"].lower()
                    or pattern_tool in tool["description"].lower()
                ]

                if matching_tools:
                    best_tool = matching_tools[0]
                    sequence.append(
                        {
                            "step": step,
                            "tool": f"{best_tool['server_name']}.{best_tool['entity_name']}",
                            "purpose": self._get_tool_purpose(pattern_tool),
                            "required": step <= 2,
                        }
                    )
                    step += 1

            return sequence

        sequence = []
        for i, tool in enumerate(tools[:3], 1):
            sequence.append(
                {
                    "step": i,
                    "tool": f"{tool['server_name']}.{tool['entity_name']}",
                    "purpose": tool["description"][:50] + "...",
                    "required": i == 1,
                }
            )

        return sequence

    def _get_tool_purpose(self, pattern_tool: str) -> str:
        """패턴 도구의 목적 설명"""
        purposes = {
            "navigate_to": "대상 웹페이지로 이동",
            "click_element": "지정된 요소 클릭",
            "type_text": "텍스트 입력",
            "wait_for_element": "요소 로딩 대기",
            "extract_text": "텍스트 데이터 추출",
            "screenshot": "화면 캡처",
            "search": "정보 검색",
            "follow_up": "후속 질문",
        }
        return purposes.get(pattern_tool, f"{pattern_tool} 실행")

    def _calculate_confidence(
        self, search_results: Dict, enhanced_tools: List[Dict]
    ) -> float:
        """전체 추천 신뢰도 계산"""
        if not enhanced_tools:
            return 0.0

        top_confidences = [tool.get("confidence", 0.5) for tool in enhanced_tools[:3]]
        avg_confidence = sum(top_confidences) / len(top_confidences)

        server_bonus = 0.1 if len(search_results["servers"]) >= 2 else 0.0

        categories = set(tool["category"] for tool in enhanced_tools[:5])
        diversity_bonus = len(categories) * 0.05

        final_confidence = min(0.95, avg_confidence + server_bonus + diversity_bonus)
        return round(final_confidence, 3)

    def _generate_explanation(
        self, query: str, search_results: Dict, enhanced_tools: List[Dict], intent: Dict
    ) -> str:
        """추천 결과 설명 생성"""

        explanations = []

        explanations.append(f"분석된 작업 유형: {intent['task_type']}")

        if search_results["servers"]:
            top_server = search_results["servers"][0]
            explanations.append(
                f"주요 추천 서버: {top_server['server_name']} "
                f"(관련도: {top_server['score']:.2f})"
            )

        if enhanced_tools:
            top_tool = enhanced_tools[0]
            explanations.append(
                f"최우선 도구: {top_tool['entity_name']} "
                f"({top_tool['category']} 카테고리)"
            )

        if intent["complexity"] == "complex":
            explanations.append("복합 작업으로 판단되어 여러 도구의 조합을 추천합니다.")
        else:
            explanations.append("단순 작업으로 판단되어 핵심 도구를 우선 추천합니다.")

        return " | ".join(explanations)

    def update_tool_statistics(
        self, tool_name: str, success: bool, usage_count: int = 1
    ):
        """도구 사용 통계 업데이트"""

        if tool_name not in self.tool_popularity:
            self.tool_popularity[tool_name] = 0
        self.tool_popularity[tool_name] += usage_count

        if tool_name not in self.tool_success_rate:
            self.tool_success_rate[tool_name] = 0.5

        current_rate = self.tool_success_rate[tool_name]
        alpha = 0.1
        new_rate = alpha * (1.0 if success else 0.0) + (1 - alpha) * current_rate
        self.tool_success_rate[tool_name] = new_rate


class MCPMetadataEnricher:
    """MCP 메타데이터를 LLM으로 보강하는 클래스"""

    def __init__(self, llm_model, cache_duration_hours: int = 24):
        self.llm_model = llm_model
        self.cache_duration_hours = cache_duration_hours
        self.enrichment_cache = {}
        self.enrichment_status = EnrichmentStatus(
            is_enrichment_enabled=False,
            total_servers=0,
            enriched_servers=0,
            failed_servers=0,
            enrichment_progress=0.0,
            last_enrichment_time=None,
            cache_size=0,
            background_task_running=False,
        )

    async def enrich_server_metadata(
        self, server_name: str, metadata: Dict[str, Any]
    ) -> EnrichedMCPMetadata:
        """서버 메타데이터를 LLM으로 보강"""

        # 캐시 확인
        cache_key = f"{server_name}_{hash(str(metadata))}"
        if cache_key in self.enrichment_cache:
            cached_result = self.enrichment_cache[cache_key]
            if self._is_cache_valid(cached_result["timestamp"]):
                logger.info(f"💾 캐시에서 보강 정보 로드: {server_name}")
                return cached_result["data"]

        logger.info(f"🔍 LLM으로 메타데이터 보강 시작: {server_name}")

        try:
            # 서버 전체 정보 보강
            enriched_server_info = await self._enrich_server_info(server_name, metadata)

            # 개별 도구 정보 보강
            enriched_tools = []
            for tool in metadata.get("tools", []):
                enriched_tool = await self._enrich_tool_info(
                    server_name, tool, enriched_server_info
                )
                enriched_tools.append(enriched_tool)

            # 통합 메타데이터 생성
            enriched_metadata = EnrichedMCPMetadata(
                original_server_name=server_name,
                original_description=metadata.get("description", ""),
                original_tools=metadata.get("tools", []),
                original_resources=metadata.get("resources", []),
                original_prompts=metadata.get("prompts", []),
                enriched_server_description=enriched_server_info["description"],
                enriched_capabilities=enriched_server_info["capabilities"],
                enriched_use_cases=enriched_server_info["use_cases"],
                enriched_keywords=enriched_server_info["keywords"],
                enriched_tools=enriched_tools,
                enrichment_timestamp=kst_now.isoformat(),
                enrichment_confidence=enriched_server_info["confidence"],
            )

            # 캐시에 저장
            self.enrichment_cache[cache_key] = {
                "data": enriched_metadata,
                "timestamp": kst_now.isoformat(),
            }

            self.enrichment_status.enriched_servers += 1
            self.enrichment_status.cache_size = len(self.enrichment_cache)

            logger.info(f"✅ 메타데이터 보강 완료: {server_name}")
            return enriched_metadata

        except Exception as e:
            logger.error(f"❌ 메타데이터 보강 실패: {server_name} - {e}")
            self.enrichment_status.failed_servers += 1
            return self._create_fallback_enriched_metadata(server_name, metadata)

    async def _enrich_server_info(
        self, server_name: str, metadata: Dict[str, Any]
    ) -> Dict[str, Any]:
        """서버 전체 정보 보강"""

        tools_summary = []
        for tool in metadata.get("tools", []):
            tool_summary = f"- {tool.get('name', 'unknown')}: {tool.get('description', 'No description')[:100]}"
            tools_summary.append(tool_summary)

        tools_text = "\n".join(tools_summary) if tools_summary else "도구 정보 없음"

        prompt = f"""다음 MCP 서버의 정보를 분석하여 보강된 메타데이터를 생성해주세요:

서버명: {server_name}
원본 설명: {metadata.get('description', '설명 없음')}
도구 개수: {len(metadata.get('tools', []))}개

도구 목록:
{tools_text}

다음 형식의 JSON으로 응답해주세요:
{{
    "description": "서버의 상세하고 명확한 설명 (사용자 친화적으로)",
    "capabilities": ["핵심 기능1", "핵심 기능2", "핵심 기능3"],
    "use_cases": ["사용 사례1", "사용 사례2", "사용 사례3", "사용 사례4"],
    "keywords": ["검색용 키워드1", "키워드2", "키워드3", "키워드4"],
    "confidence": 0.85
}}

JSON 형식만 반환하고 다른 텍스트는 포함하지 마세요."""

        try:
            response = await self.llm_model.ainvoke(prompt)
            json_text = self._extract_json_from_response(response.content)
            enriched_info = json.loads(json_text)

            # 유효성 검증
            required_keys = [
                "description",
                "capabilities",
                "use_cases",
                "keywords",
                "confidence",
            ]
            for key in required_keys:
                if key not in enriched_info:
                    raise ValueError(f"필수 키 누락: {key}")

            return enriched_info

        except Exception as e:
            logger.error(f"서버 정보 보강 실패: {server_name} - {e}")
            return self._create_fallback_server_info(server_name, metadata)

    async def _enrich_tool_info(
        self, server_name: str, tool: Dict[str, Any], server_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """개별 도구 정보 보강"""

        tool_name = tool.get("name", "unknown")
        tool_description = tool.get("description", "")

        # 파라미터 정보 추출
        parameters_info = ""
        if "inputSchema" in tool and "properties" in tool["inputSchema"]:
            params = []
            for param_name, param_info in tool["inputSchema"]["properties"].items():
                param_desc = param_info.get("description", "")
                param_type = param_info.get("type", "unknown")
                params.append(f"- {param_name} ({param_type}): {param_desc}")
            parameters_info = "\n".join(params)

        prompt = f"""다음 도구의 정보를 분석하여 보강된 메타데이터를 생성해주세요:

서버: {server_name}
도구명: {tool_name}
원본 설명: {tool_description}
파라미터:
{parameters_info if parameters_info else "파라미터 정보 없음"}

다음 형식의 JSON으로 응답해주세요:
{{
    "enhanced_description": "도구의 구체적이고 사용자 친화적인 설명",
    "practical_use_cases": ["실제 사용 사례1", "사용 사례2", "사용 사례3"],
    "user_intent_keywords": ["사용자가 이 도구를 원할 때 사용할 키워드1", "키워드2"],
    "example_queries": ["이 도구를 사용하게 만드는 예시 쿼리1", "예시 쿼리2"],
    "category_refined": "automation|search|data_processing|file_operations|web_interaction|analysis",
    "complexity_level": "simple|medium|complex",
    "confidence": 0.9
}}

JSON 형식만 반환하세요."""

        try:
            response = await self.llm_model.ainvoke(prompt)
            json_text = self._extract_json_from_response(response.content)
            enriched_tool_info = json.loads(json_text)

            # 원본 도구 정보와 합치기
            enriched_tool = tool.copy()
            enriched_tool.update(
                {
                    "original_description": tool_description,
                    "enhanced_description": enriched_tool_info.get(
                        "enhanced_description", tool_description
                    ),
                    "practical_use_cases": enriched_tool_info.get(
                        "practical_use_cases", []
                    ),
                    "user_intent_keywords": enriched_tool_info.get(
                        "user_intent_keywords", []
                    ),
                    "example_queries": enriched_tool_info.get("example_queries", []),
                    "category_refined": enriched_tool_info.get(
                        "category_refined", "unknown"
                    ),
                    "complexity_level": enriched_tool_info.get(
                        "complexity_level", "medium"
                    ),
                    "enrichment_confidence": enriched_tool_info.get("confidence", 0.5),
                }
            )

            return enriched_tool

        except Exception as e:
            logger.error(f"도구 정보 보강 실패: {tool_name} - {e}")
            return self._create_fallback_tool_info(tool)

    def _extract_json_from_response(self, response: str) -> str:
        """LLM 응답에서 JSON 추출"""
        json_text = response.strip()
        if json_text.startswith("```json"):
            json_text = json_text[7:-3]
        elif json_text.startswith("```"):
            json_text = json_text[3:-3]
        return json_text.strip()

    def _create_fallback_enriched_metadata(
        self, server_name: str, metadata: Dict[str, Any]
    ) -> EnrichedMCPMetadata:
        """LLM 보강 실패 시 기본 보강 메타데이터 생성"""

        tools = metadata.get("tools", [])
        capabilities = set()
        keywords = set()

        for tool in tools:
            tool_name = tool.get("name", "").lower()
            tool_desc = tool.get("description", "").lower()

            if any(
                word in tool_name + tool_desc for word in ["browser", "web", "navigate"]
            ):
                capabilities.add("웹 브라우징")
                keywords.update(["웹", "브라우저", "사이트"])
            if any(
                word in tool_name + tool_desc for word in ["search", "find", "query"]
            ):
                capabilities.add("검색")
                keywords.update(["검색", "찾기"])

        return EnrichedMCPMetadata(
            original_server_name=server_name,
            original_description=metadata.get("description", ""),
            original_tools=tools,
            original_resources=metadata.get("resources", []),
            original_prompts=metadata.get("prompts", []),
            enriched_server_description=f"{server_name} 서버 - {len(tools)}개 도구 제공",
            enriched_capabilities=list(capabilities) or ["범용 도구"],
            enriched_use_cases=[f"{server_name} 기반 작업 수행"],
            enriched_keywords=list(keywords) or [server_name.lower()],
            enriched_tools=[self._create_fallback_tool_info(tool) for tool in tools],
            enrichment_timestamp=kst_now.isoformat(),
            enrichment_confidence=0.3,
        )

    def _create_fallback_tool_info(self, tool: Dict[str, Any]) -> Dict[str, Any]:
        """도구 정보 보강 실패 시 기본 정보"""
        enriched_tool = tool.copy()
        enriched_tool.update(
            {
                "enhanced_description": tool.get("description", "도구 설명 없음"),
                "practical_use_cases": ["범용 작업"],
                "user_intent_keywords": [tool.get("name", "unknown").lower()],
                "example_queries": [f"{tool.get('name', 'unknown')} 사용해줘"],
                "category_refined": "utility",
                "complexity_level": "medium",
                "enrichment_confidence": 0.3,
            }
        )
        return enriched_tool

    def _create_fallback_server_info(
        self, server_name: str, metadata: Dict[str, Any]
    ) -> Dict[str, Any]:
        """서버 정보 보강 실패 시 기본 정보"""
        return {
            "description": f"{server_name} MCP 서버",
            "capabilities": ["범용 도구 제공"],
            "use_cases": [f"{server_name} 기반 작업"],
            "keywords": [server_name.lower()],
            "confidence": 0.3,
        }

    def _is_cache_valid(self, timestamp: str) -> bool:
        """캐시 유효성 확인"""
        try:
            cache_time = datetime.fromisoformat(timestamp)
            current_time = kst_now
            hours_diff = (current_time - cache_time).total_seconds() / 3600
            return hours_diff < self.cache_duration_hours
        except:
            return False

    def get_enrichment_status(self) -> EnrichmentStatus:
        """보강 상태 조회"""
        if self.enrichment_status.total_servers > 0:
            self.enrichment_status.enrichment_progress = (
                self.enrichment_status.enriched_servers
                / self.enrichment_status.total_servers
                * 100
            )
        return self.enrichment_status


class EnrichedUnifiedMCPVectorStore:
    """LLM 보강 정보를 활용한 향상된 벡터 스토어"""

    def __init__(self, embedding_model, collection_name: str = "enriched_mcp"):
        self.embedding_model = embedding_model
        self.collection_name = collection_name
        self.db = None
        self._documents_metadata = {}

    def setup_collection(self):
        """컬렉션 설정"""
        if not LLM_ENRICHMENT_AVAILABLE:
            raise ImportError("LLM 보강 시스템을 사용할 수 없습니다")

        self.db = InMemoryVectorStore(self.embedding_model)
        logger.info(f"보강된 InMemoryVectorStore 초기화 완료: {self.collection_name}")

    def store_enriched_metadata(self, enriched_data: Dict[str, EnrichedMCPMetadata]):
        """보강된 메타데이터 저장"""
        if not self.db:
            logger.error("InMemoryVectorStore가 초기화되지 않았습니다.")
            return

        texts = []
        metadatas = []
        doc_ids = []

        for server_name, enriched_metadata in enriched_data.items():
            try:
                # 보강된 서버 문서 생성
                server_doc = self._create_enriched_server_document(enriched_metadata)
                self._add_document_to_lists(server_doc, texts, metadatas, doc_ids)

                # 보강된 도구 문서들 생성
                for enriched_tool in enriched_metadata.enriched_tools:
                    tool_doc = self._create_enriched_tool_document(
                        server_name, enriched_tool, enriched_metadata
                    )
                    self._add_document_to_lists(tool_doc, texts, metadatas, doc_ids)

            except Exception as e:
                logger.error(f"보강된 서버 {server_name} 처리 중 오류: {e}")

        # 벡터 DB에 저장
        try:
            if texts:
                self.db.add_texts(texts=texts, metadatas=metadatas, ids=doc_ids)
                logger.info(
                    f"보강된 InMemoryVectorStore에 {len(texts)}개 문서 저장 완료"
                )

        except Exception as e:
            logger.error(f"보강된 메타데이터 저장 오류: {e}")
            raise

    def _create_enriched_server_document(
        self, enriched_metadata: EnrichedMCPMetadata
    ) -> Dict[str, Any]:
        """보강된 서버 문서 생성"""

        content = f"""
        서버: {enriched_metadata.original_server_name}
        상세 설명: {enriched_metadata.enriched_server_description}
        핵심 기능: {', '.join(enriched_metadata.enriched_capabilities)}
        사용 사례: {', '.join(enriched_metadata.enriched_use_cases)}
        검색 키워드: {', '.join(enriched_metadata.enriched_keywords)}
        도구 개수: {len(enriched_metadata.enriched_tools)}개
        """

        searchable_text = f"""
        타입: server_summary
        서버: {enriched_metadata.original_server_name}
        설명: {enriched_metadata.enriched_server_description}
        내용: {content.strip()}
        태그: {', '.join(enriched_metadata.enriched_capabilities)}
        사용 사례: {', '.join(enriched_metadata.enriched_use_cases)}
        키워드: {', '.join(enriched_metadata.enriched_keywords)}
        """

        return {
            "content": searchable_text,
            "metadata": {
                "entity_type": "server_summary",
                "server_name": enriched_metadata.original_server_name,
                "entity_name": enriched_metadata.original_server_name,
                "title": f"{enriched_metadata.original_server_name} Server",
                "description": enriched_metadata.enriched_server_description,
                "category": "server",
                "tags": json.dumps(enriched_metadata.enriched_capabilities),
                "use_cases": json.dumps(enriched_metadata.enriched_use_cases),
                "keywords": json.dumps(enriched_metadata.enriched_keywords),
                "enrichment_confidence": enriched_metadata.enrichment_confidence,
                "enriched": True,
            },
        }

    def _create_enriched_tool_document(
        self,
        server_name: str,
        enriched_tool: Dict[str, Any],
        server_metadata: EnrichedMCPMetadata,
    ) -> Dict[str, Any]:
        """보강된 도구 문서 생성"""

        tool_name = enriched_tool.get("name", "unknown")
        enhanced_description = enriched_tool.get(
            "enhanced_description", enriched_tool.get("description", "")
        )

        content = f"""
        도구: {tool_name}
        서버: {server_name}
        상세 기능: {enhanced_description}
        카테고리: {enriched_tool.get('category_refined', 'unknown')}
        실용적 사용 사례: {', '.join(enriched_tool.get('practical_use_cases', []))}
        사용자 의도 키워드: {', '.join(enriched_tool.get('user_intent_keywords', []))}
        예시 쿼리: {', '.join(enriched_tool.get('example_queries', []))}
        """

        searchable_text = f"""
        타입: tool
        서버: {server_name}
        이름: {tool_name}
        설명: {enhanced_description}
        내용: {content.strip()}
        사용 사례: {', '.join(enriched_tool.get('practical_use_cases', []))}
        의도 키워드: {', '.join(enriched_tool.get('user_intent_keywords', []))}
        예시 쿼리: {', '.join(enriched_tool.get('example_queries', []))}
        """

        return {
            "content": searchable_text,
            "metadata": {
                "entity_type": "tool",
                "server_name": server_name,
                "entity_name": tool_name,
                "title": f"{tool_name} Tool",
                "description": enhanced_description,
                "category": enriched_tool.get("category_refined", "unknown"),
                "tags": json.dumps(
                    [enriched_tool.get("category_refined", "unknown"), "tool"]
                ),
                "parameters": json.dumps(
                    list(
                        enriched_tool.get("inputSchema", {})
                        .get("properties", {})
                        .keys()
                    )
                ),
                "use_cases": json.dumps(enriched_tool.get("practical_use_cases", [])),
                "intent_keywords": json.dumps(
                    enriched_tool.get("user_intent_keywords", [])
                ),
                "example_queries": json.dumps(enriched_tool.get("example_queries", [])),
                "enrichment_confidence": enriched_tool.get(
                    "enrichment_confidence", 0.5
                ),
                "enriched": True,
            },
        }

    def _add_document_to_lists(
        self, doc_data: Dict[str, Any], texts: List, metadatas: List, doc_ids: List
    ):
        """문서를 리스트에 추가"""
        texts.append(doc_data["content"])
        metadatas.append(doc_data["metadata"])

        entity_type = doc_data["metadata"]["entity_type"]
        server_name = doc_data["metadata"]["server_name"]
        entity_name = doc_data["metadata"]["entity_name"]

        doc_id = hashlib.md5(
            f"enriched_{entity_type}_{server_name}_{entity_name}".encode()
        ).hexdigest()
        doc_ids.append(doc_id)

    def smart_search(
        self,
        query: str,
        entity_types: List[EntityType] = None,
        categories: List[str] = None,
        servers: List[str] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """스마트 검색 - 보강된 정보 기반"""
        if not self.db:
            logger.error("InMemoryVectorStore가 초기화되지 않았습니다")
            return []

        try:
            search_limit = limit * 5
            docs_with_scores = self.db.similarity_search_with_score(
                query, k=search_limit
            )

            results = []
            for doc, score in docs_with_scores:
                metadata = doc.metadata

                # 필터링 로직 (기존과 동일)
                if entity_types:
                    if metadata.get("entity_type") not in [
                        et.value for et in entity_types
                    ]:
                        continue

                if categories:
                    if metadata.get("category") not in categories:
                        continue

                if servers:
                    if metadata.get("server_name") not in servers:
                        continue

                result = {
                    "entity_type": metadata.get("entity_type"),
                    "server_name": metadata.get("server_name"),
                    "entity_name": metadata.get("entity_name"),
                    "title": metadata.get("title"),
                    "description": metadata.get("description"),
                    "category": metadata.get("category"),
                    "score": 1 - score,
                    "tags": json.loads(metadata.get("tags", "[]")),
                    "parameters": json.loads(metadata.get("parameters", "[]")),
                    "use_cases": json.loads(metadata.get("use_cases", "[]")),
                    "content": doc.page_content,
                    "enriched": metadata.get("enriched", False),
                    "enrichment_confidence": metadata.get("enrichment_confidence", 0.0),
                }
                results.append(result)

                if len(results) >= limit:
                    break

            return results

        except Exception as e:
            logger.error(f"보강된 스마트 검색 오류: {e}")
            return []

    def search_tools_only(
        self, query: str, limit: int = 10, servers: List[str] = None
    ) -> List[Dict[str, Any]]:
        """도구만 검색"""
        return self.smart_search(
            query, entity_types=[EntityType.TOOL], servers=servers, limit=limit
        )

    def search_servers_only(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """서버만 검색"""
        return self.smart_search(
            query, entity_types=[EntityType.SERVER_SUMMARY], limit=limit
        )

    def two_stage_search(
        self, query: str, top_servers: int = 3, top_tools: int = 10
    ) -> Dict[str, Any]:
        """2단계 검색: 서버 먼저, 그 다음 도구"""

        relevant_servers = self.search_servers_only(query, limit=top_servers)

        if not relevant_servers:
            return {
                "servers": [],
                "tools": [],
                "search_summary": {
                    "query": query,
                    "servers_found": 0,
                    "tools_found": 0,
                },
            }

        server_names = [server["server_name"] for server in relevant_servers]
        relevant_tools = self.search_tools_only(
            query, limit=top_tools, servers=server_names
        )

        return {
            "servers": relevant_servers,
            "tools": relevant_tools,
            "search_summary": {
                "query": query,
                "servers_found": len(relevant_servers),
                "tools_found": len(relevant_tools),
                "selected_servers": server_names,
                "enriched_search": True,
            },
        }


# =================================
# 분석 및 라우팅 시스템
# =================================


class WorkflowPatternAnalyzer:
    """Mem0에서 워크플로우 패턴을 분석하고 학습하는 엔진"""

    def __init__(self, memory_manager: WorkflowPatternMemoryManager):
        self.memory_manager = memory_manager
        self.pattern_cache = {}
        self.success_patterns = {}

    async def learn_patterns_from_memory(
        self, pattern_type: str = None
    ) -> Dict[str, Any]:
        """메모리에서 성공적인 워크플로우 패턴 학습"""

        # 성공한 워크플로우들 조회
        successful_workflows = await self.memory_manager.get_relevant_memories(
            user_id="SYSTEM_PATTERNS",
            query=f"WORKFLOW_PATTERN success:true {pattern_type or ''}",
            limit=100,
            memory_type="workflow_pattern",
        )

        patterns = {}
        for workflow in successful_workflows:
            try:
                workflow_data = json.loads(workflow["memory"]["content"])
                pattern_key = workflow_data["workflow_pattern"]["pattern_type"]

                if pattern_key not in patterns:
                    patterns[pattern_key] = {
                        "examples": [],
                        "common_tools": {},
                        "common_sequences": {},
                        "success_factors": {},
                        "optimal_step_counts": [],
                    }

                patterns[pattern_key]["examples"].append(workflow_data)

                # 도구 사용 빈도 분석
                for tool in workflow_data["tool_combinations"]:
                    patterns[pattern_key]["common_tools"][tool] = (
                        patterns[pattern_key]["common_tools"].get(tool, 0) + 1
                    )

                # 시퀀스 패턴 분석
                sequence = " -> ".join(workflow_data["tool_sequence"])
                patterns[pattern_key]["common_sequences"][sequence] = (
                    patterns[pattern_key]["common_sequences"].get(sequence, 0) + 1
                )

            except Exception as e:
                logger.warning(f"패턴 분석 중 오류: {e}")
                continue

        return patterns

    async def get_recommended_workflow_for_query(
        self, query: str, user_id: str = None
    ) -> Dict[str, Any]:
        """쿼리에 대한 추천 워크플로우 생성"""

        # 쿼리 유형 분석
        query_analysis = await self._analyze_query_pattern(query)

        # 유사한 성공 사례 검색
        similar_workflows = await self.memory_manager.get_relevant_memories(
            user_id="SYSTEM_PATTERNS" if not user_id else user_id,
            query=f"WORKFLOW_PATTERN {query_analysis['keywords']}",
            limit=20,
        )

        # 사용자별 선호도 고려
        user_preferences = {}
        if user_id:
            user_prefs = await self.memory_manager.get_user_preferences(
                user_id, "workflow_preferences"
            )
            if user_prefs:
                user_preferences = json.loads(user_prefs[0]["memory"]["content"])

        # 최적 워크플로우 구성
        recommended_workflow = self._compose_optimal_workflow(
            query_analysis, similar_workflows, user_preferences
        )

        return recommended_workflow


class EnhancedSemanticQueryAnalyzer:
    """의미적 분석을 통한 향상된 쿼리 분석기 - 수정된 버전"""

    def __init__(self, embedding_model=None, llm_model=None):
        self.embedding_model = embedding_model
        self.llm_model = llm_model

        # 복잡한 작업 패턴들 (더 정확한 분류를 위해)
        self.complex_task_examples = [
            "naver.com에서 USB 케이블을 검색해서 추천해주고 파일로 저장해줘",
            "검색하고 분석해서 파일로 저장해줘",
            "여러 단계로 나누어서 처리해야 하는 작업",
            "A를 하고 B를 분석한 다음 C로 저장해줘",
            "데이터를 수집하고 처리해서 보고서를 만들어줘",
            "웹에서 정보를 찾아서 분석하고 정리해서 마크다운으로 저장해줘",
            "여러 사이트에서 검색하고 결과를 통합해서 파일로 저장해줘",
        ]

        self.simple_task_examples = [
            "안녕하세요",
            "날씨가 어때요?",
            "간단한 검색 요청",
            "한 가지만 알려주세요",
            "검색해줘",
            "찾아줘",
        ]

    async def _llm_semantic_analysis(self, query: str) -> Dict[str, Any]:
        """LLM을 통한 의미적 분석 - 누락된 메서드 추가"""
        if not self.llm_model:
            return {}

        analysis_prompt = f"""다음 사용자 쿼리를 분석하여 작업 복잡도를 판단해주세요:

쿼리: "{query}"

다음 기준으로 분석해주세요:
1. 필요한 작업 단계 수
2. 도구 조합 필요성
3. 데이터 변환/처리 여부
4. 파일 작업 포함 여부
5. 전체적인 복잡도 수준

JSON 형식으로 응답해주세요:
{{
    "complexity_level": "simple|medium|complex",
    "estimated_steps": 숫자,
    "requires_planning": true/false,
    "main_tasks": ["작업1", "작업2", ...],
    "required_tools": ["도구타입1", "도구타입2", ...],
    "confidence": 0.0-1.0
}}"""

        try:
            response = await self.llm_model.ainvoke(analysis_prompt)
            import json

            # JSON 추출 개선
            content = response.content.strip()
            if content.startswith("```json"):
                content = content[7:-3]
            elif content.startswith("```"):
                content = content[3:-3]

            analysis = json.loads(content)
            return analysis
        except Exception as e:
            logger.warning(f"LLM 의미적 분석 실패: {e}")
            return {}

    async def analyze_query_semantic(self, query: str) -> RoutingDecision:
        """의미적 분석을 통한 쿼리 복잡도 판단 - 수정된 버전"""

        # 1. 기본 패턴 분석 (향상됨)
        basic_complexity = self._analyze_basic_patterns_enhanced(query)

        # 2. LLM 기반 의미적 분석
        semantic_complexity = (
            await self._llm_semantic_analysis(query) if self.llm_model else None
        )

        # 3. 임베딩 기반 유사도 분석 (수정됨)
        embedding_complexity = (
            await self._embedding_similarity_analysis_fixed(query)
            if self.embedding_model
            else None
        )

        # 4. 종합 판단 (수정됨)
        final_decision = self._combine_analysis_results_fixed(
            query, basic_complexity, semantic_complexity, embedding_complexity
        )

        return final_decision

    def _analyze_basic_patterns_enhanced(self, query: str) -> Dict[str, Any]:
        """향상된 기본 패턴 분석 - 더 정밀한 분류"""
        query_lower = query.lower()

        # 🔥 수정: 복잡도 지시어 재분류
        complexity_indicators = {
            "high": [
                # 진짜 복잡한 작업만
                "검색해서",
                "분석해서",
                "저장해줘",
                "만들어줘",
                "그리고 나서",
                "다음에",
                "이후에",
                "단계별로",
                "순서대로",
                "파일로 저장",
                "보고서",
                "마크다운",
                "비교해서",
                "수집하고",
                "분석하고",
                "처리하고",
                "변환해서",
            ],
            "medium": [
                # 단순한 단일 작업들은 medium으로 하향
                "검색해줘",
                "찾아줘",
                "알려줘",
                "설명해줘",
                "추천해줘",
                "분석해줘",
                "정리해줘",  # 이들은 단일 도구로 처리 가능
            ],
            "low": [
                "안녕",
                "감사",
                "미안",
                "좋아",
                "싫어",
                "어때",
                "뭐야",
                "누구야",
                "언제야",
                "어디야",
            ],
        }

        # 🔥 수정: 다중 작업 패턴을 더 엄격하게 감지
        strict_multi_task_patterns = [
            ("검색해서", "그리고", "저장"),  # 검색+저장
            ("찾아서", "분석해서", "정리"),  # 찾기+분석+정리
            ("수집", "비교", "추천"),  # 수집+비교+추천
            ("여러", "사이트", "비교"),  # 다중 소스
            ("1.", "2.", "3."),  # 명시적 단계
        ]

        # 기본 점수 계산 (가중치 조정)
        complexity_score = 0

        for level, indicators in complexity_indicators.items():
            for indicator in indicators:
                if indicator in query_lower:
                    if level == "high":
                        complexity_score += 4  # 기존 3에서 4로 상향
                    elif level == "medium":
                        complexity_score += 1  # 기존 2에서 1로 하향
                    else:
                        complexity_score += 1

        # 진짜 다중 작업 패턴만 감지
        multi_task_score = 0
        for pattern in strict_multi_task_patterns:
            if all(word in query_lower for word in pattern):
                multi_task_score += 6  # 진짜 다중 작업은 높은 점수
                break

        # 단계별 작업 패턴 감지
        step_patterns = [
            r"(\w+)해서\s+(\w+)해서\s+(\w+)해줘",  # A해서 B해서 C해줘
            r"(\w+)하고\s+(\w+)하고\s+(\w+)해줘",  # A하고 B하고 C해줘
            r"(\w+)한\s+다음[에]?\s+(\w+)해줘",  # A한 다음 B해줘
        ]

        import re

        step_count = 0
        for pattern in step_patterns:
            matches = re.findall(pattern, query_lower)
            step_count += len(matches)

        # 복잡도 점수 계산
        complexity_score = multi_task_score  # 다중 작업 점수부터 시작

        for level, indicators in complexity_indicators.items():
            for indicator in indicators:
                if indicator in query_lower:
                    if level == "high":
                        complexity_score += 3
                    elif level == "medium":
                        complexity_score += 2
                    else:
                        complexity_score += 1

        # 연결어 패턴
        connectors = ["그리고", "그다음", "이후", "다음에", "또한", "추가로", "그러면"]
        connector_count = sum(1 for conn in connectors if conn in query_lower)

        # 파일 작업 패턴
        file_operations = [
            "저장",
            "save",
            "파일",
            "file",
            ".md",
            ".txt",
            ".json",
            ".csv",
            "markdown",
        ]
        file_op_count = sum(1 for op in file_operations if op in query_lower)

        return {
            "complexity_score": complexity_score,
            "step_count": step_count,
            "connector_count": connector_count,
            "file_operations": file_op_count,
            "multi_task_score": multi_task_score,
            "query_length": len(query),
            "estimated_steps": max(
                1, multi_task_score // 3
            ),  # 더 보수적인 단계 계산 max(1, step_count + connector_count + (2 if file_op_count > 0 else 0))
        }

    async def _embedding_similarity_analysis_fixed(self, query: str) -> Dict[str, Any]:
        """수정된 임베딩 기반 유사도 분석"""
        try:
            if not self.embedding_model:
                return {}

            # 쿼리 임베딩
            query_embedding = await self.embedding_model.aembed_query(query)

            # 복잡한 작업 예시들과 유사도 계산
            complex_embeddings = await self.embedding_model.aembed_documents(
                self.complex_task_examples
            )
            simple_embeddings = await self.embedding_model.aembed_documents(
                self.simple_task_examples
            )

            # 코사인 유사도 계산
            import numpy as np

            def cosine_similarity(a, b):
                return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

            complex_similarities = [
                cosine_similarity(query_embedding, emb) for emb in complex_embeddings
            ]
            simple_similarities = [
                cosine_similarity(query_embedding, emb) for emb in simple_embeddings
            ]

            max_complex_sim = max(complex_similarities) if complex_similarities else 0
            max_simple_sim = max(simple_similarities) if simple_similarities else 0
            avg_complex_sim = (
                sum(complex_similarities) / len(complex_similarities)
                if complex_similarities
                else 0
            )

            # 더 엄격한 복잡도 판단
            is_complex = (
                max_complex_sim > 0.7  # 높은 유사도
                or (max_complex_sim > max_simple_sim + 0.1)  # 상대적으로 더 높음
                or avg_complex_sim > 0.6  # 평균적으로도 높음
            )

            return {
                "complex_similarity": max_complex_sim,
                "simple_similarity": max_simple_sim,
                "avg_complex_similarity": avg_complex_sim,
                "similarity_ratio": max_complex_sim / (max_simple_sim + 0.001),
                "is_complex": is_complex,
                "confidence": max(max_complex_sim, max_simple_sim),
            }

        except Exception as e:
            logger.warning(f"임베딩 유사도 분석 실패: {e}")
            return {}

    # Enhanced Query Complexity Analysis - 개선된 버전

    def _combine_analysis_results_fixed(
        self, query: str, basic: Dict, semantic: Dict, embedding: Dict
    ) -> RoutingDecision:
        """수정된 분석 결과 종합 - 더 엄격한 복잡도 판단"""

        # 기본 점수
        complexity_score = basic.get("complexity_score", 0)
        multi_task_score = basic.get("multi_task_score", 0)
        estimated_steps = basic.get("estimated_steps", 1)

        logger.info(
            f"기본 분석 - 복잡도: {complexity_score}, 다중작업: {multi_task_score}, 단계: {estimated_steps}"
        )

        # 🔥 핵심 수정 1: 진짜 복합 작업만 감지
        actual_complex_indicators = [
            "그리고",
            "그 다음",
            "이후에",
            "또한",
            "추가로",  # 연결어
            "비교해서",
            "분석해서",
            "정리해서",
            "저장해줘",  # 연쇄 작업
            "1.",
            "2.",
            "3.",  # 명시적 단계
            "단계별로",
            "순서대로",
            "차례로",  # 순차 작업
        ]

        query_lower = query.lower()
        actual_complex_count = sum(
            1 for indicator in actual_complex_indicators if indicator in query_lower
        )

        # 🔥 핵심 수정 2: 단순 작업 패턴 강화 감지
        simple_patterns = [
            # 단일 검색/조회 패턴
            r"^[\w\s]*에 대해 (알려줘|설명해줘|분석해줘)$",
            r"^[\w\s]*(검색해줘|찾아줘|알려줘)$",
            r"^[\w\.com]+에서 [\w\s]*(검색해줘|찾아줘)$",
            # 단일 사이트 접속 패턴
            r"^[\w\.com]+에서 [\w\s-]+ (검색|찾)",
            # 간단한 정보 요청
            r"^[\w\s]*(뭐야|어때|어떻게|언제|어디서)$",
        ]

        import re

        is_simple_pattern = any(
            re.search(pattern, query, re.IGNORECASE) for pattern in simple_patterns
        )

        # 🔥 핵심 수정 3: LLM 분석 결과 가중치 조정
        llm_boost = 0
        if semantic:
            llm_complexity = semantic.get("complexity_level", "simple")
            llm_steps = semantic.get("estimated_steps", 1)
            llm_requires_planning = semantic.get("requires_planning", False)

            # LLM이 명확히 복잡하다고 판단한 경우만 가중치 부여
            if llm_complexity == "complex" and llm_requires_planning and llm_steps >= 3:
                llm_boost = 5  # 기존 5점 유지
            elif llm_complexity == "medium" and llm_steps >= 2:
                llm_boost = 2  # 기존 3점에서 2점으로 감소
            # simple은 가중치 없음

            complexity_score += llm_boost
            estimated_steps = max(estimated_steps, llm_steps)

            logger.info(
                f"LLM 분석 반영 후 - 복잡도: {complexity_score}, LLM 부스트: {llm_boost}"
            )

        # 🔥 핵심 수정 4: 임베딩 분석 결과 가중치 대폭 감소
        embedding_bonus = 0
        if embedding and embedding.get("is_complex", False):
            # 기존 8점에서 4점으로 대폭 감소
            embedding_bonus = 4

            # 추가 조건: 실제 복합 지시어가 있을 때만 추가 보너스
            if actual_complex_count >= 2:
                embedding_bonus += 2  # 최대 6점

            complexity_score += embedding_bonus
            logger.info(
                f"임베딩 분석 반영 후 - 복잡도: {complexity_score}, 보너스: {embedding_bonus}"
            )

        # 🔥 핵심 수정 5: 특별 패턴 조건 강화
        special_pattern_bonus = 0
        special_patterns = [
            # 진짜 복합 패턴만 선별
            ("검색해서", "추천해주고", "저장해줘"),  # 3단계 연쇄
            ("찾아서", "분석해서", "정리해줘"),  # 3단계 연쇄
            ("수집하고", "비교해서", "보고서"),  # 수집+분석+리포트
            ("여러", "비교", "추천"),  # 다중 소스 비교
        ]

        for pattern in special_patterns:
            if all(word in query_lower for word in pattern):
                special_pattern_bonus += 6  # 진짜 복합 패턴은 높은 점수
                break

        complexity_score += special_pattern_bonus

        if special_pattern_bonus > 0:
            logger.info(
                f"특별 패턴 반영 후 - 복잡도: {complexity_score}, 패턴 보너스: {special_pattern_bonus}"
            )

        # 🔥 핵심 수정 6: 단순 패턴 페널티 적용
        if is_simple_pattern:
            complexity_score = max(0, complexity_score - 5)  # 단순 패턴이면 -5점
            logger.info(f"단순 패턴 페널티 적용 후 - 복잡도: {complexity_score}")

        # 🔥 핵심 수정 7: 임계값 대폭 상향 조정
        if complexity_score >= 2 or estimated_steps >= 2 or actual_complex_count >= 1:
            # 기존 15점에서 20점으로 상향
            complexity = QueryComplexity.COMPLEX_TOOL
            approach = "hierarchical_planning"
            requires_planning = True
            confidence = min(0.95, 0.8 + (complexity_score / 30))

        elif complexity_score >= 1 or estimated_steps >= 1:
            # 최소한의 도구 사용도 complex로 처리
            complexity = QueryComplexity.COMPLEX_TOOL
            approach = "hierarchical_planning"
            requires_planning = True
            confidence = min(0.9, 0.7 + (complexity_score / 20))

        # elif complexity_score >= 2 or estimated_steps >= 2 or actual_complex_count >= 1:
        #    # 기존 8점에서 12점으로 상향
        #    complexity = QueryComplexity.SIMPLE_TOOL
        #    approach = "react_pattern"
        #    requires_planning = False
        #    confidence = min(0.9, 0.7 + (complexity_score / 20))

        else:
            # complexity = QueryComplexity.SIMPLE_TOOL
            # approach = "react_pattern"
            # requires_planning = False
            # confidence = min(0.85, 0.6 + (complexity_score / 20))
            complexity = QueryComplexity.COMPLEX_TOOL
            approach = "hierarchical_planning"
            requires_planning = True
            confidence = min(0.85, 0.6 + (complexity_score / 20))

        # reasoning 구성
        reasoning_parts = []
        reasoning_parts.append(f"기본: {basic.get('complexity_score', 0)}")
        if multi_task_score > 0:
            reasoning_parts.append(f"다중작업: +{multi_task_score}")
        if llm_boost > 0:
            reasoning_parts.append(f"LLM: +{llm_boost}")
        if embedding_bonus > 0:
            reasoning_parts.append(f"임베딩: +{embedding_bonus}")
        if special_pattern_bonus > 0:
            reasoning_parts.append(f"특별패턴: +{special_pattern_bonus}")
        if is_simple_pattern:
            reasoning_parts.append("단순패턴: -5")
        if actual_complex_count > 0:
            reasoning_parts.append(f"복합지시어: {actual_complex_count}개")
        reasoning_parts.append(f"최종: {complexity_score}")

        logger.info(
            f"최종 결정 - {complexity.value} (점수: {complexity_score}, 신뢰도: {confidence:.3f})"
        )

        return RoutingDecision(
            complexity=complexity,
            confidence=confidence,
            reasoning=" | ".join(reasoning_parts),
            recommended_approach=approach,
            estimated_steps=estimated_steps,
            requires_planning=requires_planning,
        )


class QueryAnalyzer:
    def __init__(self):
        self.chat_patterns = {
            "greetings": ["안녕", "hi", "hello", "하이", "헬로"],
            "thanks": ["감사", "고마워", "thank", "thanks"],
            "apology": ["미안", "죄송", "sorry"],
            "casual": ["기분", "어때", "뭐해", "어떻게", "좋아", "싫어"],
            "simple_questions": ["누구", "뭐", "언제", "어디", "왜", "어떻게"],
        }

        self.search_priority_patterns = {
            "factual_questions": [
                "누가",
                "언제",
                "어디서",
                "몇",
                "얼마",
                "최신",
                "현재",
                "지금",
                "오늘",
            ],
            "information_seeking": [
                "정보",
                "자료",
                "데이터",
                "통계",
                "뉴스",
                "소식",
                "동향",
                "트렌드",
            ],
            "research_queries": [
                "조사",
                "찾아",
                "알아봐",
                "검색",
                "확인",
                "파악",
                "분석",
            ],
            "comparison": ["비교", "차이", "vs", "대비", "어떤게", "더 좋은"],
            "current_events": ["최근", "요즘", "근래", "이번", "올해", "지난", "작년"],
            "verification": ["사실", "진짜", "정말", "맞나", "확실", "정확"],
            "specific_topics": [
                "주가",
                "환율",
                "날씨",
                "뉴스",
                "정치",
                "경제",
                "기술",
                "과학",
            ],
            "location_based": [
                "서울",
                "한국",
                "미국",
                "중국",
                "일본",
                "유럽",
                "지역",
                "도시",
            ],
        }

        self.query_patterns = {
            "browser": [
                "naver.com",
                "google.com",
                "웹사이트",
                "사이트",
                "페이지",
                "브라우저",
                "직접 접속",
                "웹에서 확인",
            ],
            "search": [
                "검색",
                "찾아",
                "알아봐",
                "조사",
                "정보",
                "뉴스",
                "최신",
                "확인해줘",
                "어떻게 돼",
            ],
            "weather": ["날씨", "기온", "온도", "비", "눈", "바람", "습도"],
            "command": ["실행", "명령", "터미널", "파일", "폴더", "디렉토리"],
            "file_ops": ["파일", "저장", "읽기", "작성", "생성", "다운로드"],
            "analysis": ["분석", "보고서", "요약", "통계", "차트", "그래프"],
        }

        self.server_specialties = {
            "perplexity-search": [
                "search",
                "analysis",
                "factual",
                "research",
                "information",
            ],
            "hyperbrowser": ["browser", "scraping", "web_navigation", "specific_site"],
            "desktop-commander": ["command", "file_ops"],
            "weather-mcp-server": ["weather"],
            "todoist-mcp": ["task", "todo"],
            "document-retriever": ["analysis", "search"],
        }

        self.complexity_indicators = {
            "simple": ["간단", "빠르게", "바로", "한번"],
            "medium": ["자세히", "설명", "비교", "분석", "추천"],
            "complex": ["보고서", "종합", "모든", "완전", "상세", "단계별"],
        }
        # 시스템 정보 쿼리 패턴
        self.system_info_patterns = {
            "capabilities": [
                "무엇을 할 수 있",
                "뭘 할 수 있",
                "어떤 일을",
                "기능이 뭐",
                "할 수 있는 일",
            ],
            "tools": ["어떤 도구", "도구 목록", "tool", "사용 가능한 도구", "툴"],
            "help": ["도움말", "사용법", "how to use", "설명서"],
            "status": ["상태", "현재 상황", "system status", "서버 정보"],
        }

    def _is_system_info_query(self, query_lower: str) -> str:
        """시스템 정보 쿼리 유형 판단"""
        for info_type, patterns in self.system_info_patterns.items():
            if any(pattern in query_lower for pattern in patterns):
                return info_type
        return None

    def analyze_query(self, query: str) -> QueryAnalysis:
        """쿼리를 분석하여 필요한 도구와 서버를 결정"""
        query_lower = query.lower().strip()

        # 시스템 정보 쿼리 확인
        system_info_type = self._is_system_info_query(query_lower)
        if system_info_type:
            return QueryAnalysis(
                query_type="system_info",
                complexity="simple",
                required_tools=[],
                preferred_servers=[],
                needs_realtime_data=False,
                estimated_steps=1,
                system_info_type=system_info_type,  # 새 필드 추가
            )

        if self._is_casual_chat(query, query_lower):
            return QueryAnalysis(
                query_type="chat",
                complexity="simple",
                required_tools=[],
                preferred_servers=[],
                needs_realtime_data=False,
                estimated_steps=1,
            )

        search_priority_score = self._calculate_search_priority(query_lower)
        browser_priority_score = self._calculate_browser_priority(query_lower)

        if (
            search_priority_score > browser_priority_score
            and search_priority_score >= 2
        ):
            query_type = "search"
        elif any(pattern in query_lower for pattern in self.query_patterns["browser"]):
            query_type = "browser"
        else:
            query_type = "chat"
            for type_name, patterns in self.query_patterns.items():
                if any(pattern in query_lower for pattern in patterns):
                    query_type = type_name
                    break

        complexity = "simple"
        if "추천" in query_lower or "여러" in query_lower or "3개" in query_lower:
            complexity = "medium"

        for comp_level, indicators in self.complexity_indicators.items():
            if any(indicator in query_lower for indicator in indicators):
                complexity = comp_level
                break

        required_tools = []
        if query_type != "chat":
            for tool_type, patterns in self.query_patterns.items():
                if any(pattern in query_lower for pattern in patterns):
                    required_tools.append(tool_type)

        preferred_servers = []
        if query_type != "chat":
            if query_type == "search" or search_priority_score >= 2:
                preferred_servers.append("perplexity-search")

            for server, specialties in self.server_specialties.items():
                if query_type in specialties or any(
                    tool in specialties for tool in required_tools
                ):
                    if server not in preferred_servers:
                        preferred_servers.append(server)

        realtime_keywords = ["최신", "현재", "지금", "오늘", "실시간", "요즘", "최근"]
        needs_realtime_data = any(
            keyword in query_lower for keyword in realtime_keywords
        )

        estimated_steps = 1
        if query_type != "chat":
            if complexity == "medium":
                estimated_steps = 2
            elif complexity == "complex":
                estimated_steps = 3 + len(required_tools)

        logger.info(
            f"쿼리 분석 결과: 타입={query_type}, 복잡도={complexity}, 검색우선도={search_priority_score}, 예상단계={estimated_steps}"
        )

        return QueryAnalysis(
            query_type=query_type,
            complexity=complexity,
            required_tools=required_tools,
            preferred_servers=preferred_servers,
            needs_realtime_data=needs_realtime_data,
            estimated_steps=estimated_steps,
        )

    def _calculate_search_priority(self, query_lower: str) -> int:
        """검색 도구 사용 우선순위 점수 계산"""
        score = 0

        for category, patterns in self.search_priority_patterns.items():
            for pattern in patterns:
                if pattern in query_lower:
                    if category == "factual_questions":
                        score += 3
                    elif category == "current_events":
                        score += 3
                    elif category == "information_seeking":
                        score += 2
                    elif category == "research_queries":
                        score += 2
                    else:
                        score += 1

        question_patterns = [
            "?",
            "인가",
            "나요",
            "까요",
            "어떤",
            "얼마",
            "언제",
            "어디",
        ]
        if any(pattern in query_lower for pattern in question_patterns):
            score += 1

        return score

    def _calculate_browser_priority(self, query_lower: str) -> int:
        """브라우저 도구 사용 우선순위 점수 계산"""
        score = 0

        if any(
            site in query_lower
            for site in [".com", ".kr", ".net", "사이트", "웹사이트"]
        ):
            score += 5

        browser_keywords = ["접속", "들어가", "방문", "페이지", "브라우저"]
        for keyword in browser_keywords:
            if keyword in query_lower:
                score += 2

        return score

    def _is_casual_chat(self, original_query: str, query_lower: str) -> bool:
        """일반 채팅인지 판단 (개선된 버전)"""

        # 🔧 수정: 더 엄격한 단순 채팅 판단
        simple_greetings = [
            "안녕",
            "hi",
            "hello",
            "하이",
            "헬로",
            "반가워",
            "안녕하세요",
        ]
        simple_responses = [
            "네",
            "응",
            "그래",
            "알겠어",
            "고마워",
            "감사",
            "미안",
            "죄송",
        ]
        simple_questions = ["어때", "뭐해", "어떻게", "괜찮아"]

        # 길이가 짧고 단순한 패턴인 경우
        if len(original_query.strip()) <= 15:
            for pattern_list in [simple_greetings, simple_responses, simple_questions]:
                if any(pattern in query_lower for pattern in pattern_list):
                    return True

        # 도구 사용을 명시적으로 요구하는 키워드가 있으면 채팅이 아님
        tool_keywords = ["검색", "찾아", "알아봐", "해줘", "실행", "보여줘", "추천"]
        if any(keyword in query_lower for keyword in tool_keywords):
            return False

        return False


class MCPServerRouter:
    def __init__(self, available_tools: List):
        self.available_tools = available_tools
        self.server_capabilities = self._analyze_tool_capabilities()

    # 🔥 핵심 변경: 메서드를 async로 변경
    async def route_query(
        self, query_analysis: QueryAnalysis, available_tools: List
    ) -> Tuple[List, str]:
        """쿼리 분석을 바탕으로 최적의 도구들 선택 - 비동기 버전"""

        # MCP 메타데이터 기반 스마트 라우팅 추가
        if (
            hasattr(self, "mcp_recommendation_system")
            and self.mcp_recommendation_system
        ):
            try:
                # ✅ 이제 안전하게 await 사용 가능
                recommendation = await self.mcp_recommendation_system.recommend_tools(
                    f"{query_analysis.query_type} {' '.join(query_analysis.required_tools)}"
                )

                if recommendation and recommendation.recommended_tools:
                    # 추천된 도구들을 실제 도구 객체와 매칭
                    recommended_tools = []
                    for rec_tool in recommendation.recommended_tools:
                        for tool in available_tools:
                            if (
                                rec_tool.tool_name.lower() in tool.name.lower()
                                or tool.name.lower() in rec_tool.tool_name.lower()
                            ):
                                recommended_tools.append(tool)
                                break

                    if recommended_tools:
                        confidence_score = recommendation.confidence_score
                        system_type = (
                            "보강된"
                            if getattr(self, "enriched_system_enabled", False)
                            else "기존"
                        )
                        reason = f"{system_type} MCP 메타데이터 기반 추천 (신뢰도: {confidence_score:.2f})"
                        logger.info(
                            f"🎯 메타데이터 기반 라우팅 성공: {len(recommended_tools)}개 도구 선택"
                        )
                        return recommended_tools, reason

            except Exception as rec_error:
                logger.warning(f"⚠️ MCP 추천 라우팅 실패: {rec_error}")

        # 기존 동기 라우팅 로직...
        if query_analysis.query_type == "chat":
            return [], "일반 대화 - 도구 사용 불필요"

        if not available_tools:
            return [], "사용 가능한 도구 없음"

        logger.info(
            f"라우팅 시작: 쿼리타입={query_analysis.query_type}, 사용가능도구={len(available_tools)}개"
        )

        # 검색 쿼리 처리
        if query_analysis.query_type == "search":
            perplexity_tools = []
            other_search_tools = []
            other_tools = []

            for tool in available_tools:
                tool_name = (
                    tool.name.lower() if hasattr(tool, "name") else str(tool).lower()
                )
                if "perplexity" in tool_name:
                    perplexity_tools.append(tool)
                elif "search" in tool_name:
                    other_search_tools.append(tool)
                else:
                    other_tools.append(tool)

            if perplexity_tools:
                selected = perplexity_tools + other_search_tools[:1]
                logger.info(
                    f"검색 쿼리 라우팅: perplexity 우선, {len(selected)}개 도구 선택"
                )
                return (
                    selected,
                    f"검색 작업을 위해 perplexity 우선 {len(selected)}개 도구 선택",
                )

        # 브라우저 쿼리 처리
        if query_analysis.query_type == "browser":
            browser_tools = []
            other_tools = []

            for tool in available_tools:
                tool_name = (
                    tool.name.lower() if hasattr(tool, "name") else str(tool).lower()
                )
                if "browser" in tool_name or "hyperbrowser" in tool_name:
                    browser_tools.append(tool)
                else:
                    other_tools.append(tool)

            if browser_tools:
                selected = browser_tools
                logger.info(f"브라우저 쿼리 라우팅: {len(selected)}개 도구 선택")
                return selected, f"브라우저 작업을 위해 {len(selected)}개 도구 선택"

        # 복잡한 쿼리 처리
        if query_analysis.complexity == "complex":
            perplexity_tools = [
                t for t in available_tools if "perplexity" in t.name.lower()
            ]
            if perplexity_tools:
                other_tools = [
                    t for t in available_tools if "perplexity" not in t.name.lower()
                ]
                selected = perplexity_tools + other_tools[:3]
                logger.info(f"복잡한 쿼리: perplexity 포함 {len(selected)}개 도구 사용")
                return (
                    selected,
                    f"복잡한 쿼리 - perplexity 포함 {len(selected)}개 도구 사용",
                )
            else:
                logger.info(f"복잡한 쿼리: 모든 {len(available_tools)}개 도구 사용")
                return available_tools, "복잡한 쿼리 - 모든 도구 사용"

        # 기본 도구 선택
        relevant_tools = []
        query_keywords = set(
            query_analysis.required_tools + [query_analysis.query_type]
        )

        perplexity_tools = [
            t for t in available_tools if "perplexity" in t.name.lower()
        ]
        if perplexity_tools and (
            "search" in query_keywords or "information" in query_keywords
        ):
            relevant_tools.extend(perplexity_tools)

        for tool in available_tools:
            if tool in relevant_tools:
                continue

            tool_name = (
                tool.name.lower() if hasattr(tool, "name") else str(tool).lower()
            )
            tool_desc = getattr(tool, "description", "").lower()

            is_relevant = False

            if (
                query_analysis.query_type in tool_name
                or query_analysis.query_type in tool_desc
            ):
                is_relevant = True

            for keyword in query_keywords:
                if keyword in tool_name or keyword in tool_desc:
                    is_relevant = True
                    break

            if is_relevant:
                relevant_tools.append(tool)

        if not relevant_tools and available_tools:
            priority_tools = []
            for tool in available_tools:
                tool_name = tool.name.lower()
                if "perplexity" in tool_name:
                    priority_tools.insert(0, tool)
                elif "search" in tool_name:
                    priority_tools.insert(1 if priority_tools else 0, tool)
                elif "browser" in tool_name:
                    priority_tools.append(tool)
                else:
                    priority_tools.append(tool)

            relevant_tools = priority_tools[:3]
            reason = "관련 도구를 찾지 못해 perplexity 우선 기본 도구 사용"
        else:
            reason = f"쿼리 타입 '{query_analysis.query_type}'에 맞는 {len(relevant_tools)}개 도구 선택"

        logger.info(f"라우팅 완료: {len(relevant_tools)}개 도구 선택됨")
        return relevant_tools, reason

    def _analyze_tool_capabilities(self) -> Dict[str, List[str]]:
        """도구 이름을 기반으로 서버 기능 분석"""
        capabilities = {}

        for tool in self.available_tools:
            tool_name = (
                tool.name.lower() if hasattr(tool, "name") else str(tool).lower()
            )
            tool_caps = []

            if "perplexity" in tool_name:
                tool_caps.extend(
                    [
                        "search",
                        "web_search",
                        "research",
                        "factual",
                        "information",
                        "analysis",
                    ]
                )
            elif any(keyword in tool_name for keyword in ["search", "query", "find"]):
                tool_caps.extend(["search", "web_search"])

            if any(
                keyword in tool_name
                for keyword in ["browser", "scrape", "crawl", "hyperbrowser", "web"]
            ):
                tool_caps.extend(["browser", "scraping", "web_navigation"])
            if any(
                keyword in tool_name
                for keyword in ["file", "command", "desktop", "system"]
            ):
                tool_caps.extend(["file_system", "command_execution", "system"])
            if any(keyword in tool_name for keyword in ["weather", "climate"]):
                tool_caps.extend(["weather", "climate"])
            if any(keyword in tool_name for keyword in ["task", "todo"]):
                tool_caps.extend(["task_management", "todo"])

            capabilities[tool.name] = tool_caps

        return capabilities


# =================================
# 로깅 및 콜백 시스템
# =================================


class ScenarioLogger:
    def __init__(self):
        self.scenarios = {}
        self.active_sessions = set()

    def start_scenario(self, chat_id: str, query: str, scenario_name: str = None):
        """시나리오 시작"""
        if not scenario_name:
            scenario_name = self._generate_scenario_name(query)

        self.scenarios[chat_id] = {
            "scenario_name": scenario_name,
            "events": [],
            "start_time": kst_now,
            "query": query,
            "completed": False,
        }
        self.active_sessions.add(chat_id)

    def add_event(self, chat_id: str, event_dict: Dict[str, Any]):
        """이벤트 추가"""
        if chat_id in self.scenarios:
            self.scenarios[chat_id]["events"].append(event_dict)

    def complete_scenario(self, chat_id: str):
        """시나리오 완료"""
        if chat_id in self.scenarios:
            self.scenarios[chat_id]["completed"] = True
            self.scenarios[chat_id]["end_time"] = kst_now
            self.active_sessions.discard(chat_id)

    def get_scenario(self, chat_id: str) -> Optional[Dict]:
        """시나리오 조회"""
        return self.scenarios.get(chat_id)

    def get_scenario_json_schema(self, chat_id: str) -> Optional[Dict]:
        """JSON Schema 형식으로 시나리오 반환"""
        scenario = self.scenarios.get(chat_id)
        if not scenario:
            return None

        return {scenario["scenario_name"]: scenario["events"]}

    def _generate_scenario_name(self, query: str) -> str:
        """쿼리에서 시나리오 이름 생성"""
        query_lower = query.lower()

        if "naver" in query_lower and ("usb" in query_lower or "케이블" in query_lower):
            return "scenario_naver_usb_cable_search"
        elif "날씨" in query_lower:
            return "scenario_weather_query"
        elif "검색" in query_lower:
            return "scenario_web_search"
        elif "영화" in query_lower and "추천" in query_lower:
            return "scenario_movie_recommendation"
        else:
            words = query_lower.split()[:3]
            clean_words = [word for word in words if len(word) > 1]
            return f"scenario_{'_'.join(clean_words)}"


# =================================
# 수정된 콜백 핸들러 - AsyncIO 이벤트 루프 문제 해결
# =================================


class EnhancedFrontendEventCallback(BaseCallbackHandler):
    """수정된 콜백 핸들러 - 이벤트 루프 안전성 개선"""

    def __init__(self, chat_id: str, event_queue: asyncio.Queue, scenario_logger=None):
        self.chat_id = chat_id
        self.event_queue = event_queue
        self.scenario_logger = scenario_logger

        # 순차적 이벤트 관리자
        self.sequential_callback = EnhancedSequentialCallback(chat_id, scenario_logger)

        # 기존 호환성을 위한 변수들
        self.step_counter = 0
        self.plan_counter = 0
        self.current_plan_key = None
        self.failed_tools = []
        self.current_tool_name = None
        self.tool_usage_stats = {}
        self.active_tools = set()

        # 워크플로우 상태
        self.workflow_started = False
        self.current_phase = None
        self.current_step_active = False

    def _safe_create_task(self, coro):
        """안전한 태스크 생성 - 이벤트 루프 확인 (개선된 버전)"""
        try:
            import asyncio

            loop = asyncio.get_running_loop()
            # ✅ 즉시 실행되도록 수정
            task = loop.create_task(coro)
            return task
        except RuntimeError:
            # 이벤트 루프가 없는 경우 동기적으로 처리
            try:
                import asyncio

                asyncio.run(coro)
            except Exception as e:
                logger.error(f"안전한 태스크 생성 실패: {e}")
                self._create_sync_event(str(e))

    def _create_sync_event(self, content: str, event_type: str = "THINKING"):
        """동기적 이벤트 생성 (폴백용) - 개선된 버전"""
        try:
            event_dict = {
                "type": event_type,
                "content": content,
                "description": "Sync fallback event",
                "key": f"sync_fallback_{int(time.time())}",
                "id": self.chat_id,
                "created_at": kst_now.isoformat() + "Z",
            }

            # ✅ 큐에 즉시 추가 시도
            try:
                self.event_queue.put_nowait(event_dict)
                logger.debug(f"동기 이벤트 큐 추가 성공: {content[:50]}...")
            except Exception as queue_error:
                logger.error(f"동기 이벤트 큐 추가 실패: {queue_error}")

        except Exception as e:
            logger.error(f"동기 이벤트 생성 실패: {e}")

    async def start_workflow_if_needed(self, workflow_type: str, query: str):
        """워크플로우 시작 (한 번만)"""
        if not self.workflow_started:
            await self.sequential_callback.start_workflow(workflow_type, query)
            self.workflow_started = True

    def on_tool_routing(self, analysis, selected_tools: List, reason: str):
        """도구 라우팅 이벤트 - 디버깅 정보 추가"""
        try:

            async def handle_routing():
                await self.start_workflow_if_needed(
                    "Enhanced MCP Agent", "사용자 요청 처리"
                )

                if self.current_phase != WorkflowPhase.ANALYSIS:
                    await self.sequential_callback.set_analysis_phase()
                    self.current_phase = WorkflowPhase.ANALYSIS

                await self.sequential_callback.set_routing_phase()
                self.current_phase = WorkflowPhase.ROUTING

                # 🔥 도구 매칭 디버깅 정보 추가
                tool_debug_info = []
                for tool in selected_tools:
                    tool_debug_info.append(
                        f"{tool.name} ({getattr(tool, 'description', 'No desc')[:30]}...)"
                    )

                routing_info = {
                    "decision": f"{analysis.query_type} ({analysis.complexity}) 패턴으로 결정",
                    "description": f"예상 단계: {analysis.estimated_steps}단계, 선택된 도구: {len(selected_tools)}개",
                    "complexity": analysis.complexity,
                    "estimated_steps": analysis.estimated_steps,
                    "selected_tools_count": len(selected_tools),
                    "reason": reason,
                    "tool_details": tool_debug_info[:5],  # 처음 5개만
                }

                await self.sequential_callback.add_routing_decision(routing_info)

            self._safe_create_task(handle_routing())

            # 🔥 상세 로깅
            logger.info(
                f"[ROUTING] 라우팅 이벤트 전송 완료: {analysis.query_type}, {len(selected_tools)}개 도구"
            )
            for i, tool in enumerate(selected_tools[:3]):
                logger.info(f"   {i+1}. {tool.name}")

        except Exception as e:
            logger.error(f"라우팅 이벤트 전송 오류: {e}")
            self._create_sync_event(
                f"라우팅 완료: {len(selected_tools)}개 도구 선택", "ROUTING"
            )

    def on_mcp_recommendation(self, recommendation_result):
        """MCP 추천 결과 이벤트 - 수정된 버전"""
        try:

            async def handle_recommendation():
                await self.sequential_callback.add_thinking(
                    "MCP 도구 추천 시스템 결과를 분석하고 있습니다..."
                )

                server_info = []
                for server in recommendation_result.recommended_servers[:3]:
                    server_info.append(
                        f"{server['server_name']} ({server['score']:.2f})"
                    )

                tool_info = []
                for tool in recommendation_result.recommended_tools[:5]:
                    tool_info.append(
                        f"{tool.server_name}.{tool.tool_name} ({tool.score:.2f})"
                    )

                recommendation_details = {
                    "confidence": recommendation_result.confidence_score,
                    "recommended_servers": server_info,
                    "recommended_tools": tool_info,
                    "explanation": recommendation_result.explanation,
                }

                await self.sequential_callback.add_routing_decision(
                    {
                        "decision": f"MCP 추천 완료 (신뢰도: {recommendation_result.confidence_score:.2f})",
                        "description": f"추천 서버: {', '.join(server_info)} | 추천 도구: {len(recommendation_result.recommended_tools)}개",
                        "recommendation_data": recommendation_details,
                    }
                )

            self._safe_create_task(handle_recommendation())

        except Exception as e:
            logger.error(f"MCP 추천 이벤트 전송 오류: {e}")
            self._create_sync_event("MCP 추천 완료", "MCP_RECOMMENDATION")

    def on_workflow_start(
        self, workflow_type: str, estimated_steps: int, query_type: str
    ):
        """워크플로우 시작 이벤트 - 수정된 버전"""
        try:

            async def handle_workflow_start():
                await self.start_workflow_if_needed(workflow_type, f"{query_type} 작업")
                await self.sequential_callback.add_thinking(
                    f"{workflow_type} 워크플로우로 {estimated_steps}단계 처리 예정"
                )

            self._safe_create_task(handle_workflow_start())
            logger.info(f"[WORKFLOW] 워크플로우 시작 이벤트 전송: {workflow_type}")

        except Exception as e:
            logger.error(f"워크플로우 이벤트 전송 오류: {e}")
            self._create_sync_event(
                f"워크플로우 시작: {workflow_type}", "WORKFLOW_START"
            )

    def on_llm_start(self, serialized, prompts, **kwargs):
        """LLM 시작 - 수정된 버전"""
        try:

            async def handle_llm_start():
                await self.start_workflow_if_needed("LLM Processing", "LLM 처리")

                if self._is_planning_phase(prompts):
                    if self.current_phase != WorkflowPhase.PLANNING:
                        await self.sequential_callback.set_planning_phase()
                        self.current_phase = WorkflowPhase.PLANNING

                    self.plan_counter += 1
                    plan_description = (
                        "사용자 요청을 분석하여 필요한 도구와 실행 순서를 계획합니다"
                    )
                    if self.plan_counter > 1:
                        plan_description = f"이전 단계 결과를 바탕으로 다음 실행 계획을 수립합니다 (계획 {self.plan_counter})"

                    await self.sequential_callback.start_planning(plan_description)
                else:
                    await self.sequential_callback.add_thinking(
                        "응답을 생성하고 있습니다..."
                    )

            self._safe_create_task(handle_llm_start())

        except Exception as e:
            logger.error(f"LLM 시작 핸들링 오류: {e}")
            self._create_sync_event("LLM 처리 시작", "THINKING")

    def on_llm_end(self, response, **kwargs):
        """LLM 완료 - 수정된 버전"""
        try:

            async def handle_llm_end():
                if hasattr(response, "generations") and response.generations:
                    content = (
                        str(response.generations[0][0].text)
                        if response.generations[0]
                        else ""
                    )

                    if self._contains_tool_calls(content):
                        tools_mentioned = self._extract_tools_from_content(content)
                        plan_details = self._extract_plan_details(content)

                        if not plan_details:
                            if tools_mentioned:
                                plan_details = f"선택된 도구: {', '.join(tools_mentioned)} | 순차적 실행 계획 수립"
                            else:
                                plan_details = "도구 기반 실행 계획 수립 완료"

                        await self.sequential_callback.complete_planning(plan_details)
                    elif self.plan_counter > 0:
                        await self.sequential_callback.complete_planning(
                            "수집된 정보를 바탕으로 최종 응답을 준비합니다"
                        )

            self._safe_create_task(handle_llm_end())

        except Exception as e:
            logger.error(f"LLM 완료 핸들링 오류: {e}")
            self._create_sync_event("LLM 처리 완료", "PLAN_COMPLETE")

    def on_tool_start(self, serialized, input_str, **kwargs):
        """도구 시작 - 수정된 버전"""
        try:

            async def handle_tool_start():
                tool_name = serialized.get("name", "unknown_tool")
                self.current_tool_name = tool_name

                await self.start_workflow_if_needed("Tool Execution", "도구 실행 작업")

                if self.current_phase != WorkflowPhase.EXECUTION:
                    await self.sequential_callback.set_execution_phase()
                    self.current_phase = WorkflowPhase.EXECUTION

                if self.current_step_active:
                    await self.sequential_callback.complete_step(True, "이전 단계 완료")

                self.step_counter += 1
                step_name = f"{self._get_step_description(tool_name)}"
                step_description = f"{tool_name} 도구를 사용하여 작업을 수행합니다"

                await self.sequential_callback.start_step(step_name, step_description)
                self.current_step_active = True

                input_preview = (
                    str(input_str)[:100] + "..."
                    if len(str(input_str)) > 100
                    else str(input_str)
                )
                await self.sequential_callback.start_action(
                    self._get_tool_display_name(tool_name), f"입력: {input_preview}"
                )

                self._update_tool_stats_start(tool_name)

            self._safe_create_task(handle_tool_start())
            logger.info(f"도구 시작: {serialized.get('name', 'unknown')}")

        except Exception as e:
            logger.error(f"도구 시작 핸들링 오류: {e}")
            tool_name = serialized.get("name", "unknown_tool")
            self._create_sync_event(f"도구 실행 시작: {tool_name}", "STEP_START")

    def on_tool_end(self, output, **kwargs):
        """도구 완료 - 수정된 버전"""
        try:

            async def handle_tool_end():
                tool_name = self.current_tool_name or "unknown_tool"
                output_preview = (
                    str(output)[:150] + "..." if len(str(output)) > 150 else str(output)
                )

                await self.sequential_callback.complete_action(
                    self._get_tool_display_name(tool_name),
                    True,
                    f"결과: {output_preview}",
                )

                await self.sequential_callback.complete_step(
                    True, f"{self._get_tool_display_name(tool_name)} 실행 성공"
                )
                self.current_step_active = False

                self._update_tool_stats_success(tool_name)

            self._safe_create_task(handle_tool_end())
            logger.info(f"도구 완료: {self.current_tool_name or 'unknown'}")

        except Exception as e:
            logger.error(f"도구 완료 핸들링 오류: {e}")
            tool_name = self.current_tool_name or "unknown_tool"
            self._create_sync_event(f"도구 실행 완료: {tool_name}", "STEP_COMPLETE")

    def on_tool_error(self, error, **kwargs):
        """도구 오류 - 수정된 버전"""
        try:

            async def handle_tool_error():
                tool_name = self.current_tool_name or "unknown_tool"
                error_msg = (
                    str(error)[:100] + "..." if len(str(error)) > 100 else str(error)
                )

                self.failed_tools.append(tool_name)

                await self.sequential_callback.complete_action(
                    self._get_tool_display_name(tool_name),
                    False,
                    "",
                    f"오류: {error_msg}",
                )

                await self.sequential_callback.complete_step(
                    False,
                    "",
                    f"{self._get_tool_display_name(tool_name)} 실행 실패: {error_msg}",
                )
                self.current_step_active = False

                self._update_tool_stats_failure(tool_name)

                await self.sequential_callback.add_thinking(
                    f"{tool_name} 실패로 인한 전략 재평가 중..."
                )

            self._safe_create_task(handle_tool_error())
            logger.warning(
                f"도구 오류: {self.current_tool_name or 'unknown'} - {str(error)}"
            )

        except Exception as e:
            logger.error(f"도구 오류 핸들링 오류: {e}")
            tool_name = self.current_tool_name or "unknown_tool"
            self._create_sync_event(f"도구 실행 오류: {tool_name}", "ERROR")

    async def complete_workflow(self, success: bool = True, summary: str = ""):
        """워크플로우 완료"""
        try:
            if self.current_step_active:
                await self.sequential_callback.complete_step(success, "최종 단계 완료")
                self.current_step_active = False

            if self.current_phase != WorkflowPhase.SYNTHESIS:
                await self.sequential_callback.set_synthesis_phase()
                await self.sequential_callback.add_thinking(
                    "모든 단계 결과를 종합하여 최종 응답을 생성합니다..."
                )

            final_summary = summary or f"총 {self.step_counter}단계 처리 완료"
            if self.failed_tools:
                final_summary += f" (실패: {len(self.failed_tools)}개 도구)"

            await self.sequential_callback.end_workflow(success, final_summary)

        except Exception as e:
            logger.error(f"워크플로우 완료 처리 오류: {e}")

    # =================================
    # 유틸리티 메서드들 (기존과 동일)
    # =================================

    def _update_tool_stats_start(self, tool_name: str):
        """도구 시작 통계 업데이트"""
        if tool_name not in self.tool_usage_stats:
            self.tool_usage_stats[tool_name] = {
                "attempts": 0,
                "successes": 0,
                "failures": 0,
                "last_used": kst_now.isoformat(),
            }

        self.tool_usage_stats[tool_name]["attempts"] += 1
        self.tool_usage_stats[tool_name]["last_used"] = kst_now.isoformat()
        self.active_tools.add(tool_name)

    def _update_tool_stats_success(self, tool_name: str):
        """도구 성공 통계 업데이트"""
        if tool_name in self.tool_usage_stats:
            self.tool_usage_stats[tool_name]["successes"] += 1
        self.active_tools.discard(tool_name)

    def _update_tool_stats_failure(self, tool_name: str):
        """도구 실패 통계 업데이트"""
        if tool_name in self.tool_usage_stats:
            self.tool_usage_stats[tool_name]["failures"] += 1
        self.active_tools.discard(tool_name)

    def _is_planning_phase(self, prompts) -> bool:
        """계획 단계인지 확인"""
        if not prompts:
            return False
        prompt_text = str(prompts[0]).lower() if prompts else ""
        planning_keywords = ["plan", "계획", "단계", "step", "실행 계획", "작업 분해"]
        return any(keyword in prompt_text for keyword in planning_keywords)

    def _contains_tool_calls(self, content: str) -> bool:
        """도구 호출이 포함되어 있는지 확인"""
        tool_indicators = [
            "tool_calls",
            "function_call",
            "Action:",
            "```json",
            "invoke",
            "도구",
            "실행",
        ]
        return any(indicator in content.lower() for indicator in tool_indicators)

    def _extract_tools_from_content(self, content: str) -> List[str]:
        """컨텐츠에서 도구 이름 추출"""
        content_lower = content.lower()
        tools = []

        tool_mappings = {
            ("browser", "scrape", "hyperbrowser", "웹"): "브라우저",
            ("search", "perplexity", "검색"): "검색",
            ("weather", "날씨"): "날씨",
            ("desktop", "command", "명령"): "시스템",
            ("file", "파일"): "파일처리",
        }

        for keywords, tool_name in tool_mappings.items():
            if any(keyword in content_lower for keyword in keywords):
                tools.append(tool_name)

        return tools or ["범용 도구"]

    def _extract_plan_details(self, content: str) -> str:
        """LLM 응답에서 계획 상세 정보 추출"""
        try:
            content_lower = content.lower()

            if "1." in content and "2." in content:
                import re

                step_patterns = [
                    r"(\d+)\.\s*([^.]+(?:\.[^0-9][^.]*)*)",
                    r"단계\s*(\d+)[:\s]*([^단계]+)",
                    r"step\s*(\d+)[:\s]*([^step]+)",
                ]

                for pattern in step_patterns:
                    steps = re.findall(pattern, content, re.IGNORECASE)
                    if len(steps) >= 2:
                        cleaned_steps = []
                        for step_num, step_text in steps[:4]:
                            clean_step = step_text.strip()
                            clean_step = re.sub(r"\s+", " ", clean_step)[:80]
                            if clean_step and not clean_step.startswith("Navigate"):
                                cleaned_steps.append(f"{step_num}.{clean_step}")

                        if cleaned_steps:
                            return " → ".join(cleaned_steps)

            return ""

        except Exception as e:
            logger.error(f"계획 상세 정보 추출 오류: {e}")
            return ""

    def _get_step_description(self, tool_name: str) -> str:
        """도구명을 기반으로 단계 설명 생성"""
        descriptions = {
            "browser": "웹 브라우징",
            "hyperbrowser": "고급 웹 브라우징",
            "scrape": "웹 스크래핑",
            "search": "웹 검색",
            "perplexity": "지식 검색",
            "weather": "날씨 정보 조회",
            "desktop": "시스템 명령 실행",
            "command": "명령어 실행",
            "file": "파일 처리",
        }

        for key, desc in descriptions.items():
            if key in tool_name.lower():
                return desc

        return f"{tool_name} 실행"

    def _get_tool_display_name(self, tool_name: str) -> str:
        """도구 표시명 생성"""
        display_names = {
            "browser": "🌐 브라우저",
            "hyperbrowser": "🌐 하이퍼브라우저",
            "scrape": "🕷️ 웹 스크래퍼",
            "search": "🔍 검색 엔진",
            "perplexity": "🧠 지식 검색",
            "weather": "🌤️ 날씨 서비스",
            "desktop": "💻 시스템",
            "command": "⚡ 명령어",
            "file": "📁 파일처리",
        }

        for key, display in display_names.items():
            if key in tool_name.lower():
                return display

        return f"🔧 {tool_name}"

    def get_tool_usage_stats(self) -> Dict:
        """도구 사용 통계 반환"""
        return {
            "tools": self.tool_usage_stats,
            "active_tools": list(self.active_tools),
            "total_tools_used": len(self.tool_usage_stats),
            "failed_tools": self.failed_tools,
            "step_counter": self.step_counter,
        }

    def _add_event_to_queue(
        self,
        msg_type,
        content: str,
        description: str,
        key: str = "",
        extra_data: Dict = None,
    ):
        """기존 호환성을 위한 이벤트 추가 메서드 - 추가 데이터 지원"""
        try:
            if msg_type == MessageType.THINKING:

                async def add_thinking():
                    await self.sequential_callback.add_thinking(content)

                self._safe_create_task(add_thinking())
            elif msg_type == MessageType.ROUTING:

                async def add_routing():
                    await self.sequential_callback.add_routing_decision(
                        {"decision": content, "description": description}
                    )

                self._safe_create_task(add_routing())
            else:
                try:
                    # 기타 이벤트들은 직접 큐에 추가
                    event_dict = {
                        "executor": {
                            "view_messages": [
                                {
                                    msg_type.value: {
                                        "content": content,
                                        "description": description,
                                        "key": key,
                                        "id": self.chat_id,
                                        "title": extra_data.get("title", ""),
                                    }
                                }
                            ],
                            "messages": {},
                        }
                    }

                    # # 추가 데이터 병합
                    # if extra_data:
                    #     event_dict.update(extra_data)

                    try:
                        self.event_queue.put_nowait(event_dict)
                    except Exception:
                        self._create_sync_event(content, msg_type.value)

                    if self.scenario_logger:
                        self.scenario_logger.add_event(self.chat_id, event_dict)

                except Exception as e:
                    logger.error(f"이벤트 큐 추가 실패: {e}")
                    self._create_sync_event(content, "ERROR")

        except Exception as e:
            logger.error(f"이벤트 큐 추가 실패: {e}")
            self._create_sync_event(content, "ERROR")


def create_fallback_mcp_retriever():
    """폴백 MCP retriever 생성"""
    try:
        from langchain_core.vectorstores import InMemoryVectorStore

        # Azure OpenAI embeddings 사용 (기존 설정 유지)
        embeddings = AzureOpenAIEmbeddings(
            azure_endpoint=os.getenv(
                "AZURE_OPENAI_ENDPOINT",
                "https://skcc-atl-master-openai-01.openai.azure.com/",
            ),
            api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            openai_api_type="azure",
            deployment="text-embedding-3-small",
        )

        # InMemoryVectorStore 생성
        vector_store = InMemoryVectorStore(embeddings)

        # 기본 MCP 서버 정보 추가
        default_docs = [
            "Perplexity search server for web search and information retrieval",
            "Hyperbrowser server for web browsing automation and scraping",
            "Desktop commander server for system command execution",
            "Weather MCP server for weather information and forecasts",
            "GitHub server for repository management and code operations",
            "SQLite server for database queries and operations",
            "Filesystem server for file and directory operations",
        ]

        metadatas = [
            {
                "server_name": "perplexity-search",
                "entity_type": "server_summary",
                "category": "search",
            },
            {
                "server_name": "hyperbrowser",
                "entity_type": "server_summary",
                "category": "automation",
            },
            {
                "server_name": "desktop-commander",
                "entity_type": "server_summary",
                "category": "system",
            },
            {
                "server_name": "weather-mcp-server",
                "entity_type": "server_summary",
                "category": "weather",
            },
            {
                "server_name": "github",
                "entity_type": "server_summary",
                "category": "api",
            },
            {
                "server_name": "sqlite",
                "entity_type": "server_summary",
                "category": "database",
            },
            {
                "server_name": "filesystem",
                "entity_type": "server_summary",
                "category": "file_operations",
            },
        ]

        vector_store.add_texts(default_docs, metadatas=metadatas)

        logger.info("✅ 폴백 InMemoryVectorStore retriever 생성 완료")
        return vector_store.as_retriever()

    except Exception as e:
        logger.error(f"❌ 폴백 retriever 생성 실패: {e}")
        return None


# =================================
# 메인 Enhanced MCP ReAct Agent 클래스
# =================================


class EnhancedMCPReActAgent:
    def __init__(self):
        self.model = None
        self.mcp_client = None
        self.tools = []
        self.agent = None
        if MCP_AVAILABLE:
            self.memory = MemorySaver()
        else:
            self.memory = None
        self.conversations = {}
        self._executor = ThreadPoolExecutor(max_workers=4)

        # 새로운 컴포넌트들
        self.query_analyzer = QueryAnalyzer()
        self.enhanced_query_analyzer = EnhancedQueryAnalyzer()  # 추가
        self.server_router = None
        self.session_stats = {}

        # 시나리오 로거 추가
        self.scenario_logger = ScenarioLogger()

        # MCP 메타데이터 시스템 추가
        self.mcp_config_loader = MCPConfigLoader()
        self.mcp_metadata_collector = MCPMetadataCollector()
        self.mcp_vector_store = None
        self.mcp_recommendation_system = None

        # 새로운 LLM mcp_enricher 시스템
        self.mcp_enricher = None
        self.enriched_vector_store = None
        self.enriched_recommendation_system = None
        self.enrichment_enabled = False
        self.background_enrichment_task = None

        # mcp서버 정보 생성
        self.system_info_generator = None
        # 메모리 관리
        self.memory_manager = None

        # 🔥 새로운 워크플로우 패턴 시스템 추가
        self.workflow_memory_manager = None
        self.workflow_pattern_analyzer = None

    async def _handle_simple_tool_usage(
        self, chat_id: str, query: str, routing_decision: RoutingDecision, callback
    ) -> Dict[str, Any]:
        """단순 도구 사용 처리 (기존 React 패턴)"""
        try:
            # callback이 None이 아닌 경우에만 이벤트 전송
            if callback:
                callback._add_event_to_queue(
                    MessageType.WORKFLOW_START,
                    "🔧 단순 도구 사용으로 분석되어 React 패턴으로 처리합니다",
                    f"예상 단계: {getattr(routing_decision, 'estimated_steps', 1)}단계",
                    "simple_tool_workflow",
                )

            # 기존 React 패턴 처리 로직 사용
            analysis = self.query_analyzer.analyze_query(query)

            if self.server_router and self.tools:
                selected_tools, reason = await self.server_router.route_query(
                    analysis, self.tools
                )
                # callback 안전 검사 추가
                if callback:
                    callback.on_tool_routing(analysis, selected_tools, reason)
            else:
                selected_tools = self.tools
                reason = "모든 도구 사용"

            # 표준 워크플로우로 실행
            return await self._execute_standard_workflow_with_memory(
                chat_id, query, analysis, selected_tools, callback, []
            )

        except Exception as e:
            logger.error(f"단순 도구 사용 처리 오류: {e}")
            return await self._execute_fallback(query, callback)

    def get_hierarchical_planner_status(self) -> Dict[str, Any]:
        """계층적 플래너 상태 조회"""
        if not hasattr(self, "hierarchical_planner") or not self.hierarchical_planner:
            return {
                "planner_initialized": False,
                "metadata_connected": False,
                "error": "Hierarchical planner not initialized",
            }

        status = {
            "planner_initialized": True,
            "planner_type": type(self.hierarchical_planner).__name__,
            "metadata_enhanced": getattr(
                self.hierarchical_planner, "metadata_enhanced", False
            ),
            "connections": {},
        }

        # 연결된 메타데이터 시스템 확인
        if hasattr(self.hierarchical_planner, "mcp_recommendation_system"):
            status["connections"]["recommendation_system"] = {
                "connected": self.hierarchical_planner.mcp_recommendation_system
                is not None,
                "type": (
                    type(self.hierarchical_planner.mcp_recommendation_system).__name__
                    if self.hierarchical_planner.mcp_recommendation_system
                    else None
                ),
            }

        if hasattr(self.hierarchical_planner, "mcp_vector_store"):
            status["connections"]["vector_store"] = {
                "connected": self.hierarchical_planner.mcp_vector_store is not None,
                "type": (
                    type(self.hierarchical_planner.mcp_vector_store).__name__
                    if self.hierarchical_planner.mcp_vector_store
                    else None
                ),
            }

        if hasattr(self.hierarchical_planner, "enriched_mode"):
            status["enriched_mode"] = self.hierarchical_planner.enriched_mode

        return status

    async def force_enable_semantic_routing_v2(self):
        """Semantic 라우팅 강제 활성화 - 클래스 메서드 버전"""
        try:
            logger.info("🔧 Semantic 라우팅 v2 활성화 시작...")

            # 1. Semantic analyzer 초기화 확인/생성
            if not hasattr(self, "semantic_analyzer") or not self.semantic_analyzer:
                try:
                    from langchain_openai import AzureOpenAIEmbeddings

                    embedding_model = AzureOpenAIEmbeddings(
                        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                        api_version=os.getenv(
                            "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"
                        ),
                        deployment="text-embedding-3-small",
                    )

                    self.semantic_analyzer = EnhancedSemanticQueryAnalyzer(
                        embedding_model=embedding_model, llm_model=self.model
                    )

                    logger.info("✅ Semantic analyzer 생성 완료")

                except Exception as e:
                    logger.warning(f"❌ Semantic analyzer 생성 실패: {e}")
                    return False

            # 2. enhanced_query_analyzer의 메서드 교체
            if hasattr(self, "enhanced_query_analyzer"):
                # 원본 메서드 백업
                if not hasattr(
                    self.enhanced_query_analyzer, "_original_analyze_query_complexity"
                ):
                    self.enhanced_query_analyzer._original_analyze_query_complexity = (
                        self.enhanced_query_analyzer.analyze_query_complexity
                    )

                # 새 메서드로 교체
                self.enhanced_query_analyzer.analyze_query_complexity = (
                    self.semantic_analyzer.analyze_query_semantic
                )

                logger.info("✅ Enhanced query analyzer 메서드 교체 완료")
            else:
                logger.warning("❌ Enhanced query analyzer를 찾을 수 없습니다")
                return False

            # 3. 테스트
            test_query = "naver.com에서 usb-c 타입 케이블을 검색해서, url과 함께 3개 추천해주고, wiki에서 유박비료에 찾아 내용을 보여주고, 이 모든 내용을 /content/test.md 파일로 마크다운 형식으로 저장해줘."

            try:
                result = await self.semantic_analyzer.analyze_query_semantic(test_query)
                logger.info(
                    f"🧪 테스트 성공: {result.complexity.value} (신뢰도: {result.confidence:.3f})"
                )
                logger.info(f"   추론: {result.reasoning}")

                self._semantic_routing_v2_enabled = True
                return True

            except Exception as test_error:
                logger.warning(f"❌ 테스트 실패: {test_error}")
                return False

        except Exception as e:
            logger.error(f"❌ Semantic 라우팅 v2 활성화 실패: {e}")
            return False

    async def initialize(self):
        """에이전트 초기화 - 메타데이터 우선 설정 후 계층적 플래너 연결"""
        logger.info(
            "Enhanced MCP ReAct Agent with LLM Enrichment System 초기화 시작..."
        )

        try:
            # 1-5단계: 기존과 동일 (모델, MCP, 쿼리 분석기, 라우터, ReAct Agent)
            logger.info("1단계: 모델 설정 중...")
            self.setup_model()

            logger.info("2단계: MCP 클라이언트 설정 및 도구 로드 중...")
            await self.setup_mcp_client()

            logger.info("3단계: Enhanced Query Analyzer 초기화 중...")
            if (
                not hasattr(self, "enhanced_query_analyzer")
                or self.enhanced_query_analyzer is None
            ):
                self.enhanced_query_analyzer = EnhancedQueryAnalyzer()
                logger.info("✅ Enhanced Query Analyzer 초기화 완료")

            logger.info("4단계: 서버 라우터 초기화 중...")
            self.setup_server_router()

            logger.info("5단계: ReAct Agent 생성 중...")
            self.create_react_agent()

            # 6단계: 메타데이터 시스템 초기화 (계층적 플래너보다 먼저!)
            if self.tools and len(self.tools) > 0:
                logger.info("6단계: 메타데이터 시스템 초기화 중...")
                # 🔥 강제로 LLM 보강 시스템 활성화
                try:
                    logger.info("🔧 LLM 보강 시스템 강제 활성화 시도...")
                    await self.setup_llm_enrichment_system()

                    if self.enrichment_enabled:
                        logger.info("✅ LLM 보강 시스템 활성화 성공!")
                    else:
                        logger.warning(
                            "⚠️ LLM 보강 시스템 활성화 실패, 기존 시스템 사용"
                        )
                        await self.setup_mcp_metadata_system()

                except Exception as e:
                    logger.error(f"❌ LLM 보강 시스템 초기화 실패: {e}")
                    logger.info("🔄 기존 MCP 메타데이터 시스템으로 폴백")
                    await self.setup_mcp_metadata_system()

                # 🔥 메타데이터 초기화 완료 확인
                await asyncio.sleep(2)

                # 🔥 추가: 메타데이터 시스템 상태 확인 로그
                logger.info("🔍 메타데이터 시스템 초기화 상태 확인:")
                logger.info(
                    f"   - 기본 추천 시스템: {'✅' if hasattr(self, 'mcp_recommendation_system') and self.mcp_recommendation_system else '❌'}"
                )
                logger.info(
                    f"   - 기본 벡터 스토어: {'✅' if hasattr(self, 'mcp_vector_store') and self.mcp_vector_store else '❌'}"
                )
                logger.info(
                    f"   - 보강된 추천 시스템: {'✅' if hasattr(self, 'enriched_recommendation_system') and self.enriched_recommendation_system else '❌'}"
                )
                logger.info(
                    f"   - 보강된 벡터 스토어: {'✅' if hasattr(self, 'enriched_vector_store') and self.enriched_vector_store else '❌'}"
                )
            else:
                logger.warning("도구가 로드되지 않아 메타데이터 시스템을 건너뜁니다.")

            # 7-8단계: 시스템 정보 생성기 및 메모리 관리자
            logger.info("7단계: 시스템 정보 생성기 초기화 중...")
            self.system_info_generator = SystemInfoGenerator(self)

            logger.info("8단계: Mem0 메모리 관리자 초기화 중...")
            try:
                self.memory_manager = EnhancedMemoryManager()
                if self.memory_manager.enabled:
                    logger.info("✅ Mem0 메모리 시스템 활성화됨")
                else:
                    logger.warning("⚠️ 메모리 시스템 비활성화됨")
            except Exception as e:
                logger.error(f"❌ 메모리 관리자 초기화 실패: {e}")
                self.memory_manager = None

            # 🔥 9단계: 계층적 플래너 초기화 (메타데이터 시스템 준비 후!)
            logger.info(
                "9단계: Hierarchical Planning 시스템 초기화 (메타데이터 연결) 중..."
            )
            await self._initialize_hierarchical_planning_with_metadata()

            # 10-13단계: 나머지 시스템들
            logger.info("10단계: 서버 라우터 메타데이터 연결 중...")
            await self._enhance_server_router_with_metadata()

            logger.info("11단계: Semantic Tool Matcher 초기화 중...")
            await self._initialize_semantic_tool_matcher()

            logger.info("12단계: 메타데이터 기반 라우팅 통계 초기화 중...")
            self._initialize_metadata_routing_stats()

            # 워크플로우 패턴 메모리 시스템 초기화
            logger.info("13단계: 워크플로우 패턴 메모리 시스템 초기화 중...")
            try:
                self.workflow_memory_manager = WorkflowPatternMemoryManager()
                if self.workflow_memory_manager.enabled:
                    self.workflow_pattern_analyzer = WorkflowPatternAnalyzer(
                        self.workflow_memory_manager
                    )
                    logger.info("✅ 워크플로우 패턴 학습 시스템 활성화됨")
                else:
                    logger.warning("⚠️ 워크플로우 패턴 시스템 비활성화됨")
            except Exception as e:
                logger.error(f"❌ 워크플로우 패턴 시스템 초기화 실패: {e}")

            logger.info("✅ Enhanced MCP ReAct Agent 초기화 완료!")
            logger.info(f"사용 가능한 도구 수: {len(self.tools) if self.tools else 0}")

            if self.enrichment_enabled:
                logger.info("✅ LLM 보강 시스템 활성화됨")
            elif self.mcp_recommendation_system:
                logger.info("✅ 기존 MCP 추천 시스템 활성화됨")

            # 🔥 메타데이터 연결 상태 최종 확인
            self._log_metadata_connection_status()

            # 🔥 계층적 플래너 연결 상태 로깅
            self._log_hierarchical_planner_status()

            if (
                hasattr(enhanced_mcp_agent, "hierarchical_planner")
                and enhanced_mcp_agent.hierarchical_planner
            ):
                enhanced_mcp_agent.hierarchical_planner.metadata_enhanced = True
                enhanced_mcp_agent.hierarchical_planner.enriched_mode = True
                logger.info("🔧 계층적 플래너 메타데이터 플래그 강제 설정 완료")

        except Exception as e:
            logger.error(f"❌ 에이전트 초기화 중 오류: {e}")
            self.setup_fallback_tools()
            self.create_react_agent()
            logger.info("✅ 기본 도구로 에이전트 초기화 완료")

    # 3. 계층적 플래너 상태 로깅 메서드 추가

    def _log_hierarchical_planner_status(self):
        """계층적 플래너 연결 상태 로깅 - 디버깅 강화"""
        try:
            logger.info("\n🔍 상세 디버깅 정보:")

            # 1. 플래너 존재 여부
            planner_exists = (
                hasattr(self, "hierarchical_planner")
                and self.hierarchical_planner is not None
            )
            logger.info(f"   플래너 존재: {planner_exists}")

            if planner_exists:
                # 2. 플래너 타입 확인
                planner_type = type(self.hierarchical_planner).__name__
                logger.info(f"   플래너 타입: {planner_type}")

                # 3. 메타데이터 시스템 연결 상태
                has_rec_sys = hasattr(
                    self.hierarchical_planner, "mcp_recommendation_system"
                )
                has_vector = hasattr(self.hierarchical_planner, "mcp_vector_store")
                logger.info(f"   추천시스템 속성 존재: {has_rec_sys}")
                logger.info(f"   벡터스토어 속성 존재: {has_vector}")

                if has_rec_sys:
                    rec_connected = (
                        self.hierarchical_planner.mcp_recommendation_system is not None
                    )
                    logger.info(f"   추천시스템 연결됨: {rec_connected}")
                    if rec_connected:
                        rec_type = type(
                            self.hierarchical_planner.mcp_recommendation_system
                        ).__name__
                        logger.info(f"   추천시스템 타입: {rec_type}")

                if has_vector:
                    vec_connected = (
                        self.hierarchical_planner.mcp_vector_store is not None
                    )
                    logger.info(f"   벡터스토어 연결됨: {vec_connected}")
                    if vec_connected:
                        vec_type = type(
                            self.hierarchical_planner.mcp_vector_store
                        ).__name__
                        logger.info(f"   벡터스토어 타입: {vec_type}")

                # 4. 플래그 상태 확인
                metadata_enhanced = getattr(
                    self.hierarchical_planner, "metadata_enhanced", "MISSING"
                )
                enriched_mode = getattr(
                    self.hierarchical_planner, "enriched_mode", "MISSING"
                )
                logger.info(f"   metadata_enhanced: {metadata_enhanced}")
                logger.info(f"   enriched_mode: {enriched_mode}")

                # 5. connect_metadata_systems 메서드 존재 확인
                has_connect_method = hasattr(
                    self.hierarchical_planner, "connect_metadata_systems"
                )
                logger.info(
                    f"   connect_metadata_systems 메서드 존재: {has_connect_method}"
                )

        except Exception as e:
            logger.error(f"❌ 디버깅 정보 수집 실패: {e}")

    # =================================
    # 워크플로우 패턴 저장 보조 메서드들
    # =================================

    async def _store_successful_workflow_pattern(
        self, chat_id: str, workflow_tracker: Dict, result: Dict
    ):
        """성공한 워크플로우 패턴을 학습 시스템에 저장"""
        try:
            if (
                not hasattr(self, "workflow_memory_manager")
                or not self.workflow_memory_manager
            ):
                logger.debug("워크플로우 메모리 관리자가 없어 패턴 저장을 건너뜁니다")
                return

            if not self.workflow_memory_manager.enabled:
                logger.debug("워크플로우 메모리 시스템이 비활성화되어 있습니다")
                return

            # 워크플로우 패턴 분석
            pattern_analysis = self._analyze_workflow_pattern(workflow_tracker, result)

            # 성공 메트릭 계산
            success_metrics = self._calculate_success_metrics(workflow_tracker, result)

            # 도구 사용 패턴 추출
            tool_usage_pattern = self._extract_tool_usage_pattern(workflow_tracker)

            # 실행 시간 분석
            timing_analysis = self._analyze_execution_timing(workflow_tracker)

            # 품질 지표 계산
            quality_indicators = self._calculate_quality_indicators(
                workflow_tracker, result
            )

            # 워크플로우 패턴 데이터 구성
            workflow_pattern_data = {
                "workflow_pattern": {
                    "pattern_id": f"pattern_{hash(workflow_tracker['query']) % 100000}_{int(workflow_tracker['start_time'].timestamp())}",
                    "pattern_type": pattern_analysis["pattern_type"],
                    "complexity_level": workflow_tracker.get(
                        "routing_decision", {}
                    ).get("complexity", "unknown"),
                    "execution_approach": workflow_tracker.get(
                        "execution_approach", "unknown"
                    ),
                    "query_characteristics": pattern_analysis["query_characteristics"],
                    "success": True,
                    "created_at": kst_now.isoformat(),
                },
                "execution_metrics": {
                    "total_steps": len(workflow_tracker["steps"]),
                    "successful_steps": success_metrics["successful_steps"],
                    "failed_steps": success_metrics["failed_steps"],
                    "total_duration": workflow_tracker.get("total_duration", 0),
                    "average_step_duration": timing_analysis["average_step_duration"],
                    "step_timings": timing_analysis["step_timings"],
                    "efficiency_score": success_metrics["efficiency_score"],
                },
                "tool_combinations": workflow_tracker.get("tools_used", []),
                "tool_sequence": tool_usage_pattern["execution_sequence"],
                "tool_effectiveness": tool_usage_pattern["effectiveness_scores"],
                "routing_metadata": {
                    "routing_confidence": workflow_tracker.get(
                        "routing_decision", {}
                    ).get("confidence", 0),
                    "reasoning": workflow_tracker.get("routing_decision", {}).get(
                        "reasoning", ""
                    ),
                    "estimated_vs_actual_steps": {
                        "estimated": workflow_tracker.get("routing_decision", {}).get(
                            "estimated_steps", 0
                        ),
                        "actual": len(workflow_tracker["steps"]),
                    },
                },
                "quality_metrics": {
                    "overall_score": quality_indicators["overall_score"],
                    "completeness": quality_indicators["completeness"],
                    "accuracy": quality_indicators["accuracy"],
                    "relevance": quality_indicators["relevance"],
                    "user_satisfaction_predicted": quality_indicators[
                        "predicted_satisfaction"
                    ],
                },
                "context_information": {
                    "memory_context_used": len(
                        workflow_tracker.get("memory_context", [])
                    ),
                    "memory_types": list(
                        set(
                            [
                                mem.get("memory_type", "unknown")
                                for mem in workflow_tracker.get("memory_context", [])
                            ]
                        )
                    ),
                    "time_of_day": workflow_tracker["start_time"].hour,
                    "day_of_week": workflow_tracker["start_time"].weekday(),
                    "session_context": {
                        "chat_id": chat_id,
                        "is_repeat_user": await self._is_repeat_user(chat_id),
                        "recent_interaction_count": await self._get_recent_interaction_count(
                            chat_id
                        ),
                    },
                },
                "optimization_insights": {
                    "bottleneck_steps": timing_analysis["bottleneck_steps"],
                    "optimization_opportunities": pattern_analysis[
                        "optimization_opportunities"
                    ],
                    "alternative_approaches": pattern_analysis[
                        "alternative_approaches"
                    ],
                    "resource_usage": self._analyze_resource_usage(workflow_tracker),
                },
            }

            # Mem0에 워크플로우 패턴 저장
            memory_id = await self.workflow_memory_manager.add_workflow_pattern_memory(
                user_id="SYSTEM_PATTERNS",  # 시스템 레벨 패턴으로 저장
                workflow_data=workflow_pattern_data,
                metadata={
                    "type": "workflow_pattern",
                    "pattern_type": pattern_analysis["pattern_type"],
                    "success": True,
                    "complexity": workflow_tracker.get("routing_decision", {}).get(
                        "complexity", "unknown"
                    ),
                    "tools_count": len(workflow_tracker.get("tools_used", [])),
                    "duration": workflow_tracker.get("total_duration", 0),
                    "efficiency_score": success_metrics["efficiency_score"],
                    "timestamp": kst_now.isoformat(),
                },
            )

            if memory_id:
                logger.info(
                    f"✅ 성공한 워크플로우 패턴 저장: {memory_id} (타입: {pattern_analysis['pattern_type']})"
                )

                # 사용자별 개인화 패턴도 저장
                if chat_id != "SYSTEM_PATTERNS":
                    await self._store_user_specific_pattern(
                        chat_id, workflow_pattern_data
                    )

            else:
                logger.warning("❌ 워크플로우 패턴 저장 실패")

        except Exception as e:
            logger.error(f"성공한 워크플로우 패턴 저장 중 오류: {e}")

    async def _store_failed_workflow_pattern(
        self, chat_id: str, workflow_tracker: Dict, error_message: str
    ):
        """실패한 워크플로우 패턴을 학습을 위해 저장"""
        try:
            if (
                not hasattr(self, "workflow_memory_manager")
                or not self.workflow_memory_manager
            ):
                return

            if not self.workflow_memory_manager.enabled:
                return

            # 실패 패턴 분석
            failure_analysis = self._analyze_failure_pattern(
                workflow_tracker, error_message
            )

            # 실패한 단계들 분석
            failed_steps = [
                step
                for step in workflow_tracker["steps"]
                if step.get("status") == "failed"
            ]
            successful_steps = [
                step
                for step in workflow_tracker["steps"]
                if step.get("status") == "completed"
            ]

            # 실패 워크플로우 데이터 구성
            failed_workflow_data = {
                "workflow_pattern": {
                    "pattern_id": f"failed_pattern_{hash(workflow_tracker['query']) % 100000}_{int(workflow_tracker['start_time'].timestamp())}",
                    "pattern_type": failure_analysis["pattern_type"],
                    "complexity_level": workflow_tracker.get(
                        "routing_decision", {}
                    ).get("complexity", "unknown"),
                    "execution_approach": workflow_tracker.get(
                        "execution_approach", "unknown"
                    ),
                    "success": False,
                    "failure_reason": error_message,
                    "created_at": kst_now.isoformat(),
                },
                "failure_analysis": {
                    "error_type": failure_analysis["error_type"],
                    "error_stage": failure_analysis["error_stage"],
                    "failed_steps": [step["step_name"] for step in failed_steps],
                    "successful_steps_before_failure": [
                        step["step_name"] for step in successful_steps
                    ],
                    "potential_causes": failure_analysis["potential_causes"],
                    "recovery_suggestions": failure_analysis["recovery_suggestions"],
                },
                "execution_metrics": {
                    "total_steps_attempted": len(workflow_tracker["steps"]),
                    "successful_steps": len(successful_steps),
                    "failed_steps": len(failed_steps),
                    "duration_until_failure": workflow_tracker.get("total_duration", 0),
                    "failure_point": failure_analysis["failure_point"],
                },
                "tool_combinations": workflow_tracker.get("tools_used", []),
                "context_at_failure": {
                    "routing_decision": workflow_tracker.get("routing_decision", {}),
                    "memory_context_count": len(
                        workflow_tracker.get("memory_context", [])
                    ),
                    "error_details": workflow_tracker.get("error_details", {}),
                },
                "learning_insights": {
                    "avoid_patterns": failure_analysis["patterns_to_avoid"],
                    "alternative_approaches": failure_analysis[
                        "alternative_approaches"
                    ],
                    "prevention_strategies": failure_analysis["prevention_strategies"],
                },
            }

            # 실패 패턴을 별도 카테고리로 저장
            memory_id = await self.workflow_memory_manager.add_workflow_pattern_memory(
                user_id="SYSTEM_FAILURES",  # 실패 패턴 전용 ID
                workflow_data=failed_workflow_data,
                metadata={
                    "type": "failure_pattern",
                    "pattern_type": failure_analysis["pattern_type"],
                    "success": False,
                    "error_type": failure_analysis["error_type"],
                    "complexity": workflow_tracker.get("routing_decision", {}).get(
                        "complexity", "unknown"
                    ),
                    "timestamp": kst_now.isoformat(),
                },
            )

            if memory_id:
                logger.info(f"📚 실패 워크플로우 패턴 저장 (학습용): {memory_id}")
            else:
                logger.warning("❌ 실패 패턴 저장 실패")

        except Exception as e:
            logger.error(f"실패한 워크플로우 패턴 저장 중 오류: {e}")

    async def _store_user_specific_pattern(
        self, chat_id: str, workflow_pattern_data: Dict
    ):
        """사용자별 개인화 패턴 저장"""
        try:
            # 사용자 개인화 정보 추가
            user_pattern_data = workflow_pattern_data.copy()
            user_pattern_data["user_context"] = {
                "user_id": chat_id,
                "pattern_frequency": await self._get_user_pattern_frequency(
                    chat_id, workflow_pattern_data["workflow_pattern"]["pattern_type"]
                ),
                "user_preferences": await self._extract_user_preferences(chat_id),
                "success_history": await self._get_user_success_history(chat_id),
            }

            # 사용자별 패턴으로 저장
            user_memory_id = (
                await self.workflow_memory_manager.add_workflow_pattern_memory(
                    user_id=chat_id,
                    workflow_data=user_pattern_data,
                    metadata={
                        "type": "user_workflow_pattern",
                        "pattern_type": workflow_pattern_data["workflow_pattern"][
                            "pattern_type"
                        ],
                        "success": True,
                        "user_specific": True,
                        "timestamp": kst_now.isoformat(),
                    },
                )
            )

            if user_memory_id:
                logger.info(
                    f"👤 사용자별 워크플로우 패턴 저장: {chat_id} -> {user_memory_id}"
                )

        except Exception as e:
            logger.error(f"사용자별 패턴 저장 중 오류: {e}")

    def _analyze_workflow_pattern(
        self, workflow_tracker: Dict, result: Dict
    ) -> Dict[str, Any]:
        """워크플로우 패턴 분석"""
        try:
            query = workflow_tracker["query"].lower()
            tools_used = workflow_tracker.get("tools_used", [])
            execution_approach = workflow_tracker.get("execution_approach", "unknown")

            # 패턴 타입 결정
            pattern_type = "unknown"

            if "naver" in query and "usb" in query and "저장" in query:
                pattern_type = "ecommerce_search_and_save"
            elif "검색" in query and "저장" in query:
                pattern_type = "search_and_save"
            elif "wiki" in query and "찾아" in query:
                pattern_type = "wiki_information_retrieval"
            elif "분석" in query and "비교" in query:
                pattern_type = "comparative_analysis"
            elif len(tools_used) > 2:
                pattern_type = "multi_tool_workflow"
            elif execution_approach == "system_info_direct":
                pattern_type = "system_information_query"
            elif execution_approach == "simple_chat_direct":
                pattern_type = "conversational_interaction"
            elif execution_approach == "hierarchical_complex":
                pattern_type = "complex_hierarchical_task"
            else:
                pattern_type = "standard_tool_usage"

            # 쿼리 특성 분석
            query_characteristics = {
                "length": len(workflow_tracker["query"]),
                "complexity_indicators": [],
                "domain_indicators": [],
                "action_indicators": [],
            }

            # 복잡도 지시어 분석
            complexity_keywords = [
                "그리고",
                "다음에",
                "저장",
                "분석",
                "비교",
                "여러",
                "3개",
            ]
            query_characteristics["complexity_indicators"] = [
                kw for kw in complexity_keywords if kw in query
            ]

            # 도메인 지시어 분석
            domain_keywords = [
                "naver",
                "wiki",
                "웹사이트",
                "사이트",
                "검색",
                "날씨",
                "파일",
            ]
            query_characteristics["domain_indicators"] = [
                kw for kw in domain_keywords if kw in query
            ]

            # 액션 지시어 분석
            action_keywords = ["검색해", "찾아", "저장해", "추천해", "분석해", "비교해"]
            query_characteristics["action_indicators"] = [
                kw for kw in action_keywords if kw in query
            ]

            # 최적화 기회 분석
            optimization_opportunities = []

            if len(workflow_tracker["steps"]) > 5:
                optimization_opportunities.append("step_consolidation")

            if workflow_tracker.get("total_duration", 0) > 180:  # 3분 이상
                optimization_opportunities.append("performance_optimization")

            if any(
                step.get("status") == "failed" for step in workflow_tracker["steps"]
            ):
                optimization_opportunities.append("error_handling_improvement")

            # 대안 접근법 제안
            alternative_approaches = []

            if (
                pattern_type == "search_and_save"
                and "hierarchical" not in execution_approach
            ):
                alternative_approaches.append("hierarchical_planning")
            elif pattern_type == "conversational_interaction" and len(tools_used) > 0:
                alternative_approaches.append("direct_llm_response")
            elif (
                pattern_type == "complex_hierarchical_task"
                and len(workflow_tracker["steps"]) < 3
            ):
                alternative_approaches.append("simplified_react_pattern")

            return {
                "pattern_type": pattern_type,
                "query_characteristics": query_characteristics,
                "optimization_opportunities": optimization_opportunities,
                "alternative_approaches": alternative_approaches,
            }

        except Exception as e:
            logger.error(f"워크플로우 패턴 분석 오류: {e}")
            return {
                "pattern_type": "unknown",
                "query_characteristics": {},
                "optimization_opportunities": [],
                "alternative_approaches": [],
            }

    def _calculate_success_metrics(
        self, workflow_tracker: Dict, result: Dict
    ) -> Dict[str, Any]:
        """성공 메트릭 계산"""
        try:
            steps = workflow_tracker.get("steps", [])

            successful_steps = len(
                [step for step in steps if step.get("status") == "completed"]
            )
            failed_steps = len(
                [step for step in steps if step.get("status") == "failed"]
            )
            total_steps = len(steps)

            # 효율성 점수 계산 (0-1)
            efficiency_score = 0.0

            if total_steps > 0:
                success_rate = successful_steps / total_steps
                efficiency_score += success_rate * 0.4  # 성공률 40%

                # 시간 효율성 (예상 vs 실제)
                estimated_time = (
                    workflow_tracker.get("routing_decision", {}).get(
                        "estimated_steps", 1
                    )
                    * 30
                )  # 예상 30초/단계
                actual_time = workflow_tracker.get("total_duration", 0)

                if actual_time > 0 and estimated_time > 0:
                    time_efficiency = min(1.0, estimated_time / actual_time)
                    efficiency_score += time_efficiency * 0.3  # 시간 효율성 30%

                # 결과 품질
                if result and result.get("content"):
                    content_length = len(result["content"])
                    quality_score = min(1.0, content_length / 500)  # 500자 기준
                    efficiency_score += quality_score * 0.3  # 품질 30%

            return {
                "successful_steps": successful_steps,
                "failed_steps": failed_steps,
                "total_steps": total_steps,
                "success_rate": successful_steps / max(1, total_steps),
                "efficiency_score": efficiency_score,
            }

        except Exception as e:
            logger.error(f"성공 메트릭 계산 오류: {e}")
            return {
                "successful_steps": 0,
                "failed_steps": 0,
                "total_steps": 0,
                "success_rate": 0.0,
                "efficiency_score": 0.0,
            }

    def _extract_tool_usage_pattern(self, workflow_tracker: Dict) -> Dict[str, Any]:
        """도구 사용 패턴 추출"""
        try:
            tools_used = workflow_tracker.get("tools_used", [])
            steps = workflow_tracker.get("steps", [])

            # 실행 순서 추출
            execution_sequence = []
            effectiveness_scores = {}

            for step in steps:
                step_name = step.get("step_name", "unknown")
                if step_name not in execution_sequence:
                    execution_sequence.append(step_name)

                # 각 단계의 효과성 점수
                if step.get("status") == "completed":
                    duration = step.get("duration", 0)
                    # 빠르고 성공적인 단계일수록 높은 점수
                    effectiveness = 1.0 if duration == 0 else min(1.0, 30 / duration)
                    effectiveness_scores[step_name] = effectiveness
                else:
                    effectiveness_scores[step_name] = 0.0

            # 도구 조합 효과성 분석
            tool_combination_score = 0.0
            if len(tools_used) > 1:
                # 도구들이 서로 보완적인지 분석
                web_tools = [
                    t
                    for t in tools_used
                    if "browser" in t.lower() or "web" in t.lower()
                ]
                search_tools = [t for t in tools_used if "search" in t.lower()]
                file_tools = [
                    t for t in tools_used if "file" in t.lower() or "save" in t.lower()
                ]

                if web_tools and search_tools:
                    tool_combination_score += 0.3  # 웹 + 검색 조합
                if search_tools and file_tools:
                    tool_combination_score += 0.3  # 검색 + 파일 조합
                if len(set([t.split("_")[0] for t in tools_used])) == len(tools_used):
                    tool_combination_score += 0.4  # 다양한 도구 조합

            return {
                "execution_sequence": execution_sequence,
                "effectiveness_scores": effectiveness_scores,
                "tool_combination_score": tool_combination_score,
                "total_tools_used": len(tools_used),
                "unique_tool_types": len(set([t.split("_")[0] for t in tools_used])),
            }

        except Exception as e:
            logger.error(f"도구 사용 패턴 추출 오류: {e}")
            return {
                "execution_sequence": [],
                "effectiveness_scores": {},
                "tool_combination_score": 0.0,
                "total_tools_used": 0,
                "unique_tool_types": 0,
            }

    def _analyze_execution_timing(self, workflow_tracker: Dict) -> Dict[str, Any]:
        """실행 시간 분석"""
        try:
            steps = workflow_tracker.get("steps", [])
            step_timings = {}
            durations = []

            for step in steps:
                step_name = step.get("step_name", "unknown")
                duration = step.get("duration", 0)
                step_timings[step_name] = duration
                if duration > 0:
                    durations.append(duration)

            # 평균 단계 시간
            average_step_duration = sum(durations) / len(durations) if durations else 0

            # 병목 단계 식별 (평균의 2배 이상 걸린 단계)
            bottleneck_steps = []
            if average_step_duration > 0:
                threshold = average_step_duration * 2
                bottleneck_steps = [
                    step_name
                    for step_name, duration in step_timings.items()
                    if duration > threshold
                ]

            return {
                "step_timings": step_timings,
                "average_step_duration": average_step_duration,
                "bottleneck_steps": bottleneck_steps,
                "total_duration": workflow_tracker.get("total_duration", 0),
                "step_count": len(steps),
            }

        except Exception as e:
            logger.error(f"실행 시간 분석 오류: {e}")
            return {
                "step_timings": {},
                "average_step_duration": 0,
                "bottleneck_steps": [],
                "total_duration": 0,
                "step_count": 0,
            }

    def _calculate_quality_indicators(
        self, workflow_tracker: Dict, result: Dict
    ) -> Dict[str, Any]:
        """품질 지표 계산"""
        try:
            # 완성도 (요청된 작업이 얼마나 완료되었는가)
            completeness = 0.0
            if result and result.get("content"):
                content_length = len(result["content"])
                # 기본적인 완성도: 내용 길이 기반
                completeness = min(1.0, content_length / 200)  # 200자 기준

            # 정확도 (오류가 얼마나 적었는가)
            steps = workflow_tracker.get("steps", [])
            successful_steps = len([s for s in steps if s.get("status") == "completed"])
            total_steps = len(steps)
            accuracy = successful_steps / max(1, total_steps)

            # 관련성 (요청과 결과의 일치도)
            relevance = 0.0
            if result and result.get("content"):
                query_lower = workflow_tracker["query"].lower()
                result_lower = result["content"].lower()

                # 키워드 매칭 기반 관련성
                query_keywords = set(
                    [word for word in query_lower.split() if len(word) > 2]
                )
                result_keywords = set(
                    [word for word in result_lower.split() if len(word) > 2]
                )

                if query_keywords:
                    matching_keywords = query_keywords.intersection(result_keywords)
                    relevance = len(matching_keywords) / len(query_keywords)

            # 예측된 사용자 만족도
            predicted_satisfaction = (
                completeness * 0.4 + accuracy * 0.3 + relevance * 0.3
            )

            # 전체 품질 점수
            overall_score = (completeness + accuracy + relevance) / 3

            return {
                "overall_score": overall_score,
                "completeness": completeness,
                "accuracy": accuracy,
                "relevance": relevance,
                "predicted_satisfaction": predicted_satisfaction,
            }

        except Exception as e:
            logger.error(f"품질 지표 계산 오류: {e}")
            return {
                "overall_score": 0.0,
                "completeness": 0.0,
                "accuracy": 0.0,
                "relevance": 0.0,
                "predicted_satisfaction": 0.0,
            }

    def _analyze_failure_pattern(
        self, workflow_tracker: Dict, error_message: str
    ) -> Dict[str, Any]:
        """실패 패턴 분석"""
        try:
            error_lower = error_message.lower()

            # 오류 타입 분류
            error_type = "unknown"
            if "timeout" in error_lower:
                error_type = "timeout_error"
            elif "connection" in error_lower or "network" in error_lower:
                error_type = "network_error"
            elif "permission" in error_lower or "access" in error_lower:
                error_type = "permission_error"
            elif "not found" in error_lower or "404" in error_lower:
                error_type = "resource_not_found"
            elif "parsing" in error_lower or "json" in error_lower:
                error_type = "data_parsing_error"
            elif "tool" in error_lower:
                error_type = "tool_execution_error"
            else:
                error_type = "general_error"

            # 실패 단계 분석
            failed_steps = [
                step
                for step in workflow_tracker["steps"]
                if step.get("status") == "failed"
            ]

            error_stage = "unknown"
            if not failed_steps:
                error_stage = "initialization"
            elif (
                failed_steps[0]
                .get("step_name", "")
                .startswith("workflow_initialization")
            ):
                error_stage = "planning"
            elif any("execution" in step.get("step_name", "") for step in failed_steps):
                error_stage = "execution"
            else:
                error_stage = "completion"

            # 실패 지점 (실행 비율)
            total_steps = len(workflow_tracker["steps"])
            successful_steps = len(
                [s for s in workflow_tracker["steps"] if s.get("status") == "completed"]
            )
            failure_point = successful_steps / max(1, total_steps)

            # 패턴 타입
            execution_approach = workflow_tracker.get("execution_approach", "unknown")
            if execution_approach == "hierarchical_complex":
                pattern_type = "complex_hierarchical_failure"
            elif execution_approach == "standard_reactive":
                pattern_type = "standard_workflow_failure"
            else:
                pattern_type = "simple_execution_failure"

            # 잠재적 원인들
            potential_causes = []
            if error_type == "timeout_error":
                potential_causes.extend(
                    ["network_latency", "resource_overload", "infinite_loop"]
                )
            elif error_type == "tool_execution_error":
                potential_causes.extend(
                    [
                        "invalid_parameters",
                        "tool_misconfiguration",
                        "dependency_missing",
                    ]
                )
            elif error_type == "permission_error":
                potential_causes.extend(
                    ["insufficient_credentials", "api_rate_limit", "access_restriction"]
                )

            # 복구 제안
            recovery_suggestions = []
            if error_type == "timeout_error":
                recovery_suggestions.extend(
                    ["increase_timeout", "retry_with_backoff", "simplify_workflow"]
                )
            elif error_type == "tool_execution_error":
                recovery_suggestions.extend(
                    [
                        "validate_tool_parameters",
                        "use_alternative_tool",
                        "fallback_to_simple_approach",
                    ]
                )

            # 회피해야 할 패턴들
            patterns_to_avoid = []
            if failure_point > 0.8:  # 후반부 실패
                patterns_to_avoid.append("complex_final_steps")
            if len(workflow_tracker.get("tools_used", [])) > 3:
                patterns_to_avoid.append("excessive_tool_combination")

            # 대안 접근법
            alternative_approaches = []
            if execution_approach == "hierarchical_complex":
                alternative_approaches.append("simplified_react_pattern")
            elif execution_approach == "standard_reactive":
                alternative_approaches.append("direct_llm_fallback")

            # 예방 전략
            prevention_strategies = []
            if error_type == "timeout_error":
                prevention_strategies.extend(
                    ["pre_validation", "step_timeout_limits", "graceful_degradation"]
                )
            elif error_type == "tool_execution_error":
                prevention_strategies.extend(
                    [
                        "tool_health_check",
                        "parameter_validation",
                        "fallback_tool_preparation",
                    ]
                )

            return {
                "pattern_type": pattern_type,
                "error_type": error_type,
                "error_stage": error_stage,
                "failure_point": failure_point,
                "potential_causes": potential_causes,
                "recovery_suggestions": recovery_suggestions,
                "patterns_to_avoid": patterns_to_avoid,
                "alternative_approaches": alternative_approaches,
                "prevention_strategies": prevention_strategies,
            }

        except Exception as e:
            logger.error(f"실패 패턴 분석 오류: {e}")
            return {
                "pattern_type": "unknown_failure",
                "error_type": "analysis_error",
                "error_stage": "unknown",
                "failure_point": 0.0,
                "potential_causes": [],
                "recovery_suggestions": [],
                "patterns_to_avoid": [],
                "alternative_approaches": [],
                "prevention_strategies": [],
            }

    def _analyze_resource_usage(self, workflow_tracker: Dict) -> Dict[str, Any]:
        """리소스 사용량 분석"""
        try:
            steps = workflow_tracker.get("steps", [])
            tools_used = workflow_tracker.get("tools_used", [])

            # 메모리 사용량 추정
            memory_usage = {
                "context_size": len(workflow_tracker.get("memory_context", [])),
                "step_data_size": sum([len(str(step)) for step in steps]),
                "estimated_memory_mb": len(str(workflow_tracker))
                / 1024
                / 1024,  # 대략적인 추정
            }

            # 시간 리소스 사용량
            time_usage = {
                "total_duration": workflow_tracker.get("total_duration", 0),
                "average_step_time": workflow_tracker.get("total_duration", 0)
                / max(1, len(steps)),
                "longest_step": max(
                    [step.get("duration", 0) for step in steps], default=0
                ),
            }

            # 도구 리소스 사용량
            tool_usage = {
                "unique_tools": len(set(tools_used)),
                "total_tool_calls": len(tools_used),
                "tool_diversity_ratio": len(set(tools_used)) / max(1, len(tools_used)),
            }

            # API 호출 추정 (도구 사용 기반)
            api_calls = {
                "estimated_llm_calls": len(steps)
                + 2,  # 각 단계 + 초기 분석 + 최종 종합
                "estimated_tool_api_calls": len(tools_used),
                "total_estimated_calls": len(steps) + 2 + len(tools_used),
            }

            return {
                "memory_usage": memory_usage,
                "time_usage": time_usage,
                "tool_usage": tool_usage,
                "api_calls": api_calls,
                "efficiency_rating": self._calculate_efficiency_rating(
                    time_usage, tool_usage
                ),
            }

        except Exception as e:
            logger.error(f"리소스 사용량 분석 오류: {e}")
            return {
                "memory_usage": {},
                "time_usage": {},
                "tool_usage": {},
                "api_calls": {},
                "efficiency_rating": "unknown",
            }

    def _calculate_efficiency_rating(self, time_usage: Dict, tool_usage: Dict) -> str:
        """효율성 등급 계산"""
        try:
            # 시간 효율성 (짧을수록 좋음)
            avg_step_time = time_usage.get("average_step_time", 0)
            time_score = (
                1.0 if avg_step_time == 0 else min(1.0, 30 / avg_step_time)
            )  # 30초 기준

            # 도구 효율성 (적절한 도구 사용)
            diversity_ratio = tool_usage.get("tool_diversity_ratio", 0)
            tool_score = diversity_ratio  # 높은 다양성은 좋음

            # 종합 점수
            overall_score = (time_score + tool_score) / 2

            if overall_score >= 0.8:
                return "excellent"
            elif overall_score >= 0.6:
                return "good"
            elif overall_score >= 0.4:
                return "fair"
            else:
                return "poor"

        except Exception as e:
            logger.error(f"효율성 등급 계산 오류: {e}")
            return "unknown"

    async def _is_repeat_user(self, chat_id: str) -> bool:
        """반복 사용자인지 확인"""
        try:
            if not self.memory_manager or not self.memory_manager.enabled:
                return False

            # 이전 대화 기록 확인
            conversations = await self.memory_manager.get_conversation_history(
                chat_id, limit=1
            )
            return len(conversations) > 0

        except Exception as e:
            logger.error(f"반복 사용자 확인 오류: {e}")
            return False

    async def _get_recent_interaction_count(self, chat_id: str) -> int:
        """최근 상호작용 횟수 조회"""
        try:
            if not self.memory_manager or not self.memory_manager.enabled:
                return 0

            # 최근 24시간 내 대화 수 계산
            from datetime import timedelta

            recent_time = kst_now - timedelta(hours=24)

            conversations = await self.memory_manager.get_conversation_history(
                chat_id, limit=50
            )
            recent_count = 0

            for conv in conversations:
                try:
                    timestamp_str = conv.get("metadata", {}).get("timestamp", "")
                    if timestamp_str:
                        conv_time = datetime.fromisoformat(
                            timestamp_str.replace("Z", "+00:00")
                        )
                        if conv_time >= recent_time:
                            recent_count += 1
                except Exception:
                    continue

            return recent_count

        except Exception as e:
            logger.error(f"최근 상호작용 횟수 조회 오류: {e}")
            return 0

    async def _get_user_pattern_frequency(self, chat_id: str, pattern_type: str) -> int:
        """사용자의 특정 패턴 사용 빈도"""
        try:
            if (
                not self.workflow_memory_manager
                or not self.workflow_memory_manager.enabled
            ):
                return 0

            # 사용자의 워크플로우 패턴 기록 조회
            user_patterns = await self.workflow_memory_manager.get_relevant_memories(
                user_id=chat_id,
                query=f"workflow_pattern {pattern_type}",
                limit=100,
                memory_type="user_workflow_pattern",
            )

            return len([p for p in user_patterns if pattern_type in str(p)])

        except Exception as e:
            logger.error(f"사용자 패턴 빈도 조회 오류: {e}")
            return 0

    async def _extract_user_preferences(self, chat_id: str) -> Dict[str, Any]:
        """사용자 선호도 추출"""
        try:
            preferences = {
                "preferred_tools": [],
                "preferred_approaches": [],
                "response_style": "standard",
                "complexity_tolerance": "medium",
            }

            if not self.memory_manager or not self.memory_manager.enabled:
                return preferences

            # 사용자의 이전 성공적인 워크플로우들에서 선호도 추출
            successful_workflows = await self.memory_manager.get_relevant_memories(
                user_id=chat_id, query="success:true workflow", limit=20
            )

            tool_usage_count = {}
            approach_usage_count = {}

            for workflow in successful_workflows:
                try:
                    metadata = workflow.get("metadata", {})
                    tools_used = metadata.get("tools_used", [])
                    approach = metadata.get("processing_approach", "")

                    # 도구 사용 빈도
                    for tool in tools_used:
                        tool_usage_count[tool] = tool_usage_count.get(tool, 0) + 1

                    # 접근법 사용 빈도
                    if approach:
                        approach_usage_count[approach] = (
                            approach_usage_count.get(approach, 0) + 1
                        )

                except Exception:
                    continue

            # 가장 자주 사용된 도구들 (상위 3개)
            if tool_usage_count:
                sorted_tools = sorted(
                    tool_usage_count.items(), key=lambda x: x[1], reverse=True
                )
                preferences["preferred_tools"] = [
                    tool for tool, count in sorted_tools[:3]
                ]

            # 가장 자주 사용된 접근법들
            if approach_usage_count:
                sorted_approaches = sorted(
                    approach_usage_count.items(), key=lambda x: x[1], reverse=True
                )
                preferences["preferred_approaches"] = [
                    approach for approach, count in sorted_approaches[:2]
                ]

            # 복잡도 허용도 추정 (성공한 복잡한 작업이 많으면 높은 허용도)
            complex_success_count = len(
                [
                    w
                    for w in successful_workflows
                    if w.get("metadata", {}).get("routing_complexity") == "complex"
                ]
            )

            if complex_success_count >= 5:
                preferences["complexity_tolerance"] = "high"
            elif complex_success_count >= 2:
                preferences["complexity_tolerance"] = "medium"
            else:
                preferences["complexity_tolerance"] = "low"

            return preferences

        except Exception as e:
            logger.error(f"사용자 선호도 추출 오류: {e}")
            return {
                "preferred_tools": [],
                "preferred_approaches": [],
                "response_style": "standard",
                "complexity_tolerance": "medium",
            }

    async def _get_user_success_history(self, chat_id: str) -> Dict[str, Any]:
        """사용자의 성공 이력 조회"""
        try:
            if not self.memory_manager or not self.memory_manager.enabled:
                return {
                    "total_interactions": 0,
                    "successful_interactions": 0,
                    "success_rate": 0.0,
                    "recent_success_rate": 0.0,
                }

            # 전체 상호작용 조회
            all_interactions = await self.memory_manager.get_conversation_history(
                chat_id, limit=100
            )

            successful_interactions = []
            recent_interactions = []

            # 최근 7일 기준
            from datetime import timedelta

            recent_cutoff = kst_now - timedelta(days=7)

            for interaction in all_interactions:
                try:
                    metadata = interaction.get("metadata", {})
                    is_successful = metadata.get("success", True)  # 기본값 True

                    if is_successful:
                        successful_interactions.append(interaction)

                    # 최근 상호작용 확인
                    timestamp_str = metadata.get("timestamp", "")
                    if timestamp_str:
                        try:
                            interaction_time = datetime.fromisoformat(
                                timestamp_str.replace("Z", "+00:00")
                            )
                            if interaction_time >= recent_cutoff:
                                recent_interactions.append(
                                    {
                                        "interaction": interaction,
                                        "successful": is_successful,
                                    }
                                )
                        except Exception:
                            pass

                except Exception:
                    continue

            # 성공률 계산
            total_interactions = len(all_interactions)
            successful_count = len(successful_interactions)
            success_rate = successful_count / max(1, total_interactions)

            # 최근 성공률 계산
            recent_successful = len([r for r in recent_interactions if r["successful"]])
            recent_total = len(recent_interactions)
            recent_success_rate = recent_successful / max(1, recent_total)

            return {
                "total_interactions": total_interactions,
                "successful_interactions": successful_count,
                "success_rate": success_rate,
                "recent_success_rate": recent_success_rate,
                "recent_interactions_count": recent_total,
            }

        except Exception as e:
            logger.error(f"사용자 성공 이력 조회 오류: {e}")
            return {
                "total_interactions": 0,
                "successful_interactions": 0,
                "success_rate": 0.0,
                "recent_success_rate": 0.0,
            }

    def _calculate_quality_metrics(
        self, query: str, result: Dict, workflow_tracker: Dict
    ) -> Dict[str, Any]:
        """품질 메트릭 계산"""
        try:
            if not result:
                return {
                    "overall_score": 0,
                    "success": False,
                    "completeness": 0,
                    "relevance": 0,
                    "efficiency": 0,
                }

            content = result.get("content", "")

            # 완성도 (결과의 충실성)
            completeness = 0.0
            if content:
                content_length = len(content)
                # 길이 기반 완성도 (최소 100자, 최적 500자 기준)
                if content_length >= 100:
                    completeness = min(1.0, content_length / 500)
                else:
                    completeness = content_length / 100

            # 관련성 (쿼리와 결과의 일치도)
            relevance = 0.0
            if content and query:
                query_words = set(
                    [word.lower() for word in query.split() if len(word) > 2]
                )
                content_words = set(
                    [word.lower() for word in content.split() if len(word) > 2]
                )

                if query_words:
                    matching_words = query_words.intersection(content_words)
                    relevance = len(matching_words) / len(query_words)

            # 효율성 (시간 대비 결과)
            efficiency = 0.0
            total_duration = workflow_tracker.get("total_duration", 0)
            if total_duration > 0:
                # 1분 이내면 1.0, 5분이면 0.2 정도로 계산
                efficiency = min(1.0, 60 / total_duration)
            else:
                efficiency = 1.0  # 즉시 완료

            # 전체 점수
            overall_score = completeness * 0.4 + relevance * 0.3 + efficiency * 0.3

            return {
                "overall_score": overall_score,
                "success": overall_score >= 0.6,
                "completeness": completeness,
                "relevance": relevance,
                "efficiency": efficiency,
                "content_length": len(content),
                "processing_time": total_duration,
            }

        except Exception as e:
            logger.error(f"품질 메트릭 계산 오류: {e}")
            return {
                "overall_score": 0,
                "success": False,
                "completeness": 0,
                "relevance": 0,
                "efficiency": 0,
            }

    # =================================
    # 워크플로우 패턴 활용 메서드들
    # =================================

    async def _get_workflow_recommendations(
        self, query: str, user_id: str = None
    ) -> Dict[str, Any]:
        """쿼리에 대한 워크플로우 추천 조회"""
        try:
            if (
                not hasattr(self, "workflow_pattern_analyzer")
                or not self.workflow_pattern_analyzer
            ):
                return {}

            # 워크플로우 패턴 분석기를 통한 추천
            recommendations = (
                await self.workflow_pattern_analyzer.get_recommended_workflow_for_query(
                    query, user_id
                )
            )

            return recommendations

        except Exception as e:
            logger.error(f"워크플로우 추천 조회 오류: {e}")
            return {}

    async def _apply_learned_optimizations(
        self, workflow_tracker: Dict, pattern_recommendations: Dict
    ):
        """학습된 최적화 적용"""
        try:
            if not pattern_recommendations:
                return

            # 권장 도구 순서 적용
            recommended_tools = pattern_recommendations.get("recommended_tools", [])
            if recommended_tools and "tools_used" in workflow_tracker:
                # 기존 도구 목록을 추천 순서로 재배열
                current_tools = workflow_tracker["tools_used"]
                optimized_order = []

                # 추천 도구 순서대로 먼저 배치
                for rec_tool in recommended_tools:
                    for current_tool in current_tools:
                        if rec_tool.lower() in current_tool.lower():
                            optimized_order.append(current_tool)
                            break

                # 나머지 도구들 추가
                for tool in current_tools:
                    if tool not in optimized_order:
                        optimized_order.append(tool)

                workflow_tracker["tools_used"] = optimized_order
                logger.info(f"도구 순서 최적화 적용: {optimized_order}")

            # 실행 접근법 최적화
            recommended_approach = pattern_recommendations.get("recommended_approach")
            if recommended_approach and recommended_approach != workflow_tracker.get(
                "execution_approach"
            ):
                logger.info(
                    f"실행 접근법 최적화 제안: {workflow_tracker.get('execution_approach')} -> {recommended_approach}"
                )
                # 실제 적용은 다음 실행 시 고려될 수 있도록 메타데이터에 저장
                workflow_tracker["optimization_suggestions"] = {
                    "recommended_approach": recommended_approach,
                    "current_approach": workflow_tracker.get("execution_approach"),
                    "confidence": pattern_recommendations.get("confidence", 0),
                }

        except Exception as e:
            logger.error(f"학습된 최적화 적용 오류: {e}")

    def _extract_workflow_insights(self, workflow_tracker: Dict) -> Dict[str, Any]:
        """워크플로우에서 인사이트 추출"""
        try:
            insights = {
                "efficiency_insights": [],
                "tool_usage_insights": [],
                "timing_insights": [],
                "error_insights": [],
            }

            # 효율성 인사이트
            total_duration = workflow_tracker.get("total_duration", 0)
            step_count = len(workflow_tracker.get("steps", []))

            if total_duration > 180:  # 3분 이상
                insights["efficiency_insights"].append("workflow_duration_long")
            if step_count > 5:
                insights["efficiency_insights"].append("many_steps_executed")

            # 도구 사용 인사이트
            tools_used = workflow_tracker.get("tools_used", [])
            unique_tool_types = len(set([tool.split("_")[0] for tool in tools_used]))

            if len(tools_used) > unique_tool_types * 2:
                insights["tool_usage_insights"].append("repetitive_tool_usage")
            if unique_tool_types >= 3:
                insights["tool_usage_insights"].append("diverse_tool_combination")

            # 타이밍 인사이트
            steps = workflow_tracker.get("steps", [])
            step_durations = [
                step.get("duration", 0) for step in steps if step.get("duration", 0) > 0
            ]

            if step_durations:
                avg_duration = sum(step_durations) / len(step_durations)
                max_duration = max(step_durations)

                if max_duration > avg_duration * 3:
                    insights["timing_insights"].append("bottleneck_step_detected")
                if avg_duration < 10:
                    insights["timing_insights"].append("fast_execution_achieved")

            # 오류 인사이트
            failed_steps = [step for step in steps if step.get("status") == "failed"]
            if failed_steps:
                insights["error_insights"].append("step_failures_occurred")
                if len(failed_steps) > len(steps) * 0.3:
                    insights["error_insights"].append("high_failure_rate")

            return insights

        except Exception as e:
            logger.error(f"워크플로우 인사이트 추출 오류: {e}")
            return {
                "efficiency_insights": [],
                "tool_usage_insights": [],
                "timing_insights": [],
                "error_insights": [],
            }

    async def _initialize_hierarchical_planning_with_metadata(self):
        """계층적 플래너 강제 메타데이터 연결 - 완전 개선 버전 v3"""
        try:
            logger.info("🔧 계층적 플래너 강제 메타데이터 연결 v3 시작...")

            # 1. 🔥 올바른 메타데이터 지원 클래스 사용 확인
            planner_class = (
                EnhancedHierarchicalPlannerWithMetadata  # 메타데이터 완전 지원 클래스
            )
            executor_class = EnhancedHierarchicalExecutorWithMetadata

            logger.info(f"📋 사용할 클래스:")
            logger.info(f"   - Planner: {planner_class.__name__}")
            logger.info(f"   - Executor: {executor_class.__name__}")

            # 2. 플래너/실행기 생성
            self.hierarchical_planner = planner_class(self.model, self.tools)
            self.hierarchical_executor = executor_class(self.model, self.tools)

            logger.info("✅ 메타데이터 지원 플래너/실행기 생성 완료")

            # 3. 사용 가능한 메타데이터 시스템 상세 진단
            available_systems = {
                "enriched_rec": getattr(self, "enriched_recommendation_system", None),
                "basic_rec": getattr(self, "mcp_recommendation_system", None),
                "enriched_vec": getattr(self, "enriched_vector_store", None),
                "basic_vec": getattr(self, "mcp_vector_store", None),
            }

            logger.info("🔍 메타데이터 시스템 진단:")
            for system_key, system_obj in available_systems.items():
                status = "✅ 사용 가능" if system_obj is not None else "❌ 없음"
                system_type = type(system_obj).__name__ if system_obj else "None"
                logger.info(f"   - {system_key}: {status} ({system_type})")

            # 4. 🔥 플래너 메타데이터 연결 (반환값 확인)
            planner_connected = self.hierarchical_planner.connect_metadata_systems(
                mcp_recommendation_system=available_systems["basic_rec"],
                mcp_vector_store=available_systems["basic_vec"],
                enriched_vector_store=available_systems["enriched_vec"],
                enriched_recommendation_system=available_systems["enriched_rec"],
            )

            logger.info(f"🎯 플래너 연결 결과: {planner_connected}")

            # 5. 🔥 실행기 메타데이터 연결 (반환값 확인)
            executor_connected = self.hierarchical_executor.connect_metadata_systems(
                mcp_recommendation_system=available_systems["basic_rec"],
                mcp_vector_store=available_systems["basic_vec"],
                enriched_vector_store=available_systems["enriched_vec"],
                enriched_recommendation_system=available_systems["enriched_rec"],
            )

            logger.info(f"🎯 실행기 연결 결과: {executor_connected}")

            # 6. 🔥 연결 후 상태 강제 검증 및 수정
            if not planner_connected:
                logger.warning("⚠️ 플래너 자동 연결 실패, 수동 설정 시도...")

                # 수동으로 속성 설정
                if available_systems["enriched_rec"] or available_systems["basic_rec"]:
                    self.hierarchical_planner.metadata_enhanced = True
                    logger.info("🔧 플래너 metadata_enhanced 수동 설정")

                if (
                    available_systems["enriched_rec"]
                    or available_systems["enriched_vec"]
                ):
                    self.hierarchical_planner.enriched_mode = True
                    logger.info("🔧 플래너 enriched_mode 수동 설정")

            if not executor_connected:
                logger.warning("⚠️ 실행기 자동 연결 실패, 수동 설정 시도...")

                # 수동으로 속성 설정
                if available_systems["enriched_rec"] or available_systems["basic_rec"]:
                    self.hierarchical_executor.metadata_enhanced = True
                    logger.info("🔧 실행기 metadata_enhanced 수동 설정")

                if (
                    available_systems["enriched_rec"]
                    or available_systems["enriched_vec"]
                ):
                    self.hierarchical_executor.enriched_mode = True
                    logger.info("🔧 실행기 enriched_mode 수동 설정")

            # 7. 🔥 최종 상태 진단 및 보고
            await self.diagnose_hierarchical_planner_status()

            # 8. 추가 안전 장치: 상태 검증
            planner_status = self._check_hierarchical_planner_status()
            executor_status = self._check_hierarchical_executor_status()

            logger.info(f"🏁 최종 상태 검증:")
            logger.info(f"   - 플래너 메타데이터 활성: {planner_status}")
            logger.info(f"   - 실행기 메타데이터 활성: {executor_status}")

            if planner_status and executor_status:
                logger.info("🎉 계층적 플래너 메타데이터 연결 v3 완전 성공!")
            else:
                logger.warning(
                    f"⚠️ 부분적 성공: 플래너({planner_status}), 실행기({executor_status})"
                )

            # 9. 🔥 추가: 메타데이터 시스템 성능 테스트
            await self._test_metadata_system_performance()

        except Exception as e:
            logger.error(f"❌ 계층적 플래너 연결 v3 실패: {e}")
            import traceback

            logger.error(f"상세 오류: {traceback.format_exc()}")

            # 실패 시에도 기본 플래너 생성
            self.hierarchical_planner = HierarchicalPlanner(self.model, self.tools)
            self.hierarchical_executor = HierarchicalExecutor(self.model, self.tools)
            logger.info("🔄 기본 계층적 플래너로 폴백 완료")

    async def _test_metadata_system_performance(self):
        """메타데이터 시스템 성능 테스트"""
        try:
            logger.info("🧪 메타데이터 시스템 성능 테스트 시작...")

            # 플래너에서 메타데이터 상태 조회
            if hasattr(self.hierarchical_planner, "get_metadata_status"):
                planner_status = self.hierarchical_planner.get_metadata_status()
                logger.info(f"📊 플래너 메타데이터 상태: {planner_status}")

            # 테스트 쿼리로 추천 시스템 동작 확인
            if (
                hasattr(self.hierarchical_planner, "mcp_recommendation_system")
                and self.hierarchical_planner.mcp_recommendation_system
            ):
                try:
                    test_result = await self.hierarchical_planner.mcp_recommendation_system.recommend_tools(
                        "test query for metadata system", max_tools=3
                    )
                    if test_result:
                        logger.info(
                            f"✅ 추천 시스템 동작 확인: {len(test_result.recommended_tools)}개 도구 추천"
                        )
                    else:
                        logger.warning("⚠️ 추천 시스템이 빈 결과 반환")
                except Exception as test_error:
                    logger.warning(f"⚠️ 추천 시스템 테스트 실패: {test_error}")

            logger.info("🧪 메타데이터 시스템 성능 테스트 완료")

        except Exception as e:
            logger.warning(f"메타데이터 시스템 테스트 중 오류: {e}")

    def _log_detailed_connection_status(self):
        """상세한 연결 상태 로깅 - 개선된 버전"""
        try:
            logger.info("\n🔗 상세 메타데이터 연결 상태 분석:")

            # 1. 플래너 상세 분석
            if hasattr(self, "hierarchical_planner") and self.hierarchical_planner:
                planner_class = type(self.hierarchical_planner).__name__
                logger.info(f"📋 플래너 분석:")
                logger.info(f"   - 클래스: {planner_class}")

                # 메타데이터 속성들 확인
                metadata_attrs = [
                    "metadata_enhanced",
                    "enriched_mode",
                    "enriched_system_enabled",
                    "enriched_vector_enabled",
                ]
                for attr in metadata_attrs:
                    if hasattr(self.hierarchical_planner, attr):
                        value = getattr(self.hierarchical_planner, attr)
                        status = "✅" if value else "❌"
                        logger.info(f"   - {attr}: {status} ({value})")
                    else:
                        logger.info(f"   - {attr}: 🚫 속성 없음")

                # 연결된 시스템들 확인
                if hasattr(self.hierarchical_planner, "mcp_recommendation_system"):
                    rec_sys = self.hierarchical_planner.mcp_recommendation_system
                    rec_status = "✅ 연결됨" if rec_sys else "❌ 없음"
                    rec_type = type(rec_sys).__name__ if rec_sys else "None"
                    logger.info(f"   - 추천 시스템: {rec_status} ({rec_type})")

                if hasattr(self.hierarchical_planner, "mcp_vector_store"):
                    vec_store = self.hierarchical_planner.mcp_vector_store
                    vec_status = "✅ 연결됨" if vec_store else "❌ 없음"
                    vec_type = type(vec_store).__name__ if vec_store else "None"
                    logger.info(f"   - 벡터 스토어: {vec_status} ({vec_type})")

            # 2. 실행기 상세 분석
            if hasattr(self, "hierarchical_executor") and self.hierarchical_executor:
                executor_class = type(self.hierarchical_executor).__name__
                logger.info(f"⚡ 실행기 분석:")
                logger.info(f"   - 클래스: {executor_class}")

                # 메타데이터 속성들 확인
                for attr in metadata_attrs:
                    if hasattr(self.hierarchical_executor, attr):
                        value = getattr(self.hierarchical_executor, attr)
                        status = "✅" if value else "❌"
                        logger.info(f"   - {attr}: {status} ({value})")
                    else:
                        logger.info(f"   - {attr}: 🚫 속성 없음")

            logger.info("")  # 빈 줄

        except Exception as e:
            logger.error(f"상세 연결 상태 로깅 오류: {e}")

    async def _enhance_server_router_with_metadata(self):
        """서버 라우터에 메타데이터 시스템 연결"""
        try:
            if not self.server_router:
                logger.warning("⚠️ 서버 라우터가 없어 메타데이터 연결 건너뜀")
                return

            connections = 0

            # 추천 시스템 연결
            if self.enrichment_enabled and self.enriched_recommendation_system:
                self.server_router.mcp_recommendation_system = (
                    self.enriched_recommendation_system
                )
                self.server_router.enriched_system_enabled = True
                connections += 1
                logger.info("   ✅ 서버 라우터에 보강된 추천 시스템 연결됨")
            elif self.mcp_recommendation_system:
                self.server_router.mcp_recommendation_system = (
                    self.mcp_recommendation_system
                )
                self.server_router.enriched_system_enabled = False
                connections += 1
                logger.info("   ✅ 서버 라우터에 기존 추천 시스템 연결됨")

            # 벡터 스토어 연결
            if self.enrichment_enabled and self.enriched_vector_store:
                self.server_router.mcp_vector_store = self.enriched_vector_store
                connections += 1
                logger.info("   ✅ 서버 라우터에 보강된 벡터 스토어 연결됨")
            elif self.mcp_vector_store:
                self.server_router.mcp_vector_store = self.mcp_vector_store
                connections += 1
                logger.info("   ✅ 서버 라우터에 기존 벡터 스토어 연결됨")

            # 메타데이터 활용 플래그 설정
            self.server_router.metadata_enhanced = connections > 0

            # 🔥 라우팅 메서드를 메타데이터 기반으로 업그레이드
            if connections > 0:
                await self._upgrade_router_methods()

            logger.info(
                f"✅ 서버 라우터 메타데이터 연결 완료: {connections}개 시스템 연결"
            )

        except Exception as e:
            logger.error(f"❌ 서버 라우터 메타데이터 연결 실패: {e}")

    async def _upgrade_router_methods(self):
        """라우터 메서드를 메타데이터 기반으로 업그레이드"""
        try:
            if not hasattr(self.server_router, "_original_route_query"):
                # 원본 메서드 백업
                self.server_router._original_route_query = (
                    self.server_router.route_query
                )

                # 🔥 메타데이터 기반 라우팅 메서드로 교체 (동기 함수로 수정)
                def metadata_enhanced_route_query(
                    analysis: QueryAnalysis, available_tools: List
                ) -> Tuple[List, str]:
                    """메타데이터 기반 향상된 도구 라우팅 - 동기 버전"""
                    try:
                        # 1. MCP 추천 시스템 활용 시도 (동기 방식으로 변경)
                        if (
                            hasattr(self.server_router, "mcp_recommendation_system")
                            and self.server_router.mcp_recommendation_system
                        ):
                            try:
                                # 🔧 동기 방식으로 변경: asyncio.run 사용하거나 동기 메서드 호출
                                import asyncio

                                # 쿼리 분석을 바탕으로 추천 요청 생성
                                query_for_recommendation = f"{analysis.query_type} {' '.join(analysis.required_tools)}"

                                # 이미 실행 중인 이벤트 루프가 있는지 확인
                                try:
                                    loop = asyncio.get_running_loop()
                                    # 이미 이벤트 루프가 실행 중인 경우, 태스크 생성
                                    future = asyncio.create_task(
                                        self.server_router.mcp_recommendation_system.recommend_tools(
                                            query_for_recommendation
                                        )
                                    )
                                    # 잠시 대기 후 결과 확인 (논블로킹)
                                    recommendation = None
                                    if future.done():
                                        recommendation = future.result()
                                    else:
                                        # 완료되지 않은 경우 폴백
                                        logger.info(
                                            "🔄 MCP 추천 요청이 진행 중, 기본 라우팅으로 폴백"
                                        )
                                        return self.server_router._original_route_query(
                                            analysis, available_tools
                                        )

                                except RuntimeError:
                                    # 이벤트 루프가 없는 경우 새로 생성
                                    recommendation = asyncio.run(
                                        self.server_router.mcp_recommendation_system.recommend_tools(
                                            query_for_recommendation
                                        )
                                    )

                                if recommendation and recommendation.recommended_tools:
                                    # 추천된 도구들을 실제 도구 객체와 매칭
                                    recommended_tools = []
                                    for rec_tool in recommendation.recommended_tools:
                                        for tool in available_tools:
                                            if (
                                                rec_tool.tool_name.lower()
                                                in tool.name.lower()
                                                or tool.name.lower()
                                                in rec_tool.tool_name.lower()
                                            ):
                                                recommended_tools.append(tool)
                                                break

                                    if recommended_tools:
                                        confidence_score = (
                                            recommendation.confidence_score
                                        )
                                        system_type = (
                                            "보강된"
                                            if getattr(
                                                self.server_router,
                                                "enriched_system_enabled",
                                                False,
                                            )
                                            else "기존"
                                        )
                                        reason = f"{system_type} MCP 메타데이터 기반 추천 (신뢰도: {confidence_score:.2f})"
                                        logger.info(
                                            f"🎯 메타데이터 기반 라우팅 성공: {len(recommended_tools)}개 도구 선택"
                                        )
                                        return recommended_tools, reason

                            except Exception as rec_error:
                                logger.warning(f"⚠️ MCP 추천 라우팅 실패: {rec_error}")

                        # 2. 벡터 스토어 활용 시도 (동기 방식)
                        if (
                            hasattr(self.server_router, "mcp_vector_store")
                            and self.server_router.mcp_vector_store
                        ):
                            try:
                                # 벡터 스토어는 일반적으로 동기 메서드
                                search_query = (
                                    f"{analysis.query_type} {analysis.complexity}"
                                )
                                search_results = self.server_router.mcp_vector_store.search_tools_only(
                                    search_query, limit=8
                                )

                                if search_results:
                                    vector_tools = []
                                    for result in search_results:
                                        for tool in available_tools:
                                            if (
                                                result["entity_name"].lower()
                                                in tool.name.lower()
                                            ):
                                                vector_tools.append(tool)
                                                break

                                    if vector_tools:
                                        vector_type = (
                                            "보강된"
                                            if getattr(
                                                self.server_router,
                                                "enriched_vector_enabled",
                                                False,
                                            )
                                            else "기존"
                                        )
                                        reason = f"{vector_type} 벡터 스토어 기반 라우팅 ({len(search_results)}개 매칭)"
                                        logger.info(
                                            f"🔍 벡터 기반 라우팅 성공: {len(vector_tools)}개 도구 선택"
                                        )
                                        return vector_tools, reason

                            except Exception as vector_error:
                                logger.warning(
                                    f"⚠️ 벡터 스토어 라우팅 실패: {vector_error}"
                                )

                        # 3. 폴백: 원본 라우팅 메서드
                        logger.info("🔄 기본 라우팅 메서드로 폴백")
                        return self.server_router._original_route_query(
                            analysis, available_tools
                        )

                    except Exception as e:
                        logger.error(f"❌ 메타데이터 라우팅 전체 실패: {e}")
                        return self.server_router._original_route_query(
                            analysis, available_tools
                        )

                # 메서드 교체
                self.server_router.route_query = metadata_enhanced_route_query
                logger.info("✅ 라우터 메서드를 메타데이터 기반으로 업그레이드 완료")

        except Exception as e:
            logger.error(f"❌ 라우터 메서드 업그레이드 실패: {e}")

    async def _initialize_semantic_tool_matcher(self):
        """Semantic Tool Matcher 초기화"""
        try:
            if not self.tools:
                logger.warning("⚠️ 도구가 없어 Semantic Tool Matcher 초기화 건너뜀")
                return

            # Embedding 모델 확인
            embedding_model = None
            try:
                from langchain_openai import AzureOpenAIEmbeddings

                embedding_model = AzureOpenAIEmbeddings(
                    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                    api_version=os.getenv(
                        "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"
                    ),
                    deployment="text-embedding-3-small",
                )
                logger.info("   ✅ Embedding 모델 초기화 성공")
            except Exception as e:
                logger.warning(f"⚠️ Embedding 모델 초기화 실패: {e}")
                return

            # Tool Matcher 생성
            self.tool_matcher = SemanticToolMatcher(embedding_model, self.tools)
            await self.tool_matcher.initialize_tool_embeddings()

            # Hierarchical Planner에 연결
            if hasattr(self, "hierarchical_planner") and self.hierarchical_planner:
                # Enhanced Hierarchical Planner로 업그레이드
                self.hierarchical_planner = EnhancedHierarchicalPlanner(
                    self.model, self.tools, self.tool_matcher
                )

                # 기존 메타데이터 시스템들 재연결
                if hasattr(self, "mcp_recommendation_system"):
                    self.hierarchical_planner.mcp_recommendation_system = (
                        self.mcp_recommendation_system
                    )
                if hasattr(self, "mcp_vector_store"):
                    self.hierarchical_planner.mcp_vector_store = self.mcp_vector_store

                logger.info("✅ Enhanced Hierarchical Planner로 업그레이드 완료")

            logger.info("✅ Semantic Tool Matcher 초기화 완료")

        except Exception as e:
            logger.error(f"❌ Semantic Tool Matcher 초기화 실패: {e}")

    def _initialize_metadata_routing_stats(self):
        """메타데이터 기반 라우팅 통계 초기화"""
        try:
            # 기존 라우팅 통계 확장
            if not hasattr(self, "routing_stats"):
                self.routing_stats = {
                    "total_queries": 0,
                    "simple_chat": 0,
                    "simple_tool": 0,
                    "complex_tool": 0,
                    "hierarchical_plans": 0,
                }

            # 메타데이터 관련 통계 추가
            self.routing_stats.update(
                {
                    "metadata_enhanced_routing": 0,
                    "mcp_recommendation_used": 0,
                    "vector_store_routing": 0,
                    "enriched_system_routing": 0,
                    "semantic_tool_matching": 0,
                    "fallback_routing": 0,
                    "metadata_routing_success_rate": 0.0,
                }
            )

            # 메타데이터 시스템 상태 통계
            self.metadata_system_stats = {
                "hierarchical_planner_metadata_enabled": (
                    getattr(self.hierarchical_planner, "metadata_enhanced", False)
                    if hasattr(self, "hierarchical_planner")
                    else False
                ),
                "hierarchical_executor_metadata_enabled": (
                    getattr(self.hierarchical_executor, "metadata_enhanced", False)
                    if hasattr(self, "hierarchical_executor")
                    else False
                ),
                "server_router_metadata_enabled": (
                    getattr(self.server_router, "metadata_enhanced", False)
                    if hasattr(self, "server_router")
                    else False
                ),
                "semantic_tool_matcher_available": hasattr(self, "tool_matcher")
                and self.tool_matcher is not None,
                "enriched_systems_count": sum(
                    [
                        self.enrichment_enabled
                        and self.enriched_recommendation_system is not None,
                        self.enrichment_enabled
                        and self.enriched_vector_store is not None,
                        self.mcp_recommendation_system is not None,
                        self.mcp_vector_store is not None,
                    ]
                ),
            }

            logger.info("✅ 메타데이터 기반 라우팅 통계 초기화 완료")
            logger.info(
                f"   - 메타데이터 시스템 연결 수: {self.metadata_system_stats['enriched_systems_count']}"
            )

        except Exception as e:
            logger.error(f"❌ 메타데이터 라우팅 통계 초기화 실패: {e}")

    async def diagnose_hierarchical_planner_status(self):
        """계층적 플래너 상태 정확한 진단"""
        logger.info("\n🔍 계층적 플래너 상태 진단 시작...")

        # 1. 플래너 존재 여부
        has_planner = hasattr(self, "hierarchical_planner")
        planner_not_none = has_planner and self.hierarchical_planner is not None
        logger.info(f"1. 플래너 존재: {has_planner}")
        logger.info(f"2. 플래너 None 아님: {planner_not_none}")

        if planner_not_none:
            planner_type = type(self.hierarchical_planner).__name__
            logger.info(f"3. 플래너 타입: {planner_type}")

            # 속성 존재 여부 확인
            attrs_to_check = [
                "metadata_enhanced",
                "enriched_mode",
                "mcp_recommendation_system",
                "mcp_vector_store",
                "enriched_system_enabled",
                "enriched_vector_enabled",
            ]

            for attr in attrs_to_check:
                has_attr = hasattr(self.hierarchical_planner, attr)
                if has_attr:
                    value = getattr(self.hierarchical_planner, attr)
                    logger.info(f"4. {attr}: {value} (타입: {type(value)})")
                else:
                    logger.info(f"4. {attr}: 속성 없음")

            # connect_metadata_systems 메서드 확인
            has_connect_method = hasattr(
                self.hierarchical_planner, "connect_metadata_systems"
            )
            logger.info(f"5. connect_metadata_systems 메서드: {has_connect_method}")

            # 실제 메타데이터 시스템 연결 상태
            rec_sys_connected = (
                getattr(self.hierarchical_planner, "mcp_recommendation_system", None)
                is not None
            )
            vec_store_connected = (
                getattr(self.hierarchical_planner, "mcp_vector_store", None) is not None
            )
            logger.info(f"6. 추천시스템 실제 연결: {rec_sys_connected}")
            logger.info(f"7. 벡터스토어 실제 연결: {vec_store_connected}")

    def _log_metadata_connection_status(self):
        """메타데이터 연결 상태 상세 로깅 - 수정된 버전"""
        try:
            logger.info("\n🔗 MCP 메타데이터 연결 상태 요약:")

            # 시스템별 연결 상태
            connections = {
                "추천 시스템": {
                    "보강된": self.enrichment_enabled
                    and self.enriched_recommendation_system is not None,
                    "기존": self.mcp_recommendation_system is not None,
                },
                "벡터 스토어": {
                    "보강된": self.enrichment_enabled
                    and self.enriched_vector_store is not None,
                    "기존": self.mcp_vector_store is not None,
                },
                # 🔥 핵심 수정: 계층적 플래너 상태 확인 방법 개선
                "계층적 플래너": self._check_hierarchical_planner_status(),
                "계층적 실행기": self._check_hierarchical_executor_status(),
                "서버 라우터": (
                    hasattr(self, "server_router")
                    and self.server_router is not None
                    and getattr(self.server_router, "metadata_enhanced", False)
                ),
                "의미적 도구 매칭": hasattr(self, "tool_matcher")
                and self.tool_matcher is not None,
            }

            for system_name, status in connections.items():
                if isinstance(status, dict):
                    # 추천 시스템, 벡터 스토어
                    if status["보강된"]:
                        logger.info(f"   ✅ {system_name}: 보강된 시스템 연결됨")
                    elif status["기존"]:
                        logger.info(f"   🔧 {system_name}: 기존 시스템 연결됨")
                    else:
                        logger.info(f"   ❌ {system_name}: 연결되지 않음")
                else:
                    # 기타 시스템
                    emoji = "✅" if status else "❌"
                    status_text = "연결됨" if status else "연결되지 않음"
                    logger.info(f"   {emoji} {system_name}: {status_text}")

            # 전체 메타데이터 활용 수준 평가
            total_systems = 6
            connected_systems = sum(
                [
                    connections["추천 시스템"]["보강된"]
                    or connections["추천 시스템"]["기존"],
                    connections["벡터 스토어"]["보강된"]
                    or connections["벡터 스토어"]["기존"],
                    connections["계층적 플래너"],
                    connections["계층적 실행기"],
                    connections["서버 라우터"],
                    connections["의미적 도구 매칭"],
                ]
            )

            utilization_rate = (connected_systems / total_systems) * 100

            if utilization_rate >= 80:
                logger.info(
                    f"🎯 메타데이터 활용도: {utilization_rate:.1f}% - 완전 통합"
                )
            elif utilization_rate >= 60:
                logger.info(
                    f"🔧 메타데이터 활용도: {utilization_rate:.1f}% - 높은 수준"
                )
            elif utilization_rate >= 40:
                logger.info(
                    f"⚠️ 메타데이터 활용도: {utilization_rate:.1f}% - 부분적 활용"
                )
            else:
                logger.info(
                    f"❌ 메타데이터 활용도: {utilization_rate:.1f}% - 제한적 활용"
                )

            logger.info("")  # 빈 줄로 구분

        except Exception as e:
            logger.error(f"❌ 메타데이터 연결 상태 로깅 실패: {e}")

    def _check_hierarchical_planner_status(self):
        """계층적 플래너 상태 정확한 확인 - 자동 복구 기능 포함"""
        try:
            if (
                not hasattr(self, "hierarchical_planner")
                or self.hierarchical_planner is None
            ):
                logger.warning("   ❌ 계층적 플래너가 존재하지 않음")
                return False

            planner = self.hierarchical_planner
            planner_class = type(planner).__name__
            logger.info(f"🔍 플래너 상태 검사: {planner_class}")

            # 🔥 1. 필수 속성들 존재 여부 확인 및 자동 생성
            required_attrs = {
                "metadata_enhanced": False,
                "enriched_mode": False,
                "enriched_system_enabled": False,
                "enriched_vector_enabled": False,
            }

            missing_attrs_fixed = 0
            for attr_name, default_value in required_attrs.items():
                if not hasattr(planner, attr_name):
                    logger.warning(
                        f"   🔧 누락된 속성 자동 생성: {attr_name} = {default_value}"
                    )
                    setattr(planner, attr_name, default_value)
                    missing_attrs_fixed += 1
                else:
                    current_value = getattr(planner, attr_name)
                    logger.info(f"   ✅ {attr_name}: {current_value}")

            if missing_attrs_fixed > 0:
                logger.info(f"🔧 {missing_attrs_fixed}개 누락 속성 자동 복구 완료")

            # 🔥 2. 메타데이터 시스템 연결 상태 감지 및 플래그 자동 설정
            has_rec_sys = (
                hasattr(planner, "mcp_recommendation_system")
                and planner.mcp_recommendation_system is not None
            )
            has_vec_store = (
                hasattr(planner, "mcp_vector_store")
                and planner.mcp_vector_store is not None
            )

            logger.info(f"🔍 시스템 연결 감지:")
            logger.info(f"   - 추천 시스템: {'✅' if has_rec_sys else '❌'}")
            logger.info(f"   - 벡터 스토어: {'✅' if has_vec_store else '❌'}")

            # 🔥 3. 자동 플래그 설정 (연결된 시스템이 있으면 활성화)
            metadata_should_be_enabled = has_rec_sys or has_vec_store
            current_metadata_enabled = getattr(planner, "metadata_enhanced", False)

            if metadata_should_be_enabled and not current_metadata_enabled:
                logger.info(
                    "🔧 메타데이터 시스템 연결 감지 → metadata_enhanced 자동 활성화"
                )
                planner.metadata_enhanced = True

            # 🔥 4. enriched_mode 자동 설정 (보강된 시스템 연결 여부 확인)
            enriched_rec_connected = (
                has_rec_sys
                and hasattr(planner, "mcp_recommendation_system")
                and "Enriched" in type(planner.mcp_recommendation_system).__name__
            )

            enriched_vec_connected = (
                has_vec_store
                and hasattr(planner, "mcp_vector_store")
                and "Enriched" in type(planner.mcp_vector_store).__name__
            )

            enriched_should_be_enabled = (
                enriched_rec_connected or enriched_vec_connected
            )
            current_enriched_enabled = getattr(planner, "enriched_mode", False)

            if enriched_should_be_enabled and not current_enriched_enabled:
                logger.info("🔧 보강된 시스템 연결 감지 → enriched_mode 자동 활성화")
                planner.enriched_mode = True

            # 🔥 5. 최종 상태 확인 및 보고
            final_metadata_enhanced = getattr(planner, "metadata_enhanced", False)
            final_enriched_mode = getattr(planner, "enriched_mode", False)

            logger.info(f"🏁 최종 플래너 상태:")
            logger.info(f"   - metadata_enhanced: {final_metadata_enhanced}")
            logger.info(f"   - enriched_mode: {final_enriched_mode}")
            logger.info(f"   - 시스템 연결 수: {sum([has_rec_sys, has_vec_store])}")

            # 🔥 6. 추가 검증: connect_metadata_systems 메서드 존재 확인
            has_connect_method = hasattr(planner, "connect_metadata_systems")
            if has_connect_method:
                logger.info("   ✅ connect_metadata_systems 메서드 사용 가능")
            else:
                logger.warning("   ⚠️ connect_metadata_systems 메서드 없음")

            # 🔥 7. 종합 판정 (더 관대한 기준)
            # 메타데이터 시스템이 연결되어 있거나, metadata_enhanced가 True이면 성공
            is_truly_connected = final_metadata_enhanced and (
                has_rec_sys or has_vec_store
            )

            if is_truly_connected:
                logger.info("✅ 계층적 플래너 메타데이터 시스템 정상 동작")
            else:
                logger.warning(f"⚠️ 계층적 플래너 메타데이터 시스템 부분적 연결")
                logger.warning(f"   - metadata_enhanced: {final_metadata_enhanced}")
                logger.warning(f"   - 실제 시스템 연결: {has_rec_sys or has_vec_store}")

            return is_truly_connected

        except Exception as e:
            logger.error(f"계층적 플래너 상태 확인 오류: {e}")
            return False

    def _check_hierarchical_executor_status(self):
        """계층적 실행기 상태 정확한 확인 - 자동 복구 기능 포함"""
        try:
            if (
                not hasattr(self, "hierarchical_executor")
                or self.hierarchical_executor is None
            ):
                logger.warning("   ❌ 계층적 실행기가 존재하지 않음")
                return False

            executor = self.hierarchical_executor
            executor_class = type(executor).__name__
            logger.info(f"🔍 실행기 상태 검사: {executor_class}")

            # 🔥 1. 필수 속성들 존재 여부 확인 및 자동 생성
            required_attrs = {
                "metadata_enhanced": False,
                "enriched_mode": False,
                "enriched_system_enabled": False,
                "enriched_vector_enabled": False,
            }

            missing_attrs_fixed = 0
            for attr_name, default_value in required_attrs.items():
                if not hasattr(executor, attr_name):
                    logger.warning(
                        f"   🔧 실행기 누락 속성 자동 생성: {attr_name} = {default_value}"
                    )
                    setattr(executor, attr_name, default_value)
                    missing_attrs_fixed += 1

            if missing_attrs_fixed > 0:
                logger.info(
                    f"🔧 실행기 {missing_attrs_fixed}개 누락 속성 자동 복구 완료"
                )

            # 🔥 2. 메타데이터 시스템 연결 감지 및 자동 설정
            has_rec_sys = (
                hasattr(executor, "mcp_recommendation_system")
                and executor.mcp_recommendation_system is not None
            )
            has_vec_store = (
                hasattr(executor, "mcp_vector_store")
                and executor.mcp_vector_store is not None
            )

            metadata_should_be_enabled = has_rec_sys or has_vec_store
            current_metadata_enabled = getattr(executor, "metadata_enhanced", False)

            if metadata_should_be_enabled and not current_metadata_enabled:
                logger.info(
                    "🔧 실행기 메타데이터 시스템 연결 감지 → metadata_enhanced 자동 활성화"
                )
                executor.metadata_enhanced = True

            # 🔥 3. 최종 상태 확인
            final_metadata_enhanced = getattr(executor, "metadata_enhanced", False)
            is_truly_connected = final_metadata_enhanced and (
                has_rec_sys or has_vec_store
            )

            logger.info(f"🏁 최종 실행기 상태:")
            logger.info(f"   - metadata_enhanced: {final_metadata_enhanced}")
            logger.info(f"   - 실제 연결: {has_rec_sys or has_vec_store}")
            logger.info(
                f"   - 종합 판정: {'✅ 정상' if is_truly_connected else '⚠️ 부분적'}"
            )

            return is_truly_connected

        except Exception as e:
            logger.error(f"계층적 실행기 상태 확인 오류: {e}")
            return False

    def _force_enable_metadata_systems(self):
        """메타데이터 시스템 강제 활성화 - 최후의 수단"""
        try:
            logger.info("🚨 메타데이터 시스템 강제 활성화 시작...")

            systems_to_fix = [
                (self.hierarchical_planner, "플래너"),
                (self.hierarchical_executor, "실행기"),
            ]

            for system, name in systems_to_fix:
                if system:
                    # 필수 속성들 강제 설정
                    system.metadata_enhanced = True
                    system.enriched_mode = getattr(self, "enrichment_enabled", False)

                    # 메타데이터 시스템 연결 (사용 가능한 것들)
                    if (
                        hasattr(self, "enriched_recommendation_system")
                        and self.enriched_recommendation_system
                    ):
                        system.mcp_recommendation_system = (
                            self.enriched_recommendation_system
                        )
                        system.enriched_system_enabled = True
                    elif (
                        hasattr(self, "mcp_recommendation_system")
                        and self.mcp_recommendation_system
                    ):
                        system.mcp_recommendation_system = (
                            self.mcp_recommendation_system
                        )
                        system.enriched_system_enabled = False

                    if (
                        hasattr(self, "enriched_vector_store")
                        and self.enriched_vector_store
                    ):
                        system.mcp_vector_store = self.enriched_vector_store
                        system.enriched_vector_enabled = True
                    elif hasattr(self, "mcp_vector_store") and self.mcp_vector_store:
                        system.mcp_vector_store = self.mcp_vector_store
                        system.enriched_vector_enabled = False

                    logger.info(f"🔧 {name} 강제 활성화 완료")

            logger.info("✅ 메타데이터 시스템 강제 활성화 완료")

        except Exception as e:
            logger.error(f"메타데이터 시스템 강제 활성화 실패: {e}")

    def get_comprehensive_metadata_status(self) -> Dict[str, Any]:
        """종합적인 메타데이터 시스템 상태 조회"""
        try:
            status = {
                "timestamp": kst_now.isoformat(),
                "overall_status": "unknown",
                "planner": {},
                "executor": {},
                "available_systems": {},
                "issues": [],
                "recommendations": [],
            }

            # 사용 가능한 시스템들 조사
            status["available_systems"] = {
                "enriched_recommendation": hasattr(
                    self, "enriched_recommendation_system"
                )
                and self.enriched_recommendation_system is not None,
                "basic_recommendation": hasattr(self, "mcp_recommendation_system")
                and self.mcp_recommendation_system is not None,
                "enriched_vector_store": hasattr(self, "enriched_vector_store")
                and self.enriched_vector_store is not None,
                "basic_vector_store": hasattr(self, "mcp_vector_store")
                and self.mcp_vector_store is not None,
            }

            # 플래너 상태
            if hasattr(self, "hierarchical_planner") and self.hierarchical_planner:
                status["planner"] = {
                    "exists": True,
                    "class": type(self.hierarchical_planner).__name__,
                    "metadata_enhanced": getattr(
                        self.hierarchical_planner, "metadata_enhanced", False
                    ),
                    "enriched_mode": getattr(
                        self.hierarchical_planner, "enriched_mode", False
                    ),
                    "connected_systems": {
                        "recommendation": hasattr(
                            self.hierarchical_planner, "mcp_recommendation_system"
                        )
                        and self.hierarchical_planner.mcp_recommendation_system
                        is not None,
                        "vector_store": hasattr(
                            self.hierarchical_planner, "mcp_vector_store"
                        )
                        and self.hierarchical_planner.mcp_vector_store is not None,
                    },
                }
            else:
                status["planner"]["exists"] = False
                status["issues"].append("계층적 플래너가 존재하지 않음")

            # 실행기 상태
            if hasattr(self, "hierarchical_executor") and self.hierarchical_executor:
                status["executor"] = {
                    "exists": True,
                    "class": type(self.hierarchical_executor).__name__,
                    "metadata_enhanced": getattr(
                        self.hierarchical_executor, "metadata_enhanced", False
                    ),
                    "enriched_mode": getattr(
                        self.hierarchical_executor, "enriched_mode", False
                    ),
                    "connected_systems": {
                        "recommendation": hasattr(
                            self.hierarchical_executor, "mcp_recommendation_system"
                        )
                        and self.hierarchical_executor.mcp_recommendation_system
                        is not None,
                        "vector_store": hasattr(
                            self.hierarchical_executor, "mcp_vector_store"
                        )
                        and self.hierarchical_executor.mcp_vector_store is not None,
                    },
                }
            else:
                status["executor"]["exists"] = False
                status["issues"].append("계층적 실행기가 존재하지 않음")

            # 전체 상태 판정
            planner_ok = status["planner"].get("metadata_enhanced", False)
            executor_ok = status["executor"].get("metadata_enhanced", False)

            if planner_ok and executor_ok:
                status["overall_status"] = "fully_operational"
            elif planner_ok or executor_ok:
                status["overall_status"] = "partially_operational"
            else:
                status["overall_status"] = "needs_attention"

            # 권장사항 생성
            if not planner_ok:
                status["recommendations"].append("계층적 플래너 메타데이터 연결 필요")
            if not executor_ok:
                status["recommendations"].append("계층적 실행기 메타데이터 연결 필요")

            return status

        except Exception as e:
            logger.error(f"종합 메타데이터 상태 조회 오류: {e}")
            return {"error": str(e), "timestamp": kst_now.isoformat()}

    async def setup_llm_enrichment_system(self):
        """LLM 보강 시스템 설정 - 강제 활성화 버전"""
        try:
            logger.info("🔧 LLM 보강 시스템 강제 초기화 시작...")

            # 🔥 조건 체크 무시하고 직접 초기화
            self.mcp_enricher = MCPMetadataEnricher(
                llm_model=self.model, cache_duration_hours=24
            )

            # 보강된 벡터 스토어 설정
            self.enriched_vector_store = EnrichedUnifiedMCPVectorStore(
                embedding_model=AzureOpenAIEmbeddings(
                    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                    api_version=os.getenv(
                        "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"
                    ),
                    deployment="text-embedding-3-small",
                ),
                collection_name="enriched_mcp_metadata",
            )

            self.enriched_vector_store.setup_collection()

            # 기존 시스템도 초기화
            await self.setup_mcp_metadata_system()

            # 🔥 강제로 활성화 플래그 설정
            self.enrichment_enabled = True

            logger.info("✅ LLM 보강 시스템 강제 활성화 완료")

            # 보강 프로세스 시작 (백그라운드)
            if self.tools:
                # 간단한 더미 데이터로 테스트
                dummy_data = {
                    "test_server": {
                        "description": "Test server for enrichment",
                        "tools": [{"name": "test_tool", "description": "Test tool"}],
                        "resources": [],
                        "prompts": [],
                    }
                }

                # 보강된 추천 시스템 초기화
                if not self.enriched_recommendation_system:
                    self.enriched_recommendation_system = MCPRecommendationSystem(
                        self.enriched_vector_store
                    )
                    logger.info("✅ 보강된 MCP 추천 시스템 초기화 완료")

            return True

        except Exception as e:
            logger.error(f"❌ LLM 보강 시스템 강제 활성화 실패: {e}")
            self.enrichment_enabled = False
            return False

    async def _progressive_enrichment_process(self, mcp_servers: Dict[str, Any]):
        """점진적 보강 프로세스 - 기존 MCP 클라이언트의 로드된 도구들 활용"""
        try:
            logger.info(f"🔄 점진적 보강 프로세스 시작: {len(mcp_servers)}개 서버")

            # 보강 상태 초기화
            self.mcp_enricher.enrichment_status.total_servers = len(mcp_servers)
            self.mcp_enricher.enrichment_status.background_task_running = True

            # 1단계: 이미 로드된 도구들에서 서버별 정보 추출
            logger.info("1단계: 로드된 도구들에서 서버별 메타데이터 추출 중...")

            # 도구들을 서버별로 그룹화
            server_tools = {}
            if self.tools:
                for tool in self.tools:
                    # 도구 이름에서 서버 이름 추출 (예: "hyperbrowser_navigate" -> "hyperbrowser")
                    tool_name = tool.name.lower()
                    server_name = None

                    # MCP 서버 이름과 매칭
                    for srv_name in mcp_servers.keys():
                        srv_name_clean = srv_name.lower().replace("-", "_")
                        if srv_name_clean in tool_name or srv_name.lower() in tool_name:
                            server_name = srv_name
                            break

                    # 매칭되지 않은 경우 도구 이름의 첫 번째 부분으로 추정
                    if not server_name:
                        parts = tool_name.split("_")
                        if len(parts) > 1:
                            potential_server = parts[0]
                            # mcp_servers에서 유사한 이름 찾기
                            for srv_name in mcp_servers.keys():
                                if (
                                    potential_server in srv_name.lower()
                                    or srv_name.lower() in potential_server
                                ):
                                    server_name = srv_name
                                    break

                    # 여전히 매칭되지 않은 경우 기본 서버로 분류
                    if not server_name and mcp_servers:
                        # 가장 일반적인 서버로 분류 (예: 첫 번째 서버)
                        server_name = list(mcp_servers.keys())[0]

                    if server_name:
                        if server_name not in server_tools:
                            server_tools[server_name] = []

                        # 도구 정보 구성
                        tool_info = {
                            "name": tool.name,
                            "description": getattr(tool, "description", ""),
                            "inputSchema": {},
                        }

                        # inputSchema 정보가 있으면 추가
                        if hasattr(tool, "inputSchema"):
                            tool_info["inputSchema"] = getattr(tool, "inputSchema", {})
                        elif hasattr(tool, "args_schema") and tool.args_schema:
                            # Pydantic 모델을 dict로 변환
                            try:
                                if hasattr(tool.args_schema, "model_json_schema"):
                                    tool_info["inputSchema"] = (
                                        tool.args_schema.model_json_schema()
                                    )
                                elif hasattr(tool.args_schema, "schema"):
                                    tool_info["inputSchema"] = tool.args_schema.schema()
                            except Exception as e:
                                logger.debug(f"스키마 추출 실패 ({tool.name}): {e}")
                                tool_info["inputSchema"] = {}

                        # 추가 메타데이터 보강
                        tool_info["_metadata"] = {
                            "has_description": bool(tool_info["description"]),
                            "has_schema": bool(tool_info["inputSchema"]),
                            "parameter_count": len(
                                tool_info["inputSchema"].get("properties", {})
                            ),
                            "extraction_method": "from_loaded_tools",
                        }

                        server_tools[server_name].append(tool_info)

            # 2단계: 서버별 메타데이터 구성
            original_metadata = {}
            for server_name, config in mcp_servers.items():
                tools_for_server = server_tools.get(server_name, [])

                # 서버 설명 생성
                server_description = f"MCP Server: {server_name}"
                if tools_for_server:
                    tool_categories = set()
                    for tool in tools_for_server:
                        name = tool.get("name", "").lower()
                        desc = tool.get("description", "").lower()

                        # 카테고리 분류
                        if any(
                            kw in f"{name} {desc}" for kw in ["search", "find", "query"]
                        ):
                            tool_categories.add("search")
                        if any(
                            kw in f"{name} {desc}"
                            for kw in ["browser", "web", "scrape", "navigate"]
                        ):
                            tool_categories.add("web")
                        if any(
                            kw in f"{name} {desc}"
                            for kw in ["file", "read", "write", "save"]
                        ):
                            tool_categories.add("file")
                        if any(
                            kw in f"{name} {desc}"
                            for kw in ["command", "execute", "shell", "terminal"]
                        ):
                            tool_categories.add("system")
                        if any(
                            kw in f"{name} {desc}" for kw in ["api", "http", "request"]
                        ):
                            tool_categories.add("api")

                    if tool_categories:
                        server_description += (
                            f" - Capabilities: {', '.join(sorted(tool_categories))}"
                        )

                    server_description += f" ({len(tools_for_server)} tools)"

                original_metadata[server_name] = {
                    "description": server_description,
                    "tools": tools_for_server,
                    "resources": [],  # 현재 로드된 정보에서는 리소스 정보 없음
                    "prompts": [],  # 현재 로드된 정보에서는 프롬프트 정보 없음
                    "command": config.get("command", ""),
                    "args": config.get("args", []),
                    "server_info": {
                        "server_name": server_name,
                        "tools_loaded": len(tools_for_server),
                        "extraction_method": "from_loaded_tools",
                        "categories": list(tool_categories) if tools_for_server else [],
                        "extraction_time": kst_now.isoformat(),
                    },
                }

                logger.info(
                    f"✅ {server_name} 메타데이터 추출 완료: {len(tools_for_server)}개 도구"
                )

            if not original_metadata:
                logger.error("원본 메타데이터 추출 실패 - 보강 프로세스 중단")
                return

            # 3단계: LLM 보강 수행
            logger.info("2단계: LLM 보강 수행 중...")
            enriched_data = {}

            for server_name, metadata in original_metadata.items():
                try:
                    logger.info(f"🧠 {server_name} 서버 보강 중...")

                    enriched_metadata = await self.mcp_enricher.enrich_server_metadata(
                        server_name, metadata
                    )
                    enriched_data[server_name] = enriched_metadata

                    # 진행률 업데이트
                    progress = len(enriched_data) / len(original_metadata) * 100
                    self.mcp_enricher.enrichment_status.enrichment_progress = progress

                    logger.info(f"✅ {server_name} 보강 완료 ({progress:.1f}%)")

                    # 점진적 업데이트 (서버 하나씩 또는 3개씩)
                    if len(enriched_data) % 3 == 0 or len(enriched_data) == len(
                        original_metadata
                    ):
                        await self._update_enriched_systems(enriched_data)

                except Exception as e:
                    logger.error(f"서버 보강 실패: {server_name} - {e}")
                    self.mcp_enricher.enrichment_status.failed_servers += 1
                    continue

            # 4단계: 보강 완료 처리
            if enriched_data:
                self.enrichment_enabled = True
                self.mcp_enricher.enrichment_status.last_enrichment_time = (
                    kst_now.isoformat()
                )

                logger.info(
                    f"🎉 LLM 보강 완료! {len(enriched_data)}/{len(original_metadata)}개 서버 성공"
                )

                # 최종 시스템 업데이트
                await self._update_enriched_systems(enriched_data)

            else:
                logger.warning("❌ 모든 서버 보강 실패")

        except Exception as e:
            logger.error(f"점진적 보강 프로세스 오류: {e}")
        finally:
            self.mcp_enricher.enrichment_status.background_task_running = False

    async def _update_enriched_systems(self, enriched_data: Dict[str, Any]):
        """보강된 시스템 업데이트"""
        try:
            # 보강된 벡터 스토어 업데이트
            if self.enriched_vector_store:
                self.enriched_vector_store.store_enriched_metadata(enriched_data)

            # 보강된 추천 시스템 초기화/업데이트
            if not self.enriched_recommendation_system and self.enriched_vector_store:
                self.enriched_recommendation_system = MCPRecommendationSystem(
                    self.enriched_vector_store
                )
                logger.info("✅ 보강된 MCP 추천 시스템 초기화 완료")

            logger.info(f"✅ {len(enriched_data)}개 서버의 보강 정보 적용 완료")

        except Exception as e:
            logger.error(f"보강된 시스템 업데이트 오류: {e}")

    async def setup_mcp_metadata_system(self):
        """MCP 메타데이터 시스템 설정 - MCP 클라이언트 준비 후 실행"""
        try:
            # MCP 클라이언트가 준비되었는지 확인
            if not self.mcp_client or not self.tools:
                logger.warning(
                    "MCP 클라이언트나 도구가 준비되지 않아 메타데이터 시스템을 비활성화합니다."
                )
                return

            # 1. MCP 설정 로드
            mcp_servers = self.mcp_config_loader.load_config()

            if not mcp_servers:
                logger.warning("MCP 설정이 없어 추천 시스템을 비활성화합니다.")
                return

            # 2. InMemoryVectorStore 설정
            self.mcp_vector_store = UnifiedMCPVectorStore(
                collection_name="mcp_metadata"
            )

            # InMemoryVectorStore 초기화
            try:
                self.mcp_vector_store.setup_collection()
                logger.info("✅ InMemoryVectorStore 설정 완료")
            except Exception as e:
                logger.warning(f"⚠️ InMemoryVectorStore 초기화 실패: {e}")
                self.mcp_vector_store = None
                return

            # 3. 추천 시스템 초기화
            if self.mcp_vector_store:
                self.mcp_recommendation_system = MCPRecommendationSystem(
                    self.mcp_vector_store
                )
                logger.info("✅ MCP 추천 시스템 초기화 완료")

            # 4. 메타데이터 수집 (백그라운드에서 실행, MCP 클라이언트 준비 후)
            logger.info(
                "메타데이터 수집을 백그라운드에서 시작합니다 (MCP 클라이언트 준비 완료 후)..."
            )

            # 잠시 대기하여 MCP 서버들이 완전히 준비될 시간 제공
            await asyncio.sleep(3)

            asyncio.create_task(self._collect_metadata_background(mcp_servers))

        except Exception as e:
            logger.error(f"MCP 메타데이터 시스템 설정 오류: {e}")
            self.mcp_vector_store = None
            self.mcp_recommendation_system = None

    async def _collect_metadata_background(self, mcp_servers: Dict[str, Any]):
        """백그라운드에서 메타데이터 수집 - 기존 로드된 도구들 활용"""
        try:
            logger.info(f"백그라운드 메타데이터 수집 시작: {len(mcp_servers)}개 서버")

            # 이미 로드된 도구들에서 서버별 정보 추출
            server_tools = {}
            if self.tools:
                for tool in self.tools:
                    # 도구 이름에서 서버 이름 추출
                    tool_name = tool.name.lower()
                    server_name = None

                    for srv_name in mcp_servers.keys():
                        if (
                            srv_name.lower().replace("-", "_") in tool_name
                            or srv_name.lower() in tool_name
                        ):
                            server_name = srv_name
                            break

                    if not server_name:
                        # 기본적으로 첫 번째 단어나 언더스코어 이전을 서버명으로 간주
                        parts = tool_name.split("_")
                        if len(parts) > 1:
                            potential_server = parts[0]
                            # mcp_servers에서 유사한 이름 찾기
                            for srv_name in mcp_servers.keys():
                                if (
                                    potential_server in srv_name.lower()
                                    or srv_name.lower() in potential_server
                                ):
                                    server_name = srv_name
                                    break

                    if server_name:
                        if server_name not in server_tools:
                            server_tools[server_name] = []

                        tool_info = {
                            "name": tool.name,
                            "description": getattr(tool, "description", ""),
                            "inputSchema": (
                                getattr(tool, "inputSchema", {})
                                if hasattr(tool, "inputSchema")
                                else {}
                            ),
                        }
                        server_tools[server_name].append(tool_info)

            # 서버별 메타데이터 구성
            metadata_list = []
            for server_name, config in mcp_servers.items():
                tools_for_server = server_tools.get(server_name, [])

                # MCPMetadata 객체 생성

                server_description = f"MCP Server: {server_name}"
                if tools_for_server:
                    tool_categories = set()
                    for tool in tools_for_server:
                        name = tool.get("name", "").lower()
                        desc = tool.get("description", "").lower()
                        if any(
                            kw in f"{name} {desc}" for kw in ["search", "find", "query"]
                        ):
                            tool_categories.add("search")
                        if any(
                            kw in f"{name} {desc}"
                            for kw in ["browser", "web", "scrape"]
                        ):
                            tool_categories.add("web")
                        if any(
                            kw in f"{name} {desc}" for kw in ["file", "read", "write"]
                        ):
                            tool_categories.add("file")
                        if any(
                            kw in f"{name} {desc}"
                            for kw in ["command", "execute", "shell"]
                        ):
                            tool_categories.add("system")

                    if tool_categories:
                        server_description += (
                            f" - Capabilities: {', '.join(sorted(tool_categories))}"
                        )

                # 메타데이터 객체 생성 (MCPMetadata와 호환되는 형태)
                metadata = MCPMetadata(
                    server_name=server_name,
                    description=server_description,
                    tools=tools_for_server,
                    resources=[],  # 현재는 리소스 정보 없음
                    prompts=[],  # 현재는 프롬프트 정보 없음
                    command=config.get("command", ""),
                    args=config.get("args", []),
                    server_info={
                        "server_name": server_name,
                        "tools_loaded": len(tools_for_server),
                        "extraction_method": "from_loaded_tools",
                        "connection_time": kst_now.isoformat(),
                    },
                )

                metadata_list.append(metadata)
                logger.info(
                    f"메타데이터 구성 완료: {server_name} ({len(tools_for_server)}개 도구)"
                )

            # 수집된 메타데이터를 벡터 스토어에 저장
            if metadata_list and self.mcp_vector_store:
                try:
                    # MCPMetadata를 dict 형태로 변환
                    mcp_data = {}
                    for metadata in metadata_list:
                        mcp_data[metadata.server_name] = {
                            "description": metadata.description,
                            "tools": metadata.tools,
                            "resources": metadata.resources,
                            "prompts": metadata.prompts,
                            "command": metadata.command,
                            "args": metadata.args,
                            "server_info": metadata.server_info,
                        }

                    self.mcp_vector_store.store_unified_metadata(mcp_data)
                    logger.info(
                        f"✅ {len(metadata_list)}개 서버의 메타데이터를 벡터 스토어에 저장 완료"
                    )

                except Exception as e:
                    logger.error(f"메타데이터 벡터 스토어 저장 오류: {e}")

        except Exception as e:
            logger.error(f"백그라운드 메타데이터 수집 오류: {e}")

    def setup_model(self):
        """LLM 모델 설정"""
        model_name = os.getenv("MODEL_NAME", "claude-3-5-sonnet-20241022")

        if "claude" in model_name.lower():
            self.model = ChatAnthropic(
                model=model_name,
                api_key=os.getenv("ANTHROPIC_API_KEY"),
                temperature=0.1,
                max_tokens=5000,
            )
        else:
            self.model = ChatOpenAI(
                model=model_name, api_key=os.getenv("OPENAI_API_KEY"), temperature=0.1
            )

        logger.info(f"모델 설정 완료: {model_name}")

    async def setup_mcp_client(self):
        """MCP 클라이언트 설정"""
        try:
            if not MCP_AVAILABLE:
                logger.error("❌ langchain-mcp-adapters를 가져올 수 없습니다")
                self.setup_fallback_tools()
                return

            logger.info("✅ langchain-mcp-adapters 사용 가능")

            if not self.setup_mcp_config_diagnostics():
                logger.error("❌ MCP 설정 진단 실패 - fallback 모드로 전환")
                self.setup_fallback_tools()
                return

            mcp_config = self.load_mcp_config()

            if not mcp_config or not mcp_config.get("mcpServers"):
                logger.warning("❌ 유효한 MCP 설정이 없습니다.")
                self.setup_fallback_tools()
                return

            mcp_servers = self.prepare_mcp_servers_with_stability(
                mcp_config["mcpServers"]
            )

            if not mcp_servers:
                logger.warning("❌ 유효한 MCP 서버가 없습니다.")
                self.setup_fallback_tools()
                return

            logger.info(f"🔧 유효한 MCP 서버: {list(mcp_servers.keys())}")

            try:
                logger.info("🔗 MultiServerMCPClient 생성 중...")
                self.mcp_client = MultiServerMCPClient(mcp_servers)
                logger.info("✅ MultiServerMCPClient 생성 성공")

                logger.info("🔧 MCP 도구 로드 시작...")
                await self._load_tools_with_enhanced_retry()

                if not self.tools or len(self.tools) == 0:
                    logger.warning(
                        "⚠️ 도구 로드는 성공했지만 사용 가능한 도구가 없습니다"
                    )
                    logger.info("🔧 기본 도구 추가로 서비스 제공")
                    self.setup_fallback_tools()
                else:
                    logger.info(
                        f"🎉 MCP 도구 설정 완료: {len(self.tools)}개 도구 사용 가능"
                    )

            except Exception as client_error:
                logger.error(f"❌ MultiServerMCPClient 생성 실패: {client_error}")
                self.setup_fallback_tools()

        except Exception as e:
            logger.error(f"❌ MCP 클라이언트 설정 중 치명적 오류: {e}")
            self.setup_fallback_tools()

    def prepare_mcp_servers_with_stability(self, mcp_servers: Dict) -> Dict:
        """연결 안정성을 개선한 MCP 서버 설정"""
        valid_servers = {}

        for name, config in mcp_servers.items():
            try:
                if self.has_placeholder_keys(config):
                    logger.warning(
                        f"⚠️ 서버 '{name}': API 키가 플레이스홀더입니다. 건너뜁니다."
                    )
                    continue

                server_config = config.copy()

                if "transport" not in server_config:
                    server_config["transport"] = "stdio"

                server_config["timeout"] = 60
                server_config["max_retries"] = 3

                valid_servers[name] = server_config
                logger.info(f"✅ 서버 '{name}' 설정 완료 (타임아웃: 60초)")

            except Exception as e:
                logger.error(f"❌ 서버 '{name}' 검증 실패: {e}")
                continue

        return valid_servers

    async def _load_tools_with_enhanced_retry(self, max_retries=3):
        """도구 로드 with enhanced retry logic"""
        logger.info(f"🔍 MCP 도구 로드 시작 (최대 {max_retries}회 시도)")

        for attempt in range(max_retries):
            try:
                logger.info(
                    f"📡 시도 {attempt + 1}/{max_retries}: MCP 클라이언트 연결 확인..."
                )

                if not self.mcp_client:
                    logger.error("❌ MCP 클라이언트가 없습니다")
                    raise Exception("MCP 클라이언트 미초기화")

                timeout = 95 + (attempt * 10)
                logger.info(f"⏰ 타임아웃: {timeout}초")

                tools = None

                if attempt == 0:
                    logger.info("🔧 기본 get_tools() 방법 시도...")
                    tools = await asyncio.wait_for(
                        self.mcp_client.get_tools(), timeout=timeout
                    )
                elif attempt == 1:
                    logger.info("🔧 개별 서버 연결 방법 시도...")
                    tools = await self._try_individual_servers()
                else:
                    logger.info("🔧 MCP 클라이언트 재연결 시도...")
                    await self._reconnect_mcp_client()
                    tools = await asyncio.wait_for(
                        self.mcp_client.get_tools(), timeout=timeout
                    )

                logger.info(f"📊 도구 로드 결과 분석:")
                logger.info(f"   - 반환된 객체 타입: {type(tools)}")
                logger.info(f"   - 도구 개수: {len(tools) if tools else 0}")

                if tools:
                    logger.info(
                        f"   - 첫 번째 도구 타입: {type(tools[0]) if tools else 'None'}"
                    )
                    if len(tools) > 0 and hasattr(tools[0], "name"):
                        logger.info(f"   - 첫 번째 도구명: {tools[0].name}")

                if tools and len(tools) > 0:
                    logger.info(f"✅ 도구 로드 성공: {len(tools)}개 발견")

                    valid_tools = []
                    invalid_tools = []

                    for i, tool in enumerate(tools):
                        try:
                            if hasattr(tool, "name") and tool.name:
                                valid_tools.append(tool)
                                description = getattr(
                                    tool, "description", "No description"
                                )
                                logger.info(
                                    f"   ✅ {i+1}. {tool.name}: {description[:50]}..."
                                )
                            else:
                                invalid_tools.append(tool)
                                logger.warning(
                                    f"   ❌ {i+1}. 유효하지 않은 도구: {type(tool)} - {str(tool)[:50]}"
                                )
                        except Exception as tool_error:
                            logger.error(f"   ❌ {i+1}. 도구 검증 오류: {tool_error}")
                            invalid_tools.append(tool)

                    if valid_tools:
                        self.tools = valid_tools
                        logger.info(f"🎯 최종 유효한 도구: {len(self.tools)}개")
                        logger.info(f"🗑️ 제외된 도구: {len(invalid_tools)}개")

                        self._analyze_tool_capabilities()
                        return
                    else:
                        logger.warning(
                            f"⚠️ 로드된 {len(tools)}개 도구가 모두 유효하지 않음"
                        )
                        raise Exception(
                            f"유효한 도구 없음 (총 {len(tools)}개 중 0개 유효)"
                        )
                else:
                    logger.warning(f"⚠️ 빈 도구 목록 반환 (시도 {attempt + 1})")
                    if attempt < max_retries - 1:
                        wait_time = 5 + (attempt * 5)
                        logger.info(f"⏳ {wait_time}초 대기 후 재시도...")
                        await asyncio.sleep(wait_time)
                        continue
                    else:
                        raise Exception("모든 시도에서 빈 도구 목록 반환")

            except asyncio.TimeoutError:
                logger.error(
                    f"⏰ 도구 로드 타임아웃 ({timeout}초) - 시도 {attempt + 1}"
                )
                if attempt < max_retries - 1:
                    await asyncio.sleep(10)
                    continue
                else:
                    break

            except Exception as e:
                logger.error(f"❌ 도구 로드 실패 (시도 {attempt + 1}): {e}")
                logger.error(f"   오류 타입: {type(e).__name__}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(10)
                    continue
                else:
                    break

        logger.error("💥 모든 MCP 도구 로드 시도 실패")
        logger.warning("🔧 기본 도구로 fallback 처리")
        self.setup_fallback_tools()

    async def _try_individual_servers(self):
        """개별 서버 시도 방법"""
        try:
            logger.info("🔗 개별 서버별 도구 로드 시도...")

            if not self.mcp_client:
                logger.error("❌ MCP 클라이언트가 없습니다")
                return []

            try:
                logger.info("📋 연결된 서버 정보 확인 중...")

                tools = await asyncio.wait_for(self.mcp_client.get_tools(), timeout=20)

                logger.info(
                    f"🔍 개별 서버 시도 결과: {len(tools) if tools else 0}개 도구"
                )
                return tools or []

            except asyncio.TimeoutError:
                logger.error("⏰ 개별 서버 연결 타임아웃")
                return []
            except Exception as e:
                logger.error(f"❌ 개별 서버 연결 실패: {e}")
                return []

        except Exception as e:
            logger.error(f"💥 개별 서버 시도 중 치명적 오류: {e}")
            return []

    async def _reconnect_mcp_client(self):
        """MCP 클라이언트 재연결"""
        try:
            logger.info("🔄 MCP 클라이언트 재연결 시도...")

            if self.mcp_client:
                try:
                    if hasattr(self.mcp_client, "close"):
                        await self.mcp_client.close()
                except Exception as cleanup_error:
                    logger.warning(f"⚠️ 기존 클라이언트 정리 중 오류: {cleanup_error}")

            mcp_config = self.load_mcp_config()
            if mcp_config and mcp_config.get("mcpServers"):
                mcp_servers = self.prepare_mcp_servers_with_stability(
                    mcp_config["mcpServers"]
                )
                if mcp_servers:
                    self.mcp_client = MultiServerMCPClient(mcp_servers)
                    logger.info("✅ MCP 클라이언트 재연결 성공")
                else:
                    logger.error("❌ 유효한 MCP 서버 설정 없음")
            else:
                logger.error("❌ MCP 설정 로드 실패")

        except Exception as e:
            logger.error(f"❌ MCP 클라이언트 재연결 실패: {e}")

    def setup_mcp_config_diagnostics(self):
        """MCP 설정 진단"""
        try:
            logger.info("🔍 MCP 설정 진단 시작...")

            config_path = "mcp_config.json"

            if not os.path.exists(config_path):
                logger.error(f"❌ MCP 설정 파일이 없습니다: {config_path}")
                return False

            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                logger.info(f"✅ 설정 파일 읽기 성공")
            except Exception as read_error:
                logger.error(f"❌ 설정 파일 읽기 실패: {read_error}")
                return False

            if not isinstance(config, dict):
                logger.error("❌ 설정 파일이 올바른 JSON 객체가 아닙니다")
                return False

            if "mcpServers" not in config:
                logger.error("❌ 'mcpServers' 키가 설정에 없습니다")
                return False

            mcp_servers = config["mcpServers"]
            if not isinstance(mcp_servers, dict):
                logger.error("❌ 'mcpServers'가 올바른 객체가 아닙니다")
                return False

            logger.info(f"📊 총 {len(mcp_servers)}개 서버 설정 발견:")

            valid_servers = 0
            for server_name, server_config in mcp_servers.items():
                logger.info(f"   🔍 서버 '{server_name}' 검사 중...")

                if self.has_placeholder_keys(server_config):
                    logger.warning(f"   ⚠️ '{server_name}': API 키가 플레이스홀더입니다")
                    continue

                if not isinstance(server_config, dict):
                    logger.warning(f"   ⚠️ '{server_name}': 설정이 올바르지 않습니다")
                    continue

                if "command" not in server_config and "args" not in server_config:
                    logger.warning(
                        f"   ⚠️ '{server_name}': command 또는 args가 없습니다"
                    )
                    continue

                logger.info(f"   ✅ '{server_name}': 설정이 유효합니다")
                valid_servers += 1

            logger.info(f"📈 유효한 서버: {valid_servers}/{len(mcp_servers)}개")

            if valid_servers == 0:
                logger.error("❌ 유효한 MCP 서버 설정이 없습니다")
                return False

            return True

        except Exception as e:
            logger.error(f"❌ MCP 설정 진단 중 오류: {e}")
            return False

    def _analyze_tool_capabilities(self):
        """도구 기능 분석 (개선된 메타데이터 추출)"""
        if not self.tools:
            return

        capabilities = {}
        for tool in self.tools:
            tool_name = tool.name.lower()
            tool_description = getattr(tool, "description", "").lower()

            # 도구 이름과 설명을 함께 분석
            combined_text = f"{tool_name} {tool_description}"
            caps = []

            # 웹 브라우징 관련
            if any(
                keyword in combined_text
                for keyword in [
                    "browser",
                    "hyperbrowser",
                    "webpage",
                    "scrape",
                    "crawl",
                    "navigate",
                ]
            ):
                caps.append("웹 브라우징")

            # 검색 관련
            if any(
                keyword in combined_text
                for keyword in [
                    "search",
                    "perplexity",
                    "find",
                    "query",
                    "lookup",
                    "exa",
                ]
            ):
                caps.append("검색")

            # 날씨 관련
            if any(
                keyword in combined_text
                for keyword in ["weather", "climate", "temperature"]
            ):
                caps.append("날씨")

            # 시스템 명령 관련
            if any(
                keyword in combined_text
                for keyword in ["command", "execute", "shell", "terminal", "desktop"]
            ):
                caps.append("시스템 명령")

            # 파일 작업 관련
            if any(
                keyword in combined_text
                for keyword in ["file", "read", "write", "directory", "folder"]
            ):
                caps.append("파일 작업")

            # 데이터베이스 관련
            if any(
                keyword in combined_text
                for keyword in ["database", "sql", "mysql", "postgres", "mongo"]
            ):
                caps.append("데이터베이스")

            # API 관련
            if any(
                keyword in combined_text
                for keyword in ["api", "http", "rest", "github", "slack"]
            ):
                caps.append("API 연동")

            # 코드 관련
            if any(
                keyword in combined_text
                for keyword in ["code", "python", "javascript", "programming"]
            ):
                caps.append("코드 실행")

            # 분석 관련
            if any(
                keyword in combined_text
                for keyword in ["analyze", "analysis", "data", "report"]
            ):
                caps.append("데이터 분석")

            # 기본 분류가 없는 경우
            if not caps:
                if "get" in tool_name or "read" in tool_name:
                    caps.append("정보 조회")
                elif (
                    "set" in tool_name or "write" in tool_name or "create" in tool_name
                ):
                    caps.append("데이터 생성")
                elif "list" in tool_name:
                    caps.append("목록 조회")
                else:
                    caps.append("범용 도구")

            capabilities[tool.name] = caps

        logger.info(f"도구 기능 분석 완료: 총 {len(capabilities)}개 도구")

        # 카테고리별 도구 수 요약
        category_counts = {}
        for tool_caps in capabilities.values():
            for cap in tool_caps:
                category_counts[cap] = category_counts.get(cap, 0) + 1

        logger.info(f"카테고리별 도구 분포: {category_counts}")

        # 상세 분석 결과 출력 (처음 10개만)
        logger.info("도구별 상세 분석 (일부):")
        for i, (tool_name, caps) in enumerate(list(capabilities.items())[:10]):
            logger.info(f"  - {tool_name}: {caps}")

        if len(capabilities) > 10:
            logger.info(f"  ... 및 {len(capabilities) - 10}개 추가 도구")

    def has_placeholder_keys(self, config):
        """플레이스홀더 키 확인"""
        args_str = str(config.get("args", []))
        placeholders = [
            "API_KEY 입력",
            "your_api_key",
            "YOUR_API_KEY",
            "ENTER_YOUR_KEY",
            "put_your_api_key_here",
            "replace_with_your_key",
        ]
        return any(placeholder in args_str for placeholder in placeholders)

    def load_mcp_config(self) -> Optional[Dict]:
        """MCP 설정 로드"""
        config_path = "mcp_config.json"

        try:
            if not os.path.exists(config_path):
                logger.error(f"❌ 설정 파일이 없습니다: {config_path}")
                return None

            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)

            if not isinstance(config, dict) or "mcpServers" not in config:
                logger.error("❌ 유효하지 않은 설정 파일 구조")
                return None

            return config

        except Exception as e:
            logger.error(f"❌ 설정 파일 로드 오류: {e}")
            return None

    def setup_server_router(self):
        """서버 라우터 설정"""
        if self.tools:
            self.server_router = MCPServerRouter(self.tools)
            logger.info(f"✅ 서버 라우터 설정 완료: {len(self.tools)}개 도구 기반")
        else:
            logger.warning("⚠️ 사용 가능한 도구가 없어 라우터를 설정할 수 없습니다.")

    async def process_query_with_routing(
        self, chat_id: str, query: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """워크플로우 패턴 학습이 포함된 라우팅 기반 쿼리 처리"""

        # 🔥 워크플로우 추적 시작
        workflow_tracker = {
            "start_time": kst_now,
            "query": query,
            "chat_id": chat_id,
            "steps": [],
            "tools_used": [],
            "step_timings": {},
            "routing_decision": None,
            "memory_context": [],
            "success": False,
            "error_details": None,
            "execution_approach": None,
            "workflow_type": None,
            "quality_metrics": {},
            "user_satisfaction": None,
        }

        # 순차적 콜백 생성
        sequential_callback = EnhancedSequentialCallback(chat_id, self.scenario_logger)
        recommendation_result = None
        selected_tools = []
        relevant_memories = []
        workflow_type = "standard"
        final_result = None
        analysis = None

        try:
            # =================================
            # 1. 워크플로우 시작
            # =================================
            await sequential_callback.start_workflow("Enhanced MCP Agent", query)

            # 워크플로우 시작 추적
            workflow_tracker["workflow_type"] = "enhanced_mcp_routing"
            workflow_tracker["steps"].append(
                {
                    "step_name": "workflow_initialization",
                    "start_time": kst_now,
                    "status": "started",
                    "description": "Enhanced MCP Agent 워크플로우 시작",
                }
            )

            # 시작 이벤트 즉시 스트리밍
            start_events = await sequential_callback.get_recent_events(1)
            for event in start_events:
                yield event

            # =================================
            # 2. 분석 단계
            # =================================
            analysis_start_time = kst_now
            await sequential_callback.set_analysis_phase()
            await sequential_callback.add_thinking(
                "사용자 쿼리의 복잡도와 요구사항을 분석하고 있습니다..."
            )

            # 분석 이벤트 스트리밍
            analysis_events = await sequential_callback.get_recent_events(2)
            for event in analysis_events:
                yield event

            # 1. 메모리에서 관련 컨텍스트 조회
            memory_retrieval_start = kst_now
            if self.memory_manager and self.memory_manager.enabled:
                try:
                    relevant_memories = await self.memory_manager.get_relevant_memories(
                        user_id=chat_id, query=query, limit=5
                    )

                    # 메모리 컨텍스트 추적
                    workflow_tracker["memory_context"] = [
                        {
                            "memory_id": mem.get("id", "unknown"),
                            "relevance_score": mem.get("score", 0),
                            "memory_type": mem.get("metadata", {}).get(
                                "type", "unknown"
                            ),
                            "timestamp": mem.get("metadata", {}).get("timestamp", ""),
                        }
                        for mem in relevant_memories
                    ]

                    workflow_tracker["steps"].append(
                        {
                            "step_name": "memory_retrieval",
                            "start_time": memory_retrieval_start,
                            "end_time": kst_now,
                            "duration": (
                                kst_now - memory_retrieval_start
                            ).total_seconds(),
                            "status": "completed",
                            "results": {
                                "memories_found": len(relevant_memories),
                                "memory_types": list(
                                    set(
                                        [
                                            mem.get("metadata", {}).get(
                                                "type", "unknown"
                                            )
                                            for mem in relevant_memories
                                        ]
                                    )
                                ),
                            },
                        }
                    )

                    if relevant_memories:
                        await sequential_callback.add_thinking(
                            f"관련 이전 대화 {len(relevant_memories)}개를 참조합니다..."
                        )
                        memory_events = await sequential_callback.get_recent_events(1)
                        for event in memory_events:
                            yield event
                except Exception as e:
                    logger.warning(f"메모리 조회 실패: {e}")
                    workflow_tracker["steps"].append(
                        {
                            "step_name": "memory_retrieval",
                            "start_time": memory_retrieval_start,
                            "end_time": kst_now,
                            "status": "failed",
                            "error": str(e),
                        }
                    )

            # 2. 쿼리 분석 수행
            query_analysis_start = kst_now
            analysis = self.query_analyzer.analyze_query(query)

            # 향상된 쿼리 분석 (가능한 경우)
            enhanced_analysis = None
            if hasattr(self, "enhanced_query_analyzer"):
                try:
                    enhanced_analysis = (
                        self.enhanced_query_analyzer.analyze_query_complexity(query)
                    )
                    workflow_tracker["routing_decision"] = {
                        "complexity": enhanced_analysis.complexity.value,
                        "confidence": enhanced_analysis.confidence,
                        "reasoning": enhanced_analysis.reasoning,
                        "approach": enhanced_analysis.recommended_approach,
                        "estimated_steps": enhanced_analysis.estimated_steps,
                        "requires_planning": enhanced_analysis.requires_planning,
                    }
                except Exception as e:
                    logger.warning(f"향상된 쿼리 분석 실패: {e}")

            workflow_tracker["steps"].append(
                {
                    "step_name": "query_analysis",
                    "start_time": query_analysis_start,
                    "end_time": kst_now,
                    "duration": (kst_now - query_analysis_start).total_seconds(),
                    "status": "completed",
                    "results": {
                        "query_type": analysis.query_type,
                        "complexity": analysis.complexity,
                        "estimated_steps": analysis.estimated_steps,
                        "enhanced_analysis_available": enhanced_analysis is not None,
                    },
                }
            )

            logger.info(
                f"쿼리 분석 완료: {analysis.query_type} ({analysis.complexity})"
            )

            # =================================
            # 3. 라우팅 단계
            # =================================
            routing_start_time = kst_now
            await sequential_callback.set_routing_phase()

            # 시스템 정보 쿼리 확인
            if analysis.query_type == "system_info" and self.system_info_generator:
                await sequential_callback.add_thinking(
                    "시스템 정보 요청으로 분석됨 - 직접 처리 모드"
                )

                # 워크플로우 추적 업데이트
                workflow_tracker["execution_approach"] = "system_info_direct"
                workflow_tracker["steps"].append(
                    {
                        "step_name": "routing_decision",
                        "start_time": routing_start_time,
                        "end_time": kst_now,
                        "status": "completed",
                        "results": {"route": "system_info_direct"},
                    }
                )

                # 라우팅 이벤트 스트리밍
                routing_events = await sequential_callback.get_recent_events(2)
                for event in routing_events:
                    yield event

                # 시스템 정보 직접 처리
                async for event in self._handle_system_info_query_sequential(
                    chat_id, query, analysis, sequential_callback
                ):
                    yield event

                # 성공적인 워크플로우 학습 저장
                workflow_tracker["success"] = True
                workflow_tracker["execution_approach"] = "system_info_direct"
                await self._store_successful_workflow_pattern(
                    chat_id, workflow_tracker, {"content": "시스템 정보 제공 완료"}
                )

                return

            # 일반 쿼리 라우팅 결정
            routing_info = {
                "decision": f"{analysis.query_type} ({analysis.complexity}) 패턴으로 분석됨",
                "description": f"복잡도: {analysis.complexity} | 예상 단계: {analysis.estimated_steps}단계",
                "complexity": analysis.complexity,
                "estimated_steps": analysis.estimated_steps,
                "query_type": analysis.query_type,
            }

            await sequential_callback.add_routing_decision(routing_info)

            # 단순 채팅 처리
            if analysis.query_type == "chat" and analysis.complexity == "simple":
                await sequential_callback.add_thinking(
                    "단순 대화로 분류 - 직접 LLM 응답 모드"
                )

                # 워크플로우 추적 업데이트
                workflow_tracker["execution_approach"] = "simple_chat_direct"
                workflow_tracker["steps"].append(
                    {
                        "step_name": "routing_decision",
                        "start_time": routing_start_time,
                        "end_time": kst_now,
                        "status": "completed",
                        "results": {"route": "simple_chat_direct"},
                    }
                )

                # 라우팅 이벤트 스트리밍
                routing_events = await sequential_callback.get_recent_events(2)
                for event in routing_events:
                    yield event

                # 단순 채팅 처리
                async for event in self._handle_simple_chat_sequential(
                    chat_id, query, analysis, sequential_callback, relevant_memories
                ):
                    yield event

                # 성공적인 워크플로우 학습 저장
                workflow_tracker["success"] = True
                workflow_tracker["execution_approach"] = "simple_chat_direct"
                await self._store_successful_workflow_pattern(
                    chat_id, workflow_tracker, {"content": "단순 채팅 처리 완료"}
                )

                return

            # =================================
            # 4. MCP 추천 시스템 활용
            # =================================
            recommendation_start_time = kst_now
            if self.mcp_recommendation_system:
                await sequential_callback.add_thinking(
                    "MCP 추천 시스템으로 최적 도구를 분석하고 있습니다..."
                )

                try:
                    recommendation_result = (
                        await self.mcp_recommendation_system.recommend_tools(
                            query, max_servers=3, max_tools=10
                        )
                    )

                    if recommendation_result:
                        # 추천 결과 이벤트
                        server_info = [
                            f"{s['server_name']} ({s['score']:.2f})"
                            for s in recommendation_result.recommended_servers[:3]
                        ]
                        tool_info = [
                            f"{t.tool_name} ({t.score:.2f})"
                            for t in recommendation_result.recommended_tools[:5]
                        ]

                        recommendation_info = {
                            "decision": f"MCP 추천 완료 (신뢰도: {recommendation_result.confidence_score:.2f})",
                            "description": f"추천 서버: {', '.join(server_info)} | 추천 도구: {len(recommendation_result.recommended_tools)}개",
                            "confidence": recommendation_result.confidence_score,
                            "servers": server_info,
                            "tools": tool_info[:5],
                        }

                        await sequential_callback.add_routing_decision(
                            recommendation_info
                        )

                        # 워크플로우 추적에 추천 정보 저장
                        workflow_tracker["steps"].append(
                            {
                                "step_name": "mcp_recommendation",
                                "start_time": recommendation_start_time,
                                "end_time": kst_now,
                                "duration": (
                                    kst_now - recommendation_start_time
                                ).total_seconds(),
                                "status": "completed",
                                "results": {
                                    "confidence_score": recommendation_result.confidence_score,
                                    "recommended_servers": len(
                                        recommendation_result.recommended_servers
                                    ),
                                    "recommended_tools": len(
                                        recommendation_result.recommended_tools
                                    ),
                                    "top_tools": tool_info[:3],
                                },
                            }
                        )

                        logger.info(
                            f"MCP 추천 완료: {len(recommendation_result.recommended_tools)}개 도구 추천"
                        )

                except Exception as e:
                    logger.warning(f"MCP 추천 시스템 오류: {e}")
                    await sequential_callback.add_thinking(
                        "MCP 추천 시스템 오류 - 기본 라우팅으로 진행"
                    )

                    workflow_tracker["steps"].append(
                        {
                            "step_name": "mcp_recommendation",
                            "start_time": recommendation_start_time,
                            "end_time": kst_now,
                            "status": "failed",
                            "error": str(e),
                        }
                    )

            # 도구 라우팅 수행
            tool_routing_start_time = kst_now
            if recommendation_result and recommendation_result.recommended_tools:
                # MCP 추천된 도구들을 실제 도구 객체로 변환
                selected_tools = []
                for rec_tool in recommendation_result.recommended_tools:
                    for tool in self.tools or []:
                        if (
                            rec_tool.tool_name.lower() in tool.name.lower()
                            or tool.name.lower() in rec_tool.tool_name.lower()
                        ):
                            selected_tools.append(tool)
                            break

                if not selected_tools and self.server_router and self.tools:
                    selected_tools, reason = await self.server_router.route_query(
                        analysis, self.tools
                    )
                    reason = f"MCP 추천 매칭 실패, 폴백: {reason}"
                else:
                    reason = f"MCP 추천 기반 선택 (추천: {len(recommendation_result.recommended_tools)}개, 매칭: {len(selected_tools)}개)"

            elif self.server_router and self.tools:
                selected_tools, reason = await self.server_router.route_query(
                    analysis, self.tools
                )
                reason = f"기존 라우팅 시스템: {reason}"
            else:
                selected_tools = self.tools or []
                reason = "기본 모든 도구 사용"

            # 도구 선택 결과 추적
            workflow_tracker["tools_used"] = [tool.name for tool in selected_tools]
            workflow_tracker["steps"].append(
                {
                    "step_name": "tool_routing",
                    "start_time": tool_routing_start_time,
                    "end_time": kst_now,
                    "duration": (kst_now - tool_routing_start_time).total_seconds(),
                    "status": "completed",
                    "results": {
                        "selected_tools_count": len(selected_tools),
                        "selected_tools": [tool.name for tool in selected_tools],
                        "routing_reason": reason,
                        "recommendation_used": recommendation_result is not None,
                    },
                }
            )

            # 최종 라우팅 결정
            final_routing_info = {
                "decision": f"최종 도구 선택: {len(selected_tools)}개",
                "description": reason,
                "selected_tools": [tool.name for tool in selected_tools[:5]],
                "total_tools": len(selected_tools),
            }
            await sequential_callback.add_routing_decision(final_routing_info)

            # 라우팅 이벤트 스트리밍
            routing_events = await sequential_callback.get_recent_events(5)
            for event in routing_events:
                yield event

            # =================================
            # 5. 워크플로우 타입 결정 및 계획 단계
            # =================================
            planning_start_time = kst_now
            workflow_type = self._determine_workflow_type(analysis)
            workflow_tracker["workflow_type"] = workflow_type

            await sequential_callback.set_planning_phase()

            if analysis.complexity == "complex" or analysis.estimated_steps > 2:
                plan_description = f"복잡한 작업으로 분석됨 - {analysis.estimated_steps}단계의 계층적 실행 계획을 수립합니다"
                workflow_tracker["execution_approach"] = "hierarchical_complex"
            else:
                plan_description = f"표준 작업으로 분석됨 - {len(selected_tools)}개 도구를 활용한 실행 계획을 수립합니다"
                workflow_tracker["execution_approach"] = "standard_reactive"

            await sequential_callback.start_planning(plan_description)

            # 계획 수립 시뮬레이션
            await asyncio.sleep(0.5)

            # 계획 상세 내용 생성
            if analysis.complexity == "complex":
                plan_details = await self._generate_complex_plan_details(
                    query, analysis, selected_tools
                )
            else:
                plan_details = await self._generate_standard_plan_details(
                    query, analysis, selected_tools
                )

            await sequential_callback.complete_planning(plan_details)

            # 계획 단계 추적
            workflow_tracker["steps"].append(
                {
                    "step_name": "execution_planning",
                    "start_time": planning_start_time,
                    "end_time": kst_now,
                    "duration": (kst_now - planning_start_time).total_seconds(),
                    "status": "completed",
                    "results": {
                        "workflow_type": workflow_type,
                        "execution_approach": workflow_tracker["execution_approach"],
                        "plan_complexity": analysis.complexity,
                        "plan_details_length": len(plan_details),
                    },
                }
            )

            # 계획 이벤트 스트리밍
            planning_events = await sequential_callback.get_recent_events(3)
            for event in planning_events:
                yield event

            # =================================
            # 6. 실행 단계
            # =================================
            execution_start_time = kst_now
            await sequential_callback.set_execution_phase()

            # 실행 방식 결정
            if analysis.complexity == "complex" or analysis.estimated_steps > 2:
                final_result = await self._execute_complex_workflow_sequential(
                    chat_id,
                    query,
                    analysis,
                    selected_tools,
                    sequential_callback,
                    relevant_memories,
                )
            else:
                final_result = await self._execute_standard_workflow_sequential(
                    chat_id,
                    query,
                    analysis,
                    selected_tools,
                    sequential_callback,
                    relevant_memories,
                )

            # 실행 단계 추적
            execution_duration = (kst_now - execution_start_time).total_seconds()
            workflow_tracker["steps"].append(
                {
                    "step_name": "workflow_execution",
                    "start_time": execution_start_time,
                    "end_time": kst_now,
                    "duration": execution_duration,
                    "status": "completed" if final_result else "failed",
                    "results": {
                        "execution_success": final_result is not None,
                        "result_content_length": (
                            len(final_result.get("content", "")) if final_result else 0
                        ),
                        "execution_type": workflow_tracker["execution_approach"],
                    },
                }
            )

            # 실행 중 이벤트 스트리밍
            execution_events = await sequential_callback.get_recent_events(20)
            for event in execution_events:
                yield event

            # =================================
            # 7. 품질 평가 및 결과 종합 단계
            # =================================
            synthesis_start_time = kst_now
            await sequential_callback.set_synthesis_phase()
            await sequential_callback.add_thinking(
                "모든 실행 결과를 종합하여 최종 응답을 생성합니다..."
            )

            # 품질 메트릭 계산
            if final_result:
                workflow_tracker["quality_metrics"] = self._calculate_quality_metrics(
                    query, final_result, workflow_tracker
                )
                workflow_tracker["success"] = True
            else:
                workflow_tracker["quality_metrics"] = {
                    "overall_score": 0,
                    "success": False,
                }
                workflow_tracker["success"] = False

            # 종합 단계 추적
            workflow_tracker["steps"].append(
                {
                    "step_name": "result_synthesis",
                    "start_time": synthesis_start_time,
                    "end_time": kst_now,
                    "duration": (kst_now - synthesis_start_time).total_seconds(),
                    "status": "completed",
                    "results": {
                        "quality_score": workflow_tracker["quality_metrics"].get(
                            "overall_score", 0
                        ),
                        "synthesis_success": True,
                    },
                }
            )

            # =================================
            # 8. 메모리 저장 (학습)
            # =================================
            memory_storage_start_time = kst_now
            if final_result and self.memory_manager and self.memory_manager.enabled:
                try:
                    await self.memory_manager.add_conversation_memory(
                        user_id=chat_id,
                        message=query,
                        response=final_result.get("content", ""),
                        metadata={
                            "query_type": analysis.query_type,
                            "tools_used": (
                                [t.name for t in selected_tools]
                                if selected_tools
                                else []
                            ),
                            "workflow_type": workflow_type,
                            "recommendation_used": recommendation_result is not None,
                            "memory_context_used": len(relevant_memories) > 0,
                            "execution_approach": workflow_tracker[
                                "execution_approach"
                            ],
                            "quality_score": workflow_tracker["quality_metrics"].get(
                                "overall_score", 0
                            ),
                            "execution_duration": execution_duration,
                            "success": True,
                        },
                    )

                    # 도구 사용 패턴도 저장
                    if selected_tools:
                        for tool in selected_tools:
                            await self.memory_manager.add_tool_usage_memory(
                                user_id=chat_id,
                                tool_name=tool.name,
                                query=query,
                                success=True,
                                result_summary=final_result.get("summary", "")[:200],
                            )

                    # 메모리 저장 추적
                    workflow_tracker["steps"].append(
                        {
                            "step_name": "memory_storage",
                            "start_time": memory_storage_start_time,
                            "end_time": kst_now,
                            "duration": (
                                kst_now - memory_storage_start_time
                            ).total_seconds(),
                            "status": "completed",
                            "results": {
                                "conversation_stored": True,
                                "tool_patterns_stored": len(selected_tools),
                                "memory_enhancement": True,
                            },
                        }
                    )

                    logger.info(f"💾 대화 및 도구 사용 패턴을 메모리에 저장했습니다")
                except Exception as e:
                    logger.warning(f"메모리 저장 실패: {e}")
                    workflow_tracker["steps"].append(
                        {
                            "step_name": "memory_storage",
                            "start_time": memory_storage_start_time,
                            "end_time": kst_now,
                            "status": "failed",
                            "error": str(e),
                        }
                    )

            # =================================
            # 9. 워크플로우 패턴 학습 저장
            # =================================
            learning_start_time = kst_now
            if workflow_tracker["success"] and hasattr(self, "workflow_memory_manager"):
                try:
                    await self._store_successful_workflow_pattern(
                        chat_id, workflow_tracker, final_result
                    )

                    workflow_tracker["steps"].append(
                        {
                            "step_name": "workflow_pattern_learning",
                            "start_time": learning_start_time,
                            "end_time": kst_now,
                            "duration": (kst_now - learning_start_time).total_seconds(),
                            "status": "completed",
                            "results": {
                                "pattern_stored": True,
                                "learning_enhanced": True,
                            },
                        }
                    )

                    logger.info(f"🧠 워크플로우 패턴을 학습 시스템에 저장했습니다")
                except Exception as e:
                    logger.warning(f"워크플로우 패턴 저장 실패: {e}")
                    workflow_tracker["steps"].append(
                        {
                            "step_name": "workflow_pattern_learning",
                            "start_time": learning_start_time,
                            "end_time": kst_now,
                            "status": "failed",
                            "error": str(e),
                        }
                    )

            # =================================
            # 10. 세션 통계 저장
            # =================================
            self.session_stats[chat_id] = {
                "query": query,
                "analysis": (
                    analysis.model_dump()
                    if hasattr(analysis, "model_dump")
                    else analysis.__dict__
                ),
                "selected_tools": (
                    [t.name for t in selected_tools] if selected_tools else []
                ),
                "workflow_type": workflow_type,
                "execution_approach": workflow_tracker["execution_approach"],
                "recommendation_used": recommendation_result is not None,
                "recommended_tools": (
                    [t.tool_name for t in recommendation_result.recommended_tools]
                    if recommendation_result
                    else []
                ),
                "confidence_score": (
                    recommendation_result.confidence_score
                    if recommendation_result
                    else 0.0
                ),
                "memory_context_used": len(relevant_memories) > 0,
                "quality_metrics": workflow_tracker["quality_metrics"],
                "execution_duration": execution_duration,
                "total_steps": len(workflow_tracker["steps"]),
                "success": final_result is not None,
                "timestamp": kst_now.isoformat(),
            }

            # 종합 이벤트 스트리밍
            synthesis_events = await sequential_callback.get_recent_events(2)
            for event in synthesis_events:
                yield event

            # =================================
            # 11. 최종 결과 전송
            # =================================
            if final_result and final_result.get("content"):
                canvas_event = {
                    "type": "CANVAS",
                    "content": final_result["content"],
                    "description": final_result["description"],
                    "key": "final_result",
                    "id": chat_id,
                    "created_at": kst_now.isoformat() + "Z",
                }
                yield canvas_event

            # =================================
            # 12. 워크플로우 종료
            # =================================
            success = final_result is not None
            tools_used = len(selected_tools) if selected_tools else 0
            memory_used = len(relevant_memories) > 0
            recommendation_used = recommendation_result is not None
            total_execution_time = (
                kst_now - workflow_tracker["start_time"]
            ).total_seconds()

            end_summary = (
                f"성공적으로 처리됨 ({tools_used}개 도구 사용)"
                if success
                else "처리 중 오류 발생"
            )
            if memory_used:
                end_summary += f", {len(relevant_memories)}개 이전 대화 참조"
            if recommendation_used:
                end_summary += " (MCP 추천 시스템 활용)"
            end_summary += f", 총 실행시간: {total_execution_time:.2f}초"

            # 최종 워크플로우 추적 정보 업데이트
            workflow_tracker["end_time"] = kst_now
            workflow_tracker["total_duration"] = total_execution_time

            await sequential_callback.end_workflow(success, end_summary)

            # 종료 이벤트 스트리밍
            end_events = await sequential_callback.get_recent_events(1)
            for event in end_events:
                yield event

        except Exception as e:
            logger.error(f"순차적 라우팅 기반 쿼리 처리 오류: {e}")

            # 오류 시 워크플로우 추적 업데이트
            workflow_tracker["success"] = False
            workflow_tracker["error_details"] = {
                "error_type": type(e).__name__,
                "error_message": str(e),
                "error_time": kst_now.isoformat(),
            }
            workflow_tracker["end_time"] = kst_now
            workflow_tracker["total_duration"] = (
                kst_now - workflow_tracker["start_time"]
            ).total_seconds()

            try:
                # 실패한 워크플로우도 학습을 위해 저장
                if hasattr(self, "workflow_memory_manager"):
                    await self._store_failed_workflow_pattern(
                        chat_id, workflow_tracker, str(e)
                    )

                await sequential_callback.end_workflow(
                    False, f"처리 중 오류 발생: {str(e)}"
                )

                error_events = await sequential_callback.get_recent_events(1)
                for event in error_events:
                    yield event

            except Exception as cleanup_error:
                logger.error(f"오류 처리 중 추가 오류: {cleanup_error}")

                # 기본 오류 이벤트
                error_event = {
                    "type": "ERROR",
                    "content": f"❌ 처리 중 오류 발생: {str(e)}",
                    "description": "시스템 오류",
                    "key": "routing_error",
                    "id": chat_id,
                    "created_at": kst_now.isoformat() + "Z",
                }
                yield error_event

    # =================================
    # 수정된 보조 함수들 (AsyncGenerator로 변경)
    # =================================

    async def _handle_system_info_query_sequential(
        self, chat_id: str, query: str, analysis, sequential_callback
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """시스템 정보 쿼리 순차적 처리"""
        try:
            await sequential_callback.set_execution_phase()

            # 시스템 정보 처리 단계
            await sequential_callback.start_step(
                "시스템 정보 수집", "요청된 시스템 정보를 수집하고 분석합니다"
            )

            # 실행 이벤트 스트리밍
            execution_events = await sequential_callback.get_recent_events(2)
            for event in execution_events:
                yield event

            # 시스템 정보 생성
            system_info_type = getattr(analysis, "system_info_type", "general")
            system_response = (
                await self.system_info_generator.generate_system_info_response(
                    system_info_type, query
                )
            )

            await sequential_callback.complete_step(True, "시스템 정보 수집 완료")

            # 결과 종합
            await sequential_callback.set_synthesis_phase()

            # 메모리 저장
            if self.memory_manager and self.memory_manager.enabled:
                try:
                    await self.memory_manager.add_conversation_memory(
                        user_id=chat_id,
                        message=query,
                        response=system_response["content"],
                        metadata={
                            "query_type": "system_info",
                            "info_type": system_info_type,
                            "tools_count": len(self.tools) if self.tools else 0,
                        },
                    )
                except Exception as e:
                    logger.warning(f"시스템 정보 메모리 저장 실패: {e}")

            # 단계 완료 이벤트 스트리밍
            completion_events = await sequential_callback.get_recent_events(2)
            for event in completion_events:
                yield event

            # 최종 결과
            canvas_event = {
                "type": "CANVAS",
                "content": system_response["content"],
                "description": system_response["description"],
                "key": "system_info_result",
                "id": chat_id,
                "created_at": kst_now.isoformat() + "Z",
            }
            yield canvas_event

            # 워크플로우 종료
            await sequential_callback.end_workflow(True, "시스템 정보 제공 완료")

            # 종료 이벤트 스트리밍
            final_events = await sequential_callback.get_recent_events(1)
            for event in final_events:
                yield event

        except Exception as e:
            logger.error(f"시스템 정보 처리 오류: {e}")
            await sequential_callback.end_workflow(
                False, f"시스템 정보 처리 실패: {str(e)}"
            )

            # 오류 이벤트 스트리밍
            error_events = await sequential_callback.get_recent_events(1)
            for event in error_events:
                yield event

    async def _handle_simple_chat_sequential(
        self, chat_id: str, query: str, analysis, sequential_callback, relevant_memories
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """단순 채팅 순차적 처리"""
        try:
            await sequential_callback.set_execution_phase()

            # 채팅 응답 생성 단계
            await sequential_callback.start_step(
                "채팅 응답 생성", "도구 사용 없이 LLM 지식만으로 응답을 생성합니다"
            )

            # 실행 이벤트 스트리밍
            execution_events = await sequential_callback.get_recent_events(2)
            for event in execution_events:
                yield event

            # 메모리 컨텍스트 포함 프롬프트 생성
            chat_prompt = self._create_enhanced_chat_prompt_with_memory(
                query, relevant_memories
            )

            # LLM 직접 호출
            response = await asyncio.get_event_loop().run_in_executor(
                self._executor,
                lambda: self.model.invoke([HumanMessage(content=chat_prompt)]),
            )

            content = self._extract_content(response.content)

            await sequential_callback.complete_step(True, "채팅 응답 생성 완료")

            # 결과 종합
            await sequential_callback.set_synthesis_phase()

            # 메모리 저장
            if self.memory_manager and self.memory_manager.enabled:
                try:
                    await self.memory_manager.add_conversation_memory(
                        user_id=chat_id,
                        message=query,
                        response=content,
                        metadata={
                            "query_type": "simple_chat",
                            "tools_used": [],
                            "memory_context_used": len(relevant_memories) > 0,
                        },
                    )
                except Exception as e:
                    logger.warning(f"단순 채팅 메모리 저장 실패: {e}")

            # 단계 완료 이벤트 스트리밍
            completion_events = await sequential_callback.get_recent_events(2)
            for event in completion_events:
                yield event

            # 최종 결과
            canvas_event = {
                "type": "CANVAS",
                "content": content,
                "description": "단순 대화 응답 (도구 사용 없음)",
                "key": "simple_chat_result",
                "id": chat_id,
                "created_at": kst_now.isoformat() + "Z",
            }
            yield canvas_event

            # 워크플로우 종료
            await sequential_callback.end_workflow(True, "단순 채팅 처리 완료")

            # 종료 이벤트 스트리밍
            final_events = await sequential_callback.get_recent_events(1)
            for event in final_events:
                yield event

        except Exception as e:
            logger.error(f"단순 채팅 처리 오류: {e}")
            await sequential_callback.end_workflow(
                False, f"단순 채팅 처리 실패: {str(e)}"
            )

            # 오류 이벤트 스트리밍
            error_events = await sequential_callback.get_recent_events(1)
            for event in error_events:
                yield event

    async def _execute_standard_workflow_sequential(
        self,
        chat_id: str,
        query: str,
        analysis,
        selected_tools: List,
        sequential_callback,
        relevant_memories: List[Dict],
    ) -> Dict[str, Any]:
        """표준 워크플로우 순차적 실행"""
        try:
            logger.info(f"표준 워크플로우 시작: {len(selected_tools)}개 도구 사용")

            if selected_tools:
                # 이전 대화 기록 로드
                conversation_history = await self._load_conversation_history(
                    chat_id, limit=8
                )

                # 메모리 컨텍스트를 포함한 향상된 쿼리 생성
                enhanced_query = self._enhance_query_with_memory(
                    query, analysis, selected_tools, relevant_memories
                )

                # 현재 사용자 메시지를 대화 기록에 추가
                conversation_history.append(HumanMessage(content=enhanced_query))

                # 대화 기록 정리
                cleaned_history = self._clean_conversation_history(conversation_history)

                logger.info(
                    f"대화 기록: 원본 {len(conversation_history)}개 -> 정리 후 {len(cleaned_history)}개"
                )

                # Agent 실행 단계
                await sequential_callback.start_step(
                    f"도구 기반 작업 실행",
                    f"선택된 {len(selected_tools)}개 도구로 사용자 요청을 처리합니다",
                    [
                        tool.name for tool in selected_tools[:3]
                    ],  # 하위 단계로 도구명 표시
                )

                # Agent 생성 및 실행
                if MCP_AVAILABLE:
                    agent = create_react_agent(
                        self.model, selected_tools, checkpointer=self.memory
                    )
                else:
                    agent = self.agent

                config = {
                    "configurable": {"thread_id": chat_id},
                    "callbacks": [],  # 순차적 콜백은 별도 관리
                }

                logger.info(
                    f"Agent 실행 시작 (메모리 활용): {len(cleaned_history)}개 메시지 포함"
                )

                result = await asyncio.wait_for(
                    agent.ainvoke({"messages": cleaned_history}, config=config),
                    timeout=180,
                )

                if result and "messages" in result and result["messages"]:
                    last_message = result["messages"][-1]
                    content = self._extract_content(last_message.content)

                    await sequential_callback.complete_step(
                        True, f"도구 실행 성공: {len(content)}자 응답 생성"
                    )

                    logger.info(f"표준 워크플로우 성공: {len(content)}자 응답 생성")

                    return {
                        "content": content,
                        "description": f"메모리 컨텍스트를 활용하여 {len(selected_tools)}개 도구로 처리 완료",
                        "summary": f"성공적으로 처리됨 ({len(selected_tools)}개 도구, {len(relevant_memories)}개 메모리 활용)",
                    }
                else:
                    await sequential_callback.complete_step(
                        False, "Agent 실행 결과 없음", "빈 응답 수신"
                    )
                    return await self._execute_fallback_sequential(
                        query, sequential_callback
                    )

            return await self._execute_fallback_sequential(query, sequential_callback)

        except asyncio.TimeoutError:
            logger.error("표준 워크플로우 타임아웃")
            await sequential_callback.complete_step(
                False, "실행 타임아웃", "180초 제한 시간 초과"
            )
            return await self._execute_fallback_sequential(query, sequential_callback)
        except Exception as e:
            logger.error(f"표준 워크플로우 실행 오류: {e}")
            await sequential_callback.complete_step(False, "실행 오류", str(e))
            return await self._execute_fallback_sequential(query, sequential_callback)

    async def _execute_complex_workflow_sequential(
        self,
        chat_id: str,
        query: str,
        analysis,
        selected_tools: List,
        sequential_callback,
        relevant_memories: List[Dict],
    ) -> Dict[str, Any]:
        """복잡한 워크플로우 순차적 실행"""
        try:
            logger.info(
                f"복잡한 워크플로우 시작: {analysis.estimated_steps}단계, {len(relevant_memories)}개 메모리"
            )

            if selected_tools:
                # 이전 대화 기록 로드 (복잡한 작업이므로 더 많은 기록)
                conversation_history = await self._load_conversation_history(
                    chat_id, limit=12
                )

                # 메모리를 활용한 복잡한 쿼리 생성
                workflow_steps = self._generate_workflow_steps(analysis, query)
                enhanced_query = self._enhance_complex_query_with_memory(
                    query, analysis, selected_tools, relevant_memories, workflow_steps
                )

                # 현재 메시지 추가 및 기록 정리
                conversation_history.append(HumanMessage(content=enhanced_query))
                cleaned_history = self._clean_conversation_history(conversation_history)

                # 복잡한 작업 실행 단계
                await sequential_callback.start_step(
                    f"복잡한 멀티스텝 작업 실행",
                    f"계층적 처리: {analysis.estimated_steps}단계 예정, {len(selected_tools)}개 도구 활용",
                    [
                        f"단계 {i+1}: {step}"
                        for i, step in enumerate(workflow_steps[:3])
                    ],
                )

                # Agent 실행
                if MCP_AVAILABLE:
                    agent = create_react_agent(
                        self.model, selected_tools, checkpointer=self.memory
                    )
                else:
                    agent = self.agent

                config = {"configurable": {"thread_id": chat_id}, "callbacks": []}

                result = await asyncio.wait_for(
                    agent.ainvoke({"messages": cleaned_history}, config=config),
                    timeout=300,
                )

                if result and "messages" in result and result["messages"]:
                    last_message = result["messages"][-1]
                    content = self._extract_content(last_message.content)

                    await sequential_callback.complete_step(
                        True, f"복잡한 워크플로우 완료: {len(workflow_steps)}단계 실행"
                    )

                    return {
                        "content": content,
                        "description": f"메모리 컨텍스트 활용한 복잡한 워크플로우 완료 ({len(workflow_steps)}단계)",
                        "summary": f"멀티-스텝 개인화 처리 완료: {' → '.join(workflow_steps)}, {len(relevant_memories)}개 메모리 활용",
                    }
                else:
                    await sequential_callback.complete_step(
                        False, "복잡한 워크플로우 실행 결과 없음", "빈 응답 수신"
                    )
                    # 표준 처리로 폴백
                    logger.warning("복잡한 워크플로우를 표준 처리로 폴백")
                    return await self._execute_standard_workflow_sequential(
                        chat_id,
                        query,
                        analysis,
                        selected_tools,
                        sequential_callback,
                        relevant_memories,
                    )

            return await self._execute_fallback_sequential(query, sequential_callback)

        except Exception as e:
            logger.error(f"복잡한 워크플로우 실행 오류: {e}")
            await sequential_callback.complete_step(
                False, "복잡한 워크플로우 실행 실패", str(e)
            )
            return await self._execute_fallback_sequential(query, sequential_callback)

    async def _execute_fallback_sequential(
        self, query: str, sequential_callback
    ) -> Dict[str, Any]:
        """폴백 실행 (순차적)"""
        try:
            await sequential_callback.start_step(
                "폴백 모드 실행", "MCP 도구 없이 기본 모델로 응답을 생성합니다"
            )

            response = await asyncio.get_event_loop().run_in_executor(
                self._executor, lambda: self.model.invoke([HumanMessage(content=query)])
            )

            content = self._extract_content(response.content)

            await sequential_callback.complete_step(True, "폴백 모드 응답 생성 완료")

            return {
                "content": content,
                "description": "폴백 모드 응답",
                "summary": "기본 모델로 처리 완료",
            }

        except Exception as e:
            logger.error(f"폴백 실행 오류: {e}")
            await sequential_callback.complete_step(False, "폴백 실행 실패", str(e))
            return {
                "content": "죄송합니다. 현재 응답을 생성할 수 없습니다.",
                "description": "폴백 실행 실패",
                "summary": "처리 실패",
            }

    async def _generate_complex_plan_details(
        self, query: str, analysis, selected_tools: List
    ) -> str:
        """복잡한 계획 상세 내용 생성"""
        try:
            plan_parts = [
                f"복잡한 작업 분석: {analysis.estimated_steps}단계 처리 예정",
                f"선택된 도구: {', '.join([tool.name for tool in selected_tools[:5]])}",
            ]

            # 쿼리 패턴 분석
            query_lower = query.lower()

            if "검색" in query_lower and "저장" in query_lower:
                plan_parts.append(
                    "실행 계획: 정보 검색 → 데이터 수집 → 분석 → 파일 저장"
                )
            elif "naver" in query_lower and "usb" in query_lower:
                plan_parts.append(
                    "실행 계획: 네이버 접속 → USB 케이블 검색 → 상품 정보 수집 → 추천 목록 작성"
                )
            elif "wiki" in query_lower:
                plan_parts.append(
                    "실행 계획: 위키피디아 접속 → 정보 검색 → 내용 추출 → 정리"
                )
            else:
                plan_parts.append(
                    "실행 계획: 단계별 분석 → 도구 실행 → 결과 통합 → 최종 정리"
                )

            if len(selected_tools) > 3:
                plan_parts.append(
                    f"도구 우선순위: {' → '.join([tool.name for tool in selected_tools[:3]])} 등"
                )

            return " | ".join(plan_parts)

        except Exception as e:
            logger.error(f"복잡한 계획 생성 오류: {e}")
            return f"복잡한 작업 처리 계획 (도구: {len(selected_tools)}개)"

    async def _generate_standard_plan_details(
        self, query: str, analysis, selected_tools: List
    ) -> str:
        """표준 계획 상세 내용 생성"""
        try:
            plan_parts = [
                f"표준 작업 분석: {analysis.query_type} 유형",
                f"예상 처리 단계: {analysis.estimated_steps}단계",
            ]

            if selected_tools:
                tool_categories = set()
                for tool in selected_tools:
                    tool_name_lower = tool.name.lower()
                    if (
                        "browser" in tool_name_lower
                        or "hyperbrowser" in tool_name_lower
                    ):
                        tool_categories.add("웹 브라우징")
                    elif "search" in tool_name_lower or "perplexity" in tool_name_lower:
                        tool_categories.add("검색")
                    elif "weather" in tool_name_lower:
                        tool_categories.add("날씨")
                    elif "command" in tool_name_lower or "desktop" in tool_name_lower:
                        tool_categories.add("시스템")
                    else:
                        tool_categories.add("범용")

                plan_parts.append(
                    f"도구 카테고리: {', '.join(sorted(tool_categories))}"
                )
                plan_parts.append(
                    f"실행 순서: {' → '.join([tool.name for tool in selected_tools[:3]])}"
                )
            else:
                plan_parts.append("기본 LLM 모델로 직접 처리")

            return " | ".join(plan_parts)

        except Exception as e:
            logger.error(f"표준 계획 생성 오류: {e}")
            return f"표준 작업 처리 계획 (도구: {len(selected_tools)}개)"

    def _create_enhanced_chat_prompt_with_memory(
        self, query: str, relevant_memories: List[Dict]
    ) -> str:
        """메모리를 포함한 향상된 채팅 프롬프트 생성"""
        base_prompt = f"""당신은 사용자와의 이전 대화를 기억하고 연속성을 유지하는 AI 어시스턴트입니다.

    현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}
    사용자 질문: {query}"""

        # 메모리 컨텍스트 추가
        if relevant_memories:
            memory_parts = ["### 📚 이전 대화 내용:"]
            for i, memory in enumerate(relevant_memories[:3], 1):
                try:
                    memory_data = memory.get("memory", {})
                    if isinstance(memory_data, dict):
                        content = memory_data.get("content", "")
                    else:
                        content = str(memory_data)

                    if content:
                        timestamp = memory.get("metadata", {}).get("timestamp", "")
                        if timestamp:
                            try:
                                dt = datetime.fromisoformat(
                                    timestamp.replace("Z", "+00:00")
                                )
                                time_str = dt.strftime("%m/%d %H:%M")
                            except:
                                time_str = timestamp[:16]
                            content_preview = f"[{time_str}] {content[:100]}"
                        else:
                            content_preview = content[:100]

                        if len(content) > 100:
                            content_preview += "..."

                        memory_parts.append(f"{i}. {content_preview}")

                except Exception as e:
                    logger.warning(f"메모리 항목 처리 오류: {e}")
                    continue

            if len(memory_parts) > 1:
                base_prompt = f"""{base_prompt}

    {chr(10).join(memory_parts)}

    ### 💡 응답 지침:
    1. 이전 대화 내용을 참고하여 연속성 있는 대화를 진행하세요
    2. 사용자의 질문에 친근하고 도움이 되는 방식으로 답변하세요
    3. 필요한 경우 추가 질문을 통해 더 도움을 드릴 수 있음을 알려주세요
    """

        return base_prompt

    # =================================
    # 추가로 필요한 EnhancedMCPReActAgent 메서드들
    # =================================

    def _determine_workflow_type(self, analysis: QueryAnalysis) -> str:
        """워크플로우 타입 결정 (기존 메서드 유지)"""
        if analysis.complexity == "complex" or analysis.estimated_steps > 3:
            return "complex"
        elif analysis.complexity == "medium" or analysis.estimated_steps > 1:
            return "standard"
        else:
            return "simple"

    def _generate_workflow_steps(
        self, analysis: QueryAnalysis, query: str
    ) -> List[str]:
        """워크플로우 단계 생성 (기존 메서드 유지)"""
        steps = []
        query_lower = query.lower()

        if "naver" in query_lower and "usb" in query_lower:
            steps = [
                "네이버 쇼핑 접속",
                "USB-C 케이블 검색",
                "상품 정보 수집",
                "추천 목록 작성",
            ]
        elif "wiki" in query_lower:
            steps = ["위키피디아 접속", "정보 검색", "내용 추출", "정리"]
        elif analysis.query_type == "browser":
            steps = ["웹사이트 접속", "검색 수행", "데이터 수집", "결과 정리"]
        elif analysis.query_type == "search":
            steps = ["키워드 분석", "정보 검색", "결과 수집", "정보 종합"]
        else:
            steps = ["요청 분석", "정보 수집", "데이터 처리", "결과 생성"]

        if "저장" in query_lower or ".md" in query_lower:
            steps.append("파일 저장")

        return steps

    def _enhance_complex_query_with_memory(
        self,
        query: str,
        analysis: QueryAnalysis,
        selected_tools: List,
        relevant_memories: List[Dict],
        workflow_steps: List[str],
    ) -> str:
        """복잡한 워크플로우를 위한 메모리 활용 쿼리 개선 (기존 메서드 유지)"""

        # 기본 메모리 컨텍스트 생성
        base_enhanced = self._enhance_query_with_memory(
            query, analysis, selected_tools, relevant_memories
        )

        # 복잡한 워크플로우 특화 지침 추가
        complex_additions = f"""

    ### 🔄 다단계 실행 계획:
    다음 단계를 순서대로 수행해주세요:
    {chr(10).join([f"{i+1}. {step}" for i, step in enumerate(workflow_steps)])}

    ### 📊 복잡한 작업 수행 지침:
    1. **단계별 진행**: 각 단계를 명확히 구분하여 차근차근 진행하세요
    2. **중간 결과 확인**: 각 단계의 결과를 검증하고 다음 단계에 반영하세요
    3. **오류 처리**: 문제 발생 시 대안 방법을 시도하세요
    4. **결과 종합**: 모든 단계의 결과를 통합하여 최종 답변을 구성하세요
    5. **품질 확보**: 정확성과 완성도를 높이기 위해 여러 도구를 활용하세요

    특히 웹사이트 검색이나 브라우징이 필요한 경우 hyperbrowser 도구를 적극적으로 활용하세요."""

        return base_enhanced + complex_additions

    def _safe_get_tool_names(self, tools: List) -> List[str]:
        """안전하게 도구명 목록 반환"""
        try:
            return [tool.name for tool in tools] if tools else []
        except Exception as e:
            logger.warning(f"도구명 추출 오류: {e}")
            return []

    async def _safe_get_mcp_recommendation(self, query: str) -> Optional:
        """안전하게 MCP 추천 수행"""
        try:
            if self.mcp_recommendation_system:
                return await self.mcp_recommendation_system.recommend_tools(
                    query, max_servers=3, max_tools=10
                )
        except Exception as e:
            logger.warning(f"MCP 추천 시스템 오류: {e}")
        return None

    async def _safe_route_tools(
        self, analysis, available_tools: List
    ) -> Tuple[List, str]:
        """안전하게 도구 라우팅 수행"""
        try:
            if self.server_router and available_tools:
                return await self.server_router.route_query(analysis, available_tools)
            else:
                return available_tools, "라우터 없음 - 모든 도구 사용"
        except Exception as e:
            logger.warning(f"도구 라우팅 오류: {e}")
            return available_tools, f"라우팅 오류 - 폴백 처리: {str(e)}"

    def _initialize_session_variables(self, chat_id: str) -> Dict[str, Any]:
        """세션 변수 초기화"""
        return {
            "recommendation_result": None,
            "selected_tools": [],
            "relevant_memories": [],
            "workflow_type": "simple",
            "final_result": None,
            "analysis": None,
        }

    def _create_enhanced_chat_prompt(self, query: str) -> str:
        """향상된 채팅용 프롬프트 생성"""
        available_tools_info = []
        if self.tools:
            featured_tools = {
                "browser_use_agent": "🌐 웹 브라우징 및 검색",
                "search": "🔍 검색",
                "weather": "🌤️ 날씨 정보",
                "command": "💻 시스템 명령 실행",
                "file": "📄 파일 읽기/쓰기",
            }

            for tool in self.tools:
                tool_name_lower = tool.name.lower()
                for key, description in featured_tools.items():
                    if key in tool_name_lower:
                        available_tools_info.append(f"• {description}")
                        break

            other_tools_count = len(self.tools) - len(available_tools_info)
            if other_tools_count > 0:
                available_tools_info.append(f"• 기타 {other_tools_count}개의 전문 도구")

        tools_text = (
            "\n".join(available_tools_info)
            if available_tools_info
            else "현재 사용 가능한 도구를 로딩 중입니다."
        )

        recommendation_status = (
            "🎯 스마트 추천 시스템 활성화"
            if self.mcp_recommendation_system
            else "📋 기본 도구 라우팅"
        )

        return f"""안녕하세요! 저는 다양한 도구를 활용하여 도움을 드리는 AI 어시스턴트입니다.

현재 사용 가능한 주요 기능들:
{tools_text}

{recommendation_status}

다음과 같은 작업들을 도와드릴 수 있습니다:
- 웹사이트 검색 및 정보 수집 (예: "naver.com에서 맛집 검색해줘")
- 최신 뉴스나 정보 검색 (예: "최신 AI 뉴스 알려줘")
- 날씨 정보 조회 (예: "오늘 날씨 어때?")
- 파일 관리 및 검색 (예: "특정 파일 찾아줘")
- 시스템 명령 실행 및 관리
- 데이터 분석 및 보고서 작성

사용자 질문: {query}

친근하고 도움이 되는 방식으로 응답해주세요. 구체적으로 어떤 도움이 필요한지 물어보거나, 간단한 안부 인사라면 자연스럽게 대화를 이어가세요.

현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}"""

    def _clean_conversation_history(
        self, messages: List[BaseMessage]
    ) -> List[BaseMessage]:
        """도구 호출이 완료되지 않은 메시지 정리"""
        try:
            cleaned_messages = []
            pending_tool_calls = {}

            for message in messages:
                if isinstance(message, AIMessage):
                    # tool_calls 속성 확인
                    tool_calls = getattr(message, "tool_calls", None) or []

                    if tool_calls:
                        # 도구 호출이 있는 AI 메시지
                        for tool_call in tool_calls:
                            call_id = (
                                tool_call.get("id")
                                if isinstance(tool_call, dict)
                                else getattr(tool_call, "id", None)
                            )
                            if call_id:
                                pending_tool_calls[call_id] = tool_call
                        cleaned_messages.append(message)
                    else:
                        # 일반 AI 메시지
                        cleaned_messages.append(message)

                elif isinstance(message, ToolMessage):
                    # 도구 실행 결과 메시지
                    tool_call_id = getattr(message, "tool_call_id", None)
                    if tool_call_id and tool_call_id in pending_tool_calls:
                        del pending_tool_calls[tool_call_id]
                    cleaned_messages.append(message)
                else:
                    # 기타 메시지 (HumanMessage 등)
                    cleaned_messages.append(message)

            # 완료되지 않은 도구 호출이 있는 AI 메시지 제거
            if pending_tool_calls:
                logger.warning(
                    f"미완료 도구 호출 {len(pending_tool_calls)}개 발견, 정리 중..."
                )
                filtered_messages = []

                for message in reversed(cleaned_messages):
                    if isinstance(message, AIMessage):
                        tool_calls = getattr(message, "tool_calls", None) or []
                        if any(
                            tc.get("id") in pending_tool_calls
                            for tc in tool_calls
                            if isinstance(tc, dict)
                        ):
                            logger.info(
                                f"미완료 도구 호출 메시지 제거: {[tc.get('name', 'unknown') for tc in tool_calls if isinstance(tc, dict)]}"
                            )
                            continue  # 미완료 도구 호출 메시지 제거
                    filtered_messages.append(message)

                cleaned_messages = list(reversed(filtered_messages))
                logger.info(
                    f"대화 기록 정리 완료: {len(cleaned_messages)}개 메시지 유지"
                )

            return cleaned_messages

        except Exception as e:
            logger.error(f"대화 기록 정리 중 오류: {e}")
            # 오류 발생 시 마지막 사용자 메시지만 유지
            user_messages = [msg for msg in messages if isinstance(msg, HumanMessage)]
            return user_messages[-1:] if user_messages else []

    async def _load_conversation_history(
        self, chat_id: str, limit: int = 10
    ) -> List[BaseMessage]:
        """대화 기록을 LangGraph 메시지 형식으로 로드"""
        conversation_history = []

        if not self.memory_manager or not self.memory_manager.enabled:
            return conversation_history

        try:
            # 최근 대화 기록 로드
            recent_conversations = await self.memory_manager.get_conversation_history(
                user_id=chat_id, limit=limit
            )

            if not recent_conversations:
                logger.info(f"사용자 {chat_id}의 이전 대화 기록 없음")
                return conversation_history

            # 시간순 정렬 (오래된 것부터)
            sorted_conversations = sorted(
                recent_conversations,
                key=lambda x: x.get("metadata", {}).get("timestamp", ""),
                reverse=False,
            )

            # LangGraph 메시지 형식으로 변환
            for conv in sorted_conversations:
                try:
                    memory_content = conv.get("memory", {})
                    if isinstance(memory_content, dict):
                        content = memory_content.get("content", "")
                    else:
                        content = str(memory_content)

                    if not content:
                        continue

                    # "User: ... Assistant: ..." 형식 파싱
                    if "User:" in content and "Assistant:" in content:
                        parts = content.split("Assistant:", 1)
                        if len(parts) == 2:
                            user_msg = parts[0].replace("User:", "").strip()
                            ai_msg = parts[1].strip()

                            if user_msg and ai_msg:
                                conversation_history.extend(
                                    [
                                        HumanMessage(content=user_msg),
                                        AIMessage(content=ai_msg),
                                    ]
                                )

                except Exception as e:
                    logger.warning(f"대화 기록 파싱 오류: {e}")
                    continue

            logger.info(
                f"대화 기록 로드 완료: {chat_id} - {len(conversation_history)}개 메시지"
            )
            return conversation_history[-20:]  # 최근 20개 메시지만 유지

        except Exception as e:
            logger.error(f"대화 기록 로드 실패: {e}")
            return []

    async def _save_conversation_to_memory(
        self, chat_id: str, user_message: str, ai_response: str, metadata: Dict = None
    ):
        """대화를 메모리에 저장 (강화된 버전)"""
        if not self.memory_manager or not self.memory_manager.enabled:
            return None

        try:
            # 상세한 메타데이터 구성
            enhanced_metadata = {
                "conversation_id": chat_id,
                "timestamp": kst_now.isoformat(),
                "message_type": "conversation",
                "user_message_length": len(user_message),
                "ai_response_length": len(ai_response),
                "session_id": f"session_{chat_id}_{int(kst_now.timestamp())}",
            }

            if metadata:
                enhanced_metadata.update(metadata)

            # 메모리 저장
            memory_id = await self.memory_manager.add_conversation_memory(
                user_id=chat_id,
                message=user_message,
                response=ai_response,
                metadata=enhanced_metadata,
            )

            if memory_id:
                logger.info(f"💾 대화 저장 성공: {chat_id} -> {memory_id}")
                return memory_id
            else:
                logger.warning(f"💾 대화 저장 실패: {chat_id}")
                return None

        except Exception as e:
            logger.error(f"대화 메모리 저장 오류: {e}")
            return None

    def get_scenario_log(self, chat_id: str) -> Optional[Dict]:
        """시나리오 로그 조회"""
        return self.scenario_logger.get_scenario_json_schema(chat_id)

    def setup_fallback_tools(self):
        """기본 도구 설정"""
        from langchain_core.tools import tool

        logger.info("🔧 기본 fallback 도구 설정 중...")

        @tool
        def enhanced_search_tool(query: str) -> str:
            """향상된 검색 도구 - 웹 검색 시뮬레이션"""
            logger.info(f"🔍 기본 검색 도구 실행: {query}")
            return f"""검색 결과: '{query}'

📊 기본 검색 도구로 처리된 결과:
- 키워드: {query}
- 처리 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}
- 상태: 시뮬레이션 모드

💡 더 정확한 결과를 위해서는 MCP 서버 설정을 완료해주세요."""

        @tool
        def system_info_tool(request: str = "시스템 정보") -> str:
            """시스템 정보 및 현재 상태 조회"""
            logger.info(f"💻 시스템 정보 도구 실행: {request}")
            return f"""시스템 정보:
🕐 현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}
🖥️ 시스템 상태: 정상 동작
🔧 모드: Fallback (기본 도구)
📡 MCP 연결: 대기 중
🎯 추천 시스템: {'활성화' if self.mcp_recommendation_system else '비활성화'}

요청사항: {request}"""

        @tool
        def web_browser_tool(url: str) -> str:
            """기본 웹 브라우저 도구 - 웹사이트 방문 시뮬레이션"""
            logger.info(f"🌐 기본 브라우저 도구 실행: {url}")
            return f"""웹사이트 방문 시뮬레이션:
🔗 URL: {url}
📅 방문 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}
📊 상태: 시뮬레이션 모드

⚠️ 실제 웹사이트 방문이 아닌 시뮬레이션입니다."""

        @tool
        def weather_tool(location: str = "서울") -> str:
            """기본 날씨 정보 도구"""
            logger.info(f"🌤️ 기본 날씨 도구 실행: {location}")
            return f"""날씨 정보 (시뮬레이션):
📍 위치: {location}
🌡️ 온도: 시뮬레이션 데이터
☁️ 날씨: 기본 정보 제공 모드
📅 조회 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}"""

        self.tools = [
            enhanced_search_tool,
            system_info_tool,
            web_browser_tool,
            weather_tool,
        ]
        logger.info("기본 도구 설정 완료")

    def create_react_agent(self):
        """ReAct Agent 생성"""
        if not self.model or not self.tools:
            raise ValueError("모델 또는 도구가 설정되지 않았습니다.")

        try:
            if MCP_AVAILABLE:
                self.agent = create_react_agent(
                    self.model, self.tools, checkpointer=self.memory
                )
                logger.info("✅ Enhanced ReAct Agent 생성 성공")
            else:
                self._create_simple_fallback_agent()
                logger.info("✅ 폴백 Agent 생성 성공")

        except Exception as e:
            logger.error(f"❌ Agent 생성 실패: {e}")
            self._create_simple_fallback_agent()

    def _create_simple_fallback_agent(self):
        """간단한 폴백 Agent 생성"""

        class SimpleFallbackAgent:
            def __init__(self, model, tools):
                self.model = model
                self.tools = {tool.name: tool for tool in tools}

            async def ainvoke(self, input_data, config=None):
                try:
                    messages = input_data.get("messages", [])
                    if not messages:
                        return {"messages": [AIMessage(content="입력이 없습니다.")]}

                    user_message = messages[-1].content
                    response = self.model.invoke([HumanMessage(content=user_message)])

                    return {
                        "messages": messages + [AIMessage(content=response.content)]
                    }
                except Exception as e:
                    return {"messages": [AIMessage(content=f"오류: {str(e)}")]}

        self.agent = SimpleFallbackAgent(self.model, self.tools)

    def _determine_workflow_type(self, analysis: QueryAnalysis) -> str:
        """워크플로우 타입 결정"""
        if analysis.complexity == "complex" or analysis.estimated_steps > 3:
            return "complex"
        elif analysis.complexity == "medium" or analysis.estimated_steps > 1:
            return "standard"
        else:
            return "simple"

    async def _execute_standard_workflow_with_memory(
        self,
        chat_id: str,
        query: str,
        analysis,
        selected_tools: List,
        callback,
        relevant_memories: List[Dict],
    ) -> Dict[str, Any]:
        """메모리 컨텍스트를 활용한 표준 워크플로우 실행 (개선된 버전)"""
        try:
            logger.info(
                f"메모리 활용 표준 워크플로우 시작: {len(selected_tools)}개 도구, {len(relevant_memories)}개 메모리"
            )

            if callback:
                callback._add_event_to_queue(
                    MessageType.PLAN_START,
                    f"🧠 실행 계획 수립 중... (메모리 컨텍스트 {len(relevant_memories)}개 활용)",
                    f"선택된 {len(selected_tools)}개 도구로 개인화된 처리 계획",
                    "memory_enhanced_plan",
                )
                plan_started = True

            if selected_tools:
                # 1. 이전 대화 기록 로드
                conversation_history = await self._load_conversation_history(
                    chat_id, limit=8
                )

                # 2. 메모리 컨텍스트를 포함한 향상된 쿼리 생성
                enhanced_query = self._enhance_query_with_memory(
                    query, analysis, selected_tools, relevant_memories
                )

                # 3. 현재 사용자 메시지를 대화 기록에 추가
                conversation_history.append(HumanMessage(content=enhanced_query))

                # 4. 대화 기록 정리 (미완료 도구 호출 제거)
                cleaned_history = self._clean_conversation_history(conversation_history)

                logger.info(
                    f"대화 기록: 원본 {len(conversation_history)}개 -> 정리 후 {len(cleaned_history)}개"
                )

                # ✅ PLAN_COMPLETE 이벤트 발생 (Agent 실행 전)
                if callback and plan_started:
                    callback._add_event_to_queue(
                        MessageType.PLAN_COMPLETE,
                        "📋 실행 계획 수립 완료",
                        f"메모리 컨텍스트 {len(relevant_memories)}개와 {len(selected_tools)}개 도구를 활용한 실행 계획 완료",
                        "memory_enhanced_plan_complete",
                    )

                # 5. Agent 생성 및 실행
                if MCP_AVAILABLE:
                    agent = create_react_agent(
                        self.model, selected_tools, checkpointer=self.memory
                    )
                else:
                    agent = self.agent

                config = {
                    "configurable": {"thread_id": chat_id},
                    "callbacks": (
                        [callback] if callback else []
                    ),  # callback이 None이면 빈 리스트
                }

                logger.info(
                    f"Agent 실행 시작 (메모리 활용): {len(cleaned_history)}개 메시지 포함"
                )

                result = await asyncio.wait_for(
                    agent.ainvoke(
                        {"messages": cleaned_history},  # 정리된 전체 기록 전달
                        config=config,
                    ),
                    timeout=180,
                )

                if result and "messages" in result and result["messages"]:
                    last_message = result["messages"][-1]
                    content = self._extract_content(last_message.content)

                    # 6. 대화를 메모리에 저장
                    await self._save_conversation_to_memory(
                        chat_id=chat_id,
                        user_message=query,
                        ai_response=content,
                        metadata={
                            "tools_used": [t.name for t in selected_tools],
                            "workflow_type": "standard_with_memory",
                            "memory_context_count": len(relevant_memories),
                            "conversation_history_count": len(cleaned_history),
                        },
                    )

                    logger.info(
                        f"메모리 활용 표준 워크플로우 성공: {len(content)}자 응답 생성"
                    )

                    return {
                        "content": content,
                        "description": f"메모리 컨텍스트를 활용하여 {len(selected_tools)}개 도구로 개인화된 처리 완료",
                        "summary": f"성공적으로 처리됨 ({len(selected_tools)}개 도구, {len(relevant_memories)}개 메모리 활용)",
                    }
                else:
                    # ❌ 실패 시에도 PLAN_COMPLETE 처리 필요
                    if callback and plan_started:
                        callback._add_event_to_queue(
                            MessageType.ERROR,
                            "❌ 실행 계획 처리 실패",
                            "Agent 실행 결과가 없어 폴백 처리로 전환",
                            "plan_execution_failed",
                        )
                    return await self._execute_fallback(query, callback)

            # return await self._execute_fallback(query, callback)
            else:
                # ✅ 도구가 없는 경우에도 PLAN_COMPLETE 처리
                if callback and plan_started:
                    callback._add_event_to_queue(
                        MessageType.PLAN_COMPLETE,
                        "📋 실행 계획 완료 (폴백 모드)",
                        "도구 없이 기본 LLM으로 처리 계획 완료",
                        "fallback_plan_complete",
                    )
                return await self._execute_fallback(query, callback)

        except asyncio.TimeoutError:
            logger.error("메모리 활용 표준 워크플로우 타임아웃")
            # ❌ 타임아웃 시에도 PLAN_COMPLETE 처리
            if callback and plan_started:
                callback._add_event_to_queue(
                    MessageType.ERROR,
                    "⏰ 실행 계획 처리 타임아웃",
                    "180초 제한 시간 초과로 폴백 처리로 전환",
                    "plan_execution_timeout",
                )
            return await self._execute_fallback(query, callback)
        except Exception as e:
            logger.error(f"메모리 활용 표준 워크플로우 실행 오류: {e}")
            # ❌ 예외 발생 시에도 PLAN_COMPLETE 또는 ERROR 처리
            if callback and plan_started:
                callback._add_event_to_queue(
                    MessageType.ERROR,
                    "❌ 실행 계획 처리 오류",
                    f"오류 발생으로 폴백 처리로 전환: {str(e)[:100]}",
                    "plan_execution_error",
                )
            # 상세한 오류 정보 로그
            import traceback

            logger.error(f"오류 상세: {traceback.format_exc()}")
            return await self._execute_fallback(query, callback)

    async def _execute_complex_workflow_with_memory(
        self,
        chat_id: str,
        query: str,
        analysis: QueryAnalysis,
        selected_tools: List,
        callback: EnhancedFrontendEventCallback,
        relevant_memories: List[Dict],
    ) -> Dict[str, Any]:
        """메모리 컨텍스트를 활용한 복잡한 워크플로우 실행 (개선된 버전)"""
        try:
            logger.info(
                f"메모리 활용 복잡한 워크플로우 시작: {analysis.estimated_steps}단계, {len(relevant_memories)}개 메모리"
            )

            plan_event = EventMessage(
                chat_id,
                MessageType.PLAN_START,
                f"🧠 복잡한 작업 계획 수립 중... (개인화 컨텍스트 활용)",
                f"멀티-스텝 워크플로우 설계: {analysis.estimated_steps}단계, {len(relevant_memories)}개 이전 대화 참조",
                "memory_complex_plan",
            )
            await self._send_event_to_callback(callback, plan_event)

            workflow_steps = self._generate_workflow_steps(analysis, query)

            if selected_tools:
                # 1. 이전 대화 기록 로드 (복잡한 작업이므로 더 많은 기록)
                conversation_history = await self._load_conversation_history(
                    chat_id, limit=12
                )

                # 2. 메모리를 활용한 복잡한 쿼리 생성
                enhanced_query = self._enhance_complex_query_with_memory(
                    query, analysis, selected_tools, relevant_memories, workflow_steps
                )

                # 3. 현재 메시지 추가 및 기록 정리
                conversation_history.append(HumanMessage(content=enhanced_query))
                cleaned_history = self._clean_conversation_history(conversation_history)

                # 4. Agent 실행
                if MCP_AVAILABLE:
                    agent = create_react_agent(
                        self.model, selected_tools, checkpointer=self.memory
                    )
                else:
                    agent = self.agent

                config = {
                    "configurable": {"thread_id": chat_id},
                    "callbacks": [callback],
                }

                result = await asyncio.wait_for(
                    agent.ainvoke({"messages": cleaned_history}, config=config),
                    timeout=300,
                )

                if result and "messages" in result and result["messages"]:
                    last_message = result["messages"][-1]
                    content = self._extract_content(last_message.content)

                    # 5. 메모리 저장
                    await self._save_conversation_to_memory(
                        chat_id=chat_id,
                        user_message=query,
                        ai_response=content,
                        metadata={
                            "tools_used": [t.name for t in selected_tools],
                            "workflow_type": "complex_with_memory",
                            "workflow_steps": len(workflow_steps),
                            "memory_context_count": len(relevant_memories),
                        },
                    )

                    return {
                        "content": content,
                        "description": f"메모리 컨텍스트 활용한 복잡한 워크플로우 완료 ({len(workflow_steps)}단계)",
                        "summary": f"멀티-스텝 개인화 처리 완료: {' → '.join(workflow_steps)}, {len(relevant_memories)}개 메모리 활용",
                    }

                logger.warning("복잡한 워크플로우를 표준 처리로 폴백")
                return await self._execute_standard_workflow_with_memory(
                    chat_id,
                    query,
                    analysis,
                    selected_tools,
                    callback,
                    relevant_memories,
                )

        except Exception as e:
            logger.error(f"메모리 활용 복잡한 워크플로우 실행 오류: {e}")
            return await self._execute_fallback(query, callback)

    def _enhance_query_with_memory(
        self,
        query: str,
        analysis: QueryAnalysis,
        selected_tools: List,
        relevant_memories: List[Dict],
    ) -> str:
        from datetime import datetime

        """메모리 정보를 활용한 쿼리 개선 (강화된 버전)"""
        # 메모리 컨텍스트 구성
        memory_context = ""
        user_preferences = []

        if relevant_memories:
            memory_parts = ["### 📚 이전 대화 내용:"]
            for i, memory in enumerate(relevant_memories[:5], 1):  # 5개로 늘림
                try:
                    memory_data = memory.get("memory", {})
                    if isinstance(memory_data, dict):
                        content = memory_data.get("content", "")
                    else:
                        content = str(memory_data)

                    if content:
                        # 타임스탬프 추가
                        timestamp = memory.get("metadata", {}).get("timestamp", "")
                        if timestamp:
                            try:
                                # ISO 형식 파싱 시도
                                from datetime import datetime

                                dt = datetime.fromisoformat(
                                    timestamp.replace("Z", "+00:00")
                                )
                                time_str = dt.strftime("%m/%d %H:%M")
                            except:
                                time_str = timestamp[:16]  # 앞 16자리만
                            content_preview = f"[{time_str}] {content[:150]}"
                        else:
                            content_preview = content[:150]

                        if len(content) > 150:
                            content_preview += "..."

                        memory_parts.append(f"{i}. {content_preview}")

                    # 선호도 정보 추출
                    metadata = memory.get("metadata", {})
                    if metadata.get("type") == "preference":
                        pref_content = memory.get("memory", {}).get("content", "")
                        if pref_content and pref_content not in user_preferences:
                            user_preferences.append(pref_content)

                except Exception as e:
                    logger.warning(f"메모리 항목 처리 오류: {e}")
                    continue

            if len(memory_parts) > 1:  # 헤더 외에 내용이 있는 경우만
                memory_context = "\n".join(memory_parts) + "\n\n"

        # 기본 프롬프트 구성
        base_prompt = f"""당신은 사용자와의 이전 대화를 기억하고 연속성을 유지하는 AI 어시스턴트입니다.

    {memory_context}"""

        if user_preferences:
            base_prompt += f"""### 🎯 사용자 선호도:
    {chr(10).join([f"- {pref[:100]}" for pref in user_preferences[:3]])}

    """

        base_prompt += f"""### 📋 현재 요청:
    {query}

    ### 🔧 사용 가능한 도구들 ({len(selected_tools)}개):
    {chr(10).join([f"- {tool.name}: {getattr(tool, 'description', 'No description')[:60]}..." for tool in selected_tools[:5]])}

    ### 💡 중요한 지침:
    1. **연속성 유지**: 이전 대화 내용을 적극적으로 참고하여 일관된 답변을 제공하세요
    2. **컨텍스트 인식**: 사용자가 "이전에", "방금 전에", "아까" 등을 언급하면 위의 대화 기록을 참조하세요
    3. **개인화**: 사용자의 특성과 선호도를 반영한 맞춤형 서비스를 제공하세요
    4. **자연스러운 대화**: 마치 계속 이어지는 대화처럼 자연스럽게 응답하세요
    5. **도구 활용**: 필요한 경우 적절한 도구를 선택하여 정확한 정보를 제공하세요

    현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}

    위의 이전 대화 맥락을 충분히 고려하여 사용자의 현재 요청을 처리해주세요."""

        return base_prompt

    def _enhance_complex_query_with_memory(
        self,
        query: str,
        analysis: QueryAnalysis,
        selected_tools: List,
        relevant_memories: List[Dict],
        workflow_steps: List[str],
    ) -> str:
        """복잡한 워크플로우를 위한 메모리 활용 쿼리 개선"""

        # 기본 메모리 컨텍스트 생성
        base_enhanced = self._enhance_query_with_memory(
            query, analysis, selected_tools, relevant_memories
        )

        # 복잡한 워크플로우 특화 지침 추가
        complex_additions = f"""

    ### 🔄 다단계 실행 계획:
    다음 단계를 순서대로 수행해주세요:
    {chr(10).join([f"{i+1}. {step}" for i, step in enumerate(workflow_steps)])}

    ### 📊 복잡한 작업 수행 지침:
    1. **단계별 진행**: 각 단계를 명확히 구분하여 차근차근 진행하세요
    2. **중간 결과 확인**: 각 단계의 결과를 검증하고 다음 단계에 반영하세요
    3. **오류 처리**: 문제 발생 시 대안 방법을 시도하세요
    4. **결과 종합**: 모든 단계의 결과를 통합하여 최종 답변을 구성하세요
    5. **품질 확보**: 정확성과 완성도를 높이기 위해 여러 도구를 활용하세요

    특히 웹사이트 검색이나 브라우징이 필요한 경우 hyperbrowser 도구를 적극적으로 활용하세요."""

        return base_enhanced + complex_additions

    async def _execute_simple_chat_workflow(
        self, chat_id: str, query: str, analysis: QueryAnalysis, callback
    ) -> Dict[str, Any]:
        """단순 채팅 전용 워크플로우 (도구 사용 없이)"""
        try:
            # PLAN_START 이벤트
            if callback:
                callback._add_event_to_queue(
                    MessageType.PLAN_START,
                    "💭 단순 대화로 분석되어 직접 응답을 생성합니다...",
                    "도구 사용 없이 LLM 지식만으로 처리",
                    "simple_chat_plan",
                )

            # 채팅용 프롬프트 생성
            chat_prompt = self._create_enhanced_chat_prompt(query)

            # LLM 직접 호출
            response = await asyncio.get_event_loop().run_in_executor(
                self._executor,
                lambda: self.model.invoke([HumanMessage(content=chat_prompt)]),
            )

            content = self._extract_content(response.content)

            # PLAN_COMPLETE 이벤트
            if callback:
                callback._add_event_to_queue(
                    MessageType.PLAN_COMPLETE,
                    "✅ 단순 대화 응답 준비 완료",
                    "도구 사용 없이 직접 LLM 응답 생성",
                    "simple_chat_complete",
                )

            return {
                "content": content,
                "description": "단순 대화 응답 (도구 사용 없음)",
                "summary": "직접 LLM 응답으로 처리 완료",
            }

        except Exception as e:
            logger.error(f"단순 채팅 워크플로우 오류: {e}")
            return {
                "content": "죄송합니다. 응답 생성 중 오류가 발생했습니다.",
                "description": "단순 채팅 처리 실패",
                "summary": "오류 발생",
            }

    async def _execute_standard_workflow(
        self,
        chat_id: str,
        query: str,
        analysis: QueryAnalysis,
        selected_tools: List,
        callback: EnhancedFrontendEventCallback,
    ):
        """표준 워크플로우 실행"""
        try:
            logger.info(f"표준 워크플로우 시작: {len(selected_tools)}개 도구 사용")

            if callback:
                callback._add_event_to_queue(
                    MessageType.PLAN_START,
                    "🧠 실행 계획 수립 중...",
                    f"선택된 {len(selected_tools)}개 도구로 표준 처리 계획",
                    "standard_plan",
                )

            if selected_tools:
                enhanced_query = self._enhance_query_for_tools(
                    query, analysis, selected_tools
                )

                if MCP_AVAILABLE:
                    agent = create_react_agent(
                        self.model, selected_tools, checkpointer=self.memory
                    )
                else:
                    agent = self.agent

                config = {
                    "configurable": {"thread_id": chat_id},
                    "callbacks": [callback],
                }

                logger.info(f"Agent 실행 시작: {enhanced_query[:100]}...")

                result = await asyncio.wait_for(
                    agent.ainvoke(
                        {"messages": [HumanMessage(content=enhanced_query)]},
                        config=config,
                    ),
                    timeout=180,
                )

                if result and "messages" in result and result["messages"]:
                    last_message = result["messages"][-1]
                    content = self._extract_content(last_message.content)

                    logger.info(f"표준 워크플로우 성공: {len(content)}자 응답 생성")

                    return {
                        "content": content,
                        "description": f"선택된 도구들로 표준 워크플로우 완료",
                        "summary": f"성공적으로 처리됨 ({len(selected_tools)}개 도구 사용)",
                    }

            return await self._execute_fallback(query, callback)

        except asyncio.TimeoutError:
            logger.error("표준 워크플로우 타임아웃")
            return await self._execute_fallback(query, callback)
        except Exception as e:
            logger.error(f"표준 워크플로우 실행 오류: {e}")
            return await self._execute_fallback(query, callback)

    def _enhance_query_for_tools(
        self, query: str, analysis: QueryAnalysis, selected_tools: List
    ) -> str:
        """도구에 맞춘 쿼리 개선 (더 상세한 계획 요청)"""
        if analysis.query_type == "chat":
            return self._create_chat_system_prompt(query)

        tool_names = [tool.name for tool in selected_tools]

        system_prompt = f"""당신은 도구를 적극적으로 사용하는 AI 어시스턴트입니다.

사용 가능한 도구들 ({len(selected_tools)}개):
{chr(10).join([f"- {tool.name}: {getattr(tool, 'description', 'No description')}" for tool in selected_tools])}

중요한 지침:
1. 작업을 시작하기 전에 단계별 실행 계획을 명확히 세우세요.
2. 각 단계에서 어떤 도구를 사용할지 구체적으로 명시하세요.
3. 웹사이트 검색이나 브라우징 요청 시 hyperbrowser 도구를 우선 사용하세요.
4. 도구 실행이 실패하면 다른 도구로 재시도하거나 대안을 찾으세요.
5. 사용자가 구체적인 웹사이트를 언급하면 반드시 해당 사이트를 방문하세요.

실행 계획 예시:
1. [도구명]을 사용하여 [구체적 작업]
2. [도구명]으로 [다음 단계 작업]
3. 결과를 [형식]으로 정리하여 제공

현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}

"""

        enhanced_parts = [system_prompt, f"사용자 요청: {query}"]

        if analysis.query_type == "browser":
            enhanced_parts.append(
                "\n중요: 웹사이트 검색이나 브라우징이 필요합니다. hyperbrowser 도구를 사용하여 해당 웹사이트를 직접 방문하고 검색하세요."
            )

        if "추천" in query or "3개" in query:
            enhanced_parts.append(
                "\n여러 개의 추천이 필요하므로 충분한 정보를 수집한 후 정리해서 제공하세요."
            )

        enhanced_parts.append(f"\n사용 가능한 도구: {', '.join(tool_names)}")
        enhanced_parts.append(
            "\n위 지침에 따라 단계별 계획을 수립하고 도구를 적극적으로 활용하여 정확하고 유용한 정보를 제공하세요."
        )

        return "\n".join(enhanced_parts)

    def _create_chat_system_prompt(self, query: str) -> str:
        """채팅용 시스템 프롬프트 생성"""
        available_tools_info = []
        if self.tools:
            featured_tools = {
                "browser_use_agent": "🌐 웹 브라우징 및 검색",
                "search_with_bing": "🔍 Bing 검색",
                "weather": "🌤️ 날씨 정보",
                "execute_command": "💻 시스템 명령 실행",
                "read_file": "📄 파일 읽기/쓰기",
                "search_files": "🔎 파일 검색",
            }

            for tool in self.tools:
                if tool.name in featured_tools:
                    available_tools_info.append(f"• {featured_tools[tool.name]}")

            other_tools_count = len(self.tools) - len(available_tools_info)
            if other_tools_count > 0:
                available_tools_info.append(f"• 기타 {other_tools_count}개의 전문 도구")

        tools_text = (
            "\n".join(available_tools_info)
            if available_tools_info
            else "현재 사용 가능한 도구를 로딩 중입니다."
        )

        recommendation_status = (
            "🎯 스마트 추천 시스템 활성화"
            if self.mcp_recommendation_system
            else "📋 기본 도구 라우팅"
        )

        return f"""안녕하세요! 저는 다양한 도구를 활용하여 도움을 드리는 AI 어시스턴트입니다.

현재 사용 가능한 주요 기능들:
{tools_text}

{recommendation_status}

다음과 같은 작업들을 도와드릴 수 있습니다:
- 웹사이트 검색 및 정보 수집 (예: "naver.com에서 맛집 검색해줘")
- 최신 뉴스나 정보 검색 (예: "최신 AI 뉴스 알려줘")
- 날씨 정보 조회 (예: "오늘 날씨 어때?")
- 파일 관리 및 검색 (예: "특정 파일 찾아줘")
- 시스템 명령 실행 및 관리
- 데이터 분석 및 보고서 작성

사용자 질문: {query}

친근하고 도움이 되는 방식으로 인사하고, 구체적으로 어떤 도움이 필요한지 물어보세요. 도구를 사용하지 말고 대화로만 응답해주세요."""

    async def _execute_complex_workflow(
        self,
        chat_id: str,
        query: str,
        analysis: QueryAnalysis,
        selected_tools: List,
        callback: EnhancedFrontendEventCallback,
    ):
        """복잡한 워크플로우 실행"""
        try:
            logger.info(f"복잡한 워크플로우 시작: {analysis.estimated_steps}단계 예상")

            plan_event = EventMessage(
                chat_id,
                MessageType.PLAN_START,
                "🧠 복잡한 작업 계획 수립 중...",
                f"멀티-스텝 워크플로우 설계: {analysis.estimated_steps}단계 예상",
                "complex_plan",
            )
            await self._send_event_to_callback(callback, plan_event)

            workflow_steps = self._generate_workflow_steps(analysis, query)

            if selected_tools:
                if MCP_AVAILABLE:
                    agent = create_react_agent(
                        self.model, selected_tools, checkpointer=self.memory
                    )
                else:
                    agent = self.agent

                system_prompt = f"""당신은 도구를 적극적으로 사용하는 AI 어시스턴트입니다.

사용 가능한 도구들 ({len(selected_tools)}개):
{chr(10).join([f"- {tool.name}: {getattr(tool, 'description', 'No description')}" for tool in selected_tools])}

중요한 지침:
1. 웹사이트 검색이나 브라우징 요청 시 hyperbrowser 도구를 우선 사용하세요.
2. 각 단계를 차근차근 진행하며, 필요한 경우 여러 도구를 사용하세요.
3. 사용자가 구체적인 웹사이트를 언급하면 반드시 해당 사이트를 방문하세요.
4. 도구 실행이 실패하면 다른 도구로 재시도하거나 대안을 찾으세요.

현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}

"""

                enhanced_query = f"""{system_prompt}다음은 복잡한 작업입니다. 다음 단계를 순서대로 수행해주세요:

단계별 실행 계획:
{chr(10).join([f"{i+1}. {step}" for i, step in enumerate(workflow_steps)])}

사용자 요청: {query}

각 단계를 차근차근 진행하며, 필요한 경우 여러 도구를 사용하여 정보를 수집하고 분석한 후 종합적인 답변을 제공해주세요.
특히 웹사이트 검색이 필요한 경우 hyperbrowser 도구를 적극 활용하세요."""

                config = {
                    "configurable": {"thread_id": chat_id},
                    "callbacks": [callback],
                }

                result = await asyncio.wait_for(
                    agent.ainvoke(
                        {"messages": [HumanMessage(content=enhanced_query)]},
                        config=config,
                    ),
                    timeout=300,
                )

                if result and "messages" in result and result["messages"]:
                    last_message = result["messages"][-1]
                    content = self._extract_content(last_message.content)

                    return {
                        "content": content,
                        "description": f"복잡한 워크플로우 완료 ({len(workflow_steps)}단계)",
                        "summary": f"멀티-스텝 처리 완료: {' → '.join(workflow_steps)}",
                    }

            logger.warning("복잡한 워크플로우를 표준 처리로 폴백")
            return await self._execute_standard_workflow(
                chat_id, query, analysis, selected_tools, callback
            )

        except Exception as e:
            logger.error(f"복잡한 워크플로우 실행 오류: {e}")
            return await self._execute_fallback(query, callback)

    def _generate_workflow_steps(
        self, analysis: QueryAnalysis, query: str
    ) -> List[str]:
        """워크플로우 단계 생성"""
        steps = []

        if analysis.query_type == "browser":
            steps.append("웹사이트 접속 및 검색")
            steps.append("검색 결과 수집")
            steps.append("결과 분석 및 정리")
        elif analysis.query_type == "search":
            steps.append("키워드 검색")
            steps.append("정보 수집")
            steps.append("결과 종합")
        else:
            steps.append("정보 수집")
            steps.append("데이터 분석")
            steps.append("결과 정리")

        if "추천" in query:
            steps.append("추천 목록 작성")

        return steps

    async def _send_event_to_callback(
        self, callback: EnhancedFrontendEventCallback, event: EventMessage
    ):
        """콜백에 이벤트 전송"""
        try:
            if callback:
                callback._add_event_to_queue(
                    MessageType(event.type), event.content, event.description, event.key
                )
        except Exception as e:
            logger.error(f"콜백 이벤트 전송 오류: {e}")

    async def _execute_fallback(self, query: str, callback):
        """폴백 실행 (Plan 이벤트 일관성 보장)"""
        try:
            # ✅ 폴백 모드도 계획 단계로 간주
            if callback:
                callback._add_event_to_queue(
                    MessageType.PLAN_START,
                    "🔄 폴백 실행 계획 수립 중...",
                    "MCP 도구 없이 기본 모델로 응답 생성 계획",
                    "fallback_plan_start",
                )

            if callback:
                callback._add_event_to_queue(
                    MessageType.PLAN_COMPLETE,
                    "📋 폴백 실행 계획 완료",
                    "기본 LLM 모델로 직접 응답 생성 계획 수립 완료",
                    "fallback_plan_complete",
                )

            if callback:
                callback._add_event_to_queue(
                    MessageType.THINKING,
                    "💭 기본 모델로 응답을 생성합니다...",
                    "MCP 도구 없이 내장 지식 사용",
                    "fallback_processing",
                )

            response = await asyncio.get_event_loop().run_in_executor(
                self._executor, lambda: self.model.invoke([HumanMessage(content=query)])
            )

            content = self._extract_content(response.content)

            return {
                "content": content,
                "description": "폴백 모드 응답",
                "summary": "기본 모델로 처리 완료",
            }

        except Exception as e:
            logger.error(f"폴백 실행 오류: {e}")

            if callback:
                callback._add_event_to_queue(
                    MessageType.ERROR,
                    "❌ 폴백 실행 실패",
                    f"폴백 처리 중에도 오류 발생: {str(e)[:100]}",
                    "fallback_error",
                )

            return {
                "content": "죄송합니다. 현재 응답을 생성할 수 없습니다.",
                "description": "폴백 실행 실패",
                "summary": "처리 실패",
            }

    def _extract_content(self, content):
        """컨텐츠에서 텍스트 추출"""
        if isinstance(content, list):
            text_parts = []
            for item in content:
                if hasattr(item, "text"):
                    text_parts.append(item.text)
                elif isinstance(item, str):
                    text_parts.append(item)
                elif isinstance(item, dict) and "text" in item:
                    text_parts.append(item["text"])
                else:
                    text_parts.append(str(item))
            return " ".join(text_parts)
        elif isinstance(content, str):
            return content
        else:
            return str(content)

    async def _decompose_user_query(
        self, query: str, analysis: QueryAnalysis
    ) -> Dict[str, Any]:
        """복잡한 사용자 쿼리를 논리적인 단계로 분해"""
        decomposition_prompt = f"""
사용자의 복잡한 요청을 논리적인 단계로 분해해주세요:

요청: "{query}"
복잡도: {analysis.complexity}
예상 단계: {analysis.estimated_steps}

다음 JSON 형식으로 응답해주세요:
{{
    "steps": [
        {{
            "step_number": 1,
            "description": "첫 번째 단계 설명",
            "required_capability": "검색|브라우징|분석|파일처리"
        }},
        {{
            "step_number": 2,
            "description": "두 번째 단계 설명",
            "required_capability": "분석|정리|추천"
        }}
    ],
    "complexity_reason": "복잡한 이유 설명"
}}
"""

        try:
            response = await self.model.ainvoke(decomposition_prompt)
            import json

            return json.loads(response.content.strip())
        except Exception as e:
            logger.error(f"쿼리 분해 실패: {e}")
            return {
                "steps": [
                    {
                        "step_number": 1,
                        "description": query,
                        "required_capability": "general",
                    }
                ],
                "complexity_reason": "분해 실패로 단일 단계 처리",
            }

    def get_session_stats(self, chat_id: str) -> Dict:
        """세션 통계 조회"""
        return self.session_stats.get(chat_id, {})

    async def get_mcp_recommendation(
        self, query: str
    ) -> Optional[MCPRecommendationResult]:
        """MCP 추천 시스템 직접 호출 - 보강된 시스템 우선 사용"""

        # 1순위: 보강된 추천 시스템
        if self.enrichment_enabled and self.enriched_recommendation_system:
            try:
                result = await self.enriched_recommendation_system.recommend_tools(
                    query
                )
                if result:
                    # 보강 시스템 사용 표시
                    result.explanation = f"[LLM 보강] {result.explanation}"
                    return result
            except Exception as e:
                logger.warning(f"보강된 추천 시스템 오류: {e}")

        # 2순위: 기존 추천 시스템으로 폴백
        if self.mcp_recommendation_system:
            try:
                result = await self.mcp_recommendation_system.recommend_tools(query)
                if result:
                    result.explanation = f"[기본] {result.explanation}"
                    return result
            except Exception as e:
                logger.error(f"기본 추천 시스템 오류: {e}")

        return None

    def get_enrichment_status(self) -> Dict[str, Any]:
        """보강 시스템 상태 조회"""
        if not self.mcp_enricher:
            return {
                "enrichment_enabled": False,
                "status": "LLM 보강 시스템이 초기화되지 않았습니다",
            }

        status = self.mcp_enricher.get_enrichment_status()
        return {
            "enrichment_enabled": self.enrichment_enabled,
            "total_servers": status.total_servers,
            "enriched_servers": status.enriched_servers,
            "failed_servers": status.failed_servers,
            "enrichment_progress": status.enrichment_progress,
            "last_enrichment_time": status.last_enrichment_time,
            "cache_size": status.cache_size,
            "background_task_running": status.background_task_running,
            "enriched_vector_store_ready": self.enriched_vector_store is not None,
            "enriched_recommendation_system_ready": self.enriched_recommendation_system
            is not None,
        }


class EnhancedQueryAnalyzer:
    """계층적 계획을 위한 향상된 쿼리 분석기"""

    def __init__(self):
        # 단순 채팅 패턴 (도구 사용 불필요)
        self.simple_chat_patterns = {
            "greetings": ["안녕", "hi", "hello", "하이", "헬로", "반가워"],
            "thanks": ["감사", "고마워", "thank", "thanks", "고맙"],
            "casual": ["기분", "어때", "뭐해", "어떻게", "좋아", "싫어", "힘들어"],
            "simple_questions": ["뭐야", "누구야", "어디야", "언제야"],
            "small_talk": ["날씨", "시간", "요일", "오늘", "내일", "어제"],
        }

        # 단순 도구 사용 패턴
        self.simple_tool_patterns = {
            "single_search": ["검색해줘", "찾아줘", "알려줘", "확인해줘"],
            "single_action": ["열어줘", "실행해줘", "보여줘", "읽어줘"],
            "weather": ["날씨", "기온", "온도", "비", "눈"],
            "time_info": ["시간", "날짜", "요일"],
            "simple_calculation": ["계산", "더하기", "빼기", "곱하기", "나누기"],
        }

        # 복합 도구 사용 지시어
        self.complex_indicators = {
            "multi_step": ["그리고", "그 다음", "이후에", "다음으로", "또한", "추가로"],
            "comparison": ["비교", "차이", "vs", "대비", "어떤게 좋", "장단점"],
            "analysis": ["분석", "조사", "연구", "파악", "검토", "평가"],
            "synthesis": ["종합", "정리", "요약", "취합", "통합"],
            "multiple_sources": ["여러", "다양한", "모든", "각각", "여러개"],
            "workflow": ["순서대로", "단계별로", "절차", "과정", "방법"],
        }

        # 도구 조합이 필요한 패턴
        self.tool_combination_patterns = [
            # 검색 + 분석 + 정리
            ["검색", "분석", "정리"],
            ["찾", "비교", "추천"],
            # 브라우징 + 데이터 수집 + 리포트
            ["사이트", "정보", "보고서"],
            ["웹페이지", "데이터", "요약"],
            # 여러 소스 비교
            ["여러 사이트", "비교", "분석"],
            ["다양한", "검색", "종합"],
        ]

    def analyze_query_complexity(self, query: str) -> RoutingDecision:
        """쿼리 복잡도 분석 및 라우팅 결정"""
        query_lower = query.lower().strip()

        chat_score = self._calculate_simple_chat_score(query_lower)
        complex_score = self._calculate_complex_score(query_lower, query)

        # 정말 간단한 인사말만 SIMPLE_CHAT
        pure_chat = ["안녕", "hi", "hello", "감사", "고마워", "미안"]
        is_pure_chat = (
            len(query_lower) <= 10
            and any(p in query_lower for p in pure_chat)
            and not any(a in query_lower for a in ["해줘", "알려줘", "찾아"])
        )

        if is_pure_chat:
            return RoutingDecision(
                complexity=QueryComplexity.SIMPLE_CHAT,
                confidence=chat_score,
                reasoning="단순한 대화형 질문으로 판단됨",
                recommended_approach="direct_llm_response",
                estimated_steps=1,
                requires_planning=False,
            )
        else:
            return RoutingDecision(
                complexity=QueryComplexity.COMPLEX_TOOL,
                confidence=complex_score,
                reasoning=f"복합 작업 지시어 감지: {complex_score:.2f}",
                recommended_approach="hierarchical_planning",
                estimated_steps=self._estimate_complex_steps(query_lower),
                requires_planning=True,
            )

        ## 1단계: 단순 채팅 확인
        # chat_score = self._calculate_simple_chat_score(query_lower)
        # if chat_score > 0.7:
        #    return RoutingDecision(
        #        complexity=QueryComplexity.SIMPLE_CHAT,
        #        confidence=chat_score,
        #        reasoning="단순한 대화형 질문으로 판단됨",
        #        recommended_approach="direct_llm_response",
        #        estimated_steps=1,
        #        requires_planning=False
        #    )

    #
    ## 2단계: 복합 도구 사용 확인
    # complex_score = self._calculate_complex_score(query_lower, query)
    # if complex_score > 0.6:
    #    return RoutingDecision(
    #        complexity=QueryComplexity.COMPLEX_TOOL,
    #        confidence=complex_score,
    #        reasoning=f"복합 작업 지시어 감지: {complex_score:.2f}",
    #        recommended_approach="hierarchical_planning",
    #        estimated_steps=self._estimate_complex_steps(query_lower),
    #        requires_planning=True
    #    )
    #
    ## 3단계: 단순 도구 사용 확인
    # simple_tool_score = self._calculate_simple_tool_score(query_lower)
    # if simple_tool_score > 0.5:
    #    return RoutingDecision(
    #        complexity=QueryComplexity.SIMPLE_TOOL,
    #        confidence=simple_tool_score,
    #        reasoning="단일 도구 사용으로 처리 가능",
    #        recommended_approach="react_pattern",
    #        estimated_steps=1,
    #        requires_planning=False
    #    )
    #
    ## 기본값: 단순 도구 사용
    # return RoutingDecision(
    #    complexity=QueryComplexity.SIMPLE_TOOL,
    #    confidence=0.5,
    #    reasoning="기본 패턴으로 분류",
    #    recommended_approach="react_pattern",
    #    estimated_steps=1,
    #    requires_planning=False
    # )

    def _calculate_simple_chat_score(self, query_lower: str) -> float:
        """단순 채팅 점수 계산"""
        score = 0.0

        # 길이 체크 (너무 짧으면 채팅일 가능성 높음)
        if len(query_lower) <= 20:
            score += 0.3

        # 패턴 매칭
        for category, patterns in self.simple_chat_patterns.items():
            for pattern in patterns:
                if pattern in query_lower:
                    if category == "greetings":
                        score += 0.4
                    elif category == "thanks":
                        score += 0.3
                    else:
                        score += 0.2

        # 질문표나 명령형이 없으면 채팅일 가능성 높음
        if not any(
            indicator in query_lower for indicator in ["?", "해줘", "알려줘", "찾아줘"]
        ):
            score += 0.2

        return min(1.0, score)

    def _calculate_complex_score(self, query_lower: str, original_query: str) -> float:
        """복합 작업 점수 계산"""
        score = 0.0

        # 1. 복합 지시어 확인
        for category, indicators in self.complex_indicators.items():
            for indicator in indicators:
                if indicator in query_lower:
                    if category == "multi_step":
                        score += 0.3
                    elif category == "comparison":
                        score += 0.25
                    elif category == "analysis":
                        score += 0.2
                    else:
                        score += 0.15

        # 2. 도구 조합 패턴 확인
        for pattern_set in self.tool_combination_patterns:
            if all(pattern in query_lower for pattern in pattern_set):
                score += 0.4
                break

        # 3. 문장 길이 (긴 문장은 복잡할 가능성)
        if len(original_query) > 50:
            score += 0.1
        if len(original_query) > 100:
            score += 0.1

        # 4. 복수형 및 다중 요청
        multi_indicators = ["여러", "다양한", "3개", "5개", "목록", "리스트"]
        if any(indicator in query_lower for indicator in multi_indicators):
            score += 0.2

        # 5. 조건부 요청
        conditional_indicators = ["만약", "경우", "조건", "상황에 따라"]
        if any(indicator in query_lower for indicator in conditional_indicators):
            score += 0.15

        return min(1.0, score)

    def _calculate_simple_tool_score(self, query_lower: str) -> float:
        """단순 도구 사용 점수 계산"""
        score = 0.0

        for category, patterns in self.simple_tool_patterns.items():
            for pattern in patterns:
                if pattern in query_lower:
                    score += 0.3

        # 단일 동작 지시어
        single_actions = ["해줘", "알려줘", "찾아줘", "보여줘", "실행해줘"]
        if any(action in query_lower for action in single_actions):
            score += 0.2

        return min(1.0, score)

    def _estimate_complex_steps(self, query_lower: str) -> int:
        """복합 작업의 예상 단계 수 계산"""
        steps = 1

        # 명시적 단계 언급
        if "단계" in query_lower or "step" in query_lower:
            steps += 2

        # 연결어 개수
        connectors = ["그리고", "그 다음", "이후", "또한", "추가로"]
        connector_count = sum(1 for conn in connectors if conn in query_lower)
        steps += connector_count

        # 복합 작업 지시어
        if any(word in query_lower for word in ["비교", "분석", "종합"]):
            steps += 1

        return min(5, max(2, steps))  # 2-5 단계로 제한


# =================================
# 계층적 계획기
# =================================


class HierarchicalPlanner:
    """계층적 작업 계획 수립기 - 수정된 버전"""

    def __init__(self, llm_model, available_tools: List):
        self.llm_model = llm_model
        self.available_tools = available_tools
        self.tool_capabilities = self._analyze_tool_capabilities()

        # 🔥 메타데이터 시스템 연결용 속성 초기화
        self.mcp_recommendation_system = None
        self.mcp_vector_store = None
        self.enriched_vector_store = None
        self.enriched_system_enabled = False
        self.enriched_vector_enabled = False
        self.metadata_enhanced = False

    def connect_metadata_systems(
        self,
        mcp_recommendation_system=None,
        mcp_vector_store=None,
        enriched_vector_store=None,
        enriched_recommendation_system=None,
    ):
        """메타데이터 시스템들 연결"""
        if enriched_recommendation_system:
            self.mcp_recommendation_system = enriched_recommendation_system
            self.enriched_system_enabled = True
            logger.info("✅ 계층적 플래너에 보강된 추천 시스템 연결됨")
        elif mcp_recommendation_system:
            self.mcp_recommendation_system = mcp_recommendation_system
            self.enriched_system_enabled = False
            logger.info("✅ 계층적 플래너에 기존 추천 시스템 연결됨")

        if enriched_vector_store:
            self.mcp_vector_store = enriched_vector_store
            self.enriched_vector_enabled = True
            logger.info("✅ 계층적 플래너에 보강된 벡터 스토어 연결됨")
        elif mcp_vector_store:
            self.mcp_vector_store = mcp_vector_store
            self.enriched_vector_enabled = False
            logger.info("✅ 계층적 플래너에 기존 벡터 스토어 연결됨")

        # 메타데이터 활용 플래그 설정
        self.metadata_enhanced = (
            self.mcp_recommendation_system is not None
            or self.mcp_vector_store is not None
        )

        if self.metadata_enhanced:
            logger.info(f"🎯 계층적 플래너 메타데이터 활용 모드 활성화")

    def _analyze_tool_capabilities(self) -> Dict[str, List[str]]:
        """도구별 기능 분석"""
        capabilities = {}

        for tool in self.available_tools:
            tool_name = tool.name.lower()
            tool_desc = getattr(tool, "description", "").lower()

            caps = []

            # 웹 관련
            if any(
                kw in tool_name + tool_desc
                for kw in ["browser", "web", "scrape", "navigate"]
            ):
                caps.extend(["web_browsing", "data_extraction", "web_search"])

            # 검색 관련
            if any(
                kw in tool_name + tool_desc
                for kw in ["search", "find", "query", "perplexity"]
            ):
                caps.extend(["search", "information_retrieval"])

            # 파일 관련
            if any(
                kw in tool_name + tool_desc for kw in ["file", "read", "write", "save"]
            ):
                caps.extend(["file_operations", "data_storage"])

            # 분석 관련
            if any(
                kw in tool_name + tool_desc
                for kw in ["analyze", "process", "calculate"]
            ):
                caps.extend(["data_analysis", "processing"])

            capabilities[tool.name] = caps

        return capabilities

    async def create_execution_plan(
        self, query: str, routing_decision: RoutingDecision
    ) -> ExecutionPlan:
        """메타데이터를 활용한 실행 계획 생성"""

        # 🔥 1. MCP 메타데이터 기반 도구 추천 활용
        recommended_tools_metadata = None
        if self.mcp_recommendation_system:
            try:
                logger.info("🧠 MCP 추천 시스템으로 계획 수립용 도구 분석 중...")
                recommended_tools_metadata = (
                    await self.mcp_recommendation_system.recommend_tools(
                        query, max_servers=5, max_tools=15
                    )
                )
                if recommended_tools_metadata:
                    logger.info(
                        f"✅ 계획 수립용 도구 추천 완료: {len(recommended_tools_metadata.recommended_tools)}개"
                    )
            except Exception as e:
                logger.warning(f"⚠️ 계획 수립 중 MCP 추천 실패: {e}")

        # 🔥 2. 벡터 스토어에서 도구별 상세 메타데이터 수집
        detailed_tool_metadata = {}
        if self.mcp_vector_store:
            try:
                logger.info("🔍 벡터 스토어에서 도구별 상세 메타데이터 수집 중...")

                # 쿼리와 관련된 도구들의 상세 정보 검색
                search_results = self.mcp_vector_store.search_tools_only(
                    query, limit=20
                )

                for result in search_results:
                    tool_name = result["entity_name"]
                    detailed_tool_metadata[tool_name] = {
                        "description": result["description"],
                        "category": result["category"],
                        "use_cases": result["use_cases"],
                        "parameters": result["parameters"],
                        "tags": result["tags"],
                        "score": result["score"],
                        "enriched": result.get("enriched", False),
                    }

                logger.info(
                    f"✅ {len(detailed_tool_metadata)}개 도구의 상세 메타데이터 수집 완료"
                )
            except Exception as e:
                logger.warning(f"⚠️ 벡터 스토어 메타데이터 수집 실패: {e}")

        # 3. 메타데이터 기반 계획 수립 프롬프트 생성
        planning_prompt = await self._create_metadata_enhanced_planning_prompt(
            query, routing_decision, recommended_tools_metadata, detailed_tool_metadata
        )

        try:
            logger.info("🎯 메타데이터 강화 계획 수립 시작...")
            plan_response = await self.llm_model.ainvoke(planning_prompt)
            plan_content = plan_response.content

            # 계획 파싱 (메타데이터 정보 포함)
            subtasks = self._parse_subtasks_with_metadata(
                plan_content, query, detailed_tool_metadata
            )
            execution_order = self._determine_execution_order(subtasks)

            plan_id = f"{hash(query) % 10000}"

            logger.info(
                f"✅ 메타데이터 기반 계획 수립 완료: {len(subtasks)}개 하위 작업"
            )

            return ExecutionPlan(
                plan_id=plan_id,
                query=query,
                total_subtasks=len(subtasks),
                subtasks=subtasks,
                execution_order=execution_order,
                estimated_total_time=sum(task.estimated_duration for task in subtasks),
                fallback_strategy="metadata_enhanced_react_pattern",
            )

        except Exception as e:
            logger.error(f"메타데이터 기반 계획 수립 실패: {e}")
            return self._create_fallback_plan(query)

    async def _create_metadata_enhanced_planning_prompt(
        self,
        query: str,
        routing_decision: RoutingDecision,
        recommended_tools_metadata,
        detailed_tool_metadata: Dict,
    ) -> str:
        """메타데이터를 활용한 계획 수립 프롬프트 생성"""

        prompt_parts = [
            "당신은 MCP 메타데이터를 활용하여 복잡한 작업을 하위 작업으로 분해하는 전문가입니다.",
            "",
            f"사용자 요청: {query}",
            f"예상 복잡도: {routing_decision.complexity.value}",
            f"예상 단계: {routing_decision.estimated_steps}",
            "",
        ]

        # 🔥 MCP 추천 시스템 결과 활용
        if recommended_tools_metadata and recommended_tools_metadata.recommended_tools:
            prompt_parts.extend(
                [
                    "## 🎯 MCP 추천 시스템 분석 결과:",
                    f"전체 신뢰도: {recommended_tools_metadata.confidence_score:.2f}",
                    f"설명: {recommended_tools_metadata.explanation}",
                    "",
                ]
            )

            # 추천된 서버들
            if recommended_tools_metadata.recommended_servers:
                prompt_parts.append("### 📡 추천 서버들:")
                for server in recommended_tools_metadata.recommended_servers[:3]:
                    prompt_parts.append(
                        f"- **{server['server_name']}** (관련도: {server['score']:.2f})"
                    )
                prompt_parts.append("")

            # 추천된 도구들 (상세 정보 포함)
            prompt_parts.append("### 🛠️ 추천 도구들 (상세 메타데이터):")
            for tool in recommended_tools_metadata.recommended_tools[:10]:
                tool_info = [
                    f"- **{tool.tool_name}** (서버: {tool.server_name})",
                    f"  - 설명: {tool.description}",
                    f"  - 카테고리: {tool.category}",
                    f"  - 추천 점수: {tool.score:.2f}",
                    f"  - 신뢰도: {tool.confidence:.2f}",
                ]

                if tool.use_cases:
                    tool_info.append(f"  - 주요 용도: {', '.join(tool.use_cases[:3])}")

                if tool.parameters:
                    tool_info.append(f"  - 파라미터: {', '.join(tool.parameters[:5])}")

                tool_info.append(f"  - 추천 이유: {tool.reason}")

                prompt_parts.extend(tool_info)
            prompt_parts.append("")

            # 도구 시퀀스 정보
            if recommended_tools_metadata.tool_sequence:
                prompt_parts.append("### 🔄 권장 도구 시퀀스:")
                for step in recommended_tools_metadata.tool_sequence:
                    prompt_parts.append(
                        f"{step['step']}. {step['tool']}: {step['purpose']}"
                    )
                prompt_parts.append("")

        # 🔥 벡터 스토어의 상세 메타데이터 활용
        if detailed_tool_metadata:
            prompt_parts.extend(["## 📊 도구별 상세 메타데이터:", ""])

            # 카테고리별로 그룹화
            category_tools = {}
            for tool_name, metadata in detailed_tool_metadata.items():
                category = metadata["category"]
                if category not in category_tools:
                    category_tools[category] = []
                category_tools[category].append((tool_name, metadata))

            for category, tools in category_tools.items():
                prompt_parts.append(f"### 🏷️ {category.title()} 카테고리:")

                for tool_name, metadata in tools[:5]:  # 카테고리당 5개까지
                    enriched_mark = " 🧠" if metadata.get("enriched", False) else ""
                    tool_detail = [
                        f"- **{tool_name}**{enriched_mark} (관련도: {metadata['score']:.2f})",
                        f"  - 기능: {metadata['description'][:100]}{'...' if len(metadata['description']) > 100 else ''}",
                    ]

                    if metadata["use_cases"]:
                        tool_detail.append(
                            f"  - 사용 사례: {', '.join(metadata['use_cases'][:3])}"
                        )

                    if metadata["parameters"]:
                        tool_detail.append(
                            f"  - 파라미터: {', '.join(metadata['parameters'][:3])}"
                        )

                    if metadata["tags"]:
                        tool_detail.append(
                            f"  - 태그: {', '.join(metadata['tags'][:3])}"
                        )

                    prompt_parts.extend(tool_detail)

                prompt_parts.append("")

        # 작업 분해 지침
        prompt_parts.extend(
            [
                "## 📋 작업 분해 지침:",
                "",
                "위의 MCP 메타데이터를 적극 활용하여 다음 형식으로 하위 작업들을 정의해주세요:",
                "",
                "SUBTASK_1:",
                "name: [메타데이터 기반으로 선정된 구체적 작업명]",
                "description: [상세 설명 - 사용할 도구의 특성을 반영]",
                "required_tools: [메타데이터에서 확인된 최적 도구들]",
                "tool_rationale: [해당 도구들을 선택한 메타데이터 기반 근거]",
                "dependencies: []",
                "priority: [1-5]",
                "duration: [메타데이터의 복잡도를 고려한 예상 시간(분)]",
                "success_criteria: [메타데이터 기반 성공 기준]",
                "",
                "중요한 원칙:",
                "1. **메타데이터 우선 활용**: 추천 시스템과 벡터 스토어의 정보를 최우선으로 고려",
                "2. **도구 특성 반영**: 각 도구의 use_cases, parameters, 카테고리 정보를 작업 설계에 반영",
                "3. **논리적 순서**: 의존성과 도구 특성을 고려한 실행 순서 결정",
                "4. **효율성 최적화**: 유사한 기능의 도구는 하나로 통합하여 중복 제거",
                "5. **품질 보장**: 각 하위 작업의 성공 기준을 명확히 정의",
                "",
                f"현재 작업 '{query}'을 위한 최적의 계획을 수립해주세요.",
            ]
        )

        return "\n".join(prompt_parts)

    def _parse_tool_string(self, tools_str: str) -> List[str]:
        """도구 문자열 파싱"""
        if not tools_str or tools_str.strip() in ["[]", "", "None", "null"]:
            return []

        # 대괄호 제거
        cleaned = tools_str.strip()
        if cleaned.startswith("[") and cleaned.endswith("]"):
            cleaned = cleaned[1:-1]

        # 쉼표로 분리하고 정리
        tools = []
        for tool in cleaned.split(","):
            clean_tool = tool.strip().strip('"').strip("'").strip()
            if clean_tool and clean_tool.lower() not in ["none", "null", ""]:
                tools.append(clean_tool)

        return tools

    def _parse_dependencies(self, deps_str: str) -> List[str]:
        """의존성 문자열 파싱"""
        if not deps_str or deps_str.strip() in ["[]", "", "None", "null"]:
            return []

        # 대괄호 제거
        cleaned = deps_str.strip()
        if cleaned.startswith("[") and cleaned.endswith("]"):
            cleaned = cleaned[1:-1]

        # 쉼표로 분리하고 정리
        dependencies = []
        for dep in cleaned.split(","):
            clean_dep = dep.strip().strip('"').strip("'").strip()
            if clean_dep and clean_dep.lower() not in ["none", "null", ""]:
                dependencies.append(clean_dep)

        return dependencies

    def _find_exact_tool_match_enhanced(self, raw_tool: str) -> Optional[str]:
        """향상된 정확한 도구 매칭"""
        if not self.available_tools:
            return None

        raw_lower = raw_tool.lower().strip()

        # 1. 정확한 이름 매칭
        for tool in self.available_tools:
            if tool.name.lower() == raw_lower:
                return tool.name

        # 2. 부분 매칭 (언더스코어 고려)
        for tool in self.available_tools:
            tool_name_lower = tool.name.lower()
            if raw_lower in tool_name_lower or tool_name_lower in raw_lower:
                return tool.name

            # 키워드 매칭
            raw_keywords = set(raw_lower.split("_"))
            tool_keywords = set(tool_name_lower.split("_"))
            if raw_keywords.intersection(tool_keywords):
                return tool.name

        return None

    def _recommend_tools_by_task_semantics(
        self, task_name: str, task_description: str
    ) -> List:
        """작업 의미 기반 도구 추천"""
        if not self.available_tools:
            return []

        task_text = f"{task_name} {task_description}".lower()
        recommended = []

        # 더 정교한 패턴 매칭
        patterns = {
            "naver_shopping": {
                "keywords": ["naver", "네이버", "shopping", "쇼핑", "usb"],
                "tools": ["hyperbrowser", "browser"],
            },
            "wiki_search": {
                "keywords": ["wiki", "위키", "wikipedia", "유박비료"],
                "tools": ["hyperbrowser", "browser", "search"],
            },
            "file_save": {
                "keywords": ["저장", "save", "markdown", ".md", "파일"],
                "tools": ["file", "write", "filesystem"],
            },
            "web_search": {
                "keywords": ["검색", "search", "찾기", "find"],
                "tools": ["search", "perplexity"],
            },
        }

        for pattern_name, pattern_data in patterns.items():
            if any(keyword in task_text for keyword in pattern_data["keywords"]):
                for tool_type in pattern_data["tools"]:
                    matching_tools = [
                        t for t in self.available_tools if tool_type in t.name.lower()
                    ]
                    recommended.extend(matching_tools[:1])  # 각 타입당 1개

        return recommended[:3]  # 최대 3개

    def _assign_fallback_tools_by_query_pattern(
        self, task_dict: Dict, task_id: str
    ) -> List[str]:
        """쿼리 패턴 기반 강제 도구 할당"""
        if not self.available_tools:
            return []

        # task_dict에서 원본 쿼리 패턴 파악
        task_content = (
            f"{task_dict.get('name', '')} {task_dict.get('description', '')}".lower()
        )

        fallback_tools = []

        if any(kw in task_content for kw in ["naver", "usb", "web", "site"]):
            # 웹 브라우징 도구 강제 할당
            browser_tools = [
                t.name
                for t in self.available_tools
                if any(bt in t.name.lower() for bt in ["browser", "hyperbrowser"])
            ]
            fallback_tools.extend(browser_tools[:1])

        if any(kw in task_content for kw in ["search", "find", "wiki"]):
            # 검색 도구 강제 할당
            search_tools = [
                t.name
                for t in self.available_tools
                if any(st in t.name.lower() for st in ["search", "perplexity"])
            ]
            fallback_tools.extend(search_tools[:1])

        if any(kw in task_content for kw in ["save", "markdown", "file"]):
            # 파일 도구 강제 할당
            file_tools = [
                t.name
                for t in self.available_tools
                if any(ft in t.name.lower() for ft in ["file", "write", "save"])
            ]
            fallback_tools.extend(file_tools[:1])

        # 아무것도 매칭되지 않으면 첫 번째 도구라도 할당
        if not fallback_tools and self.available_tools:
            fallback_tools = [self.available_tools[0].name]

        return fallback_tools

    def _generate_meaningful_task_name(self, task_dict: Dict, task_id: str) -> str:
        """의미있는 작업 이름 생성"""
        raw_name = task_dict.get("name", "").strip()
        description = task_dict.get("description", "").strip()

        # 1. 원본 이름이 의미있으면 사용
        if (
            raw_name
            and len(raw_name) > 3
            and raw_name.lower() not in ["task", "subtask", "none"]
        ):
            return raw_name

        # 2. 설명에서 의미있는 이름 추출
        if description:
            desc_lower = description.lower()

            # 특정 패턴 기반 이름 생성
            if "naver" in desc_lower and "usb" in desc_lower:
                return "네이버 쇼핑 USB-C 케이블 검색"
            elif "wiki" in desc_lower and "유박비료" in desc_lower:
                return "위키피디아 유박비료 정보 검색"
            elif "저장" in desc_lower and "markdown" in desc_lower:
                return "마크다운 파일 저장"
            elif "검색" in desc_lower:
                return "정보 검색 작업"
            elif "추출" in desc_lower:
                return "데이터 추출 작업"
            else:
                # 설명의 첫 부분을 이용한 이름 생성
                clean_desc = description.split(".")[0].split("을")[0].split("를")[0]
                return clean_desc[:25] + "..." if len(clean_desc) > 25 else clean_desc

        # 3. 기본 이름
        if task_id.startswith("task_"):
            task_number = task_id.replace("task_", "")
            return f"작업 단계 {task_number}"
        else:
            return task_id.replace("_", " ").title()

    def _parse_subtasks_with_metadata(
        self, response: str, query: str, detailed_tool_metadata: Dict
    ) -> List[SubTask]:
        """메타데이터 정보를 포함한 하위 작업 파싱 - 개선된 버전"""
        subtasks = []

        try:
            lines = response.split("\n")
            current_task = {}
            task_id = 1

            logger.info(f"🔍 LLM 응답 파싱 시작:")
            logger.info(f"응답 길이: {len(response)}")
            logger.info(f"첫 200자: {response[:200]}")

            for line in lines:
                line = line.strip()

                if line.startswith("SUBTASK_"):
                    if current_task:
                        # 🔥 개선: 더 상세한 로깅
                        logger.info(f"📋 파싱된 작업 데이터: {current_task}")
                        subtask = self._create_subtask_with_validated_tools(
                            current_task, f"task_{task_id}", detailed_tool_metadata
                        )
                        if subtask:
                            subtasks.append(subtask)
                            logger.info(f"✅ 작업 생성 성공: {subtask.name}")
                        else:
                            logger.warning(f"❌ 작업 생성 실패: task_{task_id}")
                        task_id += 1
                    current_task = {}

                elif ":" in line and current_task is not None:
                    key, value = line.split(":", 1)
                    current_task[key.strip().lower()] = value.strip()
                    logger.debug(f"파싱: {key.strip().lower()} = {value.strip()}")

            # 마지막 작업 저장
            if current_task:
                logger.info(f"📋 마지막 작업 데이터: {current_task}")
                subtask = self._create_subtask_with_validated_tools(
                    current_task, f"task_{task_id}", detailed_tool_metadata
                )
                if subtask:
                    subtasks.append(subtask)

        except Exception as e:
            logger.error(f"하위 작업 파싱 오류: {e}")
            logger.error(f"파싱 실패한 응답:\n{response}")
            return self._create_query_based_default_subtasks(query)

        if not subtasks:
            logger.warning("파싱된 작업이 없어 쿼리 기반 기본 작업 생성")
            return self._create_query_based_default_subtasks(query)

        logger.info(f"🎯 최종 파싱 결과: {len(subtasks)}개 작업")
        for i, task in enumerate(subtasks, 1):
            logger.info(f"  {i}. {task.name} (도구: {len(task.required_tools)}개)")

        return subtasks

    # 🔥 문제 2: 도구 매핑 로직 개선
    def _create_subtask_with_validated_tools(
        self, task_dict: Dict, task_id: str, detailed_tool_metadata: Dict
    ) -> Optional[SubTask]:
        """검증된 도구를 가진 SubTask 객체 생성 - 개선된 버전"""
        try:
            # 이름 생성 (개선됨)
            name = self._generate_meaningful_task_name(task_dict, task_id)
            description = task_dict.get("description", f"{name}을 수행합니다")

            logger.info(f"🔧 SubTask 생성: {task_id}")
            logger.info(f"  이름: {name}")
            logger.info(f"  설명: {description[:100]}...")

            # 🔥 도구 파싱 및 검증 개선
            tools_str = task_dict.get("required_tools", "[]")
            raw_tools = self._parse_tool_string(tools_str)
            logger.info(f"  원본 도구: {raw_tools}")

            # 🔥 단계별 도구 매칭
            validated_tools = []

            # 1단계: 정확한 매칭
            for raw_tool in raw_tools:
                exact_match = self._find_exact_tool_match_enhanced(raw_tool)
                if exact_match:
                    validated_tools.append(exact_match)
                    logger.info(f"    ✅ 정확 매칭: {raw_tool} → {exact_match}")
                else:
                    logger.warning(f"    ❌ 매칭 실패: {raw_tool}")

            # 2단계: 매칭된 도구가 없으면 작업 기반 추천
            if not validated_tools:
                logger.info("  🔄 작업 기반 도구 추천 시도...")
                suggested_tools = self._recommend_tools_by_task_semantics(
                    name, description
                )
                validated_tools = [tool.name for tool in suggested_tools]
                logger.info(f"    🎯 추천된 도구: {validated_tools}")

            # 3단계: 여전히 없으면 강제 할당
            if not validated_tools:
                logger.warning("  ⚠️ 강제 도구 할당...")
                fallback_tools = self._assign_fallback_tools_by_query_pattern(
                    task_dict, task_id
                )
                validated_tools = fallback_tools
                logger.info(f"    🆘 강제 할당: {validated_tools}")

            subtask = SubTask(
                id=task_id,
                name=name,
                description=description,
                required_tools=validated_tools[:3],  # 최대 3개
                dependencies=self._parse_dependencies(
                    task_dict.get("dependencies", "[]")
                ),
                priority=int(task_dict.get("priority", "3")),
                estimated_duration=int(task_dict.get("duration", "5")),
            )

            logger.info(f"✅ SubTask 생성 완료: {name} (도구 {len(validated_tools)}개)")
            return subtask

        except Exception as e:
            logger.error(f"SubTask 생성 오류: {e}")
            return None

    def _find_exact_tool_match_enhanced(self, raw_tool: str) -> Optional[str]:
        """향상된 정확한 도구 매칭"""
        if not self.available_tools:
            return None

        raw_lower = raw_tool.lower().strip()

        # 1. 정확한 이름 매칭
        for tool in self.available_tools:
            if tool.name.lower() == raw_lower:
                return tool.name

        # 2. 부분 매칭 (언더스코어 고려)
        for tool in self.available_tools:
            tool_name_lower = tool.name.lower()
            if raw_lower in tool_name_lower or tool_name_lower in raw_lower:
                return tool.name

            # 키워드 매칭
            raw_keywords = set(raw_lower.split("_"))
            tool_keywords = set(tool_name_lower.split("_"))
            if raw_keywords.intersection(tool_keywords):
                return tool.name

        return None

    def _recommend_tools_by_task_semantics(
        self, task_name: str, task_description: str
    ) -> List:
        """작업 의미 기반 도구 추천"""
        task_text = f"{task_name} {task_description}".lower()
        recommended = []

        # 더 정교한 패턴 매칭
        patterns = {
            "naver_shopping": {
                "keywords": ["naver", "네이버", "shopping", "쇼핑", "usb"],
                "tools": ["hyperbrowser", "browser"],
            },
            "wiki_search": {
                "keywords": ["wiki", "위키", "wikipedia", "유박비료"],
                "tools": ["hyperbrowser", "browser", "search"],
            },
            "file_save": {
                "keywords": ["저장", "save", "markdown", ".md", "파일"],
                "tools": ["file", "write", "filesystem"],
            },
            "web_search": {
                "keywords": ["검색", "search", "찾기", "find"],
                "tools": ["search", "perplexity"],
            },
        }

        for pattern_name, pattern_data in patterns.items():
            if any(keyword in task_text for keyword in pattern_data["keywords"]):
                for tool_type in pattern_data["tools"]:
                    matching_tools = [
                        t for t in self.available_tools if tool_type in t.name.lower()
                    ]
                    recommended.extend(matching_tools[:1])  # 각 타입당 1개

        return recommended[:3]  # 최대 3개

    def _assign_fallback_tools_by_query_pattern(
        self, task_dict: Dict, task_id: str
    ) -> List[str]:
        """쿼리 패턴 기반 강제 도구 할당"""
        # task_dict에서 원본 쿼리 패턴 파악
        task_content = (
            f"{task_dict.get('name', '')} {task_dict.get('description', '')}".lower()
        )

        fallback_tools = []

        if any(kw in task_content for kw in ["naver", "usb", "web", "site"]):
            # 웹 브라우징 도구 강제 할당
            browser_tools = [
                t.name
                for t in self.available_tools
                if any(bt in t.name.lower() for bt in ["browser", "hyperbrowser"])
            ]
            fallback_tools.extend(browser_tools[:1])

        if any(kw in task_content for kw in ["search", "find", "wiki"]):
            # 검색 도구 강제 할당
            search_tools = [
                t.name
                for t in self.available_tools
                if any(st in t.name.lower() for st in ["search", "perplexity"])
            ]
            fallback_tools.extend(search_tools[:1])

        if any(kw in task_content for kw in ["save", "markdown", "file"]):
            # 파일 도구 강제 할당
            file_tools = [
                t.name
                for t in self.available_tools
                if any(ft in t.name.lower() for ft in ["file", "write", "save"])
            ]
            fallback_tools.extend(file_tools[:1])

        # 아무것도 매칭되지 않으면 첫 번째 도구라도 할당
        if not fallback_tools and self.available_tools:
            fallback_tools = [self.available_tools[0].name]

        return fallback_tools

    def _generate_meaningful_task_name(self, task_dict: Dict, task_id: str) -> str:
        """의미있는 작업 이름 생성"""
        raw_name = task_dict.get("name", "").strip()
        description = task_dict.get("description", "").strip()

        # 1. 원본 이름이 의미있으면 사용
        if (
            raw_name
            and len(raw_name) > 3
            and raw_name.lower() not in ["task", "subtask", "none"]
        ):
            return raw_name

        # 2. 설명에서 의미있는 이름 추출
        if description:
            desc_lower = description.lower()

            # 특정 패턴 기반 이름 생성
            if "naver" in desc_lower and "usb" in desc_lower:
                return "네이버 쇼핑 USB-C 케이블 검색"
            elif "wiki" in desc_lower and "유박비료" in desc_lower:
                return "위키피디아 유박비료 정보 검색"
            elif "저장" in desc_lower and "markdown" in desc_lower:
                return "마크다운 파일 저장"
            elif "검색" in desc_lower:
                return "정보 검색 작업"
            elif "추출" in desc_lower:
                return "데이터 추출 작업"
            else:
                # 설명의 첫 부분을 이용한 이름 생성
                clean_desc = description.split(".")[0].split("을")[0].split("를")[0]
                return clean_desc[:25] + "..." if len(clean_desc) > 25 else clean_desc

        # 3. 기본 이름
        if task_id.startswith("task_"):
            task_number = task_id.replace("task_", "")
            return f"작업 단계 {task_number}"
        else:
            return task_id.replace("_", " ").title()

    def _create_subtask_with_metadata(
        self, task_dict: Dict, task_id: str, detailed_tool_metadata: Dict
    ) -> Optional[SubTask]:
        """메타데이터 정보를 활용한 SubTask 객체 생성"""
        try:
            name = task_dict.get("name", f"Task {task_id}")
            description = task_dict.get("description", "")
            tool_rationale = task_dict.get("tool_rationale", "")
            success_criteria = task_dict.get("success_criteria", "")

            # 도구 파싱 및 메타데이터 검증
            tools_str = task_dict.get("required_tools", "[]")
            required_tools = [
                tool.strip()
                for tool in tools_str.replace("[", "").replace("]", "").split(",")
                if tool.strip()
            ]

            # 🔥 메타데이터에서 검증된 도구만 유지
            validated_tools = []
            for tool in required_tools:
                # 정확한 매칭 또는 부분 매칭 확인
                if tool in detailed_tool_metadata:
                    validated_tools.append(tool)
                else:
                    # 부분 매칭 시도
                    for metadata_tool in detailed_tool_metadata.keys():
                        if (
                            tool.lower() in metadata_tool.lower()
                            or metadata_tool.lower() in tool.lower()
                        ):
                            validated_tools.append(metadata_tool)
                            break

            # 의존성 파싱
            deps_str = task_dict.get("dependencies", "[]")
            dependencies = [
                dep.strip()
                for dep in deps_str.replace("[", "").replace("]", "").split(",")
                if dep.strip()
            ]

            priority = int(task_dict.get("priority", "3"))

            # 🔥 메타데이터 기반 시간 추정 개선
            duration = int(task_dict.get("duration", "5"))
            if validated_tools:
                # 도구의 복잡도에 따른 시간 조정
                complex_categories = ["automation", "web_browsing", "data_extraction"]
                for tool in validated_tools:
                    if tool in detailed_tool_metadata:
                        tool_category = detailed_tool_metadata[tool]["category"]
                        if tool_category in complex_categories:
                            duration = max(duration, 7)  # 복잡한 도구는 최소 7분

            subtask = SubTask(
                id=task_id,
                name=name,
                description=description,
                required_tools=validated_tools,  # 검증된 도구만 사용
                dependencies=dependencies,
                priority=priority,
                estimated_duration=duration,
            )

            # 🔥 메타데이터 정보를 SubTask의 추가 속성으로 저장
            subtask.tool_rationale = tool_rationale
            subtask.success_criteria = success_criteria
            subtask.metadata_enhanced = True

            # 사용된 도구들의 메타데이터 요약
            subtask.tools_metadata = {}
            for tool in validated_tools:
                if tool in detailed_tool_metadata:
                    subtask.tools_metadata[tool] = detailed_tool_metadata[tool]

            return subtask

        except Exception as e:
            logger.error(f"메타데이터 SubTask 생성 오류: {e}")
            return None

    def _create_metadata_enhanced_default_subtasks(
        self, query: str, detailed_tool_metadata: Dict
    ) -> List[SubTask]:
        """메타데이터를 활용한 기본 하위 작업 생성"""
        subtasks = []
        query_lower = query.lower()

        # 🔥 메타데이터에서 관련도가 높은 도구들 우선 선택
        relevant_tools = []
        if detailed_tool_metadata:
            # 점수 기준으로 정렬
            sorted_tools = sorted(
                detailed_tool_metadata.items(),
                key=lambda x: x[1]["score"],
                reverse=True,
            )
            relevant_tools = [tool_name for tool_name, metadata in sorted_tools[:10]]

        # 작업 유형별 하위 작업 생성 (메타데이터 기반)
        if any(kw in query_lower for kw in ["검색", "찾", "search"]):
            search_tools = [
                tool
                for tool in relevant_tools
                if "search" in detailed_tool_metadata.get(tool, {}).get("category", "")
            ]
            subtasks.append(
                SubTask(
                    id="metadata_search_task",
                    name="메타데이터 기반 정보 검색",
                    description="MCP 메타데이터에서 선정된 최적 검색 도구로 관련 정보를 검색합니다",
                    required_tools=(
                        search_tools[:3] if search_tools else ["search", "perplexity"]
                    ),
                    dependencies=[],
                    priority=4,
                    estimated_duration=4,
                )
            )

        if any(kw in query_lower for kw in ["브라우저", "사이트", "웹페이지"]):
            browser_tools = [
                tool
                for tool in relevant_tools
                if "web" in detailed_tool_metadata.get(tool, {}).get("category", "")
                or "browser" in tool.lower()
            ]
            subtasks.append(
                SubTask(
                    id="metadata_browse_task",
                    name="메타데이터 기반 웹 브라우징",
                    description="MCP 메타데이터에서 선정된 브라우징 도구로 웹사이트를 방문하여 정보를 수집합니다",
                    required_tools=(
                        browser_tools[:2]
                        if browser_tools
                        else ["browser", "hyperbrowser"]
                    ),
                    dependencies=[],
                    priority=4,
                    estimated_duration=6,
                )
            )

        if any(kw in query_lower for kw in ["분석", "비교", "정리"]):
            analysis_tools = [
                tool
                for tool in relevant_tools
                if "analysis"
                in detailed_tool_metadata.get(tool, {}).get("category", "")
            ]
            subtasks.append(
                SubTask(
                    id="metadata_analysis_task",
                    name="메타데이터 기반 결과 분석",
                    description="MCP 메타데이터 정보를 바탕으로 수집된 정보를 분석하고 정리합니다",
                    required_tools=(
                        analysis_tools[:2] if analysis_tools else ["analysis"]
                    ),
                    dependencies=["metadata_search_task", "metadata_browse_task"],
                    priority=3,
                    estimated_duration=5,
                )
            )

        # 기본 작업이 없으면 최고 점수 도구로 생성
        if not subtasks and relevant_tools:
            subtasks.append(
                SubTask(
                    id="metadata_default_task",
                    name="메타데이터 최적 도구 처리",
                    description=f"MCP 메타데이터에서 가장 관련도가 높은 도구들로 요청을 처리합니다",
                    required_tools=relevant_tools[:3],
                    dependencies=[],
                    priority=3,
                    estimated_duration=5,
                )
            )

        return subtasks

    async def _create_planning_prompt(
        self, query: str, routing_decision: RoutingDecision
    ) -> str:
        """계획 수립용 프롬프트 생성"""

        tool_info = []
        # MCP 추천 시스템에서 메타데이터 활용
        if (
            hasattr(self, "mcp_recommendation_system")
            and self.mcp_recommendation_system
        ):
            try:
                # 쿼리 기반 도구 추천으로 메타데이터 활용
                mcp_recommendations = (
                    await self.mcp_recommendation_system.recommend_tools(query)
                )
                if mcp_recommendations:
                    for rec_tool in mcp_recommendations.recommended_tools:
                        enhanced_info = (
                            f"- **{rec_tool.tool_name}** (서버: {rec_tool.server_name})\n"
                            f"  - 설명: {rec_tool.description}\n"
                            f"  - 카테고리: {rec_tool.category}\n"
                            f"  - 사용사례: {', '.join(rec_tool.use_cases)}\n"
                            f"  - 파라미터: {', '.join(rec_tool.parameters)}\n"
                            f"  - 추천점수: {rec_tool.score:.2f}\n"
                            f"  - 추천이유: {rec_tool.reason}"
                        )
                        tool_info.append(enhanced_info)
            except Exception as e:
                logger.warning(f"MCP 메타데이터 활용 실패: {e}")
                # 폴백: 기존 방식
                pass

        # 벡터스토어에서 메타데이터 활용
        if hasattr(self, "mcp_vector_store") and self.mcp_vector_store:
            try:
                # 쿼리와 관련된 도구들의 상세 메타데이터 검색
                search_results = self.mcp_vector_store.search_tools_only(
                    query, limit=10
                )
                for result in search_results:
                    if result["entity_type"] == "tool":
                        enhanced_info = (
                            f"- **{result['entity_name']}** (서버: {result['server_name']})\n"
                            f"  - 설명: {result['description']}\n"
                            f"  - 카테고리: {result['category']}\n"
                            f"  - 태그: {', '.join(result['tags'])}\n"
                            f"  - 사용사례: {', '.join(result['use_cases'])}\n"
                            f"  - 관련도: {result['score']:.2f}"
                        )
                        tool_info.append(enhanced_info)
            except Exception as e:
                logger.warning(f"벡터스토어 메타데이터 활용 실패: {e}")
        return f"""당신은 복잡한 작업을 하위 작업으로 분해하는 전문가입니다.

사용자 요청: {query}
예상 복잡도: {routing_decision.complexity.value}
예상 단계: {routing_decision.estimated_steps}

사용 가능한 도구들:
{chr(10).join(tool_info)}

다음 형식으로 하위 작업들을 정의해주세요:

SUBTASK_1:
name: [작업명]
description: [상세 설명]
required_tools: [도구1, 도구2]
dependencies: []
priority: [1-5]
duration: [예상 시간(분)]

SUBTASK_2:
name: [작업명]
description: [상세 설명]
required_tools: [도구명들]
dependencies: [SUBTASK_1]
priority: [1-5]
duration: [예상 시간(분)]

지침:
1. 논리적 순서로 하위 작업을 나누세요
2. 각 하위 작업은 특정 도구로 수행 가능해야 합니다
3. 의존성을 명확히 정의하세요
4. 우선순위는 1(낮음) ~ 5(높음)입니다"""

    def _parse_subtasks_from_response(self, response: str, query: str) -> List[SubTask]:
        """LLM 응답에서 하위 작업 파싱"""
        subtasks = []

        try:
            # 간단한 파싱 로직 (실제로는 더 정교한 파싱이 필요)
            lines = response.split("\n")
            current_task = {}
            task_id = 1

            for line in lines:
                line = line.strip()

                if line.startswith("SUBTASK_"):
                    if current_task:
                        # 이전 작업 저장
                        subtask = self._create_subtask_from_dict(
                            current_task, f"task_{task_id}"
                        )
                        if subtask:
                            subtasks.append(subtask)
                        task_id += 1
                    current_task = {}

                elif ":" in line and current_task is not None:
                    key, value = line.split(":", 1)
                    current_task[key.strip().lower()] = value.strip()

            # 마지막 작업 저장
            if current_task:
                subtask = self._create_subtask_from_dict(
                    current_task, f"task_{task_id}"
                )
                if subtask:
                    subtasks.append(subtask)

        except Exception as e:
            logger.error(f"하위 작업 파싱 오류: {e}")
            return self._create_default_subtasks(query)

        return subtasks if subtasks else self._create_default_subtasks(query)

    def _create_subtask_from_dict(
        self, task_dict: Dict, task_id: str
    ) -> Optional[SubTask]:
        """딕셔너리에서 SubTask 객체 생성"""
        try:
            name = task_dict.get("name", f"Task {task_id}")
            description = task_dict.get("description", "")

            # 도구 파싱
            tools_str = task_dict.get("required_tools", "[]")
            required_tools = [
                tool.strip()
                for tool in tools_str.replace("[", "").replace("]", "").split(",")
                if tool.strip()
            ]

            # 의존성 파싱
            deps_str = task_dict.get("dependencies", "[]")
            dependencies = [
                dep.strip()
                for dep in deps_str.replace("[", "").replace("]", "").split(",")
                if dep.strip()
            ]

            priority = int(task_dict.get("priority", "3"))
            duration = int(task_dict.get("duration", "5"))

            return SubTask(
                id=task_id,
                name=name,
                description=description,
                required_tools=required_tools,
                dependencies=dependencies,
                priority=priority,
                estimated_duration=duration,
            )

        except Exception as e:
            logger.error(f"SubTask 생성 오류: {e}")
            return None

    def _create_default_subtasks(self, query: str) -> List[SubTask]:
        """기본 하위 작업 생성"""
        query_lower = query.lower()

        subtasks = []

        if any(kw in query_lower for kw in ["검색", "찾", "search"]):
            subtasks.append(
                SubTask(
                    id="search_task",
                    name="정보 검색",
                    description="관련 정보를 검색합니다",
                    required_tools=["search", "perplexity"],
                    dependencies=[],
                    priority=4,
                    estimated_duration=3,
                )
            )

        if any(kw in query_lower for kw in ["브라우저", "사이트", "웹페이지"]):
            subtasks.append(
                SubTask(
                    id="browse_task",
                    name="웹 브라우징",
                    description="웹사이트를 방문하여 정보를 수집합니다",
                    required_tools=["browser", "hyperbrowser"],
                    dependencies=[],
                    priority=4,
                    estimated_duration=5,
                )
            )

        if any(kw in query_lower for kw in ["분석", "비교", "정리"]):
            subtasks.append(
                SubTask(
                    id="analysis_task",
                    name="결과 분석",
                    description="수집된 정보를 분석하고 정리합니다",
                    required_tools=["analysis"],
                    dependencies=["search_task", "browse_task"],
                    priority=3,
                    estimated_duration=4,
                )
            )

        return (
            subtasks
            if subtasks
            else [
                SubTask(
                    id="default_task",
                    name="기본 처리",
                    description="요청을 처리합니다",
                    required_tools=[],
                    dependencies=[],
                    priority=3,
                    estimated_duration=3,
                )
            ]
        )

    def _determine_execution_order(self, subtasks: List[SubTask]) -> List[str]:
        """실행 순서 결정 (의존성 고려)"""
        executed = set()
        execution_order = []

        # 우선순위 + 의존성 기반 정렬
        remaining_tasks = subtasks.copy()

        while remaining_tasks:
            # 의존성이 해결된 태스크 찾기
            ready_tasks = [
                task
                for task in remaining_tasks
                if all(dep in executed for dep in task.dependencies)
            ]

            if not ready_tasks:
                # 순환 의존성이나 문제가 있는 경우 가장 높은 우선순위 선택
                ready_tasks = [max(remaining_tasks, key=lambda t: t.priority)]

            # 우선순위로 정렬
            ready_tasks.sort(key=lambda t: t.priority, reverse=True)

            # 첫 번째 태스크 실행
            next_task = ready_tasks[0]
            execution_order.append(next_task.id)
            executed.add(next_task.id)
            remaining_tasks.remove(next_task)

        return execution_order

    def _create_fallback_plan(self, query: str) -> ExecutionPlan:
        """폴백 계획 생성"""
        fallback_task = SubTask(
            id="fallback_task",
            name="기본 처리",
            description=f"요청 처리: {query}",
            required_tools=[],
            dependencies=[],
            priority=3,
            estimated_duration=5,
        )

        return ExecutionPlan(
            plan_id="fallback_plan",
            query=query,
            total_subtasks=1,
            subtasks=[fallback_task],
            execution_order=["fallback_task"],
            estimated_total_time=5,
            fallback_strategy="react_pattern",
        )


# =================================
# 새로운 메타데이터 통합 계층적 플래너 클래스
# =================================


class EnhancedHierarchicalPlannerWithMetadata(HierarchicalPlanner):
    """메타데이터가 완전히 통합된 계층적 플래너 - 속성 보완"""

    def __init__(self, llm_model, available_tools: List):
        super().__init__(llm_model, available_tools)

        # 🔥 핵심: 메타데이터 속성들 명시적 추가
        self.metadata_enhanced = False
        self.enriched_mode = False
        self.enriched_system_enabled = False
        self.enriched_vector_enabled = False

        logger.info(
            f"✅ EnhancedHierarchicalPlannerWithMetadata 초기화: metadata_enhanced={self.metadata_enhanced}"
        )

    def connect_metadata_systems(
        self,
        mcp_recommendation_system=None,
        mcp_vector_store=None,
        enriched_vector_store=None,
        enriched_recommendation_system=None,
    ):
        """메타데이터 시스템들 연결 - 개선된 버전"""
        connections_made = 0

        if enriched_recommendation_system:
            self.mcp_recommendation_system = enriched_recommendation_system
            self.enriched_system_enabled = True
            connections_made += 1
            logger.info("✅ WithMetadata 플래너: 보강된 추천 시스템 연결됨")
        elif mcp_recommendation_system:
            self.mcp_recommendation_system = mcp_recommendation_system
            self.enriched_system_enabled = False
            connections_made += 1
            logger.info("✅ WithMetadata 플래너: 기존 추천 시스템 연결됨")

        if enriched_vector_store:
            self.mcp_vector_store = enriched_vector_store
            self.enriched_vector_enabled = True
            connections_made += 1
            logger.info("✅ WithMetadata 플래너: 보강된 벡터 스토어 연결됨")
        elif mcp_vector_store:
            self.mcp_vector_store = mcp_vector_store
            self.enriched_vector_enabled = False
            connections_made += 1
            logger.info("✅ WithMetadata 플래너: 기존 벡터 스토어 연결됨")

        # 🔥 핵심 수정: 플래그 강제 설정
        self.metadata_enhanced = connections_made > 0
        self.enriched_mode = getattr(self, "enriched_system_enabled", False) or getattr(
            self, "enriched_vector_enabled", False
        )

        logger.info(f"🎯 WithMetadata 플래너 상태 업데이트:")
        logger.info(f"   - connections_made: {connections_made}")
        logger.info(f"   - metadata_enhanced: {self.metadata_enhanced}")
        logger.info(f"   - enriched_mode: {self.enriched_mode}")

        return self.metadata_enhanced

    async def _create_metadata_enhanced_planning_prompt(
        self,
        query: str,
        routing_decision: RoutingDecision,
        recommended_tools_metadata,
        detailed_tool_metadata: Dict,
    ) -> str:
        """메타데이터를 활용한 계획 수립 프롬프트 생성 - 도구 매칭 강화"""

        prompt_parts = [
            "당신은 MCP 메타데이터를 활용하여 복잡한 작업을 하위 작업으로 분해하는 전문가입니다.",
            "",
            f"사용자 요청: {query}",
            "",
        ]

        # 🔥 중요: 사용 가능한 실제 도구명을 정확히 나열
        if self.available_tools:
            prompt_parts.extend(
                ["## 🛠️ 사용 가능한 실제 도구명 (정확히 이 이름들만 사용하세요):", ""]
            )

            # 카테고리별로 정리
            web_tools = [
                t.name
                for t in self.available_tools
                if any(
                    kw in t.name.lower()
                    for kw in ["browser", "hyperbrowser", "navigate"]
                )
            ]
            search_tools = [
                t.name
                for t in self.available_tools
                if any(kw in t.name.lower() for kw in ["search", "perplexity"])
            ]
            file_tools = [
                t.name
                for t in self.available_tools
                if any(kw in t.name.lower() for kw in ["file", "write", "save"])
            ]

            if web_tools:
                prompt_parts.append("### 웹 브라우징 도구:")
                for tool in web_tools[:3]:
                    prompt_parts.append(f"- `{tool}`")
                prompt_parts.append("")

            if search_tools:
                prompt_parts.append("### 검색 도구:")
                for tool in search_tools[:3]:
                    prompt_parts.append(f"- `{tool}`")
                prompt_parts.append("")

            if file_tools:
                prompt_parts.append("### 파일 처리 도구:")
                for tool in file_tools[:3]:
                    prompt_parts.append(f"- `{tool}`")
                prompt_parts.append("")

        # 🔥 쿼리별 구체적 예시 제공
        query_lower = query.lower()
        prompt_parts.extend(["## 📝 작업 분해 예시 (이 형식을 정확히 따르세요):", ""])

        if "naver" in query_lower and "usb" in query_lower:
            prompt_parts.extend(
                [
                    "SUBTASK_1:",
                    "name: 네이버 쇼핑 USB-C 케이블 검색",
                    "description: 네이버 쇼핑에서 USB-C 타입 케이블을 검색하고 상품 정보를 수집합니다",
                    f"required_tools: [{web_tools[0] if web_tools else 'hyperbrowser_navigate_to'}]",
                    "dependencies: []",
                    "priority: 5",
                    "duration: 7",
                    "",
                    "SUBTASK_2:",
                    "name: 추천 목록 작성",
                    "description: 검색된 상품들 중에서 가장 적합한 3개를 선별하여 URL과 함께 추천 목록을 작성합니다",
                    "required_tools: []",
                    "dependencies: [task_1]",
                    "priority: 4",
                    "duration: 3",
                    "",
                ]
            )

            if "wiki" in query_lower:
                prompt_parts.extend(
                    [
                        "SUBTASK_3:",
                        "name: 위키피디아 유박비료 정보 검색",
                        "description: 위키피디아에서 유박비료에 대한 정보를 검색하고 관련 내용을 추출합니다",
                        f"required_tools: [{web_tools[0] if web_tools else 'hyperbrowser_navigate_to'}]",
                        "dependencies: []",
                        "priority: 4",
                        "duration: 5",
                        "",
                    ]
                )

            if "저장" in query_lower or ".md" in query_lower:
                prompt_parts.extend(
                    [
                        f"SUBTASK_{4 if 'wiki' in query_lower else 3}:",
                        "name: 마크다운 파일 저장",
                        "description: 수집된 모든 정보를 마크다운 형식으로 정리하여 지정된 경로에 저장합니다",
                        f"required_tools: [{file_tools[0] if file_tools else 'write_file'}]",
                        "dependencies: [task_1, task_2"
                        + (", task_3" if "wiki" in query_lower else "")
                        + "]",
                        "priority: 3",
                        "duration: 2",
                        "",
                    ]
                )

        prompt_parts.extend(
            [
                "## 🚨 중요한 규칙:",
                "1. **정확한 도구명**: 위 '사용 가능한 실제 도구명' 목록의 정확한 이름만 사용",
                "2. **SUBTASK_ 형식**: 반드시 SUBTASK_1:, SUBTASK_2: 형식으로 시작",
                "3. **필수 필드**: name, description, required_tools, dependencies, priority, duration 모두 포함",
                "4. **의미있는 이름**: 'Task task_1' 같은 이름 금지, 구체적인 작업명 사용",
                "5. **도구 배열**: required_tools는 [도구명1, 도구명2] 형식으로 작성",
                "",
                f"위 규칙에 따라 '{query}' 작업을 분해해주세요.",
            ]
        )

        return "\n".join(prompt_parts)

    def _create_query_based_default_subtasks(self, query: str) -> List[SubTask]:
        """쿼리 기반 기본 하위 작업 생성 - 도구 매핑 강화"""
        subtasks = []
        query_lower = query.lower()
        available_tool_names = {tool.name: tool for tool in self.available_tools}

        logger.info(f"🔧 쿼리 기반 기본 작업 생성: {query}")
        logger.info(f"   사용 가능한 도구: {list(available_tool_names.keys())}")

        # 🔥 더 정교한 패턴 매칭
        if "naver" in query_lower and "usb" in query_lower:
            # 웹 브라우징 도구 찾기
            browser_tools = [
                name
                for name in available_tool_names.keys()
                if any(
                    kw in name.lower() for kw in ["browser", "hyperbrowser", "navigate"]
                )
            ]

            subtasks.append(
                SubTask(
                    id="naver_shopping_search",
                    name="네이버 쇼핑 USB-C 케이블 검색",
                    description="네이버 쇼핑에서 USB-C 케이블을 검색하고 상품 정보를 수집합니다",
                    required_tools=browser_tools[:2] if browser_tools else [],
                    dependencies=[],
                    priority=5,
                    estimated_duration=7,
                )
            )

            subtasks.append(
                SubTask(
                    id="product_recommendation",
                    name="USB-C 케이블 3개 추천 작성",
                    description="검색된 상품들을 분석하여 URL과 함께 3개 추천 목록을 작성합니다",
                    required_tools=[],  # LLM으로 처리
                    dependencies=["naver_shopping_search"],
                    priority=4,
                    estimated_duration=3,
                )
            )

        if "wiki" in query_lower and "유박비료" in query_lower:
            browser_tools = [
                name
                for name in available_tool_names.keys()
                if any(kw in name.lower() for kw in ["browser", "hyperbrowser"])
            ]

            subtasks.append(
                SubTask(
                    id="wiki_fertilizer_search",
                    name="위키피디아 유박비료 정보 검색",
                    description="위키피디아에서 유박비료에 대한 정보를 검색하고 내용을 추출합니다",
                    required_tools=browser_tools[:1] if browser_tools else [],
                    dependencies=[],
                    priority=4,
                    estimated_duration=5,
                )
            )

        if any(kw in query_lower for kw in ["저장", "save", ".md", "markdown"]):
            file_tools = [
                name
                for name in available_tool_names.keys()
                if any(kw in name.lower() for kw in ["file", "write", "save"])
            ]

            # 이전 모든 작업에 의존
            prev_task_ids = [task.id for task in subtasks]

            subtasks.append(
                SubTask(
                    id="markdown_file_save",
                    name="마크다운 파일 생성 및 저장",
                    description="수집된 모든 정보를 마크다운 형식으로 정리하여 파일에 저장합니다",
                    required_tools=file_tools[:1] if file_tools else [],
                    dependencies=prev_task_ids,
                    priority=3,
                    estimated_duration=2,
                )
            )

        # 기본 작업도 없으면 최소 1개 생성
        if not subtasks:
            general_tools = [
                name
                for name in available_tool_names.keys()
                if any(kw in name.lower() for kw in ["search", "browser"])
            ]

            subtasks.append(
                SubTask(
                    id="general_information_task",
                    name="정보 검색 및 처리",
                    description=f"'{query}' 요청을 처리하기 위한 정보를 검색하고 분석합니다",
                    required_tools=general_tools[:1] if general_tools else [],
                    dependencies=[],
                    priority=4,
                    estimated_duration=5,
                )
            )

        # 🔥 최종 검증: 모든 작업이 적절한 이름과 도구를 가지는지 확인
        for task in subtasks:
            if not task.name or task.name.startswith("Task "):
                logger.warning(f"⚠️ 부적절한 작업 이름 수정: {task.id}")
                task.name = (
                    f"작업: {task.description[:30]}..."
                    if task.description
                    else f"기본 작업 {task.id}"
                )

            if not task.required_tools:
                logger.info(f"ℹ️ 도구가 없는 작업: {task.name} (LLM 직접 처리)")

        logger.info(f"✅ 기본 작업 생성 완료: {len(subtasks)}개")
        for i, task in enumerate(subtasks, 1):
            logger.info(f"   {i}. {task.name} (도구: {len(task.required_tools)}개)")

        return subtasks

    def _parse_subtasks_with_metadata(
        self, response: str, query: str, detailed_tool_metadata: Dict
    ) -> List[SubTask]:
        """메타데이터 정보를 포함한 하위 작업 파싱 - 도구 검증 강화"""
        subtasks = []

        try:
            lines = response.split("\n")
            current_task = {}
            task_id = 1

            for line in lines:
                line = line.strip()

                if line.startswith("SUBTASK_"):
                    if current_task:
                        # 이전 작업 저장 (도구 검증 강화)
                        subtask = self._create_subtask_with_validated_tools(
                            current_task, f"task_{task_id}", detailed_tool_metadata
                        )
                        if subtask:
                            subtasks.append(subtask)
                        task_id += 1
                    current_task = {}

                elif ":" in line and current_task is not None:
                    key, value = line.split(":", 1)
                    current_task[key.strip().lower()] = value.strip()

            # 마지막 작업 저장
            if current_task:
                subtask = self._create_subtask_with_validated_tools(
                    current_task, f"task_{task_id}", detailed_tool_metadata
                )
                if subtask:
                    subtasks.append(subtask)

        except Exception as e:
            logger.error(f"메타데이터 기반 하위 작업 파싱 오류: {e}")
            # 🔥 폴백: 쿼리 기반 기본 작업 생성
            return self._create_query_based_default_subtasks(query)

        return (
            subtasks if subtasks else self._create_query_based_default_subtasks(query)
        )

    def _create_subtask_with_validated_tools(
        self, task_dict: Dict, task_id: str, detailed_tool_metadata: Dict
    ) -> Optional[SubTask]:
        """검증된 도구를 가진 SubTask 객체 생성 - 개선된 버전"""
        try:
            name = task_dict.get("name", f"Task {task_id}")
            description = task_dict.get("description", "")

            # 🔥 도구 파싱 및 검증 개선
            tools_str = task_dict.get("required_tools", "[]")
            raw_tools = self._parse_tool_string(tools_str)

            # 🔥 도구 검증 및 매칭 개선
            validated_tools = []
            for raw_tool in raw_tools:
                # 1. 정확한 매칭 시도
                exact_matches = [
                    t.name
                    for t in self.available_tools
                    if t.name.lower() == raw_tool.lower()
                ]
                if exact_matches:
                    validated_tools.extend(exact_matches)
                    continue

                # 2. 부분 매칭 시도
                partial_matches = [
                    t.name
                    for t in self.available_tools
                    if raw_tool.lower() in t.name.lower()
                    or t.name.lower() in raw_tool.lower()
                ]
                if partial_matches:
                    validated_tools.extend(partial_matches[:1])  # 첫 번째만
                    continue

                # 3. MCP 메타데이터 기반 매칭
                metadata_matches = self._find_tools_by_metadata(
                    raw_tool, detailed_tool_metadata
                )
                validated_tools.extend(metadata_matches)

            # 🔥 매칭된 도구가 없으면 작업 기반 추천
            if not validated_tools:
                task_obj = SubTask(
                    id=task_id,
                    name=name,
                    description=description,
                    required_tools=[],
                    dependencies=[],
                    priority=3,
                    estimated_duration=5,
                )
                suggested_tools = self._recommend_tools_by_task_content(task_obj)
                validated_tools = [t.name for t in suggested_tools]

            # 나머지 SubTask 생성 로직...
            subtask = SubTask(
                id=task_id,
                name=name,
                description=description,
                required_tools=list(set(validated_tools))[:3],  # 중복 제거 후 최대 3개
                dependencies=self._parse_dependencies(
                    task_dict.get("dependencies", "[]")
                ),
                priority=int(task_dict.get("priority", "3")),
                estimated_duration=int(task_dict.get("duration", "5")),
            )

            return subtask

        except Exception as e:
            logger.error(f"검증된 SubTask 생성 오류: {e}")
            return None

    def _parse_tool_string(self, tools_str: str) -> List[str]:
        """도구 문자열 파싱 개선"""
        if not tools_str or tools_str.strip() in ["[]", ""]:
            return []

        # 대괄호 제거
        cleaned = tools_str.strip()
        if cleaned.startswith("[") and cleaned.endswith("]"):
            cleaned = cleaned[1:-1]

        # 쉼표로 분리하고 정리
        tools = []
        for tool in cleaned.split(","):
            clean_tool = tool.strip().strip('"').strip("'").strip()
            if clean_tool:
                tools.append(clean_tool)

        return tools

    def _find_tools_by_metadata(self, raw_tool: str, metadata: Dict) -> List[str]:
        """메타데이터 기반 도구 매칭"""
        matches = []
        raw_lower = raw_tool.lower()

        for tool_name, tool_meta in metadata.items():
            # 카테고리 매칭
            if raw_lower in tool_meta.get("category", "").lower():
                if any(t.name == tool_name for t in self.available_tools):
                    matches.append(tool_name)

            # use_cases 매칭
            use_cases = tool_meta.get("use_cases", [])
            if any(raw_lower in uc.lower() for uc in use_cases):
                if any(t.name == tool_name for t in self.available_tools):
                    matches.append(tool_name)

        return matches[:2]  # 최대 2개

    def _fuzzy_match(self, str1: str, str2: str, threshold: float = 0.6) -> bool:
        """간단한 퍼지 매칭 (편집 거리 기반)"""
        try:
            # 간단한 유사도 계산 (공통 문자열 비율)
            common_chars = sum(1 for c in str1 if c in str2)
            similarity = common_chars / max(len(str1), len(str2), 1)
            return similarity >= threshold
        except:
            return False

    def _assign_default_tools_by_task_type(
        self, task_name: str, task_description: str
    ) -> List[str]:
        """작업 유형에 따른 기본 도구 할당"""
        task_text = f"{task_name} {task_description}".lower()
        available_tool_names = [tool.name for tool in self.available_tools]

        assigned_tools = []

        # 웹 브라우징/검색 작업
        if any(
            kw in task_text
            for kw in [
                "웹",
                "web",
                "사이트",
                "site",
                "브라우징",
                "browser",
                "네이버",
                "naver",
                "검색",
            ]
        ):
            browser_tools = [
                name
                for name in available_tool_names
                if "browser" in name.lower() or "navigate" in name.lower()
            ]
            assigned_tools.extend(browser_tools[:2])

        # 파일 저장 작업
        if any(
            kw in task_text
            for kw in ["저장", "save", "파일", "file", "markdown", ".md"]
        ):
            file_tools = [
                name
                for name in available_tool_names
                if any(kw in name.lower() for kw in ["file", "write", "save"])
            ]
            assigned_tools.extend(file_tools[:2])

        # 정보 검색 작업
        if any(
            kw in task_text
            for kw in ["정보", "info", "검색", "search", "조회", "query"]
        ):
            search_tools = [
                name
                for name in available_tool_names
                if "search" in name.lower() or "perplexity" in name.lower()
            ]
            assigned_tools.extend(search_tools[:1])

        # 데이터 추출 작업
        if any(
            kw in task_text for kw in ["추출", "extract", "수집", "collect", "스크래핑"]
        ):
            extract_tools = [
                name
                for name in available_tool_names
                if any(kw in name.lower() for kw in ["extract", "scrape", "get"])
            ]
            assigned_tools.extend(extract_tools[:1])

        # 기본 도구가 없으면 범용 도구 할당
        if not assigned_tools:
            # 가장 범용적인 도구들 선택
            general_tools = [
                name
                for name in available_tool_names
                if any(kw in name.lower() for kw in ["search", "browser", "file"])
            ]
            assigned_tools = general_tools[:1]

        return list(set(assigned_tools))  # 중복 제거

    def _create_query_based_default_subtasks(self, query: str) -> List[SubTask]:
        """쿼리 기반 기본 하위 작업 생성 - 이름 설정 개선"""
        subtasks = []
        query_lower = query.lower()

        available_tool_names = [tool.name for tool in self.available_tools]

        # 🔥 수정: 네이버 쇼핑 + USB 케이블 패턴
        if "naver" in query_lower and "usb" in query_lower:
            browser_tools = [
                name
                for name in available_tool_names
                if "browser" in name.lower() or "navigate" in name.lower()
            ]

            # ✅ 수정: name을 명확히 설정
            subtasks.append(
                SubTask(
                    id="naver_shopping_search",
                    name="네이버 쇼핑 USB-C 케이블 검색",  # ← 명확한 이름
                    description="네이버 쇼핑에서 USB-C 케이블을 검색하고 상품 정보를 수집합니다",
                    required_tools=browser_tools[:2] if browser_tools else [],
                    dependencies=[],
                    priority=5,
                    estimated_duration=7,
                )
            )

            # 위키 검색 작업 추가
            if "wiki" in query_lower and "유박비료" in query_lower:
                subtasks.append(
                    SubTask(
                        id="wiki_fertilizer_search",
                        name="위키피디아 유박비료 정보 검색",  # ← 명확한 이름
                        description="위키피디아에서 유박비료에 대한 정보를 검색하고 내용을 추출합니다",
                        required_tools=browser_tools[:1] if browser_tools else [],
                        dependencies=[],
                        priority=4,
                        estimated_duration=5,
                    )
                )

            # 추천 목록 작성 작업
            if "추천" in query_lower or "3개" in query_lower:
                subtasks.append(
                    SubTask(
                        id="recommendation_analysis",
                        name="USB-C 케이블 추천 분석",  # ← 명확한 이름
                        description="검색된 상품들을 분석하여 3개 추천 목록을 작성합니다",
                        required_tools=[],  # LLM으로 처리
                        dependencies=["naver_shopping_search"],
                        priority=4,
                        estimated_duration=3,
                    )
                )

        # 🔥 수정: 파일 저장 패턴
        if any(kw in query_lower for kw in ["저장", "save", ".md", "markdown"]):
            file_tools = [
                name
                for name in available_tool_names
                if any(kw in name.lower() for kw in ["file", "write", "save"])
            ]

            subtasks.append(
                SubTask(
                    id="markdown_file_save",
                    name="마크다운 파일 생성 및 저장",  # ← 명확한 이름
                    description="수집된 모든 정보를 마크다운 형식으로 정리하여 /content/test.md 파일에 저장합니다",
                    required_tools=file_tools[:2] if file_tools else [],
                    dependencies=[
                        task.id for task in subtasks
                    ],  # 이전 모든 작업에 의존
                    priority=3,
                    estimated_duration=2,
                )
            )

        # 🔥 핵심 수정: 기본 작업 생성 시에도 명확한 이름
        if not subtasks:
            search_tools = [
                name
                for name in available_tool_names
                if "search" in name.lower() or "perplexity" in name.lower()
            ]

            subtasks.append(
                SubTask(
                    id="general_information_task",
                    name="정보 검색 및 처리",  # ← 기본값도 의미있는 이름
                    description=f"'{query}' 요청을 처리하기 위한 정보를 검색하고 분석합니다",
                    required_tools=search_tools[:1] if search_tools else [],
                    dependencies=[],
                    priority=4,
                    estimated_duration=5,
                )
            )

        # 🔥 추가 검증: 생성된 작업들의 이름 확인
        for task in subtasks:
            if not task.name or task.name.startswith("Task "):
                logger.warning(f"⚠️ 작업 이름 오류 감지: {task.id} -> {task.name}")
                # 자동 수정
                task.name = f"작업 {task.id.replace('_', ' ').title()}"
                logger.info(f"🔧 자동 수정됨: {task.name}")

        logger.info(f"✅ 쿼리 기반 기본 작업 생성: {len(subtasks)}개")
        for task in subtasks:
            logger.info(f"   - ID: {task.id}, Name: {task.name}")

        return subtasks

    def _create_subtask_with_validated_tools(
        self, task_dict: Dict, task_id: str, detailed_tool_metadata: Dict
    ) -> Optional[SubTask]:
        """검증된 도구를 가진 SubTask 객체 생성 - 개선된 버전"""
        try:
            # 이름 생성 (개선됨)
            name = self._generate_meaningful_task_name(task_dict, task_id)
            description = task_dict.get("description", f"{name}을 수행합니다")

            logger.info(f"🔧 SubTask 생성: {task_id}")
            logger.info(f"  이름: {name}")
            logger.info(f"  설명: {description[:100]}...")

            # 🔥 도구 파싱 및 검증 개선
            tools_str = task_dict.get("required_tools", "[]")
            raw_tools = self._parse_tool_string(tools_str)
            logger.info(f"  원본 도구: {raw_tools}")

            # 🔥 단계별 도구 매칭
            validated_tools = []

            # 1단계: 정확한 매칭
            for raw_tool in raw_tools:
                exact_match = self._find_exact_tool_match_enhanced(raw_tool)
                if exact_match:
                    validated_tools.append(exact_match)
                    logger.info(f"    ✅ 정확 매칭: {raw_tool} → {exact_match}")
                else:
                    logger.warning(f"    ❌ 매칭 실패: {raw_tool}")

            # 2단계: 매칭된 도구가 없으면 작업 기반 추천
            if not validated_tools:
                logger.info("  🔄 작업 기반 도구 추천 시도...")
                suggested_tools = self._recommend_tools_by_task_semantics(
                    name, description
                )
                validated_tools = [tool.name for tool in suggested_tools]
                logger.info(f"    🎯 추천된 도구: {validated_tools}")

            # 3단계: 여전히 없으면 강제 할당
            if not validated_tools:
                logger.warning("  ⚠️ 강제 도구 할당...")
                fallback_tools = self._assign_fallback_tools_by_query_pattern(
                    task_dict, task_id
                )
                validated_tools = fallback_tools
                logger.info(f"    🆘 강제 할당: {validated_tools}")

            subtask = SubTask(
                id=task_id,
                name=name,
                description=description,
                required_tools=validated_tools[:3],  # 최대 3개
                dependencies=self._parse_dependencies(
                    task_dict.get("dependencies", "[]")
                ),
                priority=int(task_dict.get("priority", "3")),
                estimated_duration=int(task_dict.get("duration", "5")),
            )

            logger.info(f"✅ SubTask 생성 완료: {name} (도구 {len(validated_tools)}개)")
            return subtask

        except Exception as e:
            logger.error(f"SubTask 생성 오류: {e}")
            return None

    # 위에서 정의한 모든 헬퍼 메서드들을 여기에도 포함
    def _parse_tool_string(self, tools_str: str) -> List[str]:
        """도구 문자열 파싱"""
        if not tools_str or tools_str.strip() in ["[]", "", "None", "null"]:
            return []

        # 대괄호 제거
        cleaned = tools_str.strip()
        if cleaned.startswith("[") and cleaned.endswith("]"):
            cleaned = cleaned[1:-1]

        # 쉼표로 분리하고 정리
        tools = []
        for tool in cleaned.split(","):
            clean_tool = tool.strip().strip('"').strip("'").strip()
            if clean_tool and clean_tool.lower() not in ["none", "null", ""]:
                tools.append(clean_tool)

        return tools

    def _parse_dependencies(self, deps_str: str) -> List[str]:
        """의존성 문자열 파싱"""
        if not deps_str or deps_str.strip() in ["[]", "", "None", "null"]:
            return []

        # 대괄호 제거
        cleaned = deps_str.strip()
        if cleaned.startswith("[") and cleaned.endswith("]"):
            cleaned = cleaned[1:-1]

        # 쉼표로 분리하고 정리
        dependencies = []
        for dep in cleaned.split(","):
            clean_dep = dep.strip().strip('"').strip("'").strip()
            if clean_dep and clean_dep.lower() not in ["none", "null", ""]:
                dependencies.append(clean_dep)

        return dependencies

    def _find_exact_tool_match_enhanced(self, raw_tool: str) -> Optional[str]:
        """향상된 정확한 도구 매칭"""
        if not self.available_tools:
            return None

        raw_lower = raw_tool.lower().strip()

        # 1. 정확한 이름 매칭
        for tool in self.available_tools:
            if tool.name.lower() == raw_lower:
                return tool.name

        # 2. 부분 매칭 (언더스코어 고려)
        for tool in self.available_tools:
            tool_name_lower = tool.name.lower()
            if raw_lower in tool_name_lower or tool_name_lower in raw_lower:
                return tool.name

            # 키워드 매칭
            raw_keywords = set(raw_lower.split("_"))
            tool_keywords = set(tool_name_lower.split("_"))
            if raw_keywords.intersection(tool_keywords):
                return tool.name

        return None

    def _recommend_tools_by_task_semantics(
        self, task_name: str, task_description: str
    ) -> List:
        """작업 의미 기반 도구 추천"""
        if not self.available_tools:
            return []

        task_text = f"{task_name} {task_description}".lower()
        recommended = []

        # 더 정교한 패턴 매칭
        patterns = {
            "naver_shopping": {
                "keywords": ["naver", "네이버", "shopping", "쇼핑", "usb"],
                "tools": ["hyperbrowser", "browser"],
            },
            "wiki_search": {
                "keywords": ["wiki", "위키", "wikipedia", "유박비료"],
                "tools": ["hyperbrowser", "browser", "search"],
            },
            "file_save": {
                "keywords": ["저장", "save", "markdown", ".md", "파일"],
                "tools": ["file", "write", "filesystem"],
            },
            "web_search": {
                "keywords": ["검색", "search", "찾기", "find"],
                "tools": ["search", "perplexity"],
            },
        }

        for pattern_name, pattern_data in patterns.items():
            if any(keyword in task_text for keyword in pattern_data["keywords"]):
                for tool_type in pattern_data["tools"]:
                    matching_tools = [
                        t for t in self.available_tools if tool_type in t.name.lower()
                    ]
                    recommended.extend(matching_tools[:1])  # 각 타입당 1개

        return recommended[:3]  # 최대 3개

    def _assign_fallback_tools_by_query_pattern(
        self, task_dict: Dict, task_id: str
    ) -> List[str]:
        """쿼리 패턴 기반 강제 도구 할당"""
        if not self.available_tools:
            return []

        # task_dict에서 원본 쿼리 패턴 파악
        task_content = (
            f"{task_dict.get('name', '')} {task_dict.get('description', '')}".lower()
        )

        fallback_tools = []

        if any(kw in task_content for kw in ["naver", "usb", "web", "site"]):
            # 웹 브라우징 도구 강제 할당
            browser_tools = [
                t.name
                for t in self.available_tools
                if any(bt in t.name.lower() for bt in ["browser", "hyperbrowser"])
            ]
            fallback_tools.extend(browser_tools[:1])

        if any(kw in task_content for kw in ["search", "find", "wiki"]):
            # 검색 도구 강제 할당
            search_tools = [
                t.name
                for t in self.available_tools
                if any(st in t.name.lower() for st in ["search", "perplexity"])
            ]
            fallback_tools.extend(search_tools[:1])

        if any(kw in task_content for kw in ["save", "markdown", "file"]):
            # 파일 도구 강제 할당
            file_tools = [
                t.name
                for t in self.available_tools
                if any(ft in t.name.lower() for ft in ["file", "write", "save"])
            ]
            fallback_tools.extend(file_tools[:1])

        # 아무것도 매칭되지 않으면 첫 번째 도구라도 할당
        if not fallback_tools and self.available_tools:
            fallback_tools = [self.available_tools[0].name]

        return fallback_tools

    def _generate_meaningful_task_name(self, task_dict: Dict, task_id: str) -> str:
        """의미있는 작업 이름 생성"""
        raw_name = task_dict.get("name", "").strip()
        description = task_dict.get("description", "").strip()

        # 1. 원본 이름이 의미있으면 사용
        if (
            raw_name
            and len(raw_name) > 3
            and raw_name.lower() not in ["task", "subtask", "none"]
        ):
            return raw_name

        # 2. 설명에서 의미있는 이름 추출
        if description:
            desc_lower = description.lower()

            # 특정 패턴 기반 이름 생성
            if "naver" in desc_lower and "usb" in desc_lower:
                return "네이버 쇼핑 USB-C 케이블 검색"
            elif "wiki" in desc_lower and "유박비료" in desc_lower:
                return "위키피디아 유박비료 정보 검색"
            elif "저장" in desc_lower and "markdown" in desc_lower:
                return "마크다운 파일 저장"
            elif "검색" in desc_lower:
                return "정보 검색 작업"
            elif "추출" in desc_lower:
                return "데이터 추출 작업"
            else:
                # 설명의 첫 부분을 이용한 이름 생성
                clean_desc = description.split(".")[0].split("을")[0].split("를")[0]
                return clean_desc[:25] + "..." if len(clean_desc) > 25 else clean_desc

        # 3. 기본 이름
        if task_id.startswith("task_"):
            task_number = task_id.replace("task_", "")
            return f"작업 단계 {task_number}"
        else:
            return task_id.replace("_", " ").title()

    def _extract_meaningful_name_from_description(
        self, description: str, task_id: str
    ) -> str:
        """설명에서 의미있는 작업 이름 추출"""
        desc_lower = description.lower()

        # 특정 패턴 기반 이름 생성
        if "naver" in desc_lower and "usb" in desc_lower:
            return "네이버 쇼핑 USB-C 케이블 검색"
        elif "wiki" in desc_lower and (
            "유박비료" in desc_lower or "fertilizer" in desc_lower
        ):
            return "위키피디아 유박비료 정보 검색"
        elif "저장" in desc_lower and "markdown" in desc_lower:
            return "마크다운 파일 저장"
        elif "검색" in desc_lower:
            return "정보 검색 작업"
        elif "추출" in desc_lower:
            return "데이터 추출 작업"
        else:
            # 설명의 첫 30자를 이용한 이름 생성
            clean_desc = description.split(".")[0].split("을")[0].split("를")[0]
            return clean_desc[:30] + "..." if len(clean_desc) > 30 else clean_desc

    def _generate_fallback_task_name(self, task_id: str) -> str:
        """기본 작업 이름 생성"""
        if task_id.startswith("task_"):
            task_number = task_id.replace("task_", "")
            return f"작업 단계 {task_number}"
        else:
            return task_id.replace("_", " ").title()


# =================================
# 계층적 실행기
# =================================


class HierarchicalExecutor:
    """계층적 계획 실행기 - 수정된 버전"""

    def __init__(
        self, llm_model, available_tools: List, mcp_recommendation_system=None
    ):
        self.llm_model = llm_model  # ✅ LLM 모델 저장
        self.available_tools = available_tools
        # self.mcp_recommendation_system = mcp_recommendation_system
        self.execution_results = {}

        # 🔥 메타데이터 시스템 연결용 속성 초기화
        self.mcp_recommendation_system = None
        self.mcp_vector_store = None
        self.enriched_vector_store = None
        self.mcp_metadata_collector = None
        self.mcp_config_loader = None
        self.enriched_vector_enabled = False
        self.metadata_enhanced = False

    def connect_metadata_systems(
        self,
        mcp_recommendation_system=None,
        mcp_vector_store=None,
        enriched_vector_store=None,
        enriched_recommendation_system=None,
    ):
        """메타데이터 시스템들 연결 - 수정된 버전"""
        connections_made = 0
        if enriched_recommendation_system:
            self.mcp_recommendation_system = enriched_recommendation_system
            self.enriched_system_enabled = True
            connections_made += 1
            logger.info("✅ 계층적 플래너에 보강된 추천 시스템 연결됨")
        elif mcp_recommendation_system:
            self.mcp_recommendation_system = mcp_recommendation_system
            self.enriched_system_enabled = False
            connections_made += 1
            logger.info("✅ 계층적 플래너에 기존 추천 시스템 연결됨")

        if enriched_vector_store:
            self.mcp_vector_store = enriched_vector_store
            self.enriched_vector_enabled = True
            connections_made += 1
            logger.info("✅ 계층적 플래너에 보강된 벡터 스토어 연결됨")
        elif mcp_vector_store:
            self.mcp_vector_store = mcp_vector_store
            self.enriched_vector_enabled = False
            connections_made += 1
            logger.info("✅ 계층적 플래너에 기존 벡터 스토어 연결됨")

        # 🔥 핵심 수정: metadata_enhanced 플래그 명시적 설정
        self.metadata_enhanced = connections_made > 0

        # 🔥 enriched_mode도 설정
        self.enriched_mode = (
            self.enriched_system_enabled or self.enriched_vector_enabled
        )

        if self.metadata_enhanced:
            logger.info(
                f"🎯 계층적 플래너 메타데이터 활용 모드 활성화 ({connections_made}개 연결)"
            )
            logger.info(f"🧠 보강 모드: {'✅' if self.enriched_mode else '❌'}")
        else:
            logger.warning("⚠️ 계층적 플래너 메타데이터 연결 실패")

    def _recommend_tools_by_task_content(
        self, task: SubTask, max_tools: int = 10
    ) -> List:
        """MCP 메타데이터만 활용한 작업 기반 도구 추천"""
        recommended_tools = []

        # 🔥 1. MCP 벡터 스토어에서 직접 검색
        if hasattr(self, "mcp_vector_store") and self.mcp_vector_store:
            try:
                # 작업 설명으로 직접 검색
                search_results = self.mcp_vector_store.search_tools_only(
                    f"{task.name} {task.description}",
                    limit=max_tools * 2,  # 여유있게 검색
                )

                for result in search_results:
                    # 실제 도구와 매칭
                    matched_tool = self._find_tool_by_exact_name(result["entity_name"])
                    if matched_tool and matched_tool not in recommended_tools:
                        recommended_tools.append(matched_tool)
                        logger.info(
                            f"   📊 메타데이터 매칭: {result['server_name']}.{result['entity_name']} (관련도: {result['score']:.2f})"
                        )

                    if len(recommended_tools) >= max_tools:
                        break

            except Exception as e:
                logger.warning(f"메타데이터 기반 추천 실패: {e}")

        # 🔥 2. 메타데이터가 없거나 결과가 부족한 경우만 실제 도구명 기반 매칭
        if len(recommended_tools) < max_tools // 2:  # 절반도 못 찾은 경우만
            additional_tools = self._find_tools_by_actual_names(
                task, max_tools - len(recommended_tools)
            )
            recommended_tools.extend(additional_tools)

        return recommended_tools[:max_tools]

    def _find_tool_by_exact_name(self, tool_name: str):
        """정확한 도구명으로 실제 도구 찾기"""
        for tool in self.available_tools:
            if tool.name == tool_name:
                return tool
            # 부분 매칭도 시도
            if (
                tool_name.lower() in tool.name.lower()
                or tool.name.lower() in tool_name.lower()
            ):
                return tool
        return None

    def _find_tools_by_actual_names(self, task: SubTask, needed_count: int) -> List:
        """실제 사용 가능한 도구명만으로 매칭"""
        task_content = f"{task.name} {task.description}".lower()
        found_tools = []

        # 실제 도구들의 이름과 설명에서 직접 매칭
        for tool in self.available_tools:
            if len(found_tools) >= needed_count:
                break

            tool_name_lower = tool.name.lower()
            tool_desc = getattr(tool, "description", "").lower()

            # 작업 키워드와 실제 도구명/설명 매칭
            task_keywords = task_content.split()

            relevance_score = 0
            for keyword in task_keywords:
                if len(keyword) > 2:  # 2자 이상 키워드만
                    if keyword in tool_name_lower:
                        relevance_score += 2  # 도구명 매칭은 높은 점수
                    elif keyword in tool_desc:
                        relevance_score += 1  # 설명 매칭은 낮은 점수

            if relevance_score > 0:
                found_tools.append((tool, relevance_score))

        # 관련도 순으로 정렬하여 반환
        found_tools.sort(key=lambda x: x[1], reverse=True)
        return [tool for tool, score in found_tools[:needed_count]]

    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """문자열 유사도 계산"""
        try:
            # 간단한 Jaccard 유사도
            set1 = set(str1.split("_"))
            set2 = set(str2.split("_"))

            if not set1 and not set2:
                return 1.0
            if not set1 or not set2:
                return 0.0

            intersection = len(set1.intersection(set2))
            union = len(set1.union(set2))

            return intersection / union if union > 0 else 0.0
        except:
            return 0.0

    def _extract_content(self, content):
        """컨텐츠에서 텍스트 추출"""
        if isinstance(content, list):
            text_parts = []
            for item in content:
                if hasattr(item, "text"):
                    text_parts.append(item.text)
                elif isinstance(item, str):
                    text_parts.append(item)
                elif isinstance(item, dict) and "text" in item:
                    text_parts.append(item["text"])
                else:
                    text_parts.append(str(item))
            return " ".join(text_parts)
        elif isinstance(content, str):
            return content
        else:
            return str(content)

    def _get_task_name(self, plan: ExecutionPlan, task_id: str) -> str:
        """태스크 ID로 태스크 이름 조회"""
        task = next((t for t in plan.subtasks if t.id == task_id), None)
        return task.name if task else task_id

    def _format_tools_with_server_info(self, tools: List) -> str:
        """도구 정보를 MCP 서버명과 함께 포맷팅"""
        if not tools:
            return "도구 없음"

        tool_infos = []
        for tool in tools[:3]:  # 최대 3개만 표시
            # 도구명에서 서버명 추출
            server_name = self._extract_server_name(tool.name)
            if server_name:
                tool_infos.append(f"{server_name}.{tool.name.split('_')[-1]}")
            else:
                tool_infos.append(tool.name)

        result = ", ".join(tool_infos)
        if len(tools) > 3:
            result += f" 외 {len(tools)-3}개"

        return result

    def _extract_server_name(self, tool_name: str) -> str:
        """도구명에서 MCP 서버명 추출"""
        tool_lower = tool_name.lower()

        # 알려진 MCP 서버명 매핑
        server_mappings = {
            "hyperbrowser": "hyperbrowser",
            "browser": "hyperbrowser",
            "perplexity": "perplexity-search",
            "search": "perplexity-search",
            "weather": "weather-mcp",
            "desktop": "desktop-commander",
            "command": "desktop-commander",
            "file": "filesystem",
            "github": "github",
            "slack": "slack",
        }

        for keyword, server in server_mappings.items():
            if keyword in tool_lower:
                return server

        # 도구명에 언더스코어가 있으면 첫 번째 부분을 서버명으로 간주
        if "_" in tool_name:
            return tool_name.split("_")[0]

        return "unknown"

    def _format_used_tools_with_server(self, tool_names: List[str]) -> str:
        """실제 사용된 도구명을 서버명과 함께 포맷팅"""
        if not tool_names:
            return "없음"

        formatted_tools = []
        for tool_name in tool_names[:3]:  # 최대 3개만 표시
            server_name = self._extract_server_name(tool_name)
            if server_name and server_name != "unknown":
                # 서버명.도구명 형태로 표시
                simple_tool_name = tool_name.replace(f"{server_name}_", "").replace(
                    server_name, ""
                )
                if simple_tool_name.startswith("_"):
                    simple_tool_name = simple_tool_name[1:]
                formatted_tools.append(f"{server_name}.{simple_tool_name}")
            else:
                formatted_tools.append(tool_name)

        result = ", ".join(formatted_tools)
        if len(tool_names) > 3:
            result += f" 외 {len(tool_names)-3}개"

        return result

    async def execute_plan(
        self, plan: ExecutionPlan, chat_id: str, callback
    ) -> Dict[str, Any]:
        """계층적 계획 실행"""
        logger.info(
            f"계층적 계획 실행 시작: {plan.plan_id}, {plan.total_subtasks}개 하위 작업"
        )

        # 계획 시작 이벤트
        if callback:
            callback._add_event_to_queue(
                MessageType.PLAN_START,
                f"🎯 계층적 실행 계획 시작 ({plan.total_subtasks}단계)",
                f"총 {plan.estimated_total_time}분 예상, 순서: {' → '.join([self._get_task_name(plan, tid) for tid in plan.execution_order])}",
                f"hierarchical_plan_{plan.plan_id}",
            )

        all_results = []

        # 각 하위 작업 실행
        for step_num, task_id in enumerate(plan.execution_order, 1):
            task = next((t for t in plan.subtasks if t.id == task_id), None)
            if not task:
                continue

            logger.info(
                f"하위 작업 실행 {step_num}/{len(plan.execution_order)}: {task.name}"
            )

            # 단계 시작 이벤트
            if callback:
                callback._add_event_to_queue(
                    MessageType.STEP_START,
                    f"📋 {step_num}단계: {task.name} 시작",
                    f"{task.description} (예상 시간: {task.estimated_duration}분)",
                    f"subtask_{task_id}",
                )

            try:
                # 하위 작업 실행
                result = await self._execute_subtask(task, plan, chat_id, callback)
                self.execution_results[task_id] = result
                all_results.append(result)

                # 단계 완료 이벤트
                if callback:
                    callback._add_event_to_queue(
                        MessageType.STEP_COMPLETE,
                        f"✅ {step_num}단계 완료: {task.name}",
                        f"결과: {result.get('summary', 'N/A')[:100]}",
                        f"subtask_{task_id}_complete",
                    )

            except Exception as e:
                logger.error(f"하위 작업 실행 실패: {task_id} - {e}")

                error_result = {
                    "task_id": task_id,
                    "status": "failed",
                    "error": str(e),
                    "content": f"하위 작업 '{task.name}' 실행 중 오류 발생: {str(e)}",
                    "summary": f"실패: {task.name}",
                }
                self.execution_results[task_id] = error_result
                all_results.append(error_result)

                # 오류 이벤트
                if callback:
                    callback._add_event_to_queue(
                        MessageType.ERROR,
                        f"❌ {step_num}단계 실패: {task.name}",
                        f"오류: {str(e)[:100]}",
                        f"subtask_{task_id}_error",
                    )
                if callback:
                    callback._add_event_to_queue(
                        MessageType.STEP_COMPLETE,
                        f"✅ {step_num}단계 완료: {task.name}",
                        f"결과: {result.get('summary', 'N/A')[:100]}",
                        f"subtask_{task_id}_complete",
                    )

        # 결과 통합
        final_result = await self._synthesize_results(plan, all_results, callback)

        # 계획 완료 이벤트
        if callback:
            callback._add_event_to_queue(
                MessageType.PLAN_COMPLETE,
                f"🎉 계층적 계획 완료: {plan.plan_id}",
                f"{len(all_results)}개 하위 작업 완료, 최종 결과 생성",
                f"hierarchical_plan_{plan.plan_id}_complete",
            )

        return final_result

    async def _execute_subtask(
        self, task: SubTask, plan: ExecutionPlan, chat_id: str, callback
    ) -> Dict[str, Any]:
        """개별 하위 작업 실행 - 이벤트 추가 버전"""

        # 1. 의존성 확인 및 컨텍스트 수집
        context = await self._collect_dependency_context(task, plan)

        # 2. 도구 선택 (MCP 추천 시스템 활용)
        selected_tools = await self._select_tools_for_task(task)

        # 3. 하위 작업 쿼리 생성
        subtask_query = self._generate_subtask_query(task, plan, context)

        # 4. React Agent로 실행
        if selected_tools:
            if MCP_AVAILABLE:
                from langgraph.prebuilt import create_react_agent

                subtask_agent = create_react_agent(
                    self.llm_model, selected_tools, checkpointer=None
                )
            else:
                subtask_agent = self._create_simple_agent()
        else:
            subtask_agent = self._create_simple_agent()

        config = {
            "configurable": {"thread_id": f"{chat_id}_subtask_{task.id}"},
            "callbacks": [callback] if callback else [],
        }

        # ✅ ACTION_START 이벤트 직접 발생
        if callback:
            await self._emit_action_start_event(callback, task.name, subtask_query)

        try:
            # Agent 실행
            result = await asyncio.wait_for(
                subtask_agent.ainvoke(
                    {"messages": [HumanMessage(content=subtask_query)]}, config=config
                ),
                timeout=120,
            )

            if result and "messages" in result and result["messages"]:
                last_message = result["messages"][-1]
                content = self._extract_content(last_message.content)

                # ✅ ACTION_SUCCESS 이벤트 직접 발생
                if callback:
                    await self._emit_action_success_event(callback, task.name, content)

                return {
                    "task_id": task.id,
                    "status": "success",
                    "content": content,
                    "summary": f"{task.name} 완료",
                    "tools_used": (
                        [t.name for t in selected_tools] if selected_tools else []
                    ),
                    "context_used": len(context) > 0,
                }
            else:
                raise Exception("빈 응답 수신")

        except Exception as e:
            # ✅ ACTION_FAIL 이벤트 직접 발생
            if callback:
                await self._emit_action_fail_event(callback, task.name, str(e))
            raise

    # ✅ 헬퍼 메서드들 (클래스 내 별도 메서드로 정의)
    async def _emit_action_start_event(
        self, callback, action_name: str, description: str
    ):
        """ACTION_START 이벤트 발생"""
        try:
            if hasattr(callback, "_add_event_to_queue"):
                callback._add_event_to_queue(
                    MessageType.ACTION_START,
                    f"⚡ {action_name} 실행 중...",
                    (
                        description[:100] + "..."
                        if len(description) > 100
                        else description
                    ),
                    f"action_{action_name}_{int(time.time())}",
                )
        except Exception as e:
            logger.error(f"ACTION_START 이벤트 발생 실패: {e}")

    async def _emit_action_success_event(self, callback, action_name: str, result: str):
        """ACTION_SUCCESS 이벤트 발생"""
        try:
            if hasattr(callback, "_add_event_to_queue"):
                callback._add_event_to_queue(
                    MessageType.ACTION_SUCCESS,
                    f"✅ {action_name} 실행 성공",
                    result[:100] + "..." if len(result) > 100 else result,
                    f"action_{action_name}_success_{int(time.time())}",
                )
        except Exception as e:
            logger.error(f"ACTION_SUCCESS 이벤트 발생 실패: {e}")

    async def _emit_action_fail_event(self, callback, action_name: str, error: str):
        """ACTION_FAIL 이벤트 발생"""
        try:
            if hasattr(callback, "_add_event_to_queue"):
                callback._add_event_to_queue(
                    MessageType.ACTION_FAIL,
                    f"❌ {action_name} 실행 실패",
                    error[:100] + "..." if len(error) > 100 else error,
                    f"action_{action_name}_fail_{int(time.time())}",
                )
        except Exception as e:
            logger.error(f"ACTION_FAIL 이벤트 발생 실패: {e}")

    def _create_simple_agent(self):
        """도구가 없을 때 사용할 간단한 agent - 수정된 버전"""

        class SimpleAgent:
            def __init__(self, llm_model):
                self.llm_model = llm_model

            async def ainvoke(self, input_data, config=None):
                try:
                    messages = input_data.get("messages", [])
                    if messages:
                        # ✅ 수정: 메시지 객체를 올바르게 처리
                        last_message = messages[-1]
                        if hasattr(last_message, "content"):
                            content = last_message.content
                        else:
                            content = str(last_message)

                        response = await self.llm_model.ainvoke(
                            [HumanMessage(content=content)]
                        )
                        return {
                            "messages": messages + [AIMessage(content=response.content)]
                        }
                    return {"messages": []}
                except Exception as e:
                    logger.error(f"Simple agent 실행 오류: {e}")
                    return {
                        "messages": [AIMessage(content=f"처리 중 오류 발생: {str(e)}")]
                    }

        return SimpleAgent(self.llm_model)

    async def _collect_dependency_context(
        self, task: SubTask, plan: ExecutionPlan
    ) -> List[Dict]:
        """의존성 작업 결과 수집"""
        context = []

        for dep_id in task.dependencies:
            if dep_id in self.execution_results:
                dep_result = self.execution_results[dep_id]
                context.append(
                    {
                        "task_id": dep_id,
                        "task_name": self._get_task_name(plan, dep_id),
                        "result": dep_result.get("content", ""),
                        "summary": dep_result.get("summary", ""),
                        "status": dep_result.get("status", "unknown"),
                    }
                )

        return context

    async def _select_tools_for_task(self, task: SubTask) -> List:
        """하위 작업별 도구 선택 - MCP 메타데이터 활용 강화"""
        logger.info(f"🔧 도구 선택 시작: {task.name}")

        if not self.available_tools:
            logger.warning("   ⚠️ 사용 가능한 도구가 없음")
            return []

        selected_tools = []
        max_tools = 10  # 최대 10개 선택

        # 🔥 1. MCP 추천 시스템 활용 - 메타데이터 기반
        if (
            hasattr(self, "mcp_recommendation_system")
            and self.mcp_recommendation_system
        ):
            try:
                task_query = f"{task.name}: {task.description}"
                recommendation = await self.mcp_recommendation_system.recommend_tools(
                    task_query, max_servers=5, max_tools=max_tools
                )

                if recommendation and recommendation.recommended_tools:
                    # 추천된 도구를 실제 도구와 정확히 매칭
                    for rec_tool in recommendation.recommended_tools:
                        # 서버명과 도구명을 기반으로 정확한 매칭
                        matched_tool = self._find_exact_tool_match(
                            rec_tool, self.available_tools
                        )
                        if matched_tool and matched_tool not in selected_tools:
                            selected_tools.append(matched_tool)
                            logger.info(
                                f"   ✅ MCP 추천 매칭: {rec_tool.server_name}.{rec_tool.tool_name} → {matched_tool.name}"
                            )

                    if selected_tools:
                        logger.info(
                            f"🎯 MCP 추천 성공: {len(selected_tools)}개 도구 선택"
                        )
                        return selected_tools[:max_tools]

            except Exception as e:
                logger.warning(f"MCP 추천 실패: {e}")

        # 🔥 2. 벡터 스토어 기반 도구 검색 확장
        if hasattr(self, "mcp_vector_store") and self.mcp_vector_store:
            try:
                search_query = f"{task.name} {task.description}"
                # 더 많은 결과 검색
                search_results = self.mcp_vector_store.search_tools_only(
                    search_query, limit=20
                )

                for result in search_results:
                    # 실제 도구와 매칭
                    matched_tool = self._find_tool_by_metadata(
                        result, self.available_tools
                    )
                    if matched_tool and matched_tool not in selected_tools:
                        selected_tools.append(matched_tool)
                        logger.info(
                            f"   🔍 벡터 매칭: {result['server_name']}.{result['entity_name']} → {matched_tool.name}"
                        )

                    if len(selected_tools) >= max_tools:
                        break

                if selected_tools:
                    return selected_tools

            except Exception as e:
                logger.warning(f"벡터 스토어 매칭 실패: {e}")

        # 🔥 3. 폴백: 작업 내용 기반 도구 선택 (확장)
        content_based_tools = self._recommend_tools_by_task_content_enhanced(
            task, max_tools
        )
        selected_tools.extend(
            [tool for tool in content_based_tools if tool not in selected_tools]
        )

        logger.info(f"🎯 최종 선택: {[t.name for t in selected_tools[:max_tools]]}")
        return selected_tools[:max_tools]

    def _recommend_tools_by_task_content_enhanced(
        self, task: SubTask, max_tools: int = 10
    ) -> List:
        """작업 내용 기반 도구 추천 - 확장된 버전"""
        task_content = f"{task.name} {task.description}".lower()
        recommended_tools = []

        # 더 세분화된 패턴 매핑
        tool_patterns = {
            "file_operations": {
                "keywords": [
                    "저장",
                    "save",
                    "파일",
                    "file",
                    "markdown",
                    ".md",
                    "작성",
                    "write",
                    "읽기",
                    "read",
                    "생성",
                    "create",
                ],
                "tool_types": [
                    "file",
                    "write",
                    "save",
                    "read",
                    "create",
                    "filesystem",
                    "document",
                ],
            },
            "web_browsing": {
                "keywords": [
                    "웹",
                    "web",
                    "사이트",
                    "site",
                    "브라우징",
                    "browser",
                    "네이버",
                    "naver",
                    "접속",
                    "navigate",
                ],
                "tool_types": [
                    "browser",
                    "hyperbrowser",
                    "navigate",
                    "web",
                    "click",
                    "scroll",
                    "extract",
                ],
            },
            "search": {
                "keywords": [
                    "검색",
                    "search",
                    "찾기",
                    "find",
                    "조회",
                    "query",
                    "정보",
                    "perplexity",
                ],
                "tool_types": ["search", "perplexity", "query", "find", "lookup"],
            },
            "data_extraction": {
                "keywords": [
                    "추출",
                    "extract",
                    "수집",
                    "collect",
                    "스크래핑",
                    "scrape",
                    "가져오기",
                    "get",
                ],
                "tool_types": [
                    "extract",
                    "scrape",
                    "get",
                    "collect",
                    "fetch",
                    "retrieve",
                ],
            },
        }

        # 패턴별 도구 수집
        for pattern_name, pattern_data in tool_patterns.items():
            if any(keyword in task_content for keyword in pattern_data["keywords"]):
                for tool_type in pattern_data["tool_types"]:
                    matching_tools = [
                        t
                        for t in self.available_tools
                        if tool_type in t.name.lower() and t not in recommended_tools
                    ]
                    recommended_tools.extend(matching_tools[:2])  # 각 타입당 최대 2개

        # 중복 제거 및 제한
        unique_tools = []
        seen = set()
        for tool in recommended_tools:
            if tool.name not in seen:
                seen.add(tool.name)
                unique_tools.append(tool)

        return unique_tools[:max_tools]

    def _find_exact_tool_match(self, rec_tool, available_tools) -> Optional:
        """MCP 추천 도구와 실제 도구의 정확한 매칭"""
        # 1. 정확한 도구명 매칭
        for tool in available_tools:
            if tool.name == rec_tool.tool_name:
                return tool

        # 2. 서버명 + 도구명 조합 매칭
        expected_names = [
            f"{rec_tool.server_name}_{rec_tool.tool_name}",
            f"{rec_tool.server_name}.{rec_tool.tool_name}",
            f"{rec_tool.server_name}-{rec_tool.tool_name}",
        ]

        for tool in available_tools:
            for expected in expected_names:
                if tool.name.lower() == expected.lower():
                    return tool

        # 3. 부분 매칭
        for tool in available_tools:
            if (
                rec_tool.tool_name.lower() in tool.name.lower()
                and rec_tool.server_name.lower() in tool.name.lower()
            ):
                return tool

        return None

    def _find_tool_by_metadata(self, metadata_result, available_tools) -> Optional:
        """메타데이터 결과와 실제 도구 매칭"""
        tool_name = metadata_result["entity_name"]
        server_name = metadata_result.get("server_name", "")

        # 정확한 매칭 시도
        for tool in available_tools:
            if tool.name == tool_name:
                return tool

            # 서버명 조합 매칭
            if server_name:
                expected_names = [
                    f"{server_name}_{tool_name}",
                    f"{server_name}.{tool_name}",
                    f"{server_name}-{tool_name}",
                ]

                for expected in expected_names:
                    if tool.name.lower() == expected.lower():
                        return tool

        return None

    def _extract_server_name_from_metadata(self, tool_name: str) -> str:
        """MCP 메타데이터에서 실제 서버명 추출"""
        # 🔥 메타데이터 벡터 스토어 활용
        if hasattr(self, "mcp_vector_store") and self.mcp_vector_store:
            try:
                # 도구명으로 메타데이터 검색
                search_results = self.mcp_vector_store.search_tools_only(
                    tool_name, limit=1
                )
                if search_results:
                    return search_results[0].get("server_name", "unknown")
            except Exception as e:
                logger.debug(f"메타데이터에서 서버명 추출 실패: {e}")

        # 폴백: 기존 추론 방식
        return self._extract_server_name(tool_name)

    def _format_tools_with_server_info(self, tools: List) -> str:
        """도구 정보를 실제 MCP 서버명과 함께 포맷팅"""
        if not tools:
            return "도구 없음"

        formatted_tools = []
        seen_tools = set()  # 중복 방지

        for tool in tools:
            if tool.name in seen_tools:
                continue
            seen_tools.add(tool.name)

            # 실제 MCP 메타데이터에서 서버명 추출
            server_name = self._extract_server_name_from_metadata(tool.name)

            if server_name and server_name != "unknown":
                formatted_tools.append(f"{server_name}.{tool.name}")
            else:
                formatted_tools.append(tool.name)

        return ", ".join(formatted_tools[:10])  # 최대 10개 표시

    def _fuzzy_match_tools(self, mcp_tool_name: str, actual_tool_name: str) -> bool:
        """MCP 도구명과 실제 도구명 퍼지 매칭"""
        mcp_lower = mcp_tool_name.lower()
        actual_lower = actual_tool_name.lower()

        # 직접 매칭
        if mcp_lower == actual_lower:
            return True

        # 부분 문자열 매칭
        if mcp_lower in actual_lower or actual_lower in mcp_lower:
            return True

        # 키워드 기반 매칭
        mcp_keywords = set(mcp_lower.replace("_", " ").split())
        actual_keywords = set(actual_lower.replace("_", " ").split())

        # 공통 키워드가 50% 이상이면 매칭
        if mcp_keywords and actual_keywords:
            common = mcp_keywords.intersection(actual_keywords)
            return len(common) / len(mcp_keywords.union(actual_keywords)) > 0.5

        return False

    def _calculate_task_tool_relevance(self, task: SubTask, tool_result: Dict) -> float:
        """작업과 도구의 관련성 점수 계산"""
        score = 0.0

        task_text = f"{task.name} {task.description}".lower()

        # use_cases 매칭
        use_cases = tool_result.get("use_cases", [])
        for use_case in use_cases:
            if any(word in use_case.lower() for word in task_text.split()):
                score += 0.3

        # 카테고리 매칭
        category = tool_result.get("category", "").lower()
        if any(word in category for word in task_text.split()):
            score += 0.2

        # 태그 매칭
        tags = tool_result.get("tags", [])
        for tag in tags:
            if tag.lower() in task_text:
                score += 0.1

        # 기본 유사도 점수 반영
        score += tool_result.get("score", 0) * 0.4

        return min(1.0, score)

    def _match_required_tool_to_available(
        self, required_tool: str, available_tools: List
    ) -> List:
        """required_tool을 available_tools에서 찾기"""
        matched = []
        req_lower = required_tool.lower()

        for tool in available_tools:
            tool_lower = tool.name.lower()

            # 정확 매칭
            if req_lower == tool_lower:
                matched.append(tool)
                continue

            # 부분 매칭
            if req_lower in tool_lower or tool_lower in req_lower:
                matched.append(tool)
                continue

            # 키워드 매칭
            req_words = set(req_lower.split("_"))
            tool_words = set(tool_lower.split("_"))

            if req_words.intersection(tool_words):
                matched.append(tool)

        return matched[:2]  # 최대 2개

    def _generate_subtask_query(
        self, task: SubTask, plan: ExecutionPlan, context: List[Dict]
    ) -> str:
        """하위 작업 쿼리 생성 - MCP 메타데이터를 활용한 향상된 버전"""

        # 기본 쿼리 구성
        query_parts = [
            f"하위 작업: {task.name}",
            f"설명: {task.description}",
            f"원본 요청: {plan.query}",
        ]

        # 컨텍스트 추가 (이전 단계 결과)
        if context:
            query_parts.append("\n📋 이전 단계 결과:")
            for ctx in context:
                if ctx["status"] == "success":
                    query_parts.append(f"- {ctx['task_name']}: {ctx['summary']}")
                    if ctx["result"]:
                        # 결과 요약 (너무 길면 자르기)
                        result_preview = (
                            ctx["result"][:200] + "..."
                            if len(ctx["result"]) > 200
                            else ctx["result"]
                        )
                        query_parts.append(f"  내용: {result_preview}")

        # 🔥 MCP 메타데이터 기반 도구 사용 가이드 추가
        if (
            hasattr(self, "mcp_vector_store")
            and self.mcp_vector_store
            and task.required_tools
        ):
            try:
                query_parts.append("\n## 🔧 도구별 사용 가이드 (MCP 메타데이터):")

                for tool_name in task.required_tools:
                    # 각 도구별 상세 메타데이터 검색
                    tool_results = self.mcp_vector_store.search_tools_only(
                        tool_name, limit=1
                    )

                    if tool_results:
                        tool_data = tool_results[0]
                        use_cases = tool_data.get("use_cases", [])
                        parameters = tool_data.get("parameters", [])
                        tags = tool_data.get("tags", [])
                        category = tool_data.get("category", "unknown")
                        description = tool_data.get("description", "")

                        # 도구별 상세 가이드 생성
                        guide_parts = [f"\n### 🛠️ {tool_name} 도구 활용법:"]

                        # 기본 정보
                        if description:
                            guide_parts.append(f"**기능**: {description}")

                        if category != "unknown":
                            guide_parts.append(f"**카테고리**: {category}")

                        # 주요 용도 (use_cases 활용)
                        if use_cases:
                            guide_parts.append(
                                f"**주요 용도**: {', '.join(use_cases[:3])}"
                            )

                            # 현재 작업과 관련된 사용 사례 강조
                            relevant_cases = []
                            for case in use_cases:
                                if any(
                                    keyword in case.lower()
                                    for keyword in [
                                        task.name.lower(),
                                        task.description.lower(),
                                    ]
                                ):
                                    relevant_cases.append(case)

                            if relevant_cases:
                                guide_parts.append(
                                    f"**이 작업에 적합한 용도**: {', '.join(relevant_cases[:2])}"
                                )

                        # 파라미터 정보 (parameters 활용)
                        if parameters:
                            if len(parameters) <= 3:
                                guide_parts.append(
                                    f"**필수 파라미터**: {', '.join(parameters)}"
                                )
                            else:
                                guide_parts.append(
                                    f"**주요 파라미터**: {', '.join(parameters[:3])} (외 {len(parameters)-3}개)"
                                )

                            # 파라미터별 설명 (메타데이터에서 추출)
                            param_details = self._extract_parameter_details(
                                tool_data, task
                            )
                            if param_details:
                                guide_parts.append(
                                    f"**파라미터 설명**: {param_details}"
                                )

                        # 태그 기반 특성 (tags 활용)
                        if tags:
                            special_tags = [
                                tag
                                for tag in tags
                                if tag.lower()
                                in ["automation", "web", "search", "file", "api"]
                            ]
                            if special_tags:
                                guide_parts.append(
                                    f"**특성**: {', '.join(special_tags)}"
                                )

                        # 작업별 맞춤 팁
                        usage_tips = self._generate_task_specific_tips(tool_data, task)
                        if usage_tips:
                            guide_parts.append(
                                f"**이 작업에서의 사용 팁**: {usage_tips}"
                            )

                        query_parts.extend(guide_parts)

                    else:
                        # 메타데이터를 찾을 수 없는 경우 기본 안내
                        query_parts.append(
                            f"\n### 🛠️ {tool_name}: 기본 도구 (메타데이터 없음)"
                        )

                # 🔥 도구 조합 사용법 (여러 도구가 필요한 경우)
                if len(task.required_tools) > 1:
                    query_parts.append(f"\n## 🔗 도구 조합 전략:")
                    query_parts.append(
                        f"이 작업은 {len(task.required_tools)}개 도구를 조합하여 사용합니다:"
                    )

                    # 도구 실행 순서 제안
                    tool_sequence = self._suggest_tool_execution_order(
                        task.required_tools, task
                    )
                    if tool_sequence:
                        query_parts.append(
                            f"**권장 실행 순서**: {' → '.join(tool_sequence)}"
                        )

                    # 도구 간 데이터 전달 방법
                    data_flow = self._suggest_data_flow_between_tools(
                        task.required_tools, task
                    )
                    if data_flow:
                        query_parts.append(f"**데이터 흐름**: {data_flow}")

            except Exception as e:
                logger.warning(f"MCP 메타데이터 기반 도구 가이드 생성 실패: {e}")
                # 폴백: 기본 도구 목록만 표시
                if task.required_tools:
                    query_parts.append(
                        f"\n🔧 사용할 도구: {', '.join(task.required_tools)}"
                    )

        # 🔥 작업별 성공 기준 및 검증 포인트
        success_criteria = self._generate_success_criteria(task, plan)
        if success_criteria:
            query_parts.append(f"\n## ✅ 성공 기준:")
            query_parts.extend(success_criteria)

        # 실행 지침
        execution_guidelines = [
            "\n## 📋 실행 지침:",
            "1. 위의 하위 작업만 집중적으로 수행하세요",
            "2. 이전 단계 결과를 적극 활용하세요",
            "3. MCP 메타데이터 가이드를 참고하여 도구를 효과적으로 사용하세요",
            "4. 구체적이고 실용적인 결과를 제공하세요",
            "5. 현재 단계의 목적에 맞는 정보만 수집하세요",
        ]

        # 도구별 특별 지침
        if task.required_tools:
            tool_specific_guidelines = self._generate_tool_specific_guidelines(
                task.required_tools, task
            )
            if tool_specific_guidelines:
                execution_guidelines.extend(
                    ["6. 도구별 특별 지침:", *tool_specific_guidelines]
                )

        query_parts.extend(execution_guidelines)

        # 최종 작업 요청
        query_parts.extend(
            [
                f"\n## 🎯 최종 요청:",
                f"'{task.name}' 작업을 위해 위의 가이드와 메타데이터를 활용하여 최적의 결과를 생성해주세요.",
            ]
        )

        return "\n".join(query_parts)

    def _extract_parameter_details(self, tool_data: Dict, task: SubTask) -> str:
        """도구 메타데이터에서 파라미터 상세 정보 추출"""
        try:
            metadata = tool_data.get("metadata", {})
            if isinstance(metadata, str):
                import json

                metadata = json.loads(metadata)

            param_details = metadata.get("parameter_details", [])
            if param_details and isinstance(param_details, list):
                # 작업과 관련된 파라미터만 선별
                relevant_params = []
                task_keywords = (
                    task.name.lower().split() + task.description.lower().split()
                )

                for param in param_details[:3]:  # 최대 3개까지
                    param_str = str(param).lower()
                    if any(keyword in param_str for keyword in task_keywords):
                        relevant_params.append(str(param)[:50])

                return "; ".join(relevant_params) if relevant_params else ""
        except Exception as e:
            logger.debug(f"파라미터 상세 정보 추출 실패: {e}")

        return ""

    def _generate_task_specific_tips(self, tool_data: Dict, task: SubTask) -> str:
        """작업별 맞춤 사용 팁 생성"""
        tips = []

        try:
            category = tool_data.get("category", "").lower()
            task_desc = task.description.lower()

            # 카테고리별 작업 맞춤 팁
            if category == "search" and ("검색" in task_desc or "find" in task_desc):
                tips.append("구체적인 검색 키워드를 사용하여 정확한 결과를 얻으세요")

            elif category == "automation" and (
                "자동" in task_desc or "navigate" in task_desc
            ):
                tips.append("단계별로 차근차근 진행하여 안정적인 자동화를 수행하세요")

            elif category == "data_extraction" and (
                "추출" in task_desc or "collect" in task_desc
            ):
                tips.append("필요한 데이터만 선별적으로 추출하여 효율성을 높이세요")

            elif category == "file_operations" and (
                "저장" in task_desc or "save" in task_desc
            ):
                tips.append("파일 경로와 형식을 명확히 지정하여 저장하세요")

            # 태그 기반 추가 팁
            tags = tool_data.get("tags", [])
            if "web" in tags and "웹" in task_desc:
                tips.append("웹페이지 로딩 시간을 고려하여 충분한 대기 시간을 두세요")

            if "api" in tags and "api" in task_desc:
                tips.append("API 호출 시 적절한 파라미터와 헤더를 설정하세요")

        except Exception as e:
            logger.debug(f"작업별 팁 생성 실패: {e}")

        return "; ".join(tips[:2]) if tips else ""

    def _suggest_tool_execution_order(
        self, tools: List[str], task: SubTask
    ) -> List[str]:
        """도구 실행 순서 제안"""
        try:
            # 일반적인 도구 실행 순서 패턴
            order_patterns = {
                "navigation": ["browser", "navigate", "web"],
                "search": ["search", "find", "query"],
                "extraction": ["extract", "scrape", "get"],
                "processing": ["process", "analyze", "transform"],
                "output": ["save", "write", "export", "store"],
            }

            ordered_tools = []
            remaining_tools = tools.copy()

            # 패턴 순서대로 도구 배치
            for pattern_name, pattern_keywords in order_patterns.items():
                for tool in remaining_tools.copy():
                    if any(keyword in tool.lower() for keyword in pattern_keywords):
                        ordered_tools.append(tool)
                        remaining_tools.remove(tool)
                        break

            # 남은 도구들 추가
            ordered_tools.extend(remaining_tools)

            return ordered_tools

        except Exception as e:
            logger.debug(f"도구 실행 순서 제안 실패: {e}")
            return tools

    def _suggest_data_flow_between_tools(self, tools: List[str], task: SubTask) -> str:
        """도구 간 데이터 흐름 제안"""
        try:
            if len(tools) < 2:
                return ""

            flow_suggestions = []

            # 웹 작업 플로우
            if any(
                "browser" in tool.lower() or "web" in tool.lower() for tool in tools
            ):
                if any("search" in tool.lower() for tool in tools):
                    flow_suggestions.append("브라우저로 페이지 접속 → 검색 수행")

                if any(
                    "extract" in tool.lower() or "scrape" in tool.lower()
                    for tool in tools
                ):
                    flow_suggestions.append("웹 탐색 → 데이터 추출")

            # 검색 → 처리 → 저장 플로우
            search_tools = [t for t in tools if "search" in t.lower()]
            save_tools = [
                t
                for t in tools
                if any(kw in t.lower() for kw in ["save", "write", "store"])
            ]

            if search_tools and save_tools:
                flow_suggestions.append("검색 결과 수집 → 데이터 정리 → 파일 저장")

            return " | ".join(flow_suggestions[:2]) if flow_suggestions else ""

        except Exception as e:
            logger.debug(f"데이터 흐름 제안 실패: {e}")
            return ""

    def _generate_success_criteria(
        self, task: SubTask, plan: ExecutionPlan
    ) -> List[str]:
        """작업별 성공 기준 생성"""
        criteria = []

        try:
            task_name_lower = task.name.lower()
            task_desc_lower = task.description.lower()

            # 작업 유형별 성공 기준
            if "검색" in task_name_lower or "search" in task_desc_lower:
                criteria.append("- 관련성 높은 검색 결과를 3개 이상 수집")
                criteria.append("- 각 결과에 대한 URL과 요약 정보 포함")

            elif "추출" in task_name_lower or "extract" in task_desc_lower:
                criteria.append("- 요청된 데이터 필드를 모두 추출")
                criteria.append("- 데이터 형식이 일관성 있게 구조화됨")

            elif "저장" in task_name_lower or "save" in task_desc_lower:
                criteria.append("- 지정된 경로에 파일이 성공적으로 저장됨")
                criteria.append("- 파일 내용이 요청된 형식과 일치함")

            elif "분석" in task_name_lower or "analyze" in task_desc_lower:
                criteria.append("- 수집된 데이터에 대한 의미있는 인사이트 제공")
                criteria.append("- 분석 결과가 구체적이고 실행 가능함")

            # 일반적인 기준
            if not criteria:
                criteria.extend(
                    [
                        "- 작업 목표가 명확히 달성됨",
                        "- 결과물이 다음 단계에서 활용 가능함",
                    ]
                )

            # 품질 기준 추가
            criteria.extend(
                ["- 오류나 누락된 정보가 없음", "- 실행 시간이 합리적인 범위 내"]
            )

        except Exception as e:
            logger.debug(f"성공 기준 생성 실패: {e}")
            criteria = ["- 작업이 성공적으로 완료됨"]

        return criteria

    def _generate_tool_specific_guidelines(
        self, tools: List[str], task: SubTask
    ) -> List[str]:
        """도구별 특별 지침 생성"""
        guidelines = []

        try:
            for tool in tools:
                tool_lower = tool.lower()

                if "browser" in tool_lower or "hyperbrowser" in tool_lower:
                    guidelines.append(
                        f"   - {tool}: 페이지 로딩 완료를 확인하고 요소가 나타날 때까지 대기"
                    )

                elif "search" in tool_lower or "perplexity" in tool_lower:
                    guidelines.append(
                        f"   - {tool}: 구체적이고 명확한 검색어 사용으로 정확도 향상"
                    )

                elif "extract" in tool_lower or "scrape" in tool_lower:
                    guidelines.append(
                        f"   - {tool}: 대상 요소를 정확히 선택하여 불필요한 데이터 제외"
                    )

                elif any(kw in tool_lower for kw in ["save", "write", "file"]):
                    guidelines.append(
                        f"   - {tool}: 파일 경로와 확장자를 정확히 지정하여 저장"
                    )

                elif "command" in tool_lower or "execute" in tool_lower:
                    guidelines.append(
                        f"   - {tool}: 명령어 실행 전 안전성을 검토하고 결과 확인"
                    )

                elif "api" in tool_lower:
                    guidelines.append(
                        f"   - {tool}: API 응답 상태를 확인하고 적절한 오류 처리 수행"
                    )

        except Exception as e:
            logger.debug(f"도구별 지침 생성 실패: {e}")

        return guidelines

    async def _synthesize_results(
        self, plan: ExecutionPlan, results: List[Dict], callback
    ) -> Dict[str, Any]:
        """결과 통합 및 최종 응답 생성"""

        if callback:
            callback._add_event_to_queue(
                MessageType.THINKING,
                "🔄 하위 작업 결과들을 통합하고 있습니다...",
                f"{len(results)}개 하위 작업 결과 종합 중",
                "result_synthesis",
            )

        successful_results = [r for r in results if r.get("status") == "success"]
        failed_results = [r for r in results if r.get("status") == "failed"]

        # 성공한 결과들 통합
        synthesis_parts = [
            f"# {plan.query}에 대한 종합 결과\n",
            f"총 {len(results)}개 하위 작업 중 {len(successful_results)}개 성공\n",
        ]

        if successful_results:
            synthesis_parts.append("## 📋 단계별 실행 결과:\n")

            for i, result in enumerate(successful_results, 1):
                task_name = (
                    result.get("summary", f"작업 {i}").replace("완료", "").strip()
                )
                task_name = task_name if task_name else f"단계 {i}"

                synthesis_parts.extend(
                    [f"### {i}. {task_name}", f"{result.get('content', '')}\n"]
                )

        # 실패한 작업이 있으면 언급
        if failed_results:
            synthesis_parts.extend(
                [
                    "## ⚠️ 처리 중 발생한 문제:",
                    f"{len(failed_results)}개 하위 작업에서 오류가 발생했지만, 가능한 범위에서 결과를 제공합니다.\n",
                ]
            )

        # 최종 요약
        if successful_results:
            synthesis_parts.extend(
                [
                    "## 🎯 최종 요약:",
                    "위의 단계별 결과를 통해 요청하신 내용을 처리했습니다.",
                    f"계층적 접근 방식으로 {len(successful_results)}단계에 걸쳐 체계적으로 분석했습니다.",
                ]
            )

        final_content = "\n".join(synthesis_parts)

        return {
            "content": final_content,
            "description": f"계층적 계획 실행 완료 ({len(successful_results)}/{len(results)} 성공)",
            "summary": f"계층적 처리: {plan.total_subtasks}단계 실행, {len(successful_results)}개 성공",
            "execution_stats": {
                "total_subtasks": len(results),
                "successful_subtasks": len(successful_results),
                "failed_subtasks": len(failed_results),
                "total_time": plan.estimated_total_time,
            },
        }

    def _get_task_name(self, plan: ExecutionPlan, task_id: str) -> str:
        """태스크 ID로 태스크 이름 조회"""
        task = next((t for t in plan.subtasks if t.id == task_id), None)
        return task.name if task else task_id

    def _extract_content(self, content):
        """컨텐츠에서 텍스트 추출"""
        if isinstance(content, list):
            text_parts = []
            for item in content:
                if hasattr(item, "text"):
                    text_parts.append(item.text)
                elif isinstance(item, str):
                    text_parts.append(item)
                elif isinstance(item, dict) and "text" in item:
                    text_parts.append(item["text"])
                else:
                    text_parts.append(str(item))
            return " ".join(text_parts)
        elif isinstance(content, str):
            return content
        else:
            return str(content)


# =================================
# 새로운 메타데이터 통합 계층적 실행기 클래스
# =================================


class EnhancedHierarchicalExecutorWithMetadata(HierarchicalExecutor):
    """메타데이터가 완전히 통합된 계층적 실행기 - 도구 매칭 수정"""

    def __init__(self, llm_model, available_tools: List):
        # 🔥 수정: 부모 클래스의 올바른 __init__ 호출
        super().__init__(llm_model, available_tools)

        # 추가 속성들 초기화
        self.enriched_mode = False
        self.enriched_system_enabled = False
        self.enriched_vector_enabled = False

    def _get_tool_metadata_info(self, tool_name: str) -> Dict[str, Any]:
        """도구의 메타데이터 정보 조회"""
        if hasattr(self, "mcp_vector_store") and self.mcp_vector_store:
            try:
                results = self.mcp_vector_store.search_tools_only(tool_name, limit=1)
                if results:
                    return results[0]
            except Exception as e:
                logger.debug(f"도구 메타데이터 조회 실패: {e}")

        return {}

    def _validate_selected_tools(self, selected_tools: List) -> List:
        """선택된 도구들의 유효성 검증 및 중복 제거"""
        validated_tools = []
        seen_names = set()

        for tool in selected_tools:
            if tool.name not in seen_names:
                # 도구가 실제로 사용 가능한지 확인
                if hasattr(tool, "name") and hasattr(tool, "__call__"):
                    validated_tools.append(tool)
                    seen_names.add(tool.name)

        return validated_tools

    def connect_metadata_systems(
        self,
        mcp_recommendation_system=None,
        mcp_vector_store=None,
        enriched_vector_store=None,
        enriched_recommendation_system=None,
    ):
        """메타데이터 시스템들 연결 - 파라미터 통일"""
        connections_made = 0

        if enriched_recommendation_system:
            self.mcp_recommendation_system = enriched_recommendation_system
            self.enriched_system_enabled = True
            connections_made += 1
            logger.info("✅ 계층적 실행기에 보강된 추천 시스템 연결됨")
        elif mcp_recommendation_system:
            self.mcp_recommendation_system = mcp_recommendation_system
            self.enriched_system_enabled = False
            connections_made += 1
            logger.info("✅ 계층적 실행기에 기존 추천 시스템 연결됨")

        if enriched_vector_store:
            self.mcp_vector_store = enriched_vector_store
            self.enriched_vector_enabled = True
            connections_made += 1
            logger.info("✅ 계층적 실행기에 보강된 벡터 스토어 연결됨")
        elif mcp_vector_store:
            self.mcp_vector_store = mcp_vector_store
            self.enriched_vector_enabled = False
            connections_made += 1
            logger.info("✅ 계층적 실행기에 기존 벡터 스토어 연결됨")

        # 🔥 핵심 수정: metadata_enhanced 플래그 명시적 설정
        self.metadata_enhanced = connections_made > 0
        self.enriched_mode = getattr(self, "enriched_system_enabled", False) or getattr(
            self, "enriched_vector_enabled", False
        )

        if self.metadata_enhanced:
            logger.info(
                f"🎯 계층적 실행기 메타데이터 활용 모드 활성화 ({connections_made}개 연결)"
            )
            logger.info(f"🧠 보강 모드: {'✅' if self.enriched_mode else '❌'}")
        else:
            logger.warning("⚠️ 계층적 실행기 메타데이터 연결 실패")

    async def _select_tools_for_task(self, task: SubTask) -> List:
        """메타데이터를 활용한 하위 작업별 도구 선택 - 검증 강화"""
        logger.info(f"🔧 도구 선택 시작: {task.name}")
        logger.info(f"   required_tools: {task.required_tools}")
        logger.info(
            f"   available_tools: {len(self.available_tools) if self.available_tools else 0}개"
        )

        if not self.available_tools:
            logger.warning("   ⚠️ 사용 가능한 도구가 없음")
            return []

        # 🔥 핵심 수정: required_tools가 비어있지 않은 경우에만 매칭 수행
        if not task.required_tools:
            logger.warning("   ⚠️ 요구되는 도구가 지정되지 않음")
            # 작업 이름과 설명으로 적절한 도구 추천
            return self._recommend_tools_by_task_content(task)

        selected_tools = []
        available_tool_names = {tool.name: tool for tool in self.available_tools}

        # 🔥 1. 정확한 도구명 매칭 우선
        for required_tool in task.required_tools:
            if required_tool in available_tool_names:
                selected_tools.append(available_tool_names[required_tool])
                logger.info(f"   ✅ 정확 매칭: {required_tool}")
            else:
                # 부분 매칭 시도
                matched = False
                required_lower = required_tool.lower()

                for available_name, available_tool in available_tool_names.items():
                    available_lower = available_name.lower()

                    if (
                        required_lower in available_lower
                        or available_lower in required_lower
                        or self._calculate_similarity(required_lower, available_lower)
                        > 0.7
                    ):
                        selected_tools.append(available_tool)
                        logger.info(
                            f"   🔍 부분 매칭: {required_tool} → {available_name}"
                        )
                        matched = True
                        break

                if not matched:
                    logger.warning(f"   ❌ 매칭 실패: {required_tool}")

        # 🔥 2. 매칭된 도구가 없으면 작업 내용 기반 추천
        if not selected_tools:
            logger.info("   🔄 작업 내용 기반 도구 추천으로 폴백")
            selected_tools = self._recommend_tools_by_task_content(task)

        logger.info(f"🎯 최종 선택된 도구: {[t.name for t in selected_tools]}")
        return selected_tools

    def _recommend_tools_by_task_content(self, task: SubTask) -> List:
        """작업 내용 기반 도구 추천 - 개선된 버전"""
        task_content = f"{task.name} {task.description}".lower()
        recommended_tools = []

        # 더 정교한 키워드 매핑
        tool_patterns = {
            # 웹 브라우징 관련
            "web_browsing": {
                "keywords": [
                    "웹",
                    "web",
                    "사이트",
                    "site",
                    "브라우징",
                    "browser",
                    "네이버",
                    "naver",
                    "접속",
                    "navigate",
                    "click",
                    "scroll",
                ],
                "tool_types": ["browser", "hyperbrowser", "navigate", "web"],
            },
            # 검색 관련
            "search": {
                "keywords": [
                    "검색",
                    "search",
                    "찾기",
                    "find",
                    "조회",
                    "query",
                    "정보",
                    "perplexity",
                ],
                "tool_types": ["search", "perplexity", "query", "find"],
            },
            # 파일 처리
            "file_operations": {
                "keywords": [
                    "저장",
                    "save",
                    "파일",
                    "file",
                    "markdown",
                    ".md",
                    "작성",
                    "write",
                    "읽기",
                    "read",
                ],
                "tool_types": ["file", "write", "save", "read", "filesystem"],
            },
            # 데이터 추출
            "data_extraction": {
                "keywords": [
                    "추출",
                    "extract",
                    "수집",
                    "collect",
                    "스크래핑",
                    "scrape",
                    "가져오기",
                    "get",
                ],
                "tool_types": ["extract", "scrape", "get", "collect"],
            },
        }

        # 패턴별 매칭 및 점수 계산
        pattern_scores = {}
        for pattern_name, pattern_data in tool_patterns.items():
            score = sum(
                1 for keyword in pattern_data["keywords"] if keyword in task_content
            )
            if score > 0:
                pattern_scores[pattern_name] = score

        # 점수 순으로 정렬
        sorted_patterns = sorted(
            pattern_scores.items(), key=lambda x: x[1], reverse=True
        )

        # 상위 패턴의 도구들 선택
        for pattern_name, score in sorted_patterns[:2]:  # 상위 2개 패턴
            pattern_data = tool_patterns[pattern_name]
            for tool_type in pattern_data["tool_types"]:
                matching_tools = [
                    t for t in self.available_tools if tool_type in t.name.lower()
                ]
                recommended_tools.extend(matching_tools[:1])  # 각 타입당 1개씩

        # 중복 제거
        seen = set()
        unique_tools = []
        for tool in recommended_tools:
            if tool.name not in seen:
                seen.add(tool.name)
                unique_tools.append(tool)

        logger.info(f"   📊 내용 기반 추천: {[t.name for t in unique_tools]}")
        return unique_tools[:3]

    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """문자열 유사도 계산"""
        try:
            # 간단한 Jaccard 유사도
            set1 = set(str1.split("_"))
            set2 = set(str2.split("_"))

            if not set1 and not set2:
                return 1.0
            if not set1 or not set2:
                return 0.0

            intersection = len(set1.intersection(set2))
            union = len(set1.union(set2))

            return intersection / union if union > 0 else 0.0
        except:
            return 0.0


class MemoryDrivenHierarchicalPlanner(HierarchicalPlanner):

    def __init__(
        self,
        llm_model,
        available_tools,
        workflow_pattern_analyzer: WorkflowPatternAnalyzer,
    ):
        super().__init__(llm_model, available_tools)
        self.workflow_pattern_analyzer = workflow_pattern_analyzer

    async def create_execution_plan(
        self, query: str, routing_decision: RoutingDecision
    ) -> ExecutionPlan:
        """메모리 기반 실행 계획 생성"""

        # 🔥 1. 메모리에서 유사한 성공 워크플로우 검색
        recommended_workflow = (
            await self.workflow_pattern_analyzer.get_recommended_workflow_for_query(
                query
            )
        )

        # 🔥 2. 메모리 기반 계획 프롬프트 생성
        memory_enhanced_prompt = self._create_memory_enhanced_prompt(
            query, routing_decision, recommended_workflow
        )

        # 🔥 3. LLM으로 최적화된 계획 생성
        plan_response = await self.llm_model.ainvoke(memory_enhanced_prompt)

        # 🔥 4. 계획 실행 및 학습
        execution_plan = self._parse_and_enhance_plan(
            plan_response.content, recommended_workflow
        )

        # 🔥 5. 실행 결과를 메모리에 저장 (학습 루프)
        asyncio.create_task(self._store_plan_for_learning(execution_plan, query))

        return execution_plan

    def _create_memory_enhanced_prompt(
        self, query: str, routing_decision: RoutingDecision, recommended_workflow: Dict
    ) -> str:

        return f"""당신은 과거 성공 경험을 학습한 워크플로우 전문가입니다.

사용자 요청: {query}

🧠 과거 성공 패턴 분석:
{self._format_success_patterns(recommended_workflow)}

🎯 논리적 작업 단위 원칙:
1. 각 단위는 완결적인 의미 있는 결과를 생산해야 함
2. 단위의 개수는 작업의 본질적 복잡성에 따라 자연스럽게 결정 (1개~10개+)
3. 각 단위 내에서 도구들이 협력하여 하나의 목표 달성
4. 단위 간에는 명확한 데이터 흐름과 의존성 존재

🔥 성공 확률 높은 검증된 접근법:
{self._format_proven_approaches(recommended_workflow)}

위 정보를 바탕으로 현실적이고 성공 가능성 높은 실행 계획을 수립하세요."""


class SemanticToolMatcher:
    """의미적 검색을 통한 도구 매칭"""

    def __init__(self, embedding_model, available_tools):
        self.embedding_model = embedding_model
        self.available_tools = available_tools
        self.tool_embeddings = None
        self.tool_descriptions = []

    async def initialize_tool_embeddings(self):
        """도구 설명을 임베딩으로 변환"""
        self.tool_descriptions = []
        for tool in self.available_tools:
            description = f"{tool.name}: {getattr(tool, 'description', '')}"
            self.tool_descriptions.append(description)

        if self.tool_descriptions:
            self.tool_embeddings = await self.embedding_model.aembed_documents(
                self.tool_descriptions
            )

    async def find_best_tools(
        self, task_description: str, top_k: int = 5
    ) -> List[Dict]:
        """작업 설명에 가장 적합한 도구들 찾기"""
        if not self.tool_embeddings:
            await self.initialize_tool_embeddings()

        try:
            task_embedding = await self.embedding_model.aembed_query(task_description)

            # 유사도 계산
            import numpy as np

            similarities = []
            for i, tool_emb in enumerate(self.tool_embeddings):
                similarity = np.dot(task_embedding, tool_emb) / (
                    np.linalg.norm(task_embedding) * np.linalg.norm(tool_emb)
                )
                similarities.append(
                    {
                        "tool": self.available_tools[i],
                        "similarity": similarity,
                        "description": self.tool_descriptions[i],
                    }
                )

            # 유사도 순으로 정렬
            similarities.sort(key=lambda x: x["similarity"], reverse=True)

            return similarities[:top_k]

        except Exception as e:
            logger.error(f"의미적 도구 매칭 실패: {e}")
            return []


class EnhancedHierarchicalPlanner(HierarchicalPlanner):
    """의미적 분석을 활용한 향상된 계층적 플래너"""

    def __init__(
        self, llm_model, available_tools, tool_matcher: SemanticToolMatcher = None
    ):
        super().__init__(llm_model, available_tools)
        self.tool_matcher = tool_matcher

        # 🔥 핵심 수정: 메타데이터 관련 속성들 명시적 추가
        self.metadata_enhanced = False
        self.enriched_mode = False
        self.enriched_system_enabled = False
        self.enriched_vector_enabled = False

        logger.info(
            f"✅ EnhancedHierarchicalPlanner 초기화: metadata_enhanced={self.metadata_enhanced}"
        )

    def connect_metadata_systems(
        self,
        mcp_recommendation_system=None,
        mcp_vector_store=None,
        enriched_vector_store=None,
        enriched_recommendation_system=None,
    ):
        """메타데이터 시스템들 연결 - 강화된 버전"""
        connections_made = 0

        # 보강된 시스템 연결
        if enriched_recommendation_system:
            self.mcp_recommendation_system = enriched_recommendation_system
            self.enriched_system_enabled = True
            connections_made += 1
            logger.info("✅ EnhancedHierarchicalPlanner: 보강된 추천 시스템 연결됨")
        elif mcp_recommendation_system:
            self.mcp_recommendation_system = mcp_recommendation_system
            self.enriched_system_enabled = False
            connections_made += 1
            logger.info("✅ EnhancedHierarchicalPlanner: 기존 추천 시스템 연결됨")

        if enriched_vector_store:
            self.mcp_vector_store = enriched_vector_store
            self.enriched_vector_enabled = True
            connections_made += 1
            logger.info("✅ EnhancedHierarchicalPlanner: 보강된 벡터 스토어 연결됨")
        elif mcp_vector_store:
            self.mcp_vector_store = mcp_vector_store
            self.enriched_vector_enabled = False
            connections_made += 1
            logger.info("✅ EnhancedHierarchicalPlanner: 기존 벡터 스토어 연결됨")

        # 🔥 핵심: 메타데이터 플래그 강제 설정
        self.metadata_enhanced = connections_made > 0
        self.enriched_mode = (
            self.enriched_system_enabled or self.enriched_vector_enabled
        )

        logger.info(f"🎯 EnhancedHierarchicalPlanner 메타데이터 상태:")
        logger.info(f"   - metadata_enhanced: {self.metadata_enhanced}")
        logger.info(f"   - enriched_mode: {self.enriched_mode}")
        logger.info(f"   - 연결된 시스템 수: {connections_made}")

        return connections_made > 0

    def get_metadata_status(self) -> Dict[str, Any]:
        """메타데이터 연결 상태 조회"""
        return {
            "metadata_enhanced": self.metadata_enhanced,
            "enriched_mode": self.enriched_mode,
            "enriched_system_enabled": self.enriched_system_enabled,
            "enriched_vector_enabled": self.enriched_vector_enabled,
            "has_recommendation_system": hasattr(self, "mcp_recommendation_system")
            and self.mcp_recommendation_system is not None,
            "has_vector_store": hasattr(self, "mcp_vector_store")
            and self.mcp_vector_store is not None,
            "planner_type": type(self).__name__,
        }

    async def create_execution_plan(
        self, query: str, routing_decision: RoutingDecision
    ) -> ExecutionPlan:
        """향상된 실행 계획 생성"""

        # 1. LLM을 통한 상세 작업 분해
        task_breakdown = await self._llm_task_breakdown(query)

        # 2. 각 하위 작업에 최적 도구 매칭
        enhanced_subtasks = []
        for task in task_breakdown.get("subtasks", []):
            if self.tool_matcher:
                best_tools = await self.tool_matcher.find_best_tools(
                    task["description"]
                )
                task["recommended_tools"] = [t["tool"].name for t in best_tools[:3]]

            subtask = SubTask(
                id=task["id"],
                name=task["name"],
                description=task["description"],
                required_tools=task.get(
                    "recommended_tools", task.get("required_tools", [])
                ),
                dependencies=task.get("dependencies", []),
                priority=task.get("priority", 3),
                estimated_duration=task.get("duration", 5),
            )
            enhanced_subtasks.append(subtask)

        # 3. 실행 순서 최적화
        execution_order = self._optimize_execution_order(enhanced_subtasks)
        from uuid import uuid4

        plan_id = f"{uuid4()}"

        return ExecutionPlan(
            plan_id=plan_id,
            query=query,
            total_subtasks=len(enhanced_subtasks),
            subtasks=enhanced_subtasks,
            execution_order=execution_order,
            estimated_total_time=sum(
                task.estimated_duration for task in enhanced_subtasks
            ),
            fallback_strategy="semantic_react_pattern",
        )

    async def _llm_task_breakdown(self, query: str) -> Dict:
        """LLM을 통한 작업 분해"""
        breakdown_prompt = f"""다음 복잡한 요청을 논리적인 하위 작업들로 분해해주세요:

요청: "{query}"

각 하위 작업은 다음 기준을 따라야 합니다:
1. 독립적으로 실행 가능해야 함
2. 명확한 입력과 출력이 있어야 함
3. 적절한 도구로 수행 가능해야 함
4. 의존성이 명확해야 함

JSON 형식으로 응답해주세요:
{{
    "subtasks": [
        {{
            "id": "task_1",
            "name": "작업명",
            "description": "상세 설명",
            "required_tools": ["도구타입1", "도구타입2"],
            "dependencies": [],
            "priority": 1-5,
            "duration": 예상시간(분)
        }}
    ],
    "execution_strategy": "순차|병렬|혼합",
    "critical_path": ["task_1", "task_2"]
}}"""

        try:
            response = await self.llm_model.ainvoke(breakdown_prompt)
            import json

            return json.loads(response.content.strip())
        except Exception as e:
            logger.error(f"LLM 작업 분해 실패: {e}")
            return {"subtasks": []}

    def _optimize_execution_order(self, subtasks: List[SubTask]) -> List[str]:
        """실행 순서 최적화 (의존성 + 우선순위 고려)"""
        # 토폴로지 정렬 + 우선순위 기반 최적화
        from collections import defaultdict

        # 의존성 그래프 구성
        in_degree = defaultdict(int)
        graph = defaultdict(list)

        for task in subtasks:
            for dep in task.dependencies:
                graph[dep].append(task.id)
                in_degree[task.id] += 1

        # 우선순위 큐 (높은 우선순위 먼저)
        ready_queue = []
        for task in subtasks:
            if in_degree[task.id] == 0:
                ready_queue.append((task.priority, task.id))

        ready_queue.sort(reverse=True)  # 높은 우선순위 먼저

        execution_order = []
        while ready_queue:
            _, current_task = ready_queue.pop(0)
            execution_order.append(current_task)

            # 의존성 업데이트
            for next_task in graph[current_task]:
                in_degree[next_task] -= 1
                if in_degree[next_task] == 0:
                    # 우선순위 찾기
                    priority = next(
                        (t.priority for t in subtasks if t.id == next_task), 3
                    )
                    ready_queue.append((priority, next_task))
                    ready_queue.sort(reverse=True)

        return execution_order


# =================================
# 기존 EnhancedMCPReActAgent 클래스 수정
# =================================


class EnhancedMCPReActAgentWithSemanticRouting(EnhancedMCPReActAgent):
    """의미적 라우팅을 활용한 향상된 MCP ReAct Agent"""

    async def initialize(self):
        """초기화 - 의미적 분석 컴포넌트 추가"""
        await super().initialize()

        # 의미적 분석기 초기화
        if self.model and self.tools:
            try:
                # Azure OpenAI Embeddings 사용
                from langchain_openai import AzureOpenAIEmbeddings

                embedding_model = AzureOpenAIEmbeddings(
                    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                    api_version=os.getenv(
                        "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"
                    ),
                    deployment="text-embedding-3-small",
                )

                self.semantic_analyzer = EnhancedSemanticQueryAnalyzer(
                    embedding_model=embedding_model, llm_model=self.model
                )

                self.tool_matcher = SemanticToolMatcher(embedding_model, self.tools)
                await self.tool_matcher.initialize_tool_embeddings()

                # 향상된 계층적 플래너로 교체
                self.hierarchical_planner = EnhancedHierarchicalPlanner(
                    self.model, self.tools, self.tool_matcher
                )

                logger.info("✅ 의미적 라우팅 시스템 초기화 완료")

            except Exception as e:
                logger.warning(f"의미적 라우팅 시스템 초기화 실패: {e}")

    async def process_query_with_semantic_routing(
        self, chat_id: str, query: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """의미적 라우팅을 통한 쿼리 처리"""

        # 의미적 분석 수행
        if hasattr(self, "semantic_analyzer"):
            routing_decision = await self.semantic_analyzer.analyze_query_semantic(
                query
            )
        else:
            # 폴백: 기존 분석기 사용
            routing_decision = self.enhanced_query_analyzer.analyze_query_complexity(
                query
            )

        # 기존 처리 로직과 동일하게 진행
        async for event in self.process_query_with_enhanced_routing(chat_id, query):
            yield event

    async def process_query_with_enhanced_routing_with_semantic(
        self, chat_id: str, query: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Semantic 벡터 유사도를 포함한 향상된 라우팅"""
        event_queue = asyncio.Queue()

        # 시나리오 시작
        self.scenario_logger.start_scenario(chat_id, query)

        # START 이벤트
        start_event = EventMessage(
            chat_id,
            MessageType.START,
            "🚀 Enhanced MCP Agent with Semantic Routing 시작",
            f"벡터 유사도 + 패턴 분석으로 최적 라우팅 결정: {query}",
            "semantic_enhanced_session_start",
        )

        self.scenario_logger.add_event(chat_id, start_event.to_dict())
        yield start_event.to_dict()

        # 콜백 핸들러 생성
        callback = EnhancedFrontendEventCallback(
            chat_id, event_queue, self.scenario_logger
        )

        try:
            # 통계 업데이트
            self.routing_stats["total_queries"] += 1

            # 🔥 핵심 개선: Semantic 분석 우선 사용
            routing_decision = None

            # Semantic 분석기 사용 (벡터 유사도 포함)
            if hasattr(self, "semantic_analyzer") and self.semantic_analyzer:
                try:
                    # Semantic 분석 시작 알림
                    if callback:
                        callback._add_event_to_queue(
                            MessageType.THINKING,
                            "🧠 벡터 유사도 기반 semantic 분석 중...",
                            "임베딩 모델로 쿼리 복잡도를 정밀 분석합니다",
                            "semantic_analysis_start",
                        )

                    # 실제 semantic 분석 수행
                    routing_decision = (
                        await self.semantic_analyzer.analyze_query_semantic(query)
                    )

                    if callback:
                        callback._add_event_to_queue(
                            MessageType.ROUTING,
                            f" Semantic 분석 완료 → {routing_decision.complexity.value}",
                            f"벡터 유사도 기반 | 신뢰도: {routing_decision.confidence:.3f} | {routing_decision.reasoning}",
                            "semantic_routing_decision",
                            # extra_data={
                            #    "title": f" Semantic 분석 완료 → {routing_decision.complexity.value}"
                            # }
                        )

                    logger.info(
                        f"✅ Semantic 라우팅 결정: {routing_decision.complexity.value} (신뢰도: {routing_decision.confidence:.3f})"
                    )

                except Exception as e:
                    logger.warning(f"⚠️ Semantic 분석 실패, 기본 분석으로 폴백: {e}")
                    routing_decision = None

            # Semantic 분석 실패 시 기본 분석기로 폴백
            if routing_decision is None:
                if callback:
                    callback._add_event_to_queue(
                        MessageType.THINKING,
                        "🔄 기본 패턴 분석으로 폴백 중...",
                        "Semantic 분석 불가로 패턴 기반 분석 사용",
                        "fallback_analysis",
                    )

                routing_decision = (
                    self.enhanced_query_analyzer.analyze_query_complexity(query)
                )

                if callback:
                    callback._add_event_to_queue(
                        MessageType.ROUTING,
                        f"패턴 분석 완료 ",
                        f"폴백 분석 | 신뢰도: {routing_decision.confidence:.3f} | {routing_decision.reasoning}",
                        "fallback_routing_decision",  # ,
                        #   extra_data={
                        #       "title": f" 패턴 분석 완료 완료"
                        #   }
                    )

            logger.info(
                f"최종 라우팅 결정: {routing_decision.complexity.value} (신뢰도: {routing_decision.confidence:.2f})"
            )

            # 라우팅 이벤트 먼저 전송
            routing_event_count = 0
            while not event_queue.empty() and routing_event_count < 5:
                try:
                    event = event_queue.get_nowait()
                    yield event
                    routing_event_count += 1
                except asyncio.QueueEmpty:
                    break

            # 2. 라우팅 결정에 따른 처리 분기
            result = None

            if routing_decision.complexity == QueryComplexity.SIMPLE_CHAT:
                # 단순 채팅 - 도구 사용 없이 직접 LLM 응답
                self.routing_stats["simple_chat"] += 1
                result = await self._handle_simple_chat(chat_id, query, callback)

            elif routing_decision.complexity == QueryComplexity.SIMPLE_TOOL:
                # 단순 도구 사용 - 기존 React 패턴
                self.routing_stats["simple_tool"] += 1
                result = await self._handle_simple_tool_usage(
                    chat_id, query, routing_decision, callback
                )

            elif routing_decision.complexity == QueryComplexity.COMPLEX_TOOL:
                # 복합 도구 사용 - Hierarchical Planning
                self.routing_stats["complex_tool"] += 1
                if routing_decision.requires_planning:
                    self.routing_stats["hierarchical_plans"] += 1
                result = await self._handle_complex_tool_usage(
                    chat_id, query, routing_decision, callback
                )

            # 3. 실행 중 이벤트 스트리밍
            execution_event_count = 0
            while not event_queue.empty() and execution_event_count < 30:
                try:
                    event = event_queue.get_nowait()
                    yield event
                    execution_event_count += 1
                except asyncio.QueueEmpty:
                    break

            ## 메모리에 대화 저장 (semantic 정보 포함)
            # if result and self.memory_manager and self.memory_manager.enabled:
            #    try:
            #        await self.memory_manager.add_conversation_memory(
            #            user_id=chat_id,
            #            message=query,
            #            response=result.get("content", ""),
            #            metadata={
            #                "query_type": analysis.query_type,
            #                "tools_used": [t.name for t in selected_tools] if selected_tools else [],
            #                "workflow_type": workflow_type,
            #                "recommendation_used": recommendation_result is not None,
            #                "memory_context_used": len(relevant_memories) > 0,
            #                "execution_approach": workflow_tracker["execution_approach"],
            #                "quality_score": workflow_tracker["quality_metrics"].get("overall_score", 0),
            #                "execution_duration": execution_duration,
            #                "success": True
            #            }
            #        )
            #        logger.info(f"💾 Semantic 향상 라우팅 대화를 메모리에 저장: {routing_decision.complexity.value}")
            #    except Exception as e:
            #        logger.warning(f"💾 메모리 저장 실패하지만 작업은 계속 진행: {e}")

            # 메모리에 대화 저장 (semantic 정보 포함)
            if result and self.memory_manager and self.memory_manager.enabled:
                try:
                    await self.memory_manager.add_conversation_memory(
                        user_id=chat_id,
                        message=query,
                        response=result.get("content", ""),
                        metadata={
                            "routing_complexity": routing_decision.complexity.value,
                            "routing_confidence": routing_decision.confidence,
                            "processing_approach": routing_decision.recommended_approach,
                            "requires_planning": routing_decision.requires_planning,
                            "semantic_analysis_used": hasattr(self, "semantic_analyzer")
                            and self.semantic_analyzer is not None,
                            "success": True,
                        },
                    )
                    logger.info(
                        f"💾 Semantic 향상 라우팅 대화를 메모리에 저장: {routing_decision.complexity.value}"
                    )
                except Exception as e:
                    logger.warning(f"메모리 저장 실패: {e}")

            # 세션 통계 업데이트 (semantic 정보 포함)
            self.session_stats[chat_id] = {
                "query": query,
                "routing_decision": routing_decision.__dict__,
                "processing_approach": routing_decision.recommended_approach,
                "semantic_analysis_used": hasattr(self, "semantic_analyzer")
                and self.semantic_analyzer is not None,
                "success": result is not None,
                "timestamp": kst_now.isoformat(),
                "routing_stats": self.routing_stats.copy(),
            }

            # 최종 결과 전송
            if result and result.get("content"):
                canvas_event = EventMessage(
                    chat_id,
                    MessageType.CANVAS,
                    result["content"],
                    result["description"],
                    "semantic_enhanced_final_result",
                )
                self.scenario_logger.add_event(chat_id, canvas_event.to_dict())
                yield canvas_event.to_dict()

            # END 이벤트
            approach_description = {
                "direct_llm_response": "직접 LLM 응답",
                "react_pattern": "React 패턴",
                "hierarchical_planning": "계층적 계획",
            }.get(routing_decision.recommended_approach, "기본 처리")

            analysis_type = (
                "Semantic 벡터 분석"
                if hasattr(self, "semantic_analyzer") and self.semantic_analyzer
                else "패턴 분석"
            )

            end_event = EventMessage(
                chat_id,
                MessageType.END,
                f"✅ {approach_description} 처리 완료 ({analysis_type})",
                f"복잡도: {routing_decision.complexity.value} | 신뢰도: {routing_decision.confidence:.2f}",
                "semantic_enhanced_session_end",
            )

            self.scenario_logger.add_event(chat_id, end_event.to_dict())
            self.scenario_logger.complete_scenario(chat_id)
            yield end_event.to_dict()

        except Exception as e:
            logger.error(f"Semantic 향상 라우팅 처리 오류: {e}")
            error_event = EventMessage(
                chat_id,
                MessageType.ERROR,
                f"❌ 처리 중 오류 발생: {str(e)}",
                "시스템 오류",
                "semantic_enhanced_routing_error",
            )
            self.scenario_logger.add_event(chat_id, error_event.to_dict())
            self.scenario_logger.complete_scenario(chat_id)
            yield error_event.to_dict()

    async def _handle_simple_chat(
        self, chat_id: str, query: str, callback
    ) -> Dict[str, Any]:
        """단순 채팅 처리 (도구 사용 없이)"""
        try:
            # callback이 None이 아닌 경우에만 이벤트 전송
            if callback:
                callback._add_event_to_queue(
                    MessageType.THINKING,
                    "💭 단순 대화로 분석되어 직접 응답을 생성합니다...",
                    "도구 사용 없이 LLM 지식만으로 처리",
                    "simple_chat_processing",
                )

            # 채팅용 시스템 프롬프트 생성
            chat_prompt = self._create_enhanced_chat_prompt(query)

            response = await asyncio.get_event_loop().run_in_executor(
                self._executor,
                lambda: self.model.invoke([HumanMessage(content=chat_prompt)]),
            )

            content = self._extract_content(response.content)

            return {
                "content": content,
                "description": "단순 대화 응답",
                "summary": "직접 LLM 응답으로 처리 완료",
            }

        except Exception as e:
            logger.error(f"단순 채팅 처리 오류: {e}")
            return {
                "content": "죄송합니다. 응답 생성 중 오류가 발생했습니다.",
                "description": "단순 채팅 처리 실패",
                "summary": "오류 발생",
            }

    async def _handle_simple_tool_usage(
        self, chat_id: str, query: str, routing_decision: RoutingDecision, callback
    ) -> Dict[str, Any]:
        """단순 도구 사용 처리 (기존 React 패턴)"""
        try:
            # callback이 None이 아닌 경우에만 이벤트 전송
            if callback:
                callback._add_event_to_queue(
                    MessageType.WORKFLOW_START,
                    "🔧 단순 도구 사용으로 분석되어 React 패턴으로 처리합니다",
                    f"예상 단계: {getattr(routing_decision, 'estimated_steps', 1)}단계",
                    "simple_tool_workflow",
                )

            # 기존 React 패턴 처리 로직 사용
            analysis = self.query_analyzer.analyze_query(query)

            if self.server_router and self.tools:
                selected_tools, reason = await self.server_router.route_query(
                    analysis, self.tools
                )
                # callback 안전 검사 추가
                if callback:
                    callback.on_tool_routing(analysis, selected_tools, reason)
            else:
                selected_tools = self.tools
                reason = "모든 도구 사용"

            # ✅ 표준 워크플로우로 실행 (Plan 이벤트 완성 보장)
            result = await self._execute_standard_workflow_with_memory(
                chat_id, query, analysis, selected_tools, callback, []
            )

            return result

        except Exception as e:
            logger.error(f"단순 도구 사용 처리 오류: {e}")
            # ✅ 오류 발생 시에도 적절한 이벤트 처리
            if callback:
                callback._add_event_to_queue(
                    MessageType.ERROR,
                    "❌ 단순 도구 사용 처리 실패",
                    f"오류 발생으로 폴백 처리: {str(e)[:100]}",
                    "simple_tool_error",
                )

            return await self._execute_fallback(query, callback)

    async def _handle_complex_tool_usage(
        self, chat_id: str, query: str, routing_decision, callback
    ) -> Dict[str, Any]:
        """복합 도구 사용 처리"""
        try:

            # 계층적 플래너가 있으면 사용, 없으면 표준 처리로 폴백
            if (
                hasattr(self, "hierarchical_planner")
                and self.hierarchical_planner
                and hasattr(self, "hierarchical_executor")
                and self.hierarchical_executor
            ):

                # 실행 계획 생성
                execution_plan = await self.hierarchical_planner.create_execution_plan(
                    query, routing_decision
                )

                if callback:
                    callback._add_event_to_queue(
                        MessageType.WORKFLOW_START,
                        "복합 작업으로 분석되어 계층적 계획을 수립합니다",
                        f"{execution_plan}",
                        "hierarchical_planning",
                        # extra_data={
                        #    "title": "복합 작업으로 분석되어 계층적 계획을 수립합니다"
                        #    }
                    )
                # if callback:
                #    callback._add_event_to_queue(
                #        MessageType.PLAN_COMPLETE,
                #        f"📋 실행 계획 완료: {execution_plan.total_subtasks}개 하위 작업",
                #        f"실행 순서: {' → '.join([execution_plan.subtasks[i].name for i in range(min(3, len(execution_plan.subtasks)))])}{'...' if len(execution_plan.subtasks) > 3 else ''}",
                #        f"execution_plan_{execution_plan.plan_id}"
                #    )

                # 계층적 실행
                result = await self.hierarchical_executor.execute_plan(
                    execution_plan, chat_id, callback
                )
                return result
            else:
                # 표준 처리로 폴백
                if callback:
                    callback._add_event_to_queue(
                        MessageType.ERROR,
                        f"⚠️ 계층적 계획 처리 불가능, 표준 워크플로우로 전환",
                        "계층적 플래너가 초기화되지 않음",
                        "hierarchical_fallback",
                    )

                analysis = self.query_analyzer.analyze_query(query)
                selected_tools = self.tools
                return await self._execute_standard_workflow_with_memory(
                    chat_id, query, analysis, selected_tools, callback, []
                )

        except Exception as e:
            logger.error(f"복합 도구 사용 처리 오류: {e}")

            if callback:
                callback._add_event_to_queue(
                    MessageType.ERROR,
                    f"⚠️ 계층적 계획 처리 실패, 표준 워크플로우로 전환",
                    f"오류: {str(e)[:100]}",
                    "hierarchical_fallback",
                )

            # 표준 워크플로우로 폴백
            analysis = self.query_analyzer.analyze_query(query)
            selected_tools = self.tools
            return await self._execute_standard_workflow_with_memory(
                chat_id, query, analysis, selected_tools, callback, []
            )

    def _create_enhanced_chat_prompt(self, query: str) -> str:
        """향상된 채팅용 프롬프트 생성"""
        return f"""당신은 친근하고 도움이 되는 AI 어시스턴트입니다.

사용자의 메시지: {query}

다음과 같이 응답해주세요:
1. 친근하고 자연스러운 톤으로 대화하세요
2. 사용자의 감정이나 상황을 고려해서 응답하세요
3. 필요하다면 추가 질문을 통해 더 도움을 드릴 수 있음을 알려주세요
4. 구체적인 작업이 필요하다면 어떤 도움을 드릴 수 있는지 설명해주세요

현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}"""

    def get_routing_stats(self) -> Dict[str, Any]:
        """라우팅 통계 조회"""
        total = max(1, self.routing_stats["total_queries"])  # 0으로 나누기 방지

        return {
            "total_queries": self.routing_stats["total_queries"],
            "simple_chat": self.routing_stats["simple_chat"],
            "simple_tool": self.routing_stats["simple_tool"],
            "complex_tool": self.routing_stats["complex_tool"],
            "hierarchical_plans": self.routing_stats["hierarchical_plans"],
            "distribution": {
                "simple_chat_percentage": (self.routing_stats["simple_chat"] / total)
                * 100,
                "simple_tool_percentage": (self.routing_stats["simple_tool"] / total)
                * 100,
                "complex_tool_percentage": (self.routing_stats["complex_tool"] / total)
                * 100,
                "hierarchical_planning_rate": (
                    self.routing_stats["hierarchical_plans"] / total
                )
                * 100,
            },
        }


class EnhancedMCPReActAgentWithHierarchicalPlanning(EnhancedMCPReActAgent):
    """Hierarchical Planning이 추가된 Enhanced MCP ReAct Agent"""

    def __init__(self):
        super().__init__()

        # 새로운 컴포넌트들
        self.enhanced_query_analyzer = EnhancedQueryAnalyzer()
        self.hierarchical_planner = None
        self.hierarchical_executor = None

        # 통계
        self.routing_stats = {
            "total_queries": 0,
            "simple_chat": 0,
            "simple_tool": 0,
            "complex_tool": 0,
            "hierarchical_plans": 0,
        }

    async def initialize(self):
        """에이전트 초기화 - 기존 초기화 + 새로운 컴포넌트들"""
        await super().initialize()

        # Hierarchical Planner 초기화
        if self.model and self.tools:
            self.hierarchical_planner = HierarchicalPlanner(self.model, self.tools)
            self.hierarchical_executor = HierarchicalExecutor(
                self.model, self.tools, self.mcp_recommendation_system
            )
            logger.info("✅ Hierarchical Planning 시스템 초기화 완료")
        else:
            logger.warning("⚠️ Hierarchical Planning 초기화 실패 - 모델 또는 도구 없음")

    async def process_query_with_enhanced_routing_with_semantic(
        self, chat_id: str, query: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Semantic 벡터 유사도를 포함한 향상된 라우팅"""
        event_queue = asyncio.Queue()

        # 시나리오 시작
        self.scenario_logger.start_scenario(chat_id, query)

        # START 이벤트
        start_event = EventMessage(
            chat_id,
            MessageType.START,
            "🚀 Enhanced MCP Agent with Semantic Routing 시작",
            f"벡터 유사도 + 패턴 분석으로 최적 라우팅 결정: {query}",
            "semantic_enhanced_session_start",
        )

        self.scenario_logger.add_event(chat_id, start_event.to_dict())
        yield start_event.to_dict()

        # 콜백 핸들러 생성
        callback = EnhancedFrontendEventCallback(
            chat_id, event_queue, self.scenario_logger
        )

        try:
            # 통계 업데이트
            self.routing_stats["total_queries"] += 1

            # 🔥 핵심 개선: Semantic 분석 우선 사용
            routing_decision = None

            # Semantic 분석기 사용 (벡터 유사도 포함)
            if hasattr(self, "semantic_analyzer") and self.semantic_analyzer:
                try:
                    # Semantic 분석 시작 알림
                    if callback:
                        callback._add_event_to_queue(
                            MessageType.THINKING,
                            "🧠 벡터 유사도 기반 semantic 분석 중...",
                            "임베딩 모델로 쿼리 복잡도를 정밀 분석합니다",
                            "semantic_analysis_start",
                        )

                    # 실제 semantic 분석 수행
                    routing_decision = (
                        await self.semantic_analyzer.analyze_query_semantic(query)
                    )

                    if callback:
                        callback._add_event_to_queue(
                            MessageType.ROUTING,
                            f"Semantic 분석 완료",
                            f"벡터 유사도 기반 | 신뢰도: {routing_decision.confidence:.3f} | {routing_decision.reasoning}",
                            "semantic_routing_decision",
                            # extra_data={
                            #    "title": f" Semantic 분석 완료"
                            # }
                        )

                    logger.info(
                        f"✅ Semantic 라우팅 결정: {routing_decision.complexity.value} (신뢰도: {routing_decision.confidence:.3f})"
                    )

                except Exception as e:
                    logger.warning(f"⚠️ Semantic 분석 실패, 기본 분석으로 폴백: {e}")
                    routing_decision = None

            # Semantic 분석 실패 시 기본 분석기로 폴백
            if routing_decision is None:
                if callback:
                    callback._add_event_to_queue(
                        MessageType.THINKING,
                        "🔄 기본 패턴 분석으로 폴백 중...",
                        "Semantic 분석 불가로 패턴 기반 분석 사용",
                        "fallback_analysis",
                    )

                routing_decision = (
                    self.enhanced_query_analyzer.analyze_query_complexity(query)
                )

                if callback:
                    callback._add_event_to_queue(
                        MessageType.ROUTING,
                        f"패턴 분석 완료",
                        f"폴백 분석 | 신뢰도: {routing_decision.confidence:.3f} | {routing_decision.reasoning}",
                        "fallback_routing_decision",
                        # extra_data={
                        #    "title": f" 패턴 분석 완료"
                        # }
                    )

            logger.info(
                f"최종 라우팅 결정: {routing_decision.complexity.value} (신뢰도: {routing_decision.confidence:.2f})"
            )

            # 라우팅 이벤트 먼저 전송
            routing_event_count = 0
            while not event_queue.empty() and routing_event_count < 5:
                try:
                    event = event_queue.get_nowait()
                    yield event
                    routing_event_count += 1
                except asyncio.QueueEmpty:
                    break

            # 이후 처리는 기존과 동일...
            result = None

            if routing_decision.complexity == QueryComplexity.SIMPLE_CHAT:
                self.routing_stats["simple_chat"] += 1
                result = await self._handle_simple_chat(chat_id, query, callback)

            elif routing_decision.complexity == QueryComplexity.SIMPLE_TOOL:
                self.routing_stats["simple_tool"] += 1
                result = await self._handle_simple_tool_usage(
                    chat_id, query, routing_decision, callback
                )

            elif routing_decision.complexity == QueryComplexity.COMPLEX_TOOL:
                self.routing_stats["complex_tool"] += 1
                if routing_decision.requires_planning:
                    self.routing_stats["hierarchical_plans"] += 1
                result = await self._handle_complex_tool_usage(
                    chat_id, query, routing_decision, callback
                )

            # 실행 중 이벤트 스트리밍
            execution_event_count = 0
            while not event_queue.empty() and execution_event_count < 30:
                try:
                    event = event_queue.get_nowait()
                    yield event
                    execution_event_count += 1
                except asyncio.QueueEmpty:
                    break

            # 메모리에 대화 저장 (semantic 정보 포함)
            if result and self.memory_manager and self.memory_manager.enabled:
                try:
                    await self.memory_manager.add_conversation_memory(
                        user_id=chat_id,
                        message=query,
                        response=result.get("content", ""),
                        metadata={
                            "routing_complexity": routing_decision.complexity.value,
                            "routing_confidence": routing_decision.confidence,
                            "processing_approach": routing_decision.recommended_approach,
                            "requires_planning": routing_decision.requires_planning,
                            "semantic_analysis_used": hasattr(self, "semantic_analyzer")
                            and self.semantic_analyzer is not None,
                            "success": True,
                        },
                    )
                    logger.info(
                        f"💾 Semantic 향상 라우팅 대화를 메모리에 저장: {routing_decision.complexity.value}"
                    )
                except Exception as e:
                    logger.warning(f"메모리 저장 실패: {e}")

            # 세션 통계 업데이트 (semantic 정보 포함)
            self.session_stats[chat_id] = {
                "query": query,
                "routing_decision": routing_decision.__dict__,
                "processing_approach": routing_decision.recommended_approach,
                "semantic_analysis_used": hasattr(self, "semantic_analyzer")
                and self.semantic_analyzer is not None,
                "success": result is not None,
                "timestamp": datetime.now().isoformat(),
                "routing_stats": self.routing_stats.copy(),
            }

            # 최종 결과 전송
            if result and result.get("content"):
                canvas_event = EventMessage(
                    chat_id,
                    MessageType.CANVAS,
                    result["content"],
                    result["description"],
                    "semantic_enhanced_final_result",
                )
                self.scenario_logger.add_event(chat_id, canvas_event.to_dict())
                yield canvas_event.to_dict()

            # END 이벤트
            approach_description = {
                "direct_llm_response": "직접 LLM 응답",
                "react_pattern": "React 패턴",
                "hierarchical_planning": "계층적 계획",
            }.get(routing_decision.recommended_approach, "기본 처리")

            analysis_type = (
                "Semantic 벡터 분석"
                if hasattr(self, "semantic_analyzer") and self.semantic_analyzer
                else "패턴 분석"
            )

            end_event = EventMessage(
                chat_id,
                MessageType.END,
                f"✅ {approach_description} 처리 완료 ({analysis_type})",
                f"복잡도: {routing_decision.complexity.value} | 신뢰도: {routing_decision.confidence:.2f}",
                "semantic_enhanced_session_end",
            )

            self.scenario_logger.add_event(chat_id, end_event.to_dict())
            self.scenario_logger.complete_scenario(chat_id)
            yield end_event.to_dict()

        except Exception as e:
            logger.error(f"Semantic 향상 라우팅 처리 오류: {e}")
            error_event = EventMessage(
                chat_id,
                MessageType.ERROR,
                f"❌ 처리 중 오류 발생: {str(e)}",
                "시스템 오류",
                "semantic_enhanced_routing_error",
            )
            self.scenario_logger.add_event(chat_id, error_event.to_dict())
            self.scenario_logger.complete_scenario(chat_id)
            yield error_event.to_dict()

    async def _handle_simple_chat(
        self, chat_id: str, query: str, callback
    ) -> Dict[str, Any]:
        """단순 채팅 처리 (도구 사용 없이)"""
        try:
            # callback이 None이 아닌 경우에만 이벤트 전송
            if callback:
                callback._add_event_to_queue(
                    MessageType.THINKING,
                    "💭 단순 대화로 분석되어 직접 응답을 생성합니다...",
                    "도구 사용 없이 LLM 지식만으로 처리",
                    "simple_chat_processing",
                )

            # 채팅용 시스템 프롬프트 생성
            chat_prompt = self._create_enhanced_chat_prompt(query)

            response = await asyncio.get_event_loop().run_in_executor(
                self._executor,
                lambda: self.model.invoke([HumanMessage(content=chat_prompt)]),
            )

            content = self._extract_content(response.content)

            # 완료 이벤트도 callback 체크
            if callback:
                callback._add_event_to_queue(
                    MessageType.PLAN_COMPLETE,
                    "✅ 단순 채팅 응답 준비 완료",
                    "도구 사용 없이 직접 LLM 응답 생성",
                    "simple_chat_complete",
                )

            return {
                "content": content,
                "description": "단순 대화 응답 (도구 사용 없음)",
                "summary": "직접 LLM 응답으로 처리 완료",
            }

        except Exception as e:
            logger.error(f"단순 채팅 워크플로우 오류: {e}")
            return {
                "content": "죄송합니다. 응답 생성 중 오류가 발생했습니다.",
                "description": "단순 채팅 처리 실패",
                "summary": "오류 발생",
            }

    async def _handle_simple_tool_usage(
        self, chat_id: str, query: str, routing_decision: RoutingDecision, callback
    ) -> Dict[str, Any]:
        """단순 도구 사용 처리 (기존 React 패턴)"""
        if callback:
            callback._add_event_to_queue(
                MessageType.WORKFLOW_START,
                "🔧 단순 도구 사용으로 분석되어 React 패턴으로 처리합니다",
                f"예상 단계: {routing_decision.estimated_steps}단계",
                "simple_tool_workflow",
            )

        # 기존 React 패턴 처리 로직 사용
        analysis = self.query_analyzer.analyze_query(query)

        if self.server_router and self.tools:
            selected_tools, reason = await self.server_router.route_query(
                analysis, self.tools
            )
            if callback:
                callback.on_tool_routing(analysis, selected_tools, reason)
        else:
            selected_tools = self.tools
            reason = "모든 도구 사용"

        # 표준 워크플로우로 실행
        return await self._execute_standard_workflow_with_memory(
            chat_id, query, analysis, selected_tools, callback, []
        )

    async def _handle_complex_tool_usage(
        self, chat_id: str, query: str, routing_decision: RoutingDecision, callback
    ) -> Dict[str, Any]:
        """복합 도구 사용 처리 (Hierarchical Planning)"""

        if not self.hierarchical_planner or not self.hierarchical_executor:
            logger.warning("Hierarchical Planning 시스템이 없어 표준 워크플로우로 폴백")
            # 표준 처리로 폴백
            analysis = self.query_analyzer.analyze_query(query)
            if self.server_router and self.tools:
                # ✅ await 추가
                selected_tools, reason = await self.server_router.route_query(
                    analysis, self.tools
                )
            else:
                selected_tools = self.tools
                reason = "모든 도구 사용"

            return await self._execute_standard_workflow_with_memory(
                chat_id, query, analysis, selected_tools, callback, []
            )

        try:
            # 1. 실행 계획 생성
            execution_plan = await self.hierarchical_planner.create_execution_plan(
                query, routing_decision
            )

            if callback:
                callback._add_event_to_queue(
                    MessageType.WORKFLOW_START,
                    " 복합 작업으로 분석되어 계층적 계획을 수립합니다",
                    f"실행 순서: {' → '.join([execution_plan.subtasks[i].name for i in range(min(5, len(execution_plan.subtasks)))])}{'...' if len(execution_plan.subtasks) > 5 else ''}",
                    "hierarchical_planning_start",
                    # extra_data={
                    #    "title": "복합 작업으로 분석되어 계층적 계획을 수립합니다"
                    #    }
                )

            logger.info(
                f"계층적 실행 계획 생성 완료: {execution_plan.total_subtasks}개 하위 작업"
            )
            # if callback:
            #    callback._add_event_to_queue(
            #    MessageType.PLAN_COMPLETE,
            #    f"📋 실행 계획 완료: {execution_plan.total_subtasks}개 하위 작업",
            #    f"실행 순서: {' → '.join([execution_plan.subtasks[i].name for i in range(min(3, len(execution_plan.subtasks)))])}{'...' if len(execution_plan.subtasks) > 3 else ''}",
            #    f"execution_plan_{execution_plan.plan_id}"
            # )

            # 2. 계층적 실행
            result = await self.hierarchical_executor.execute_plan(
                execution_plan, chat_id, callback
            )

            return result

        except Exception as e:
            logger.error(f"계층적 계획 처리 오류: {e}")

            if callback:
                callback._add_event_to_queue(
                    MessageType.ERROR,
                    f"⚠️ 계층적 계획 처리 실패, 표준 워크플로우로 전환",
                    f"오류: {str(e)[:100]}",
                    "hierarchical_fallback",
                )

            # 표준 워크플로우로 폴백
            analysis = self.query_analyzer.analyze_query(query)
            if self.server_router and self.tools:
                # ✅ await 추가
                selected_tools, reason = await self.server_router.route_query(
                    analysis, self.tools
                )
            else:
                selected_tools = self.tools
                reason = "모든 도구 사용"

            return await self._execute_standard_workflow_with_memory(
                chat_id, query, analysis, selected_tools, callback, []
            )

    def _create_enhanced_chat_prompt(self, query: str) -> str:
        """향상된 채팅용 프롬프트 생성"""
        return f"""당신은 친근하고 도움이 되는 AI 어시스턴트입니다.

사용자의 메시지: {query}

다음과 같이 응답해주세요:
1. 친근하고 자연스러운 톤으로 대화하세요
2. 사용자의 감정이나 상황을 고려해서 응답하세요
3. 필요하다면 추가 질문을 통해 더 도움을 드릴 수 있음을 알려주세요
4. 구체적인 작업이 필요하다면 어떤 도움을 드릴 수 있는지 설명해주세요

현재 시간: {kst_now.strftime('%Y-%m-%d %H:%M:%S')}"""

    def get_routing_stats(self) -> Dict[str, Any]:
        """라우팅 통계 조회"""
        total = max(1, self.routing_stats["total_queries"])  # 0으로 나누기 방지

        return {
            "total_queries": self.routing_stats["total_queries"],
            "simple_chat": self.routing_stats["simple_chat"],
            "simple_tool": self.routing_stats["simple_tool"],
            "complex_tool": self.routing_stats["complex_tool"],
            "hierarchical_plans": self.routing_stats["hierarchical_plans"],
            "distribution": {
                "simple_chat_percentage": (self.routing_stats["simple_chat"] / total)
                * 100,
                "simple_tool_percentage": (self.routing_stats["simple_tool"] / total)
                * 100,
                "complex_tool_percentage": (self.routing_stats["complex_tool"] / total)
                * 100,
                "hierarchical_planning_rate": (
                    self.routing_stats["hierarchical_plans"] / total
                )
                * 100,
            },
        }


class MCPToolMatchingDiagnostics:
    """MCP 도구 매칭 진단 시스템"""

    def __init__(self, agent):
        self.agent = agent

    def diagnose_tool_matching_issue(self, subtasks: List[SubTask]) -> Dict[str, Any]:
        """도구 매칭 문제 진단"""
        diagnosis = {
            "total_subtasks": len(subtasks),
            "subtasks_with_tools": 0,
            "subtasks_without_tools": 0,
            "tool_matching_issues": [],
            "recommendations": [],
        }

        available_tool_names = (
            [tool.name for tool in self.agent.tools] if self.agent.tools else []
        )

        for subtask in subtasks:
            if subtask.required_tools:
                diagnosis["subtasks_with_tools"] += 1

                # 각 도구가 실제로 사용 가능한지 확인
                for tool_name in subtask.required_tools:
                    if tool_name not in available_tool_names:
                        # 유사한 도구 찾기
                        similar_tools = self._find_similar_tools(
                            tool_name, available_tool_names
                        )
                        diagnosis["tool_matching_issues"].append(
                            {
                                "subtask": subtask.name,
                                "requested_tool": tool_name,
                                "available": False,
                                "similar_tools": similar_tools,
                            }
                        )
            else:
                diagnosis["subtasks_without_tools"] += 1
                diagnosis["tool_matching_issues"].append(
                    {
                        "subtask": subtask.name,
                        "issue": "no_tools_specified",
                        "suggested_tools": self._suggest_tools_for_task(
                            subtask, available_tool_names
                        ),
                    }
                )

        # 추천사항 생성
        if diagnosis["subtasks_without_tools"] > 0:
            diagnosis["recommendations"].append(
                f"하위 작업 분해 시 구체적인 도구명 지정 필요 ({diagnosis['subtasks_without_tools']}개 작업)"
            )

        if diagnosis["tool_matching_issues"]:
            diagnosis["recommendations"].append(
                "LLM 프롬프트에 사용 가능한 실제 도구 목록을 더 명확히 제시 필요"
            )

        return diagnosis

    def _find_similar_tools(
        self, requested_tool: str, available_tools: List[str]
    ) -> List[str]:
        """요청된 도구와 유사한 사용 가능한 도구 찾기"""
        requested_lower = requested_tool.lower()
        similar = []

        for available in available_tools:
            available_lower = available.lower()

            # 부분 문자열 매칭
            if (
                requested_lower in available_lower
                or available_lower in requested_lower
                or any(word in available_lower for word in requested_lower.split("_"))
            ):
                similar.append(available)

        return similar[:3]  # 최대 3개

    def _suggest_tools_for_task(
        self, subtask: SubTask, available_tools: List[str]
    ) -> List[str]:
        """작업에 적합한 도구 제안"""
        task_text = f"{subtask.name} {subtask.description}".lower()
        suggestions = []

        # 키워드 기반 매칭
        keyword_mappings = {
            ("웹", "web", "브라우저", "browser", "사이트", "navigate"): [
                "browser",
                "hyperbrowser",
                "navigate",
            ],
            ("검색", "search", "찾기", "find"): ["search", "perplexity", "query"],
            ("파일", "file", "저장", "save", "write"): ["file", "write", "save"],
            ("추출", "extract", "스크래핑", "scrape"): ["extract", "scrape", "get"],
        }

        for keywords, tool_types in keyword_mappings.items():
            if any(keyword in task_text for keyword in keywords):
                for tool_type in tool_types:
                    matching_tools = [
                        tool for tool in available_tools if tool_type in tool.lower()
                    ]
                    suggestions.extend(matching_tools[:2])

        return list(set(suggestions))[:3]  # 중복 제거 후 최대 3개


# =================================
# FastAPI 애플리케이션 및 엔드포인트
# =================================

# 전역 에이전트 인스턴스
enhanced_mcp_agent = EnhancedMCPReActAgentWithHierarchicalPlanning()
# enhanced_mcp_agent = EnhancedMCPReActAgent()


# lifespan 이벤트 핸들러
@asynccontextmanager
async def lifespan(app: FastAPI):
    # 시작 시
    try:
        await enhanced_mcp_agent.initialize()
        logger.info(
            "Enhanced MCP Agent with Recommendation System 서버가 시작되었습니다."
        )
    except Exception as e:
        logger.error(f"서버 시작 중 오류: {e}")

    yield

    # 종료 시
    logger.info("Enhanced MCP Agent with Recommendation System 서버가 종료됩니다.")


# FastAPI 앱 생성
app = FastAPI(
    title="Enhanced MCP ReAct Agent API",
    version="4.1.0",
    description="""
    ## 🚀 Enhanced MCP ReAct Agent with Specialized Routing

    이 API는 Model Context Protocol (MCP)을 활용한 AI 에이전트 시스템으로,
    쿼리 복잡도에 따라 다른 처리 방식을 제공합니다.

    ### 🎯 새로운 분산 엔드포인트
    - **General Agent** (`/api/v1/general-agent/chat`): 단순 대화 전용
    - **React Agent** (`/api/v1/react-agent/chat`): 도구 기반 작업 처리
    - **Auto Router** (`/chat/enhanced/{chat_id}`): 자동 분류 및 라우팅

    ### 🔧 주요 기능
    - **쿼리 복잡도 자동 분석**: Simple Chat, Simple Tool, Complex Tool 분류
    - **전문화된 처리 파이프라인**: 각 유형별 최적화된 워크플로우
    - **실시간 스트리밍**: Server-Sent Events 기반 응답
    - **통합 모니터링**: 성능 및 사용 통계 추적
    """,
    lifespan=lifespan,
    openapi_tags=[
        {
            "name": "Specialized Chat",
            "description": "특화된 채팅 엔드포인트 - General Agent 및 React Agent",
        },
        {"name": "Auto Routing", "description": "자동 분류 및 라우팅 시스템"},
        {"name": "Legacy Chat", "description": "기존 호환성을 위한 레거시 엔드포인트"},
        {"name": "System Status", "description": "시스템 상태 확인 및 헬스 체크"},
        {"name": "MCP Tools", "description": "MCP 도구 관리 및 분석"},
        {"name": "MCP Recommendation", "description": "MCP 도구 추천 시스템"},
        {"name": "Debug & Diagnosis", "description": "디버깅 및 시스템 진단"},
        {"name": "Analytics", "description": "분석 및 통계"},
    ],
)

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =================================
# 1. 새로운 특화 엔드포인트
# =================================


@app.post("/api/v1/general-agent/chat", tags=["Specialized Chat"])
async def general_agent_chat(request: ChatRequest):
    """
    ## 💬 General Agent Chat (Simple Chat Only)

    단순 대화 전용 엔드포인트 - 도구 사용 없이 LLM만으로 응답합니다.

    **특징:**
    - 빠른 응답 속도
    - 도구 오버헤드 없음
    - 일반적인 질문 및 대화에 최적화

    **적합한 쿼리:**
    - 인사 및 일반 대화
    - 간단한 질문
    - 설명 요청
    - 조언 및 상담
    """
    chat_id = f"general_{int(time.time())}"

    async def generate_events():
        try:
            # 시작 이벤트
            start_event = {
                "type": "START",
                "content": "🤖 General Agent로 처리를 시작합니다",
                "description": "단순 대화 모드 - 도구 사용 없이 LLM 직접 응답",
                "key": "general_start",
                "id": chat_id,
            }
            yield f"data: {json.dumps(start_event, ensure_ascii=False)}\n\n"

            # 처리 시작 알림
            thinking_event = {
                "type": "THINKING",
                "content": "💭 General Agent가 응답을 생성하고 있습니다...",
                "description": "도구 사용 없이 LLM 지식만으로 처리",
                "key": "general_processing",
                "id": chat_id,
            }
            yield f"data: {json.dumps(thinking_event, ensure_ascii=False)}\n\n"

            # General Agent 처리
            result = await enhanced_mcp_agent._handle_simple_chat(
                chat_id, request.message, None
            )

            # 결과 이벤트
            canvas_event = {
                "type": "CANVAS",
                "content": result["content"],
                "description": result["description"],
                "key": "general_result",
                "id": chat_id,
            }
            yield f"data: {json.dumps(canvas_event, ensure_ascii=False)}\n\n"

            # 종료 이벤트
            end_event = {
                "type": "END",
                "content": "✅ General Agent 처리 완료",
                "description": "도구 사용 없이 성공적으로 처리됨",
                "key": "general_end",
                "id": chat_id,
            }
            yield f"data: {json.dumps(end_event, ensure_ascii=False)}\n\n"

        except Exception as e:
            logger.error(f"General Agent 처리 오류: {e}")
            error_event = {
                "type": "ERROR",
                "content": f"General Agent 처리 중 오류: {str(e)}",
                "description": "시스템 오류 발생",
                "key": "general_error",
                "id": chat_id,
            }
            yield f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"

    return StreamingResponse(
        generate_events(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/api/v1/react-agent/chat", tags=["Specialized Chat"])
async def react_agent_chat(request: ChatRequest):
    """React Agent Chat 엔드포인트 - 실시간 스트리밍 수정 버전"""
    chat_id = f"react_{int(time.time())}"

    async def generate_events():
        try:
            # 이벤트 큐와 콜백 생성
            event_queue = asyncio.Queue()
            callback = EnhancedFrontendEventCallback(
                chat_id, event_queue, enhanced_mcp_agent.scenario_logger
            )

            # 시작 이벤트 즉시 전송
            start_event = {
                "type": "START",
                "content": "React Agent로 처리를 시작합니다.",
                "description": "쿼리 분석 및 도구 기반 처리 준비 중...",
                "key": "react_start",
                "id": chat_id,
                "created_at": kst_now.isoformat() + "Z",
                "title": "React Agent로 처리를 시작합니다.",
            }
            yield f"data: {json.dumps(start_event, ensure_ascii=False)}\n\n"

            # 쿼리 분석 - AWAIT 수정
            try:
                if hasattr(enhanced_mcp_agent, "_semantic_routing_v2_enabled"):
                    routing_decision = await enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(
                        request.message
                    )
                else:
                    routing_decision = enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(
                        request.message
                    )
            except Exception as analysis_error:
                logger.warning(f"쿼리 분석 실패, 기본 분석 사용: {analysis_error}")
                basic_analysis = enhanced_mcp_agent.query_analyzer.analyze_query(
                    request.message
                )
                routing_decision = RoutingDecision(
                    complexity=QueryComplexity.SIMPLE_TOOL,
                    confidence=0.7,
                    reasoning=f"기본 분석: {basic_analysis.query_type}",
                    recommended_approach="react_pattern",
                    estimated_steps=basic_analysis.estimated_steps,
                    requires_planning=False,
                )

            processing_type = (
                "Simple Tool"
                if routing_decision.complexity == QueryComplexity.SIMPLE_TOOL
                else "Complex Tool"
            )

            # 라우팅 결정 이벤트 즉시 전송
            routing_event = {
                "type": "ROUTING",
                "content": f" {processing_type} 패턴으로 분석됨",
                "description": f"접근 방식: {routing_decision.recommended_approach} | 신뢰도: {routing_decision.confidence:.2f}",
                "key": "react_routing",
                "id": chat_id,
                "created_at": kst_now.isoformat() + "Z",
                #         "title" : f" {processing_type} 패턴으로 분석됨"
            }
            yield f"data: {json.dumps(routing_event, ensure_ascii=False)}\n\n"

            # ✅ 핵심 수정: 백그라운드 태스크로 React Agent 실행
            agent_task = None
            result = None

            if routing_decision.complexity == QueryComplexity.SIMPLE_TOOL:
                agent_task = asyncio.create_task(
                    enhanced_mcp_agent._handle_simple_tool_usage(
                        chat_id, request.message, routing_decision, callback
                    )
                )
            else:  # COMPLEX_TOOL
                agent_task = asyncio.create_task(
                    enhanced_mcp_agent._handle_complex_tool_usage(
                        chat_id, request.message, routing_decision, callback
                    )
                )

            # ✅ 실시간 이벤트 스트리밍: agent_task와 event_queue를 병렬 처리
            event_count = 0
            max_events = 100  # 무한 루프 방지

            while not agent_task.done() and event_count < max_events:
                try:
                    # 0.1초마다 이벤트 큐 확인
                    event = await asyncio.wait_for(event_queue.get(), timeout=0.1)
                    yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                    event_count += 1
                except asyncio.TimeoutError:
                    # 타임아웃은 정상 - 계속 진행
                    continue
                except Exception as e:
                    logger.error(f"이벤트 스트리밍 오류: {e}")
                    break

            # Agent 작업 완료 대기
            try:
                result = await agent_task
            except Exception as e:
                logger.error(f"React Agent 실행 오류: {e}")
                error_event = {
                    "type": "ERROR",
                    "content": f"React Agent 처리 중 오류: {str(e)}",
                    "description": "도구 기반 처리 중 시스템 오류 발생",
                    "key": "react_error",
                    "id": chat_id,
                    "created_at": kst_now.isoformat() + "Z",
                }
                yield f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"
                return

            # ✅ 남은 이벤트들 모두 전송
            remaining_events = 0
            while not event_queue.empty() and remaining_events < 50:
                try:
                    event = event_queue.get_nowait()
                    yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                    remaining_events += 1
                except asyncio.QueueEmpty:
                    break

            # ✅ THINKING 이벤트 추가 (PLAN_COMPLETE 이후, CANVAS 이전)
            thinking_event = {
                "type": "THINKING",
                "content": "💭 실행 결과를 정리하고 최종 응답을 생성하고 있습니다...",
                "description": "수집된 정보를 종합하여 사용자 친화적인 형태로 변환 중",
                "key": "result_synthesis",
                "id": chat_id,
                "created_at": kst_now.isoformat() + "Z",
            }
            yield f"data: {json.dumps(thinking_event, ensure_ascii=False)}\n\n"

            # 결과 이벤트 전송
            if result and result.get("content"):
                canvas_event = {
                    "type": "CANVAS",
                    "content": result["content"],
                    "description": result["description"],
                    "key": "react_result",
                    "id": chat_id,
                    "created_at": kst_now.isoformat() + "Z",
                }
                yield f"data: {json.dumps(canvas_event, ensure_ascii=False)}\n\n"

            # 종료 이벤트
            end_event = {
                "type": "END",
                "content": f"React Agent ({processing_type}) 처리 완료",
                "description": f"도구 기반 처리 성공 - {routing_decision.recommended_approach}",
                "key": "react_end",
                "id": chat_id,
                "created_at": kst_now.isoformat() + "Z",
                #    "title" : f"React Agent ({processing_type}) 처리 완료"
            }
            yield f"data: {json.dumps(end_event, ensure_ascii=False)}\n\n"

        except Exception as e:
            logger.error(f"React Agent 스트리밍 처리 오류: {e}")
            error_event = {
                "type": "ERROR",
                "content": f"React Agent 처리 중 치명적 오류: {str(e)}",
                "description": "시스템 오류로 인한 처리 중단",
                "key": "react_fatal_error",
                "id": chat_id,
                "created_at": kst_now.isoformat() + "Z",
            }
            yield f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"

    return StreamingResponse(
        generate_events(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
            "X-Accel-Buffering": "no",
        },
    )


# =================================
# 2. 자동 라우팅 엔드포인트 (기존 enhanced 수정)
# =================================


@app.post("/chat/enhanced/{chat_id}", tags=["Auto Routing"])
async def enhanced_chat_with_auto_routing(chat_id: str, request: ChatRequest):
    """
    ## 🎯 Auto-Routing Enhanced Chat - async/await 수정 버전

    쿼리를 자동 분석하여 적절한 처리 방식을 선택하는 통합 엔드포인트입니다.

    **자동 라우팅 규칙:**
    - **Simple Chat** → General Agent (도구 사용 없음)
    - **Simple Tool** → React Agent (단순 도구 사용)
    - **Complex Tool** → React Agent (복합 도구 사용)

    **장점:**
    - 사용자가 복잡도를 판단할 필요 없음
    - 최적의 처리 방식 자동 선택
    - 일관된 인터페이스 제공
    """
    try:
        # 1. 쿼리 분석 (AWAIT 추가!)
        if hasattr(
            enhanced_mcp_agent.enhanced_query_analyzer, "analyze_query_complexity"
        ):
            # Semantic 분석이 활성화된 경우 (async 메서드)
            if hasattr(enhanced_mcp_agent, "_semantic_routing_v2_enabled"):
                routing_decision = await enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(
                    request.message
                )
            else:
                # 원본 메서드인 경우 (sync 메서드)
                routing_decision = (
                    enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(
                        request.message
                    )
                )
        else:
            # 폴백: 기본 분석기 사용
            basic_analysis = enhanced_mcp_agent.query_analyzer.analyze_query(
                request.message
            )
            # 기본 분석 결과를 RoutingDecision 형태로 변환

            complexity_mapping = {
                "simple": QueryComplexity.SIMPLE_CHAT,
                "medium": QueryComplexity.SIMPLE_TOOL,
                "complex": QueryComplexity.COMPLEX_TOOL,
            }

            routing_decision = RoutingDecision(
                complexity=complexity_mapping.get(
                    basic_analysis.complexity, QueryComplexity.SIMPLE_TOOL
                ),
                confidence=0.7,
                reasoning=f"폴백 분석: {basic_analysis.query_type}",
                recommended_approach="react_pattern",
                estimated_steps=basic_analysis.estimated_steps,
                requires_planning=False,
            )

        # 2. 분류에 따른 내부 라우팅 (기존 코드와 동일)
        if routing_decision.complexity == QueryComplexity.SIMPLE_CHAT:
            # General Agent로 처리
            async def route_to_general():
                # 라우팅 정보 이벤트
                routing_event = {
                    "type": "ROUTING",
                    "content": f"🎯 General Agent로 자동 라우팅됨",
                    "description": f"단순 대화로 분류 | 신뢰도: {routing_decision.confidence:.2f} | {routing_decision.reasoning}",
                    "key": "auto_routing_general",
                    "id": chat_id,
                }
                yield f"data: {json.dumps(routing_event, ensure_ascii=False)}\n\n"

                # General Agent 처리
                result = await enhanced_mcp_agent._handle_simple_chat(
                    chat_id, request.message, None
                )

                canvas_event = {
                    "type": "CANVAS",
                    "content": result["content"],
                    "description": "General Agent 자동 라우팅 결과",
                    "key": "auto_routed_result",
                    "id": chat_id,
                }
                yield f"data: {json.dumps(canvas_event, ensure_ascii=False)}\n\n"

                end_event = {
                    "type": "END",
                    "content": "✅ 자동 라우팅 완료 (General Agent)",
                    "description": "단순 대화로 성공적으로 처리됨",
                    "key": "auto_routing_end",
                    "id": chat_id,
                }
                yield f"data: {json.dumps(end_event, ensure_ascii=False)}\n\n"

            return StreamingResponse(
                route_to_general(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "Access-Control-Allow-Origin": "*",
                    "X-Accel-Buffering": "no",
                },
            )

        else:  # SIMPLE_TOOL or COMPLEX_TOOL
            # React Agent로 처리
            async def route_to_react():
                event_queue = asyncio.Queue()
                callback = EnhancedFrontendEventCallback(
                    chat_id, event_queue, enhanced_mcp_agent.scenario_logger
                )

                processing_type = (
                    "Simple Tool"
                    if routing_decision.complexity == QueryComplexity.SIMPLE_TOOL
                    else "Complex Tool"
                )

                # 라우팅 정보 이벤트
                routing_event = {
                    "type": "ROUTING",
                    "content": f"🎯 React Agent로 자동 라우팅됨 ({processing_type})",
                    "description": f"신뢰도: {routing_decision.confidence:.2f} | 예상 단계: {routing_decision.estimated_steps} | {routing_decision.reasoning}",
                    "key": "auto_routing_react",
                    "id": chat_id,
                }
                yield f"data: {json.dumps(routing_event, ensure_ascii=False)}\n\n"

                # React Agent 처리
                if routing_decision.complexity == QueryComplexity.SIMPLE_TOOL:
                    result = await enhanced_mcp_agent._handle_simple_tool_usage(
                        chat_id, request.message, routing_decision, callback
                    )
                else:
                    result = await enhanced_mcp_agent._handle_complex_tool_usage(
                        chat_id, request.message, routing_decision, callback
                    )

                # 이벤트 큐에서 이벤트들을 스트리밍
                while not event_queue.empty():
                    try:
                        event = event_queue.get_nowait()
                        yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                    except asyncio.QueueEmpty:
                        break

                canvas_event = {
                    "type": "CANVAS",
                    "content": result["content"],
                    "description": f"React Agent 자동 라우팅 결과 ({processing_type})",
                    "key": "auto_routed_result",
                    "id": chat_id,
                }
                yield f"data: {json.dumps(canvas_event, ensure_ascii=False)}\n\n"

                end_event = {
                    "type": "END",
                    "content": f"✅ 자동 라우팅 완료 (React Agent - {processing_type})",
                    "description": f"도구 기반 처리 성공: {routing_decision.recommended_approach}",
                    "key": "auto_routing_end",
                    "id": chat_id,
                }
                yield f"data: {json.dumps(end_event, ensure_ascii=False)}\n\n"

            return StreamingResponse(
                route_to_react(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "Access-Control-Allow-Origin": "*",
                    "X-Accel-Buffering": "no",
                },
            )

    except Exception as e:
        logger.error(f"자동 라우팅 오류: {e}")

        async def error_response():
            error_event = {
                "type": "ERROR",
                "content": f"자동 라우팅 중 오류 발생: {str(e)}",
                "description": "시스템 오류로 인한 라우팅 실패",
                "key": "auto_routing_error",
                "id": chat_id,
            }
            yield f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"

        return StreamingResponse(
            error_response(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Access-Control-Allow-Origin": "*",
                "X-Accel-Buffering": "no",
            },
        )


# =================================
# 3. 기존 호환성 엔드포인트
# =================================


@app.post("/chat/stream", tags=["Legacy Chat"])
async def stream_chat_enhanced(request: ChatRequest):
    """기존 호환성을 위한 스트리밍 채팅 엔드포인트"""
    chat_id = request.conversation_id or f"legacy_chat_{int(time.time())}"

    async def generate_response():
        try:
            async for event in enhanced_mcp_agent.process_query_with_routing(
                chat_id, request.message
            ):
                # 기존 형식으로 변환하되 새로운 키 순서 적용
                converted_event = {
                    "type": event.get("type", "MESSAGE"),
                    "content": event.get("content", ""),
                    "description": event.get("description", ""),
                    "key": event.get("key", ""),
                    "id": event.get("id", chat_id),
                }
                yield f"data: {json.dumps(converted_event, ensure_ascii=False)}\n\n"

            yield "data: [DONE]\n\n"

        except Exception as e:
            logger.error(f"레거시 스트리밍 채팅 오류: {e}")
            error_event = {
                "type": "ERROR",
                "content": f"처리 중 오류 발생: {str(e)}",
                "description": "시스템 오류",
                "key": "legacy_error",
                "id": chat_id,
            }
            yield f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"

    return StreamingResponse(
        generate_response(),
        media_type="text/plain",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Content-Type": "text/plain; charset=utf-8",
        },
    )


@app.post("/chat", tags=["Legacy Chat"])
async def chat_fallback(request: ChatRequest):
    """기존 호환성을 위한 기본 채팅 엔드포인트"""
    try:
        chat_id = request.conversation_id or f"fallback_chat_{int(time.time())}"

        if hasattr(enhanced_mcp_agent, "process_query_with_enhanced_routing"):
            events = []
            async for event in enhanced_mcp_agent.process_query_with_enhanced_routing(
                chat_id, request.message
            ):
                # 새로운 키 순서로 이벤트 변환
                converted_event = {
                    "type": event.get("type", "MESSAGE"),
                    "content": event.get("content", ""),
                    "description": event.get("description", ""),
                    "key": event.get("key", ""),
                    "id": event.get("id", chat_id),
                }
                events.append(converted_event)

            final_content = "처리 중 오류가 발생했습니다."
            for event in reversed(events):
                if event.get("type") == "CANVAS":
                    final_content = event.get("content", final_content)
                    break

            return ChatResponse(
                response=final_content,
                conversation_id=chat_id,
                events=events,
                metadata={
                    "routing_method": "enhanced",
                    "event_format": "updated_no_timestamp",
                },
            )
        else:
            events = []
            async for event in enhanced_mcp_agent.process_query_with_routing(
                chat_id, request.message
            ):
                converted_event = {
                    "type": event.get("type", "MESSAGE"),
                    "content": event.get("content", ""),
                    "description": event.get("description", ""),
                    "key": event.get("key", ""),
                    "id": event.get("id", chat_id),
                }
                events.append(converted_event)

            final_content = "처리 중 오류가 발생했습니다."
            for event in reversed(events):
                if event.get("type") == "CANVAS":
                    final_content = event.get("content", final_content)
                    break

            return ChatResponse(
                response=final_content,
                conversation_id=chat_id,
                events=events,
                metadata={
                    "routing_method": "legacy",
                    "event_format": "updated_no_timestamp",
                },
            )
    except Exception as e:
        logger.error(f"채팅 처리 오류: {e}")
        return ChatResponse(
            response=f"처리 중 오류가 발생했습니다: {str(e)}",
            conversation_id=chat_id,
            events=[],
            metadata={"error": str(e), "event_format": "updated_no_timestamp"},
        )


# =================================
# 4. 시스템 상태 및 진단 엔드포인트 (키 순서 업데이트)
# =================================


@app.get("/", tags=["System Status"])
async def root():
    """루트 엔드포인트"""
    return {
        "message": "Enhanced LangGraph ReAct MCP Chat API with Specialized Routing",
        "version": "4.1.0",
        "status": "running",
        "new_features": [
            "특화된 General Agent 엔드포인트",
            "전문 React Agent 엔드포인트",
            "자동 라우팅 시스템",
            "업데이트된 이벤트 키 순서 (type, content, description, key, id, created_at)",
        ],
        "endpoints": {
            "general_agent": "/api/v1/general-agent/chat",
            "react_agent": "/api/v1/react-agent/chat",
            "auto_routing": "/chat/enhanced/{chat_id}",
            "legacy": "/chat",
        },
    }


@app.get("/health", tags=["System Status"])
async def health_check():
    """시스템 헬스 체크 (이벤트 형식 업데이트 반영)"""
    try:
        base_health = {
            "status": "healthy",
            "timestamp": kst_now.isoformat() + "Z",
            "version": "4.1.0",
            # 기존 시스템 상태
            "agent_initialized": enhanced_mcp_agent.model is not None,
            "tools_count": (
                len(enhanced_mcp_agent.tools) if enhanced_mcp_agent.tools else 0
            ),
            "router_available": enhanced_mcp_agent.server_router is not None,
            "mcp_client_connected": enhanced_mcp_agent.mcp_client is not None,
            "recommendation_system_active": enhanced_mcp_agent.mcp_recommendation_system
            is not None,
            "vector_store_active": enhanced_mcp_agent.mcp_vector_store is not None,
            "model": (
                getattr(enhanced_mcp_agent.model, "model_name", "Unknown")
                if enhanced_mcp_agent.model
                else "None"
            ),
            "mcp_available": MCP_AVAILABLE,
            # 새로 추가된 컴포넌트들
            "system_info_generator_available": enhanced_mcp_agent.system_info_generator
            is not None,
            "memory_system_available": enhanced_mcp_agent.memory_manager is not None,
            "memory_system_enabled": False,
            # 새로운 라우팅 시스템
            "enhanced_query_analyzer_available": hasattr(
                enhanced_mcp_agent, "enhanced_query_analyzer"
            ),
            "specialized_endpoints_active": True,
            "event_format_updated": "no_timestamp",
        }

        # 메모리 시스템 상세 정보
        memory_health = {
            "available": enhanced_mcp_agent.memory_manager is not None,
            "enabled": False,
            "provider": "mem0",
            "status": "not_initialized",
            "config": {},
            "test_results": {},
            "error": None,
        }

        if enhanced_mcp_agent.memory_manager:
            try:
                memory_health.update(
                    {
                        "enabled": enhanced_mcp_agent.memory_manager.enabled,
                        "status": (
                            "operational"
                            if enhanced_mcp_agent.memory_manager.enabled
                            else "disabled"
                        ),
                    }
                )

                if enhanced_mcp_agent.memory_manager.enabled:
                    base_health["memory_system_enabled"] = True

                    memory_health["config"] = {
                        "vector_store_provider": "qdrant",
                        "vector_store_host": os.getenv("QDRANT_HOST", "localhost"),
                        "vector_store_port": os.getenv("QDRANT_PORT", "6333"),
                        "collection_name": "mcp_agent_memory",
                        "llm_provider": (
                            "openai"
                            if os.getenv("OPENAI_API_KEY")
                            else (
                                "anthropic"
                                if os.getenv("ANTHROPIC_API_KEY")
                                else "unknown"
                            )
                        ),
                        "cache_ttl": os.getenv("MEMORY_CACHE_TTL", "86400"),
                    }

                    # 메모리 시스템 기능 테스트
                    test_results = {
                        "memory_add_test": False,
                        "memory_search_test": False,
                        "preference_test": False,
                        "conversation_test": False,
                    }

                    try:
                        test_user_id = "health_check_test"
                        test_memory_id = await enhanced_mcp_agent.memory_manager.add_conversation_memory(
                            user_id=test_user_id,
                            message="Health check test message",
                            response="Health check test response",
                            metadata={"test": True, "timestamp": kst_now.isoformat()},
                        )
                        test_results["memory_add_test"] = test_memory_id is not None

                        if test_memory_id:
                            search_results = await enhanced_mcp_agent.memory_manager.get_relevant_memories(
                                user_id=test_user_id, query="health check", limit=1
                            )
                            test_results["memory_search_test"] = len(search_results) > 0

                        pref_memory_id = (
                            await enhanced_mcp_agent.memory_manager.add_user_preference(
                                user_id=test_user_id,
                                preference="Test preference for health check",
                                category="test",
                            )
                        )
                        test_results["preference_test"] = pref_memory_id is not None

                        conversation_history = await enhanced_mcp_agent.memory_manager.get_conversation_history(
                            user_id=test_user_id, limit=1
                        )
                        test_results["conversation_test"] = (
                            len(conversation_history) >= 0
                        )

                        # 테스트 메모리 정리
                        if test_memory_id:
                            await enhanced_mcp_agent.memory_manager.delete_memory(
                                test_memory_id
                            )
                        if pref_memory_id:
                            await enhanced_mcp_agent.memory_manager.delete_memory(
                                pref_memory_id
                            )

                        memory_health["test_results"] = test_results
                        memory_health["test_summary"] = {
                            "total_tests": len(test_results),
                            "passed_tests": sum(test_results.values()),
                            "success_rate": sum(test_results.values())
                            / len(test_results)
                            * 100,
                        }

                        if not all(test_results.values()):
                            memory_health["status"] = "warning"
                            if base_health["status"] == "healthy":
                                base_health["status"] = "warning"

                    except Exception as test_error:
                        memory_health["test_results"] = test_results
                        memory_health["test_error"] = str(test_error)
                        memory_health["status"] = "error"
                        logger.warning(f"메모리 시스템 테스트 실패: {test_error}")

                        if base_health["status"] == "healthy":
                            base_health["status"] = "warning"

                else:
                    memory_health["status"] = "disabled"
                    memory_health["reason"] = (
                        "Memory manager initialized but not enabled"
                    )

            except Exception as memory_error:
                memory_health.update(
                    {"status": "error", "error": str(memory_error), "enabled": False}
                )
                logger.error(f"메모리 시스템 헬스 체크 오류: {memory_error}")

                if base_health["status"] == "healthy":
                    base_health["status"] = "warning"

        else:
            memory_health.update(
                {
                    "status": "not_available",
                    "reason": "Memory manager not initialized",
                    "enabled": False,
                }
            )

        base_health["memory_system"] = memory_health

        # LLM 보강 시스템 정보
        if LLM_ENRICHMENT_AVAILABLE:
            try:
                enrichment_status = enhanced_mcp_agent.get_enrichment_status()
                base_health.update(
                    {
                        "llm_enrichment_available": True,
                        "enrichment_enabled": enrichment_status.get(
                            "enrichment_enabled", False
                        ),
                        "enriched_vector_store_active": enrichment_status.get(
                            "enriched_vector_store_ready", False
                        ),
                        "enriched_recommendation_system_active": enrichment_status.get(
                            "enriched_recommendation_system_ready", False
                        ),
                        "enrichment_progress": enrichment_status.get(
                            "enrichment_progress", 0
                        ),
                        "background_enrichment_running": enrichment_status.get(
                            "background_task_running", False
                        ),
                        "enriched_servers": enrichment_status.get(
                            "enriched_servers", 0
                        ),
                        "total_servers": enrichment_status.get("total_servers", 0),
                    }
                )
            except Exception as enrichment_error:
                base_health.update(
                    {
                        "llm_enrichment_available": True,
                        "enrichment_error": str(enrichment_error),
                        "enrichment_enabled": False,
                    }
                )
                logger.warning(f"보강 시스템 상태 조회 실패: {enrichment_error}")
        else:
            base_health.update(
                {
                    "llm_enrichment_available": False,
                    "enrichment_enabled": False,
                    "enrichment_reason": "LLM enrichment libraries not available",
                }
            )

        # 전체 시스템 상태 요약
        system_summary = {
            "core_systems_operational": base_health["agent_initialized"]
            and base_health["tools_count"] > 0,
            "advanced_features_available": base_health["recommendation_system_active"]
            or base_health["memory_system_enabled"],
            "specialized_routing_ready": base_health[
                "enhanced_query_analyzer_available"
            ]
            and base_health["specialized_endpoints_active"],
            "total_features": sum(
                [
                    base_health["agent_initialized"],
                    base_health["mcp_client_connected"],
                    base_health["recommendation_system_active"],
                    base_health["vector_store_active"],
                    base_health["memory_system_enabled"],
                    base_health["system_info_generator_available"],
                    base_health["enhanced_query_analyzer_available"],
                ]
            ),
            "operational_features": 7,
        }

        base_health["system_summary"] = system_summary

        # 전체 상태 최종 판정
        if not system_summary["core_systems_operational"]:
            base_health["status"] = "critical"
        elif (
            base_health["status"] == "healthy" and system_summary["total_features"] < 5
        ):
            base_health["status"] = "warning"

        # 상태별 메시지 추가
        status_messages = {
            "healthy": "모든 시스템이 정상적으로 작동하고 있습니다",
            "warning": "일부 시스템에 경고가 있지만 기본 기능은 정상 작동합니다",
            "critical": "핵심 시스템에 문제가 있습니다. 즉시 확인이 필요합니다",
        }

        base_health["status_message"] = status_messages.get(
            base_health["status"], "상태를 확인할 수 없습니다"
        )

        # 개선 권장사항
        recommendations = []

        if not base_health["memory_system_enabled"]:
            recommendations.append(
                "메모리 시스템 활성화를 권장합니다 (사용자 경험 개선)"
            )

        if not base_health["recommendation_system_active"]:
            recommendations.append(
                "MCP 추천 시스템 활성화를 권장합니다 (도구 선택 최적화)"
            )

        if not base_health.get("enrichment_enabled", False):
            recommendations.append("LLM 보강 시스템 활성화를 권장합니다 (정확도 향상)")

        if base_health["tools_count"] < 5:
            recommendations.append("더 많은 MCP 도구 설정을 권장합니다 (기능 확장)")

        if not base_health["enhanced_query_analyzer_available"]:
            recommendations.append(
                "향상된 쿼리 분석기 활성화를 권장합니다 (라우팅 정확도 개선)"
            )

        if recommendations:
            base_health["recommendations"] = recommendations

        return base_health

    except Exception as e:
        logger.error(f"헬스 체크 중 치명적 오류: {e}")
        return {
            "status": "critical",
            "timestamp": kst_now.isoformat() + "Z",
            "error": str(e),
            "error_type": type(e).__name__,
            "agent_initialized": (
                enhanced_mcp_agent.model is not None if enhanced_mcp_agent else False
            ),
            "memory_system_available": False,
            "memory_system_enabled": False,
            "specialized_endpoints_active": False,
            "event_format_updated": "no_timestamp",
            "status_message": "시스템 헬스 체크 중 오류가 발생했습니다",
        }


@app.get("/health/memory", tags=["System Status"])
async def memory_health_check():
    """메모리 시스템 전용 헬스 체크 (이벤트 형식 업데이트 반영)"""
    try:
        if not enhanced_mcp_agent.memory_manager:
            return {
                "status": "not_available",
                "timestamp": kst_now.isoformat() + "Z",
                "message": "메모리 관리자가 초기화되지 않았습니다",
                "available": False,
                "enabled": False,
            }

        memory_health = {
            "status": "unknown",
            "timestamp": kst_now.isoformat() + "Z",
            "available": True,
            "enabled": enhanced_mcp_agent.memory_manager.enabled,
            "configuration": {},
            "performance_tests": {},
            "detailed_tests": {},
            "recommendations": [],
        }

        if not enhanced_mcp_agent.memory_manager.enabled:
            memory_health.update(
                {
                    "status": "disabled",
                    "message": "메모리 시스템이 비활성화되어 있습니다",
                    "recommendations": [
                        "환경 변수 ENABLE_MEMORY_SYSTEM=true 설정",
                        "Qdrant 서버 연결 확인",
                        "필요한 API 키 설정 확인",
                    ],
                }
            )
            return memory_health

        # 설정 정보 수집
        memory_health["configuration"] = {
            "provider": "mem0",
            "vector_store": {
                "provider": "qdrant",
                "host": os.getenv("QDRANT_HOST", "localhost"),
                "port": os.getenv("QDRANT_PORT", "6333"),
                "collection": "mcp_agent_memory",
            },
            "llm": {
                "provider": (
                    "openai"
                    if os.getenv("OPENAI_API_KEY")
                    else "anthropic" if os.getenv("ANTHROPIC_API_KEY") else "unknown"
                ),
                "model": (
                    "gpt-4"
                    if os.getenv("OPENAI_API_KEY")
                    else (
                        "claude-3-sonnet"
                        if os.getenv("ANTHROPIC_API_KEY")
                        else "unknown"
                    )
                ),
            },
            "cache_ttl": os.getenv("MEMORY_CACHE_TTL", "86400"),
        }

        # 상세 기능 테스트
        test_user_id = f"health_check_detailed_{int(kst_now.timestamp())}"
        detailed_tests = {
            "conversation_memory": {"status": "pending", "duration": 0, "error": None},
            "user_preferences": {"status": "pending", "duration": 0, "error": None},
            "tool_usage_memory": {"status": "pending", "duration": 0, "error": None},
            "memory_search": {"status": "pending", "duration": 0, "error": None},
            "memory_update": {"status": "pending", "duration": 0, "error": None},
            "memory_deletion": {"status": "pending", "duration": 0, "error": None},
        }

        test_memory_ids = []

        try:
            import time

            # 1. 대화 메모리 테스트
            start_time = time.time()
            conv_memory_id = (
                await enhanced_mcp_agent.memory_manager.add_conversation_memory(
                    user_id=test_user_id,
                    message="Health check conversation test",
                    response="This is a test response for health check",
                    metadata={
                        "test_type": "health_check",
                        "timestamp": kst_now.isoformat(),
                    },
                )
            )
            detailed_tests["conversation_memory"]["duration"] = time.time() - start_time

            if conv_memory_id:
                detailed_tests["conversation_memory"]["status"] = "passed"
                test_memory_ids.append(conv_memory_id)
            else:
                detailed_tests["conversation_memory"]["status"] = "failed"

            # 2. 사용자 선호도 테스트
            start_time = time.time()
            pref_memory_id = (
                await enhanced_mcp_agent.memory_manager.add_user_preference(
                    user_id=test_user_id,
                    preference="I prefer detailed explanations",
                    category="communication_style",
                )
            )
            detailed_tests["user_preferences"]["duration"] = time.time() - start_time

            if pref_memory_id:
                detailed_tests["user_preferences"]["status"] = "passed"
                test_memory_ids.append(pref_memory_id)
            else:
                detailed_tests["user_preferences"]["status"] = "failed"

            # 3. 도구 사용 메모리 테스트
            start_time = time.time()
            tool_memory_id = (
                await enhanced_mcp_agent.memory_manager.add_tool_usage_memory(
                    user_id=test_user_id,
                    tool_name="test_tool",
                    query="test query",
                    success=True,
                    result_summary="Test tool usage for health check",
                )
            )
            detailed_tests["tool_usage_memory"]["duration"] = time.time() - start_time

            if tool_memory_id:
                detailed_tests["tool_usage_memory"]["status"] = "passed"
                test_memory_ids.append(tool_memory_id)
            else:
                detailed_tests["tool_usage_memory"]["status"] = "failed"

            # 4. 메모리 검색 테스트
            start_time = time.time()
            search_results = (
                await enhanced_mcp_agent.memory_manager.get_relevant_memories(
                    user_id=test_user_id, query="health check test", limit=5
                )
            )
            detailed_tests["memory_search"]["duration"] = time.time() - start_time
            detailed_tests["memory_search"]["status"] = (
                "passed" if len(search_results) > 0 else "failed"
            )
            detailed_tests["memory_search"]["results_count"] = len(search_results)

            # 5. 메모리 업데이트 테스트
            if test_memory_ids:
                start_time = time.time()
                update_success = await enhanced_mcp_agent.memory_manager.update_memory(
                    memory_id=test_memory_ids[0],
                    new_content="Updated content for health check test",
                )
                detailed_tests["memory_update"]["duration"] = time.time() - start_time
                detailed_tests["memory_update"]["status"] = (
                    "passed" if update_success else "failed"
                )

            # 6. 메모리 삭제 테스트
            deletion_results = []
            for memory_id in test_memory_ids:
                start_time = time.time()
                delete_success = await enhanced_mcp_agent.memory_manager.delete_memory(
                    memory_id
                )
                duration = time.time() - start_time
                deletion_results.append(
                    {
                        "memory_id": memory_id,
                        "success": delete_success,
                        "duration": duration,
                    }
                )

            avg_deletion_time = (
                sum(r["duration"] for r in deletion_results) / len(deletion_results)
                if deletion_results
                else 0
            )
            deletion_success_rate = (
                sum(r["success"] for r in deletion_results) / len(deletion_results)
                if deletion_results
                else 0
            )

            detailed_tests["memory_deletion"]["duration"] = avg_deletion_time
            detailed_tests["memory_deletion"]["status"] = (
                "passed" if deletion_success_rate >= 0.8 else "failed"
            )
            detailed_tests["memory_deletion"]["success_rate"] = deletion_success_rate
            detailed_tests["memory_deletion"]["deleted_count"] = len(deletion_results)

        except Exception as test_error:
            for test_name, test_info in detailed_tests.items():
                if test_info["status"] == "pending":
                    test_info["status"] = "error"
                    test_info["error"] = str(test_error)

        memory_health["detailed_tests"] = detailed_tests

        # 성능 요약
        total_tests = len(detailed_tests)
        passed_tests = sum(
            1 for test in detailed_tests.values() if test["status"] == "passed"
        )
        failed_tests = sum(
            1 for test in detailed_tests.values() if test["status"] == "failed"
        )
        error_tests = sum(
            1 for test in detailed_tests.values() if test["status"] == "error"
        )

        memory_health["performance_tests"] = {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "error_tests": error_tests,
            "success_rate": (
                (passed_tests / total_tests * 100) if total_tests > 0 else 0
            ),
            "average_response_time": (
                sum(test["duration"] for test in detailed_tests.values()) / total_tests
                if total_tests > 0
                else 0
            ),
        }

        # 전체 상태 판정
        if error_tests > 0:
            memory_health["status"] = "error"
            memory_health["message"] = f"{error_tests}개 테스트에서 오류 발생"
        elif failed_tests > total_tests * 0.3:
            memory_health["status"] = "critical"
            memory_health["message"] = (
                f"{failed_tests}개 테스트 실패 (성공률: {memory_health['performance_tests']['success_rate']:.1f}%)"
            )
        elif failed_tests > 0:
            memory_health["status"] = "warning"
            memory_health["message"] = (
                f"{failed_tests}개 테스트 실패하였으나 주요 기능은 정상"
            )
        else:
            memory_health["status"] = "healthy"
            memory_health["message"] = "모든 메모리 기능이 정상적으로 작동합니다"

        # 권장사항 생성
        if memory_health["performance_tests"]["average_response_time"] > 2.0:
            memory_health["recommendations"].append(
                "메모리 응답 시간이 느립니다. Qdrant 서버 성능을 확인하세요"
            )

        if memory_health["performance_tests"]["success_rate"] < 90:
            memory_health["recommendations"].append(
                "메모리 테스트 성공률이 낮습니다. 설정과 연결을 확인하세요"
            )

        if detailed_tests["memory_search"]["status"] != "passed":
            memory_health["recommendations"].append(
                "메모리 검색 기능에 문제가 있습니다. 벡터 스토어 상태를 확인하세요"
            )

        return memory_health

    except Exception as e:
        logger.error(f"메모리 헬스 체크 중 오류: {e}")
        return {
            "status": "critical",
            "timestamp": kst_now.isoformat() + "Z",
            "available": enhanced_mcp_agent.memory_manager is not None,
            "enabled": False,
            "error": str(e),
            "error_type": type(e).__name__,
            "message": "메모리 시스템 헬스 체크 중 치명적 오류 발생",
        }


# =================================
# 메타데이터 연결 테스트 메서드
# =================================
@app.get("/health/hiermeta", tags=["System Status"])
async def test_hierarchical_metadata_connection(self) -> Dict[str, Any]:
    """계층적 플래너의 메타데이터 연결 테스트"""
    test_results = {
        "timestamp": kst_now.isoformat(),
        "tests": {},
        "overall_status": "unknown",
    }

    try:
        # 1. 플래너 존재 확인
        if not hasattr(self, "hierarchical_planner") or not self.hierarchical_planner:
            test_results["tests"]["planner_existence"] = {
                "status": "FAIL",
                "message": "Hierarchical planner not initialized",
            }
            test_results["overall_status"] = "FAIL"
            return test_results

        test_results["tests"]["planner_existence"] = {
            "status": "PASS",
            "message": f"Planner type: {type(self.hierarchical_planner).__name__}",
        }

        # 2. 추천 시스템 연결 테스트
        if (
            hasattr(self.hierarchical_planner, "mcp_recommendation_system")
            and self.hierarchical_planner.mcp_recommendation_system
        ):
            try:
                # 테스트 쿼리로 추천 시스템 호출
                test_recommendation = await self.hierarchical_planner.mcp_recommendation_system.recommend_tools(
                    "test query", max_tools=1
                )
                test_results["tests"]["recommendation_system"] = {
                    "status": "PASS",
                    "message": f"Recommendation system working: {type(self.hierarchical_planner.mcp_recommendation_system).__name__}",
                    "test_result": test_recommendation is not None,
                }
            except Exception as e:
                test_results["tests"]["recommendation_system"] = {
                    "status": "FAIL",
                    "message": f"Recommendation system error: {str(e)}",
                }
        else:
            test_results["tests"]["recommendation_system"] = {
                "status": "FAIL",
                "message": "Recommendation system not connected",
            }

        # 3. 벡터 스토어 연결 테스트
        if (
            hasattr(self.hierarchical_planner, "mcp_vector_store")
            and self.hierarchical_planner.mcp_vector_store
        ):
            try:
                # 테스트 검색
                test_search = (
                    self.hierarchical_planner.mcp_vector_store.search_tools_only(
                        "test", limit=1
                    )
                )
                test_results["tests"]["vector_store"] = {
                    "status": "PASS",
                    "message": f"Vector store working: {type(self.hierarchical_planner.mcp_vector_store).__name__}",
                    "test_result": len(test_search) >= 0,
                }
            except Exception as e:
                test_results["tests"]["vector_store"] = {
                    "status": "FAIL",
                    "message": f"Vector store error: {str(e)}",
                }
        else:
            test_results["tests"]["vector_store"] = {
                "status": "FAIL",
                "message": "Vector store not connected",
            }

        # 4. 실행기 메타데이터 연결 테스트
        if hasattr(self, "hierarchical_executor") and self.hierarchical_executor:
            executor_metadata = getattr(
                self.hierarchical_executor, "metadata_enhanced", False
            )
            test_results["tests"]["executor_metadata"] = {
                "status": "PASS" if executor_metadata else "FAIL",
                "message": f"Executor metadata enhanced: {executor_metadata}",
            }
        else:
            test_results["tests"]["executor_metadata"] = {
                "status": "FAIL",
                "message": "Hierarchical executor not initialized",
            }

        # 5. 전체 상태 결정
        passed_tests = sum(
            1 for test in test_results["tests"].values() if test["status"] == "PASS"
        )
        total_tests = len(test_results["tests"])

        if passed_tests == total_tests:
            test_results["overall_status"] = "PASS"
        elif passed_tests > total_tests / 2:
            test_results["overall_status"] = "PARTIAL"
        else:
            test_results["overall_status"] = "FAIL"

        test_results["summary"] = f"{passed_tests}/{total_tests} tests passed"

    except Exception as e:
        test_results["tests"]["system_error"] = {
            "status": "FAIL",
            "message": f"System error during testing: {str(e)}",
        }
        test_results["overall_status"] = "ERROR"

    return test_results


# =================================
# 5. MCP 도구 및 추천 시스템 엔드포인트 (키 순서 업데이트)
# =================================


@app.post("/mcp/recommend", tags=["MCP Recommendation"])
async def get_mcp_recommendation(request: MCPRecommendationRequest):
    """MCP 도구 추천 API (이벤트 형식 업데이트 반영)"""
    try:
        if not enhanced_mcp_agent.mcp_recommendation_system:
            return {
                "status": "unavailable",
                "message": "MCP 추천 시스템이 활성화되지 않았습니다.",
                "query": request.query,
                "created_at": kst_now.isoformat() + "Z",
            }

        recommendation = await enhanced_mcp_agent.get_mcp_recommendation(request.query)

        if recommendation:
            return {
                "status": "success",
                "query": request.query,
                "confidence_score": recommendation.confidence_score,
                "explanation": recommendation.explanation,
                "recommended_servers": [
                    {
                        "server_name": server["server_name"],
                        "score": server["score"],
                        "categories": server.get("tags", []),
                    }
                    for server in recommendation.recommended_servers
                ],
                "recommended_tools": [
                    {
                        "server_name": tool.server_name,
                        "tool_name": tool.tool_name,
                        "score": tool.score,
                        "category": tool.category,
                        "description": tool.description,
                        "confidence": tool.confidence,
                        "reason": tool.reason,
                    }
                    for tool in recommendation.recommended_tools
                ],
                "tool_sequence": recommendation.tool_sequence,
                "created_at": kst_now.isoformat() + "Z",
            }
        else:
            return {
                "status": "no_recommendations",
                "message": "추천할 도구를 찾을 수 없습니다.",
                "query": request.query,
                "created_at": kst_now.isoformat() + "Z",
            }

    except Exception as e:
        logger.error(f"MCP 추천 API 오류: {e}")
        return {
            "status": "error",
            "error": str(e),
            "query": request.query,
            "created_at": kst_now.isoformat() + "Z",
        }


@app.get("/tools", tags=["MCP Tools"])
async def get_tools():
    """사용 가능한 도구 목록 조회 (이벤트 형식 업데이트 반영)"""
    try:
        tools_info = []
        if enhanced_mcp_agent.tools:
            for tool in enhanced_mcp_agent.tools:
                tool_info = {
                    "name": tool.name,
                    "description": getattr(
                        tool, "description", "No description available"
                    ),
                }
                tools_info.append(tool_info)

        return {
            "tools": tools_info,
            "count": len(enhanced_mcp_agent.tools) if enhanced_mcp_agent.tools else 0,
            "mcp_available": MCP_AVAILABLE,
            "routing_enabled": enhanced_mcp_agent.server_router is not None,
            "recommendation_system": enhanced_mcp_agent.mcp_recommendation_system
            is not None,
            "vector_store": enhanced_mcp_agent.mcp_vector_store is not None,
            "enhanced_query_analyzer": hasattr(
                enhanced_mcp_agent, "enhanced_query_analyzer"
            ),
            "created_at": kst_now.isoformat() + "Z",
        }
    except Exception as e:
        logger.error(f"도구 목록 조회 오류: {e}")
        return {
            "tools": [],
            "count": 0,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


@app.get("/mcp/metadata/status", tags=["MCP Tools", "System Status"])
async def get_metadata_status():
    """MCP 메타데이터 시스템 상태 조회 (이벤트 형식 업데이트 반영)"""
    try:
        status = {
            "vector_store_active": enhanced_mcp_agent.mcp_vector_store is not None,
            "recommendation_system_active": enhanced_mcp_agent.mcp_recommendation_system
            is not None,
            "metadata_collector_active": enhanced_mcp_agent.mcp_metadata_collector
            is not None,
            "config_loader_active": enhanced_mcp_agent.mcp_config_loader is not None,
            "qdrant_host": os.getenv("QDRANT_HOST", "localhost"),
            "qdrant_port": os.getenv("QDRANT_PORT", "6333"),
            "azure_openai_configured": bool(os.getenv("AZURE_OPENAI_API_KEY")),
            "enhanced_query_analyzer_active": hasattr(
                enhanced_mcp_agent, "enhanced_query_analyzer"
            ),
            "specialized_endpoints_available": True,
            "event_format_version": "4.1.0",
            "created_at": kst_now.isoformat() + "Z",
        }

        # MCP 서버 설정 정보
        if enhanced_mcp_agent.mcp_config_loader:
            mcp_servers = enhanced_mcp_agent.mcp_config_loader.load_config()
            status["mcp_servers"] = {
                "total_configured": len(mcp_servers),
                "server_names": list(mcp_servers.keys()),
                "config_path": "mcp_config.json",
            }

        # 도구 분석 정보
        if enhanced_mcp_agent.tools:
            tool_categories = {}
            for tool in enhanced_mcp_agent.tools:
                tool_name = tool.name.lower()
                tool_description = getattr(tool, "description", "").lower()
                combined_text = f"{tool_name} {tool_description}"

                categories = []
                if any(kw in combined_text for kw in ["browser", "web", "scrape"]):
                    categories.append("웹 브라우징")
                if any(kw in combined_text for kw in ["search", "find", "query"]):
                    categories.append("검색")
                if any(kw in combined_text for kw in ["file", "read", "write"]):
                    categories.append("파일 작업")
                if any(kw in combined_text for kw in ["command", "execute", "shell"]):
                    categories.append("시스템 명령")
                if any(kw in combined_text for kw in ["api", "http", "github"]):
                    categories.append("API 연동")

                for category in categories:
                    tool_categories[category] = tool_categories.get(category, 0) + 1

            status["tools_analysis"] = {
                "total_tools": len(enhanced_mcp_agent.tools),
                "categories": tool_categories,
                "sample_tools": [tool.name for tool in enhanced_mcp_agent.tools[:5]],
            }

        # 벡터 스토어 상태
        if enhanced_mcp_agent.mcp_vector_store:
            try:
                test_results = enhanced_mcp_agent.mcp_vector_store.smart_search(
                    "test", limit=1
                )
                status["vector_store_status"] = {
                    "operational": True,
                    "test_query_results": len(test_results),
                    "collection_name": enhanced_mcp_agent.mcp_vector_store.collection_name,
                }
            except Exception as e:
                status["vector_store_status"] = {"operational": False, "error": str(e)}

        return status

    except Exception as e:
        logger.error(f"메타데이터 상태 조회 오류: {e}")
        return {
            "status": "error",
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


# =================================
# 6. 분석 및 통계 엔드포인트 (키 순서 업데이트)
# =================================


@app.get("/memory/stats/{user_id}", tags=["Analytics"])
async def get_user_memory_stats(user_id: str):
    """사용자 메모리 통계 조회 (이벤트 형식 업데이트 반영)"""
    try:
        if (
            not enhanced_mcp_agent.memory_manager
            or not enhanced_mcp_agent.memory_manager.enabled
        ):
            return {
                "status": "disabled",
                "message": "메모리 시스템이 비활성화되어 있습니다",
                "created_at": kst_now.isoformat() + "Z",
            }

        stats = await enhanced_mcp_agent.memory_manager.get_memory_stats(user_id)
        return {
            "status": "success",
            "user_id": user_id,
            "stats": stats,
            "created_at": kst_now.isoformat() + "Z",
        }

    except Exception as e:
        logger.error(f"메모리 통계 조회 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memory/conversation/{user_id}", tags=["Analytics"])
async def get_user_conversation_history(user_id: str, limit: int = 10):
    """사용자 대화 기록 조회 (이벤트 형식 업데이트 반영)"""
    try:
        if (
            not enhanced_mcp_agent.memory_manager
            or not enhanced_mcp_agent.memory_manager.enabled
        ):
            return {
                "status": "disabled",
                "conversations": [],
                "created_at": kst_now.isoformat() + "Z",
            }

        limit = min(max(1, limit), 50)

        conversations = (
            await enhanced_mcp_agent.memory_manager.get_conversation_history(
                user_id=user_id, limit=limit
            )
        )

        return {
            "status": "success",
            "user_id": user_id,
            "conversation_count": len(conversations),
            "conversations": conversations,
            "created_at": kst_now.isoformat() + "Z",
        }

    except Exception as e:
        logger.error(f"대화 기록 조회 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/memory/preference/{user_id}", tags=["Analytics"])
async def add_user_preference(user_id: str, preference: str, category: str = "general"):
    """사용자 선호도 추가 (이벤트 형식 업데이트 반영)"""
    try:
        if (
            not enhanced_mcp_agent.memory_manager
            or not enhanced_mcp_agent.memory_manager.enabled
        ):
            return {
                "status": "disabled",
                "message": "메모리 시스템이 비활성화되어 있습니다",
                "created_at": kst_now.isoformat() + "Z",
            }

        memory_id = await enhanced_mcp_agent.memory_manager.add_user_preference(
            user_id=user_id, preference=preference, category=category
        )

        if memory_id:
            return {
                "status": "success",
                "message": "선호도가 성공적으로 저장되었습니다",
                "memory_id": memory_id,
                "user_id": user_id,
                "preference": preference,
                "category": category,
                "created_at": kst_now.isoformat() + "Z",
            }
        else:
            return {
                "status": "failed",
                "message": "선호도 저장에 실패했습니다",
                "created_at": kst_now.isoformat() + "Z",
            }

    except Exception as e:
        logger.error(f"선호도 추가 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/memory/preferences/{user_id}", tags=["Analytics"])
async def get_user_preferences(user_id: str, category: Optional[str] = None):
    """사용자 선호도 조회 (이벤트 형식 업데이트 반영)"""
    try:
        if (
            not enhanced_mcp_agent.memory_manager
            or not enhanced_mcp_agent.memory_manager.enabled
        ):
            return {
                "status": "disabled",
                "preferences": [],
                "created_at": kst_now.isoformat() + "Z",
            }

        preferences = await enhanced_mcp_agent.memory_manager.get_user_preferences(
            user_id=user_id, category=category
        )

        return {
            "status": "success",
            "user_id": user_id,
            "category_filter": category,
            "preference_count": len(preferences),
            "preferences": preferences,
            "created_at": kst_now.isoformat() + "Z",
        }

    except Exception as e:
        logger.error(f"선호도 조회 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/memory/{user_id}/{memory_id}", tags=["Analytics"])
async def delete_user_memory(user_id: str, memory_id: str):
    """특정 메모리 삭제 (이벤트 형식 업데이트 반영)"""
    try:
        if (
            not enhanced_mcp_agent.memory_manager
            or not enhanced_mcp_agent.memory_manager.enabled
        ):
            return {
                "status": "disabled",
                "message": "메모리 시스템이 비활성화되어 있습니다",
                "created_at": kst_now.isoformat() + "Z",
            }

        success = await enhanced_mcp_agent.memory_manager.delete_memory(memory_id)

        if success:
            return {
                "status": "success",
                "message": "메모리가 성공적으로 삭제되었습니다",
                "user_id": user_id,
                "memory_id": memory_id,
                "created_at": kst_now.isoformat() + "Z",
            }
        else:
            return {
                "status": "failed",
                "message": "메모리 삭제에 실패했습니다",
                "created_at": kst_now.isoformat() + "Z",
            }

    except Exception as e:
        logger.error(f"메모리 삭제 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# =================================
# 7. 디버깅 및 진단 엔드포인트 (키 순서 업데이트)
# =================================


@app.get("/debug/mcp/diagnosis", tags=["Debug & Diagnosis"])
async def mcp_diagnosis():
    """MCP 시스템 종합 진단 (이벤트 형식 업데이트 반영)"""
    diagnosis = {
        "created_at": kst_now.isoformat() + "Z",
        "overall_status": "healthy",
        "issues": [],
        "warnings": [],
        "suggestions": [],
        "details": {},
        "event_format_version": "4.1.0",
    }

    try:
        # 1. 기본 시스템 진단
        basic_system = {
            "model_loaded": enhanced_mcp_agent.model is not None,
            "tools_count": (
                len(enhanced_mcp_agent.tools) if enhanced_mcp_agent.tools else 0
            ),
            "mcp_client_connected": enhanced_mcp_agent.mcp_client is not None,
            "memory_available": enhanced_mcp_agent.memory is not None,
            "router_active": enhanced_mcp_agent.server_router is not None,
            "enhanced_query_analyzer_active": hasattr(
                enhanced_mcp_agent, "enhanced_query_analyzer"
            ),
        }

        diagnosis["details"]["basic_system"] = basic_system

        if not basic_system["model_loaded"]:
            diagnosis["issues"].append("LLM 모델이 로드되지 않았습니다")
            diagnosis["overall_status"] = "critical"

        if basic_system["tools_count"] == 0:
            diagnosis["warnings"].append("사용 가능한 도구가 없습니다")
            if diagnosis["overall_status"] == "healthy":
                diagnosis["overall_status"] = "warning"

        # 2. MCP 설정 파일 진단
        config_status = enhanced_mcp_agent.setup_mcp_config_diagnostics()
        diagnosis["details"]["config_file"] = {
            "exists": os.path.exists("mcp_config.json"),
            "valid": config_status,
            "path": "mcp_config.json",
        }

        if not config_status:
            diagnosis["issues"].append("MCP 설정 파일이 유효하지 않습니다")
            diagnosis["overall_status"] = "critical"

        # 3. 벡터 스토어 진단
        vector_store_status = {
            "initialized": enhanced_mcp_agent.mcp_vector_store is not None,
            "operational": False,
            "collection_exists": False,
        }

        if enhanced_mcp_agent.mcp_vector_store:
            try:
                test_results = enhanced_mcp_agent.mcp_vector_store.smart_search(
                    "diagnostic_test", limit=1
                )
                vector_store_status["operational"] = True
                vector_store_status["collection_exists"] = True
                vector_store_status["test_results_count"] = len(test_results)
            except Exception as e:
                vector_store_status["error"] = str(e)
                diagnosis["warnings"].append(f"벡터 스토어 테스트 실패: {e}")
        else:
            diagnosis["warnings"].append("벡터 스토어가 초기화되지 않았습니다")

        diagnosis["details"]["vector_store"] = vector_store_status

        # 4. 추천 시스템 진단
        recommendation_status = {
            "initialized": enhanced_mcp_agent.mcp_recommendation_system is not None,
            "functional": False,
        }

        if enhanced_mcp_agent.mcp_recommendation_system:
            try:
                test_recommendation = await enhanced_mcp_agent.get_mcp_recommendation(
                    "test search query"
                )
                recommendation_status["functional"] = test_recommendation is not None
                if test_recommendation:
                    recommendation_status["confidence_score"] = (
                        test_recommendation.confidence_score
                    )
            except Exception as e:
                recommendation_status["error"] = str(e)
                diagnosis["warnings"].append(f"추천 시스템 테스트 실패: {e}")
        else:
            diagnosis["warnings"].append("추천 시스템이 초기화되지 않았습니다")

        diagnosis["details"]["recommendation_system"] = recommendation_status

        # 5. 새로운 라우팅 시스템 진단
        routing_system_status = {
            "enhanced_query_analyzer": hasattr(
                enhanced_mcp_agent, "enhanced_query_analyzer"
            ),
            "specialized_endpoints": True,
            "auto_routing_available": True,
        }

        if not routing_system_status["enhanced_query_analyzer"]:
            diagnosis["warnings"].append("향상된 쿼리 분석기가 초기화되지 않았습니다")
            routing_system_status["enhanced_query_analyzer"] = False

        diagnosis["details"]["routing_system"] = routing_system_status

        # 6. 도구 분석
        if enhanced_mcp_agent.tools:
            tools_with_desc = sum(
                1
                for tool in enhanced_mcp_agent.tools
                if getattr(tool, "description", "")
            )
            tools_analysis = {
                "total_tools": len(enhanced_mcp_agent.tools),
                "tools_with_description": tools_with_desc,
                "description_coverage": tools_with_desc
                / len(enhanced_mcp_agent.tools)
                * 100,
            }

            if tools_analysis["description_coverage"] < 80:
                diagnosis["warnings"].append(
                    f"도구 설명 커버리지가 낮습니다 ({tools_analysis['description_coverage']:.1f}%)"
                )

            diagnosis["details"]["tools_analysis"] = tools_analysis

        # 7. 환경 변수 진단
        env_status = {
            "anthropic_api_key": bool(os.getenv("ANTHROPIC_API_KEY")),
            "openai_api_key": bool(os.getenv("OPENAI_API_KEY")),
            "azure_openai_api_key": bool(os.getenv("AZURE_OPENAI_API_KEY")),
            "qdrant_host": bool(os.getenv("QDRANT_HOST")),
            "model_name": bool(os.getenv("MODEL_NAME")),
        }

        diagnosis["details"]["environment"] = env_status

        if not any([env_status["anthropic_api_key"], env_status["openai_api_key"]]):
            diagnosis["issues"].append("LLM API 키가 설정되지 않았습니다")
            diagnosis["overall_status"] = "critical"

        # 개선 제안 생성
        if diagnosis["overall_status"] == "critical":
            diagnosis["suggestions"].extend(
                [
                    "1. 환경 변수 설정을 확인하세요 (.env 파일)",
                    "2. mcp_config.json 파일을 검토하고 수정하세요",
                    "3. 필요한 의존성이 모두 설치되었는지 확인하세요",
                ]
            )
        elif diagnosis["overall_status"] == "warning":
            diagnosis["suggestions"].extend(
                [
                    "1. Qdrant 서버 연결을 확인하세요",
                    "2. MCP 서버 설정을 검토하세요",
                    "3. 도구 설명을 보완하여 추천 정확도를 향상시키세요",
                    "4. 향상된 쿼리 분석기 활성화를 고려하세요",
                ]
            )
        else:
            diagnosis["suggestions"].extend(
                [
                    "시스템이 정상적으로 작동하고 있습니다",
                    "새로운 특화 엔드포인트를 활용하여 성능을 최적화하세요",
                ]
            )

        return diagnosis

    except Exception as e:
        logger.error(f"시스템 진단 중 오류: {e}")
        diagnosis["overall_status"] = "critical"
        diagnosis["issues"].append(f"진단 중 오류 발생: {str(e)}")
        return diagnosis


@app.post("/debug/test-metadata-integration", tags=["Debug & Diagnosis"])
async def test_metadata_integration():
    """MCP 메타데이터 통합 테스트"""
    try:
        test_results = {
            "hierarchical_planner_metadata": {
                "connected": hasattr(enhanced_mcp_agent, "hierarchical_planner")
                and hasattr(
                    enhanced_mcp_agent.hierarchical_planner, "metadata_enhanced"
                )
                and enhanced_mcp_agent.hierarchical_planner.metadata_enhanced,
                "vector_store": hasattr(
                    enhanced_mcp_agent.hierarchical_planner, "mcp_vector_store"
                )
                and enhanced_mcp_agent.hierarchical_planner.mcp_vector_store
                is not None,
                "recommendation_system": hasattr(
                    enhanced_mcp_agent.hierarchical_planner, "mcp_recommendation_system"
                )
                and enhanced_mcp_agent.hierarchical_planner.mcp_recommendation_system
                is not None,
            },
            "hierarchical_executor_metadata": {
                "connected": hasattr(enhanced_mcp_agent, "hierarchical_executor")
                and hasattr(
                    enhanced_mcp_agent.hierarchical_executor, "metadata_enhanced"
                )
                and enhanced_mcp_agent.hierarchical_executor.metadata_enhanced,
                "vector_store": hasattr(
                    enhanced_mcp_agent.hierarchical_executor, "mcp_vector_store"
                )
                and enhanced_mcp_agent.hierarchical_executor.mcp_vector_store
                is not None,
                "enriched_vector_store": hasattr(
                    enhanced_mcp_agent.hierarchical_executor, "enriched_vector_store"
                )
                and enhanced_mcp_agent.hierarchical_executor.enriched_vector_store
                is not None,
            },
            "created_at": kst_now.isoformat() + "Z",
        }

        # 실제 메타데이터 검색 테스트
        if (
            hasattr(enhanced_mcp_agent, "hierarchical_executor")
            and enhanced_mcp_agent.hierarchical_executor
            and hasattr(enhanced_mcp_agent.hierarchical_executor, "mcp_vector_store")
            and enhanced_mcp_agent.hierarchical_executor.mcp_vector_store
        ):

            try:
                # 테스트 검색
                search_results = enhanced_mcp_agent.hierarchical_executor.mcp_vector_store.search_tools_only(
                    "browser navigation", limit=3
                )
                test_results["metadata_search_test"] = {
                    "success": True,
                    "results_count": len(search_results),
                    "sample_results": [
                        {
                            "entity_name": result.get("entity_name", ""),
                            "category": result.get("category", ""),
                            "score": result.get("score", 0),
                        }
                        for result in search_results[:2]
                    ],
                }
            except Exception as search_error:
                test_results["metadata_search_test"] = {
                    "success": False,
                    "error": str(search_error),
                }

        # 보강된 시스템 테스트
        if (
            enhanced_mcp_agent.enrichment_enabled
            and hasattr(enhanced_mcp_agent, "hierarchical_executor")
            and enhanced_mcp_agent.hierarchical_executor
            and hasattr(
                enhanced_mcp_agent.hierarchical_executor, "enriched_vector_store"
            )
            and enhanced_mcp_agent.hierarchical_executor.enriched_vector_store
        ):

            try:
                enriched_results = enhanced_mcp_agent.hierarchical_executor.enriched_vector_store.search_tools_only(
                    "web search extraction", limit=3
                )
                test_results["enriched_search_test"] = {
                    "success": True,
                    "results_count": len(enriched_results),
                    "enrichment_enabled": True,
                }
            except Exception as enriched_error:
                test_results["enriched_search_test"] = {
                    "success": False,
                    "error": str(enriched_error),
                }
        else:
            test_results["enriched_search_test"] = {
                "success": False,
                "reason": "Enriched system not enabled or not available",
            }

        return {"success": True, "test_results": test_results}

    except Exception as e:
        logger.error(f"메타데이터 통합 테스트 오류: {e}")
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


@app.post("/debug/test-hierarchical-with-metadata", tags=["Debug & Diagnosis"])
async def test_hierarchical_planning_with_metadata(request: Dict[str, str]):
    """메타데이터를 활용한 계층적 계획 테스트"""
    try:
        query = request.get(
            "query",
            "naver.com에서 USB-C 케이블을 검색해서 3개 추천하고 파일로 저장해줘",
        )

        # 1. 쿼리 분석
        routing_decision = (
            enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(query)
        )

        # 2. 계층적 계획 생성 (메타데이터 활용)
        if (
            hasattr(enhanced_mcp_agent, "hierarchical_planner")
            and enhanced_mcp_agent.hierarchical_planner
        ):

            execution_plan = (
                await enhanced_mcp_agent.hierarchical_planner.create_execution_plan(
                    query, routing_decision
                )
            )

            # 3. 각 하위 작업별 도구 선택 테스트 (메타데이터 활용)
            tool_selection_results = []

            if (
                hasattr(enhanced_mcp_agent, "hierarchical_executor")
                and enhanced_mcp_agent.hierarchical_executor
            ):

                for subtask in execution_plan.subtasks:
                    selected_tools = await enhanced_mcp_agent.hierarchical_executor._select_tools_for_task(
                        subtask
                    )

                    tool_selection_results.append(
                        {
                            "subtask_name": subtask.name,
                            "required_tools": subtask.required_tools,
                            "selected_tools": [tool.name for tool in selected_tools],
                            "selection_method": (
                                "metadata_enhanced"
                                if hasattr(
                                    enhanced_mcp_agent.hierarchical_executor,
                                    "metadata_enhanced",
                                )
                                and enhanced_mcp_agent.hierarchical_executor.metadata_enhanced
                                else "basic"
                            ),
                        }
                    )

            # 4. 하위 작업 쿼리 생성 테스트 (메타데이터 활용)
            if execution_plan.subtasks:
                first_subtask = execution_plan.subtasks[0]
                enhanced_query = (
                    enhanced_mcp_agent.hierarchical_executor._generate_subtask_query(
                        first_subtask, execution_plan, []
                    )
                )

                sample_query_preview = (
                    enhanced_query[:500] + "..."
                    if len(enhanced_query) > 500
                    else enhanced_query
                )
            else:
                sample_query_preview = "No subtasks generated"

            return {
                "success": True,
                "query": query,
                "routing_decision": {
                    "complexity": routing_decision.complexity.value,
                    "confidence": routing_decision.confidence,
                    "requires_planning": routing_decision.requires_planning,
                },
                "execution_plan": {
                    "plan_id": execution_plan.plan_id,
                    "total_subtasks": execution_plan.total_subtasks,
                    "subtasks": [
                        {
                            "name": task.name,
                            "description": task.description,
                            "required_tools": task.required_tools,
                        }
                        for task in execution_plan.subtasks
                    ],
                },
                "tool_selection_results": tool_selection_results,
                "sample_enhanced_query_preview": sample_query_preview,
                "metadata_integration_status": {
                    "planner_enhanced": hasattr(
                        enhanced_mcp_agent.hierarchical_planner, "metadata_enhanced"
                    )
                    and enhanced_mcp_agent.hierarchical_planner.metadata_enhanced,
                    "executor_enhanced": hasattr(
                        enhanced_mcp_agent.hierarchical_executor, "metadata_enhanced"
                    )
                    and enhanced_mcp_agent.hierarchical_executor.metadata_enhanced,
                    "enriched_system_enabled": enhanced_mcp_agent.enrichment_enabled,
                },
                "created_at": kst_now.isoformat() + "Z",
            }
        else:
            return {
                "success": False,
                "error": "Hierarchical planner not available",
                "created_at": kst_now.isoformat() + "Z",
            }

    except Exception as e:
        logger.error(f"계층적 계획 메타데이터 테스트 오류: {e}")
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


# =================================
# Semantic 분석기 관리 유틸리티
# =================================
#  Semantic 분석기 상태 확인 유틸리티
def check_semantic_analyzer_status(agent):
    """Semantic 분석기 상태 확인"""
    status = {
        "semantic_analyzer_available": hasattr(agent, "semantic_analyzer"),
        "semantic_analyzer_initialized": False,
        "embedding_model_available": False,
        "llm_model_available": False,
        "can_perform_vector_similarity": False,
    }

    if hasattr(agent, "semantic_analyzer") and agent.semantic_analyzer:
        status["semantic_analyzer_initialized"] = True

        if (
            hasattr(agent.semantic_analyzer, "embedding_model")
            and agent.semantic_analyzer.embedding_model
        ):
            status["embedding_model_available"] = True
            status["can_perform_vector_similarity"] = True

        if (
            hasattr(agent.semantic_analyzer, "llm_model")
            and agent.semantic_analyzer.llm_model
        ):
            status["llm_model_available"] = True

    return status


async def force_enable_semantic_routing_v2(agent):
    """Semantic 라우팅 강제 활성화 - v2"""
    try:
        print("🔧 Semantic 라우팅 v2 활성화 시작...")

        # 1. Semantic analyzer 초기화 확인/생성
        if not hasattr(agent, "semantic_analyzer") or not agent.semantic_analyzer:
            try:
                from langchain_openai import AzureOpenAIEmbeddings

                embedding_model = AzureOpenAIEmbeddings(
                    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                    api_version=os.getenv(
                        "AZURE_OPENAI_API_VERSION", "2024-02-15-preview"
                    ),
                    deployment="text-embedding-3-small",
                )

                agent.semantic_analyzer = EnhancedSemanticQueryAnalyzer(
                    embedding_model=embedding_model, llm_model=agent.model
                )

                print("✅ Semantic analyzer 생성 완료")

            except Exception as e:
                print(f"❌ Semantic analyzer 생성 실패: {e}")
                return False

        # 2. enhanced_query_analyzer의 메서드 교체
        if hasattr(agent, "enhanced_query_analyzer"):
            # 원본 메서드 백업
            if not hasattr(
                agent.enhanced_query_analyzer, "_original_analyze_query_complexity"
            ):
                agent.enhanced_query_analyzer._original_analyze_query_complexity = (
                    agent.enhanced_query_analyzer.analyze_query_complexity
                )

            # 새 메서드로 교체
            agent.enhanced_query_analyzer.analyze_query_complexity = (
                agent.semantic_analyzer.analyze_query_semantic
            )

            print("✅ Enhanced query analyzer 메서드 교체 완료")
        else:
            print("❌ Enhanced query analyzer를 찾을 수 없습니다")
            return False

        # 3. 테스트
        test_query = "naver.com에서 usb-c 타입 케이블을 검색해서, url과 함께 3개 추천해주고, wiki에서 유박비료에 찾아 내용을 보여주고, 이 모든 내용을 /content/test.md 파일로 마크다운 형식으로 저장해줘."

        try:
            result = await agent.semantic_analyzer.analyze_query_semantic(test_query)
            print(
                f"🧪 테스트 성공: {result.complexity.value} (신뢰도: {result.confidence:.3f})"
            )
            print(f"   추론: {result.reasoning}")

            agent._semantic_routing_v2_enabled = True
            return True

        except Exception as test_error:
            print(f"❌ 테스트 실패: {test_error}")
            return False

    except Exception as e:
        print(f"❌ Semantic 라우팅 v2 활성화 실패: {e}")
        return False


# 3. 테스트 API 엔드포인트
@app.post("/debug/enable-semantic-v2", tags=["Debug & Diagnosis"])
async def enable_semantic_routing_v2():
    """Semantic 라우팅 v2 활성화"""
    try:
        success = await force_enable_semantic_routing_v2(enhanced_mcp_agent)

        if success:
            # 테스트 쿼리로 확인
            test_query = "naver.com에서 usb-c 타입 케이블을 검색해서, url과 함께 3개 추천해주고, wiki에서 유박비료에 찾아 내용을 보여주고, 이 모든 내용을 /content/test.md 파일로 마크다운 형식으로 저장해줘."

            # 기존 방식
            original_result = enhanced_mcp_agent.enhanced_query_analyzer._original_analyze_query_complexity(
                test_query
            )

            # 새로운 방식
            new_result = await enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(
                test_query
            )

            return {
                "success": True,
                "message": "Semantic 라우팅 v2가 활성화되었습니다",
                "test_query": test_query,
                "original_result": {
                    "complexity": original_result.complexity.value,
                    "confidence": original_result.confidence,
                    "reasoning": original_result.reasoning,
                },
                "new_result": {
                    "complexity": new_result.complexity.value,
                    "confidence": new_result.confidence,
                    "reasoning": new_result.reasoning,
                },
                "improvement": {
                    "complexity_changed": original_result.complexity
                    != new_result.complexity,
                    "confidence_improved": new_result.confidence
                    > original_result.confidence,
                    "better_classification": new_result.complexity.value
                    == "complex_tool",
                },
                "created_at": kst_now.isoformat() + "Z",
            }
        else:
            return {
                "success": False,
                "message": "Semantic 라우팅 v2 활성화 실패",
                "created_at": kst_now.isoformat() + "Z",
            }

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


## 3. 수정된 버전 2: 테스트 부분만 동기화


def force_enable_semantic_routing_fixed_sync(agent):
    """수정된 Semantic 라우팅 활성화 함수 (동기 버전 - 테스트 제거)"""
    try:
        # 1. 상태 확인
        status = check_semantic_analyzer_status(agent)

        print("🔍 Semantic 분석기 상태:")
        for key, value in status.items():
            emoji = "✅" if value else "❌"
            print(f"   {emoji} {key}: {value}")

        # 2. 모든 컴포넌트가 준비되어 있는지 확인
        if not status["can_perform_vector_similarity"]:
            print("❌ 벡터 유사도 분석을 위한 컴포넌트가 준비되지 않았습니다")
            return False

        # 3. 이미 활성화되어 있는지 확인
        if (
            hasattr(agent, "_semantic_routing_enabled")
            and agent._semantic_routing_enabled
        ):
            print("✅ Semantic 라우팅이 이미 활성화되어 있습니다")
            return True

        # 4. 안전한 메서드 래핑
        try:
            # 기존 메서드 백업 (한 번만)
            if not hasattr(agent, "_original_enhanced_routing"):
                if hasattr(agent, "process_query_with_enhanced_routing"):
                    agent._original_enhanced_routing = (
                        agent.process_query_with_enhanced_routing
                    )
                else:
                    print(
                        "❌ process_query_with_enhanced_routing 메서드를 찾을 수 없습니다"
                    )
                    return False

            # 5. 새로운 래퍼 함수 정의
            async def semantic_enhanced_wrapper(chat_id: str, query: str):
                """개선된 Semantic 분석 래퍼"""
                routing_decision = None

                # Semantic 분석 시도
                if hasattr(agent, "semantic_analyzer") and agent.semantic_analyzer:
                    try:
                        logger.info(f"🧠 Semantic 분석 시작: {query[:50]}...")
                        semantic_result = (
                            await agent.semantic_analyzer.analyze_query_semantic(query)
                        )
                        routing_decision = semantic_result

                        logger.info(
                            f"✅ Semantic 분석 완료: {semantic_result.complexity.value} (신뢰도: {semantic_result.confidence:.3f})"
                        )

                        # 결과를 agent에 임시 저장
                        agent._last_semantic_result = semantic_result

                    except Exception as e:
                        logger.warning(f"⚠️ Semantic 분석 실패: {e}")
                        routing_decision = None

                # 기존 메서드 호출 (event generator)
                try:
                    async for event in agent._original_enhanced_routing(chat_id, query):
                        # Semantic 결과가 있으면 라우팅 이벤트에 추가 정보 포함
                        if (
                            routing_decision
                            and event.get("type") == "ROUTING"
                            and "semantic" not in event.get("description", "").lower()
                        ):

                            # 라우팅 이벤트에 Semantic 정보 추가
                            original_desc = event.get("description", "")
                            event["description"] = (
                                f"Semantic 분석: {routing_decision.complexity.value} (신뢰도: {routing_decision.confidence:.2f}) | {original_desc}"
                            )
                            event["key"] = "semantic_enhanced_routing"

                        yield event

                except Exception as e:
                    logger.error(f"❌ 원본 라우팅 메서드 실행 실패: {e}")
                    # 오류 이벤트 생성
                    error_event = {
                        "type": "ERROR",
                        "content": f"Semantic 라우팅 처리 중 오류: {str(e)}",
                        "description": "라우팅 시스템 오류",
                        "key": "semantic_routing_error",
                        "id": chat_id,
                    }
                    yield error_event

            # 6. 메서드 교체
            agent.process_query_with_enhanced_routing = semantic_enhanced_wrapper
            agent._semantic_routing_enabled = True

            print("✅ Semantic 라우팅 래퍼가 성공적으로 활성화되었습니다!")
            print("📝 테스트는 별도 API (/debug/manual-semantic-test)를 사용해주세요")

            return True

        except Exception as wrapper_error:
            print(f"❌ 래퍼 함수 생성 실패: {wrapper_error}")
            import traceback

            traceback.print_exc()
            return False

    except Exception as e:
        print(f"❌ Semantic 라우팅 활성화 중 예외 발생: {e}")
        import traceback

        traceback.print_exc()
        return False


# 기존 force_enable_semantic_routing 함수에서 문제가 되는 테스트 부분만 제거
def force_enable_semantic_routing_minimal_fix(agent):
    """최소한의 수정으로 문제 해결"""
    try:
        status = check_semantic_analyzer_status(agent)

        if not status["can_perform_vector_similarity"]:
            return False

        if (
            hasattr(agent, "_semantic_routing_enabled")
            and agent._semantic_routing_enabled
        ):
            return True

        # 기존 메서드 백업
        if not hasattr(agent, "_original_enhanced_routing"):
            agent._original_enhanced_routing = agent.process_query_with_enhanced_routing

        # 래퍼 함수 정의
        async def semantic_enhanced_wrapper(chat_id: str, query: str):
            routing_decision = None

            if hasattr(agent, "semantic_analyzer") and agent.semantic_analyzer:
                try:
                    semantic_result = (
                        await agent.semantic_analyzer.analyze_query_semantic(query)
                    )
                    routing_decision = semantic_result
                    agent._last_semantic_result = semantic_result
                except:
                    pass

            async for event in agent._original_enhanced_routing(chat_id, query):
                if routing_decision and event.get("type") == "ROUTING":
                    event["description"] = (
                        f"Semantic: {routing_decision.complexity.value} ({routing_decision.confidence:.2f}) | "
                        + event.get("description", "")
                    )
                yield event

        # 메서드 교체
        agent.process_query_with_enhanced_routing = semantic_enhanced_wrapper
        agent._semantic_routing_enabled = True

        # ❌ 문제가 되는 await 테스트 부분 제거
        print("✅ Semantic 라우팅 활성화 완료 (테스트는 별도 실행)")

        return True

    except Exception as e:
        print(f"❌ 오류: {e}")
        return False


# 라우터 비교 테스트 함수
async def compare_routing_methods(agent, query):
    """기존 방식 vs Semantic 방식 비교"""

    results = {
        "query": query,
        "original_method": {},
        "semantic_method": {},
        "comparison": {},
    }

    try:
        # 1. 기존 방식
        if hasattr(agent, "_original_enhanced_routing"):
            print("🔍 기존 라우팅 방식 테스트...")
            start_time = time.time()

            try:
                original_result = (
                    agent.enhanced_query_analyzer.analyze_query_complexity(query)
                )
                original_time = time.time() - start_time

                results["original_method"] = {
                    "complexity": original_result.complexity.value,
                    "confidence": original_result.confidence,
                    "reasoning": original_result.reasoning,
                    "processing_time": original_time,
                    "method": "pattern_based",
                }
                print(
                    f"   결과: {original_result.complexity.value} ({original_result.confidence:.3f})"
                )

            except Exception as e:
                results["original_method"] = {"error": str(e)}
                print(f"   ❌ 실패: {e}")

        # 2. Semantic 방식
        if hasattr(agent, "semantic_analyzer") and agent.semantic_analyzer:
            print("🧠 Semantic 라우팅 방식 테스트...")
            start_time = time.time()

            try:
                semantic_result = await agent.semantic_analyzer.analyze_query_semantic(
                    query
                )
                semantic_time = time.time() - start_time

                results["semantic_method"] = {
                    "complexity": semantic_result.complexity.value,
                    "confidence": semantic_result.confidence,
                    "reasoning": semantic_result.reasoning,
                    "processing_time": semantic_time,
                    "method": "vector_similarity",
                }
                print(
                    f"   결과: {semantic_result.complexity.value} ({semantic_result.confidence:.3f})"
                )

            except Exception as e:
                results["semantic_method"] = {"error": str(e)}
                print(f"   ❌ 실패: {e}")

        # 3. 비교 분석
        if (
            "error" not in results["original_method"]
            and "error" not in results["semantic_method"]
        ):
            original = results["original_method"]
            semantic = results["semantic_method"]

            results["comparison"] = {
                "complexity_changed": original["complexity"] != semantic["complexity"],
                "confidence_improved": semantic["confidence"] > original["confidence"],
                "confidence_difference": semantic["confidence"]
                - original["confidence"],
                "processing_time_difference": semantic["processing_time"]
                - original["processing_time"],
                "better_method": (
                    "semantic"
                    if semantic["confidence"] > original["confidence"]
                    else "original"
                ),
                "accuracy_assessment": (
                    "improved"
                    if (
                        query.count("검색해서")
                        + query.count("저장해줘")
                        + query.count(".md")
                        >= 2
                        and semantic["complexity"] == "complex"
                        and original["complexity"] != "complex"
                    )
                    else "similar"
                ),
            }

            print("\n📊 비교 결과:")
            print(f"   복잡도 변경: {results['comparison']['complexity_changed']}")
            print(f"   신뢰도 개선: {results['comparison']['confidence_improved']}")
            print(f"   더 나은 방법: {results['comparison']['better_method']}")
            print(f"   정확도 평가: {results['comparison']['accuracy_assessment']}")

    except Exception as e:
        results["comparison_error"] = str(e)
        print(f"❌ 비교 분석 실패: {e}")

    return results


@app.post("/debug/compare-routing-methods", tags=["Debug & Diagnosis"])
async def compare_routing_methods_endpoint(request: Dict[str, str]):
    """라우팅 방식 비교 테스트 엔드포인트"""
    try:
        query = request.get(
            "query",
            "naver.com에서 usb-c 타입 케이블을 검색해서, url과 함께 3개 추천해주고, wiki에서 유박비료에 찾아 내용을 보여주고, 이 모든 내용을 /content/test.md 파일로 마크다운 형식으로 저장해줘.",
        )

        comparison_result = await compare_routing_methods(enhanced_mcp_agent, query)

        return {
            "success": True,
            "comparison": comparison_result,
            "semantic_available": check_semantic_analyzer_status(enhanced_mcp_agent)[
                "can_perform_vector_similarity"
            ],
            "created_at": datetime.now().isoformat() + "Z",
        }

    except Exception as e:
        logger.error(f"라우팅 비교 테스트 오류: {e}")
        return {
            "success": False,
            "error": str(e),
            "created_at": datetime.now().isoformat() + "Z",
        }


@app.get(
    "/mcp/enrichment/status",
    tags=["MCP Recommendation"],
    response_model=EnrichmentStatusResponse,
)
async def get_enrichment_status():
    """LLM 보강 시스템 상태 조회 (이벤트 형식 업데이트 반영)"""
    try:
        status = enhanced_mcp_agent.get_enrichment_status()
        return EnrichmentStatusResponse(**status)
    except Exception as e:
        logger.error(f"보강 상태 조회 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/mcp/enrichment/control", tags=["MCP Recommendation"])
async def control_enrichment_system(request: EnrichmentControlRequest):
    """LLM 보강 시스템 제어 (이벤트 형식 업데이트 반영)"""
    try:
        if not enhanced_mcp_agent.mcp_enricher:
            raise HTTPException(
                status_code=400, detail="LLM 보강 시스템이 초기화되지 않았습니다"
            )

        result = {"created_at": kst_now.isoformat() + "Z"}

        if request.action == "enable":
            enhanced_mcp_agent.enrichment_enabled = True
            result.update(
                {"status": "success", "message": "LLM 보강 시스템이 활성화되었습니다"}
            )

        elif request.action == "disable":
            enhanced_mcp_agent.enrichment_enabled = False
            result.update(
                {
                    "status": "success",
                    "message": "LLM 보강 시스템이 비활성화되었습니다 (기존 시스템으로 폴백)",
                }
            )

        elif request.action == "restart":
            if (
                enhanced_mcp_agent.background_enrichment_task
                and not enhanced_mcp_agent.background_enrichment_task.done()
            ):
                if not request.force:
                    raise HTTPException(
                        status_code=400,
                        detail="보강 작업이 진행 중입니다. force=true로 강제 재시작하거나 완료까지 대기하세요",
                    )
                enhanced_mcp_agent.background_enrichment_task.cancel()

            mcp_servers = enhanced_mcp_agent.mcp_config_loader.load_config()
            if mcp_servers:
                enhanced_mcp_agent.background_enrichment_task = asyncio.create_task(
                    enhanced_mcp_agent._progressive_enrichment_process(mcp_servers)
                )
                result.update(
                    {
                        "status": "success",
                        "message": "LLM 보강 프로세스가 재시작되었습니다",
                    }
                )
            else:
                raise HTTPException(
                    status_code=400, detail="MCP 서버 설정을 찾을 수 없습니다"
                )

        elif request.action == "clear_cache":
            cache_size = len(enhanced_mcp_agent.mcp_enricher.enrichment_cache)
            enhanced_mcp_agent.mcp_enricher.enrichment_cache.clear()
            enhanced_mcp_agent.mcp_enricher.enrichment_status.cache_size = 0
            result.update(
                {
                    "status": "success",
                    "message": f"보강 캐시가 초기화되었습니다 ({cache_size}개 항목 삭제)",
                }
            )

        else:
            raise HTTPException(
                status_code=400, detail=f"지원하지 않는 액션: {request.action}"
            )

        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"보강 시스템 제어 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/debug/enable-semantic-v2", tags=["Debug & Diagnosis"])
async def enable_semantic_routing_v2():
    """Semantic 라우팅 v2 활성화"""
    try:
        success = await force_enable_semantic_routing_v2(enhanced_mcp_agent)

        if success:
            # 테스트 쿼리로 확인
            test_query = "naver.com에서 usb-c 타입 케이블을 검색해서, url과 함께 3개 추천해주고, wiki에서 유박비료에 찾아 내용을 보여주고, 이 모든 내용을 /content/test.md 파일로 마크다운 형식으로 저장해줘."

            # 기존 방식
            original_result = enhanced_mcp_agent.enhanced_query_analyzer._original_analyze_query_complexity(
                test_query
            )

            # 새로운 방식
            new_result = await enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(
                test_query
            )

            return {
                "success": True,
                "message": "Semantic 라우팅 v2가 활성화되었습니다",
                "test_query": test_query,
                "original_result": {
                    "complexity": original_result.complexity.value,
                    "confidence": original_result.confidence,
                    "reasoning": original_result.reasoning,
                },
                "new_result": {
                    "complexity": new_result.complexity.value,
                    "confidence": new_result.confidence,
                    "reasoning": new_result.reasoning,
                },
                "improvement": {
                    "complexity_changed": original_result.complexity
                    != new_result.complexity,
                    "confidence_improved": new_result.confidence
                    > original_result.confidence,
                    "better_classification": new_result.complexity.value
                    == "complex_tool",
                },
                "created_at": kst_now.isoformat() + "Z",
            }
        else:
            return {
                "success": False,
                "message": "Semantic 라우팅 v2 활성화 실패",
                "created_at": kst_now.isoformat() + "Z",
            }

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


# 4. 단순 테스트 API
@app.post("/debug/test-semantic-analysis", tags=["Debug & Diagnosis"])
async def test_semantic_analysis_only(request: Dict[str, str]):
    """Semantic 분석만 테스트"""
    try:
        query = request.get("query", "")

        if (
            hasattr(enhanced_mcp_agent, "semantic_analyzer")
            and enhanced_mcp_agent.semantic_analyzer
        ):
            result = await enhanced_mcp_agent.semantic_analyzer.analyze_query_semantic(
                query
            )

            return {
                "success": True,
                "query": query,
                "result": {
                    "complexity": result.complexity.value,
                    "confidence": result.confidence,
                    "reasoning": result.reasoning,
                    "recommended_approach": result.recommended_approach,
                    "estimated_steps": result.estimated_steps,
                    "requires_planning": result.requires_planning,
                },
                "created_at": kst_now.isoformat() + "Z",
            }
        else:
            return {
                "success": False,
                "error": "Semantic analyzer not available",
                "created_at": kst_now.isoformat() + "Z",
            }

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


@app.get("/mcp/enrichment/comparison", tags=["MCP Recommendation"])
async def compare_enrichment_performance(
    query: str = "naver.com에서 USB 케이블 검색해줘",
):
    """보강 시스템 성능 비교 (이벤트 형식 업데이트 반영)"""
    try:
        import time

        comparison_result = {
            "test_query": query,
            "created_at": kst_now.isoformat() + "Z",
            "original_system": {},
            "enriched_system": {},
            "comparison": {},
        }

        # 기존 시스템 테스트
        if enhanced_mcp_agent.mcp_recommendation_system:
            start_time = time.time()
            try:
                original_result = (
                    await enhanced_mcp_agent.mcp_recommendation_system.recommend_tools(
                        query
                    )
                )
                original_latency = time.time() - start_time

                comparison_result["original_system"] = {
                    "available": True,
                    "latency": original_latency,
                    "confidence_score": (
                        original_result.confidence_score if original_result else 0
                    ),
                    "recommended_servers": (
                        len(original_result.recommended_servers)
                        if original_result
                        else 0
                    ),
                    "recommended_tools": (
                        len(original_result.recommended_tools) if original_result else 0
                    ),
                    "top_3_tools": [
                        {
                            "tool_name": tool.tool_name,
                            "server_name": tool.server_name,
                            "score": tool.score,
                        }
                        for tool in (
                            original_result.recommended_tools[:3]
                            if original_result
                            else []
                        )
                    ],
                }
            except Exception as e:
                comparison_result["original_system"] = {
                    "available": False,
                    "error": str(e),
                }
        else:
            comparison_result["original_system"] = {
                "available": False,
                "reason": "Not initialized",
            }

        # 보강된 시스템 테스트
        if (
            enhanced_mcp_agent.enrichment_enabled
            and enhanced_mcp_agent.enriched_recommendation_system
        ):
            start_time = time.time()
            try:
                enriched_result = await enhanced_mcp_agent.enriched_recommendation_system.recommend_tools(
                    query
                )
                enriched_latency = time.time() - start_time

                comparison_result["enriched_system"] = {
                    "available": True,
                    "latency": enriched_latency,
                    "confidence_score": (
                        enriched_result.confidence_score if enriched_result else 0
                    ),
                    "recommended_servers": (
                        len(enriched_result.recommended_servers)
                        if enriched_result
                        else 0
                    ),
                    "recommended_tools": (
                        len(enriched_result.recommended_tools) if enriched_result else 0
                    ),
                    "top_3_tools": [
                        {
                            "tool_name": tool.tool_name,
                            "server_name": tool.server_name,
                            "score": tool.score,
                        }
                        for tool in (
                            enriched_result.recommended_tools[:3]
                            if enriched_result
                            else []
                        )
                    ],
                }
            except Exception as e:
                comparison_result["enriched_system"] = {
                    "available": False,
                    "error": str(e),
                }
        else:
            comparison_result["enriched_system"] = {
                "available": False,
                "reason": "Not enabled or not initialized",
            }

        # 비교 분석
        if comparison_result["original_system"].get("available") and comparison_result[
            "enriched_system"
        ].get("available"):

            original = comparison_result["original_system"]
            enriched = comparison_result["enriched_system"]

            comparison_result["comparison"] = {
                "latency_difference": enriched["latency"] - original["latency"],
                "latency_improvement": (
                    (
                        (original["latency"] - enriched["latency"])
                        / original["latency"]
                        * 100
                    )
                    if original["latency"] > 0
                    else 0
                ),
                "confidence_improvement": enriched["confidence_score"]
                - original["confidence_score"],
                "confidence_improvement_percentage": (
                    (
                        (enriched["confidence_score"] - original["confidence_score"])
                        / original["confidence_score"]
                        * 100
                    )
                    if original["confidence_score"] > 0
                    else 0
                ),
                "tools_difference": enriched["recommended_tools"]
                - original["recommended_tools"],
                "recommendation": (
                    "enriched"
                    if enriched["confidence_score"] > original["confidence_score"]
                    else "original"
                ),
            }

        return comparison_result

    except Exception as e:
        logger.error(f"성능 비교 오류: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# =================================
# 8. 추가 유틸리티 엔드포인트 (키 순서 업데이트)
# =================================


@app.get("/system/capabilities", tags=["System Status"])
async def get_system_capabilities():
    """시스템 기능 조회 (이벤트 형식 업데이트 반영)"""
    try:
        capabilities = {
            "basic_chat": True,
            "tool_routing": hasattr(enhanced_mcp_agent, "server_router")
            and enhanced_mcp_agent.server_router is not None,
            "mcp_recommendation": hasattr(
                enhanced_mcp_agent, "mcp_recommendation_system"
            )
            and enhanced_mcp_agent.mcp_recommendation_system is not None,
            "enhanced_routing": hasattr(enhanced_mcp_agent, "enhanced_query_analyzer"),
            "hierarchical_planning": (
                hasattr(enhanced_mcp_agent, "hierarchical_planner")
                and hasattr(enhanced_mcp_agent, "hierarchical_executor")
                and enhanced_mcp_agent.hierarchical_planner is not None
            ),
            "memory_system": hasattr(enhanced_mcp_agent, "memory_manager")
            and enhanced_mcp_agent.memory_manager
            and enhanced_mcp_agent.memory_manager.enabled,
            "llm_enrichment": getattr(enhanced_mcp_agent, "enrichment_enabled", False),
            "specialized_endpoints": True,
            "auto_routing": True,
        }

        # 도구 정보
        tools_info = {
            "total_tools": (
                len(enhanced_mcp_agent.tools) if enhanced_mcp_agent.tools else 0
            ),
            "tool_names": (
                [tool.name for tool in enhanced_mcp_agent.tools]
                if enhanced_mcp_agent.tools
                else []
            ),
        }

        # 라우팅 통계 (가능한 경우)
        routing_stats = {}
        if hasattr(enhanced_mcp_agent, "get_routing_stats"):
            routing_stats = enhanced_mcp_agent.get_routing_stats()

        return {
            "success": True,
            "capabilities": capabilities,
            "tools": tools_info,
            "routing_stats": routing_stats,
            "agent_type": type(enhanced_mcp_agent).__name__,
            "endpoints": {
                "general_agent": "/api/v1/general-agent/chat",
                "react_agent": "/api/v1/react-agent/chat",
                "auto_routing": "/chat/enhanced/{chat_id}",
                "legacy": "/chat",
            },
            "event_format": {
                "version": "4.1.0",
                "key_order": [
                    "type",
                    "content",
                    "description",
                    "key",
                    "id",
                    "created_at",
                ],
            },
            "created_at": kst_now.isoformat() + "Z",
        }

    except Exception as e:
        logger.error(f"시스템 기능 조회 오류: {e}")
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


@app.post("/system/analyze-query", tags=["Debug & Diagnosis"])
async def analyze_query_complexity(request: Dict[str, str]):
    """쿼리 복잡도 분석 테스트 (이벤트 형식 업데이트 반영)"""
    try:
        query = request.get("query", "")
        if not query:
            return {
                "success": False,
                "error": "Query is required",
                "created_at": kst_now.isoformat() + "Z",
            }

        result = {"query": query, "created_at": kst_now.isoformat() + "Z"}

        # 기존 분석기
        if hasattr(enhanced_mcp_agent, "query_analyzer"):
            basic_analysis = enhanced_mcp_agent.query_analyzer.analyze_query(query)
            result["basic_analysis"] = {
                "query_type": basic_analysis.query_type,
                "complexity": basic_analysis.complexity,
                "estimated_steps": basic_analysis.estimated_steps,
                "needs_realtime_data": basic_analysis.needs_realtime_data,
                "required_tools": basic_analysis.required_tools,
                "preferred_servers": basic_analysis.preferred_servers,
            }

        # 향상된 분석기
        if hasattr(enhanced_mcp_agent, "enhanced_query_analyzer"):
            enhanced_analysis = (
                enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(
                    query
                )
            )
            result["enhanced_analysis"] = {
                "complexity": enhanced_analysis.complexity.value,
                "confidence": enhanced_analysis.confidence,
                "reasoning": enhanced_analysis.reasoning,
                "recommended_approach": enhanced_analysis.recommended_approach,
                "estimated_steps": enhanced_analysis.estimated_steps,
                "requires_planning": enhanced_analysis.requires_planning,
            }

            # 라우팅 추천
            if enhanced_analysis.complexity.value == "simple_chat":
                result["routing_recommendation"] = {
                    "endpoint": "/api/v1/general-agent/chat",
                    "agent_type": "General Agent",
                    "reason": "단순 대화로 분류되어 도구 사용 없이 처리 권장",
                }
            else:
                result["routing_recommendation"] = {
                    "endpoint": "/api/v1/react-agent/chat",
                    "agent_type": "React Agent",
                    "reason": f"{enhanced_analysis.complexity.value} 복잡도로 분류되어 도구 기반 처리 권장",
                }

        return {"success": True, "result": result}

    except Exception as e:
        logger.error(f"쿼리 분석 오류: {e}")
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


@app.get("/system/routing-stats", tags=["Analytics"])
async def get_routing_stats():
    """라우팅 통계 조회 (이벤트 형식 업데이트 반영)"""
    try:
        if hasattr(enhanced_mcp_agent, "get_routing_stats"):
            stats = enhanced_mcp_agent.get_routing_stats()
            stats["created_at"] = kst_now.isoformat() + "Z"
            return {"success": True, "stats": stats}
        else:
            return {
                "success": False,
                "error": "Routing stats not available",
                "created_at": kst_now.isoformat() + "Z",
            }
    except Exception as e:
        logger.error(f"라우팅 통계 조회 오류: {e}")
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


@app.post("/system/test-hierarchical-planning", tags=["Debug & Diagnosis"])
async def test_hierarchical_planning(request: Dict[str, str]):
    """계층적 계획 테스트 (이벤트 형식 업데이트 반영)"""
    try:
        query = request.get("query", "")
        if not query:
            return {
                "success": False,
                "error": "Query is required",
                "created_at": kst_now.isoformat() + "Z",
            }

        if not hasattr(enhanced_mcp_agent, "enhanced_query_analyzer"):
            return {
                "success": False,
                "error": "Enhanced query analyzer not available",
                "created_at": kst_now.isoformat() + "Z",
            }

        # 쿼리 분석
        routing_decision = (
            enhanced_mcp_agent.enhanced_query_analyzer.analyze_query_complexity(query)
        )

        result = {
            "query": query,
            "routing_decision": {
                "complexity": routing_decision.complexity.value,
                "confidence": routing_decision.confidence,
                "reasoning": routing_decision.reasoning,
                "recommended_approach": routing_decision.recommended_approach,
                "estimated_steps": routing_decision.estimated_steps,
                "requires_planning": routing_decision.requires_planning,
            },
            "created_at": kst_now.isoformat() + "Z",
        }

        # 계층적 계획이 필요한 경우 계획 생성
        if (
            routing_decision.requires_planning
            and hasattr(enhanced_mcp_agent, "hierarchical_planner")
            and enhanced_mcp_agent.hierarchical_planner
        ):

            execution_plan = (
                await enhanced_mcp_agent.hierarchical_planner.create_execution_plan(
                    query, routing_decision
                )
            )

            result["execution_plan"] = {
                "plan_id": execution_plan.plan_id,
                "total_subtasks": execution_plan.total_subtasks,
                "subtasks": [
                    {
                        "id": task.id,
                        "name": task.name,
                        "description": task.description,
                        "required_tools": task.required_tools,
                        "dependencies": task.dependencies,
                        "priority": task.priority,
                        "estimated_duration": task.estimated_duration,
                    }
                    for task in execution_plan.subtasks
                ],
                "execution_order": execution_plan.execution_order,
                "estimated_total_time": execution_plan.estimated_total_time,
            }

        return {"success": True, "result": result}

    except Exception as e:
        logger.error(f"계층적 계획 테스트 오류: {e}")
        return {
            "success": False,
            "error": str(e),
            "created_at": kst_now.isoformat() + "Z",
        }


# =================================
# 9. 서버 시작 및 메인 함수
# =================================


async def main():
    """에이전트 초기화 메인 함수"""
    global enhanced_mcp_agent
    await enhanced_mcp_agent.initialize()
    logger.info("🎉 Enhanced MCP Agent with Specialized Routing System 초기화 완료")


if __name__ == "__main__":
    import uvicorn

    # 에이전트 초기화를 위한 startup 이벤트
    @app.on_event("startup")
    async def startup_event():
        await main()

    # 서버 실행
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info", access_log=True)
