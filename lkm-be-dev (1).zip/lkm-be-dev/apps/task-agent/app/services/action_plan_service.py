from typing import Any, Dict, List

from core.config import get_setting
from core.log.logging import get_logging
from database.crud.crud_expert_agent import CRUDAction
from database.session import get_db

settings = get_setting()
logger = get_logging()


class ActionPlanService:
    """액션 플랜을 관리하는 서비스"""

    def __init__(self):
        self.crud_action = CRUDAction()

    def get_actions_with_tools(
        self, action_plan: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """액션 플랜과 도구를 조인하여 확장된 액션 플랜 리스트 생성

        Args:
            action_plan (List[Dict[str, Any]]): 기존 액션 플랜 리스트

        Returns:
            List[Dict[str, Any]]: 도구 정보가 포함된 확장된 액션 플랜 리스트
        """
        db = next(get_db())

        try:
            # 액션 ID 리스트 추출
            action_ids = [action["id"] for action in action_plan]

            # 액션과 도구 정보 조회
            actions_with_tools = self.crud_action.get_actions_with_tools(db, action_ids)

            return actions_with_tools

        except Exception as e:
            logger.error(f"액션 플랜과 도구 정보 조인 중 오류 발생: {str(e)}")
            raise
        finally:
            db.close()
