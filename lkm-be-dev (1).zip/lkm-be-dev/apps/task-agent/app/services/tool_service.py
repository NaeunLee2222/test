from typing import List, Optional

from sqlalchemy.orm import Session

from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from database.crud.crud_tool import CRUDToolSync
from services.schemas.expert_agent.agent_model import (
    ToolDetail,
    ToolGroupDetail,
    ToolGroupForUpdate,
)
from services.schemas.expert_agent.response import ToolDetailListResponse
from services.schemas.tool.request import (
    MCPToolAddRequest,
    ToolAddRequest,
    ToolDetailUpdateRequest,
    ToolGroupAddRequest,
)

logger = get_logging()


class ToolService:
    def __init__(self):
        self.crud_tool = CRUDToolSync()

    def get_tool_list(
        self,
        db: Session,
        tool_name: Optional[str] = None,
        tool_id: Optional[int] = None,
        is_visible: Optional[bool] = None,
        tool_group_id: Optional[int] = None,
    ) -> ToolDetailListResponse:
        try:
            tools = self.crud_tool.get_tools(
                db, tool_group_id, tool_name, tool_id, is_visible
            )
            return ToolDetailListResponse(tools=tools)
        except Exception as e:
            logger.error(f"ToolService.get_tool_list error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.get_tool_list error",
            )

    def get_tool(
        self,
        db: Session,
        tool_id: int,
    ) -> ToolDetail:
        try:
            tool = self.crud_tool.get_tool_by_id(db, tool_id)
            return tool
        except Exception as e:
            logger.error(f"ToolService.get_tool error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.get_tool error",
            )

    def add_tool(self, db: Session, tool_detail: ToolAddRequest) -> ToolDetail:
        try:
            # 1. 도구 그룹 존재 여부를 먼저 확인
            tool_groups = self.crud_tool.get_tool_group_by_id(
                db, tool_detail.tool_group_id
            )
            if not tool_groups:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"Tool group with id {tool_detail.tool_group_id} does not exist",
                )

            # 2. 필수 필드 검증 - 각 필드별로 상세한 에러 메시지 제공
            missing_fields = []

            if not tool_detail.description:
                missing_fields.append("description")
            if not tool_detail.type:
                missing_fields.append("type")
            if not tool_detail.endpoint:
                missing_fields.append("endpoint")
            if tool_detail.config is None:
                missing_fields.append("config")
            if tool_detail.is_visible is None:
                missing_fields.append("is_visible")

            if missing_fields:
                raise ServiceException(
                    status_code=400,
                    error_code=ErrorCode.UNEXPECTED_ERROR,
                    detail="Tool description, type, config, endpoint, and is_visible are required",
                )

            tool = self.crud_tool.add_tool(
                db,
                tool_detail.name,
                tool_detail.description,
                tool_detail.type,
                tool_detail.config,
                tool_detail.endpoint,
                tool_detail.is_visible,
            )

            # 3. 도구 그룹 관계 등록
            self.crud_tool.register_tool_to_tool_group_by_id(
                db, tool_detail.tool_group_id, tool.id
            )

            return ToolDetail(
                id=tool.id,
                name=tool.name,
                description=tool.description,
                type=tool.type,
                config=tool.config,
                endpoint=tool.endpoint,
                is_visible=tool.is_visible,
                tool_group_id=tool_detail.tool_group_id,
            )
        except ServiceException as se:
            raise se
        except Exception as e:
            logger.error(f"ToolService.add_tool error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.add_tool error",
            )

    async def add_mcp_tool_bulk(
        self, db: Session, mcp_tool_add_request: MCPToolAddRequest
    ) -> List[ToolDetail]:
        tool_group_name = "TEMP_TOOL_GROUP"
        try:
            tools = await self.crud_tool.save_mcp_tool(
                db,
                url=mcp_tool_add_request.url,
                transport=mcp_tool_add_request.transport,
                is_visible=mcp_tool_add_request.is_visible,
            )
            tool_group_name = (
                mcp_tool_add_request.tool_group_name
                if hasattr(mcp_tool_add_request, "tool_group_name")
                else "TEMP_TOOL_GROUP"
            )

            try:
                tool_group = self.crud_tool.get_tool_group_by_name(db, tool_group_name)
            except ValueError as e:
                tool_group = self.crud_tool.create_tool_group(
                    db,
                    name=tool_group_name,
                    description="TEMPORAL TOOL GROUP FOR MCP TOOLS",
                    is_visible=True,
                )
            tool_ids = [tool.id for tool in tools]
            logger.info(f"tool_ids: {tool_ids}")
            logger.info(f"tool_group: {tool_group.id}")

            if tool_ids:
                self.crud_tool.register_mcp_tool_bulk(
                    db, tool_group_id=tool_group.id, tool_ids=tool_ids
                )

            # 4. 결과 반환
            new_tools = []
            for tool in tools:
                new_tools.append(
                    ToolDetail(
                        id=tool.id,
                        name=tool.name,
                        description=tool.description,
                        type=tool.type,
                        config=tool.config,
                        endpoint=tool.endpoint,
                        is_visible=tool.is_visible,
                        tool_group_id=tool_group.id,
                        tool_group_name=tool_group.name,
                        created_at=tool.created_at,
                        updated_at=tool.updated_at,
                    )
                )
            return new_tools
        except Exception as e:
            logger.error(f"ToolService.add_mcp_tool_bulk error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.add_mcp_tool_bulk error",
            )

    def update_tool(
        self, db: Session, tool_id: int, tool_detail_update: ToolDetailUpdateRequest
    ) -> ToolDetail:
        tool_detail = ToolDetail(
            id=tool_id,
            name=tool_detail_update.name,
            description=tool_detail_update.description,
            type=tool_detail_update.type,
            config=tool_detail_update.config,
            endpoint=tool_detail_update.endpoint,
            is_visible=tool_detail_update.is_visible,
        )
        tool = self.crud_tool.update_tool(db, tool_detail)
        return ToolDetail(
            id=tool.id,
            name=tool.name,
            description=tool.description,
            type=tool.type,
            config=tool.config,
            endpoint=tool.endpoint,
            is_visible=tool.is_visible,
        )

    def delete_tool(self, db: Session, tool_id: int) -> bool:
        try:
            self.crud_tool.delete_tool(db, tool_id)
            return True
        except Exception as e:
            logger.error(f"ToolService.delete_tool error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.delete_tool error",
            )

    def add_tool_group(
        self, db: Session, tool_group: ToolGroupAddRequest
    ) -> ToolGroupDetail:
        try:
            new_tool_group = self.crud_tool.create_tool_group(
                db,
                name=tool_group.name,
                description=tool_group.description,
                is_visible=tool_group.is_visible,
            )
            return new_tool_group
        except Exception as e:
            logger.error(f"ToolService.add_tool_group error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.add_tool_group error",
            )

    def get_tool_groups(self, db: Session) -> List[ToolGroupDetail]:
        try:
            tool_groups: List[ToolGroupDetail] = self.crud_tool.get_tool_groups(db)
            return sorted(tool_groups, key=lambda x: x.name)
        except Exception as e:
            logger.error(f"ToolService.get_tool_groups error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.get_tool_groups error",
            )

    def update_tool_group(
        self, db: Session, tool_group_for_update: ToolGroupForUpdate
    ) -> ToolGroupDetail:
        try:
            tool_group_detail = ToolGroupDetail(
                id=tool_group_for_update.id,
                name=tool_group_for_update.name,
                description=tool_group_for_update.description,
                is_visible=tool_group_for_update.is_visible,
            )
            updated_tool_group = self.crud_tool.update_tool_group(db, tool_group_detail)
            return updated_tool_group
        except Exception as e:
            logger.error(f"ToolService.update_tool_group error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.update_tool_group error",
            )

    def update_tool_group_relationship(
        self, db: Session, tool_group_id: int, tool_id: int
    ) -> bool:
        try:
            self.crud_tool.update_tool_group_relationship(db, tool_group_id, tool_id)
            return True
        except Exception as e:
            logger.error(f"ToolService.update_tool_group_relationship error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.update_tool_group_relationship error",
            )

    def get_tools_by_tool_group_id(
        self, db: Session, tool_group_id: int
    ) -> List[ToolDetail]:
        try:
            tools = self.crud_tool.get_tools_by_tool_group_id(db, tool_group_id)
            return tools
        except Exception as e:
            logger.error(f"ToolService.get_tools_by_tool_group_id error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.get_tools_by_tool_group_id error",
            )

    def delete_tool_group(self, db: Session, tool_group_id: int) -> bool:
        try:
            registered_tools = self.crud_tool.get_tools_by_tool_group_id(
                db, tool_group_id
            )
            if registered_tools:
                raise ServiceException(
                    status_code=403,
                    error_code=ErrorCode.ACCESS_DENIED,
                    detail=f"Tool group with id {tool_group_id} has registered tools",
                )
            self.crud_tool.delete_tool_group(db, tool_group_id)
            return True
        except ServiceException as se:
            raise se
        except Exception as e:
            logger.error(f"ToolService.delete_tool_group error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"ToolService.delete_tool_group error",
            )
