from typing import Any, Dict

from core.context import (
    get_chat_message_id,
    get_current_user_info,
    get_transaction_id,
)
from database.models.tool_call import ToolCall


def create_tool_call(
    tool_name: str,
    tool_service_category: str,
    request_params: Dict[str, Any],
    request_body: Dict[str, Any],
) -> ToolCall:
    return ToolCall(
        user_id=get_current_user_info().user_id,
        chat_message_id=get_chat_message_id(),
        tool_name=tool_name,
        tool_service_category=tool_service_category,
        transaction_id=get_transaction_id(),
        request={
            "params": request_params,
            "body": request_body,
        },
    )
