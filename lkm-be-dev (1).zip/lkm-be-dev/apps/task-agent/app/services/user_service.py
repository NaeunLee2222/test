from typing import Tuple, Dict, Any, Optional
import pandas as pd

from core.config import get_setting
from core.utils.parsing import rows_as_text
from core.utils.user_info import get_detailed_user_info
from services.schemas.user.user_info import UserInfo
from core.errors.exceptions import ErrorCode, ServiceException

settings = get_setting()


class UserService:
    def __init__(self):
        self.HISTORY_INFO_CSV = None
        if settings.ENVIRONMENT == "LOCAL":
            self.default_user_id = "10861"
            self.default_detailed_user_info = get_detailed_user_info(
                int(self.default_user_id)
            )
        else:
            self.default_detailed_user_info = None

    async def get_user_details(self, user_info: UserInfo) -> Dict[str, Any]:
        """최적화된 사용자 정보 조회 - 단일 데이터베이스 호출"""
        try:
            if settings.ENVIRONMENT == "LOCAL":
                return self.default_detailed_user_info

            return get_detailed_user_info(
                user_info.user_id, user_info.username, user_info.email
            )
        except Exception as e:
            # 에러 발생 시 기본값 반환
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get user details, {str(e)}",
            )

    async def get_user_meeting_info(
        self, user_id: str, username: str
    ) -> Tuple[str, str]:
        """최적화된 사용자 미팅 정보 조회 - 단일 데이터베이스 호출"""
        try:
            if isinstance(self.HISTORY_INFO_CSV, str):
                # CSV 파일에서 조회
                history = pd.read_csv(self.HISTORY_INFO_CSV)
                history = history.map(str)
                filtered_rows = history[
                    (history["id"] == str(user_id)) & (history["name"] == username)
                ]

                history_columns = [
                    "meetingroom_id",
                    "meetingdate",
                    "meeting_start_time",
                    "meeting_end_time",
                    "floor_id",
                ]
                preferred_columns = [
                    "preferred_meetingroom_id",
                    "preferred_meetingroom_name",
                    "preferred_floor_id",
                ]

                history_info = filtered_rows[history_columns]
                preferred_info = filtered_rows[preferred_columns]

                history_info_string = rows_as_text(history_info)
                preferred_info_string = rows_as_text(preferred_info)
                return history_info_string, preferred_info_string
            else:
                """DB 연결하여 호출"""
                return "", ""
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get user meeting info, {str(e)}",
            )
