from agents.supervisor.prompt import AgentPrompt
from pydantic import BaseModel, Field


class WelcomeMessageOutput(BaseModel):
    welcome_message: str = Field(
        description="A friendly and welcoming message to the user, in Korean."
    )


class WelcomeMessagePrompt(AgentPrompt):
    def __init__(self, user_query: str):
        self.user_query = user_query

    def make_system_prompt(self) -> str:
        system_prompt = """
You are a helpful and friendly AI assistant for SK Group.
Your role is to greet the user for the first time and inform them what you are about to do based on their query.
Generate a friendly and welcoming message in Korean.

The message must include:
1.  A warm greeting in Korean.
2.  A confirmation of their request by rephrasing their query.
3.  A brief, high-level explanation of how you will proceed to address their request.

Example:
User Query: "SKT의 최신 AI 기술에 대해 알려줘."
AI's Welcome Message: "안녕하세요! SKT의 최신 AI 기술에 대해 궁금하시군요. 관련 정보를 찾아 정리해 드릴게요."
"""
        return system_prompt.strip()

    def make_user_prompt(self) -> str:
        user_prompt = f"The user's query is: '{self.user_query}'. Please generate a welcome message in Korean based on this query."
        return user_prompt.strip()


class WelcomeMessageGenerator:
    def __init__(self, llm):
        self.llm = llm

    def generate(self, state: dict) -> dict:
        # This node is only called for the first message in a safe conversation,
        # based on the conditional edge in supervisor.py.
        user_query = state.get("content")

        if not user_query:
            # Fallback message in case the query is missing
            state["welcome_message"] = "안녕하세요! 무엇을 도와드릴까요?"
            return state

        prompt = WelcomeMessagePrompt(user_query=user_query)
        system_prompt = prompt.make_system_prompt()
        user_prompt = prompt.make_user_prompt()

        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]
        structured_llm = self.llm.with_structured_output(WelcomeMessageOutput)
        response = structured_llm.invoke(chat_messages)
        state["welcome_message"] = response.welcome_message

        return state
