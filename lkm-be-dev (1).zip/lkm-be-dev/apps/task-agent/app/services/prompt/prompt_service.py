from typing import Dict, List

from core.config import get_setting
from database.crud.crud_dynamic_prompt import (
    CRUDDynamicPrompt,
    CRUDDynamicPromptCondition,
    CRUDDynamicPromptSnippet,
)
from database.crud.crud_prompt import CRUDPrompt
from database.session import SyncSessionLocal

settings = get_setting()


class PromptService:
    def __init__(self):
        self.crud_prompt = CRUDPrompt()
        self.crud_dynamic_prompt = CRUDDynamicPrompt()
        self.crud_dynamic_prompt_condition = CRUDDynamicPromptCondition()
        self.crud_dynamic_prompt_snippet = CRUDDynamicPromptSnippet()
        self._prompts_cache = None
        self._dynamic_prompts_cache = None
        self._conditions_cache = None
        self._snippets_cache = None

    def get_prompts(self) -> Dict[str, str]:
        """프롬프트 캐시 또는 DB에서 가져오기"""
        if self._prompts_cache is None:
            with SyncSessionLocal() as db:
                prompts = self.crud_prompt.list_all(db)
                self._prompts_cache = {p.prompt_name: p.prompt_text for p in prompts}
        return self._prompts_cache

    def get_dynamic_prompts(self) -> Dict[str, List[Dict]]:
        """동적 프롬프트 캐시 또는 DB에서 가져와서 조합"""
        if self._dynamic_prompts_cache is None:
            with SyncSessionLocal() as db:
                dynamic_prompts = self.crud_dynamic_prompt.list_all(db)
                dynamic_prompt_conditions = self.crud_dynamic_prompt_condition.list_all(
                    db
                )
                dynamic_prompt_snippets = self.crud_dynamic_prompt_snippet.list_all(db)
                self._dynamic_prompts_cache = []
                for p in dynamic_prompts:
                    # 공통 프롬프트나 현재 회사에 맞는 프롬프트만 적용
                    if p.company != "COMMON" and p.company.upper() != settings.COMPANY:
                        continue

                    condition_description = ""
                    for c in dynamic_prompt_conditions:
                        if c.condition == p.condition:
                            condition_description = c.description
                    prompt_snippet = ""
                    for s in dynamic_prompt_snippets:
                        if s.prompt_snippet_title == p.prompt_snippet_title:
                            prompt_snippet = s.prompt_snippet
                    self._dynamic_prompts_cache.append(
                        {
                            "node": p.node,
                            "condition": p.condition,
                            "condition_description": condition_description,
                            "prompt_snippet_title": p.prompt_snippet_title,
                            "prompt_snippet": prompt_snippet,
                        }
                    )
        return self._dynamic_prompts_cache
