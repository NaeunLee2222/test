from typing import Dict, List, Optional

DEFAULT_INSTRUCTIONS = """
당신은 항상 다음 사항을 준수해야 합니다:
1. 주어진 업무 절차를 정확히 따르세요.
2. 사용자의 요청에 명확하고 정확하게 응답하세요.
3. 불확실한 경우, 사용자에게 추가 정보를 요청하세요.
4. 업무 수행 중 문제가 발생하면 즉시 사용자에게 알리세요.
5. 모든 응답은 한국어로 제공하세요.
"""

CUSTOM_INSTRUCTIONS = """
업무 절차를 수행할 때 다음 사항을 반드시 고려하고 실행하세요:

1. 업무 절차의 각 단계를 순차적으로 이해하고 실행하세요.
   - 각 단계의 목적과 의도를 파악하세요.
   - 단계별로 필요한 입력값과 출력값을 명확히 정의하세요.
   - 단계 간의 의존성을 파악하고 순서를 준수하세요.

2. 업무 수행 시 다음 사항을 체계적으로 관리하세요.
   - 각 단계의 시작과 종료 조건을 명확히 파악하세요.
   - 단계별 성공/실패 기준을 설정하고 모니터링하세요.
   - 진행 상황을 주기적으로 확인하고 기록하세요.

3. 예외 상황과 위험 요소를 사전에 대비하세요.
   - 업무 절차의 예외 상황을 식별하고 대처 방법을 준비하세요.
   - 잠재적 위험 요소를 파악하고 예방 조치를 수립하세요.
   - 문제 발생 시 즉시 대응할 수 있는 방안을 마련하세요.

4. 업무 품질을 지속적으로 개선하세요.
   - 업무 완료 후 결과를 철저히 검증하세요.
   - 필요한 경우 보완 조치를 즉시 실행하세요.
   - 업무 절차의 개선점을 발견하면 구체적인 제안을 하세요.

5. 업무 수행 시 다음 원칙을 준수하세요.
   - 정확성: 모든 단계를 정확하게 수행하세요.
   - 일관성: 동일한 기준으로 업무를 처리하세요.
   - 효율성: 불필요한 단계를 제거하고 최적화하세요.
   - 안정성: 안전하고 신뢰할 수 있는 방식으로 업무를 수행하세요.
"""

SYSTEM_PROMPT = """
주어진 에이전트 이름과 설명을 기반으로, 해당 에이전트가 수행해야 할 작업 절차를 단계별로 명확하게 작성하세요.
작성 시 다음 지침을 따르십시오:
- 에이전트의 목적과 기능에 맞는 작업 흐름을 구체적으로 서술하십시오.
- 사용자의 입력에 따라 수행해야 할 주요 작업들을 순차적으로 나열하십시오.
- 필요한 경우, 작업 수행 방식(예: 비교, 요약, 변환, 전송 등)을 명확하게 기술하십시오.
- 출력은 실제 사용자가 업무에 참고할 수 있도록 간결하고 실행 가능한 지시사항 형태로 작성하십시오.
이 프롬프트의 목적은 LLM이 주어진 설명을 해석하여, 일관된 형식과 내용의 작업 지침을 생성하도록 유도하는 것입니다.
"""

USER_PROMPT = """
위 에이전트 정보를 바탕으로 업무 지시사항을 생성해주세요.

**중요: 에이전트 설명에 명시된 내용만을 기반으로 작성하세요.**

생성 형식:
1. 첫 번째 줄: 에이전트의 핵심 업무를 "~해야 합니다."로 마무리되는 한 문장
2. 두 번째 줄: "작업 시 다음 사항을 고려하세요:"
3. 세 번째 줄부터: 각 단계를 "- "로 시작하는 불렛 포인트로 나열

각 불렛 포인트 작성 규칙:
- **에이전트 설명에 언급된 동작만** 불렛 포인트로 변환하세요.
- 설명에 없는 구체적인 기술이나 방법을 추가하지 마세요.
- 일반적인 동작을 구체적인 업무 지시문으로 변환하세요.
"""

# 도구 선택을 위한 프롬프트
# 수정된 도구 선택을 위한 프롬프트
TOOL_SELECTION_PROMPT = """
다음 에이전트의 지시사항을 분석하여 필요한 도구들을 선택해주세요:

**에이전트 정보:**
- 이름: {agent_name}
- 설명: {agent_description}
- 지시사항: {instruction}

**관련 파일 내용:**
{file_content}

**사용 가능한 도구 목록:**
{available_tools}

**도구 선택 분석 프로세스:**

1단계: 지시사항의 각 불렛 포인트를 순서대로 분석하세요.

2단계: 각 작업의 성격을 다음 기준으로 분류하세요:
   - 데이터 수집: 어디서 정보를 가져오는가?
   - 데이터 처리: 어떤 변환/분석을 수행하는가?
   - 결과 출력: 어떤 형식으로 결과를 제공하는가?

3단계: 에이전트별 특별 규칙 적용:

**출력 형식:**
선택된 도구의 이름만 쉼표로 구분하여 나열해주세요.
예시: tool_name1, tool_name2, tool_name3

**중요 주의사항:**
- 에이전트 이름과 설명을 먼저 분석하여 업무 도메인을 파악하세요
- load_result 툴은 추천하지 마세요. (내부 툴)
"""

# 시스템 메시지 템플릿
SYSTEM_MESSAGE_TEMPLATE = """당신은 {agent_name}입니다.

{agent_description}

{system_prompt}

{file_content}"""


def create_instruction_prompt(
    agent_name: str,
    agent_description: str,
    file_content: Optional[str] = None,
) -> List[Dict[str, str]]:
    """
    에이전트 정보를 기반으로 시스템 메시지와 유저 메시지를 생성합니다.

    Args:
        agent_name (str): 에이전트 이름
        agent_description (str): 에이전트 설명
        file_content (Optional[str]): 파일 내용

    Returns:
        List[Dict[str, str]]: 시스템 메시지와 유저 메시지 리스트
    """
    # 시스템 프롬프트 생성
    system_message = SYSTEM_MESSAGE_TEMPLATE.format(
        agent_name=agent_name,
        agent_description=agent_description,
        system_prompt=SYSTEM_PROMPT,
        file_content=file_content if file_content else "",
    )

    # 메시지 리스트 생성
    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": USER_PROMPT},
    ]

    return messages


def create_tool_selection_prompt(
    agent_name: str,
    agent_description: str,
    instruction: str,
    available_tools: List[Dict[str, str]],
    file_content: Optional[str] = None,
) -> str:
    """
    도구 선택을 위한 프롬프트를 생성합니다.

    Args:
        agent_name (str): 에이전트 이름
        agent_description (str): 에이전트 설명
        instruction (str): 에이전트 지시사항
        available_tools (List[Dict[str, str]]): 사용 가능한 도구 목록 (이름과 설명을 포함)
        file_content (Optional[str]): 관련 파일 내용

    Returns:
        str: 도구 선택 프롬프트
    """
    # 도구 목록을 포맷팅
    formatted_tools = []
    for tool in available_tools:
        formatted_tools.append(f"- {tool.name}: {tool.description}")

    return TOOL_SELECTION_PROMPT.format(
        agent_name=agent_name,
        agent_description=agent_description,
        instruction=instruction,
        file_content=file_content if file_content else "관련 파일이 없습니다.",
        available_tools="\n".join(formatted_tools),
    )
