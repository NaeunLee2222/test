SEARCH_QUERY_SYSTEM_PROMPT = """당신은 검색 쿼리 최적화 전문가입니다. 주어진 정보를 분석하여 가장 효과적인 검색 쿼리를 생성합니다."""

SEARCH_QUERY_USER_PROMPT_TEMPLATE = """다음 정보를 바탕으로 문서 검색에 가장 효과적인 검색 쿼리를 생성해주세요:

도구 이름: {tool_name}
도구 설명: {tool_description}
실행할 작업: {action_description}
사용자 원본 질의: {user_query}
도구 파라미터: {tool_parameters}
필수 파라미터: {required_params}

요구사항:
1. 도구 실행에 필요한 핵심 정보를 포함
2. 관련 문서를 찾기 위한 키워드 포함
3. 간결하고 명확한 검색어 구성
4. 사용자의 의도를 정확히 반영

검색 쿼리만 반환해주세요. 설명은 제외하고 쿼리 텍스트만 생성해주세요."""
