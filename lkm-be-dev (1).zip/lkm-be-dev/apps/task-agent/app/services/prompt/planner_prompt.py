from typing import List

from pydantic import BaseModel, Field

FILTER_STEPS_PROMPT_TEMPLATE = """
당신은 사용자의 요청을 매우 정확하게 이해하고, 주어진 전체 업무 단계 목록에서 사용자의 핵심 목표 달성에 필요한 단계만을 논리적으로 선별하고, 그 실행 순서까지 결정하는 AI 전문가입니다.

## 사용자의 요청 (User Query):
{user_query}
(사용자 요청은 다음과 같은 구조로 제공될 수 있습니다: '주요 목표', '배경 정보/제약 조건', '필수 포함/고려 사항', '기대 결과물'. 각 항목을 주의 깊게 분석하십시오.)

## 전체 업무 단계 (Full Step Plan):
```json
{steps_str}
```

## 분석 및 선별 지침:
1.  **사용자 요청의 핵심 의도 파악**: 사용자 쿼리 내 **'주요 목표'** 항목을 최우선으로 분석하여 가장 중요한 목표가 무엇인지 정확히 파악하십시오. '기대 결과물' 항목이 있다면, 목표 달성 여부를 판단하는 데 참고하십시오.
2.  **단계 간 의존성 및 데이터 흐름 고려**: 특정 단계가 다른 필수 단계의 전제 조건이 되거나, 특정 데이터/결과물을 생성하여 후속 단계의 입력으로 사용되는 경우(데이터 흐름), 해당 전제 조건 또는 데이터 생성 단계도 함께 선별해야 합니다. 각 단계의 `actions`를 통해 필요한 입력, 선행 작업, 생성되는 결과물을 면밀히 확인하십시오. **사용자 요청의 '배경 정보/제약 조건' 및 '필수 포함/고려 사항'을 바탕으로 이러한 의존성을 더욱 정밀하게 판단하십시오.**
3.  **단계별 관련성 및 시너지 평가**: 각 업무 단계가 사용자 요청의 **'주요 목표'** 및 '기대 결과물'과 어떻게 관련되어 있는지, 그리고 선별된 다른 주요 단계들과 어떤 시너지 효과를 낼 수 있는지 종합적으로 평가하십시오. 각 단계의 'name'과 'description', 그리고 'actions' 내의 'name'과 'description'을 모두 고려하여 판단해야 합니다. **'필수 포함/고려 사항'에 명시된 내용은 반드시 반영될 수 있도록 관련 단계를 선별해야 합니다.**
4.  **실행 순서 결정**: 선별된 단계들을 어떤 순서로 실행하는 것이 가장 논리적이고 효율적인지 판단하십시오. **단계 간의 명확한 선후 관계와 데이터 흐름을 반드시 고려해야 합니다.** 사용자 요청의 **'배경 정보/제약 조건'에서 파생될 수 있는 순서 제약도 고려하십시오.** 예를 들어, 데이터 생성 단계는 해당 데이터를 사용하는 단계보다 먼저 와야 합니다. **'RFQ 정합성 검토'와 같이 다른 작업들의 결과를 종합적으로 검토하거나 최종 확인하는 성격의 단계는, 관련된 모든 선행 작업들이 완료되고 해당 결과물들이 도출된 후 가장 마지막 또는 그에 준하는 순서로 배치되어야 합니다.** 원래 `order` 순서를 따를 필요는 없으며, 사용자 요청 해결에 최적화된 순서로 재구성할 수 있습니다.
5.  **불필요한 단계 제거**: 사용자의 핵심 의도와 직접적인 관련이 없거나, 명시적으로 요청되지 않은 부가적인 단계는 과감히 제외하십시오.
6.  **최소한의 필수 단계 선택**: 사용자의 목표를 달성하기 위한 최소한의 필수적인 단계들로만 구성된 계획을 만드는 것을 목표로 합니다.
7.  **유효한 단계만 사용**: 제공된 "전체 업무 단계" 목록에 있는 `order` 번호만을 사용해야 하며, 존재하지 않는 단계를 만들어내거나 없는 `order` 번호를 사용해서는 안 됩니다. 동일한 `order` 번호가 여러 번 필요하다고 판단되면, 응답 배열에 해당 `order` 번호를 여러 번 포함할 수 있습니다.

## 최종 선별 결과 제공 형식 (Structured JSON Output):
선별된 각 단계에 대해 `order` 번호와 해당 단계를 선별한 `reason` (간략한 이유, 1-2 문장)을 포함하는 JSON 객체 배열 형태로 반환해주십시오. **배열의 순서는 당신이 결정한 최적의 실행 순서를 반영해야 합니다.** 다른 설명은 포함하지 마십시오.

-   **선별된 단계가 있는 경우의 예시 (LLM이 결정한 실행 순서)**:
    ```json
    [
        {{
            "order": 3, 
            "reason": "사용자 요청 분석 결과, 먼저 3번 단계를 통해 특정 정보를 조회해야 합니다."
        }},
        {{
            "order": 1,
            "reason": "3번 단계의 조회 결과를 바탕으로 1번 단계를 실행하여 데이터를 처리합니다."
        }},
        {{
            "order": 3, 
            "reason": "1번 단계 처리 후, 변경된 조건으로 3번 단계를 다시 실행하여 추가 정보를 확인합니다."
        }},
        {{
            "order": 5,
            "reason": "모든 처리 결과를 종합하여 5번 단계에서 최종 보고서를 생성합니다."
        }}
    ]
    ```
-   **모든 단계가 원래 순서대로 필요한 경우**: 위와 같은 형식으로 모든 단계의 `order`와 `reason`을 포함하여, 원래 `order` 오름차순으로 반환합니다.
-   **필요한 단계가 없거나 요청 처리가 불가능한 경우**: 빈 JSON 배열 `[]`을 반환합니다.

주어진 정보를 바탕으로 신중하게 판단하여, 사용자 요청 해결에 가장 적합한 단계들을 **당신이 생각하는 최적의 실행 순서대로 배열하여** 위의 JSON 형식으로 제시해주십시오.
"""


class SelectedStep(BaseModel):
    order: int = Field(description="선별된 단계의 order 번호")
    reason: str = Field(
        description="해당 단계를 사용자 요청 및 다른 선별된 단계들과 연관지어 선별한 핵심 이유 (간결하게 1-2 문장)"
    )


class FilteredStepsResponse(BaseModel):
    selected_steps: List[SelectedStep] = Field(
        description="선별된 단계 목록. 필요한 단계가 없으면 빈 리스트로 응답합니다."
    )


class AgentPromptGuard(BaseModel):
    is_agent_capable_task: bool = Field(
        description="사용자의 요청이 Agent가 할 수 있는 일인지 판단 (True 또는 False)"
    )
    reason: str = Field(description="판단의 근거와 이유를 설명하는 문장")
    planning_message: str = Field(
        description="사용자에게 자신의 능력 범위 내에서 처리 가능한 요청인지 알려주는 메시지. 그리고 자기가 할 수 있는 역할을 알려주는 메시지"
    )


class AgentCapabilityGenerator:
    def __init__(self, llm):
        self.llm = llm

    def make_agent_capability_prompt(
        self,
        user_query: str,
        agent_name: str,
        agent_description: str,
        markdown_plan: str,
    ) -> List[BaseModel]:
        """
        사용자 요청이 Agent의 능력 범위 내에서 처리 가능한지 판단하는 프롬프트를 생성합니다.

        Args:
            user_query: 사용자의 요청
            agent_name: Agent의 이름
            agent_description: Agent의 설명
            markdown_plan: markdown 형식으로 포맷된 계획

        Returns:
            판단용 메시지 리스트
        """
        from langchain_core.messages import HumanMessage, SystemMessage

        system_prompt = f"""
    당신은 사용자의 요청이 특정 Agent의 능력 범위 내에서 처리 가능한지 판단하는 전문가입니다.

    ## Agent 정보:
    - **이름**: {agent_name}
    - **설명**: {agent_description}

    ## Agent가 수행할 수 있는 업무 계획들:
    {markdown_plan}

    ## 판단 기준:
    1. **직접적 관련성**: 사용자 요청이 Agent의 설명과 직접적으로 관련이 있는가?
    2. **업무 범위**: 제공된 업무 계획들 중에서 사용자 요청을 처리할 수 있는 적절한 단계와 작업들이 존재하는가?
    3. **기술적 실현 가능성**: Agent의 능력과 도구로 사용자의 요청을 실제로 수행할 수 있는가?
    4. **정확성 보장**: Agent가 사용자 요청에 대해 정확하고 신뢰할 수 있는 결과를 제공할 수 있는가?

    ## 응답 형식:
    - **is_agent_capable_task**: true 또는 false로 명확히 답변
    - **reason**: 판단 근거를 구체적이고 간결하게 설명 (2-3 문장)
    - **planning_message**: 사용자에게 전달할 공식적이고 권위있는 한국어 메시지. 계획 수립 시작을 알리는 내용으로 작성

    사용자의 요청을 신중히 분석하고, Agent의 능력과 업무 범위를 고려하여 정확한 판단을 내려주세요.
    """

        user_prompt = f"사용자 요청: '{user_query}'"

        return [
            SystemMessage(content=system_prompt.strip()),
            HumanMessage(content=user_prompt.strip()),
        ]

    def generate(
        self,
        user_query: str,
        agent_name: str,
        agent_description: str,
        markdown_plan: str,
    ) -> AgentPromptGuard:
        if not user_query:
            # Fallback response
            return AgentPromptGuard(
                is_agent_capable_task=True,
                reason="기본 요청 처리 가능",
                planning_message="요청 처리를 위한 계획을 수립하겠습니다.",
            )

        prompt_messages = self.make_agent_capability_prompt(
            user_query=user_query,
            agent_name=agent_name,
            agent_description=agent_description,
            markdown_plan=markdown_plan,
        )

        structured_llm = self.llm.with_structured_output(AgentPromptGuard)
        response = structured_llm.invoke(prompt_messages)
        return response
