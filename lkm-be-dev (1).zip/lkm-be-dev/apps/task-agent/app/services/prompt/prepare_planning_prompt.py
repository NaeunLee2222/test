import json
from typing import TYPE_CHECKING, Any, Dict, List

from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from pydantic import BaseModel, Field

if TYPE_CHECKING:
    pass


class PreparePlanningOutput(BaseModel):
    planning_message: str = Field(
        description="A message to inform the user that the planning phase is starting, in Korean."
    )


def make_prepare_planning_prompt(user_query: str) -> List[BaseMessage]:
    from langchain_core.messages import HumanMessage, SystemMessage

    system_prompt = """
You are an AI assistant for a large enterprise. Your task is to inform the user that you are starting to plan to handle their request.
Generate a formal and authoritative message in Korean. Do not use conversational fillers or honorifics like '네'.

The message should state that you have analyzed the user's query.
- If the query is clear and specific, briefly rephrase the inferred goal before announcing the plan.
- If the query is ambiguous or too complex to summarize confidently, just state that you have analyzed the query and will create a plan.
Finally, announce that you will create a plan to proceed.

Example (Clear Query):
User Query: "SKT의 최신 AI 기술에 대해 알려줘."
AI's Planning Message: "'SKT의 최신 AI 기술'에 대한 답변을 드리기 위해 작업 계획을 수립하여 진행하겠습니다."

Example (Ambiguous Query):
User Query: "그거 관련해서 다시 좀 알아봐줘."
AI's Planning Message: "요청하신 내용에 대한 작업 계획을 수립하여 진행하겠습니다."
"""
    user_prompt = f"The user's query is: '{user_query}'. Please generate a planning start message in Korean based on this query."

    return [
        SystemMessage(content=system_prompt.strip()),
        HumanMessage(content=user_prompt.strip()),
    ]


class FormattedPlanOutput(BaseModel):
    formatted_plan: str = Field(
        description="A user-friendly, markdown-formatted explanation of the work plan, in Korean."
    )


def format_step_plan_as_markdown(step_plan: List[Dict[str, Any]], llm: Any) -> str:
    """
    Uses an LLM to convert the step plan into a user-friendly markdown format.
    """
    system_prompt = """
You are an AI assistant for a large enterprise. Your task is to convert a JSON work plan into a formal, professional, and user-friendly markdown format in Korean.

- Start with a polite sentence thanking the user for their patience and stating that a plan has been created for their request. Infer the request's topic from the plan details.
- Briefly summarize the main steps of the plan in prose.
- Then, present the detailed plan using markdown.
- Use a clear title for the plan, like `**작업 계획**`.
- Use bold headings for major steps (e.g., `**정보 수집**`). Do not use numbers for the steps.
- Use bullet points (`-`) for actions within each step.
- Conclude with a closing sentence.
- The tone should be formal and professional. Do not include raw JSON.

Example Input (JSON):
[
  {
    "name": "정보 수집",
    "description": "사용자 질문에 답변하기 위해 필요한 정보를 수집합니다.",
    "actions": [
      { "name": "웹 검색", "description": "최신 AI 기술에 대해 검색합니다." },
    ]
  },
  {
    "name": "답변 생성",
    "description": "수집된 정보를 바탕으로 답변을 생성합니다.",
    "actions": [
      { "name": "초안 작성", "description": "정보를 종합하여 답변 초안을 작성합니다." },
    ]
  }
]

Example Output (Markdown):
기다려 주셔서 감사합니다. 요청하신 '최신 AI 기술'에 대한 답변을 드리기 위해 작업 계획을 수립했습니다. 먼저 관련 정보를 수집하고, 이를 바탕으로 답변을 생성하는 순서로 진행하겠습니다.

**작업 계획**

**정보 수집**
  - 최신 AI 기술에 대해 웹 검색

**답변 생성**
  - 수집된 정보로 답변 초안 작성

수립된 계획에 따라 작업을 시작하겠습니다.
"""

    plan_json = json.dumps(step_plan, indent=2, ensure_ascii=False)
    user_prompt = f"Please convert the following JSON plan into a formal and polite markdown format, including a prose introduction and a detailed list without step numbers:\n\n{plan_json}"

    messages = [
        SystemMessage(content=system_prompt.strip()),
        HumanMessage(content=user_prompt.strip()),
    ]

    structured_llm = llm.with_structured_output(FormattedPlanOutput)

    try:
        response = structured_llm.invoke(messages)
        return response.formatted_plan
    except Exception:
        # Fallback to simple JSON dump in case of LLM error
        return f"- 작업 계획\n```json\n{plan_json}\n```"


class PreparePlanningGenerator:
    def __init__(self, llm):
        self.llm = llm

    def generate(self, state) -> str:
        user_query = state.get("user_query")

        if not user_query:
            # Fallback message
            return "요청 처리를 위한 계획을 수립하겠습니다."

        prompt_messages = make_prepare_planning_prompt(user_query=user_query)

        structured_llm = self.llm.with_structured_output(PreparePlanningOutput)
        response = structured_llm.invoke(prompt_messages)
        return response.planning_message
