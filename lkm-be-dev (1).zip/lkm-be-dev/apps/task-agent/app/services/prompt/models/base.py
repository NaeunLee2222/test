from abc import ABC, abstractmethod


class BasePrompt(ABC):
    """프롬프트 기본 클래스"""

    @abstractmethod
    def make_system_prompt(self) -> str:
        pass
