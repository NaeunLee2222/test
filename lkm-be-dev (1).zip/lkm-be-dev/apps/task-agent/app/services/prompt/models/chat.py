from dataclasses import dataclass
from typing import Optional

from services.prompt.models.base import BasePrompt


class ChatPrompt(BasePrompt):
    def __init__(self) -> None:
        pass

    def make_system_prompt(self) -> str:
        pass


@dataclass
class UserChatPrompt(ChatPrompt):
    nowtime: str
    name: str
    email: str
    id: str
    office: Optional[str] = ""
    office_id: Optional[str] = ""
    floor: Optional[str] = ""
    floor_id: Optional[str] = ""
    history_info: Optional[str] = ""
    preferred_info: Optional[str] = ""
    calendar_id: Optional[str] = ""

    def make_system_prompt(self) -> str:
        base_info = {
            "현재 날짜 및 시간": self.nowtime,
            "이름": self.name,
            "사번": self.id,
            "이메일": self.email,
        }

        optional_info = {
            "근무 사옥": self.office,
            "근무 사옥 ID": self.office_id,
            "근무 층 이름": self.floor,
            "근무 층 ID": self.floor_id,
            "캘린더 ID": self.calendar_id,
        }

        prompt_lines = ["당신은 사용자의 요청에 대한 답변을 생성하는 챗봇입니다."]

        prompt_lines.extend(f"{key}: {value}" for key, value in base_info.items())

        prompt_lines.extend(
            f"{key}: {value}" for key, value in optional_info.items() if value
        )

        return "\n".join(prompt_lines)
