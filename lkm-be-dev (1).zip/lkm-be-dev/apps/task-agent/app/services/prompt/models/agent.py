from enum import Enum
from typing import Any, Dict, List, Optional

from langchain.tools import Tool
from langchain_core.tools import Tool
from pydantic import BaseModel, Field, create_model
from pydantic.fields import FieldInfo

from services.prompt.models.base import BasePrompt


class AgentPrompt(BasePrompt):
    def __init__(self, agent_config: dict):
        self.agent_config = agent_config

    def make_system_prompt(self) -> str:
        return self.system_prompt.format(agent_name=self.agent_config["agent_name"])


class SelectorPrompt(AgentPrompt):
    class OutputFormat(BaseModel):
        analyze: str = Field(
            description="Analyze the user's query by comparing it with each condition one by one."
        )
        conditions: List[str] = Field(
            description="Output a list of titles from the (title, condition) set that are relevant to the user's query."
        )

    def __init__(
        self,
        agent_config: dict,
        user_query: str,
        history: List[str],
        current_time: str,
        # conditions: List[tuple],
    ) -> None:
        self.user_query = user_query
        self.current_time = current_time
        self.agent_config = agent_config
        self.history = history
        # self.conditions = conditions

    def make_system_prompt(self) -> str:
        return self.system_prompt

    def make_user_prompt(self) -> str:
        # conditions_text = "\n".join(str(item) for item in self.conditions)

        return self.user_prompt.format(
            history=self.history,
            current_time=self.current_time,
            user_query=self.user_query,
            conditions="",
        )
        # conditions=conditions_text,


class PlannerPrompt(AgentPrompt):
    class OutputFormat(BaseModel):
        class PlanItem(BaseModel):
            """
            Components of each plan item
            """

            order: int = Field(description="Execution order (starting from 1)")
            name: str = Field(description="Name of the function to execute")
            goal: str = Field(
                description="The objective to achieve through executing this function. Specify the completion criteria for function execution"
            )
            display_text: str = Field(
                description="Text to display to the user for this step. Express as a single KOREAN sentence in the form '~~ 합니다.'. Add one appropriate emoji at the end of the sentence."
            )

        thinking_steps: List[str] = Field(
            description="Create a list of strings for the thinking process that reviews '# Steps', '# Notes', etc. presented in advance to properly execute the user's query and instructions."
        )

        examine: str = Field(
            description="Review the analysis results from the analyze step to evaluate the appropriateness of function selection and execution order"
        )

        plan: List[PlanItem]

    def __init__(
        self,
        user_basic_info: str,
        agent_config: dict,
        tools: dict,
        user_query: str,
        history: List[str],
        current_time: str,
        system_prompt: str,
        user_prompt: str,
    ) -> None:
        self.user_basic_info = user_basic_info
        self.tools = list(tools.values())
        self.user_query = user_query
        self.current_time = current_time
        self.agent_config = agent_config
        self.history = history
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt

    def make_system_prompt(self) -> str:
        function_text = ""
        for idx, tool in enumerate(self.tools):
            function_text += f"""
            function {idx}.
            "name": "{tool.name}"
            "description": "{tool.description}"
            "parameters": "{self._get_tool_args(tool)}"
            "response": "{self._get_required_top_level_keys(tool)}"

            """
        # 템플릿 문자열에 실제 값을 포맷팅
        return self.system_prompt.format(
            agent_name=self.agent_config["agent_name"],
            function_list_text=function_text,
            current_time=self.current_time,
            user_basic_info=self.user_basic_info,
        )

    def _get_tool_args(self, tool: Tool) -> List[str]:
        # args_schema가 있는지 확인
        if not hasattr(tool, "args_schema"):
            return []

        # args_schema가 None인 경우 처리
        if tool.args_schema is None:
            return []

        # schema의 필드명들을 리스트로 반환
        return list(tool.args_schema.__fields__.keys())

    def _get_required_top_level_keys(self, tool: Tool) -> List[str]:
        # schema가 None이거나 빈 dictionary인 경우
        if not hasattr(tool, "response_schema"):
            return []
        schema = tool.response_schema

        if not schema:
            return []

        # response_format이 없는 경우
        response_format = schema.get("response_format")
        if not response_format:
            return []

        # properties가 없는 경우
        properties = response_format.get("properties")
        if not properties:
            return []

        # data가 없는 경우
        data_schema = properties.get("data")
        if not data_schema:
            return []

        # data type에 따라 properties 가져오기
        data_type = data_schema.get("type")
        if data_type == "array":
            if not data_schema.get("items"):
                return []
            properties = data_schema["items"].get("properties", {})
        elif data_type == "object":
            properties = data_schema.get("properties", {})
        else:
            return []

        # required가 true인 키들만 추출
        required_keys = [
            key
            for key, value in properties.items()
            if isinstance(value, dict) and value.get("required") == True
        ]

        return required_keys

    def make_user_prompt(self) -> str:
        user_prompt = self.user_prompt.format(
            history=self.history, user_query=self.user_query
        )
        return user_prompt


class ReviewerPrompt(AgentPrompt):
    class OutputFormat(BaseModel):
        required_params: List[str] = Field(
            description="List of all required parameters needed for functions included in the plan"
        )
        user_input_params: List[str] = Field(
            description="List of required parameters that can be inferred through conversation with the user"
        )
        default_input_params: List[str] = Field(
            description="List of required parameters that can be filled with default values"
        )
        execution_derived_params: List[str] = Field(
            description="List of required parameters that will be naturally discovered during function execution, rather than being provided by the user"
        )

    def __init__(
        self,
        user_basic_info: str,
        agent_config: dict,
        function_list: List[dict],
        step_plan: List[dict],
        action_plan: List[dict],
        history: List[str],
        system_prompt: str,
        user_prompt: str,
    ):
        self.function_list = function_list
        self.using_function_list = [
            tool
            for tool in function_list
            if tool["name"] in [p["tool_name"] for p in action_plan]
        ]
        self.user_basic_info = user_basic_info
        self.plan = action_plan
        self.history = history
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        self.agent_config = agent_config

    def make_system_prompt(self) -> str:
        # 템플릿 문자열에 실제 값을 포맷팅
        return self.system_prompt.format(
            user_basic_info=self.user_basic_info,
        )

    def make_user_prompt(self) -> str:
        use_function_list = ""
        for order, i in enumerate(self.plan):
            current_order_function = [
                item for item in self.function_list if item["name"] == i["tool_name"]
            ]
            if current_order_function:
                use_function_list += (
                    f"{order} 번째 실행할 함수:\n{str(current_order_function[0])}\n"
                )

        user_prompt = self.user_prompt.format(
            use_function_list=use_function_list, history=self.history
        )

        return user_prompt

    def make_output_format(self) -> BaseModel:
        def create_multiple_dynamic_models(
            configs: List[Dict[str, Dict[str, Any]]],
        ) -> BaseModel:
            models = {}

            for model_name, field_config in configs.items():
                fields = {}

                for field_name, field_spec in field_config.items():
                    if field_spec.get("type") == "enum":
                        enum_class = Enum(
                            f"{model_name}_{field_name}_enum",
                            {v: v for v in field_spec["values"]},
                        )
                        fields[field_name] = (enum_class, FieldInfo())
                    else:
                        fields[field_name] = (field_spec["type"], FieldInfo())

                models[model_name] = create_model(model_name, **fields)

            combined_fields = {
                model_name: (model_class, None)
                for model_name, model_class in models.items()
            }

            return create_model("CombinedModel", **combined_fields)

        response_format = {}
        for i in self.using_function_list:
            function_name = i["name"]

            params_dict = {}
            if "params" in i.keys():
                params = i["params"]
            else:
                params = None
            if params is not None:
                for param in params:
                    # params[param]이 dict인 경우만 required 키를 확인
                    if isinstance(params[param], dict) and "required" in params[param]:
                        if params[param]["required"]:
                            params_dict[param] = {
                                "type": "enum",
                                "values": [
                                    "QUERY_DERIVED",
                                    "EXECUTION_DEPENDENT",
                                    "USER_REQUIRED",
                                    "DEFAULT_VALUE",
                                ],
                            }
            if "body" in i.keys():
                bodys = i["body"]
            else:
                bodys = None
            # bodys = i["body"]
            if bodys is not None:
                for body in bodys:
                    if isinstance(bodys[body], dict) and "required" in bodys[body]:
                        if bodys[body]["required"]:
                            params_dict[body] = {
                                "type": "enum",
                                "values": [
                                    "QUERY_DERIVED",
                                    "EXECUTION_DEPENDENT",
                                    "USER_REQUIRED",
                                    "DEFAULT_VALUE",
                                ],
                            }

            response_format[function_name] = params_dict

        return create_multiple_dynamic_models(response_format)


class ReverseQuestionerOutputFormat(BaseModel):
    needs_clarification: bool = Field(description="사용자에게 질문이 필요한지 여부")
    question: Optional[str] = Field(
        description="질문이 필요한 경우, 사용자에게 선택을 요청하는 질문"
    )
    reasoning: Optional[str] = Field(description="질문이 필요하다고 판단한 이유")


class ReverseQuestionerPrompt:
    def __init__(
        self,
        user_basic_info: List[str],
        agent_config: dict,
        user_query: str,
        history: str,
        plan: List[dict] = None,
        function_response: List[str] = None,
        system_prompt: str = "",
        user_prompt: str = "",
    ):
        self.user_basic_info = user_basic_info
        self.agent_config = agent_config
        self.user_query = user_query
        self.history = history
        self.plan = plan or []
        self.function_response = function_response or []
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        self.OutputFormat = ReverseQuestionerOutputFormat

    def make_system_prompt(self) -> str:
        return self.system_prompt.format(
            user_basic_info="\n".join(self.user_basic_info),
        )

    def make_user_prompt(self) -> str:
        return self.user_prompt.format(
            history=self.history,
            plan=self.plan,
            user_query=self.user_query,
            function_response=self.function_response,
        )


class ExecutorPrompt(AgentPrompt):
    def __init__(
        self,
        user_basic_info: str,
        agent_config: dict,
        plan: List[dict],
        current_step: int,
        function_response: List[dict],
        history: List[str],
        system_prompt: str,
        user_prompt: str,
    ):
        self.user_basic_info = user_basic_info
        self.plan = plan
        self.current_step = current_step
        self.function_response = function_response
        self.history = history
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        self.agent_config = agent_config

    def make_system_prompt(self) -> str:
        # 템플릿 문자열에 실제 값을 포맷팅
        return self.system_prompt.format(
            agent_name=self.agent_config["agent_name"],
            user_basic_info=self.user_basic_info,
        )

    def make_user_prompt(self) -> str:
        plan_str = "\n".join(f"{i + 1}. {step}" for i, step in enumerate(self.plan))
        task = self.plan[self.current_step]
        self.current_step = self.current_step + 1
        user_prompt = self.user_prompt.format(
            plan_str=plan_str,
            current_step=self.current_step,
            task=task,
            function_response=self.function_response,
            history=self.history,
        )

        return user_prompt


class ReporterPrompt(AgentPrompt):
    class OutputFormat(BaseModel):
        is_success: bool = Field(
            description="사용자의 query를 최종적으로 만족했는지를 작성. 성공했으면 true, 실패했으면 false"
        )
        reason: str = Field(description="is_success의 사유 간단하게 작성")
        assistant_prompt: str = Field(
            description="모든 결과를 하나로 합쳐 사용자에게 전달할 말을 작성. 친절하고 자세하게 말해야 함"
        )

        is_canvas_need: bool = Field(
            description="사용자의 요청 결과 html로 나오게 되어 화면에 띄워줄 필요가 있는지 유무"
        )
        files_path: List[str] = Field(
            description="사용자의 툴 결과로 얻게 된 File 경로. 그 중 사용자에게 보여줄 가치가 있는 파일의 경로를 리스트로 작성"
        )
        title: str = Field(description="이 내용의 제목을 작성")

    def __init__(
        self,
        agent_config: dict,
        user_query: str,
        history: List[str],
        plan: List[dict],
        tool_calling_history: List[dict],
        plan_analysis: str,
        system_prompt: str,
        user_prompt: str,
        user_no_plan_prompt: str,
    ):
        self.user_query = user_query
        self.history = history
        self.plan = plan
        self.plan_analysis = plan_analysis
        self.tool_calling_history = tool_calling_history
        self.agent_config = agent_config
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt
        self.user_no_plan_prompt = user_no_plan_prompt

    def make_system_prompt(self) -> str:
        # 템플릿 문자열에 실제 값을 포맷팅
        return self.system_prompt

    def make_user_prompt(self) -> str:
        user_prompt = self.user_prompt.format(
            user_query=self.user_query,
            history=self.history,
            plan=self.plan,
            tool_calling_history=self.tool_calling_history,
        )

        return user_prompt

    def make_user_prompt_no_plan(self) -> str:
        user_prompt = self.user_no_plan_prompt.format(
            user_query=self.user_query,
            history=self.history,
            plan_analysis=self.plan_analysis,
        )

        return user_prompt


class ReplannerPrompt(AgentPrompt):
    class OutputFormat(BaseModel):
        class PlanItem(BaseModel):
            """
            각 plan의 구성 요소들
            """

            order: int = Field(description="실행 순서 (1부터 시작)")
            name: str = Field(description="실행할 function의 이름")
            goal: str = Field(
                description="해당 function 실행을 통해 달성하고자 하는 목표. function 실행 완료 조건을 명시"
            )
            display_text: str = Field(
                description="사용자에게 해당 step을 표시할 안내문구. '~~ 합니다' 형태의 한 문장으로 표현. 문장 마지막에 어울리는 이모지를 한 개 추가."
            )

        analyze: str = Field(
            description="사용자의 query를 종합적으로 분석하여, 사용 가능한 function들과의 연관성 및 호출이 필요한 function들에 대한 분석 내용"
        )
        examine: str = Field(
            description="analyze 단계의 분석 결과를 재검토하여, function의 선택 및 실행 순서의 적절성을 검토한 내용"
        )

        plan: List[PlanItem]

    def __init__(
        self,
        user_basic_info: str,
        agent_config: dict,
        function_list: List[dict],
        user_query: str,
        history: List[str],
        plan: List[dict],
        current_time: str,
        system_prompt: str,
        user_prompt: str,
    ) -> None:
        self.user_basic_info = user_basic_info
        self.function_list = function_list
        self.user_query = user_query
        self.current_time = current_time
        self.agent_config = agent_config
        self.history = history

        self.plan = plan
        self.system_prompt = system_prompt
        self.user_prompt = user_prompt

    def make_system_prompt(self) -> str:
        function_text = ""
        for idx, function in enumerate(self.function_list):
            description = function["description"]
            name = function["name"]

            function_text += f"""
            function {idx}.
            "name": "{name}"
            "description": "{description}"
            """
        # 템플릿 문자열에 실제 값을 포맷팅
        return self.system_prompt.format(
            agent_name=self.agent_config["agent_name"],
            function_list_text=function_text,
            current_time=self.current_time,
            user_basic_info=self.user_basic_info,
        )

    def make_user_prompt(self) -> str:
        user_prompt = self.user_prompt.format(
            plan=self.plan, history=self.history, user_query=self.user_query
        )

        return user_prompt
