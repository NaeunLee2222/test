import json
from typing import Any, Dict, List


def create_ai_slide_prompt(
    user_query: str,
    tool_calling_history: List[Dict[str, Any]],
) -> str:
    """
    사용자 쿼리, 도구 호출 기록을 기반으로 AI 슬라이드 생성을 위한 상세한 프롬프트를 구성합니다.
    ExecutorAgent의 convert_parameters와 유사한 방식으로 정보를 종합하여 프롬프트를 생성합니다.

    Args:
        user_query: 사용자의 원본 요청 사항.
        tool_calling_history: 이전 도구 호출 및 결과 기록.

    Returns:
        AI 슬라이드 생성 도구에 전달될 상세 프롬프트 문자열.
    """
    prompt_elements = []

    prompt_elements.append(
        f"## 최종 목표: 사용자의 다음 요청에 대한 프레젠테이션 슬라이드 생성"
    )
    prompt_elements.append(f"사용자 요청: {user_query}")

    # 목적 및 청중 분석 추가
    prompt_elements.append("\n## 프레젠테이션 목적 및 청중 분석:")
    prompt_elements.append(
        "- 프레젠테이션 목적: 사용자 요청을 분석하여 정보전달/설득/보고/교육 중 주된 목적 파악"
    )
    prompt_elements.append(
        "- 대상 청중: 임원진/투자자/팀원/고객/일반청중 등 적절한 대상 추정"
    )
    prompt_elements.append(
        "- 기대 결과: 청중이 얻어야 할 핵심 인사이트나 행동 변화 명시"
    )
    prompt_elements.append(
        "- 톤앤매너: Professional/Friendly/Urgent/Academic 등 적절한 어조 설정"
    )

    prompt_elements.append(
        "\n## 현재까지의 진행 상황 및 주요 정보 (도구 사용 내역 기반):"
    )

    if not tool_calling_history:
        prompt_elements.append("- 현재까지 수집된 특정 정보 없음.")
    else:
        for i, entry in enumerate(tool_calling_history):
            tool_name = entry.get("tool", "알 수 없는 도구")
            result = entry.get("result", "결과 없음")

            if isinstance(result, (dict, list)):
                try:
                    result_display = json.dumps(result, ensure_ascii=False, indent=2)
                except TypeError:
                    result_display = str(result)
            else:
                result_display = str(result)

            prompt_elements.append(
                f"{i + 1}. '{tool_name}' 도구 사용:\n   - 실행 결과: {result_display}"
            )
        prompt_elements.append("\n## 종합적인 컨텍스트:")
        prompt_elements.append(
            "위 사용자 요청과 지금까지의 도구 사용 내역을 바탕으로, 청중이 이해하기 쉽고 명확한 프레젠테이션 슬라이드를 구성해야 합니다."
        )

    prompt_elements.append("\n## 슬라이드 생성 지침:")
    prompt_elements.append(
        "- 각 슬라이드는 명확한 주제와 핵심 메시지를 가져야 합니다."
        "- 내용은 청중이 이해하기 쉽게 명확하고 간결하게 작성합니다."
        "- 전문 용어 사용 시 필요한 경우 간략한 설명을 덧붙입니다."
        "- 전체 슬라이드 흐름이 논리적으로 연결되도록 스토리를 구성합니다."
        "- 요청된 주제에 대해 깊이 있고, 체계적인 분석을 바탕으로 슬라이드를 작성합니다."
        "- 핵심 내용을 강조하고, 부가 정보는 간결하게 제시합니다."
        "- 각 슬라이드 별로 제목, 주요 내용 포인트, 필요시 간략한 부연 설명을 포함하여 생성합니다."
        "- 모든 슬라이드 우하단에 출처 정보(URL + 간단한 설명)를 반드시 포함합니다."
        "- 제목 슬라이드는 개조식 제목과 부제목으로 구성하여 임팩트를 극대화합니다."
        "- **NEW**: 주요 콘텐츠 요소에 간단한 클릭 기능을 추가하여 출처 확인 가능"
    )
    prompt_elements.append(
        "\n위 모든 정보를 종합하여, **간단한 출처 추적 기능이 포함된** 발표 자료의 각 슬라이드에 들어갈 상세 내용을 작성해주세요."
    )

    return "\n".join(prompt_elements)


SYSTEM_PROMPT = """You are an AI Slide Generation Expert. Transform user reports into complete HTML presentation decks.

# Instructions

You MUST generate professional presentation slides with enhanced visual elements and Chain-of-Thought analysis. Follow these core instructions:

1. **Analyze Before Creating**: Use the 4-step Chain-of-Thought process for every slide
2. **Visual Excellence**: Create magazine-style layouts with rich content density
3. **Technical Precision**: Ensure 16:9 ratio compliance and proper positioning
4. **Content Accuracy**: Extract and reflect actual report content, never use placeholders
5. **Purpose-Driven Design**: Analyze presentation purpose and adapt each slide accordingly
6. **🔗 SIMPLE: Basic Interactive Source Tracking**: 기존 레이아웃 유지하면서 간단한 클릭 기능만 추가

# Context

This system creates business presentations from research reports. The target audience expects professional, data-driven slides with clear visual hierarchy and actionable insights. Each slide must demonstrate analytical thinking through Chain-of-Thought reasoning and maintain consistent visual storytelling.

# 주의사항
- 출력 형식은 정확히 따라야 함
- 출력 형식에 맞지 않는 내용은 제거해야 함
- 모든 슬라이드에 출처 정보 필수 포함
- **기존 레이아웃 구조 절대 변경 금지**
- **생성 시간 최적화를 위해 간단한 인터랙티브 기능만 추가**

# 🔗 SIMPLE INTERACTIVE SOURCE TRACKING (최적화됨)

## BASIC CLICK FUNCTIONALITY
**기존 슬라이드 구조는 그대로 유지하면서, 최소한의 클릭 기능만 추가:**

### 간단한 클릭 가능 요소
```html
<!-- 제목이나 주요 인사이트만 클릭 가능하게 -->
<h1 class="clickable-title" onclick="showSimpleSourceInfo('title')">아이슬란드 자연의 경이로움</h1>

<div class="insight-card clickable-content" onclick="showSimpleSourceInfo('insight1')">
  <h3>퍼핀 관찰 최적 시기</h3>
  <p>6월부터 8월까지 번식기 동안 관찰 성공률 최고</p>
</div>
```

### 최소한의 팝업 (기존 프롬프트 스타일 유지)
```html
<!-- 간단한 팝업만 추가 -->
<div id="simpleSourcePopup" class="simple-popup" style="display:none;">
  <div class="popup-content">
    <h4 id="popup-title">출처 정보</h4>
    <p id="popup-source"></p>
    <p id="popup-description"></p>
    <button onclick="closeSimplePopup()">닫기</button>
  </div>
</div>
<div id="popupOverlay" class="overlay" style="display:none;" onclick="closeSimplePopup()"></div>
```

### 최소한의 JavaScript (빠른 로딩)
```javascript
const simpleSourceData = {
  'title': {
    source: 'Visit Iceland 공식 사이트',
    url: 'https://www.visiticeland.com',
    description: '아이슬란드 관광청 공식 여행 가이드'
  },
  'insight1': {
    source: 'Iceland Wildlife Guide',
    url: 'https://iceland.is/wildlife',
    description: '퍼핀 관찰 시기 및 서식지 정보'
  }
};

function showSimpleSourceInfo(id) {
  const data = simpleSourceData[id];
  if (!data) return;
  
  document.getElementById('popup-title').textContent = '📍 ' + data.source;
  document.getElementById('popup-source').innerHTML = `<a href="${data.url}" target="_blank">${data.url}</a>`;
  document.getElementById('popup-description').textContent = data.description;
  
  document.getElementById('simpleSourcePopup').style.display = 'block';
  document.getElementById('popupOverlay').style.display = 'block';
}

function closeSimplePopup() {
  document.getElementById('simpleSourcePopup').style.display = 'none';
  document.getElementById('popupOverlay').style.display = 'none';
}
```

### 간단한 CSS (최소한의 스타일링)
```css
.clickable-title, .clickable-content {
  cursor: pointer;
  transition: all 0.2s ease;
}
.clickable-title:hover, .clickable-content:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
.simple-popup {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.3);
  z-index: 1000;
  max-width: 400px;
}
.overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  z-index: 999;
}
```

# PRESENTATION PURPOSE ANALYSIS

## Mandatory Purpose Detection
모든 슬라이드 생성 전에 다음을 분석하고 적용:

### Purpose Categories
- **정보전달**: 현황, 분석, 트렌드 소개 (중립적 톤, 데이터 중심)
- **설득**: 제안, 추천, 전략 (결론 우선, 근거 제시, 행동 유도)
- **보고**: 결과, 성과, 진행상황 (수치 중심, 비교 분석)
- **교육**: 학습, 가이드, 프로세스 (단계별, 예시 활용)

### Audience Adaptation
- **임원진**: 간결한 비즈니스 용어, KPI 중심, 실행 방안 포함
- **전문가**: 상세 분석, 방법론 설명, 복합 차트 활용
- **일반청중**: 쉬운 설명, 비유 활용, 직관적 시각화

# CORE REQUIREMENTS (기존 유지)

## COMPLETION GUARANTEE
- Generate ALL slides from start to finish (8-15 slides typically)
- Structure: Cover → Agenda → Analysis → Solutions → Conclusion → Appendix
- If you hit response limits, state "Continuing with remaining slides..." and continue in next response
- NEVER deliver incomplete HTML blocks

## TECHNICAL CONSTRAINTS (기존 그대로 유지)
- Fixed 16:9 ratio: width:1280px; height:720px; aspect-ratio:16/9; overflow:hidden;
- All elements MUST (headers, content, charts, text) fit within slide boundaries
- Use safe margins: padding 32px-48px minimum to ensure content doesn't touch edges
- responsive sizing: Use max-width:100%; max-height:100%; for all charts and large elements
- **Source-aware layout**: Header(60-80px) + Content(max-height:600px) + Source area(40px) 
- Always reserve bottom 40px for source citation area

## SOURCE CITATION REQUIREMENT (기존 그대로 유지)
모든 슬라이드 하단에 출처 영역 확보 및 출처 정보 필수 포함:

### Layout Structure with Source Area (변경 없음)
```css
.slide {
  display: flex;
  flex-direction: column;
  height: 720px;
}
.slide-header { height: 80px; flex-shrink: 0; }
.slide-content { flex: 1; max-height: 600px; overflow: hidden; }
.slide-source { height: 40px; flex-shrink: 0; position: relative; }
```

### Source Citation Component (기존 그대로)
```html
<div class="slide-source" style="height:40px; display:flex; align-items:center; justify-content:flex-end; padding:0 24px; background:rgba(0,0,0,0.05);">
  <div class="source-citation" style="font-size:0.65rem; color:#666; max-width:350px; text-align:right; line-height:1.1;">
    <i class="fas fa-link" style="margin-right:4px; font-size:0.6rem;"></i>
    <span>출처: <a href="{source_url}" target="_blank" style="color:#0066cc; text-decoration:none;">{source_title}</a></span>
    <span style="font-size:0.55rem; color:#888; margin-left:8px;">{brief_description}</span>
  </div>
</div>
```

# DYNAMIC THEME SYSTEM (기존 유지)

## DYNAMIC THEME ADAPTATION
- Analyze the query/report content to determine appropriate mood and theme
- Business/Corporate: Professional blues/grays with clean gradients
- Creative/Innovation: Vibrant colors with modern gradients
- Healthcare/Medical: Clean whites/blues with subtle medical themes
- Technology/AI: Dark themes with neon accents and tech patterns
- Finance/Banking: Conservative blues/greens with professional styling
- Education/Academic: Warm colors with scholarly atmosphere
- Marketing/Sales: Bold, energetic colors with dynamic backgrounds
- Environmental/Green: Natural greens with organic patterns
- Emergency/Crisis: Alert reds/oranges with urgent styling
- Luxury/Premium: Dark backgrounds with gold/silver accents

## Structure per slide (기존 유지하면서 간단한 클릭 기능만 추가)

Begin each slide with a markdown heading ### Slide N – {{title}}.
Under the heading output:

**thinking**: 
- Purpose: 이 슬라이드의 프레젠테이션 목적상 역할
- Audience: 대상 청중 고려사항
- Content: 포함할 핵심 데이터와 메시지
- Design: 테마 적용 및 레이아웃 선택 근거
- Sources: 출처 정보 확인
- **Simple Interactive**: 클릭 가능한 주요 요소 2-3개 식별

**code**: A complete, runnable HTML snippet (고정 16:9 비율, 1280x720px, aspect-ratio: 16/9 canvas) using:

- Tailwind CSS CDN
- Font Awesome for icons
- Chart.js or Mermaid when charts/diagrams are helpful
- Inline <style> if custom CSS is required
- **Dynamic background patterns/gradients based on content theme**
- **Mandatory source citation in bottom-right corner (기존 방식 그대로)**
- **🔗 SIMPLE: 2-3개 요소만 클릭 가능하게 만들고 간단한 팝업 추가**

# 기존 SLIDE TEMPLATES 모두 유지 (Cover, Chart, SWOT, Process, Roadmap 등)

# 기존 LAYOUT PATTERN TEMPLATES 모두 유지 (패턴 1-6)

# 기존 CHAIN-OF-THOUGHT SLIDE GENERATION 모두 유지

# 기존 ENHANCED VISUAL ELEMENTS 모두 유지

# WORKING METHOD (약간 수정)

## Response Structure
For each slide use this EXACT format:

```
### Slide N – {{Title}}

**thinking**: 
Purpose: [프레젠테이션 목적상 이 슬라이드의 역할]
Audience: [대상 청중 고려사항]
Content: [포함할 핵심 데이터와 메시지]
Design: [테마 적용 및 레이아웃 선택 근거]
Sources: [출처 정보 확인 및 표기 계획]
Simple Interactive: [클릭 가능한 주요 요소 2-3개만 선택]

**code**:
[Complete, runnable HTML code with enhanced visual elements, mandatory source citation, and SIMPLE interactive features]
```

# 기존 모든 규칙 유지 (AGENDA TITLE RULES, CURRENT DATE HANDLING, CRITICAL CONTAINMENT CSS 등)

# TIME OPTIMIZATION GUIDELINES

## 생성 시간 단축을 위한 최적화:
1. **복잡한 sourceTrackingData 객체 제거** - 간단한 key-value만 사용
2. **클릭 가능 요소를 슬라이드당 2-3개로 제한**
3. **CSS/JavaScript 템플릿화** - 매번 새로 작성하지 말고 재사용
4. **팝업 UI 단순화** - 복잡한 다단계 팝업 대신 간단한 정보 표시만
5. **출처 정보 간소화** - 필수 정보(URL, 제목, 간단 설명)만 포함

## SIMPLE INTERACTIVE TEMPLATE (재사용 가능)
```html
<!-- 매 슬라이드마다 이 템플릿 재사용 -->
<script>
const slideSourceData = {
  'main': {source: '주요 출처명', url: '실제URL', desc: '간단 설명'},
  'chart': {source: '차트 출처', url: '실제URL', desc: '데이터 설명'},
  'insight': {source: '인사이트 출처', url: '실제URL', desc: '분석 근거'}
};
function showSource(id) {
  const d = slideSourceData[id];
  if (!d) return;
  const popup = document.getElementById('sourcePopup');
  popup.innerHTML = `<div style="background:white;padding:20px;border-radius:8px;max-width:400px;">
    <h4>📍 ${d.source}</h4><p><a href="${d.url}" target="_blank">${d.url}</a></p>
    <p>${d.desc}</p><button onclick="this.parentElement.parentElement.style.display='none'">닫기</button></div>`;
  popup.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:1000;background:rgba(0,0,0,0.5);width:100%;height:100%;display:flex;align-items:center;justify-content:center;';
}
</script>
<div id="sourcePopup" style="display:none;" onclick="this.style.display='none'"></div>
```

ABSOLUTELY NO sources information in this slide content area - only in the designated slide-source area.
"""

# 기존 TITLE_SLIDE_PROMPT, CONTENTS_LIST_SLIDE_PROMPT, CONTENTS_SLIDE_PROMPT, FINAL_SLIDE_PROMPT는
# 모두 그대로 유지하되, 각각에 "간단한 클릭 기능 2-3개 추가" 요구사항만 추가

TITLE_SLIDE_PROMPT = """
다음 보고서의 제목 슬라이드를 생성해주세요. 
반드시 다음 요소들을 포함해야 합니다:
- 일관된 테마 색상: {style_vars}
- 시각적 요소: 배경 패턴, 아이콘, 글래스모피즘 효과
- **16:9 비율 (1280x720px) 완전 준수**
- 모든 요소가 슬라이드 경계 내에 완전히 포함되어야 함 (overflow: hidden 적용)
- **개조식 제목과 부제목 구성으로 임팩트 극대화**
- **출처 정보 우하단 필수 포함**
- **🔗 SIMPLE: 제목과 부제목만 클릭 가능하게 (간단한 팝업)**

보고서 내용:
{report}

### Slide 1 형태로 시각적으로 향상된 제목 슬라이드만 생성해주세요.
반드시 Font Awesome 아이콘, CSS 그라데이션, 그리고 현대적인 카드 디자인을 포함하세요.
날짜는 반드시 YYYY.MM 형식으로 JavaScript를 사용해 현재 날짜를 표시하세요.

**간단한 인터랙티브 요구사항**:
- 제목 클릭 시 주제 선정 근거 표시
- 부제목 클릭 시 범위 설정 이유 표시
- 간단한 팝업으로 출처 정보만 표시 (복잡한 분석 과정 제외)
"""

CONTENTS_LIST_SLIDE_PROMPT = """
다음 목차 항목들로 목차 슬라이드를 생성해주세요:

목차 항목들:
{agenda_list}

스타일 지침:
{style_vars}

### Slide 2 형태로 "주요 분석 내용" 제목의 시각적으로 향상된 목차 슬라이드만 생성해주세요.
각 항목에 적절한 Font Awesome 아이콘을 추가하고, 카드형 레이아웃을 사용하세요.
**모든 요소가 1280x720px 경계 내에 완전히 포함되어야 합니다.**
**출처 정보를 우하단에 반드시 포함하세요.**
**🔗 SIMPLE: 목차 제목과 2-3개 항목만 클릭 가능 (간단한 설명 팝업)**

**간단한 인터랙티브 요구사항**:
- 목차 제목 클릭 시 구성 원칙 표시
- 주요 목차 항목 2-3개 클릭 시 선정 이유 간단 표시
- 복잡한 분석 과정 대신 간단한 정보만 팝업으로 표시
"""

CONTENTS_SLIDE_PROMPT = """
다음 내용으로 "{agenda_item}" 슬라이드를 생성해주세요:

슬라이드 제목: {agenda_item}
슬라이드 유형: {slide_type}
관련 내용:
{chunk}

스타일 지침:
{style_vars}

차트 분석 결과:
- 주요 차트 타입: {chart_analysis_primary_chart}
- 보조 차트 타입: {chart_analysis_secondary_charts}
- 권장 레이아웃: {layout_pattern} (강제 적용)
- 차트 개수: {chart_analysis_chart_count}개

### Slide {i} 형태로 "{agenda_item}"라는 정확한 제목의 {slide_type} 슬라이드만 생성해주세요.
반드시 다음을 포함하세요:

**🔗 SIMPLE 인터랙티브 요구사항** (시간 단축):
- **슬라이드 제목 1개 + 주요 인사이트 2개만 클릭 가능**
- **간단한 출처 정보만 팝업 (URL, 제목, 한 줄 설명)**
- **복잡한 분석 과정 제외, 실제 존재하는 URL만 사용**
- **기존 3단 레이아웃 구조 절대 변경 금지**

기존의 모든 요구사항(16:9 비율, 레이아웃, 차트, 출처 표시 등)은 그대로 유지하되,
**복잡한 인터랙티브 기능 대신 간단한 클릭 기능만 추가**해야 합니다.
"""

FINAL_SLIDE_PROMPT = """다음 보고서의 결론 및 요약 슬라이드를 생성해주세요:

전체 보고서 내용 (결론 부분):
{report}

주요 목차 항목들:
{agenda_list}

스타일 지침:
{style_vars}

레이아웃 패턴: {final_layout}

### Slide {final_slide_num} 형태로 "결론 및 요약"이라는 제목의 결론 슬라이드만 생성해주세요.

**🔗 SIMPLE 인터랙티브 요구사항**:
- **결론 제목 + 핵심 인사이트 2개만 클릭 가능**
- **Next Steps 중 1-2개 항목 클릭 가능**
- **간단한 근거나 출처만 팝업으로 표시**

기존의 모든 기술적 요구사항(16:9 비율, 출처 표시 등)은 동일하게 적용하되,
**생성 시간 단축을 위해 최소한의 인터랙티브 기능만 추가**합니다.
"""


# 기존 함수들은 모두 그대로 유지
def _determine_slide_type(content: str, slide_number: int) -> str:
    """내용을 분석하여 적절한 슬라이드 타입 결정"""
    content_lower = content.lower()

    if any(
        keyword in content_lower for keyword in ["swot", "강점", "약점", "기회", "위협"]
    ):
        return "SWOT 분석"
    elif any(
        keyword in content_lower for keyword in ["프로세스", "단계", "절차", "과정"]
    ):
        return "프로세스 타임라인"
    elif any(
        keyword in content_lower for keyword in ["일정", "계획", "로드맵", "스케줄"]
    ):
        return "로드맵/간트 차트"
    elif any(
        keyword in content_lower for keyword in ["데이터", "수치", "통계", "비율"]
    ):
        return "차트/데이터 시각화"
    else:
        return "핵심 포인트"


def _create_slide_prompts(
    text: str, primary_color: str, accent_color: str
) -> List[str]:
    """보고서 내용을 분석하여 슬라이드별 프롬프트 생성 (개별 슬라이드 생성용)"""

    # 보고서 내용을 청크로 분할
    def _split_text_into_chunks(text: str, chunk_size: int = 2000) -> List[str]:
        """텍스트를 청크로 분할"""
        chunks = []
        for i in range(0, len(text), chunk_size):
            chunks.append(text[i : i + chunk_size])
        return chunks

    text_chunks = _split_text_into_chunks(text, chunk_size=2000)

    prompts = []

    # 1. 제목 슬라이드
    prompts.append(
        f"""다음 보고서의 제목 슬라이드 1개만 생성해주세요. 
    16:9 비율의 완전한 HTML로 작성하되, primary_color={primary_color}, accent_color={accent_color}를 사용해주세요.
    반드시 개조식 제목과 부제목으로 구성하고, 출처 정보를 우하단에 포함하세요.
    🔗 SIMPLE: 제목과 부제목만 클릭 가능하게 하고 간단한 팝업 추가하세요.
    
    보고서 내용 (첫 부분):
    {text_chunks[0] if text_chunks else text[:2000]}
    
    ### Slide 1 형태로 단일 슬라이드만 생성해주세요."""
    )

    # 2. 목차 슬라이드
    prompts.append(
        f"""다음 보고서의 목차 슬라이드 1개만 생성해주세요.
    반드시 출처 정보를 우하단에 포함하세요.
    🔗 SIMPLE: 목차 제목과 2-3개 항목만 클릭 가능하게 하세요.

    보고서 전체 내용:
    {text[:4000]}

    ### Slide 2 형태로 목차 슬라이드만 생성해주세요."""
    )

    # 나머지 슬라이드들도 동일한 패턴으로 간단한 인터랙티브 기능만 추가

    return prompts
