from typing import Dict, List

from core.config import get_setting
from core.log.logging import get_logging
from database.crud.crud_expert_agent import CRUDExpertAgent, CRUDStep
from database.session import get_db

settings = get_setting()
logger = get_logging()


class StepPlanService:
    """스텝 플랜을 관리하는 서비스"""

    def __init__(self):
        self.CRUDExpertAgent = CRUDExpertAgent()
        self.CURDStep = CRUDStep()

    def get_agent_info(self, agent_id: int) -> Dict[str, any]:
        """
        Expert Agent의 ID로 해당 에이전트의 정보를 가져옵니다.
        """
        db = next(get_db())
        try:
            agent_info = self.CRUDExpertAgent.get_agent_info(db, agent_id)
            if not agent_info:
                logger.error(f"No agent found with id {agent_id}")
                raise ValueError(f"No agent found with id {agent_id}")
            return agent_info
        finally:
            db.close()

    def get_agent_steps(
        self, agent_info: Dict[str, any]
    ) -> List[Dict[str, any]] | None:
        """
        Expert Agent의 ID로 해당 에이전트의 스텝들을 가져옵니다.

        Args:
            agent_id: Expert Agent의 ID

        Returns:
            스텝 플랜 또는 None
        """
        db = next(get_db())

        try:
            # Expert Agent 정보 가져오기
            if not agent_info:
                logger.info(f"No agent found with id {agent_info.id}")
                return None

            # Steps 가져오기
            steps = self.CURDStep.get_steps_with_join(db, agent_info.id)
            if not steps:
                logger.info(f"No steps found for agent {agent_info.id}")
                return None

            return steps

        except Exception as e:
            logger.error(f"Error getting agent steps: {str(e)}")
            return None
        finally:
            db.close()
