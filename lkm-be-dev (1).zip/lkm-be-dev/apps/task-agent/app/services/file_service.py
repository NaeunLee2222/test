import io

import docx
import openpyxl
from fastapi import UploadFile

from core.config import get_setting
from core.log.logging import get_logging

settings = get_setting()
logger = get_logging()


class FileService:
    """File 업로드 및 관리 서비스"""

    def __init__(self):
        self._document_type = {
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
                "docx",
                self._handle_docx,
                "pip install python-docx",
            ],
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
                "xlsx",
                self._handle_xlsx,
                "pip install openpyxl",
            ],
        }

    @staticmethod
    def _handle_docx(file_bytes: bytes):
        doc_stream = io.BytesIO(file_bytes)
        document = docx.Document(doc_stream)
        file_content = "\\n".join([paragraph.text for paragraph in document.paragraphs])
        return file_content

    @staticmethod
    def _handle_xlsx(file_bytes: bytes):
        excel_stream = io.BytesIO(file_bytes)
        workbook = openpyxl.load_workbook(excel_stream)
        sheet_texts = []
        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            rows_text = []
            for row in sheet.iter_rows():
                cell_texts = [
                    str(cell.value) if cell.value is not None else "" for cell in row
                ]
                rows_text.append(" ".join(cell_texts))
            sheet_texts.append("\n".join(rows_text))
        file_content = "\n--- 다음 시트 ---\n".join(sheet_texts)
        return file_content

    async def validate_file(self, file: UploadFile):
        if file.content_type not in settings.ALLOWED_FILE_TYPES:
            return {
                "status_code": 400,
                "detail": f"허용되지 않는 파일 타입입니다. 허용된 타입: {settings.ALLOWED_FILE_TYPES}\n현재 타입: {file.content_type}",
            }
        contents = await file.read()
        file_size = len(contents)
        if file_size > settings.MAX_UPLOAD_SIZE:
            return {
                "status_code": 400,
                "detail": f"파일 크기가 최대 허용 크기를 초과합니다. ({file_size} bytes / {settings.MAX_UPLOAD_SIZE} bytes)",
            }
        return False

    async def read_document(self, file: UploadFile):
        file_content = None
        file_bytes = await file.read()

        if file.content_type in self._document_type:
            document_type = self._document_type[file.content_type][0]
            try:
                file_content = self._document_type[file.content_type][1](file_bytes)
            except ImportError:
                logger.error(
                    f"파일 '{file.filename}' (MIME: {file.content_type})을(를) 처리하려면 '{self._document_type[file.content_type][2]}'을(를) 실행하세요."
                )
                return {
                    "status_code": 500,
                    "detail": f"서버에 .{document_type} 처리 기능이 설정되지 않았습니다. 관리자에게 문의하세요.",
                }
            except Exception as e_docx:
                logger.error(
                    f".{document_type} 파일 '{file.filename}' 처리 중 오류: {str(e_docx)}"
                )
                return {
                    "status_code": 400,
                    "detail": f".{document_type} 파일 ('{file.filename}')을 처리할 수 없습니다. 파일이 손상되었거나 지원되지 않는 형식일 수 있습니다.",
                }

        # 기타 텍스트 기반 파일 처리
        else:
            # 파일 확장자 확인
            file_extension = ""
            if file.filename and "." in file.filename:
                file_extension = file.filename.lower().split(".")[-1]

            # docx 파일인 경우 직접 처리
            if file_extension in ["docx", "doc"]:
                try:
                    doc_stream = io.BytesIO(file_bytes)
                    document = docx.Document(doc_stream)
                    file_content = "\n".join([p.text for p in document.paragraphs])
                except ImportError:
                    logger.error(
                        f"파일 '{file.filename}' (MIME: {file.content_type})을(를) 처리하려면 'pip install python-docx'를 실행하세요."
                    )
                    return {
                        "status_code": 500,
                        "detail": f"서버에 .docx 처리 기능이 설정되지 않았습니다. 관리자에게 문의하세요.",
                    }
                except Exception as e:
                    logger.error(f".docx 파일 '{file.filename}' 처리 중 오류: {str(e)}")
                    return {
                        "status_code": 400,
                        "detail": f".docx 파일 ('{file.filename}')을 처리할 수 없습니다. 파일이 손상되었거나 지원되지 않는 형식일 수 있습니다.",
                    }
            # 기타 텍스트 파일 처리
            else:
                possible_encodings = ["utf-8", "cp949", "euc-kr"]
                decoded = False
                for encoding in possible_encodings:
                    try:
                        file_content = file_bytes.decode(encoding)
                        logger.info(
                            f"파일 '{file.filename}' (MIME: {file.content_type})을(를) {encoding}으로 디코딩 성공."
                        )
                        decoded = True
                        break
                    except UnicodeDecodeError:
                        logger.warning(
                            f"파일 '{file.filename}' (MIME: {file.content_type})을(를) {encoding}으로 디코딩 실패, 다음 인코딩 시도."
                        )

                if not decoded:
                    logger.error(
                        f"파일 '{file.filename}' (MIME: {file.content_type})의 모든 텍스트 인코딩 시도 실패."
                    )
                    return {
                        "status_code": 400,
                        "detail": f"파일 ('{file.filename}', MIME: {file.content_type})의 인코딩을 확인할 수 없습니다. .docx 파일이 아니며, 지원되는 텍스트 인코딩(UTF-8, CP949, EUC-KR)으로도 읽을 수 없습니다.",
                    }
        return file_content
