from typing import List, Optional

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from database.crud.crud_ai_chat import CRUDAIChat
from database.crud.crud_expert_agent import (
    CRUDAction,
    CRUDActionToolRelationship,
    CRUDChatStarter,
    CRUDExpertAgent,
    CRUDGeneralAgentInstructionTool,
    CRUDProcedureDocument,
    CRUDStep,
    CRUDTool,
)
from database.crud.crud_expert_agent_history import CRUDExpertAgentHistory
from database.models.expert_agent.expert_agent import (
    Action,
    ExpertAgent,
    GeneralAgentInstruction,
    GeneralAgentInstructionTool,
    ProcedureDocument,
    Step,
    Tool,
)
from services.schemas.expert_agent.agent_model import (
    ActionForUpdate,
    ActionWithTools,
    ExpertAgentDetail,
    ExpertAgentSchema,
    StepWithActions,
    ToolSchema,
    UpdateAgentPayload,
)
from services.schemas.expert_agent.response import ExpertAgentDetail

logger = get_logging()


class ExpertAgentService:
    def __init__(self):
        self.crud_expert_agent = CRUDExpertAgent()
        self.crud_step = CRUDStep()
        self.crud_action = CRUDAction()
        self.crud_tool = CRUDTool()
        self.crud_action_tool_relationship = CRUDActionToolRelationship()
        self.crud_general_instruction_tool = CRUDGeneralAgentInstructionTool()
        self.crud_procedure_document = CRUDProcedureDocument()
        self.crud_chat_starter = CRUDChatStarter()
        self.crud_ai_chat = CRUDAIChat()
        self.crud_expert_agent_history = CRUDExpertAgentHistory()

    async def get_agent_detail(
        self, db: AsyncSession, expert_agent_id: int
    ) -> Optional[ExpertAgentDetail]:
        """
        Agent의 Step, Action, Tool 까지의 모든 구조 상세정보를 가져옵니다.
        """
        try:
            # 1. ID로 Agent 가져오기
            agent = await self.crud_expert_agent.get_agent_by_id(db, expert_agent_id)
            if not agent:
                return None

            # 2. 모든 관련 데이터를 한 번에 조회
            steps = await self.crud_expert_agent.get_steps_by_agent_id(
                db, expert_agent_id
            )
            step_ids = [step.id for step in steps]

            # 3. 모든 Actions 한 번에 조회
            actions = await self.crud_expert_agent.get_actions_by_step_ids(db, step_ids)

            # 4. Step ID별로 Action 그룹핑
            actions_by_step = {}
            action_ids = []
            for action in actions:
                if action.step_id not in actions_by_step:
                    actions_by_step[action.step_id] = []
                actions_by_step[action.step_id].append(action)
                action_ids.append(action.id)

            # 5. 모든 Tool 관계 한 번에 조회
            if action_ids:
                tool_relationships = await self.crud_action_tool_relationship.get_action_tool_relationships_by_action_ids(
                    db, action_ids
                )

                # Action ID별로 Tool ID 그룹핑
                tools_by_action = {}
                all_tool_ids = set()
                for rel in tool_relationships:
                    if rel.action_id not in tools_by_action:
                        tools_by_action[rel.action_id] = []
                    tools_by_action[rel.action_id].append(rel.tool_id)
                    all_tool_ids.add(rel.tool_id)

                # 6. 모든 Tool 한 번에 조회
                if all_tool_ids:
                    tools = await self.crud_tool.get_tools_by_ids(
                        db, list(all_tool_ids)
                    )
                    # Tool ID별로 Tool 객체 매핑
                    tools_by_id = {tool.id: tool for tool in tools}
                else:
                    tools_by_id = {}
            else:
                tools_by_action = {}
                tools_by_id = {}
            # 7. 데이터 조립
            steps_with_actions = []
            for step in steps:
                step_actions = actions_by_step.get(step.id, [])

                actions_with_tools = []
                for action in step_actions:
                    # 해당 Action의 Tool들 가져오기
                    action_tool_ids = tools_by_action.get(action.id, [])
                    tool_infos = [
                        ToolSchema(
                            id=tools_by_id[tool_id].id,
                            name=tools_by_id[tool_id].name,
                            description=tools_by_id[tool_id].description,
                            type=tools_by_id[tool_id].type,
                            icon_path=tools_by_id[tool_id].icon_path,
                            config=tools_by_id[tool_id].config,
                            created_at=tools_by_id[tool_id].created_at,
                            updated_at=tools_by_id[tool_id].updated_at,
                            tool_group_id=tools_by_id[tool_id].tool_group_id,
                            tool_group_name=tools_by_id[tool_id].tool_group_name,
                        )
                        for tool_id in action_tool_ids
                        if tool_id in tools_by_id
                    ]

                    action_with_tools = ActionWithTools(
                        id=action.id,
                        step_id=action.step_id,
                        name=action.name,
                        description=action.description,
                        order=action.order,
                        tools=tool_infos,
                    )
                    actions_with_tools.append(action_with_tools)
                step_with_actions = StepWithActions(
                    id=step.id,
                    expert_agent_id=step.expert_agent_id,
                    name=step.name,
                    description=step.description,
                    order=step.order,
                    created_at=step.created_at,
                    updated_at=step.updated_at,
                    actions=actions_with_tools,
                )
                steps_with_actions.append(step_with_actions)
            await self.crud_expert_agent.use_count_up(db, agent_id=agent.id)
            # 에이전트 상세 스키마 생성
            agent_detail = ExpertAgentDetail(
                id=agent.id,
                name=agent.name,
                description=agent.description,
                category=agent.category,
                usage_scope=agent.usage_scope,
                org_id=agent.org_id,
                team_id=agent.team_id,
                use_count=agent.use_count,
                review_status=agent.review_status,
                reject_description=agent.reject_description,
                agent_type=agent.agent_type,
                created_user_id=agent.created_user_id,
                created_at=agent.created_at,
                updated_at=agent.updated_at,
                steps=steps_with_actions,
            )
            return agent_detail

        except Exception as e:
            logger.error(f"Error getting agent detail: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get agent detail: {str(e)}",
            )

    async def get_agent_simple_detail(
        self, db: AsyncSession, expert_agent_id: int
    ) -> Optional[ExpertAgentSchema]:
        """
        Agent의 기본 정보만 가져옵니다. (Step, Action, Tool 정보 제외)
        """
        try:
            # ID로 Agent 기본 정보만 가져오기
            agent = await self.crud_expert_agent.get_agent_by_id(db, expert_agent_id)
            if not agent:
                return None

            # 에이전트 기본 스키마 생성
            agent_schema = ExpertAgentSchema(
                id=agent.id,
                name=agent.name,
                description=agent.description,
                category=agent.category,
                usage_scope=agent.usage_scope,
                org_id=agent.org_id,
                team_id=agent.team_id,
                use_count=agent.use_count,
                review_status=agent.review_status,
                reject_description=agent.reject_description,
                agent_type=agent.agent_type,
                created_user_id=agent.created_user_id,
                created_at=agent.created_at,
                updated_at=agent.updated_at,
            )
            return agent_schema

        except Exception as e:
            logger.error(f"Error getting agent simple detail: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get agent simple detail: {str(e)}",
            )

    async def create_pro_agent(
        self, db: AsyncSession, agent_detail: ExpertAgentDetail
    ) -> ExpertAgentDetail:
        """
        ExpertAgentDetail 정보를 받아 관련된 모든 데이터(Agent, Step, Action, Tool)를 생성합니다.
        일반 agent의 경우 step과 action을 생성하지 않습니다.
        """
        try:
            # 1. Agent 생성
            agent_data = {
                "name": agent_detail.name,
                "description": agent_detail.description,
                "category": agent_detail.category,
                "usage_scope": agent_detail.usage_scope,
                "org_id": agent_detail.org_id,
                "team_id": agent_detail.team_id,
                "created_user_id": agent_detail.created_user_id,
                "use_count": agent_detail.use_count,
                "review_status": agent_detail.review_status,
                "agent_type": agent_detail.agent_type,
            }
            new_agent: ExpertAgent = await self.crud_expert_agent.create(
                db, obj_in=agent_data
            )

            # 2. Pro Agent인 경우에만 Step, Action, Tool 생성
            steps_data = []
            actions_data = []
            tools_data = []
            step_action_mapping = []  # step과 action 간의 관계 매핑
            action_tool_mapping = []  # action과 tool 간의 관계 매핑

            for step_idx, step_data in enumerate(agent_detail.steps):
                step_obj = {
                    "id": step_data.id,
                    "expert_agent_id": new_agent.id,
                    "name": step_data.name,
                    "description": step_data.description,
                    "order": step_data.order,
                }
                steps_data.append(step_obj)

                for action_idx, action_data in enumerate(step_data.actions):
                    action_obj = {
                        "name": action_data.name,
                        "description": action_data.description,
                        "order": action_data.order,
                    }
                    actions_data.append(action_obj)
                    step_action_mapping.append(
                        {
                            "step_idx": step_idx,
                            "action_idx": len(actions_data)
                            - 1,  # actions_data에서의 실제 인덱스
                        }
                    )

                    for tool_data in action_data.tools:
                        tool_obj = {
                            "name": tool_data.name,
                            "description": tool_data.description,
                            "type": tool_data.type,
                            "icon_path": tool_data.icon_path,
                            "config": tool_data.config,
                        }
                        tools_data.append(tool_obj)
                        action_tool_mapping.append(
                            {
                                "action_idx": len(actions_data) - 1,
                                "tool_name": tool_data.name,
                            }
                        )
            logger.info(f"steps_data: {steps_data}")
            logger.info(f"actions_data: {actions_data}")
            logger.info(f"tools_data: {tools_data}")
            logger.info(f"step_action_mapping: {step_action_mapping}")
            logger.info(f"action_tool_mapping: {action_tool_mapping}")

            created_steps = []
            if steps_data:
                created_steps = await self.crud_step.acreate_all(db, obj_in=steps_data)
            created_actions = []
            if actions_data:
                for sam in step_action_mapping:
                    step_idx = sam["step_idx"]
                    action_idx = sam["action_idx"]
                    actions_data[action_idx]["step_id"] = created_steps[step_idx].id
                created_actions = await self.crud_action.acreate_all(
                    db, obj_in=actions_data
                )  # 한번에 생성
            logger.info(f"created_actions_id: {created_actions[0].id}")
            created_tools_map = {}
            if tools_data:
                tool_names = list(set(tool["name"] for tool in tools_data))
                existing_tools_result = await self.crud_tool.get_tools_by_names(
                    db, tool_names
                )
                existing_tools = {tool.name: tool for tool in existing_tools_result}
                logger.info(f"existing_tools: {existing_tools}")

                new_tools_data = []  # 새로 만들 도구 리스트
                for tool_data in tools_data:
                    if tool_data["name"] not in existing_tools:
                        new_tools_data.append(tool_data)
                    created_tools_map[tool_data["name"]] = existing_tools.get(
                        tool_data["name"]
                    )

                unique_new_tools = []  # 중복제거
                seen_names = set()
                for tool_data in new_tools_data:
                    if tool_data["name"] not in seen_names:
                        unique_new_tools.append(tool_data)
                        seen_names.add(tool_data["name"])

                if unique_new_tools:
                    new_created_tools = await self.crud_tool.acreate_all(
                        db, obj_in=unique_new_tools
                    )
                    for tool in new_created_tools:
                        created_tools_map[tool.name] = tool

            relations_data = []
            for mapping in action_tool_mapping:
                action_idx = mapping["action_idx"]
                tool_name = mapping["tool_name"]

                if tool_name in created_tools_map and created_tools_map[tool_name]:
                    relation_obj = {
                        "action_id": created_actions[action_idx].id,
                        "tool_id": created_tools_map[tool_name].id,
                    }
                    relations_data.append(relation_obj)

            if relations_data:
                logger.info(f"relations_data: {relations_data}")
                await self.crud_action_tool_relationship.acreate_all(
                    db, obj_in=relations_data
                )
            new_agent_detail = await self.get_agent_detail(db, new_agent.id)
            if not new_agent_detail:
                raise ServiceException(
                    status_code=500,
                    error_code=ErrorCode.UNEXPECTED_ERROR,
                    detail="Failed to retrieve agent details after creation.",
                )
            await db.commit()
            return new_agent_detail
        except Exception as e:
            await db.rollback()
            logger.error(f"Error creating pro agent: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to create pro agent: {str(e)}",
            )

    async def create_general_agent(
        self, db: AsyncSession, agent_detail: ExpertAgentDetail
    ) -> ExpertAgentDetail:
        """
        ExpertAgentDetail 정보를 받아 관련된 모든 데이터(Agent, Step, Action, Tool)를 생성합니다.
        일반 agent의 경우 step과 action을 생성하지 않습니다.
        """
        try:
            # 1. Agent 생성
            agent_data = {
                "name": agent_detail.name,
                "description": agent_detail.description,
                "category": agent_detail.category,
                "usage_scope": agent_detail.usage_scope,
                "org_id": agent_detail.org_id,
                "team_id": agent_detail.team_id,
                "created_user_id": agent_detail.created_user_id,
                "use_count": agent_detail.use_count,
                "review_status": agent_detail.review_status,
                "agent_type": agent_detail.agent_type,
            }
            new_agent: ExpertAgent = await self.crud_expert_agent.create(
                db, obj_in=agent_data
            )

            # 2. Tool ID들을 한 번에 수집
            tool_ids = []
            if hasattr(agent_detail, "steps"):
                for step in agent_detail.steps:
                    for action in step.actions:
                        for tool in action.tools:
                            if tool and tool.id is not None:
                                tool_ids.append(tool.id)
            await self.crud_expert_agent.create_general_agent_instruction(
                db=db,
                expert_agent_id=new_agent.id,
                instruction=agent_detail.description,
                tools=tool_ids if tool_ids else None,
            )
            # 4. 생성된 Agent의 상세 정보 조회
            return await self.crud_expert_agent.get_agent_detail(db, new_agent.id)
        except Exception as e:
            await db.rollback()
            logger.error(f"Error creating general agent: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to create general agent: {str(e)}",
            )

    async def update_pro_agent(
        self, db: AsyncSession, agent_id: int, agent_detail: UpdateAgentPayload
    ) -> ExpertAgentDetail:
        try:
            # 1. 에이전트 존재 확인
            agent = await db.get(ExpertAgent, agent_id)
            if not agent:
                return None

            # Agent level
            agent_data = agent_detail.model_dump(exclude={"steps", "created_user_id"})
            await self.crud_expert_agent.update(db, db_obj=agent, obj_in=agent_data)

            # Step-Action-Tool level
            await self._update_pro_agent_structure(db, agent_id, agent_detail)

            await db.commit()
            return agent

        except Exception as e:
            await db.rollback()
            logger.error(f"Error updating pro agent: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to update pro agent: {str(e)}",
            )

    async def update_general_agent(
        self, db: AsyncSession, agent_id: int, agent_detail: UpdateAgentPayload
    ) -> ExpertAgentDetail:
        try:
            # 1. 에이전트 존재 확인
            agent = await db.get(ExpertAgent, agent_id)
            if not agent:
                return None

            # Agent level
            agent_data = agent_detail.model_dump(exclude={"steps", "created_user_id"})
            await self.crud_expert_agent.update(db, db_obj=agent, obj_in=agent_data)

            # Step-Action-Tool level
            await self._update_general_agent_contents(db, agent_id, agent_detail)
            await db.commit()
            return agent

        except Exception as e:
            await db.rollback()
            logger.error(f"Error updating general agent: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to update general agent: {str(e)}",
            )

    async def _update_pro_agent_structure(
        self, db: AsyncSession, agent_id: int, agent_detail: UpdateAgentPayload
    ) -> None:
        # 기존 구조 삭제
        await self.crud_expert_agent.delete_agent_contents_pro(db, agent_id=agent_id)
        if not agent_detail.steps:
            return

        # 1. 모든 Tool 이름을 미리 수집하여 기존 Tool들을 한 번에 조회
        all_tool_names = set()
        for step_data in agent_detail.steps:
            if step_data.actions:
                for action_data in step_data.actions:
                    if action_data.tools:
                        for tool_data in action_data.tools:
                            if tool_data and tool_data.name:
                                all_tool_names.add(tool_data.name)
        # 2. 기존 Tool들을 한 번에 조회
        existing_tools_by_name = {}
        if all_tool_names:
            existing_tools = await self.crud_tool.get_tools_by_names(db, all_tool_names)
            existing_tools_by_name = {tool.name: tool for tool in existing_tools}

        # 3. 새로 생성할 Tool들 식별 및 일괄 생성
        new_tools_to_create = []
        tools_to_create_names = set()

        for step_data in agent_detail.steps:
            if step_data.actions:
                for action_data in step_data.actions:
                    if action_data.tools:
                        for tool_data in action_data.tools:
                            if (
                                tool_data
                                and tool_data.name
                                and tool_data.name not in existing_tools_by_name
                                and tool_data.name not in tools_to_create_names
                            ):

                                new_tools_to_create.append(
                                    Tool(
                                        name=tool_data.name,
                                        description=tool_data.description,
                                        type=tool_data.type,
                                        icon_path=tool_data.icon_path,
                                        config=tool_data.config,
                                    )
                                )
                                tools_to_create_names.add(tool_data.name)
        # 4. 새 Tool들 bulk insert
        if new_tools_to_create:
            await self.crud_tool.acreate_all(
                db,
                obj_in=[
                    {
                        "name": t.name,
                        "description": t.description,
                        "type": t.type,
                        "icon_path": t.icon_path,
                        "config": t.config,
                    }
                    for t in new_tools_to_create
                ],
            )
            for tool in new_tools_to_create:
                existing_tools_by_name[tool.name] = tool

        # 5. Step들 생성 및 하위 구조 생성
        for step_data in agent_detail.steps:
            # Step 생성
            step_obj = {
                "expert_agent_id": agent_id,
                "name": step_data.name,
                "description": step_data.description,
                "order": step_data.order,
            }
            new_step: Step = await self.crud_step.create(db, obj_in=step_obj)

            # 해당 Step의 Action들과 Tool 관계 처리
            if step_data.actions:
                await self._create_actions_with_tools_batch(
                    db, new_step.id, step_data.actions, existing_tools_by_name
                )
        return

    async def _create_actions_with_tools_batch(
        self,
        db: AsyncSession,
        step_id: int,
        actions_data: List[ActionForUpdate],
        existing_tools_by_name: dict,
    ) -> None:
        # Action들 생성
        actions_to_insert = []
        action_tool_mappings = []  # (action_index, tool_names)

        for action_idx, action_data in enumerate(actions_data):
            action_obj = Action(
                step_id=step_id,
                name=action_data.name,
                description=action_data.description,
                order=action_data.order,
            )
            actions_to_insert.append(action_obj)

            # 해당 Action의 Tool 이름들 수집
            tool_names = []
            if action_data.tools:
                for tool_data in action_data.tools:
                    if tool_data and tool_data.name:
                        tool_names.append(tool_data.name)

            action_tool_mappings.append((action_idx, tool_names))

        # Action들 bulk insert
        await self.crud_action.acreate_all(
            db,
            obj_in=[
                {
                    "step_id": step_id,
                    "name": a.name,
                    "description": a.description,
                    "order": a.order,
                }
                for a in actions_to_insert
            ],
        )

        # 생성된 Action들의 ID를 조회하여 actions_to_insert에 할당
        created_actions_stmt = (
            select(Action).where(Action.step_id == step_id).order_by(Action.order)
        )
        created_actions_result = await db.execute(created_actions_stmt)
        created_actions = created_actions_result.scalars().all()

        # actions_to_insert의 각 Action에 ID 할당
        for i, action in enumerate(actions_to_insert):
            if i < len(created_actions):
                # name과 description으로 검증하여 올바른 Action에 ID 할당
                for created_action in created_actions:
                    if (
                        created_action.name == action.name
                        and created_action.description == action.description
                    ):
                        action.id = created_action.id
                        break
        # Action-Tool 관계들 생성
        relations_to_insert = []
        for action_idx, tool_names in action_tool_mappings:
            action_obj = actions_to_insert[action_idx]
            for tool_name in tool_names:
                if tool_name in existing_tools_by_name:
                    relations_to_insert.append(
                        {
                            "action_id": action_obj.id,
                            "tool_id": existing_tools_by_name[tool_name].id,
                        }
                    )

        # Relation들 bulk insert
        if relations_to_insert:
            await self.crud_action_tool_relationship.acreate_all(
                db, obj_in=relations_to_insert
            )
        return

    async def _update_general_agent_contents(
        self, db: AsyncSession, agent_id: int, agent_detail: UpdateAgentPayload
    ):
        """General Agent의 추가 정보를 효율적으로 업데이트"""

        tool_ids = []

        if hasattr(agent_detail, "steps") and agent_detail.steps:
            # 모든 Tool 이름을 먼저 수집
            all_tool_names = set()
            for step in agent_detail.steps:
                if step.actions:
                    for action in step.actions:
                        if action.tools:
                            for tool in action.tools:
                                if tool and tool.name:
                                    all_tool_names.add(tool.name)

            # Tool들을 한 번에 조회
            if all_tool_names:
                tools_stmt = select(Tool).where(Tool.name.in_(all_tool_names))
                tools_result = await db.execute(tools_stmt)
                existing_tools = tools_result.scalars().all()
                tool_ids = [tool.id for tool in existing_tools]

        await self.update_general_agent_instruction(
            db=db,
            expert_agent_id=agent_id,
            instruction=agent_detail.description,
            tools=tool_ids if tool_ids else None,
        )
        return

    async def update_general_agent_instruction(
        self,
        db: AsyncSession,
        expert_agent_id: int,
        instruction: str,
        tools: Optional[List[int]] = None,
    ) -> GeneralAgentInstruction:
        """
        General Agent의 instruction과 tool 관계를 업데이트합니다.
        """
        try:
            # 기존 instruction 조회
            stmt = select(GeneralAgentInstruction).where(
                GeneralAgentInstruction.expert_agent_id == expert_agent_id
            )
            result = await db.execute(stmt)
            instruction_obj = result.scalars().first()

            if instruction_obj:
                instruction_obj.instruction = instruction
                ### crud로 추후 이동 ###
                await db.execute(
                    delete(GeneralAgentInstructionTool).where(
                        GeneralAgentInstructionTool.expert_agent_instruction_id
                        == instruction_obj.id
                    )
                )
                ### crud로 추후 이동 ###

                if tools:
                    tool_relationships = [
                        {
                            "expert_agent_instruction_id": instruction_obj.id,
                            "tool_id": tool_id,
                        }
                        for tool_id in tools
                    ]
                    await self.crud_general_instruction_tool.acreate_all(
                        db, obj_in=tool_relationships
                    )
            else:
                instruction_obj = await self.create_general_agent_instruction(
                    db, expert_agent_id, instruction, tools
                )

            await db.commit()
            await db.refresh(instruction_obj)
            return instruction_obj

        except Exception as e:
            await db.rollback()
            logger.error(f"Error updating general agent instruction: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to update general agent instruction: {str(e)}",
            )

    async def create_general_agent_instruction(
        self,
        db: AsyncSession,
        expert_agent_id: int,
        instruction: str,
        tools: Optional[List[int]] = None,
    ) -> GeneralAgentInstruction:
        try:
            tool_delete_stmt = delete(GeneralAgentInstructionTool).where(
                GeneralAgentInstructionTool.expert_agent_instruction_id.in_(
                    select(GeneralAgentInstruction.id).where(
                        GeneralAgentInstruction.expert_agent_id == expert_agent_id
                    )
                )
            )
            await db.execute(tool_delete_stmt)

            # instruction 삭제
            stmt = delete(GeneralAgentInstruction).where(
                GeneralAgentInstruction.expert_agent_id == expert_agent_id
            )
            await db.execute(stmt)
            general_agent_instruction = GeneralAgentInstruction(
                expert_agent_id=expert_agent_id,
                instruction=instruction,
            )
            db.add(general_agent_instruction)
            await db.flush()  # ID 생성을 위해 flush

            # tools가 있을 때만 tool 관계 생성
            if tools:
                tool_relationships = [
                    {
                        "expert_agent_instruction_id": general_agent_instruction.id,
                        "tool_id": tool_id,
                    }
                    for tool_id in tools
                ]
                await self.crud_general_instruction_tool.acreate_all(
                    db, obj_in=tool_relationships
                )

            await db.commit()
            return general_agent_instruction

        except Exception as e:
            await db.rollback()
            logger.error(f"Error creating general agent instruction: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to create general agent instruction: {str(e)}",
            )

    async def delete_agent_with_document(self, db: AsyncSession, agent_id: int) -> bool:
        agent = await db.get(ExpertAgent, agent_id)
        if not agent:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="Agent not found",
            )
        from time import time

        try:
            t0 = time()

            # 1. HTTP 요청들과 문서 삭제를 가장 먼저 시작 (백그라운드에서 실행)
            import asyncio

            # HTTP 요청들을 백그라운드에서 시작 (에러 처리 포함)
            async def safe_http_request(func, *args, **kwargs):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    logger.warning(f"HTTP request failed: {func.__name__} - {e}")
                    return None

            http_tasks = [
                safe_http_request(
                    self.crud_ai_chat.delete_user_agent_preference,
                    user_id=agent.created_user_id,
                    agent_id=agent_id,
                ),
                safe_http_request(
                    self.crud_ai_chat.delete_all_user_memory,
                    user_id=agent.created_user_id,
                    agent_id=agent_id,
                ),
            ]
            http_futures = [asyncio.create_task(task) for task in http_tasks]

            # 문서 조회 및 삭제 작업도 백그라운드에서 시작
            async def delete_documents_async():
                document_stmt = select(ProcedureDocument).where(
                    ProcedureDocument.expert_agent_id == agent_id,
                    ProcedureDocument.status == "active",
                )
                result = await db.execute(document_stmt)
                documents = result.scalars().all()

                if documents:
                    document_tasks = [
                        self.crud_procedure_document.delete_file(
                            db, document.id, auto_commit=False
                        )
                        for document in documents
                    ]
                    await asyncio.gather(*document_tasks)
                return len(documents)

            document_future = asyncio.create_task(delete_documents_async())

            # 2. 모든 작업을 완전히 병렬로 실행
            all_tasks = []

            # HTTP 요청들 추가
            all_tasks.extend(http_futures)

            # 문서 삭제 추가
            all_tasks.append(document_future)

            # DB 작업들 추가
            if agent.agent_type == "general":
                all_tasks.append(
                    self.crud_expert_agent.delete_general_agent_instruction(
                        db, agent_id, auto_commit=False
                    )
                )

            all_tasks.extend(
                [
                    self.crud_chat_starter.delete_chat_starter_by_agent_id(
                        db, agent_id, auto_commit=False
                    ),
                    self.crud_expert_agent_history.delete_agent_history(
                        db, agent_id, auto_commit=False
                    ),
                    self.crud_expert_agent.delete_agent_contents(
                        db, agent_id, auto_commit=False
                    ),
                    self.crud_expert_agent.delete(db, id=agent_id, auto_commit=False),
                ]
            )

            # 모든 작업을 병렬로 실행
            try:
                results = await asyncio.wait_for(
                    asyncio.gather(*all_tasks, return_exceptions=True),
                    timeout=30.0,  # 30초 타임아웃
                )

                # 결과 분석
                http_results = results[:2]  # 처음 2개는 HTTP 요청
                document_count = (
                    results[2] if len(results) > 2 else 0
                )  # 3번째는 문서 삭제
                db_results = results[3:]  # 나머지는 DB 작업들

                # HTTP 요청 결과 확인 및 로깅
                if http_results:
                    request_names = [
                        "delete_user_agent_preference",
                        "delete_all_user_memory",
                    ]
                    for i, result in enumerate(http_results):
                        if isinstance(result, Exception):
                            logger.warning(
                                f"HTTP request {request_names[i]} failed: {result}"
                            )
                        elif result is None:
                            logger.warning(f"HTTP request {request_names[i]} failed")
                        else:
                            logger.info(
                                f"HTTP request {request_names[i]} completed successfully"
                            )

                # DB 작업 결과 확인
                db_task_names = [
                    (
                        "delete_general_agent_instruction"
                        if agent.agent_type == "general"
                        else None
                    ),
                    "delete_chat_starter_by_agent_id",
                    "delete_agent_history",
                    "delete_agent_contents",
                    "delete_agent",
                ]

                for i, result in enumerate(db_results):
                    if isinstance(result, Exception):
                        task_name = db_task_names[i] or f"DB task {i}"
                        logger.error(f"DB task {task_name} failed: {result}")
                        raise result  # DB 작업 실패는 치명적이므로 예외 발생

                logger.info(
                    f"All tasks completed successfully (deleted {document_count} documents)"
                )

            except asyncio.TimeoutError:
                logger.warning("All tasks timed out after 30 seconds")
                raise ServiceException(
                    status_code=500,
                    error_code=ErrorCode.UNEXPECTED_ERROR,
                    detail="Tasks timed out",
                )
            except Exception as e:
                logger.error(f"Error in parallel tasks: {e}")
                raise

            # 모든 작업이 성공적으로 완료된 후 한 번만 commit
            await db.commit()
            return True
        except Exception as e:
            await db.rollback()
            logger.error(f"Error deleting agent with document: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to delete agent with document: {str(e)}",
            )

    async def update_agent_timestamp(
        self, db: AsyncSession, agent_id: int, review_status: str
    ) -> bool:
        try:
            agent = await self.crud_expert_agent.get_agent_by_id(db, agent_id)
            if not agent:
                return False

            if review_status == "submitted":
                timestamp_type = "registered_at"
            elif review_status == "deployed" or review_status == "rejected":
                timestamp_type = "reviewed_at"
            else:
                return False

            result = await self.crud_expert_agent.update_agent_timestamp(
                db, agent_id, timestamp_type
            )
            await db.commit()
            return result

        except Exception as e:
            await db.rollback()
            logger.error(f"Error updating agent timestamp: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to update agent timestamp: {str(e)}",
            )
