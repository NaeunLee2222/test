from typing import Dict, Type

from .company_service import CompanyService
from .skcc.skcc_service import SKCCCompanyService
from .skt.skt_service import SKTCompanyService


class CompanyServiceFactory:
    _services: Dict[str, Type[CompanyService]] = {
        "SKT": SKTCompanyService,
        "SKCC": SKCCCompanyService,
    }

    @classmethod
    def get_service(cls, company: str) -> CompanyService:
        service_class = cls._services.get(company)
        if not service_class:
            raise ValueError(f"Unsupported company: {company}")
        return service_class()
