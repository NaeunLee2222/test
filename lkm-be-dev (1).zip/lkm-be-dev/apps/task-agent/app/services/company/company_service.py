from abc import ABC, abstractmethod
from typing import Any, Dict

from core.config import get_setting

settings = get_setting()


class CompanyService(ABC):
    @abstractmethod
    def get_meeting_room_access_token(self) -> str:
        """회사별 회의실 시스템 액세스 토큰 반환"""
        pass

    @abstractmethod
    def get_user_working_location(self, user_id: str) -> Dict[str, Any]:
        """사용자의 근무지 정보 조회"""
        pass

    @abstractmethod
    def process_meeting_room_data(self, data: Any) -> Any:
        """회의실 데이터 처리"""
        pass

    @abstractmethod
    def get_custom_tools(self) -> Dict[str, Any]:
        """회사별 커스텀 도구 반환"""
        pass
