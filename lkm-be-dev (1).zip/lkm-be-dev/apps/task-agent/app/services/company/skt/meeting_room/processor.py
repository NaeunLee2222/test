import ast
import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Tuple

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.api_client import APIClient

settings = get_setting()
logger = get_logging()


class MeetingRoomProcessor:
    """SKT 커스텀 회의실 데이터 처리 로직"""

    @staticmethod
    def find_available_times(
        reservations: List[Dict[str, Any]], start_time: str, end_time: str
    ) -> List[Tuple[datetime, datetime]]:
        """예약 가능한 시간대 찾기"""
        available_times = []

        # 시작 시간과 종료 시간을 datetime 객체로 변환
        start = datetime.strptime(start_time, "%H:%M:%S")
        end = datetime.strptime(end_time, "%H:%M:%S")

        # 예약된 시간대를 datetime 범위로 변환
        reserved_ranges = []
        target_date = None
        for reservation in reservations:
            start_dt = datetime.strptime(reservation["start"], "%Y-%m-%dT%H:%M:%S")
            end_dt = datetime.strptime(reservation["end"], "%Y-%m-%dT%H:%M:%S")
            if target_date is None:
                target_date = start_dt.date()

            reserved_ranges.append(
                (
                    datetime.strptime(start_dt.strftime("%H:%M:%S"), "%H:%M:%S"),
                    datetime.strptime(end_dt.strftime("%H:%M:%S"), "%H:%M:%S"),
                )
            )

        # 시간 정렬
        reserved_ranges.sort(key=lambda x: x[0])

        current_time = start

        # 예약되지 않은 시간 계산
        for res_start, res_end in reserved_ranges:
            if current_time < res_start:
                available_times.append((current_time, res_start))
            current_time = max(current_time, res_end)

        # 마지막 예약 이후 시간 추가
        if current_time < end:
            available_times.append((current_time, end))

        seoul_tz = timezone(timedelta(hours=9))
        now_in_seoul = datetime.now(seoul_tz)

        # 현재 날짜와 대상 날짜가 같은 경우에만 시간 조정
        if target_date and target_date == now_in_seoul.date():
            now_str = now_in_seoul.strftime("%H:%M:%S")
            now_time = datetime.strptime(now_str, "%H:%M:%S")

            # 30분 단위로 내림 계산
            minutes = now_time.hour * 60 + now_time.minute
            rounded_minutes = (minutes // 30) * 30
            rounded_time = datetime.strptime("00:00:00", "%H:%M:%S") + timedelta(
                minutes=rounded_minutes
            )

            future_available_times = []
            for slot_start, slot_end in available_times:
                if slot_end <= now_time:
                    continue
                if slot_start < now_time:
                    slot_start = rounded_time
                future_available_times.append((slot_start, slot_end))
        else:
            # 다른 날짜의 경우 시간 조정 없이 그대로 사용
            future_available_times = available_times

        # 시작시간 기준 정렬 (이미 정렬되어 있지만, 안전을 위해 정렬)
        future_available_times.sort(key=lambda x: x[0])

        return future_available_times

    @staticmethod
    def process_meeting_room_data(
        api_response: str | dict,
        start_time: str = "08:00:00",
        end_time: str = "23:00:00",
    ) -> dict:
        """회의실 데이터 처리"""
        logger.info(f"[MeetingRoomProcessor] api_response: {api_response}")
        logger.info(f"[MeetingRoomProcessor] api_response type: {type(api_response)}")
        if type(api_response) == dict and api_response.get("items"):
            logger.info(
                f"[MeetingRoomProcessor] api_response items: {api_response.get('items')}"
            )
            logger.info(
                f"[MeetingRoomProcessor] api_response items type: {type(api_response.get('items'))}"
            )

        # 이미 딕셔너리인 경우 파싱 스킵
        if isinstance(api_response, dict):
            parsed_response = api_response
        else:
            # 1. JSON 파싱 시도
            try:
                parsed_response = json.loads(api_response)
            except Exception as e:
                logger.warning(
                    f"JSON parsing failed, trying ast.literal_eval: {str(e)}"
                )

                # 2. AST 파싱 시도
                try:
                    parsed_response = ast.literal_eval(api_response)
                except Exception as e:
                    logger.error(f"Both JSON and AST parsing failed: {str(e)}")
                    raise ValueError("Failed to parse API response")

        if not parsed_response:
            raise ValueError("Empty API response after parsing")

        rooms = parsed_response.get("items", [])
        output = []

        for room in rooms:
            reservations = room.get("reservations", [])
            available_times = MeetingRoomProcessor.find_available_times(
                reservations, start_time, end_time
            )

            # 빈 시간이 있는 회의실만 추가
            if available_times:
                output.append(
                    {
                        "roomId": room.get("roomId"),
                        "roomName": room.get("roomName"),
                        "seatCount": room.get("seatCount"),
                        "floorId": room.get("floor").get("floorId"),
                        "floorName": room.get("floor").get("floorName"),
                        "isAvailableReservation": room.get("isAvailableReservation"),
                        "fixedDevices": room.get("fixedDevices"),
                        "availableTimes": [
                            {
                                "start": available[0].strftime("%H:%M:%S"),
                                "end": available[1].strftime("%H:%M:%S"),
                            }
                            for available in available_times
                        ],
                    }
                )

        logger.info(f"Available meeting room info: {output}")

        # 사용 가능한 회의실이 없는 경우 메타데이터 추가
        if not output:
            return {
                "available_rooms": [],
                "has_available_rooms": False,
                "message": "현재 사용 가능한 회의실이 없습니다.",
            }

        return {"available_rooms": output, "has_available_rooms": True}

    @staticmethod
    def get_user_working_location(
        user_id: str,
        api_key: str,
        timeout: tuple[int, int] = (5, 15),
        max_retries: int = 3,
        retry_delay: float = 0.5,
    ) -> dict:
        """사용자의 기본 근무지 정보 조회"""
        api_client = APIClient(timeout, max_retries, retry_delay)

        try:
            base_url = (
                "meetingroomifdev" if settings.ENVIRONMENT == "DEV" else "meetingroomif"
            )
            url = (
                f"http://{base_url}.sktelecom.com/api/v1/user/{user_id}/workingLocation"
            )

            result = api_client.request(
                method="GET",
                url=url,
                headers={
                    "accept": "application/json",
                    "Authorization": api_key,
                },
            )

            if not result.get("success") or not result.get("data"):
                logger.error(f"데이터 조회 실패: {result.get('message')}")
                raise ValueError(result.get("message") or "데이터 조회 실패")

            data = result["data"]
            working_office = data.get("workingOffice")
            working_office_floor = data.get("workingOfficeFloor")

            if not working_office or not working_office_floor:
                logger.error("근무지 정보가 존재하지 않습니다.")
                raise ValueError("근무지 정보가 존재하지 않습니다.")

            logger.info(f"사용자 기본 회의실 정보: {working_office}")
            return {
                "officeName": working_office.get("officeName") or "이름 없음",
                "officeId": working_office["officeId"],
                "floorName": working_office_floor.get("floorName")
                or f"{working_office_floor['floorNumber']}층",
                "floorId": working_office_floor["floorId"],
            }

        except (KeyError, TypeError) as e:
            logger.error(f"데이터 형식 오류: {str(e)}")
