from typing import Any, Dict

from core.config import get_setting
from services.company.company_service import CompanyService
from services.company.skt.meeting_room.processor import MeetingRoomProcessor
from services.tools.reserve_and_noti import meeting_reserve_and_notify_tool

settings = get_setting()


class SKTCompanyService(CompanyService):
    def get_meeting_room_access_token(self) -> str:
        return settings.MEETING_ROOM_LEGACY_API_KEY

    def get_user_working_location(self, user_id: str) -> Dict[str, Any]:
        return MeetingRoomProcessor.get_user_working_location(
            user_id, self.get_meeting_room_access_token()
        )

    def process_meeting_room_data(self, data: Any) -> Any:
        return MeetingRoomProcessor.process_meeting_room_data(data)

    def get_custom_tools(self) -> Dict[str, Any]:
        return {
            "meeting_reserve_and_notify": {
                "tool": meeting_reserve_and_notify_tool,
                "description": meeting_reserve_and_notify_tool.description,
            }
        }
