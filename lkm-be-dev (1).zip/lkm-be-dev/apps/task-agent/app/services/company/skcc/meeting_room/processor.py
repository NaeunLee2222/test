import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Tuple

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.api_client import APIClient

settings = get_setting()
logger = get_logging()


class SKCCMeetingRoomProcessor:
    """SKCC 커스텀 회의실 데이터 처리 로직"""

    @staticmethod
    def find_available_times(
        resv_list: List[Dict[str, Any]],
        resv_start_time: str,
        resv_end_time: str,
    ) -> List[Tuple[datetime, datetime]]:
        """예약 가능한 시간대 찾기"""
        available_times = []

        # KST 타임존 설정
        seoul_tz = timezone(timedelta(hours=9))
        now_in_seoul = datetime.now(seoul_tz)
        today = now_in_seoul.date()

        # 모든 예약 내역을 검사하여 target_date 결정
        target_date = None
        for reservation in resv_list:
            if "startDate" in reservation:
                resv_date = datetime.strptime(reservation["startDate"], "%Y%m%d").date()
                if target_date is None:
                    target_date = resv_date
                elif resv_date == today:  # 오늘 날짜의 예약이 있다면 우선적으로 선택
                    target_date = today
                    break
                elif abs((resv_date - today).days) < abs((target_date - today).days):
                    # 오늘 날짜와 가장 가까운 날짜 선택
                    target_date = resv_date

        # 예약 내역이 없거나 날짜 정보가 없는 경우 오늘 날짜 사용
        if target_date is None:
            target_date = today

        start_hour = int(resv_start_time)
        end_hour = int(resv_end_time)

        # 시작 시간과 종료 시간을 datetime 객체로 변환
        start = datetime.strptime(f"{start_hour:02d}:00:00", "%H:%M:%S")
        end = datetime.strptime(f"{end_hour:02d}:00:00", "%H:%M:%S")

        # 예약된 시간대를 datetime 범위로 변환
        reserved_ranges = []

        # Get the target date from the first reservation's startDate if available
        target_date = None
        if resv_list and "startDate" in resv_list[0]:
            target_date = datetime.strptime(resv_list[0]["startDate"], "%Y%m%d").date()
        else:
            # Default to current date if no reservations or no startDate
            target_date = datetime.now().date()

        for reservation in resv_list:
            # SKCC API는 시간과 분을 별도 필드로 제공
            start_hour = int(reservation.get("startTime", "0"))
            start_minute = int(reservation.get("startMinute", "0"))
            end_hour = int(reservation.get("endTime", "0"))
            end_minute = int(reservation.get("endMinute", "0"))

            start_dt = datetime.strptime(
                f"{start_hour:02d}:{start_minute:02d}:00", "%H:%M:%S"
            )
            end_dt = datetime.strptime(
                f"{end_hour:02d}:{end_minute:02d}:00", "%H:%M:%S"
            )

            reserved_ranges.append((start_dt, end_dt))

        # 시간 정렬
        reserved_ranges.sort(key=lambda x: x[0])

        current_time = start

        # 예약되지 않은 시간 계산
        for res_start, res_end in reserved_ranges:
            if current_time < res_start:
                available_times.append((current_time, res_start))
            current_time = max(current_time, res_end)

        # 마지막 예약 이후 시간 추가
        if current_time < end:
            available_times.append((current_time, end))

        # 현재 시간 이후의 시간대만 필터링
        seoul_tz = timezone(timedelta(hours=9))
        now_in_seoul = datetime.now(seoul_tz)

        # 현재 날짜와 대상 날짜 비교
        if target_date == now_in_seoul.date():
            now_str = now_in_seoul.strftime("%H:%M:%S")
            now_time = datetime.strptime(now_str, "%H:%M:%S")

            # 30분 단위로 내림 계산
            minutes = now_time.hour * 60 + now_time.minute
            rounded_minutes = (minutes // 30) * 30
            rounded_time = datetime.strptime("00:00:00", "%H:%M:%S") + timedelta(
                minutes=rounded_minutes
            )

            future_available_times = []
            for slot_start, slot_end in available_times:
                if slot_end <= now_time:
                    continue
                if slot_start < now_time:
                    slot_start = rounded_time
                future_available_times.append((slot_start, slot_end))
        else:
            # 다른 날짜의 경우 시간 조정 없이 그대로 사용
            future_available_times = available_times

        # 시작시간 기준 정렬
        future_available_times.sort(key=lambda x: x[0])

        return future_available_times

    @staticmethod
    def process_meeting_room_data(
        api_response: str | dict,
    ) -> List[Dict[str, Any]]:
        """회의실 데이터 처리"""
        logger.info(
            f"[SKCCMeetingRoomProcessor] api_response type: {type(api_response)}"
        )

        # 이미 딕셔너리인 경우 파싱 스킵
        if isinstance(api_response, dict):
            parsed_response = api_response
        else:
            try:
                parsed_response = json.loads(api_response)
            except Exception as e:
                logger.error(f"JSON parsing failed: {str(e)}")
                raise ValueError("Failed to parse API response")

        if not parsed_response:
            raise ValueError("Empty API response after parsing")

        # 응답 코드 확인
        response_code = parsed_response.get("response_code")
        # if response_code != "0000":
        #     response_msg = parsed_response.get("response_msg", "Unknown error")
        #     logger.error(f"API error: {response_code} - {response_msg}")
        #     raise ValueError(f"API error: {response_msg}")

        rooms = parsed_response.get("roomList", [])
        output = []

        for room in rooms:
            resv_list = room.get("resvList", [])
            resv_start_time = room.get("resvStartTime", "8")
            resv_end_time = room.get("resvEndTime", "23")

            available_times = SKCCMeetingRoomProcessor.find_available_times(
                resv_list, resv_start_time, resv_end_time
            )

            # 회의실 정보 구성
            if available_times:
                room_info = {
                    "buildCode": room.get("buildCode"),
                    "buildName": room.get("buildNm"),
                    "floorNum": room.get("floorNum"),
                    "roomName": room.get("roomNm"),
                    "roomId": room.get("roomId"),
                    "roomType": room.get("roomType"),
                    "roomTypeName": room.get("roomTypeNm"),
                    "hasTv": room.get("oaTv") == "Y",
                    "hasBeamProjector": room.get("oaBeam") == "Y",
                    "hasVideoConference": room.get("videoConference") == "Y",
                    "capacity": int(room.get("inMax", 0)),
                    "resvStartTime": room.get("resvStartTime"),
                    "resvEndTime": room.get("resvEndTime"),
                    "resvMaxMinute": room.get("resvMaxMinute"),
                    "availableTimes": [
                        {
                            "start": available[0].strftime("%H:%M:%S"),
                            "end": available[1].strftime("%H:%M:%S"),
                        }
                        for available in available_times
                    ],
                }

                output.append(room_info)

        logger.info(f"Available meeting room info: {output}")

        if not output:
            return {
                "available_rooms": [],
                "has_available_rooms": False,
                "message": "현재 사용 가능한 회의실이 없습니다.",
            }

        return {"available_rooms": output, "has_available_rooms": True}

    @staticmethod
    def get_user_working_location(
        user_id: str,
        api_key: str,
        timeout: tuple[int, int] = (5, 15),
        max_retries: int = 3,
        retry_delay: float = 0.5,
    ) -> Dict[str, Any]:
        """사용자 근무지 정보 조회"""
        url = "https://onspace.sk.com/websvc/settings/mySettings"
        api_client = APIClient(timeout, max_retries, retry_delay)
        result = api_client.request(
            method="POST",
            url=url,
            headers={
                "Authorization": api_key,
                "Accept-Language": "ko",
            },
            json={"userId": f"SKCC.{user_id}"},
        )

        response_code = result.get("response_code", "1")
        if response_code == "0":
            logger.info(f"사용자 기본 회의실 정보: {result}")
            return {
                "officeName": result.get("buildNm", ""),
                "officeId": result.get("buildCode", ""),
                "floorName": result.get("floorNm", ""),
                "floorId": result.get("floorNum", ""),
            }
        else:
            logger.error(
                f"사용자 기본 회의실 정보 조회 실패: {result.get('response_msg')}"
            )
            return {
                "officeName": "",
                "officeId": "",
                "floorName": "",
                "floorId": "",
            }
