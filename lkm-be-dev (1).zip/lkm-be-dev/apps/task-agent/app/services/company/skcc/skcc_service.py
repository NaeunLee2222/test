from typing import Any, Dict

from core.config import get_setting
from core.utils.auth import get_onspace_access_token
from services.company.company_service import CompanyService
from services.company.skcc.meeting_room.processor import SKCCMeetingRoomProcessor

settings = get_setting()


class SKCCCompanyService(CompanyService):
    def get_meeting_room_access_token(self) -> str:
        return f"Bearer {get_onspace_access_token()}"

    def get_user_working_location(self, user_id: str) -> Dict[str, Any]:
        return SKCCMeetingRoomProcessor.get_user_working_location(
            user_id, self.get_meeting_room_access_token()
        )

    def process_meeting_room_data(self, data: Any) -> Any:
        return SKCCMeetingRoomProcessor.process_meeting_room_data(data)

    def get_custom_tools(self) -> Dict[str, Any]:
        return {}
