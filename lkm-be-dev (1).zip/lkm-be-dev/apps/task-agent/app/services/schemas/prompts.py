from datetime import datetime
from typing import Optional

from pydantic import BaseModel


# 요청에 사용되는 기본 모델
class PromptBase(BaseModel):
    title: str  # 프롬프트 제목
    content: str  # 프롬프트 내용


# 데이터 생성 시 사용하는 스키마
class PromptCreate(PromptBase):
    pass  # 기본 PromptBase를 상속받아서 title과 content만 필요


# 데이터 응답 시 사용하는 스키마
class Prompt(PromptBase):
    id: int  # 프롬프트 ID
    created_at: datetime  # 생성 일자
    updated_at: datetime  # 업데이트 일자

    class Config:
        from_attributes = (
            True  # SQLAlchemy 모델을 Pydantic 모델로 변환할 수 있도록 설정
        )


# 데이터 업데이트 시 사용하는 스키마
class PromptUpdate(PromptBase):
    title: Optional[str] = None  # 제목은 선택적
    content: Optional[str] = None  # 내용은 선택적

    # title 또는 content만 선택적으로 업데이트 할 수 있게 함


# 응답에서 출력할 때, 선택적으로 `created_at`과 `updated_at`을 포함
class PromptOut(PromptBase):
    id: int  # 프롬프트 ID
    created_at: datetime  # 생성 일자
    updated_at: datetime  # 업데이트 일자

    class Config:
        from_attributes = (
            True  # SQLAlchemy 모델을 Pydantic 모델로 변환할 수 있도록 설정
        )
