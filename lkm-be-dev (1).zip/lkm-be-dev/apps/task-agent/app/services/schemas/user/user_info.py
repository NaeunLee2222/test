from typing import Optional

from pydantic import BaseModel


class UserInfo(BaseModel):
    user_id: int
    email: Optional[str] = None
    username: Optional[str] = None
    department: Optional[str] = None
    profile: Optional[str] = None

    # @validator("profile")
    # def validate_profile(cls, v: Any) -> Dict[str, Any]:
    #     if isinstance(v, str):
    #         try:
    #             v = v.replace("'", '"')
    #             return json.loads(v)
    #         except json.JSONDecodeError:
    #             raise ValueError("Invalid JSON in profile")
    #     return v
