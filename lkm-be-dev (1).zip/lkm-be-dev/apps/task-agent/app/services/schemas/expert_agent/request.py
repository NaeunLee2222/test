from datetime import date
from typing import List, Optional

from pydantic import BaseModel, Field

from services.schemas.expert_agent.agent_model import (
    ExpertAgentBase,
    StepWithActions,
    UpdateAgentPayload,
)


class GetAgentsRequest(BaseModel):
    skip: int = 0
    limit: int = 100
    category: Optional[str] = None
    usage_scope: Optional[str] = None


class RecommendStepsRequest(BaseModel):
    name: str = Field(..., description="에이전트 이름", example="Engr. 업무 지원 Agent")
    description: str = Field(
        ..., description="에이전트 설명", example="RFQ/TBE sheet 자동 작성 및 기술검증"
    )
    document_id: Optional[int] = Field(
        None, description="업로드된 문서 ID (선택사항)", example=None
    )


class GeneralAgentInstructionRequest(BaseModel):
    instruction: str = Field(
        ...,
        description="General Agent의 instruction",
        example="이 에이전트는 RFQ/TBE sheet를 자동으로 작성하고 기술 검증을 수행합니다.",
    )
    tool_ids: Optional[List[int]] = Field(
        None, description="General Agent가 사용할 도구 ID 목록", example=[1, 2, 3]
    )

class UpdateChatStarterRequest(BaseModel):
    id : int
    starter: str = Field(
        ...,
        description="챗봇 시작 메시지",
        example="안녕하세요! 무엇을 도와드릴까요?"
    )


class CreateAgentWithStepsRequest(BaseModel):
    agent: ExpertAgentBase = Field(
        ...,
        description="에이전트 정보",
        example={
            "name": "generate workflow",
            "description": "1234",
            "category": "Engineering",
            "usage_scope": "public",
            "org_id": 1,
            "team_id": 1,
            "use_count": 0,
            "review_status": "saved",
            "agent_type": "pro",
        },
    )
    created_user_id: int = Field(..., description="생성한 사용자 ID", example=1)
    steps: List[StepWithActions] = Field(
        ...,
        description="Step 정보",
        example=[
            {
                "description": "Review the quality and consistency of the document and perform the necessary precautionary work (what: analyze the status of the document and identify the necessary corrections)",
                "id": None,
                "name": "Document analysis and preparation",
                "order": 1,
                "actions": [
                    {
                        "description": "identify the problem by checking the logical flow and consistency of the document (how: using a tool to detect logical errors)",
                        "id": None,
                        "name": "Review of logical consistency in documents",
                        "order": 1,
                        "tools": [
                            {
                                "description": "Review the logical consistency in the document.",
                                "id": 198,
                                "name": "logic_checker",
                                "type": "mcp",
                            }
                        ],
                    },
                    {
                        "description": "Evaluate the need to remove duplicate sentences or paragraphs from documents (how: use duplicate detection tools)",
                        "id": None,
                        "name": "detect duplicate contents in documents",
                        "order": 2,
                        "tools": [
                            {
                                "description": "Desert duplicate sentences or paragraphs in a document.",
                                "id": 228,
                                "name": "duplication_detector",
                                "type": "mcp",
                            }
                        ],
                    },
                    {
                        "description": "Identify the need to modify documents by reviewing spelling, spaces, typos, etc. (how to: use a spell review tool)",
                        "id": None,
                        "name": "Customization and typographic review",
                        "order": 3,
                        "tools": [
                            {
                                "description": "detects spelling, space writing, typos, etc.",
                                "id": 200,
                                "name": "typo_checker",
                                "type": "mcp",
                            }
                        ],
                    },
                ],
            },
            {
                "description": "reflecting changes in the document and performing the merge operation if necessary (what: do the document update and merge operation)",
                "id": None,
                "name": "Update and merge documents",
                "order": 2,
                "actions": [
                    {
                        "description": "Analyze changes in the document to identify items that need to be updated (how: Use the change analysis tool)",
                        "id": None,
                        "name": "Analysis of document changes",
                        "order": 1,
                        "tools": [
                            {
                                "description": "Identifies Excel rows that need updating according to document changes.",
                                "id": 231,
                                "name": "diff_based_selector",
                                "type": "mcp",
                            }
                        ],
                    },
                    {
                        "description": "Update Excel data based on identified changes (how: reflect changes using the update tool)",
                        "id": None,
                        "name": "Update Excel data",
                        "order": 2,
                        "tools": [
                            {
                                "description": "Updates the content to reflect the differences between documents in the identified Excel row.",
                                "id": 230,
                                "name": "excel_updater",
                                "type": "mcp",
                            }
                        ],
                    },
                    {
                        "description": "If necessary, merge two documents into one document (how: use the merge tool)",
                        "id": None,
                        "name": "Merge documents",
                        "order": 3,
                        "tools": [
                            {
                                "description": "Merge two HTML documents and organize them into one document.",
                                "id": 188,
                                "name": "merge_htmls",
                                "type": "mcp",
                            }
                        ],
                    },
                ],
            },
            {
                "description": "Procedure to increase usability by converting documents to various formats (what: converting documents to Markdown format)",
                "id": None,
                "name": "Convert document format",
                "order": 3,
                "actions": [
                    {
                        "description": "Save documents by converting them to Markdown format (how to: use the conversion tool)",
                        "id": None,
                        "name": "Convert to Markdown format",
                        "order": 1,
                        "tools": [
                            {
                                "description": "Converts the document to Markdown format.",
                                "id": 244,
                                "name": "convert_markdown",
                                "type": "mcp",
                            }
                        ],
                    }
                ],
            },
            {
                "description": "Proceeding and sending emergency messages based on business standard documents (what: generating and sending emergency response messages)",
                "id": None,
                "name": "Create and send emergency messages",
                "order": 4,
                "actions": [
                    {
                        "description": "Generate personalized emergency response messages based on work standard documents (how: use message creation tools)",
                        "id": None,
                        "name": "Create an emergency message",
                        "order": 1,
                        "tools": [
                            {
                                "description": "Create personalized emergency response messages based on work standard documents.",
                                "id": 194,
                                "name": "get_emergency_msg",
                                "type": "mcp",
                            }
                        ],
                    },
                    {
                        "description": "Send generated emergency messages via Slack (how to: use the message sending tool)",
                        "id": None,
                        "name": "Send emergency message",
                        "order": 2,
                        "tools": [
                            {
                                "description": "Sends generated emergency messages through Slack.",
                                "id": 195,
                                "name": "send_emergency_msg",
                                "type": "mcp",
                            }
                        ],
                    },
                ],
            },
            {
                "description": "Compare the differences between documents and generate reports based on them (what: document comparison and report generation)",
                "id": None,
                "name": "Compare documents and generate reports",
                "order": 5,
                "actions": [
                    {
                        "description": "Analyze differences by comparing two HTML documents (how: use a comparison tool)",
                        "id": None,
                        "name": "Compare documents",
                        "order": 1,
                        "tools": [
                            {
                                "description": "We compare two HTML documents to analyze the differences.",
                                "id": 187,
                                "name": "compare_htmls",
                                "type": "mcp",
                            }
                        ],
                    },
                    {
                        "description": "Generate a report based on document comparison results (how: use the report generation tool)",
                        "id": None,
                        "name": "Create report",
                        "order": 2,
                        "tools": [
                            {
                                "description": "Create a relevant report based on web search results.",
                                "id": 237,
                                "name": "websearch_to_report",
                                "type": "mcp",
                            }
                        ],
                    },
                    {
                        "description": "Create a presentation based on the generated report (how: use the presentation creation tool)",
                        "id": None,
                        "name": "Generate presentation",
                        "order": 3,
                        "tools": [
                            {
                                "description": "Create a presentation based on the content of the report entered.",
                                "id": 238,
                                "name": "report_to_presentation",
                                "type": "mcp",
                            }
                        ],
                    },
                ],
            },
        ],
    )
    document_id: Optional[int] = Field(
        None, description="업로드된 문서 ID (선택사항)", example=0
    )
    general_agent_instruction: Optional[GeneralAgentInstructionRequest] = Field(
        None,
        description="General Agent인 경우 필요한 instruction 정보",
        example={
            "instruction": "",
            "tool_ids": [],
        },
    )
    chat_starters: Optional[List[str]] = Field(
        None,
        description="챗봇 시작 메시지 정보",
        example=["안녕하세요! 무엇을 도와드릴까요1?", "안녕하세요! 무엇을 도와드릴까요2?"]

    )


class UpdateAgentRequest(BaseModel):
    agent: UpdateAgentPayload = Field(
        ...,
        description="업데이트할 에이전트 데이터 (ID 필드 없음)",
        example={
            "name": "Engr. 업무 지원 Agent",
            "description": "RFQ/TBE sheet 자동 작성 및 기술검증",
            "category": "Engineering",
            "usage_scope": "public",
            "org_id": 0,
            "team_id": 0,
            "created_user_id": 11345,
            "administer_id": 1,
            "agent_type": "general",
            "review_status": "pending",
            "reject_description": "주요 기능이 명확히 기재되지 않았습니다.",
            "steps": [
                {
                    "name": "의도분석",
                    "description": "사용자 요청의 의도를 파악합니다",
                    "order": 1,
                    "actions": [
                        {
                            "name": "문서분석",
                            "description": "업무 절차서를 통해 업무의 핵심요소 파악",
                            "order": 1,
                            "tools": [
                                {
                                    "name": "File Uploader",
                                    "description": "File Uploader 도구입니다",
                                    "type": "utility",
                                }
                            ],
                        },
                        {
                            "name": "데이터 추출",
                            "description": "문서내 데이터 추출 및 분석",
                            "order": 2,
                            "tools": [],
                        },
                    ],
                },
                {
                    "name": "최근 문서 검색",
                    "description": "관련 최신 문서를 검색합니다",
                    "order": 2,
                    "actions": [
                        {
                            "name": "최근 문서 검색 기본 액션",
                            "description": "최근 문서 검색 단계의 기본 액션입니다",
                            "order": 1,
                            "tools": [],
                        }
                    ],
                },
                {
                    "name": "RFQ 초안 작성",
                    "description": "요청에 맞는 RFQ 초안을 작성합니다",
                    "order": 3,
                    "actions": [
                        {
                            "name": "RFQ 초안 작성 기본 액션",
                            "description": "RFQ 초안 작성 단계의 기본 액션입니다",
                            "order": 1,
                            "tools": [],
                        }
                    ],
                },
                {
                    "name": "검증",
                    "description": "작성된 문서를 검토하고 검증합니다",
                    "order": 4,
                    "actions": [
                        {
                            "name": "검증목적",
                            "description": "검증 진행 목적 설명",
                            "order": 1,
                            "tools": [],
                        },
                        {
                            "name": "검증 단계별 중점항목 확인",
                            "description": "주요 검증 항목",
                            "order": 2,
                            "tools": [],
                        },
                        {
                            "name": "검증 결과 및 검증 결과 출력",
                            "description": "검증 결과 요약",
                            "order": 3,
                            "tools": [
                                {
                                    "name": "Canvas",
                                    "description": "Canvas 도구입니다",
                                    "type": "utility",
                                }
                            ],
                        },
                        {
                            "name": "RFQ 수정이 필요한 경우 수정 검사 분석",
                            "description": "수정사항 검토",
                            "order": 4,
                            "tools": [],
                        },
                    ],
                },
            ],
        },
    )
    general_agent_instruction: Optional[GeneralAgentInstructionRequest] = Field(
        None,
        description="General Agent인 경우 필요한 instruction 정보",
        example={
            "instruction": "이 에이전트는 RFQ/TBE sheet를 자동으로 작성하고 기술 검증을 수행합니다.",
            "tool_ids": [194],
        },
    )
    chat_starters : Optional[List[UpdateChatStarterRequest]] = Field(
        None,
        description="챗봇 시작 메시지 정보",
        example=[
            {
                "id": 1,
                "starter": "안녕하세요! 무엇을 도와드릴까요1?",
            },
            {
                "id": 2,
                "starter": "안녕하세요! 무엇을 도와드릴까요2?",
            }
        ]
    )


class UploadDocumentRequest(BaseModel):
    expert_agent_id: int = Field(..., description="연결할 에이전트 ID")
    original_filename: str = Field(..., description="원본 파일명")
    file_type: str = Field(..., description="파일 타입 (MIME)")
    uploaded_user_id: int = Field(..., description="업로드한 사용자 ID")


class UpdateDocumentStatusRequest(BaseModel):
    status: str = Field(..., description="새 상태값 (active/deleted)")


class UpdateActionRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    tool_id: int


class AdminAgentListRequest(BaseModel):
    skip: int = Field(0, ge=0)
    limit: int = Field(100, ge=1, le=100)
    agent_type: Optional[str] = None
    date_type: Optional[str] = Field(None, enum=["registered_at", "reviewed_at"])
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    review_status: Optional[str] = None
    search: Optional[str] = None  # 검색어 (신청자/에이전트 명)
    order: Optional[str] = None  # 정렬 기준


class AdminDeployedAgentListRequest(BaseModel):
    skip: int = 0
    limit: int = 100
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    usage_scope: Optional[str] = None
    is_active: Optional[str] = None
    agent_type: Optional[str] = None
    name: Optional[str] = None
    order: Optional[str] = None


class CreateAgentHistoryRequest(BaseModel):
    modified_user_id: Optional[int] = Field(..., description="수정한 사용자 ID")
    description: Optional[str] = Field(..., description="수정 이력 설명")

