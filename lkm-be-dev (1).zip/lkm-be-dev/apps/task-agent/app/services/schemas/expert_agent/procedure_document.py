from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class ProcedureDocumentBase(BaseModel):
    expert_agent_id: Optional[int] = Field(..., description="연결된 에이전트 ID")
    original_filename: str = Field(..., description="원본 파일명")
    file_type: str = Field(..., description="파일 타입")


class ProcedureDocumentCreate(ProcedureDocumentBase):
    uploaded_user_id: int = Field(..., description="업로드한 사용자 ID")
    filename: str = Field(..., description="UUID로 생성된 파일명")


class ProcedureDocumentUpdate(BaseModel):
    expert_agent_id: Optional[int] = None
    original_filename: Optional[str] = None
    file_type: Optional[str] = None
    status: Optional[str] = None


class ProcedureDocumentSchema(ProcedureDocumentBase):
    id: Optional[int] = None
    uploaded_user_id: int
    filename: str
    status: str = "active"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ProcedureDocumentResponse(BaseModel):
    document: ProcedureDocumentSchema
    file_path: str = Field(..., description="파일 시스템 경로")
