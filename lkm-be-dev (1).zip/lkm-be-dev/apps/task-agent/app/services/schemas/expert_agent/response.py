from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from services.schemas.expert_agent.agent_model import (
    ActionSchema,
    ActionWithTools,
    ExpertAgentDetail,
    ExpertAgentSchema,
    StepBase,
    StepSchema,
    StepWithActions,
    ToolDetail,
    ToolGroupDetail,
    ToolSchema,
)
from services.schemas.expert_agent.procedure_document import ProcedureDocumentSchema


class ApiResponse(BaseModel):
    success: bool = True
    message: Optional[str] = None


class AgentHistory(BaseModel):
    expert_agent_id: int = Field(..., description="에이전트 ID")
    modified_user_id: Optional[int] = Field(..., description="수정한 사용자 ID")
    modified_user_name: Optional[str] = Field(..., description="수정한 사용자 이름")
    description: Optional[str] = Field(..., description="수정 이력 설명")
    created_at: Optional[datetime] = Field(..., description="생성 시간")
    updated_at: Optional[datetime] = Field(..., description="수정 시간")


class AgentListResponse(ApiResponse):
    agents: List[ExpertAgentSchema] = Field([], description="에이전트 목록")
    total: int = Field(..., description="전체 에이전트 수")
    skip: int = Field(..., description="건너뛴 레코드 수")
    limit: int = Field(..., description="조회된 레코드 수")
    name: Optional[str] = Field(None, description="에이전트 이름")
    category: Optional[str] = Field(None, description="카테고리")
    usage_scope: Optional[str] = Field(
        None,
        description="공개 범위 (public, org, personal)",
    )
    review_status: Optional[str] = Field(
        None,
        description="에이전트 검토 상태 (pending, saved, testing, submitted, deployed, rejected)",
    )
    reject_description: Optional[str] = Field(
        None, description="에이전트 등록 요청 반려 사유"
    )
    agent_type: Optional[str] = Field(None, description="에이전트 타입 (pro, general)")


class AgentDetailResponse(ApiResponse):
    agent: ExpertAgentDetail = Field(..., description="에이전트 상세 정보")


class AgentSimpleDetailResponse(ApiResponse):
    agent: ExpertAgentSchema = Field(
        ..., description="에이전트 기본 정보 (step 정보 제외)"
    )


class DocumentUploadResponse(ApiResponse):
    document: ProcedureDocumentSchema = Field(..., description="업로드된 문서 정보")
    file_path: str = Field(..., description="업로드된 파일 경로")
    original_filename: str = Field(..., description="원본 파일명")
    file_size: int = Field(..., description="파일 크기")


class StepListResponse(ApiResponse):
    steps: List[StepSchema] = Field([], description="스텝 목록")
    agent_id: int = Field(..., description="에이전트 ID")


class StepWithActionsResponse(ApiResponse):
    steps: List[StepWithActions] = Field([], description="스텝 목록")


class ActionListResponse(ApiResponse):
    actions: List[ActionSchema] = Field([], description="액션 목록")
    step_id: int = Field(..., description="스텝 ID")


class ActionWithToolsResponse(ApiResponse):
    actions: List[ActionWithTools] = Field([], description="모든 액션 목록")


class ToolListResponse(ApiResponse):
    tools: List[ToolSchema] = Field([], description="툴 목록")


class StepRecommendationResponse(ApiResponse):
    document_id: Optional[int] = None
    steps: List[StepBase] = []


class StepActionRecommendationResponse(ApiResponse):
    steps: List[StepWithActions] = Field([], description="추천된 Step과 Action 목록")

    class Config:
        exclude_none = True


class UseCountResponse(ApiResponse):
    expert_agent_id: int = Field(..., description="에이전트 ID")
    use_count: int = Field(..., description="사용 횟수")


class ToolGroupListResponse(ApiResponse):
    tool_groups: List[ToolGroupDetail] = Field([], description="툴 그룹 목록")


class ToolDetailListResponse(ApiResponse):
    tools: List[ToolDetail] = Field([], description="툴 목록")


class AdminAgentListItem(BaseModel):
    id: int = Field(..., description="에이전트 ID")
    name: str = Field(..., description="에이전트 명")
    user_name: str = Field(..., description="신청자 이름")
    agent_type: str = Field(..., description="에이전트 타입 (pro, general)")
    review_status: Optional[str] = Field(None, description="상태 (대기/승인/반려)")
    usage_scope: Optional[str] = Field(
        None, description="공개 범위 (public, org, personal)"
    )
    is_activated: Optional[bool] = Field(None, description="활성화 여부")
    admin_name: Optional[str] = Field(None, description="관리자 이름")
    registered_at: Optional[datetime] = Field(None, description="신청일")
    reviewed_at: Optional[datetime] = Field(None, description="승인/반려일")


class AdminAgentListResponse(ApiResponse):
    agents: List[AdminAgentListItem] = Field([], description="에이전트 목록")
    total: int = Field(..., description="전체 에이전트 수")
    submitted_count: int = Field(..., description="대기 중인 에이전트 수")
    deployed_count: int = Field(..., description="승인된 에이전트 수")
    rejected_count: int = Field(..., description="반려된 에이전트 수")
    skip: int = Field(..., description="건너뛴 레코드 수")
    limit: int = Field(..., description="조회된 레코드 수")


class AdminDeployedAgentListResponse(ApiResponse):
    agents: List[AdminAgentListItem] = Field([], description="에이전트 목록")
    total: int = Field(..., description="전체 에이전트 수")
    skip: int = Field(..., description="건너뛴 레코드 수")
    limit: int = Field(..., description="조회된 레코드 수")


class GeneralAgentDetailResponse(ApiResponse):
    agent: ExpertAgentDetail
    instruction: Optional[str] = None
    tools: Optional[List[ToolSchema]] = None


class ChatStarterResponse(ApiResponse):
    starter: List[str] = Field(..., description="챗봇 시작 메시지")


class AgentHistoryResponse(ApiResponse):
    agent_history: List[AgentHistory] = Field([], description="에이전트 수정 이력")
    skip: Optional[int] = None
    limit: Optional[int] = None


class AgentActivationResponse(ApiResponse):
    agent_id: int = Field(..., description="에이전트 ID")
    is_activated: bool = Field(..., description="활성화 여부")
