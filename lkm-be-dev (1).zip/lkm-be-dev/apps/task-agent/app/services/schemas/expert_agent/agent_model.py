from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel


# Tool 모델
class ToolBase(BaseModel):
    name: str
    description: Optional[str] = None
    type: Optional[str] = None
    icon_path: Optional[str] = None
    config: Optional[Dict[str, Any]] = None


class ToolSchema(ToolBase):
    id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    tool_group_id: Optional[int] = None
    tool_group_name: Optional[str] = None

    class Config:
        from_attributes = True


# Action 모델
class ActionBase(BaseModel):
    name: str
    description: Optional[str] = None
    order: int


class ActionCreate(ActionBase):
    step_id: int


class ActionSchema(ActionBase):
    id: Optional[int] = None
    step_id: Optional[int] = None

    class Config:
        from_attributes = True


# Action-Tool 관계
class ActionToolRelationshipBase(BaseModel):
    action_id: int
    tool_id: int


class ActionToolRelationshipSchema(ActionToolRelationshipBase):
    id: Optional[int] = None

    class Config:
        from_attributes = True


# Step 모델
class StepBase(BaseModel):
    name: str
    description: Optional[str] = None
    order: int


class StepCreate(StepBase):
    expert_agent_id: int


class StepSchema(StepBase):
    id: Optional[int] = None
    expert_agent_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# Action with Tool 상세 정보를 포함한 모델
class ActionWithTools(ActionSchema):
    tools: List[ToolSchema] = []


# Step with Actions 상세 정보를 포함한 모델
class StepWithActions(StepSchema):
    actions: List[ActionWithTools] = []


# Expert Agent 모델
class ExpertAgentBase(BaseModel):
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    usage_scope: str = "public"
    org_id: Optional[int] = None
    team_id: Optional[int] = None
    use_count: Optional[int] = 0
    review_status: Optional[str] = "pending"
    reject_description: Optional[str] = None
    agent_type: str = "general"
    administer_id: Optional[int] = None


class ExpertAgentCreate(ExpertAgentBase):
    created_user_id: int


class ExpertAgentSchema(ExpertAgentBase):
    id: Optional[int] = None
    created_user_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# 상세 정보를 포함한 Expert Agent 모델
class ExpertAgentDetail(ExpertAgentSchema):
    steps: List[StepWithActions] = []


class StepForUpdate(BaseModel):
    name: str
    description: Optional[str] = None
    order: int
    actions: List["ActionForUpdate"] = []


class ActionForUpdate(BaseModel):
    name: str
    description: Optional[str] = None
    order: int
    tools: List["ToolForUpdate"] = []


class ToolForUpdate(BaseModel):
    name: str
    description: Optional[str] = None
    type: str
    icon_path: Optional[str] = None
    config: Optional[Dict[str, Any]] = None


class ToolGroupForUpdate(BaseModel):
    id: int
    name: Optional[str] = None
    description: Optional[str] = None
    is_visible: Optional[bool] = True


class UpdateAgentPayload(BaseModel):
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    usage_scope: str = "public"
    org_id: Optional[int] = None
    team_id: Optional[int] = None
    created_user_id: int
    administer_id: Optional[int] = None
    steps: List[StepForUpdate] = []
    agent_type: str
    review_status: str
    reject_description: Optional[str] = None


class ToolDetail(BaseModel):
    id: int
    name: Optional[str] = None
    description: Optional[str] = None
    type: Optional[str] = None
    icon_path: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    endpoint: Optional[str] = None
    tool_group_id: Optional[int] = None
    tool_group_name: Optional[str] = None
    is_visible: Optional[bool] = True


class ToolGroupDetail(BaseModel):
    id: Optional[int] = None
    name: str
    description: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    is_visible: Optional[bool] = True


class UpdateToolGroupRelationship(BaseModel):
    tool_group_id: int
    tool_id: int
