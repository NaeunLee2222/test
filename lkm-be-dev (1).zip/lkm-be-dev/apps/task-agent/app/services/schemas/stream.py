from dataclasses import dataclass, field
from typing import Optional


@dataclass
class StreamMessage:
    type: str
    content: str
    state: Optional[dict] = field(default_factory=dict)
    description: Optional[str] = field(default="")
    key: Optional[str] = field(default="")
    title: Optional[str] = field(default="")
