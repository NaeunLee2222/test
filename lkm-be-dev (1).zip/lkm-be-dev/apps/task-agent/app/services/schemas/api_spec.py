from datetime import datetime
from enum import Enum
from typing import Dict, Optional

from pydantic import BaseModel


# HTTP Method Enum 정의
class HTTPMethod(str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"


# 공통 필드를 포함한 ApiSpecBase 정의
class ApiSpecBase(BaseModel):
    name: Optional[str] = None
    endpoint: Optional[str] = None
    description: Optional[str] = None
    method: Optional[HTTPMethod] = None
    params: Optional[Dict] = None
    body: Optional[Dict] = None
    headers: Optional[Dict] = None
    response_format: Optional[Dict] = None
    rate_limit: Optional[int] = None
    service_category: Optional[str] = None
    is_tool_enabled: Optional[bool] = None


# ApiSpec 생성 요청 스키마
class ApiSpecCreate(ApiSpecBase):
    name: str
    endpoint: str
    method: HTTPMethod
    service_category: str
    is_tool_enabled: bool


# ApiSpec 읽기 스키마
class ApiSpecRead(ApiSpecBase):
    id: int
    name: str
    is_tool_enabled: bool
    endpoint: str
    method: HTTPMethod
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# ApiSpec 업데이트 스키마
class ApiSpecUpdate(ApiSpecBase):
    pass  # ApiSpecBase의 모든 필드를 Optional로 상속받음
