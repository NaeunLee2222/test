from typing import List, Optional

from pydantic import BaseModel


class ModelPermission(BaseModel):
    id: str
    object: str = "model_permission"
    created: int
    allow_create_engine: bool = False
    allow_sampling: bool = True
    allow_logprobs: bool = True
    allow_search_indices: bool = False
    allow_view: bool = True
    allow_fine_tuning: bool = False
    organization: str = "*"
    group: Optional[None] = None
    is_blocking: bool = False


class ModelData(BaseModel):
    id: str
    object: str = "model"
    created: int
    owned_by: str = "custom-agent"
    permission: List[ModelPermission]
    root: str
    parent: Optional[None] = None


class ModelsResponse(BaseModel):
    object: str = "list"
    data: List[ModelData]


class ChatWithWebResponse(BaseModel):
    id: str
    object: str
    created: int
    model: str
    choices: list
    usage: Optional[dict] = None


class OpenAIResponse(BaseModel):
    id: str
    object: str
    created: int
    model: str
    choices: list
    usage: Optional[dict] = None
