from typing import List, Optional

from pydantic import BaseModel

from services.schemas.user.user_info import UserInfo


class ChatInput(BaseModel):
    model: str
    messages: list
    max_tokens: Optional[int] = None
    stop: Optional[List[str]] = None
    stream: bool = False


class ChatWithWebInput(BaseModel):
    model: str
    messages: list
    max_tokens: Optional[int] = None
    stop: Optional[List[str]] = None
    stream: bool = False


class SupervisorRequestBody(BaseModel):
    input_data: Optional[list] = None
    stream: bool = False
    state: Optional[dict] = None
    user_info: Optional[UserInfo] = None
    chat_id: Optional[str] = None
    task_agent_id: Optional[int] = None
    expert_agent_id: Optional[int] = None
    canvas: Optional[str] = None


class OpenAIRequest(BaseModel):
    model: str
    messages: list
    max_tokens: Optional[int] = None
    temperature: float = 0.1
    stop: Optional[List[str]] = None
    n: int = 1
    stream: bool = False
