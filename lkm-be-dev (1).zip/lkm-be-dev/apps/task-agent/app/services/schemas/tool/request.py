from datetime import datetime
from typing import Any, Dict, Optional
from pydantic import BaseModel


class MCPToolAddRequest(BaseModel):
    url: str
    transport: str
    is_visible: Optional[bool] = None
    tool_group_name: Optional[str] = None


class MCPToolAddDirectRequest(MCPToolAddRequest):
    tool_name: str


class ToolGroupAddRequest(BaseModel):
    name: str
    description: Optional[str] = None
    is_visible: Optional[bool] = None


class ToolDetailUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    type: Optional[str] = None
    icon_path: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    endpoint: Optional[str] = None
    is_visible: Optional[bool] = None


class ToolAddRequest(BaseModel):
    name: str
    description: Optional[str] = None
    type: Optional[str] = None
    icon_path: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    endpoint: Optional[str] = None
    is_visible: Optional[bool] = None
    tool_group_id: Optional[int] = None
