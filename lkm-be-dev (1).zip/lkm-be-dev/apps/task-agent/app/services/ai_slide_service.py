import asyncio
import json
from typing import Optional

import pandas as pd

from core.config import get_setting
from core.log.logging import get_logging
from services.tools.ai_slide_tool import Report2PPTStreamingTool
from services.tools.statistic_tool import StatisticTool
from services.tools.websearch_tool import WebSearchTool

settings = get_setting()
logger = get_logging()


async def print_event(**kwargs) -> str:
    event = {
        **kwargs,
    }
    await asyncio.sleep(2)
    print(event)

    return f"event: data\ndata: {json.dumps(event, ensure_ascii=False)}\n\n"


class AiSlideService:
    def __init__(self):
        self.ai_slide_tool = Report2PPTStreamingTool()
        self.web_search_tool = WebSearchTool()
        self.statistic_tool = StatisticTool()
        self.primary_color = "#1e40af"
        self.accent_color = "#f59e0b"

    async def slide_completions_stream(
        self,
        query: str,
        chat_id: str,
        data: Optional[pd.DataFrame] = None,
        **kwargs,
    ):

        try:
            yield "event: start\n\n"

            t1 = await print_event(
                type="id",
                content="-1",
                description="",
                key="",
                id=chat_id,
            )
            yield t1

            yield await print_event(
                type="START",
                content="프레젠테이션 생성을 시작합니다.",
                description="보고서 작성, 자료 분석, 프레젠테이션 생성을 준비합니다.",
                key="start",
                id=chat_id,
            )
            yield await print_event(
                type="PLAN_START",
                content="보고서 작성을 시작합니다.",
                description="보고서 작성 에이전트 호출",
                key="plan_start",
                id=chat_id,
            )
            yield await print_event(
                type="STEP_START",
                content="웹 검색을 시작합니다.",
                description="BING SEARCH ...",
                key="step_start",
                id=chat_id,
            )
            yield await print_event(
                type="ACTION_START",
                content="보고서 작성을 시작합니다.",
                description="내용 분석 및 자료 정리 진행",
                key="action_start",
                id=chat_id,
            )

            websearch_result = await self.web_search_tool._arun(query)
            report = websearch_result["report"]
            agenda_items = websearch_result["agenda_items"]
            yield await print_event(
                type="ACTION_SUCCESS",
                content="보고서 작성을 완료했습니다.",
                description="보고서 작성 에이전트를 종료합니다.",
                key="action_success",
                id=chat_id,
            )

            yield await print_event(
                type="STEP_END",
                content="보고서 작성을 완료했습니다.",
                description="",
                key="step_end",
                id=chat_id,
            )
            yield await print_event(
                type="PLAN_END",
                content="보고서 작성을 완료했습니다.",
                description="보고서 작성을 완료했습니다.",
                key="plan_end",
                id=chat_id,
            )
            if data is not None:

                async for chunk in self.statistic_tool.get_statistic(
                    query=query,
                    report=report,
                    agenda_items=agenda_items,
                    data=data,
                    chat_id=chat_id,
                ):
                    yield chunk

                research_result = self.statistic_tool.contents
            else:
                research_result = ""

            yield await print_event(
                type="PLAN_START",
                content="슬라이드 생성을 시작합니다.",
                description="슬라이드 생성을 시작합니다.",
                key="plan_start",
                id=chat_id,
            )

            yield await print_event(
                type="STEP_START",
                content="프레젠테이션 생성을 시작합니다.",
                description="프레젠테이션 생성을 시작합니다.",
                key="step_start",
                id=chat_id,
            )
            yield await print_event(
                type="ACTION_START",
                content="프레젠테이션 생성을 시작합니다.",
                description="프레젠테이션 생성을 시작합니다.",
                key="action_start",
                id=chat_id,
            )
            yield await print_event(
                type="ACTION_SUCCESS",
                content="프레젠테이션 생성을 완료했습니다.",
                description="프레젠테이션 생성을 완료했습니다.",
                key="action_success",
                id=chat_id,
            )

            yield await print_event(
                type="STEP_END",
                content="프레젠테이션 생성을 완료했습니다.",
                description="프레젠테이션 생성을 완료했습니다.",
                key="step_end",
                id=chat_id,
            )
            yield await print_event(
                type="PLAN_END",
                content="보고서 작성을 완료했습니다.",
                description="보고서 작성을 완료했습니다.",
                key="plan_end",
                id=chat_id,
            )

            async for chunk in self.ai_slide_tool.stream_slides(
                query,
                report,
                agenda_items,
                self.primary_color,
                self.accent_color,
                research_result,
                chat_id=chat_id,
                **kwargs,
            ):
                yield chunk

            yield await print_event(
                type="END",
                content="프레젠테이션 생성을 완료했습니다.",
                description="프레젠테이션 생성을 완료했습니다.",
                key="end",
                id=chat_id,
            )
            yield "event: end\n\n"

        except Exception as e:
            logger.error(f"슬라이드 생성 중 오류 발생: {e}")
            raise e
