import asyncio
import json
import time
from typing import Any, AsyncGenerator, Dict, List, Tuple, Optional
from core.errors.exceptions import ErrorCode, ServiceException

from fastapi.responses import StreamingResponse
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langgraph.graph import Graph
from sqlalchemy.ext.asyncio import AsyncSession

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.parsing import get_first_and_last_10
from core.utils.state import make_stream_message
from core.utils.time import get_kor_nowtime
from services.agent.state import State
from services.prompt.models.chat import UserChatPrompt
from services.schemas.chat.request import OpenAIRequest
from services.schemas.stream import StreamMessage
from services.schemas.user.user_info import UserInfo
from services.user_service import UserService

settings = get_setting()
logger = get_logging()


class ChatService:
    def __init__(self):
        self.models_available = [
            {
                "id": "gpt-4o",
                "object": "model",
                "created": 1234567890,
                "owned_by": "organization",
                "permission": [{"role": "all"}],
            }
        ]
        self.user_service = UserService()
        self.SPECIAL_REQUEST = ("Create a concise,", "### Task:")

    @staticmethod
    def get_available_models() -> List[Dict[str, Any]]:
        return ChatService().models_available

    def convert_openai_messages_to_langchain(
        self, messages: List[dict]
    ) -> List[BaseMessage]:
        """OpenAI 형식의 메시지를 Langchain 형식으로 변환"""
        converted_messages = []
        for msg in messages:
            if msg["role"] == "user":
                converted_messages.append(HumanMessage(content=msg["content"]))
            elif msg["role"] == "assistant":
                last_agent_response = msg["content"].split("**:")[-1]
                converted_messages.append(AIMessage(content=last_agent_response))
            elif msg["role"] == "system":
                converted_messages.append(SystemMessage(content=msg["content"]))
        return converted_messages

    async def supervisor_chat_completions_stream(
        self, input_data: list, state: State, user_info: UserInfo, graph: Any
    ) -> AsyncGenerator[str, None]:
        """최적화된 스트리밍 채팅 완료 처리 - 단일 데이터베이스 호출로 사용자 정보 조회"""
        try:
            # 단일 데이터베이스 호출로 사용자 정보 조회
            detailed_user_info = await self.user_service.get_user_details(user_info)

            # 기본값 설정으로 None 체크 방지
            history_info = None
            preferred_info = (user_info.profile or "").strip("{}")

            # 프롬프트 생성
            prompt = await self._create_user_chat_prompt(
                detailed_user_info, history_info, preferred_info
            )

            # 메시지 처리
            messages = input_data
            messages.insert(
                0, {"role": "system", "content": prompt.make_system_prompt()}
            )
            messages = self.convert_openai_messages_to_langchain(messages)

            messages_list = [(msg.type, msg.content) for msg in messages[:-1]]

            # 상태 초기화
            init_state = await self._initialize_supervisor_state(
                messages, messages_list
            )
            init_state.update(state)
            state = init_state

            # 스트리밍 처리
            async for s in graph.astream(state):
                if "__end__" in s:
                    continue

                stream_message: Optional[StreamMessage] = make_stream_message(s)
                if not stream_message or stream_message == {}:
                    continue

                if isinstance(stream_message, list):
                    for msg in stream_message:
                        if msg:
                            yield f"{json.dumps(msg.__dict__)}\n\n"
                            await asyncio.sleep(0)
                else:
                    yield f"{json.dumps(stream_message.__dict__)}\n\n"
                    await asyncio.sleep(0)

        except Exception as e:
            logger.error(f"Streaming chat completion error: {e}")
            error_message = {"error": "Streaming processing failed", "detail": str(e)}
            yield f"{json.dumps(error_message)}\n\n"

    async def supervisor_chat_completions(
        self, input_data: list, state: State, user_info: UserInfo, graph: Any
    ) -> List:
        """최적화된 채팅 완료 처리 - 단일 데이터베이스 호출로 사용자 정보 조회"""
        try:
            # 단일 데이터베이스 호출로 사용자 정보 조회
            detailed_user_info = await self.user_service.get_user_details(user_info)

            # 기본값 설정으로 None 체크 방지
            history_info = ""
            preferred_info = (user_info.profile or "").strip("{}")

            # 프롬프트 생성
            prompt = await self._create_user_chat_prompt(
                detailed_user_info, history_info, preferred_info
            )

            # 메시지 처리
            messages = input_data
            messages.insert(
                0, {"role": "system", "content": prompt.make_system_prompt()}
            )
            messages = self.convert_openai_messages_to_langchain(messages)

            messages_list = [(msg.type, msg.content) for msg in messages[:-1]]

            # 상태 초기화
            init_state = await self._initialize_supervisor_state(
                messages, messages_list
            )
            init_state.update(state)
            state = init_state

            # 응답 생성
            responses = []
            for s in graph.stream(state):
                if "__end__" not in s:
                    responses.append(s)
            return responses

        except Exception as e:
            logger.error(f"Chat completion error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get user details, {str(e)}",
            )

    async def _create_user_chat_prompt(
        self, user_info: dict, history_info: str, preferred_info: str
    ) -> UserChatPrompt:
        return UserChatPrompt(
            nowtime=get_kor_nowtime(),
            name=user_info.username,
            id=user_info.user_id,
            email=user_info.email,
            office=user_info.officeName,
            office_id=user_info.officeId,
            floor=user_info.floorName,
            floor_id=user_info.floorId,
            history_info=history_info,
            preferred_info=preferred_info,
            calendar_id=user_info.calendarId,
        )

    async def _initialize_supervisor_state(
        self,
        messages: List[BaseMessage],
        messages_list: List[Tuple],
    ) -> Dict:
        from core.utils.parsing import get_first_and_last_10

        return {
            "messages": [],
            "next": "planner",
            "plan": [],
            "messages_list": get_first_and_last_10(messages_list),
            "user_query": messages[-1].content,
            "now_order": 0,
            "function_response": [],
            "view_messages": [],
            "is_reply": False,
            "tool_calling_history": [],
        }

    async def chat_completions(
        self, request: OpenAIRequest, id: str, graph: Any
    ) -> Dict:
        """
        채팅 완료 처리

        Args:
            request (OpenAIRequest): 채팅 요청
            id (str): 채팅 ID
            graph: 그래프 객체

        Returns:
            Dict: 응답 데이터
        """
        try:
            # 사용자 정보 가져오기
            detailed_user_info = await self.user_service.get_user_details({})
            history_info, preferred_info = (
                await self.user_service.get_user_meeting_info(
                    detailed_user_info.user_id,
                    detailed_user_info.username,
                )
            )

            # 프롬프트 생성
            prompt = await self._create_user_chat_prompt(
                detailed_user_info, history_info, preferred_info
            )

            # 메시지 처리
            messages = request.messages
            messages.insert(
                0, {"role": "system", "content": prompt.make_system_prompt()}
            )
            messages = self.convert_openai_messages_to_langchain(messages)

            # 특수 요청 처리
            if request.messages[-1]["content"].startswith(self.SPECIAL_REQUEST):
                return self._create_special_response(request.model)

            # 메시지 리스트 생성
            messages_list = [(msg.type, msg.content) for msg in messages[:-1]]

            # 상태 초기화 및 처리
            state = await self._initialize_chat_state(
                messages_list, messages[-1].content, id
            )

            # 스트림 처리
            if request.stream and len(messages_list) > 1:
                return StreamingResponse(
                    self._generate_stream_responses(messages, graph),
                    media_type="text/event-stream",
                )

            # 응답 생성
            responses = await self._generate_responses(state, graph)

            # 응답 포맷팅
            response_content = self._format_view_messages(responses)

            return self._create_response_data(
                response_content, request.model, len(responses)
            )

        except Exception as e:
            logger.error(f"Chat completions error: {e}")
            return self._create_error_response(request.model, str(e))

    def _create_special_response(self, model: str) -> Dict:
        """특수 요청에 대한 응답 생성"""
        return {
            "id": f"chatcmpl-{int(time.time())}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "test",
                    },
                    "logprobs": None,
                    "finish_reason": "stop",
                    "index": 0,
                }
            ],
            "usage": {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
            },
        }

    async def _initialize_chat_state(
        self, messages_list: List, user_query: str, chat_id: str
    ) -> Dict:
        """채팅 상태 초기화"""
        state = {
            "messages": [],
            "next": "planner",
            "plan": [],
            "messages_list": get_first_and_last_10(messages_list),
            "user_query": user_query,
            "now_order": 0,
            "function_response": [],
            "view_messages": [],
            "is_reply": False,
            "chat_id": chat_id,
            "tool_calling_history": [],
        }
        return state

    async def _generate_responses(self, state: Dict, graph: Any) -> List:
        """응답 생성 - 안전한 처리"""
        try:
            responses = []
            async for s in graph.astream(state):
                if "__end__" not in s:
                    responses.append(s)
            return responses
        except Exception as e:
            logger.error(f"Response generation error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to generate responses, {str(e)}",
            )

    def _format_view_messages(self, responses: List) -> str:
        """뷰 메시지 포맷팅"""
        try:
            response_content = ""
            view_messages = list(responses[0].values())[0]["view_messages"]
            for dic in view_messages:
                response_content += (
                    f"**{list(dic.keys())[0]}**:\n{list(dic.values())[0]}\n\n"
                )
            return response_content
        except Exception as e:
            logger.error(f"View message formatting error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to format view messages, {str(e)}",
            )

    def _create_response_data(
        self, content: str, model: str, response_length: int
    ) -> Dict:
        """응답 데이터 생성"""
        return {
            "id": f"chatcmpl-{int(time.time())}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": content,
                    },
                    "logprobs": None,
                    "finish_reason": "stop",
                    "index": 0,
                }
            ],
            "usage": {
                "prompt_tokens": 0,
                "completion_tokens": response_length,
                "total_tokens": response_length,
            },
        }

    async def generate_stream_response(
        self, request: OpenAIRequest, id: str
    ) -> AsyncGenerator[str, None]:
        """스트림 응답 생성 - 안전한 처리"""
        try:
            state = self._initialize_state(request.messages)
            for s in self.graph.stream(state):
                if "__end__" in s:
                    continue

                stream_message = make_stream_message(s)
                if not stream_message:
                    continue

                if isinstance(stream_message, list):
                    for msg in stream_message:
                        if msg:
                            yield f"{json.dumps(msg.__dict__)}\n\n"
                else:
                    yield f"{json.dumps(stream_message.__dict__)}\n\n"
        except Exception as e:
            logger.error(f"Stream response generation error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to generate stream response, {str(e)}",
            )

    async def generate_chat_response(self, request: OpenAIRequest, id: str) -> Dict:
        """
        일반 채팅 응답 생성 로직

        Args:
            request (OpenAIRequest): 요청
            id (str): 아이디

        Returns:
            dict: langgraph 응답
        """
        try:
            state = self._initialize_state(request.messages)
            responses = []

            for s in self.graph.stream(state):
                if "__end__" not in s:
                    responses.append(s)

            return self._format_response(responses, request.model)
        except Exception as e:
            logger.error(f"Chat response generation error: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to generate chat response, {str(e)}",
            )

    def _initialize_state(self, messages: List[dict]) -> dict:
        """
        state 초기화

        Args:
            messages (List[dict]): 메시지 리스트

        Returns:
            dict: 상태
        """
        # 상태 초기화 로직
        return {
            "next": "planner",
            "plan": [],
            "messages_list": self._process_messages(messages),
            "user_query": messages[-1]["content"],
            "now_order": 0,
            "function_response": [],
            "view_messages": [],
            "is_reply": False,
            "tool_calling_history": [],
        }

    def _process_messages(self, messages: List[dict]) -> List[str]:
        """메시지 처리 - 안전한 처리"""
        try:
            return [str(msg) for msg in messages]
        except Exception as e:
            logger.error(f"Message processing error: {e}")
            return []

    def _format_response(self, responses: List, model: str) -> Dict:
        """
        응답 포맷팅 로직

        Args:
            responses (List): 응답 리스트
            model (str): 모델

        Returns:
            dict: 포맷팅 된 response
        """
        return {
            "id": f"chatcmpl-{int(time.time())}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": self._format_content(responses),
                    },
                    "finish_reason": "stop",
                    "index": 0,
                }
            ],
            "usage": {
                "prompt_tokens": 0,
                "completion_tokens": len(responses),
                "total_tokens": len(responses),
            },
        }

    def _format_content(self, responses: List) -> str:
        """콘텐츠 포맷팅 - 안전한 처리"""
        try:
            if not responses:
                return "No response generated"
            return str(responses)
        except Exception as e:
            logger.error(f"Content formatting error: {e}")
            return "Error formatting content"
