import json
import re
from datetime import datetime
from typing import Any, Union

from langchain.agents import AgentExecutor
from langchain.agents.format_scratchpad.tools import format_to_tool_messages
from langchain.agents.output_parsers.openai_tools import OpenAIToolsAgentOutputParser
from langchain_core.prompts import (
    ChatPromptTemplate,
    MessagesPlaceholder,
)
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langgraph.graph import END, START, StateGraph

from core.config import get_setting
from core.llm import get_llm_config
from core.log.logging import get_logging, get_web_logging
from services.agent.base_agent import BaseAgent
from services.agent.state import State
from services.prompt.prompt_service import PromptService
from services.tools.search_tools import MyBingSearch

settings = get_setting()
logger = get_logging()
web_logger = get_web_logging()
prompt_service = PromptService()


def manage_history(state: State) -> State:
    user_basic_info = state["messages_list"][0][1].split("\n")[1:]
    if len(state["messages"]) > 0:
        history = state["messages"]

    elif (len(state["messages_list"]) >= 3) and (len(state["messages"]) == 0):
        history = state["messages_list"][1:]

    else:
        history = "No chatting history"

    return user_basic_info, history


class ChatWithWebAgent(BaseAgent):
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        super().__init__(llm)
        self.tools = [MyBingSearch(k=10)]
        self.system_prompt = prompt_service.get_prompts()["Chat_with_Web_Prompt"]

    def get_graph(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("websearch", self.run_chain)
        workflow.add_edge(START, "websearch")
        workflow.add_edge("websearch", END)
        return workflow.compile()

    def run_chain(self, state: State) -> State:
        query = state["user_query"]
        web_logger.critical(f"[Search Query]: {query}")

        _, history = manage_history(state)

        now = datetime.now()
        # 현재 날짜와 시간 포맷팅 (예: 2024-12-10 15:30:45)
        today = now.strftime("%Y-%m-%d %H:%M:%S")

        logger.info("[Bing Search] Agent started")
        history_str = json.dumps(history, ensure_ascii=False)

        history_str = history_str.replace("{", "{{").replace("}", "}}")
        # history_str = json.dumps(history, ensure_ascii=False)
        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", self.system_prompt.format(today=today, history=history_str)),
                ("human", "{input}"),
                MessagesPlaceholder(variable_name="agent_scratchpad"),
            ]
        )

        # agent = create_tool_calling_agent(self.llm, self.tools, prompt)
        pipe = (
            {
                "input": lambda x: x["input"],
                "agent_scratchpad": lambda x: format_to_tool_messages(
                    x["intermediate_steps"]
                ),
            }
            | prompt
            | self.llm.bind_tools(self.tools)
            | OpenAIToolsAgentOutputParser()
        )
        agent_executor = AgentExecutor(
            agent=pipe, tools=self.tools, verbose=True, return_intermediate_steps=True
        )

        ans = agent_executor.invoke(
            {"input": query}, config=get_llm_config(session_id=state["chat_id"])
        )

        if len(ans["intermediate_steps"]) > 0:
            search_results = ans["intermediate_steps"][0][1]
            web_logger.critical(f"[Bing Search Results]: {search_results}")

        llm_ans = ans["output"]
        web_logger.critical(f"[LLM response]: {llm_ans}")

        logger.debug(f"[Bing Search] LLM response: {llm_ans}")
        report = re.sub(r"\n+", "\n", llm_ans)
        report_for_history = re.sub(r"\n+", "\n", llm_ans.split("[URL link]")[0])

        state["view_messages"].append({"WebSearcher": report})

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        state["messages"].append(
            {
                "Query": query,
                "Used_tool": [],
                "Answer": report_for_history,
                "Datetime": now,
            }
        )

        return state
