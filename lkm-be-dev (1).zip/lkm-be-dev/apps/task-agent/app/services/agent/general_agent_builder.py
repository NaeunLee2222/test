from typing import List, Optional

from sqlalchemy.orm import Session

from core.log.logging import get_logging
from database.crud.crud_tool import CRUDToolSync
from services.agent.base_agent import BaseAgent
from services.prompt.instruction_prompt import (
    create_instruction_prompt,
    create_tool_selection_prompt,
)
from services.schemas.expert_agent.agent_model import ToolSchema

logger = get_logging()
crud_tool = CRUDToolSync()


class GeneralAgentBuilder(BaseAgent):
    def make_instruction(
        self,
        agent_name: str,
        agent_description: str,
        file_content: Optional[str] = None,
    ):
        # 프롬프트 생성
        messages = create_instruction_prompt(
            agent_name=agent_name,
            agent_description=agent_description,
            file_content=file_content,
        )

        # LLM 호출
        return self.llm.invoke(messages).content

    def recommend_tools(
        self,
        db: Session,
        agent_name: str,
        agent_description: str,
        instruction: str,
        file_content: Optional[str] = None,
    ) -> List[ToolSchema]:
        """
        에이전트의 특성과 요구사항을 기반으로 적절한 도구들을 추천합니다.

        Args:
            db: 데이터베이스 세션
            agent_name: 에이전트 이름
            agent_description: 에이전트 설명
            file_content: 관련 파일 내용
            instruction: 에이전트 지시사항

        Returns:
            List[ToolSchema]: 추천된 도구 목록
        """
        # 1. 모든 사용 가능한 도구 목록 가져오기
        available_tools = crud_tool.get_tools(db)

        # 2. LLM을 사용하여 도구 선택
        tool_selection_prompt = create_tool_selection_prompt(
            agent_name=agent_name,
            agent_description=agent_description,
            instruction=instruction,
            available_tools=available_tools,
            file_content=file_content,
        )

        selected_tools_response = self.llm.invoke(tool_selection_prompt).content
        selected_tool_names = [
            name.strip() for name in selected_tools_response.split(",")
        ]

        # 3. 선택된 도구들을 ToolSchema로 변환
        recommended_tools = []
        for tool in available_tools:
            if tool.name in selected_tool_names:
                tool_schema = ToolSchema(
                    id=tool.id,
                    name=tool.name,
                    description=tool.description,
                    type=tool.type,
                    icon_path=tool.icon_path,
                    config=tool.config,
                )
                recommended_tools.append(tool_schema)

        return recommended_tools
