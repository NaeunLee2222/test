from enum import Enum


class MessageType(Enum):
    # 계획 관련
    PLAN_START = "plan_start"
    PLAN_END = "plan_end"
    PLAN_COMPLETE = "plan_complete"

    # 단계 관련
    STEP_START = "step_start"
    STEP_COMPLETE = "step_complete"
    STEP_END = "step_end"

    # 액션 관련
    ACTION_START = "action_start"
    ACTION_SUCCESS = "action_success"
    ACTION_FAIL = "action_fail"

    # 캔버스 관련
    CANVAS = "canvas"
    AI_SLIDE = "ai_slide"
    AI_SHEET = "ai_sheet"
    TITLE = "title"

    # 기타
    ERROR = "error"
    TOKEN = "token"  # 최종 메시지

    FILE = "file"

    START = "START"
    END = "END"
