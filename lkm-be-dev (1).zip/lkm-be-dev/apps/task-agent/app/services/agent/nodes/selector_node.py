# from typing import Dict

# from core.context import get_current_user_info
# from core.llm import get_llm_config
# from core.log.logging import get_logging
# from services.agent.nodes.base_node import BaseNode
# from services.agent.state import State
# from services.prompt.prompt_service import PromptService

# logger = get_logging()


# class SelectorNode(BaseNode):
#     def _setup_prompts(self) -> None:
#         self.selector_system_prompt = prompt_service.get_prompts(
#             get_current_user_info().company_code
#         )["Selector_System_Prompt"]
#         self.selector_user_prompt = prompt_service.get_prompts(
#             get_current_user_info().company_code
#         )["Selector_User_Prompt"]

#     async def __call__(self, state: State) -> State:
#         self._log_node_start("Selector")
#         user_basic_info, history = self._manage_history(state)

#         prompt_service_instance = PromptService()
#         dynamic_prompts = prompt_service_instance.get_dynamic_prompts(
#             get_current_user_info().company_code
#         )

#         conditions = []
#         seen_conditions = set()

#         for p in dynamic_prompts:
#             if p["condition"] and p["condition"] not in seen_conditions:
#                 conditions.append((p["condition"], p["condition_description"]))
#                 seen_conditions.add(p["condition"])

#         prompt = SelectorPrompt(
#             agent_config=self.agent_config,
#             user_query=state["user_query"],
#             history=history,
#             current_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#             system_prompt=self.selector_system_prompt,
#             user_prompt=self.selector_user_prompt,
#             conditions=conditions,
#         )

#         response = await self._invoke_llm_async(prompt, state["chat_id"])
#         self._log_llm_response("Selector", response)

#         matching_conditions = response.get("conditions", [])
#         matching_prompts = [
#             (p["node"], p["prompt_snippet"])
#             for p in dynamic_prompts
#             if p["condition"] in matching_conditions
#         ]

#         if "dynamic_prompts" in state:
#             state["dynamic_prompts"].extend(
#                 [i for i in matching_prompts if i not in state["dynamic_prompts"]]
#             )
#         else:
#             state["dynamic_prompts"] = [t for t in matching_prompts]

#         return state

#     async def _invoke_llm_async(self, prompt: SelectorPrompt, chat_id: str) -> Dict:
#         """LLM 호출 공통 메서드 (비동기)"""
#         structured_llm = self.llm.with_structured_output(prompt.OutputFormat)
#         response = await structured_llm.ainvoke(
#             [
#                 ("system", prompt.make_system_prompt()),
#                 ("human", prompt.make_user_prompt()),
#             ],
#             config=get_llm_config(chat_id),
#         )
#         return response.model_dump()
