from datetime import datetime
from typing import Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.state import State
from services.agent.message_types import MessageType
from services.agent.nodes.base_node import BaseNode
from services.agent.state import State, clear_view_messages
from services.tools.tool_executor import ToolExecutor

logger = get_logging()
settings = get_setting()

# MAX_RETRY_COUNT 상수 정의 (manager_node와 동일)
MAX_RETRY_COUNT = 2


class RetryExecutorNode(BaseNode):
    """재시도 실행 에이전트 - 실패한 액션에 대한 정교한 재시도 로직"""

    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        super().__init__(llm)
        self.tool_executor = ToolExecutor(self.llm)

    async def __call__(self, state: State) -> State:
        """실패한 도구 재실행"""
        self._log_node_start("RetryExecutor")

        # view_messages 초기화
        clear_view_messages(state)

        last_failed_action = state.get("last_failed_action")
        if not last_failed_action:
            logger.warning("[RetryExecutor] No failed action to retry")
            state["next"] = "manager"
            return state

        retry_count = state.get("retry_count", 0)
        state["retry_count"] = retry_count + 1

        # 최대 재시도 횟수 초과 체크
        if state["retry_count"] > MAX_RETRY_COUNT:
            logger.warning(
                f"[RetryExecutor] Maximum retry count exceeded: {state['retry_count']}/{MAX_RETRY_COUNT}"
            )

            action = last_failed_action.get("action", {})

            # 최대 재시도 횟수 초과 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_FAIL,
                content=f"❌ {action.get('name', 'Unknown Action')} (최대 재시도 횟수 초과)",
                description=f"최대 {MAX_RETRY_COUNT}회 재시도 후 실패",
                key=str(action.get("id", "")),
            )

            # 재시도 관련 정보 초기화
            state.pop("last_failed_action", None)
            state.pop("retry_count", None)

            # action_order와 current_step_action_order 증가 (다음 액션으로 진행)
            state["current_step_action_order"] = (
                state.get("current_step_action_order", 0) + 1
            )
            state["action_order"] = state.get("action_order", 0) + 1

            state["next"] = "manager"
            return state

        action = last_failed_action.get("action", {})
        failure_type = last_failed_action.get("failure_type", "unknown")
        failure_reason = last_failed_action.get("failure_reason", "Unknown error")
        tool_error_details = last_failed_action.get("tool_error_details", {})

        logger.info(
            f"[RetryExecutor] Retrying action: {action.get('name', 'Unknown')} "
            f"(Attempt {state['retry_count']}, Failure: {failure_type})"
        )

        # 재시도 시작 메시지 추가
        self.message_manager.add_message(
            state=state,
            message_type=MessageType.ACTION_START,
            content=f"🔄 {action.get('name', 'Unknown Action')} (재시도 {state['retry_count']}회)",
            description=f"이전 실패: {failure_reason}",
            key=str(action.get("id", "")),
        )

        try:
            # 재시도 파라미터 변환
            retry_params = await self.tool_executor.convert_parameters_for_retry(
                tool_info=last_failed_action.get("tool_info", {}),
                action=action,
                failure_info=last_failed_action,
                retry_count=state.get("retry_count", 0),
                history_info=state["tool_calling_history"],
                user_query=state["user_query"],
                messages_list=state["messages_list"],
                tool_document_mapping=state["tool_document_mapping"],
                state=state,
                chat_id=state["chat_id"],
                agent_id=state["agent_id"],
            )

            logger.info(f"[RetryExecutor] Retry parameters: {retry_params}")

            # 재시도 파라미터로 도구 실행
            tool_info = last_failed_action.get("tool_info", {})
            retry_result = await self.tool_executor.execute_tool(
                tool_info, retry_params
            )

            # 결과 검증 - 에러인지 확인 (executor node와 동일한 방식)
            if retry_result.get("success", False) is False:
                # 재시도 실패
                error_message = (
                    retry_result.get("error", "Unknown error")
                    if isinstance(retry_result, dict)
                    else str(retry_result)
                )
                logger.warning(f"[RetryExecutor] Retry failed: {error_message}")

                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_FAIL,
                    content=f"🔄❌ {action.get('name', 'Unknown Action')} (재시도 실패)",
                    description="개선된 전략으로도 실행 실패",
                    key=str(action.get("id", "")),
                )

                # tool_calling_history에 재시도 실패 정보 기록
                tool_calling_history = state.get("tool_calling_history", [])

                # step과 action 정보 가져오기
                step_plan = state.get("step_plan", [])
                step_order = state.get("step_order", 0)
                current_step = (
                    step_plan[step_order] if step_order < len(step_plan) else {}
                )
                tool_info = last_failed_action.get("tool_info", {})

                # 재시도 실패 기록
                retry_fail_history_entry = {
                    "timestamp": datetime.now().isoformat(),
                    "execution_id": f"retry_{step_order}_{state.get('action_order', 0)}_{state['retry_count']}_{datetime.now().strftime('%H%M%S')}_fail",
                    "ai_analysis": state.get(
                        "failure_analysis", {}
                    ),  # AI 분석 결과 추가
                    "retry_info": {
                        "is_retry": True,
                        "retry_attempt": state["retry_count"],
                        "original_failure_type": failure_type,
                        "original_failure_reason": failure_reason,
                        "retry_strategy": state.get("failure_analysis", {}).get(
                            "improvement_strategy", "unknown"
                        ),
                        "retry_success": False,
                        "retry_failure_reason": "재시도에서도 동일한 실패 발생",
                    },
                    "step_context": {
                        "step_order": step_order,
                        "step_name": current_step.get("name", "Unknown"),
                        "step_description": current_step.get("description", ""),
                        "step_id": str(current_step.get("id", "")),
                    },
                    "action_context": {
                        "action_order": state.get("action_order", 0),
                        "current_step_action_order": state.get(
                            "current_step_action_order", 0
                        ),
                        "action_name": action.get("name", "Unknown"),
                        "action_description": action.get("description", ""),
                        "action_id": str(action.get("id", "")),
                    },
                    "tool_execution": {
                        "tool_name": tool_info.get("name", "Unknown"),
                        "tool_type": tool_info.get("type", "unknown"),
                        "tool_description": tool_info.get("description", ""),
                        "tool_config": tool_info.get("config", {}),
                        "parameters_used": retry_params,
                        "success": False,
                        "result": retry_result,
                        "result_summary": "Retry failed",
                    },
                    "user_context": {
                        "user_query": state.get("user_query", ""),
                        "chat_id": state.get("chat_id", ""),
                        "agent_id": state.get("agent_id", ""),
                    },
                    "error_info": {
                        "error_type": "retry_failure",
                        "error_message": "재시도에서도 동일한 실패 발생",
                        "is_retryable": state["retry_count"] < MAX_RETRY_COUNT,
                        "failure_stage": "retry_execution",
                    },
                }

                tool_calling_history.append(retry_fail_history_entry)
                state["tool_calling_history"] = tool_calling_history

                # 실패 정보 업데이트
                state["last_failed_action"][
                    "failure_reason"
                ] = "재시도에서도 동일한 실패 발생"
                state["next"] = "manager"
                return state

            # 재시도 성공
            logger.info(f"[RetryExecutor] Retry succeeded")

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_SUCCESS,
                content=f"🔄✅ {action.get('name', 'Unknown Action')} (재시도 성공)",
                description="개선된 전략으로 실행 성공",
                key=str(action.get("id", "")),
            )

            # 성공한 결과를 messages에 추가
            messages = state.get("messages", [])
            tool_info = last_failed_action.get("tool_info", {})
            messages.append(
                {
                    "Action": tool_info.get("name", "Unknown Tool"),
                    "Result": retry_result,
                    "RetryAttempt": state["retry_count"],
                    "PreviousFailure": failure_type,
                }
            )
            state["messages"] = messages

            # tool_calling_history에 재시도 성공 정보 기록
            tool_calling_history = state.get("tool_calling_history", [])

            # step과 action 정보 가져오기
            step_plan = state.get("step_plan", [])
            step_order = state.get("step_order", 0)
            current_step = step_plan[step_order] if step_order < len(step_plan) else {}

            # 재시도 성공 기록
            retry_history_entry = {
                "timestamp": datetime.now().isoformat(),
                "execution_id": f"retry_{step_order}_{state.get('action_order', 0)}_{state['retry_count']}_{datetime.now().strftime('%H%M%S')}_success",
                "ai_analysis": state.get("failure_analysis", {}),  # AI 분석 결과 추가
                "retry_info": {
                    "is_retry": True,
                    "retry_attempt": state["retry_count"],
                    "original_failure_type": failure_type,
                    "original_failure_reason": failure_reason,
                    "retry_strategy": state.get("failure_analysis", {}).get(
                        "improvement_strategy", "unknown"
                    ),
                    "retry_success": True,
                },
                "step_context": {
                    "step_order": step_order,
                    "step_name": current_step.get("name", "Unknown"),
                    "step_description": current_step.get("description", ""),
                    "step_id": str(current_step.get("id", "")),
                },
                "action_context": {
                    "action_order": state.get("action_order", 0),
                    "current_step_action_order": state.get(
                        "current_step_action_order", 0
                    ),
                    "action_name": action.get("name", "Unknown"),
                    "action_description": action.get("description", ""),
                    "action_id": str(action.get("id", "")),
                },
                "tool_execution": {
                    "tool_name": tool_info.get("name", "Unknown"),
                    "tool_type": tool_info.get("type", "unknown"),
                    "tool_description": tool_info.get("description", ""),
                    "tool_config": tool_info.get("config", {}),
                    "parameters_used": retry_params,
                    "success": True,
                    "result": retry_result,
                    "result_summary": (
                        str(retry_result)[:200] if retry_result else "Retry successful"
                    ),
                },
                "user_context": {
                    "user_query": state.get("user_query", ""),
                    "chat_id": state.get("chat_id", ""),
                    "agent_id": state.get("agent_id", ""),
                },
            }

            tool_calling_history.append(retry_history_entry)
            state["tool_calling_history"] = tool_calling_history

            # 재시도 정보 초기화
            state.pop("last_failed_action", None)
            state.pop("retry_count", None)

            # action_order와 current_step_action_order 증가
            state["current_step_action_order"] = (
                state.get("current_step_action_order", 0) + 1
            )
            state["action_order"] = state.get("action_order", 0) + 1

            state["next"] = "manager"
            return state

        except Exception as e:
            logger.error(f"[RetryExecutor] General error during retry: {str(e)}")

            # 예외 발생 시 retry_params는 빈 딕셔너리로 설정
            retry_params = {}

            # 일반 예외 발생
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_FAIL,
                content=f"🔄❌ {action.get('name', 'Unknown Action')} (재시도 오류)",
                description=f"재시도 중 예외 발생: {str(e)}",
                key=str(action.get("id", "")),
            )

            # tool_calling_history에 재시도 예외 정보 기록
            tool_calling_history = state.get("tool_calling_history", [])

            # step과 action 정보 가져오기
            step_plan = state.get("step_plan", [])
            step_order = state.get("step_order", 0)
            current_step = step_plan[step_order] if step_order < len(step_plan) else {}
            tool_info = last_failed_action.get("tool_info", {})

            # 재시도 예외 기록
            retry_exception_history_entry = {
                "timestamp": datetime.now().isoformat(),
                "execution_id": f"retry_{step_order}_{state.get('action_order', 0)}_{state['retry_count']}_{datetime.now().strftime('%H%M%S')}_exception",
                "ai_analysis": state.get("failure_analysis", {}),  # AI 분석 결과 추가
                "retry_info": {
                    "is_retry": True,
                    "retry_attempt": state["retry_count"],
                    "original_failure_type": failure_type,
                    "original_failure_reason": failure_reason,
                    "retry_strategy": state.get("failure_analysis", {}).get(
                        "improvement_strategy", "unknown"
                    ),
                    "retry_success": False,
                    "retry_failure_reason": f"재시도 중 예외 발생: {str(e)}",
                },
                "step_context": {
                    "step_order": step_order,
                    "step_name": current_step.get("name", "Unknown"),
                    "step_description": current_step.get("description", ""),
                    "step_id": str(current_step.get("id", "")),
                },
                "action_context": {
                    "action_order": state.get("action_order", 0),
                    "current_step_action_order": state.get(
                        "current_step_action_order", 0
                    ),
                    "action_name": action.get("name", "Unknown"),
                    "action_description": action.get("description", ""),
                    "action_id": str(action.get("id", "")),
                },
                "tool_execution": {
                    "tool_name": tool_info.get("name", "Unknown"),
                    "tool_type": tool_info.get("type", "unknown"),
                    "tool_description": tool_info.get("description", ""),
                    "tool_config": tool_info.get("config", {}),
                    "parameters_used": retry_params,
                    "success": False,
                    "result": None,
                    "result_summary": f"Retry exception: {str(e)[:200]}",
                },
                "user_context": {
                    "user_query": state.get("user_query", ""),
                    "chat_id": state.get("chat_id", ""),
                    "agent_id": state.get("agent_id", ""),
                },
                "error_info": {
                    "error_type": "retry_exception",
                    "error_message": str(e),
                    "exception_type": type(e).__name__,
                    "is_retryable": state["retry_count"] < MAX_RETRY_COUNT,
                    "failure_stage": "retry_execution",
                },
            }

            tool_calling_history.append(retry_exception_history_entry)
            state["tool_calling_history"] = tool_calling_history

            # 실패 정보 업데이트
            state["last_failed_action"][
                "failure_reason"
            ] = f"재시도 중 일반 예외: {str(e)}"
            state["next"] = "manager"
            return state
