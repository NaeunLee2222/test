import asyncio
import json
import os
import re
import uuid
from typing import Any, Dict, List, Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI
from sqlalchemy import select

from client.agent_document_client import AgentDocumentClient
from client.chat_document_client import ChatDocumentClient
from core.config import get_setting
from core.llm import get_llm_config
from core.log.logging import get_logging
from database.models.expert_agent.expert_agent import (
    GeneralAgentInstruction,
    GeneralAgentInstructionTool,
    ProcedureDocument,
    Tool,
)
from database.session import AsyncSessionLocal
from services.action_plan_service import ActionPlanService
from services.agent.message_types import MessageType
from services.agent.nodes.base_node import BaseNode, manage_history
from services.agent.state import State, clear_view_messages
from services.prompt.general_chat_prompt import PROCEDURE_PROMPT
from services.prompt.planner_prompt import (
    FILTER_STEPS_PROMPT_TEMPLATE,
    FilteredStepsResponse,
)
from services.prompt.prepare_planning_prompt import (
    PreparePlanningGenerator,
)
from services.step_plan_service import StepPlanService

logger = get_logging()
settings = get_setting()


class PlannerNode(BaseNode):
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        super().__init__(llm)  # agent_id는 나중에 state에서 가져옴
        self.action_plan_service = ActionPlanService()
        self.step_plan_service = StepPlanService()
        self.chat_document_client = ChatDocumentClient()
        self.agent_document_client = AgentDocumentClient()

    def _setup_prompts(self) -> None:
        self.system_prompt = self.prompt_service.get_prompts()["Planner_System_Prompt"]
        self.user_prompt = self.prompt_service.get_prompts()["Planner_User_Prompt"]

    async def filter_steps_by_llm(
        self, state: State, initial_step_plan: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """사용자 쿼리를 기반으로 LLM을 사용하여 전체 step plan에서 필요한 step만 필터링합니다."""
        user_query = state["user_query"]
        _, history = manage_history(state)

        # initial_step_plan을 JSON 문자열로 변환 (프롬프트에 포함하기 위해)
        simplified_steps_for_prompt = []
        for step in initial_step_plan:
            simplified_actions = []
            for action in step.get("actions", []):
                action_info = {
                    "name": action.get("name"),
                    "description": action.get("description"),
                }
                # tool 정보는 간략하게 (필요하다면 tool의 name 정도만)
                if action.get("tool") and isinstance(action["tool"], dict):
                    action_info["tool_name"] = action["tool"].get("name")
                    action_info["tool_description"] = action["tool"].get("description")
                simplified_actions.append(action_info)
            simplified_steps_for_prompt.append(
                {
                    "order": step.get("order"),
                    "name": step.get("name"),
                    "description": step.get("description"),
                    "actions": simplified_actions,
                }
            )
        steps_str = json.dumps(
            simplified_steps_for_prompt, ensure_ascii=False, indent=4
        )

        prompt = FILTER_STEPS_PROMPT_TEMPLATE.format(
            user_query=user_query, steps_str=steps_str, history=history
        )

        chat_messages = [("system", prompt), ("human", user_query)]
        session_id = state["chat_id"]

        structured_llm = self.llm.with_structured_output(FilteredStepsResponse)
        try:
            response = structured_llm.invoke(
                chat_messages, config=get_llm_config(session_id)
            )
            logger.info(f"[Planner] FilteredStepsResponse from LLM: {response}")

            if not response or not response.selected_steps:
                logger.warning(
                    "[Planner] LLM did not return any selected steps. Falling back to initial full step plan."
                )
                return []

            # LLM이 반환한 selected_steps의 order 순서를 그대로 사용하여 filtered_steps를 구성합니다.
            # 중복된 order도 허용합니다 (LLM이 동일 step 반복을 의도한 경우).
            filtered_steps = []
            original_steps_map = {step["order"]: step for step in initial_step_plan}

            for selected_step_info in response.selected_steps:
                order = selected_step_info.order
                if order in original_steps_map:
                    # 원본 step 객체의 복사본을 추가하여 원본 initial_step_plan이 변경되지 않도록 함
                    filtered_steps.append(original_steps_map[order].copy())
                else:
                    logger.warning(
                        f"[Planner] LLM selected order {order} which is not in the original step plan. Skipping."
                    )

            if not filtered_steps:
                logger.warning(
                    "[Planner] No valid steps were selected by LLM or all selected orders were invalid. Returning empty list."
                )
                return []

            logger.info(
                f"[Planner] Filtered steps based on LLM (preserving LLM's order and allowing duplicates): {filtered_steps}"
            )
            return filtered_steps

        except Exception as e:
            logger.error(f"[Planner] Error in filter_steps_by_query: {str(e)}")
            return []

    async def __call__(self, state: State) -> State:
        # view_messages 초기화
        clear_view_messages(state)

        # 사용자에게 계획 시작을 알리는 메시지 생성 및 전송
        planning_generator = PreparePlanningGenerator(self.llm)
        planning_message = planning_generator.generate(state)
        self.message_manager.add_message(
            state=state,
            message_type=MessageType.TOKEN,
            content=planning_message,
            key=str(uuid.uuid4()),
        )

        self._log_node_start("Planner")

        self.agent_id = state["agent_id"]
        agent_info = self.step_plan_service.get_agent_info(state["agent_id"])

        # 에이전트 소개 메시지 생성 및 전송
        # 안녕하세요! 당신의 AI 비서 '{agent_info.name}'입니다. 저는 '{agent_info.description}' 역할을 수행하며, 지금부터 요청하신 작업을 시작하겠습니다. 먼저, 작업 계획을 세우겠습니다. 잠시만 기다려주세요.

        step_plan = []
        action_plan_with_tools = []

        # 스텝 플랜 가져오기
        step_plan = self.step_plan_service.get_agent_steps(agent_info)

        if step_plan and agent_info.agent_type == "pro":
            # Pro 에이전트의 경우 기존 step_plan 사용하면서 action_plan_with_tools도 생성
            # step_plan = await self.filter_steps_by_llm(state, step_plan)

            action_plan = []
            for step in step_plan:
                action_plan.extend(step["actions"])

            action_plan_with_tools = self.action_plan_service.get_actions_with_tools(
                action_plan
            )

        else:
            # General 에이전트의 경우 step_plan 생성
            action_plan_with_tools, step_plan = await self.make_general_chat_plan(state)

        # --- 공통 후처리 로직 ---
        if step_plan:
            plan_content = ", ".join(
                [s.get("name", "이름 없는 스텝") for s in step_plan]
            )

            # doc을 불러올 수 있는 경우 어떤 tool에 rag를 넣을지 정보 추가
            # 1. chat_id로 불러오기 -> 사용자가 업로드한 문서
            # 2. expert_agent_id로 불러오기 -> 에이전트를 만들때 등록한 문서

            # 요약 된 문서로 수정.
            # 채팅 문서와 에이전트 문서를 가져와서 state에 저장
            chat_documents_summary = (
                await self.chat_document_client.get_chat_documents_summary(
                    state["chat_id"]
                )
            )
            agent_documents_summary = (
                await self.agent_document_client.get_agent_documents_summary(
                    state["agent_id"]
                )
            )

            # 문서 요약 정보를 state에 저장
            state["chat_documents_summary"] = {}
            state["agent_documents_summary"] = {}

            # 채팅 문서 요약 저장
            if chat_documents_summary and isinstance(chat_documents_summary, list):
                for doc in chat_documents_summary:
                    doc_id = doc.get("id")
                    summary = doc.get("summary", "")
                    if doc_id and summary:
                        state["chat_documents_summary"][doc_id] = summary

            # 에이전트 문서 요약 저장
            if agent_documents_summary and isinstance(agent_documents_summary, list):
                for doc in agent_documents_summary:
                    doc_id = doc.get("id")
                    summary = doc.get("summary", "")
                    if doc_id and summary:
                        state["agent_documents_summary"][doc_id] = summary

            # 도구별 문서 매핑을 위한 상태 추가
            state["tool_document_mapping"] = {}

            # action_plan의 각 도구에 대해 어떤 문서가 필요한지 매핑
            # todo llm으로 매핑 자동화
            if action_plan_with_tools:
                for action in action_plan_with_tools:
                    tool_info = action.get("tool")
                    if tool_info and isinstance(tool_info, dict):
                        tool_name = tool_info.get("name")
                        if tool_name:
                            # 도구별로 사용할 문서 목록 초기화
                            state["tool_document_mapping"][tool_name] = {
                                "chat_documents": list(
                                    state["chat_documents_summary"].keys()
                                ),
                                "agent_documents": list(
                                    state["agent_documents_summary"].keys()
                                ),
                            }

            ## 프롬프트 가드
            # # 생성된 step에 대해서 마크다운 형식으로 제공하기
            # step_plan_markdown = format_step_plan_as_markdown(step_plan, self.llm)

            # agent_capability_generator = AgentCapabilityGenerator(self.llm)
            # agent_capability_response = agent_capability_generator.generate(
            #     user_query=state["user_query"],
            #     agent_name=agent_info.name,
            #     agent_description=agent_info.description,
            #     markdown_plan=step_plan_markdown,
            # )

            # if agent_capability_response.is_agent_capable_task is False:
            #     self.message_manager.add_message(
            #         state=state,
            #         message_type=MessageType.TOKEN,
            #         content=agent_capability_response.planning_message,
            #         key=str(uuid.uuid4()),
            #     )

            #     state["next"] = "reporter"
            #     return state

            # self.message_manager.add_message(
            #     state=state,
            #     message_type=MessageType.TOKEN,
            #     content="작업을 진행하겠습니다.",
            #     key=str(uuid.uuid4()),
            # )

            await asyncio.sleep(1.5)

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.PLAN_START,
                content=plan_content,
                description="",
                key="",
            )

            state["step_plan"] = step_plan
            state["action_plan"] = action_plan_with_tools
            state["step_order"] = 0
            state["current_step_action_order"] = 0
            state["action_order"] = 0

            tool_names = []
            if action_plan_with_tools:
                for action_item in action_plan_with_tools:
                    tool_info = action_item.get("tool")
                    if tool_info and isinstance(tool_info, dict):
                        tool_name = tool_info.get("name")
                        if tool_name:
                            tool_names.append(tool_name)

            state["messages"].append(
                {"Query": state["user_query"], "Used_tool": tool_names}
            )
            state["next"] = "manager"
        else:
            state["step_plan"] = []
            state["action_plan"] = []
            state["step_order"] = 0
            state["current_step_action_order"] = 0
            state["action_order"] = 0
            state["next"] = "reporter"

        return state

    async def make_general_chat_plan(self, state):
        # 일반 에이전트의 경우 데이터베이스에서 instruction과 tools 가져오기
        db = None
        try:
            # history 가져오기
            user_basic_info, history = manage_history(state)

            async with AsyncSessionLocal() as db:
                # ProcedureDocument 조회
                procedure_document_stmt = select(ProcedureDocument).where(
                    ProcedureDocument.expert_agent_id == state["agent_id"],
                )
                procedure_document_result = await db.execute(procedure_document_stmt)
                procedure_document = procedure_document_result.scalars().first()

                if procedure_document:
                    procedure_document_str = procedure_document.original_filename
                    file_path = os.path.join(
                        settings.FILE_UPLOAD_DIR, procedure_document.filename
                    )
                    with open(file_path, "r", encoding="utf-8") as f:
                        procedure_document_str = f.read()
                else:
                    procedure_document_str = "업무절차서가 없습니다."

                # GeneralAgentInstruction 조회
                instruction_stmt = select(GeneralAgentInstruction).where(
                    GeneralAgentInstruction.expert_agent_id == state["agent_id"],
                )
                instruction_result = await db.execute(instruction_stmt)
                instruction = instruction_result.scalars().first()

                if not instruction:
                    logger.error(
                        f"[Planner] General agent instruction not found for agent_id: {state['agent_id']}"
                    )
                    return [], []

                # GeneralAgentInstructionTool을 통해 연결된 Tool 조회
                tool_stmt = (
                    select(Tool)
                    .join(
                        GeneralAgentInstructionTool,
                        Tool.id == GeneralAgentInstructionTool.tool_id,
                    )
                    .where(
                        GeneralAgentInstructionTool.expert_agent_instruction_id
                        == instruction.id
                    )
                )
                tool_result = await db.execute(tool_stmt)
                tools = tool_result.scalars().all()

                # 사용 가능한 도구 정보 구성
                available_tools = {}
                for tool in tools:
                    available_tools[tool.name] = {
                        "id": tool.id,
                        "name": tool.name,
                        "description": tool.description,
                        "endpoint": tool.endpoint,
                        "type": tool.type,
                        "config": tool.config,
                    }

                # history를 문자열로 포맷팅
                history_str = json.dumps(history, ensure_ascii=False, indent=2)

                # 일반 에이전트를 위한 프롬프트 생성
                prompt = PROCEDURE_PROMPT.format(
                    procedure=procedure_document_str,
                    user_query=state["user_query"],
                    available_tools_str=str(available_tools),
                    instruction=instruction.instruction
                    or "사용자의 요구사항을 바탕으로 적절한 Step과 Action을 구성해주세요.",
                    history=history_str,
                )

                # LLM 호출
                chat_messages = [("system", prompt), ("human", state["user_query"])]
                session_id = state["chat_id"]
                response = self.llm.invoke(
                    chat_messages, config=get_llm_config(session_id)
                )

                # 응답 파싱
                try:
                    # JSON 문자열 추출
                    content = response.content
                    json_match = re.search(r"```json\n(.*?)\n```", content, re.DOTALL)
                    if json_match:
                        json_str = json_match.group(1)
                    else:
                        json_str = content

                    steps_json = json.loads(json_str)
                    step_plan = []
                    action_plan = []

                    for step_data in steps_json:
                        # Step 생성
                        step = {
                            "id": f"temp_step_{step_data['order']}",
                            "expert_agent_id": state["agent_id"],
                            "name": step_data["name"],
                            "description": step_data["description"],
                            "order": step_data["order"],
                            "actions": [],
                        }
                        step_plan.append(step)

                        # Action 생성
                        for action_data in step_data["actions"]:
                            action = {
                                "id": f"temp_action_{step_data['order']}_{action_data['order']}",
                                "step_id": step["id"],
                                "name": action_data["name"],
                                "description": action_data["description"],
                                "order": action_data["order"],
                                "tool": None,
                            }

                            # Tool 연결
                            if "tool" in action_data and action_data["tool"]:
                                tool_name = action_data["tool"]["name"]
                                if tool_name in available_tools:
                                    action["tool"] = available_tools[tool_name]
                                else:
                                    logger.warning(
                                        f"Tool {tool_name} not found in available tools"
                                    )
                                    action["tool"] = {
                                        "id": f"temp_tool_{step_data['order']}_{action_data['order']}",
                                        "name": tool_name,
                                        "description": action_data["tool"][
                                            "description"
                                        ],
                                    }

                            step["actions"].append(action)
                            action_plan.append(action)

                    return action_plan, step_plan

                except Exception as e:
                    logger.error(f"[Planner] Error parsing LLM response: {str(e)}")
                    return [], []

        except Exception as e:
            logger.error(
                f"[Planner] Error getting general agent instruction and tools: {str(e)}"
            )
            return [], []
