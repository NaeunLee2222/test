import json
import os
import re
from ast import literal_eval
from enum import Enum
from typing import Optional, Tuple, Union

import docx
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from client.agent_document_client import AgentDocumentClient
from client.canvas_create_client import CanvasCreateClient
from client.chat_document_client import ChatDocumentClient
from core.config import get_setting
from core.llm import get_llm_config
from core.log.logging import get_logging
from database.models.expert_agent.expert_agent import Tool
from database.session import AsyncSessionLocal
from services.agent.message_types import MessageType
from services.agent.nodes.base_node import BaseNode, manage_history
from services.agent.state import State, clear_view_messages
from services.prompt.ai_slide_prompt import create_ai_slide_prompt
from services.prompt.models.agent import ReporterPrompt

logger = get_logging()
settings = get_setting()


canvas_create_client = CanvasCreateClient()


class ProcessingResult(Enum):
    """처리 결과 타입"""

    SUCCESS = "success"
    FALLBACK_TO_TOKEN = "fallback_to_token"
    ERROR = "error"


class BaseReporterNode(BaseNode):
    """리포터 노드 - 모든 기능을 __call__ 메서드 하나로 통합"""

    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI], canvas: str = ""):
        super().__init__(llm)
        self.canvas = canvas

    def _setup_prompts(self) -> None:
        self.system_prompt = self.prompt_service.get_prompts()["Reporter_System_Prompt"]
        self.user_prompt = self.prompt_service.get_prompts()["Reporter_User_Prompt"]
        self.user_no_plan_prompt = self.prompt_service.get_prompts()[
            "Reporter_User_Prompt_no_plan"
        ]

    async def __call__(self, state: State) -> State:
        self._log_node_start("Reporter")
        clear_view_messages(state)

        if state.get("step_plan"):
            len_state = len(state["step_plan"])
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.PLAN_END,
                content="모든 계획이 완료되었습니다.",
                description=f"총 {len_state}개의 스텝이 완료되었습니다.",
                key="",
            )

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.TOKEN,
                content=f"모든 계획이 완료되었습니다.",
                description="",
                key="",
            )

        user_basic_info, history = manage_history(state)

        prev_history = history[:-1]
        keys_to_keep = ["Query", "Answer"]

        filtered_history = [
            {k: d[k] for k in keys_to_keep if k in d} for d in prev_history
        ]

        user_query = state["user_query"]

        self._setup_prompts()

        prompt = ReporterPrompt(
            agent_config=state["agent_config"],
            user_query=user_query,
            history=filtered_history,
            plan=state["step_plan"],
            tool_calling_history=state["tool_calling_history"],
            plan_analysis="",
            system_prompt=self.system_prompt,
            user_prompt=self.user_prompt,
            user_no_plan_prompt=self.user_no_plan_prompt,
        )

        output_format = prompt.OutputFormat
        system_prompt = prompt.make_system_prompt()
        user_prompt = prompt.make_user_prompt()

        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]

        session_id = state.get("chat_id")
        structured_llm = self.llm.with_structured_output(output_format)
        response = structured_llm.invoke(
            chat_messages, config=get_llm_config(session_id) if session_id else None
        )

        # response가 dict가 아닌 경우 model_dump 호출
        if hasattr(response, "model_dump"):
            response = response.model_dump()
        elif not isinstance(response, dict):
            response = dict(response) if response else {}

        state["next"] = "finish"

        canvas_type = self.canvas
        logger.debug(f"[Reporter] LLM response: {response}")

        # Canvas 타입별 처리 및 통합된 응답 처리
        await self._process_response_by_canvas_type(state, response, canvas_type)

        if (
            len(state.get("chat_documents_summary", {}))
            + len(state.get("agent_documents_summary", {}))
            != 0
        ):
            logger.info("[Reporter] 파일 정보 조회 시도")
            await self._handle_file_response(state)

        self.message_manager.add_message(
            state=state,
            message_type=MessageType.END,
            content="",
            description="",
            key="",
        )

        return state

    async def _process_response_by_canvas_type(
        self, state: State, response: dict, canvas_type: str
    ):
        """Canvas 타입에 따른 처리 및 통합된 응답 관리"""
        # Canvas 타입별 처리
        if canvas_type == "canvas":
            result = await self._try_file_canvas_processing(state, response)
            # canvas인 경우 요약 및 추가 질문 유도
            if result == ProcessingResult.SUCCESS:
                await self._handle_summary_and_followup(state, response)
        elif canvas_type == "ai_slide":
            result = await self._try_ai_slide_processing(state, response)
            if result == ProcessingResult.SUCCESS:
                await self._handle_summary_and_followup(state, response)
        else:
            logger.info(
                f"[Reporter] Unknown or empty canvas type: '{canvas_type}', using token response"
            )
            result = ProcessingResult.FALLBACK_TO_TOKEN

        # 결과에 따른 최종 응답 처리
        if result == ProcessingResult.FALLBACK_TO_TOKEN:
            await self._handle_token_response(state, response)

    async def _try_file_canvas_processing(
        self, state: State, response: dict
    ) -> ProcessingResult:
        """파일 기반 Canvas 또는 컨텐츠 처리 시도, 결과 반환"""
        try:
            if not response.get("is_canvas_need", False):
                logger.info(
                    "[Reporter] Canvas 또는 파일 표시가 필요하지 않음, 토큰 응답으로 처리"
                )
                return ProcessingResult.FALLBACK_TO_TOKEN

            files_path = response.get("files_path")
            if not files_path:
                logger.error("[Reporter] 파일 경로를 찾을 수 없습니다.")
                return ProcessingResult.FALLBACK_TO_TOKEN

            any_success = False
            for file_path in files_path:
                if not file_path:
                    continue

                try:
                    content = ""
                    _, file_extension = os.path.splitext(file_path)
                    file_extension = file_extension.lower()

                    if file_extension == ".docx":
                        doc = docx.Document(file_path)
                        content = "\n".join([p.text for p in doc.paragraphs])
                    elif file_extension in [
                        ".txt",
                        ".md",
                        ".py",
                        ".json",
                        ".csv",
                        ".html",
                    ]:
                        with open(file_path, "r", encoding="utf-8") as f:
                            content = f.read()
                    else:
                        logger.warning(
                            f"[Reporter] 지원하지 않는 파일 형식입니다 (건너뜀): {file_path}"
                        )
                        continue

                    if not content:
                        logger.warning(
                            f"[Reporter] 파일 내용이 비어있습니다 (건너뜀): {file_path}"
                        )
                        continue

                    success = await self._create_file_canvas(state, content, file_path)

                    if success:
                        any_success = True

                except Exception as e:
                    logger.error(
                        f"[Reporter] 파일 처리 중 예상치 못한 오류: {file_path}, {e}"
                    )
                    continue

            if any_success:
                return ProcessingResult.SUCCESS
            else:
                logger.error("[Reporter] 모든 파일 처리에 실패했습니다.")
                return ProcessingResult.FALLBACK_TO_TOKEN

        except Exception as e:
            logger.error(f"[Reporter] 파일 처리 중 예외: {str(e)}")
            return ProcessingResult.FALLBACK_TO_TOKEN

    async def _try_ai_slide_processing(
        self, state: State, response: dict
    ) -> ProcessingResult:
        """AI Slide 처리 시도, 결과 반환"""
        try:
            # AI Slide 도구 및 파라미터 준비
            tool_data = await self._prepare_ai_slide_tool(state, response)
            if not tool_data:
                return ProcessingResult.FALLBACK_TO_TOKEN

            mcp_tool, report_content_prompt = tool_data

            # AI Slide 생성 실행
            success = await self._execute_ai_slide_creation(
                mcp_tool, report_content_prompt, state, response
            )
            return (
                ProcessingResult.SUCCESS
                if success
                else ProcessingResult.FALLBACK_TO_TOKEN
            )

        except Exception as e:
            logger.error(f"[Reporter] AI Slide 처리 중 예외: {str(e)}")
            return ProcessingResult.FALLBACK_TO_TOKEN

    async def _prepare_ai_slide_tool(
        self, state: State, response: dict
    ) -> Optional[Tuple]:
        """AI Slide 처리에 필요한 도구와 파라미터 준비"""
        # 1. 데이터베이스에서 도구 정보 조회
        target_tool_name = "report_to_presentation"
        db_tool_info, endpoints = await self._get_tool_from_database(target_tool_name)

        if not db_tool_info or not endpoints:
            logger.error(f"[Reporter] Tool '{target_tool_name}' not found in DB")
            return None

        # 2. MCP 클라이언트에서 도구 조회
        mcp_tool = await self._get_mcp_tool(target_tool_name, endpoints)
        if not mcp_tool:
            logger.error(f"[Reporter] MCP tool '{target_tool_name}' not available")
            return None

        # 3. AI Slide용 프롬프트 생성
        report_content_prompt = create_ai_slide_prompt(
            user_query=state.get("user_query", ""),
            tool_calling_history=state.get("tool_calling_history", []),
        )
        logger.debug(f"[Reporter] Generated AI Slide Prompt:\n{report_content_prompt}")

        return mcp_tool, report_content_prompt

    async def _execute_ai_slide_creation(
        self, mcp_tool, report_content_prompt: str, state: State, response: dict
    ) -> bool:
        """AI Slide 생성 실행"""
        try:
            # 도구 실행
            converted_params = {"report_content": report_content_prompt}
            tool_result = await mcp_tool.ainvoke(converted_params)
            logger.info(
                f"[Reporter] PPT tool executed. Result type: {type(tool_result)}"
            )

            # AI Slide 생성
            return await self._create_ai_slides(state, response, tool_result)

        except Exception as e:
            logger.error(f"[Reporter] AI Slide 생성 실행 중 오류: {str(e)}")
            return False

    async def _create_ai_slides(
        self, state: State, response: dict, tool_result
    ) -> bool:
        """AI Slides를 생성하는 헬퍼 메서드"""
        try:
            if isinstance(tool_result, str):
                slide_data = json.loads(tool_result)
            else:
                slide_data = tool_result

            slides = slide_data.get("slides")
            if not isinstance(slides, list):
                logger.error(
                    "[Reporter] PPT 결과에 slides 배열이 없거나 list가 아닙니다."
                )
                return False

            logger.info(f"[Reporter] Processing {len(slides)} slides")

            chat_id = self._safe_get_state_value(state, "chat_id", "")
            if not chat_id:
                logger.error("[Reporter] chat_id를 찾을 수 없습니다.")
                return False

            title = state.get("user_query", "프레젠테이션")

            # 각 슬라이드 처리
            for idx, slide in enumerate(slides):
                slide_html = slide.get("html", "")
                slide_title = slide.get("title", f"Slide {idx + 1}")

                if not slide_html:
                    continue

                try:
                    uuid = await canvas_create_client.create_canvas(
                        chat_id=str(chat_id),
                        title=title,
                        content=slide_html,
                        file_extension="html",
                        canvas_type="ai_slide",
                        version=1,
                    )

                    if uuid:
                        self.message_manager.add_message(
                            state=state,
                            message_type=MessageType.AI_SLIDE,
                            content=slide_html,
                            title=slide_title,
                            description="",
                            key=uuid,
                        )
                        logger.info(
                            f"[Reporter] Slide {idx + 1} Canvas 생성 완료: {uuid}"
                        )
                    else:
                        logger.error(f"[Reporter] Slide {idx + 1} Canvas 생성 실패")

                except Exception as e:
                    logger.error(
                        f"[Reporter] Slide {idx + 1} Canvas API 호출 중 예외 발생: {str(e)}"
                    )
            # 완료 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.TOKEN,
                content=f"프레젠테이션이 생성되었습니다. 총 {len(slides)}개의 슬라이드가 생성되었습니다.",
                description="",
                key="",
            )

            logger.info(f"[Reporter] AI Slides 생성 완료: {len(slides)}개")
            return True

        except json.JSONDecodeError as e:
            logger.error(f"[Reporter] PPT 결과 JSON 파싱 오류: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"[Reporter] AI Slides 생성 중 오류: {str(e)}")
            return False

    def _safe_get_state_value(self, state: State, key: str, default=None):
        """State에서 안전하게 값을 가져오는 헬퍼 메서드"""
        return state.get(key, default)

    async def _get_tool_from_database(self, tool_name: str):
        """데이터베이스에서 도구 정보를 조회하는 헬퍼 메서드"""
        try:
            async with AsyncSessionLocal() as db:
                db: AsyncSession
                stmt = select(Tool).where(Tool.name == tool_name)
                result = await db.execute(stmt)
                db_tool_info = result.scalars().first()

                if not db_tool_info or not db_tool_info.endpoint:
                    return None, None

                tool_endpoint = db_tool_info.endpoint
                endpoints = {tool_name: literal_eval(tool_endpoint)}

                logger.info(
                    f"[Reporter] Found tool '{tool_name}' with endpoint: {tool_endpoint}"
                )
                return db_tool_info, endpoints

        except Exception as e:
            logger.error(
                f"[Reporter] 데이터베이스에서 도구 '{tool_name}' 조회 중 오류: {str(e)}"
            )
            return None, None

    async def _get_mcp_tool(self, tool_name: str, endpoints: dict):
        """MCP 클라이언트에서 도구를 조회하는 헬퍼 메서드"""
        try:
            client = MultiServerMCPClient(endpoints)
            available_tools = await client.get_tools()

            for tool in available_tools:
                if tool.name == tool_name:
                    return tool

            logger.error(
                f"[Reporter] MCP tool '{tool_name}' not found in available tools."
            )
            return None

        except Exception as e:
            logger.error(f"[Reporter] MCP 도구 '{tool_name}' 조회 중 오류: {str(e)}")
            return None

    async def _create_file_canvas(
        self, state: State, content: str, file_path: str
    ) -> bool:
        """파일 내용으로 Canvas를 생성하는 헬퍼 메서드"""
        try:
            chat_id = self._safe_get_state_value(state, "chat_id", "")
            if not chat_id:
                logger.error("[Reporter] chat_id를 찾을 수 없습니다.")
                return False

            title = os.path.basename(file_path)
            file_extension = file_path.split(".")[-1] if "." in file_path else "txt"

            uuid = await canvas_create_client.create_canvas(
                chat_id=str(chat_id),
                title=title,
                content=content,
                file_extension=file_extension,
                canvas_type="canvas",
                version=1,
            )

            if not uuid:
                logger.error("[Reporter] Canvas 생성 실패")
                return False

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.TOKEN,
                content=f"위의 내용을 토대로 {title} Canvas를 제공합니다.",
                title=title,
                key=str(uuid),
                description="",
            )

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.CANVAS,
                content=content,
                title=title,
                key=str(uuid),
                description="",
            )

            logger.info(f"[Reporter] Canvas 생성 완료: {uuid}")
            return True

        except Exception as e:
            logger.error(f"[Reporter] Canvas 생성 중 오류: {str(e)}")
            return False

    async def _handle_token_response(self, state, response):
        """기본 토큰 응답 처리"""
        assistant_prompt = response.get("assistant_prompt")
        if assistant_prompt is not None and isinstance(assistant_prompt, str):
            report = re.sub(r"\n+", "\n", assistant_prompt)
            report = re.sub(r"\n", "  \n", report)
        else:
            report = assistant_prompt

        self.message_manager.add_message(
            state=state,
            message_type=MessageType.TOKEN,
            content=report,
            description="",
            key="",
        )

        logger.info(f"[Reporter] Report output: {report}")

    async def _handle_file_response(self, state):
        chat_id = state.get("chat_id")
        agent_id = state.get("agent_id")

        if not chat_id or not agent_id:
            logger.error("[Reporter] chat_id 또는 agent_id를 찾을 수 없습니다.")
            return

        # file 정보 조회 api 각각 호출하기
        chat_document_client = ChatDocumentClient()
        agent_document_client = AgentDocumentClient()

        try:
            chat_documents = await chat_document_client.get_chat_documents(chat_id)
            agent_documents = await agent_document_client.get_agent_documents(agent_id)

            # chat_documents 처리
            for doc in chat_documents:
                file_info = doc.get("file", {})
                if file_info:
                    file_content = self._create_file_json(file_info)
                    self.message_manager.add_message(
                        state=state,
                        message_type=MessageType.FILE,
                        content=file_content,
                        description="",
                        key="",
                    )

            # agent_documents 처리
            for doc in agent_documents:
                file_info = doc.get("file", {})
                if file_info:
                    file_content = self._create_file_json(file_info)
                    self.message_manager.add_message(
                        state=state,
                        message_type=MessageType.FILE,
                        content=file_content,
                        description="",
                        key="",
                    )

        except Exception as e:
            logger.error(f"[Reporter] 파일 정보 조회 중 오류 발생: {str(e)}")

    def _create_file_json(self, file_info: dict) -> str:
        """파일 정보를 JSON 형식으로 변환하는 헬퍼 메서드"""
        try:
            filename = file_info.get("original_filename", "unknown_file")
            file_size = file_info.get("file_size", 0)
            file_type = file_info.get("file_type", "unknown")

            # 파일 크기를 KB 형식으로 변환
            if isinstance(file_size, (int, float)) and file_size > 0:
                file_size_kb = f"{file_size / 1024:.2f}KB"
            else:
                file_size_kb = "0KB"

            # 파일 타입에서 확장자 추출
            if "/" in file_type:
                file_extension = file_type.split("/")[-1]
            else:
                file_extension = file_type

            file_json = {
                "filename": filename,
                "file_size": file_size_kb,
                "file_type": file_extension,
            }

            return json.dumps(file_json, ensure_ascii=False)

        except Exception as e:
            logger.error(f"[Reporter] 파일 JSON 생성 중 오류: {str(e)}")
            return json.dumps(
                {"filename": "error", "file_size": "0KB", "file_type": "unknown"},
                ensure_ascii=False,
            )

    async def _handle_summary_and_followup(self, state: State, response: dict):
        """전체 내용 요약 및 추가 질문 유도 처리"""
        try:
            # 요약과 추가 질문을 하나의 프롬프트로 통합 생성
            combined_message = await self._generate_summary_and_followup(state)

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.TOKEN,
                content=combined_message,
                description="",
                key="",
            )

            logger.info("[Reporter] 요약 및 추가 질문 유도 메시지 생성 완료")

        except Exception as e:
            logger.error(f"[Reporter] 요약 및 추가 질문 유도 처리 중 오류: {str(e)}")

    async def _generate_summary_and_followup(self, state: State) -> str:
        """요약과 추가 질문을 하나의 프롬프트로 통합 생성"""
        try:
            user_query = state.get("user_query", "")
            tool_calling_history = state.get("tool_calling_history", [])
            step_plan = state.get("step_plan", [])

            # 완료된 작업 내용 요약
            completed_tasks = []
            for step in step_plan:
                step_name = step.get("name", "")
                if step_name:
                    completed_tasks.append(step_name)

            tasks_summary = (
                ", ".join(completed_tasks) if completed_tasks else "요청하신 작업"
            )

            # 통합 프롬프트 생성
            combined_prompt = f"""
사용자의 요청: "{user_query}"
완료된 작업: {tasks_summary}

주요 실행 결과:
"""

            # 도구 실행 결과 요약 추가
            if tool_calling_history:
                for i, history in enumerate(tool_calling_history, 1):
                    if isinstance(history, dict):
                        tool_name = history.get("tool", "도구")
                        result = history.get("result", "")
                        if result:
                            # 결과가 너무 길면 축약
                            if len(str(result)) > 200:
                                result = str(result)[:200] + "..."
                            combined_prompt += f"- {tool_name}: {result}\n"

            combined_prompt += """

위 내용을 바탕으로 다음 두 가지를 포함한 자연스러운 메시지를 생성해주세요:

1. 작업 내용을 간결하게 요약
2. 마지막에 "사용자의 [요청 내용 간략 요약] 요청에 따라 작업을 진행했습니다. 더 [구체적인 도움 내용]한 점이 있으시면 언제든 요청해주세요." 형식의 자연스러운 마무리 멘트

- 전체적으로 정중하고 자연스러운 톤으로 작성
- 요약과 마무리 멘트가 자연스럽게 연결되도록 구성
"""

            # LLM 호출
            chat_messages = [
                (
                    "system",
                    "당신은 작업 완료 후 요약과 자연스러운 마무리 메시지를 생성하는 전문가입니다.",
                ),
                ("human", combined_prompt),
            ]

            session_id = state.get("chat_id")
            response = self.llm.invoke(
                chat_messages, config=get_llm_config(session_id) if session_id else None
            )

            # 응답에서 텍스트 추출
            if hasattr(response, "content"):
                combined_text = response.content
            else:
                combined_text = str(response)

            # 따옴표 제거 및 정리
            combined_text = combined_text.strip().strip('"').strip("'")

            return combined_text

        except Exception as e:
            logger.error(f"[Reporter] 통합 메시지 생성 중 오류: {str(e)}")
            return "요청하신 작업을 완료했습니다. 더 궁금한 점이 있으시면 언제든 요청해주세요."
