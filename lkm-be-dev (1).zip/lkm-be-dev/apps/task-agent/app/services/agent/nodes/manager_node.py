from typing import Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI

from core.log.logging import get_logging
from services.agent.message_types import MessageType
from services.agent.nodes.base_node import BaseNode
from services.agent.state import State, clear_view_messages

logger = get_logging()

MAX_RETRY_COUNT = 2  # 최대 재시도 횟수


class ManagerNode(BaseNode):
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        super().__init__(llm)

    async def __call__(self, state: State) -> State:
        """상태 관리 및 스텝 종료 처리"""
        self._log_node_start("Manager")

        # view_messages 초기화
        clear_view_messages(state)

        # 재시도 로직 체크 - 실패한 액션이 있고 재시도 가능한 경우
        last_failed_action = state.get("last_failed_action")
        retry_count = state.get("retry_count", 0)

        if last_failed_action and retry_count < MAX_RETRY_COUNT:
            logger.info(
                f"[Manager] Detected failed action, retry count: {retry_count}/{MAX_RETRY_COUNT}"
            )
            state["next"] = "retry_executor"
            return state

        # 최대 재시도 횟수를 초과한 경우 해당 액션을 건너뛰고 다음으로 진행
        if last_failed_action and retry_count >= MAX_RETRY_COUNT:
            logger.warning(
                f"[Manager] Maximum retry count exceeded for action: {last_failed_action.get('action', {}).get('name', 'Unknown')}"
            )

            # 재시도 관련 정보 초기화
            state.pop("last_failed_action", None)
            state.pop("retry_count", None)

            # 액션을 건너뛰고 다음으로 진행
            state["current_step_action_order"] = (
                state.get("current_step_action_order", 0) + 1
            )
            state["action_order"] = state.get("action_order", 0) + 1

            # 최종 실패 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_FAIL,
                content=f"Action Permanently Failed",
                description=f"최대 재시도 횟수 초과로 액션 실행 포기",
                key=str(last_failed_action.get("action", {}).get("id", "")),
            )

        # step_plan이 없거나 이미 모든 step이 완료된 경우 (초기 상태 또는 최종 상태)
        step_plan = state.get("step_plan", [])
        step_order = state.get("step_order", 0)
        if not step_plan or step_order >= len(step_plan):
            state["next"] = "reporter"
            logger.info(
                f"[Manager] No step plan or all steps already processed. Next: {state.get('next')}"
            )
            return state

        current_step_index = step_order
        current_step = step_plan[current_step_index]
        current_step_actions = current_step.get("actions", [])
        current_step_action_order = state.get("current_step_action_order", 0)

        logger.info(
            f"[Manager] Current step: {current_step.get('name')} (Order: {current_step.get('order')}), "
            f"Action order: {current_step_action_order}/{len(current_step_actions)}"
        )

        # 현재 step의 모든 action이 완료되었는지 확인
        if current_step_action_order >= len(current_step_actions):
            logger.info(
                f"[Manager] Step '{current_step.get('name')}' (Order: {current_step.get('order')}) actions completed. Sending STEP_END."
            )

            # 스텝 종료 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.STEP_END,
                content=f"{current_step.get('name')}",
                description=current_step.get("description", ""),
                key=str(current_step.get("id")),
            )

            # 다음 step으로 이동 준비
            current_step_order = state.get("step_order", 0)
            state["step_order"] = current_step_order + 1
            state["current_step_action_order"] = 0  # 새 스텝을 위해 액션 순서 리셋

            # 모든 step이 완료되었는지 확인 (다음 step_order가 전체 스텝 수를 넘어설 때)
            if state.get("step_order", 0) >= len(step_plan):
                logger.info(
                    "[Manager] All steps in the plan have been completed. Moving to reporter."
                )
                state["next"] = "reporter"
                return state
            else:
                # 다음 스텝이 남아있음
                next_step_info = step_plan[state.get("step_order", 0)]
                logger.info(
                    f"[Manager] Moving to next step: '{next_step_info.get('name')}' (Order: {next_step_info.get('order')}). Next: executor"
                )

                # 새 스텝 시작 메시지 추가
                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.STEP_START,
                    content=f"{next_step_info.get('name')}",
                    description=next_step_info.get("description", ""),
                    key=str(next_step_info.get("id")),
                )

                state["next"] = "executor"
                return state

        # 아직 현재 스텝의 액션이 남아있는 경우
        # 첫 번째 액션인 경우 스텝 시작 메시지 추가
        if state.get("current_step_action_order", 0) == 0:
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.STEP_START,
                content=f"{current_step.get('name')}",
                description=current_step.get("description", ""),
                key=str(current_step.get("id")),
            )

        action_plan = state.get("action_plan", [])
        action_order = state.get("action_order", 0)
        # action_order 범위 체크
        if action_order >= len(action_plan):
            logger.error(
                f"[Manager] action_order {action_order} out of range for action_plan length {len(action_plan)}"
            )
            state["next"] = "reporter"
            return state

        # 현재 액션 정보 가져오기 (로깅용)
        current_action = action_plan[action_order]

        logger.info(
            f"[Manager] Current step '{current_step.get('name')}' has pending actions. Next action: {current_action.get('name')}"
        )

        state["next"] = "executor"
        return state
