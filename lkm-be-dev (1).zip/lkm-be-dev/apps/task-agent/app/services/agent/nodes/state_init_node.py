import uuid
from typing import Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI

from services.agent.message_types import MessageType
from services.agent.nodes.base_node import BaseNode
from services.agent.state import State, clear_view_messages


class StateInitNode(BaseNode):
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        super().__init__(llm)  # agent_id는 나중에 설정

    async def __call__(self, state: State) -> State:
        """상태 초기화"""
        self._log_node_start("StateInit")

        # view_messages 초기화
        clear_view_messages(state)

        self.message_manager.add_message(
            state=state,
            message_type=MessageType.START,
            content="",
            description="",
            key="",
        )

        intro_message = (
            f"최적의 결과를 제공하기 위해 사용자 요청을 분석하고 있습니다.\n"
        )
        self.message_manager.add_message(
            state=state,
            message_type=MessageType.TOKEN,
            content=intro_message,
            key=str(uuid.uuid4()),
        )

        # 기본 상태 초기화
        state["step_plan"] = []
        state["action_plan"] = []
        state["step_order"] = 0
        state["current_step_action_order"] = 0
        state["action_order"] = 0
        state["tool_calling_history"] = []
        chat_id = state.get("chat_id")
        if not chat_id:
            return state

        return state
