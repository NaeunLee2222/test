from datetime import datetime
from typing import Any, Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.state import State
from services.agent.message_types import MessageType
from services.agent.nodes.base_node import BaseNode
from services.agent.state import State, clear_view_messages
from services.tools.documentation_tool import get_documentation_tools
from services.tools.tool_executor import ToolError, ToolExecutor

logger = get_logging()
settings = get_setting()


class ExecutorNode(BaseNode):
    """실행 에이전트"""

    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        super().__init__(llm)  # agent_id는 나중에 설정
        self.available_tools: dict = get_documentation_tools()
        self.tool_executor = ToolExecutor(self.llm)

    async def __call__(self, state: State) -> State:
        """도구 실행"""
        self._log_node_start("Executor")

        # view_messages 초기화
        clear_view_messages(state)

        try:
            step_plan = state.get("step_plan", [])
            step_order = state.get("step_order", 0)
            if not step_plan or step_order >= len(step_plan):
                state["next"] = "reporter"
                return state

            # 현재 step 가져오기
            current_step = step_plan[step_order]
            current_step_actions = current_step.get("actions", [])
            current_step_action_order = state.get("current_step_action_order", 0)
            action_order = state.get("action_order", 0)
            action_plan = state.get("action_plan", [])

            # action이 없는 step인 경우 바로 완료 처리
            if len(current_step_actions) == 0:
                logger.info(
                    f"[Executor] Step {current_step.get('order')} has no actions - marking as complete"
                )

                state["current_step_action_order"] = 0  # 다음 step을 위해 리셋
                state["next"] = "manager"
                return state

            # step 내의 모든 action이 완료된 경우
            if current_step_action_order >= len(current_step_actions):
                state["next"] = "manager"
                return state

            # action_order 범위 체크
            if action_order >= len(action_plan):
                logger.error(
                    f"[Executor] action_order {action_order} out of range for action_plan length {len(action_plan)}"
                )
                state["next"] = "manager"
                return state

            # 현재 action 가져오기 (step 내에서)
            current_action = action_plan[action_order]
            tool_info = current_action.get("tool")

            logger.info(f"[Executor] tool_info: {tool_info}")

            # 액션 시작 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_START,
                content=f"{current_action.get('name')}",
                description=current_action.get("description", ""),
                key=str(current_action.get("id")),
            )
            # 액션 컨텍스트 생성 - LLM이 더 정확한 파라미터를 생성할 수 있도록
            action_context = self._build_action_context(
                state,
                current_step,
                current_action,
                step_order,
                state.get("action_order", 0),
                len(current_step_actions),
            )

            converted_params = await self.tool_executor.convert_parameters(
                tool_info,
                action_context,  # 단순한 description 대신 풍부한 컨텍스트
                state["tool_calling_history"],
                state["user_query"],
                state["messages_list"],
                state["tool_document_mapping"],
                state["chat_id"],
                state["agent_id"],
            )

            # 현재 실행 파라미터를 state에 저장
            state["current_action_params"] = converted_params

            result = await self.tool_executor.execute_tool(tool_info, converted_params)

            # 결과 검증 - 에러 메시지인지 확인
            if self._is_failed_result(result):
                # ToolError 객체에서 상세 정보 추출
                error_info = result  # result가 ToolError 객체

                # 실패 정보를 state에 저장
                state["last_failed_action"] = {
                    "action": current_action,
                    "tool_info": tool_info,
                    "converted_params": converted_params,
                    "failure_type": (
                        f"tool_error_{error_info.tool_type}"
                        if error_info.tool_type
                        else "tool_error"
                    ),
                    "failure_reason": error_info.message,
                    "tool_error_details": {
                        "tool_name": error_info.tool_name,
                        "tool_type": error_info.tool_type,
                        "message": error_info.message,
                    },
                }
                state["retry_count"] = state.get("retry_count", 0)

                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_FAIL,
                    content=f"{current_action.get('name')}",
                    description=error_info.message,
                    key=str(current_action.get("id")),
                )

                # action_order와 current_step_action_order는 증가시키지 않음 (재시도를 위해)
                state["next"] = "manager"
                return state

            # 액션 성공 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_SUCCESS,
                content=f"{current_action.get('name')}",
                description=f"{tool_info.get('name')}",
                key=str(current_action.get("id")),
            )

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_START,
                content=f"ㅤㅤ• [{tool_info.get('type', 'MCP').upper()} 도구] {tool_info.get('name', '')} - {tool_info.get('description', '')}",
                description="",
                key=str(current_action.get("id")),
            )

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_SUCCESS,
                content=f"ㅤㅤ• [{tool_info.get('type', 'MCP').upper()} 도구] {tool_info.get('name', '')} - {tool_info.get('description', '')}",
                description="",
                key=str(current_action.get("id")),
            )

            messages = state.get("messages", [])
            # 상세한 실행 정보를 messages에 저장
            step_plan = state.get("step_plan", [])
            step_order = state.get("step_order", 0)
            current_step = step_plan[step_order] if step_order < len(step_plan) else {}

            # ToolError 객체인 경우 딕셔너리로 변환하여 저장
            result_for_state = (
                result.to_dict() if isinstance(result, ToolError) else result
            )
            is_success = not isinstance(result, ToolError)

            detailed_message = {
                "timestamp": datetime.now().isoformat(),
                "step_info": {
                    "step_order": step_order,
                    "step_name": current_step.get("name", "Unknown"),
                    "step_description": current_step.get("description", ""),
                },
                "action_info": {
                    "action_order": state.get("action_order", 0),
                    "action_name": current_action.get("name", "Unknown"),
                    "action_description": current_action.get("description", ""),
                    "action_id": str(current_action.get("id", "")),
                },
                "tool_info": {
                    "tool_name": tool_info.get("name", "Unknown"),
                    "tool_type": tool_info.get("type", "unknown"),
                    "tool_description": tool_info.get("description", ""),
                },
                "execution": {
                    "success": is_success,
                    "parameters": converted_params,
                    "result": result_for_state,
                    "result_type": "success" if is_success else "error",
                },
            }

            # 에러인 경우 추가 정보
            if isinstance(result, ToolError):
                detailed_message["error_details"] = {
                    "error_message": result.message,
                    "tool_name": result.tool_name,
                    "tool_type": result.tool_type,
                }

            messages.append(detailed_message)
            state["messages"] = messages

            # tool_calling_history에 상세한 실행 기록 저장
            tool_calling_history = state.get("tool_calling_history", [])

            history_entry = {
                "timestamp": datetime.now().isoformat(),
                "execution_id": f"exec_{step_order}_{state.get('action_order', 0)}_{datetime.now().strftime('%H%M%S')}",
                "step_context": {
                    "step_order": step_order,
                    "step_name": current_step.get("name", "Unknown"),
                    "step_description": current_step.get("description", ""),
                    "step_id": str(current_step.get("id", "")),
                },
                "action_context": {
                    "action_order": state.get("action_order", 0),
                    "current_step_action_order": state.get(
                        "current_step_action_order", 0
                    ),
                    "action_name": current_action.get("name", "Unknown"),
                    "action_description": current_action.get("description", ""),
                    "action_id": str(current_action.get("id", "")),
                },
                "tool_execution": {
                    "tool_name": tool_info.get("name", "Unknown"),
                    "tool_type": tool_info.get("type", "unknown"),
                    "tool_description": tool_info.get("description", ""),
                    "tool_config": tool_info.get("config", {}),
                    "parameters_used": converted_params,
                    "success": is_success,
                    "result": result_for_state,
                    "result_summary": str(result)[:200] if result else "No result",
                },
                "user_context": {
                    "user_query": state.get("user_query", ""),
                    "chat_id": state.get("chat_id", ""),
                    "agent_id": state.get("agent_id", ""),
                },
            }

            # 에러인 경우 추가 정보
            if isinstance(result, ToolError):
                history_entry["error_info"] = {
                    "error_type": "tool_error",
                    "error_message": result.message,
                    "tool_name": result.tool_name,
                    "tool_type": result.tool_type,
                    "is_retryable": True,
                }

            tool_calling_history.append(history_entry)
            state["tool_calling_history"] = tool_calling_history

            # current_step_action_order와 action_order 증가
            state["current_step_action_order"] = (
                state.get("current_step_action_order", 0) + 1
            )
            state["action_order"] = state.get("action_order", 0) + 1

            logger.info(
                f"[Executor] Action completed. current_step_action_order: {state.get('current_step_action_order', 0)}, total_actions: {len(current_step_actions)}"
            )

            state["next"] = "manager"
            return state

        except Exception as e:
            logger.error(f"[Executor] Error in ExecutorAgent: {str(e)}")

            # 실패 정보를 state에 저장
            action_plan = state.get("action_plan", [])
            action_order = state.get("action_order", 0)
            if action_order < len(action_plan):
                current_action = action_plan[action_order]
                tool_info = current_action.get("tool")

                # 일반 예외 처리
                failure_type = "general_exception"
                failure_reason = str(e)

                state["last_failed_action"] = {
                    "action": current_action,
                    "tool_info": tool_info,
                    "converted_params": (
                        converted_params if "converted_params" in locals() else {}
                    ),
                    "failure_type": failure_type,
                    "failure_reason": failure_reason,
                    "tool_error_details": None,
                }
                state["retry_count"] = state.get("retry_count", 0)

                # 액션 실패 메시지 추가
                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_FAIL,
                    content=f"{current_action.get('name')}",
                    description=f"{failure_reason}",
                    key=str(current_action.get("id")),
                )
            else:
                state["last_failed_action"] = {
                    "action": None,
                    "tool_info": None,
                    "converted_params": {},
                    "failure_type": "action_order_error",
                    "failure_reason": f"action_order {action_order} out of range",
                    "tool_error_details": None,
                }
                state["retry_count"] = state.get("retry_count", 0)

                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_FAIL,
                    content="Action Fail",
                    description=f"{str(e)}",
                    key=str(current_action.get("id")),
                )

            messages = state.get("messages", [])

            # 상세한 예외 정보를 messages에 저장
            step_plan = state.get("step_plan", [])
            step_order = state.get("step_order", 0)
            current_step = step_plan[step_order] if step_order < len(step_plan) else {}

            exception_message = {
                "timestamp": datetime.now().isoformat(),
                "step_info": {
                    "step_order": step_order,
                    "step_name": current_step.get("name", "Unknown"),
                    "step_description": current_step.get("description", ""),
                },
                "action_info": {
                    "action_order": action_order,
                    "action_name": (
                        current_action.get("name", "Unknown")
                        if action_order < len(action_plan)
                        else "Unknown"
                    ),
                    "action_description": (
                        current_action.get("description", "")
                        if action_order < len(action_plan)
                        else ""
                    ),
                    "action_id": (
                        str(current_action.get("id", ""))
                        if action_order < len(action_plan)
                        else ""
                    ),
                },
                "tool_info": {
                    "tool_name": (
                        tool_info.get("name", "Unknown")
                        if action_order < len(action_plan)
                        else "Unknown"
                    ),
                    "tool_type": (
                        tool_info.get("type", "unknown")
                        if action_order < len(action_plan)
                        else "unknown"
                    ),
                    "tool_description": (
                        tool_info.get("description", "")
                        if action_order < len(action_plan)
                        else ""
                    ),
                },
                "execution": {
                    "success": False,
                    "parameters": (
                        converted_params if "converted_params" in locals() else {}
                    ),
                    "result": None,
                    "result_type": "exception",
                },
                "error_details": {
                    "error_type": "general_exception",
                    "error_message": str(e),
                    "exception_type": type(e).__name__,
                },
            }

            messages.append(exception_message)
            state["messages"] = messages

            # tool_calling_history에 예외 정보도 기록
            tool_calling_history = state.get("tool_calling_history", [])

            # 예외 발생 시에도 실행 기록 저장
            history_entry = {
                "timestamp": datetime.now().isoformat(),
                "execution_id": f"exec_{step_order}_{action_order}_{datetime.now().strftime('%H%M%S')}_exception",
                "step_context": {
                    "step_order": step_order,
                    "step_name": current_step.get("name", "Unknown"),
                    "step_description": current_step.get("description", ""),
                    "step_id": str(current_step.get("id", "")),
                },
                "action_context": {
                    "action_order": action_order,
                    "current_step_action_order": state.get(
                        "current_step_action_order", 0
                    ),
                    "action_name": (
                        current_action.get("name", "Unknown")
                        if action_order < len(action_plan)
                        else "Unknown"
                    ),
                    "action_description": (
                        current_action.get("description", "")
                        if action_order < len(action_plan)
                        else ""
                    ),
                    "action_id": (
                        str(current_action.get("id", ""))
                        if action_order < len(action_plan)
                        else ""
                    ),
                },
                "tool_execution": {
                    "tool_name": (
                        tool_info.get("name", "Unknown")
                        if action_order < len(action_plan)
                        else "Unknown"
                    ),
                    "tool_type": (
                        tool_info.get("type", "unknown")
                        if action_order < len(action_plan)
                        else "unknown"
                    ),
                    "tool_description": (
                        tool_info.get("description", "")
                        if action_order < len(action_plan)
                        else ""
                    ),
                    "tool_config": (
                        tool_info.get("config", {})
                        if action_order < len(action_plan)
                        else {}
                    ),
                    "parameters_used": (
                        converted_params if "converted_params" in locals() else {}
                    ),
                    "success": False,
                    "result": None,
                    "result_summary": f"Exception occurred: {str(e)[:200]}",
                },
                "user_context": {
                    "user_query": state.get("user_query", ""),
                    "chat_id": state.get("chat_id", ""),
                    "agent_id": state.get("agent_id", ""),
                },
                "error_info": {
                    "error_type": "general_exception",
                    "error_message": str(e),
                    "exception_type": type(e).__name__,
                    "is_retryable": True,
                    "failure_stage": "tool_execution",
                },
            }

            tool_calling_history.append(history_entry)
            state["tool_calling_history"] = tool_calling_history

            # 오류 발생 시에는 action_order를 증가시키지 않음 (재시도를 위해)
            state["next"] = "manager"
            return state

    # DB에서 가져온 도구 정보로 실제 도구 객체를 찾아 매핑하는 함수
    def get_function_tool(self, tool_info: dict) -> Any:
        tool_name = tool_info.get("name")
        try:
            return self.available_tools[tool_name]
        except KeyError:
            return None

    def _is_failed_result(self, result: Any) -> bool:
        """도구 실행 결과가 에러인지 판단"""
        return result.get("success", False) is False

    def _build_action_context(
        self,
        state: State,
        current_step: dict,
        current_action: dict,
        step_order: int,
        action_order: int,
        total_step_actions: int,
    ) -> str:
        """액션 실행을 위한 상세한 컨텍스트 생성"""

        step_plan = state.get("step_plan", [])
        total_steps = len(step_plan)
        current_step_action_order = state.get("current_step_action_order", 0)

        # 이전 액션들의 결과 요약
        previous_results = []
        messages = state.get("messages", [])
        for msg in messages[-3:]:  # 최근 3개 결과만
            if isinstance(msg, dict) and "execution" in msg:
                tool_name = msg.get("tool_info", {}).get("tool_name", "Unknown")
                success = msg.get("execution", {}).get("success", False)
                result_summary = msg.get("execution", {}).get(
                    "result_summary", "No summary"
                )
                previous_results.append(
                    f"- {tool_name}: {'성공' if success else '실패'} ({result_summary[:100]})"
                )

        previous_results_text = (
            "\n".join(previous_results) if previous_results else "이전 실행 결과 없음"
        )

        # 액션 컨텍스트 구성
        context = f"""
=== 작업 컨텍스트 ===
사용자 요청: {state.get("user_query", "No query")}

=== 현재 위치 ===
전체 진행: Step {step_order + 1}/{total_steps} - "{current_step.get('name', 'Unknown Step')}"
Step 설명: {current_step.get('description', 'No description')}
Step 내 진행: Action {current_step_action_order + 1}/{total_step_actions}

=== 현재 액션 정보 ===
액션명: {current_action.get('name', 'Unknown Action')}
액션 설명: {current_action.get('description', 'No description')}
전체 액션 순서: {action_order + 1}번째 액션

=== 이전 실행 결과 ===
{previous_results_text}

=== 현재 액션의 목적 ===
이 액션은 "{current_step.get('name', 'Unknown Step')}" 단계에서 "{current_action.get('name', 'Unknown Action')}"를 수행하여 
사용자의 "{state.get("user_query", "No query")}" 요청을 해결하는 데 기여해야 합니다.

위 컨텍스트를 바탕으로 도구 실행에 필요한 정확하고 구체적인 파라미터를 생성해주세요.
        """.strip()

        return context
