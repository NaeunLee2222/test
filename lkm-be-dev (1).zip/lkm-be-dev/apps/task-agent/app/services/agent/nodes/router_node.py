from ast import Dict
from typing import Any, Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI

from core.config import get_setting
from core.log.logging import get_logging
from services.agent.nodes.base_node import BaseNode
from services.agent.state import State, clear_view_messages
from services.step_plan_service import StepPlanService

logger = get_logging()
settings = get_setting()


class RouterNode(BaseNode):
    def __init__(self, agent_id: int, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        super().__init__(llm)
        self.agent_id = agent_id
        self.step_plan_service = StepPlanService()

    async def __call__(self, state: State) -> State:
        self._log_node_start("Router")

        # view_messages 초기화
        clear_view_messages(state)

        logger.info(f"[Router] User query: {state['user_query']}")
        state["messages_list"].append(("human", state["user_query"]))

        logger.info(f"[Router] Next step -> {state['next']}")
        if state.get("safety") == "unsafe":
            state["next"] = "finish"
            state["view_messages"].append({"Reporter": state["safety_message"]})
        else:
            state["next"] = "planner"

        agent_info = self.step_plan_service.get_agent_info(self.agent_id)
        agent_config = dict()
        agent_config["agent_name"] = agent_info.name
        agent_config["agent_description"] = agent_info.description

        state["agent_id"] = self.agent_id
        state["agent_config"] = agent_config
        return state

    # def _setup_prompts(self) -> None:
    #     self.system_prompt = prompt_service.get_prompts(
    #         get_current_user_info().company_code
    #     )["Analyze_User_Query_System_Prompt"]
    #     self.user_prompt = prompt_service.get_prompts(
    #         get_current_user_info().company_code
    #     )["Analyze_User_Query_User_Prompt"]

    # async def __call__(self, state: State) -> State:
    #     self._log_node_start("Router")
    #     logger.info(f"[Router] User query: {state['user_query']}")
    #     state["messages_list"].append(("human", state["user_query"]))

    #     if settings.CONFIRM_ENABLED:
    #         if state["comeback_node"] != "":
    #             query_type = await self._analyze_user_query(state)
    #             if query_type == "MODIFY" or query_type == "ACCEPT":
    #                 state["next"] = state["comeback_node"]
    #                 state["comeback_node"] = ""
    #             elif query_type == "REJECT":
    #                 state["comeback_node"] = ""
    #                 state = await state_init(state)
    #                 state["next"] = "reporter"
    #             else:
    #                 state["comeback_node"] = ""
    #                 state = await state_init(state)
    #                 state["next"] = "selector"
    #         else:
    #             state["next"] = "selector"
    #     else:
    #         state["next"] = "selector"

    #     logger.info(f"[Router] Next step -> {state['next']}")
    #     state["view_messages"].append({"Router": f"Next step -> {state['next']}"})
    #     return state

    async def _invoke_llm_async(self, prompt: Any, chat_id: str) -> Dict:
        """LLM 호출 공통 메서드 (비동기)"""
        structured_llm = self.llm.with_structured_output(prompt.OutputFormat)
        response = await structured_llm.ainvoke(
            [
                ("system", prompt.make_system_prompt()),
                ("human", prompt.make_user_prompt()),
            ],
            config=get_llm_config(chat_id),
        )
        return response.model_dump()
