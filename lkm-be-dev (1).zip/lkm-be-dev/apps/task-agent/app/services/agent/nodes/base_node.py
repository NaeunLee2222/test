from typing import Any, Dict, Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI

from core.config import get_setting
from core.llm import get_llm_config
from core.log.logging import get_logging
from services.agent.message_manager import MessageManager
from services.agent.state import State
from services.prompt.prompt_service import PromptService

logger = get_logging()
settings = get_setting()


def manage_history(state: State) -> tuple:
    """히스토리 관리 공통 함수"""
    user_basic_info = state["messages_list"][0][1].split("\n")[1:]
    if len(state["messages"]) > 0:
        history = state["messages"]
    elif (len(state["messages_list"]) >= 3) and (len(state["messages"]) == 0):
        history = state["messages_list"][1:]
    else:
        history = "No chatting history"
    return user_basic_info, history


class BaseNode:
    """모든 노드의 기본 클래스"""

    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        self.llm = llm
        self.message_manager = MessageManager()
        self.prompt_service = PromptService()

    def _log_node_start(self, node_name: str) -> None:
        """노드 시작 로깅"""
        logger.info(f"[{node_name}] Agent started")

    def _log_llm_response(self, node_name: str, response: Any) -> None:
        """LLM 응답 로깅"""
        logger.debug(f"[{node_name}] LLM response: {response}")

    def _setup_prompts(self) -> None:
        """프롬프트 설정을 위한 기본 메서드"""
        pass

    def _invoke_llm(self, prompt: Any, chat_id: str) -> Dict:
        """LLM 호출 공통 메서드"""
        structured_llm = self.llm.with_structured_output(prompt.OutputFormat)
        response = structured_llm.invoke(
            [
                ("system", prompt.make_system_prompt()),
                ("human", prompt.make_user_prompt()),
            ],
            config=get_llm_config(chat_id),
        )
        return response.model_dump()

    async def _invoke_llm_async(self, prompt: Any, chat_id: str) -> Dict:
        """LLM 호출 공통 메서드 (비동기)"""
        structured_llm = self.llm.with_structured_output(prompt.OutputFormat)
        response = await structured_llm.ainvoke(
            [
                ("system", prompt.make_system_prompt()),
                ("human", prompt.make_user_prompt()),
            ],
            config=get_llm_config(chat_id),
        )
        return response.model_dump()
