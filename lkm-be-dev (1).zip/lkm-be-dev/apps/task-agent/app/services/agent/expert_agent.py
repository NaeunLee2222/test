from typing import Any, Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langgraph.graph import END, START, StateGraph

from core.config import get_setting
from core.log.logging import get_logging
from services.agent.agents import (
    ExecutorAgent,
    ManagerAgent,
    PlannerAgent,
    RecorderAgent,
    ReporterAgent,
    ReverseQuestionerAgent,
    RouterAgent,
)
from services.agent.base_agent import BaseAgent
from services.agent.state import State

# from services.prompt.prompt_service import PromptService

logger = get_logging()
settings = get_setting()
# prompt_service = PromptService()


class ExpertAgent(BaseAgent):
    """회의실 예약 및 관리를 위한 에이전트"""

    def __init__(
        self, llm: Union[ChatOpenAI, AzureChatOpenAI], agent_id: int, canvas: str
    ):
        super().__init__(llm)
        self.agent_id = agent_id
        self.canvas = canvas



    async def get_graph(self) -> Any:
        """전체 워크플로우 그래프 구성"""
        # tools, agent_tool_info = self._prepare_tools()

        # 각 에이전트 초기화
        router = RouterAgent(self.agent_id, self.llm).get_agent()

        # planner = PlannerAgent(self.agent_id, self.llm, tools).get_agent()
        # executor = ExecutorAgent(self.agent_id, self.llm, tools).get_agent()
        planner = PlannerAgent(self.llm).get_agent()
        executor = await ExecutorAgent(self.llm).get_agent()
        reverse_questioner = ReverseQuestionerAgent(self.llm).get_agent()
        manager = ManagerAgent(self.llm).get_agent()
        reporter = ReporterAgent(self.llm, self.canvas).get_agent()
        recorder = RecorderAgent().get_agent()

        # 워크플로우 구성
        workflow = StateGraph(State)

        # 노드 추가
        workflow.add_node("router", router)
        workflow.add_node("planner", planner)
        workflow.add_node("executor", executor)
        # workflow.add_node("reverse_questioner", reverse_questioner)
        workflow.add_node("manager", manager)
        workflow.add_node("reporter", reporter)
        workflow.add_node("recorder", recorder)

        # 엣지 추가
        workflow.add_edge(START, "router")

        workflow.add_conditional_edges(
            "router",
            lambda x: x["next"],
            {"end": END, "planner": "planner"},
        )

        workflow.add_conditional_edges(
            "planner",
            lambda x: x["next"],
            ["manager", "reporter"],
        )

        # workflow.add_edge("executor", "reverse_questioner")

        # def route_after_reverse_questioner(state: State) -> str:
        #     if state.get("needs_clarification", False):
        #         return END
        #     return "manager"

        # workflow.add_conditional_edges(
        #     "reverse_questioner",
        #     route_after_reverse_questioner,
        #     {END: END, "manager": "manager"},
        # )
        workflow.add_edge("executor", "manager")

        workflow.add_conditional_edges(
            "manager",
            lambda x: x["next"],
            ["executor", "reporter"],
        )

        workflow.add_conditional_edges(
            "reporter",
            lambda x: x["next"],
            [END, "recorder"],
        )
        workflow.add_edge("recorder", END)

        return workflow.compile()
