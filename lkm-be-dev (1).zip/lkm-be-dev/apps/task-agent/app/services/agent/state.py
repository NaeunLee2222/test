import operator
from typing import Annotated, Any, Dict, List, Tuple

from langchain_core.messages import BaseMessage
from typing_extensions import TypedDict


def merge_dicts(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Recursively merge two dictionaries.
    For nested dictionaries, it performs a deep merge.
    For other types, values from dict2 override those from dict1.
    """
    result = dict1.copy()
    for key, value in dict2.items():
        if isinstance(value, dict) and key in result and isinstance(result[key], dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    return result


class State(TypedDict, total=False):
    # messages: Annotated[List[BaseMessage], add_messages]
    messages: List[Dict]
    context: str
    result: bool
    question: str
    next: str
    prompt_tokens: Annotated[float, operator.add]
    completion_tokens: Annotated[float, operator.add]
    cost: Annotated[float, operator.add]
    params: Annotated[Dict[str, Any], merge_dicts]
    debug: Dict[str, Any]
    past_steps: Annotated[List[Tuple], operator.add]
    response: str
    needs_clarification: bool
    tool_calling_history: List
    last_failed_action: dict
    retry_count: int
    failure_analysis: dict  # AI 기반 실패 분석 결과
    current_action_params: dict  # 현재 실행중인 액션의 파라미터

    function_list: List
    user_query: str
    # plan: List

    agent_id: int
    agent_config: dict
    step_plan: List
    action_plan: List

    step_order: int
    action_order: int
    current_step_action_order: int  # 현재 step 내에서의 action 순서

    plan_analysis: str
    progress_status: Dict
    messages_list: List
    ask_user_params: List

    function_response: List
    view_messages: List
    default_params: Dict
    chat_id: str
    conditions: str
    dynamic_prompts: List
    safety: str
    safety_message: str

    # supervisor node
    branch: str
    is_reply: bool = False

    # websearch state
    need_web_search: bool
    need_web_search_reason: str
    need_question: bool
    clarify_reason: str
    search_num: int
    searched_results: List[Dict[str, Any]]
    re_query: str
    # llm_result: str

    # meeting note
    start_recording: bool

    # preferred_info
    preferred_info: str

    # rag
    chat_documents_summary: Dict[int, str]  # doc_id: summary
    agent_documents_summary: Dict[int, str]  # doc_id: summary
    tool_document_mapping: Dict[
        str, Dict[str, List[int]]
    ]  # tool_name: {chat_documents: [doc_id], agent_documents: [doc_id]}


def get_last_state(state: State) -> dict:
    return {
        "messages": [state["messages"][-1]],
        "breakpoint_on": state.get("breakpoint_on"),
    }


def join_graph(response: dict) -> dict:
    """
    response["messages"] is sequence of BaseMessage.
    """

    msg = response["messages"][-1]
    if isinstance(msg, BaseMessage):
        return {
            "messages": [msg],
            "prompt_tokens": response["prompt_tokens"],
            "completion_tokens": response["completion_tokens"],
            "cost": response["cost"],
            "breakpoint_on": response.get("breakpoint_on"),
        }
    else:
        raise Exception("Can not parsing sub agent's result to to common State")


def clear_view_messages(state: State) -> State:
    """
    모든 에이전트에서 다음 에이전트로 넘어갈 때 view_messages를 초기화하는 공통 함수
    """
    state["view_messages"] = []
    return state
