import json
import re
from typing import List, Optional

from sqlalchemy.orm import Session

from core.log.logging import get_logging
from database.crud.crud_tool import CRUDToolSync
from services.agent.base_agent import BaseAgent
from services.schemas.expert_agent.agent_model import (
    ActionWithTools,
    ExpertAgentDetail,
    ExpertAgentSchema,
    StepBase,
    StepWithActions,
    ToolSchema,
)

logger = get_logging()
crud_tool = CRUDToolSync()


class ExpertAgentBuilder(BaseAgent):
    async def build_agent(
        self, agent_base: ExpertAgentSchema, steps: List[StepBase]
    ) -> ExpertAgentDetail:
        """
        에이전트 기본 정보와 Step 목록을 받아 상세 Action과 Tool이 포함된 ExpertAgentDetail을 생성합니다.
        현재는 모킹 데이터를 사용합니다.
        """
        # Step 별 Action 및 Tool 자동 구성 (모킹 데이터)
        steps_with_actions = []

        for i, step in enumerate(steps):
            actions_with_tools = []

            # Step 별로 샘플 Action 생성
            if step.name == "의도분석":
                actions = [
                    {
                        "name": "문서분석",
                        "description": "업무 절차서를 통해 업무의 핵심요소 파악",
                        "order": 1,
                        "tool_name": "File Uploader",
                    },
                    {
                        "name": "데이터 추출",
                        "description": "문서내 데이터 추출 및 분석",
                        "order": 2,
                        "tool_name": None,
                    },
                ]
            elif step.name == "취급 문서 검색":
                actions = [
                    {
                        "name": "관계분석",
                        "description": "여러 데이터 간의 관계 파악",
                        "order": 1,
                        "tool_name": "Prompt",
                    },
                    {
                        "name": "Ocean-H 검색",
                        "description": "관련 자료 검색",
                        "order": 2,
                        "tool_name": "Ocean-H DB",
                    },
                    {
                        "name": "Temp. RFQ 매칭 검색",
                        "description": "기존 RFQ 검색",
                        "order": 3,
                        "tool_name": "Temp. DB",
                    },
                    {
                        "name": "관계 분석 산출",
                        "description": "검색 결과 분석",
                        "order": 4,
                        "tool_name": "Canvas",
                    },
                    {
                        "name": "사용자에게 파일 Upload 요청",
                        "description": "추가 파일 요청",
                        "order": 5,
                        "tool_name": "File Uploader",
                    },
                ]
            elif step.name == "RFQ 초안작성":
                actions = [
                    {
                        "name": "RFQ 기본템플릿 로드",
                        "description": "표준 템플릿 로드",
                        "order": 1,
                        "tool_name": None,
                    },
                    {
                        "name": "문서 기본 정보 추출",
                        "description": "핵심 정보 추출",
                        "order": 2,
                        "tool_name": None,
                    },
                    {
                        "name": "필요 추가정보",
                        "description": "추가 정보 수집",
                        "order": 3,
                        "tool_name": None,
                    },
                    {
                        "name": "Feedback DB 검색",
                        "description": "과거 피드백 검토",
                        "order": 4,
                        "tool_name": "Feedback DB",
                    },
                    {
                        "name": "Feedback 작성 및 표시",
                        "description": "피드백 작성",
                        "order": 5,
                        "tool_name": None,
                    },
                    {
                        "name": "Canvas로 출력",
                        "description": "시각화",
                        "order": 6,
                        "tool_name": "Canvas",
                    },
                    {
                        "name": "문서 내보내기",
                        "description": "최종 문서 추출",
                        "order": 7,
                        "tool_name": "문서처리 툴",
                    },
                ]
            elif step.name == "검증":
                actions = [
                    {
                        "name": "검증목적",
                        "description": "검증 진행 목적 설명",
                        "order": 1,
                        "tool_name": None,
                    },
                    {
                        "name": "검증 단계별 중점항목 확인",
                        "description": "주요 검증 항목",
                        "order": 2,
                        "tool_name": None,
                    },
                    {
                        "name": "검증 결과 및 검증 결과 출력",
                        "description": "검증 결과 요약",
                        "order": 3,
                        "tool_name": "Canvas",
                    },
                    {
                        "name": "RFQ 수정이 필요한 경우 수정 검사 분석",
                        "description": "수정사항 검토",
                        "order": 4,
                        "tool_name": None,
                    },
                ]
            else:
                actions = [
                    {
                        "name": f"{step.name} 기본 액션",
                        "description": f"{step.name} 단계의 기본 액션입니다",
                        "order": 1,
                        "tool_name": None,
                    }
                ]

            for j, action in enumerate(actions):
                tools = []
                if action["tool_name"]:
                    # 모의 도구 생성
                    tool = ToolSchema(
                        name=action["tool_name"],
                        description=f"{action['tool_name']} 도구입니다",
                        type="api" if "DB" in action["tool_name"] else "utility",
                    )
                    tools.append(tool)

                # 액션 정보 생성
                action_with_tools = ActionWithTools(
                    name=action["name"],
                    description=action["description"],
                    order=action["order"],
                    tools=tools,
                )
                actions_with_tools.append(action_with_tools)

            # 스텝 정보 생성
            step_with_actions = StepWithActions(
                name=step.name,
                description=step.description,
                order=step.order,
                actions=actions_with_tools,
            )
            steps_with_actions.append(step_with_actions)

        # Agent Detail 생성
        agent_detail = ExpertAgentDetail(
            name=agent_base.name,
            description=agent_base.description,
            category=agent_base.category,
            usage_scope=agent_base.usage_scope,
            org_id=agent_base.org_id,
            team_id=agent_base.team_id,
            created_user_id=agent_base.created_user_id,
            steps=steps_with_actions,
            use_count=agent_base.use_count,
            review_status=agent_base.review_status,
            agent_type=agent_base.agent_type,
        )

        return agent_detail

    async def recommend_steps(
        self, name: str, description: str, file_path: Optional[str] = None
    ) -> List[StepBase]:
        """
        에이전트 이름, 설명 및 선택적으로 문서 파일을 기반으로 Step을 추천합니다.
        일단 Mock을 주기
        """
        try:
            logger.info(f"Recommend steps for agent: {name}")
            logger.info(f"Description: {description}")
            logger.info(f"File path: {file_path}")

            steps = [
                StepBase(
                    name="의도분석",
                    description="사용자 요청의 의도를 파악합니다",
                    order=1,
                ),
                StepBase(
                    name="최근 문서 검색",
                    description="관련 최신 문서를 검색합니다",
                    order=2,
                ),
                StepBase(
                    name="RFQ 초안 작성",
                    description="요청에 맞는 RFQ 초안을 작성합니다",
                    order=3,
                ),
                StepBase(
                    name="검증",
                    description="작성된 문서를 검토하고 검증합니다",
                    order=4,
                ),
            ]

            return steps

        except Exception as e:
            logger.error(f"Error recommending steps: {e}")
            raise

    async def recommend_step_action(
        self,
        db: Session,
        agent_name: str,
        agent_description: str,
        file_content: Optional[str] = None,
    ) -> List[StepWithActions]:
        """
        에이전트 이름, 설명, 파일 내용을 기반으로 Step과 Action을 함께 추천합니다.

        Args:
            db: 데이터베이스 세션
            agent_name: 에이전트 이름
            agent_description: 에이전트 설명
            file_content: 관련 파일 내용

        Returns:
            List[StepWithActions]: Step과 Action이 포함된 추천 목록
        """
        try:
            logger.info(f"Recommend step action for agent: {agent_name}")
            logger.info(f"Description: {agent_description}")
            logger.info(
                f"File content length: {len(file_content) if file_content else 0}"
            )

            # 1. DB에서 사용 가능한 도구 목록 가져오기
            available_tools = crud_tool.get_tools(db)
            available_tools_dict = {}
            for tool in available_tools:
                available_tools_dict[tool.name] = {
                    "id": tool.id,
                    "name": tool.name,
                    "description": tool.description,
                    "type": tool.type,
                    "icon_path": tool.icon_path,
                    "config": tool.config,
                    "tool_group_id": tool.tool_group_id,
                    "tool_group_name": tool.tool_group_name,
                }

            # initial_plan_step = [
            #     StepWithActions(
            #         name="계획 수립",
            #         description="업무지시서를 분석하여 계획 수립을 합니다",
            #         order=1,
            #         actions=[
            #             ActionWithTools(
            #                 name="계획 수립",
            #                 description="업무지시서를 분석하여 계획 수립을 합니다",
            #                 order=1,
            #                 tools=(
            #                     [
            #                         ToolSchema(
            #                             id=available_tools_dict.get(
            #                                 "intent_analysis", {}
            #                             ).get("id"),
            #                             name="intent_analysis",
            #                             description=available_tools_dict.get(
            #                                 "intent_analysis", {}
            #                             ).get(
            #                                 "description",
            #                                 "업무지시서를 분석하여 계획 수립을 합니다",
            #                             ),
            #                             type=available_tools_dict.get(
            #                                 "intent_analysis", {}
            #                             ).get("type", "mcp"),
            #                             icon_path=available_tools_dict.get(
            #                                 "intent_analysis", {}
            #                             ).get("icon_path", ""),
            #                             config=available_tools_dict.get(
            #                                 "intent_analysis", {}
            #                             ).get("config", {}),
            #                             tool_group_id=available_tools_dict.get(
            #                                 "intent_analysis", {}
            #                             ).get("tool_group_id", 1),
            #                             tool_group_name=available_tools_dict.get(
            #                                 "intent_analysis", {}
            #                             ).get("tool_group_name", "계획 수립"),
            #                         )
            #                     ]
            #                     if "intent_analysis" in available_tools_dict
            #                     else []
            #                 ),
            #             ),
            #             ActionWithTools(
            #                 name="할 일 목록 생성",
            #                 description="분석된 요구사항을 바탕으로 할 일 목록을 생성합니다",
            #                 order=2,
            #                 tools=(
            #                     [
            #                         ToolSchema(
            #                             id=available_tools_dict.get(
            #                                 "make_todo_list", {}
            #                             ).get("id"),
            #                             name="make_todo_list",
            #                             description=available_tools_dict.get(
            #                                 "make_todo_list", {}
            #                             ).get("description", "할 일 목록을 생성합니다"),
            #                             type=available_tools_dict.get(
            #                                 "make_todo_list", {}
            #                             ).get("type", "mcp"),
            #                             icon_path=available_tools_dict.get(
            #                                 "make_todo_list", {}
            #                             ).get("icon_path", ""),
            #                             config=available_tools_dict.get(
            #                                 "make_todo_list", {}
            #                             ).get("config", {}),
            #                             tool_group_id=available_tools_dict.get(
            #                                 "make_todo_list", {}
            #                             ).get("tool_group_id", 1),
            #                             tool_group_name=available_tools_dict.get(
            #                                 "make_todo_list", {}
            #                             ).get("tool_group_name", "계획 수립"),
            #                         )
            #                     ]
            #                     if "make_todo_list" in available_tools_dict
            #                     else []
            #                 ),
            #             ),
            #         ],
            #     )
            # ]

            # 3. Step과 Action 추천을 위한 프롬프트 생성
            step_action_prompt = self._create_step_action_prompt(
                agent_name=agent_name,
                agent_description=agent_description,
                file_content=file_content,
                available_tools=available_tools_dict,
            )

            # 4. LLM 호출
            work_response = self.llm.invoke(step_action_prompt).content
            logger.info(f"LLM Response: {work_response}")

            # 5. 실제 작업 단계 파싱
            work_steps = self._parse_step_action_response(
                str(work_response), available_tools_dict
            )

            # 6. planning step과 work step을 합쳐서 전체 steps_with_actions 생성
            # steps_with_actions = initial_plan_step + work_steps
            steps_with_actions = work_steps

            return steps_with_actions

        except Exception as e:
            logger.error(f"Error recommending step action: {e}")
            # 오류 발생시 기본 Step 반환
            return self._get_default_steps()

    def _create_step_action_prompt(
        self,
        agent_name: str,
        agent_description: str,
        file_content: Optional[str] = None,
        available_tools: Optional[dict] = None,
    ) -> str:
        """Step과 Action 추천을 위한 프롬프트를 생성합니다."""

        # 사용 가능한 도구 목록을 문자열로 포맷팅
        available_tools_str = ""
        if available_tools:
            grouped_tools = {}
            for tool_name, tool_info in available_tools.items():
                group_name = tool_info.get("tool_group_name") or "기타"
                if group_name not in grouped_tools:
                    grouped_tools[group_name] = []
                grouped_tools[group_name].append(
                    f"- {tool_name}: {tool_info['description']}"
                )

            for group_name, tool_strings in grouped_tools.items():
                available_tools_str += f"\n[{group_name}]\n"
                available_tools_str += "\n".join(tool_strings)
            available_tools_str += "\n"
        else:
            available_tools_str = "사용 가능한 도구가 없습니다."

        # agent_description 변환

        prompt = f"""다음 정보를 바탕으로 Step과 Action 구조로 변환해주세요.

[에이전트 정보]
- 이름: {agent_name}
- 설명: {agent_description}

[관련 문서 내용]
{file_content if file_content else "관련 문서가 없습니다."}

[주요 데이터 소스 및 접근 방법]
- RFQ 관련 내용: 반드시 DB를 통해 정보를 추출해야 합니다. 'db_router' 툴을 사용해 어떤 DB에서 데이터를 가져올지 결정한 후, 'searchrdb' 툴을 사용해 데이터를 조회하는 순서로 Action을 구성해야 합니다.
- 직무별 인적 정보
- 위험 메뉴얼 파일 경로
- 제조 관련 머신러닝 모델 경로
- 철강 제조 공정별 공정 파라미터 정보
- 제품 불량 테스트 결과

[사용 가능한 도구]
{available_tools_str}

[용어 정의]
Step (업무 단계): AI Agent가 특정 업무를 달성하기 위해 따라야 하는 논리적 작업 흐름입니다. Step은 '무엇을(What)'을 해야 하는지 명확히 정의하며, 명확한 입력과 기대 출력이 존재합니다. 복잡한 업무를 관리 가능한 단위로 분리하는 역할을 합니다.
Action (구체 동작): 각 Step을 수행하기 위해 필요한 구체적이고 세부적인 처리 단위입니다. Action은 실행 가능한 수준의 명령으로, '어떻게(How)' 목표를 달성할지 정의합니다.
Tool (도구): Action을 실행하기 위해 사용되는 구체적인 수단이나 서비스입니다. 제공된 도구 목록에서만 선택해야 합니다. 도구는 그룹별로 정리되어 있습니다.

###지침###
1. 각 Step은 명확한 목표와 결과물을 가져야 합니다. ex) 견적서 초안 생성, 구매 요청서 작성 등
2. 각 Step은 하나 이상의 Action으로 구성되어야 합니다. Action은 실행 가능한 구체적 동작이어야 합니다. ex) 문서 논리 검토, 문서 간 차이점 분석 등
3. 각 Action은 반드시 하나의 Tool을 사용해야 하며, 이 Tool은 제공된 도구 목록에서 선택해야 합니다.
4. Step은 '무엇을(What)' 하는지, Action은 '어떻게(How)' 하는지에 초점을 맞춰 작성해주세요.
5. 모든 이름과 설명은 명확하고 구체적으로 작성해주세요.
6. order 필드는 반드시 1부터 시작하는 연속된 숫자여야 합니다.
7. JSON 형식을 정확히 지켜주세요.
9. 에이전트의 목적과 관련 문서 내용을 바탕으로 적절한 Step과 Action을 구성해주세요.

[출력 형식]
다음 JSON 형식으로 응답해주세요:
[
    {{
        "name": "Step 이름",
        "description": "Step에 대한 상세 설명 (무엇을 달성하는지 명확히)",
        "order": 1,
        "actions": [
            {{
                "name": "Action 이름",
                "description": "Action에 대한 상세 설명 (어떻게 실행하는지 구체적으로)",
                "order": 1,
                "tool": {{
                    "name": "사용할 도구 이름",
                    "description": "도구 사용 목적 및 방법",
                    "tool_group_id": 1,
                    "tool_group_name": "데이터베이스"
                }}
            }}
        ]
    }}
]

[예시]
[
    {{
        "name": "견적서 생성",
        "description": "견적서 에 필요한 원시 데이터를 식별하고 접근하는 단계 (무엇을: 분석 대상 데이터 확보)",
        "order": 1,
        "actions": [
            {{
                "name": "데이터베이스 연결",
                "description": "분석 대상 데이터베이스에 보안 인증을 통해 연결 (어떻게: 자격 증명 입력 후 연결 프로토콜 실행)",
                "order": 1,
                "tool": {{
                    "name": "db_connect",
                    "description": "데이터베이스 연결 설정 및 인증 처리"
                    "tool_group_id": 1,
                    "tool_group_name": "데이터베이스"
                }}
            }},
            {{
                "name": "데이터 쿼리 실행",
                "description": "필요한 데이터를 추출하기 위한 SQL 쿼리 실행 (어떻게: 최적화된 쿼리문 작성 및 실행)",
                "order": 2,
                "tool": {{
                    "name": "sql_query",
                    "description": "SQL 쿼리를 실행하여 데이터 추출"
                    "tool_group_id": 1,
                    "tool_group_name": "데이터베이스"
                }}
            }}
        ]
    }}
]"""

        return prompt

    def _parse_step_action_response(
        self, response: str, available_tools: dict
    ) -> List[StepWithActions]:
        """LLM 응답을 파싱하여 StepWithActions 목록으로 변환합니다."""
        try:
            # JSON 문자열 추출
            json_match = re.search(r"```json\n(.*?)\n```", response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_str = response

            steps_json = json.loads(json_str)
            steps_with_actions = []

            for step_data in steps_json:
                # Action 리스트 생성
                actions = []
                for action_data in step_data.get("actions", []):
                    # Tool 연결
                    tools = []
                    if "tool" in action_data and action_data["tool"]:
                        tool_name = action_data["tool"]["name"]
                        if tool_name in available_tools:
                            # DB에서 가져온 실제 도구로 매칭
                            tool_info = available_tools[tool_name]
                            tool_schema = ToolSchema(
                                id=tool_info["id"],
                                name=tool_info["name"],
                                description=tool_info["description"],
                                type=tool_info["type"],
                                icon_path=tool_info["icon_path"],
                                config=tool_info["config"],
                                tool_group_id=tool_info.get("tool_group_id"),
                                tool_group_name=tool_info.get("tool_group_name"),
                            )
                            tools.append(tool_schema)
                        else:
                            logger.warning(
                                f"Tool {tool_name} not found in available tools"
                            )
                            continue

                    action = ActionWithTools(
                        name=action_data["name"],
                        description=action_data["description"],
                        order=action_data["order"],
                        tools=tools,
                    )
                    actions.append(action)

                # Step 생성
                step = StepWithActions(
                    name=step_data["name"],
                    description=step_data["description"],
                    order=step_data["order"],
                    actions=actions,
                )
                steps_with_actions.append(step)

            return steps_with_actions

        except Exception as e:
            logger.error(f"Error parsing LLM response: {str(e)}")
            return self._get_default_steps()

    def _get_default_steps(self) -> List[StepWithActions]:
        """오류 발생시 반환할 기본 Step 목록을 생성합니다."""
        default_action = ActionWithTools(
            name="기본 작업 수행",
            description="에이전트의 기본 작업을 수행합니다",
            order=1,
            tools=[],
        )

        default_step = StepWithActions(
            name="기본 업무 처리",
            description="에이전트의 기본적인 업무를 처리하는 단계입니다",
            order=1,
            actions=[default_action],
        )

        return [default_step]
