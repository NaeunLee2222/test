# app/agent/agents.py
import json
import os
import re
from ast import literal_eval
from datetime import datetime
from typing import Any, Dict, List, Union

import aiohttp
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langgraph.graph import END, START, StateGraph
from sqlalchemy import select

from core.config import get_setting
from core.llm import get_llm_config
from core.log.logging import get_logging
from core.utils.time import get_kor_nowtime
from database.crud.crud_expert_agent import CRUDExpertAgent
from database.models.expert_agent.expert_agent import (
    GeneralAgentInstruction,
    GeneralAgentInstructionTool,
    ProcedureDocument,
    Tool,
)
from database.session import AsyncSessionLocal
from services.action_plan_service import ActionPlanService
from services.agent.message_manager import MessageManager
from services.agent.message_types import MessageType
from services.agent.state import State, clear_view_messages
from services.prompt.ai_slide_prompt import create_ai_slide_prompt
from services.prompt.general_chat_prompt import PROCEDURE_PROMPT
from services.prompt.models.agent import (
    ReplannerPrompt,
    ReporterPrompt,
    ReverseQuestionerPrompt,
    ReviewerPrompt,
)
from services.prompt.planner_prompt import (
    FILTER_STEPS_PROMPT_TEMPLATE,
    FilteredStepsResponse,
)
from services.prompt.prompt_service import PromptService
from services.step_plan_service import StepPlanService
from services.tools.documentation_tool import get_documentation_tools
from services.tools.tool_executor import ToolExecutor

settings = get_setting()
prompt_service = PromptService()
action_plan_service = ActionPlanService()
crud_agent = CRUDExpertAgent()

logger = get_logging()


def manage_history(state: State) -> State:
    user_basic_info = state["messages_list"][0][1].split("\n")[1:]
    if len(state["messages"]) > 0:
        history = state["messages"]

    elif (len(state["messages_list"]) >= 3) and (len(state["messages"]) == 0):
        history = state["messages_list"][1:]

    else:
        history = "No chatting history"

    return user_basic_info, history


class RouterAgent:
    def __init__(self, agent_id: int, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        self.llm = llm
        self.agent_id = agent_id
        self.step_plan_service = StepPlanService()
        self.message_manager = MessageManager()

    def router(self, state: State) -> State:
        logger.info("[Router] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        logger.info(f"[Router] User query: {state['user_query']}")
        state["messages_list"].append(("human", state["user_query"]))
        # import pdb

        # pdb.set_trace()
        logger.info(f"[Router] Next step -> {state['next']}")
        if state["safety"] == "unsafe":
            state["next"] = "end"
            state["view_messages"].append({"Reporter": state["safety_message"]})

        agent_info = self.step_plan_service.get_agent_info(self.agent_id)
        agent_config = dict()
        agent_config["agent_name"] = agent_info.name
        agent_config["agent_description"] = agent_info.description

        state["agent_id"] = self.agent_id
        state["agent_config"] = agent_config
        return state

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("router", self.router)

        workflow.add_edge(START, "router")
        workflow.add_edge("router", END)
        return workflow.compile()


class PlannerAgent:
    def __init__(
        self,
        llm: Union[ChatOpenAI, AzureChatOpenAI],
    ) -> None:
        self.llm = llm
        self.system_prompt = prompt_service.get_prompts()["Planner_System_Prompt"]
        self.user_prompt = prompt_service.get_prompts()["Planner_User_Prompt"]
        self.step_plan_service = StepPlanService()
        self.message_manager = MessageManager()

    async def filter_steps_by_llm(
        self, state: State, initial_step_plan: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """사용자 쿼리를 기반으로 LLM을 사용하여 전체 step plan에서 필요한 step만 필터링합니다."""
        user_query = state["user_query"]
        _, history = manage_history(state)  # history 추출

        # initial_step_plan을 JSON 문자열로 변환 (프롬프트에 포함하기 위해)
        # action 내부의 tool 객체는 문자열로 변환 시 문제가 될 수 있으므로, 간단한 정보만 포함하도록 조정
        simplified_steps_for_prompt = []
        for step in initial_step_plan:
            simplified_actions = []
            for action in step.get("actions", []):
                action_info = {
                    "name": action.get("name"),
                    "description": action.get("description"),
                }
                # tool 정보는 간략하게 (필요하다면 tool의 name 정도만)
                if action.get("tool") and isinstance(action["tool"], dict):
                    action_info["tool_name"] = action["tool"].get("name")
                    action_info["tool_description"] = action["tool"].get("description")
                simplified_actions.append(action_info)
            simplified_steps_for_prompt.append(
                {
                    "order": step.get("order"),
                    "name": step.get("name"),
                    "description": step.get("description"),
                    "actions": simplified_actions,
                }
            )
        steps_str = json.dumps(
            simplified_steps_for_prompt, ensure_ascii=False, indent=4
        )

        prompt = FILTER_STEPS_PROMPT_TEMPLATE.format(
            user_query=user_query, steps_str=steps_str, history=history
        )  # history 추가

        chat_messages = [("system", prompt), ("human", user_query)]
        session_id = state["chat_id"]

        structured_llm = self.llm.with_structured_output(FilteredStepsResponse)
        try:
            response = structured_llm.invoke(
                chat_messages, config=get_llm_config(session_id)
            )
            logger.info(f"[Planner] FilteredStepsResponse from LLM: {response}")

            if not response or not response.selected_steps:
                logger.warning(
                    "[Planner] LLM did not return any selected steps. Falling back to initial full step plan."
                )
                # return initial_step_plan # 모든 step을 반환하거나, 상황에 따라 빈 리스트를 반환할 수 있음
                return []  # LLM이 빈 배열을 반환하면 그대로 빈 배열을 사용

            # LLM이 반환한 selected_steps의 order 순서를 그대로 사용하여 filtered_steps를 구성합니다.
            # 중복된 order도 허용합니다 (LLM이 동일 step 반복을 의도한 경우).
            filtered_steps = []
            original_steps_map = {step["order"]: step for step in initial_step_plan}

            for selected_step_info in response.selected_steps:
                order = selected_step_info.order
                if order in original_steps_map:
                    # 원본 step 객체의 복사본을 추가하여 원본 initial_step_plan이 변경되지 않도록 함
                    filtered_steps.append(original_steps_map[order].copy())
                else:
                    logger.warning(
                        f"[Planner] LLM selected order {order} which is not in the original step plan. Skipping."
                    )

            if not filtered_steps:
                logger.warning(
                    "[Planner] No valid steps were selected by LLM or all selected orders were invalid. Returning empty list."
                )
                return []

            logger.info(
                f"[Planner] Filtered steps based on LLM (preserving LLM's order and allowing duplicates): {filtered_steps}"
            )
            return filtered_steps

        except Exception as e:
            logger.error(f"[Planner] Error in filter_steps_by_query: {str(e)}")
            # 오류 발생 시 fallback: 초기 전체 plan을 그대로 사용하거나, 빈 리스트 반환
            # return initial_step_plan
            return []  # 오류 발생 시 빈 리스트 반환으로 변경 (더 안전한 기본값)

    def selector(self, state: State) -> State:
        # view_messages 초기화
        clear_view_messages(state)

        user_basic_info, history = manage_history(state)

        logger.info("[Selector] Agent started")
        current_time = get_kor_nowtime()

        # 동적 프롬프트 가져오기
        # prompt_service = PromptService()
        # dynamic_prompts = prompt_service.get_dynamic_prompts()
        # conditions = []
        # seen_conditions = set()
        # for p in dynamic_prompts:
        #     if p["condition"] and p["condition"] not in seen_conditions:
        #         conditions.append((p["condition"], p["condition_description"]))
        #         seen_conditions.add(p["condition"])

        # 조건 평가를 위한 프롬프트 생성
        # prompt = SelectorPrompt(
        #     agent_config=state["agent_config"],
        #     user_query=state["user_query"],
        #     history=history,
        #     current_time=current_time,
        #     system_prompt=self.selector_system_prompt,
        #     user_prompt=self.selector_user_prompt,
        #     # conditions=conditions,
        # )

        # system_prompt = prompt.make_system_prompt()
        # user_prompt = prompt.make_user_prompt()
        # output_format = prompt.OutputFormat

        # chat_messages = [
        #     ("system", system_prompt),
        #     ("human", user_prompt),
        # ]
        # session_id = state["chat_id"]
        # structured_llm = self.llm.with_structured_output(output_format)
        # response = structured_llm.invoke(
        #     chat_messages, config=get_llm_config(session_id)
        # )
        # response = response.model_dump()

        # logger.info(f"[SELECTOR] LLM response: {response}")

        # # 매칭된 조건들을 state에 저장
        # matching_conditions = response.get("conditions", [])
        # # matching_prompts = [
        # #     (p["node"], p["prompt_snippet"])
        # #     for p in dynamic_prompts
        # #     if p["condition"] in matching_conditions
        # # ]

        # logger.info(f"[SELECTOR] Matching conditions: {matching_conditions}")

        # if "dynamic_prompts" in state:
        #     state["dynamic_prompts"].extend(
        #         [i for i in matching_prompts if i not in state["dynamic_prompts"]]
        #     )
        # else:
        #     state["dynamic_prompts"] = [t for t in matching_prompts]

        return state

    async def planner(self, state: State) -> State:
        # view_messages 초기화
        clear_view_messages(state)

        logger.info("[Planner] Agent started")

        agent_info = self.step_plan_service.get_agent_info(state["agent_id"])

        step_plan = []
        action_plan_with_tools = []
        # if agent["type"] == "pro":
        # 스텝 플랜 가져오기
        step_plan = self.step_plan_service.get_agent_steps(agent_info)

        if step_plan and agent_info.agent_type == "pro":
            # Pro 에이전트의 경우 기존 step_plan 사용하면서 action_plan_with_tools도 생성

            step_plan = await self.filter_steps_by_llm(state, step_plan)

            action_plan = []
            for step in step_plan:
                action_plan.extend(step["actions"])

            action_plan_with_tools = action_plan_service.get_actions_with_tools(
                action_plan
            )

        else:
            # General 에이전트의 경우 step_plan 생성
            action_plan_with_tools, step_plan = await self.make_general_chat_plan(state)

        # --- 공통 후처리 로직 ---
        if (
            step_plan
        ):  # Pro 또는 General 에이전트로부터 step_plan이 성공적으로 결정된 경우
            plan_content = ", ".join(
                [s.get("name", "이름 없는 스텝") for s in step_plan]  # 변수명 step -> s
            )
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.PLAN_START,
                content=plan_content,
                description="",
                key="",
            )

            state["step_plan"] = step_plan
            state["action_plan"] = action_plan_with_tools  # 여기서 최종 할당
            state["step_order"] = 0
            state["current_step_action_order"] = 0
            state["action_order"] = 0

            tool_names = []
            if action_plan_with_tools:
                for (
                    action_item
                ) in action_plan_with_tools:  # 변수명 action -> action_item
                    tool_info = action_item.get("tool")
                    if tool_info and isinstance(tool_info, dict):
                        tool_name = tool_info.get("name")
                        if tool_name:
                            tool_names.append(tool_name)

            state["messages"].append(
                {"Query": state["user_query"], "Used_tool": tool_names}
            )
            state["next"] = "manager"
        else:
            # step_plan이 최종적으로 없는 경우 (Pro에서 필터링 결과 0개, General에서 생성 실패 등)
            state["step_plan"] = []
            state["action_plan"] = []
            state["step_order"] = 0
            state["current_step_action_order"] = 0
            state["action_order"] = 0
            state["next"] = "reporter"

        return state

    async def make_general_chat_plan(self, state):
        # 일반 에이전트의 경우 데이터베이스에서 instruction과 tools 가져오기
        db = None  # db 변수 초기화
        try:
            # history 가져오기
            user_basic_info, history = manage_history(state)

            async with AsyncSessionLocal() as db:
                # ProcedureDocument 조회
                procedure_document_stmt = select(ProcedureDocument).where(
                    ProcedureDocument.expert_agent_id == state["agent_id"],
                )
                procedure_document_result = await db.execute(procedure_document_stmt)
                procedure_document = procedure_document_result.scalars().first()

                if procedure_document:
                    procedure_document_str = procedure_document.original_filename
                    file_path = os.path.join(
                        settings.FILE_UPLOAD_DIR, procedure_document.filename
                    )
                    with open(file_path, "r", encoding="utf-8") as f:
                        procedure_document_str = f.read()
                else:
                    procedure_document_str = "업무절차서가 없습니다."

                # GeneralAgentInstruction 조회
                instruction_stmt = select(GeneralAgentInstruction).where(
                    GeneralAgentInstruction.expert_agent_id == state["agent_id"],
                )
                instruction_result = await db.execute(instruction_stmt)
                instruction = instruction_result.scalars().first()

                if not instruction:
                    logger.error(
                        f"[Planner] General agent instruction not found for agent_id: {state['agent_id']}"
                    )
                    return [], []

                # GeneralAgentInstructionTool을 통해 연결된 Tool 조회
                tool_stmt = (
                    select(Tool)
                    .join(
                        GeneralAgentInstructionTool,
                        Tool.id == GeneralAgentInstructionTool.tool_id,
                    )
                    .where(
                        GeneralAgentInstructionTool.expert_agent_instruction_id
                        == instruction.id
                    )
                )
                tool_result = await db.execute(tool_stmt)
                tools = tool_result.scalars().all()

                # 사용 가능한 도구 정보 구성
                available_tools = {}
                for tool in tools:
                    available_tools[tool.name] = {
                        "id": tool.id,
                        "name": tool.name,
                        "description": tool.description,
                        "endpoint": tool.endpoint,
                        "type": tool.type,
                        "config": tool.config,
                    }

                # history를 문자열로 포맷팅
                history_str = json.dumps(history, ensure_ascii=False, indent=2)

                # 일반 에이전트를 위한 프롬프트 생성
                prompt = PROCEDURE_PROMPT.format(
                    procedure=procedure_document_str,
                    user_query=state["user_query"],
                    available_tools_str=str(available_tools),
                    instruction=instruction.instruction
                    or "사용자의 요구사항을 바탕으로 적절한 Step과 Action을 구성해주세요.",
                    history=history_str,
                )

                # LLM 호출
                chat_messages = [("system", prompt), ("human", state["user_query"])]
                session_id = state["chat_id"]
                response = self.llm.invoke(
                    chat_messages, config=get_llm_config(session_id)
                )

                # 응답 파싱
                try:
                    # JSON 문자열 추출
                    content = response.content
                    json_match = re.search(r"```json\n(.*?)\n```", content, re.DOTALL)
                    if json_match:
                        json_str = json_match.group(1)
                    else:
                        json_str = content

                    steps_json = json.loads(json_str)
                    step_plan = []
                    action_plan = []

                    for step_data in steps_json:
                        # Step 생성
                        step = {
                            "id": f"temp_step_{step_data['order']}",
                            "expert_agent_id": state["agent_id"],
                            "name": step_data["name"],
                            "description": step_data["description"],
                            "order": step_data["order"],
                            "actions": [],
                        }
                        step_plan.append(step)

                        # Action 생성
                        for action_data in step_data["actions"]:
                            action = {
                                "id": f"temp_action_{step_data['order']}_{action_data['order']}",
                                "step_id": step["id"],
                                "name": action_data["name"],
                                "description": action_data["description"],
                                "order": action_data["order"],
                                "tool": None,
                            }

                            # Tool 연결
                            if "tool" in action_data and action_data["tool"]:
                                tool_name = action_data["tool"]["name"]
                                if tool_name in available_tools:
                                    action["tool"] = available_tools[tool_name]
                                else:
                                    logger.warning(
                                        f"Tool {tool_name} not found in available tools"
                                    )
                                    action["tool"] = {
                                        "id": f"temp_tool_{step_data['order']}_{action_data['order']}",
                                        "name": tool_name,
                                        "description": action_data["tool"][
                                            "description"
                                        ],
                                    }

                            step["actions"].append(action)
                            action_plan.append(action)

                    return action_plan, step_plan

                except Exception as e:
                    logger.error(f"[Planner] Error parsing LLM response: {str(e)}")
                    return [], []

        except Exception as e:
            logger.error(
                f"[Planner] Error getting general agent instruction and tools: {str(e)}"
            )
            return [], []

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("selector", self.selector)
        workflow.add_node("planner", self.planner)

        workflow.add_edge(START, "selector")
        workflow.add_edge("selector", "planner")
        workflow.add_edge("planner", END)
        return workflow.compile()


class ReviewerAgent:
    def __init__(
        self,
        llm: Union[ChatOpenAI, AzureChatOpenAI],
        tool_info: List[Dict[str, Any]],
    ):
        self.llm = llm
        self.tool_info = tool_info
        self.system_prompt = prompt_service.get_prompts()["Reviewer_System_Prompt"]
        self.user_prompt = prompt_service.get_prompts()["Reviewer_User_Prompt"]

    def reviewer(self, state: State) -> State:
        logger.info("[Reviewer] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        user_basic_info, history = manage_history(state)

        # dynamic_prompt = "\n"
        # for i in state["dynamic_prompts"]:
        #     if "reviewer" in i[0]:
        #         dynamic_prompt += "- " + i[1] + "\n"

        prompt = ReviewerPrompt(
            user_basic_info,
            state["agent_config"],
            self.tool_info,
            state["step_plan"],
            state["action_plan"],
            history,
            # system_prompt=self.system_prompt + dynamic_prompt,
            system_prompt=self.system_prompt,
            user_prompt=self.user_prompt,
        )

        system_prompt = prompt.make_system_prompt()
        user_prompt = prompt.make_user_prompt()
        output_format = prompt.make_output_format()

        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]
        session_id = state["chat_id"]
        structured_llm = self.llm.with_structured_output(output_format)
        response = structured_llm.invoke(
            chat_messages, config=get_llm_config(session_id)
        )
        response = response.model_dump()
        logger.debug(f"[Reviewer] LLM response: {response}")

        # Parse LLM response into nested dictionary
        parsed_response = {}
        for key, value in response.items():
            # Split key into function name and parameter
            parts = key.split("_")
            if len(parts) >= 2:
                function_name = parts[0]
                # Remove _enum suffix and function name from parameter
                param_name = (
                    "_".join(parts[1:-1])
                    if parts[-1] == "enum"
                    else "_".join(parts[1:])
                )

                # Initialize function dict if not exists
                if function_name not in parsed_response:
                    parsed_response[function_name] = {}

                # Add parameter and its value
                parsed_response[function_name][param_name] = value

        logger.debug(f"[Reviewer] Parsed response: {parsed_response}")
        ask_user_params = []

        for function_name, params in parsed_response.items():
            for param, status in params.items():
                if status == "USER_REQUIRED":
                    ask_user_params.append(param)

        if len(ask_user_params) == 0:
            if state["is_reply"]:
                state["next"] = "replanner"
            else:
                state["next"] = "executor"
        else:
            state["ask_user_params"] = ask_user_params
            state["next"] = "reverse_questioner"

        return state

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("reviewer", self.reviewer)
        workflow.add_edge(START, "reviewer")
        workflow.add_edge("reviewer", END)
        return workflow.compile()


class ReverseQuestionerAgent:
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        self.llm = llm
        self.system_prompt = prompt_service.get_prompts()[
            "ReverseQuestioner_System_Prompt"
        ]
        self.user_prompt = prompt_service.get_prompts()["ReverseQuestioner_User_Prompt"]

    def reverse_questioner(self, state: State) -> State:
        logger.info("[Reverse Questioner] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        user_basic_info, history = manage_history(state)

        # Get current plan and function responses
        plan = state.get("plan", [])
        function_response = state.get("function_response", [])

        prompt = ReverseQuestionerPrompt(
            user_basic_info,
            state["agent_config"],
            state["user_query"],
            history,
            plan=plan,
            function_response=function_response,
            system_prompt=self.system_prompt,
            user_prompt=self.user_prompt,
        )

        system_prompt = prompt.make_system_prompt()
        user_prompt = prompt.make_user_prompt()
        output_format = prompt.OutputFormat

        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]

        session_id = state["chat_id"]
        structured_llm = self.llm.with_structured_output(output_format)
        response = structured_llm.invoke(
            chat_messages, config=get_llm_config(session_id)
        )
        response = response.model_dump()

        logger.debug(f"[Reverse Questioner] LLM response: {response}")

        # Store whether clarification is needed
        state["needs_clarification"] = response["needs_clarification"]

        # Add response to view messages if there's a question
        if response["needs_clarification"] and response.get("question"):
            state["view_messages"].append({"Reverse Questioner": response["question"]})

        logger.info(
            f"[Reverse Questioner] Needs clarification: {state['needs_clarification']}"
        )
        logger.info(f"[Reverse Questioner] Question: {response['question']}")

        return state

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("reverse_questioner", self.reverse_questioner)

        workflow.add_edge(START, "reverse_questioner")
        workflow.add_edge("reverse_questioner", END)
        return workflow.compile()


class ManagerAgent:
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI]):
        self.llm = llm
        self.message_manager = MessageManager()

    def manager(self, state: State) -> State:
        """상태 관리 및 스텝 종료 처리"""
        logger.info("[Manager] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        # step_plan이 없거나 이미 모든 step이 완료된 경우 (초기 상태 또는 최종 상태)
        if not state.get("step_plan") or state["step_order"] >= len(state["step_plan"]):
            state["next"] = "reporter"
            logger.info(
                f"[Manager] No step plan or all steps already processed. Next: {state['next']}"
            )
            return state

        current_step_index = state["step_order"]
        current_step = state["step_plan"][current_step_index]
        current_step_actions = current_step.get("actions", [])

        logger.info(
            f"[Manager] Current step: {current_step['name']} (Order: {current_step['order']}), "
            f"Action order: {state['current_step_action_order']}/{len(current_step_actions)}"
        )

        # 현재 step의 모든 action이 완료되었는지 확인
        if state["current_step_action_order"] >= len(current_step_actions):
            logger.info(
                f"[Manager] Step '{current_step['name']}' (Order: {current_step['order']}) actions completed. Sending STEP_END."
            )

            # 스텝 종료 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.STEP_END,
                content=f"{current_step['name']}",
                description=current_step.get("description", ""),
                key=str(current_step["id"]),
            )

            # 다음 step으로 이동 준비
            state["step_order"] += 1
            state["current_step_action_order"] = 0  # 새 스텝을 위해 액션 순서 리셋

            # 모든 step이 완료되었는지 확인 (다음 step_order가 전체 스텝 수를 넘어설 때)
            if state["step_order"] >= len(state["step_plan"]):
                logger.info(
                    "[Manager] All steps in the plan have been completed. Moving to reporter."
                )
                state["next"] = "reporter"
                return state
            else:
                # 다음 스텝이 남아있음
                next_step_info = state["step_plan"][state["step_order"]]
                logger.info(
                    f"[Manager] Moving to next step: '{next_step_info['name']}' (Order: {next_step_info['order']}). Next: executor"
                )

                # 새 스텝 시작 메시지 추가
                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.STEP_START,
                    content=f"{next_step_info['name']}",
                    description=next_step_info.get("description", ""),
                    key=str(next_step_info["id"]),
                )

                state["next"] = "executor"
                return state

        # 아직 현재 스텝의 액션이 남아있는 경우
        # 첫 번째 액션인 경우 스텝 시작 메시지 추가
        if state["current_step_action_order"] == 0:
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.STEP_START,
                content=f"{current_step['name']}",
                description=current_step.get("description", ""),
                key=str(current_step["id"]),
            )

        # action_order 범위 체크
        if state["action_order"] >= len(state["action_plan"]):
            logger.error(
                f"[Manager] action_order {state['action_order']} out of range for action_plan length {len(state['action_plan'])}"
            )
            state["next"] = "reporter"
            return state

        # 현재 액션 정보 가져오기 (로깅용)
        current_action = state["action_plan"][state["action_order"]]

        logger.info(
            f"[Manager] Current step '{current_step['name']}' has pending actions. Next action: {current_action['name']}"
        )

        state["next"] = "executor"
        return state

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("manager", self.manager)

        workflow.add_edge(START, "manager")
        workflow.add_edge("manager", END)
        return workflow.compile()


class ExecutorAgent:
    """실행 에이전트"""

    def __init__(
        self,
        llm: Union[ChatOpenAI, AzureChatOpenAI],
    ) -> None:
        self.llm = llm
        self.tool_executor = ToolExecutor(self.llm)
        self.available_tools: dict = get_documentation_tools()
        self.message_manager = MessageManager()

    async def executor(self, state: State) -> State:
        """도구 실행"""
        logger.info("[Executor] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        try:
            if not state.get("step_plan") or state["step_order"] >= len(
                state["step_plan"]
            ):
                state["next"] = "reporter"
                return state

            # 현재 step 가져오기
            current_step = state["step_plan"][state["step_order"]]
            current_step_actions = current_step.get("actions", [])

            # action이 없는 step인 경우 바로 완료 처리
            if len(current_step_actions) == 0:
                logger.info(
                    f"[Executor] Step {current_step['order']} has no actions - marking as complete"
                )

                state["current_step_action_order"] = 0  # 다음 step을 위해 리셋
                state["next"] = "manager"
                return state

            # step 내의 모든 action이 완료된 경우
            if state["current_step_action_order"] >= len(current_step_actions):
                state["next"] = "manager"
                return state

            # action_order 범위 체크
            if state["action_order"] >= len(state["action_plan"]):
                logger.error(
                    f"[Executor] action_order {state['action_order']} out of range for action_plan length {len(state['action_plan'])}"
                )
                state["next"] = "manager"
                return state

            # 현재 action 가져오기 (step 내에서)
            current_action = state["action_plan"][state["action_order"]]
            tool_info = current_action["tool"]

            # 액션 시작 메시지 추가
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.ACTION_START,
                content=f"{current_action['name']}",
                description=current_action.get("description", ""),
                key=str(current_action["id"]),
            )

            converted_params = self.tool_executor.convert_parameters(
                tool_info,
                current_action["description"],
                state["tool_calling_history"],
                state["chat_id"],
                state["user_query"],
                state["messages_list"],
            )

            result = await self.tool_executor.execute_tool(tool_info, converted_params)

            if result is None or result == "":
                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_FAIL,
                    content=f"{current_action['name']}",
                    description=f"도구 실행 실패",
                    key=str(current_action["id"]),
                )
            else:
                # 액션 성공 메시지 추가
                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_SUCCESS,
                    content=f"{current_action['name']}",
                    description=f"{tool_info['name']}",
                    key=str(current_action["id"]),
                )

            state["messages"].append({"Action": tool_info["name"], "Result": result})
            state["tool_calling_history"].append(
                {"tool": tool_info["name"], "result": result}
            )

            # current_step_action_order와 action_order 증가
            state["current_step_action_order"] += 1
            state["action_order"] += 1

            logger.info(
                f"[Executor] Action completed. current_step_action_order: {state['current_step_action_order']}, total_actions: {len(current_step_actions)}"
            )

            state["next"] = "manager"
            return state

        except Exception as e:
            logger.error(f"[Executor] Error in ExecutorAgent: {str(e)}")

            # 액션 실패 메시지 추가
            if state["action_order"] < len(state["action_plan"]):
                current_action = state["action_plan"][state["action_order"]]
                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_FAIL,
                    content=f"{current_action['name']}",
                    description=f"{str(e)}",
                    key=str(current_action["id"]),
                )
            else:
                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.ACTION_FAIL,
                    content="Action Fail",
                    description=f"{str(e)}",
                    key=str(current_action["id"]),
                )

            state["error"] = str(e)
            state["messages"].append({"Error": str(e)})

            # 오류 발생 시에도 current_step_action_order와 action_order 증가
            state["current_step_action_order"] += 1
            state["action_order"] += 1
            state["next"] = "manager"
            return state

    async def get_agent(self) -> Any:
        """에이전트 생성"""
        workflow = StateGraph(State)
        workflow.add_node("executor", self.executor)
        workflow.add_edge(START, "executor")
        workflow.add_edge("executor", END)
        return workflow.compile()

    # DB에서 가져온 도구 정보로 실제 도구 객체를 찾아 매핑하는 함수
    def get_function_tool(self, tool_info: dict) -> Any:
        tool_name = tool_info.get("name")
        try:
            return self.available_tools[tool_name]
        except KeyError:
            return None


class ReporterAgent:
    def __init__(self, llm: Union[ChatOpenAI, AzureChatOpenAI], canvas: str):
        self.llm = llm
        self.canvas = canvas
        # self.cost_process = cost_process
        self.system_prompt = prompt_service.get_prompts()["Reporter_System_Prompt"]
        self.user_prompt = prompt_service.get_prompts()["Reporter_User_Prompt"]
        self.user_no_plan_prompt = prompt_service.get_prompts()[
            "Reporter_User_Prompt_no_plan"
        ]
        self.message_manager = MessageManager()

    async def reporter(self, state: State) -> State:
        logger.info("[Reporter] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        # step_plan이 있는 경우 PLAN_END 메시지 추가
        len_state = len(state["step_plan"])
        if state.get("step_plan"):
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.PLAN_END,
                content="모든 계획이 완료되었습니다.",
                description=f"총 {len_state}개의 스텝이 완료되었습니다.",
                key="",
            )
            logger.info(f"[Reporter] len_state: {len_state}")

        user_basic_info, history = manage_history(state)

        prev_history = history[:-1]
        # 포함할 키 리스트
        keys_to_keep = ["Query", "Answer"]

        # 특정 키만 남긴 새로운 리스트 생성
        filtered_history = [
            {k: d[k] for k in keys_to_keep if k in d} for d in prev_history
        ]

        user_query = state["user_query"]

        # dynamic_prompt = "\n"
        # for i in state["dynamic_prompts"]:
        #     if "reporter" in i[0]:
        #         dynamic_prompt += "- " + i[1] + "\n"

        prompt = ReporterPrompt(
            agent_config=state["agent_config"],
            user_query=user_query,
            history=filtered_history,
            plan=state["step_plan"],
            tool_calling_history=state["tool_calling_history"],
            plan_analysis="",
            # system_prompt=self.system_prompt + dynamic_prompt,
            system_prompt=self.system_prompt,
            user_prompt=self.user_prompt,
            user_no_plan_prompt=self.user_no_plan_prompt,
        )

        output_format = prompt.OutputFormat
        system_prompt = prompt.make_system_prompt()

        used_tool_list = [i["name"] for i in state["step_plan"]]

        user_prompt = prompt.make_user_prompt()
        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]

        session_id = state["chat_id"]
        structured_llm = self.llm.with_structured_output(output_format)
        response = structured_llm.invoke(
            chat_messages, config=get_llm_config(session_id)
        )
        response = response.model_dump()

        state["next"] = END

        canvas_type = self.canvas
        logger.debug(f"[Reporter] LLM response: {response}")

        if canvas_type == "canvas":
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.TITLE,
                content=response.get("title", ""),
                description="",
                key="",
            )

            # HTML Canvas 처리
            state["html_path"] = response.get("html_path")
            await self._handle_html_canvas(state, response)
        elif canvas_type == "ai_slide":
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.TITLE,
                content=response.get("title", ""),
                description="",
                key="",
            )
            # PPT 슬라이드 처리
            await self._handle_ai_slide_canvas(state, response)
        else:
            # 기타 또는 빈 값인 경우 토큰 응답 처리
            logger.info(
                f"[Reporter] Unknown or empty canvas type: '{canvas_type}', using token response"
            )
            await self._handle_token_response(state, response)

        return state

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("reporter", self.reporter)

        workflow.add_edge(START, "reporter")
        workflow.add_edge("reporter", END)
        return workflow.compile()

    async def _post_canvas_api(self, state, response):
        uuid = ""
        try:
            canvas_data = {
                "chat_id": state["chat_id"],
                "title": response.get("title", ""),
                "content": response.get("assistant_prompt", ""),
                "file_extension": "html",
                "type": "canvas",
                "version": 1,
            }

            if settings.TASK_AGENT_ROUTE == "DEV":
                ai_chat_base_url = "http://ai-chat:8010/ai-chat/"
            else:
                ai_chat_base_url = "http://localhost:8010/ai-chat/"

            ai_chat_url = ai_chat_base_url + "canvas"

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    ai_chat_url,
                    json=canvas_data,
                ) as response_client:
                    response_client_data = await response_client.json()
                    print(f"Canvas API 응답: {response_client_data}")
                    if response_client.status == 200:
                        # 서버 응답에서 uuid만 추출하여 반환
                        if "uuid" in response_client_data:
                            uuid = response_client_data["uuid"]
        except Exception as e:
            print(f"Canvas API 호출 중 예외 발생: {str(e)}")
            logger.error(f"[Reporter] Canvas API error: {str(e)}")
            return ""

        return uuid

    async def _handle_html_canvas(self, state, response):
        """HTML Canvas 처리 로직 - get_document_text로 파일 읽고 LLM으로 최종 HTML 생성"""
        logger.info("[Reporter] Processing HTML canvas")

        state["html_path"] = response.get("html_path")
        target_tool_name = "load_result"  # 찾고자 하는 도구 이름
        db_tool_info = None
        tool_endpoint = None

        async with AsyncSessionLocal() as db:
            stmt = select(Tool).where(Tool.name == target_tool_name)
            result = await db.execute(stmt)
            db_tool_info = result.scalars().first()

        if db_tool_info and db_tool_info.endpoint:
            tool_endpoint = db_tool_info.endpoint
            logger.info(
                f"[Reporter] Found tool '{target_tool_name}' with endpoint: {tool_endpoint}"
            )
        else:
            logger.error(
                f"[Reporter] Tool '{target_tool_name}' not found in DB or endpoint is missing."
            )
            # db에 tool이 없는 경우

            uuid = await self._post_canvas_api(state, response)

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.CANVAS,
                content=response.get(
                    "assistant_prompt", "Canvas에 띄울 수 있는 내용이 없습니다."
                ),
                key=uuid,
                description="",
            )
            return

        endpoints = {}
        endpoints[target_tool_name] = literal_eval(tool_endpoint)
        client = MultiServerMCPClient(endpoints)

        available_tools = await client.get_tools()
        now_tool = None
        for t in available_tools:
            if t.name == target_tool_name:
                now_tool = t
                break

        if not now_tool:
            logger.error(
                f"[Reporter] Tool '{target_tool_name}' not found in MultiServerMCPClient tools."
            )
            # mcp 서버에 tool이 없는 경우
            uuid = await self._post_canvas_api(state, response)

            # 오류 처리
            self.message_manager.add_message(
                state=state,
                message_type=MessageType.CANVAS,
                content=response.get(
                    "assistant_prompt", "Canvas에 띄울 수 있는 내용이 없습니다."
                ),
                key=uuid,
                description="",
            )

            return

        is_canvas_need = response.get("is_canvas_need", False)

        # if False:
        if is_canvas_need is False:
            # 캔버스 필요 없는 경우
            uuid = await self._post_canvas_api(state, response)

            self.message_manager.add_message(
                state=state,
                message_type=MessageType.CANVAS,
                content=response.get(
                    "assistant_prompt", "Canvas에 띄울 수 있는 내용이 없습니다."
                ),
                key=uuid,
                description="",
            )

        else:
            # get_document_text 도구로 파일 읽기
            converted_params = {
                "path": state["html_path"]
            }  # html_path를 파라미터로 사용한다고 가정

            try:
                # 1단계: get_document_text로 기본 HTML 파일 읽기
                tool_result = await now_tool.ainvoke(converted_params)
                final_html_content = tool_result

                # Canvas API 호출
                uuid = ""
                try:
                    canvas_data = {
                        "chat_id": state["chat_id"],
                        "title": response.get("title", ""),
                        "content": final_html_content,
                        "file_extension": "html",
                        "type": "canvas",
                        "version": 1,
                    }

                    if settings.TASK_AGENT_ROUTE == "DEV":
                        ai_chat_base_url = "http://ai-chat:8010/ai-chat/"
                    else:
                        ai_chat_base_url = "http://localhost:8010/ai-chat/"

                    ai_chat_url = ai_chat_base_url + "canvas"

                    async with aiohttp.ClientSession() as session:
                        async with session.post(
                            ai_chat_url,
                            json=canvas_data,
                        ) as response_client:
                            response_client_data = await response_client.json()
                            print(f"Canvas API 응답: {response_client_data}")
                            if response_client.status == 200:
                                # 서버 응답에서 uuid만 추출하여 반환
                                if "uuid" in response_client_data:
                                    uuid = response_client_data["uuid"]

                except Exception as e:
                    print(f"Canvas API 호출 중 예외 발생: {str(e)}")
                    logger.error(f"[Reporter] Canvas API error: {str(e)}")
                    # API 오류 시 토큰 응답으로 폴백
                    await self._handle_token_response(state, response)
                    return

                self.message_manager.add_message(
                    state=state,
                    message_type=MessageType.CANVAS,
                    content=final_html_content,  # LLM이 최종 생성한 HTML 사용
                    key=uuid,
                    description="",
                )

            except Exception as e:
                logger.error(f"[Reporter] Error in HTML canvas processing: {str(e)}")
                # 오류 시 토큰 응답으로 폴백
                await self._handle_token_response(state, response)

    async def _handle_ai_slide_canvas(self, state, response):
        """PPT 슬라이드 처리 로직"""
        logger.info("[Reporter] Processing PPT canvas")

        target_tool_name = (
            "report_to_presentation"  # PPT 생성 도구 이름. 실제 도구 이름으로 변경 필요
        )
        db_tool_info = None
        tool_endpoint = None

        async with AsyncSessionLocal() as db:
            stmt = select(Tool).where(Tool.name == target_tool_name)
            result = await db.execute(stmt)
            db_tool_info = result.scalars().first()

        if db_tool_info and db_tool_info.endpoint:
            tool_endpoint = db_tool_info.endpoint
            logger.info(
                f"[Reporter] Found PPT tool '{target_tool_name}' with endpoint: {tool_endpoint}"
            )
        else:
            logger.error(
                f"[Reporter] PPT tool '{target_tool_name}' not found in DB or endpoint is missing."
            )
            await self._handle_token_response(state, response)
            return

        endpoints = {}
        endpoints[target_tool_name] = literal_eval(tool_endpoint)
        client = MultiServerMCPClient(endpoints)

        available_tools = await client.get_tools()
        now_tool = None
        for t in available_tools:
            if t.name == target_tool_name:
                now_tool = t
                break

        if not now_tool:
            logger.error(
                f"[Reporter] PPT tool '{target_tool_name}' not found in MultiServerMCPClient tools."
            )
            await self._handle_token_response(state, response)
            return

        # create_ai_slide_prompt를 사용하여 상세 프롬프트 생성
        report_content_prompt = create_ai_slide_prompt(
            user_query=state["user_query"],
            tool_calling_history=state.get("tool_calling_history", []),
        )
        logger.debug(f"[Reporter] Generated AI Slide Prompt:\n{report_content_prompt}")

        # PPT 생성을 위한 파라미터 설정
        converted_params = {"report_content": report_content_prompt}

        try:
            tool_result = await now_tool.ainvoke(converted_params)
            logger.info(
                f"[Reporter] PPT tool '{target_tool_name}' executed. Result type: {type(tool_result)}"
            )

            # PPT 도구 결과 파싱
            try:
                # tool_result가 문자열인 경우 JSON 파싱
                if isinstance(tool_result, str):
                    slide_data = json.loads(tool_result)
                else:
                    slide_data = tool_result

                # slides 배열에서 각 슬라이드 처리
                if "slides" in slide_data and isinstance(slide_data["slides"], list):
                    slides = slide_data["slides"]
                    logger.info(f"[Reporter] Processing {len(slides)} slides")

                    # 각 슬라이드를 개별적으로 Canvas API에 전송
                    for idx, slide in enumerate(slides):
                        slide_title = slide.get("title", f"슬라이드 {idx + 1}")
                        slide_html = slide.get("html", "")

                        if slide_html:
                            try:
                                canvas_data = {
                                    "chat_id": state["chat_id"],
                                    "title": response.get("title", ""),
                                    "content": slide_html,
                                    "file_extension": "html",
                                    "type": "ai_slide",
                                    "version": 1,  # 슬라이드 순서를 버전으로 사용
                                }

                                if settings.TASK_AGENT_ROUTE == "DEV":
                                    ai_chat_base_url = "http://ai-chat:8010/ai-chat/"
                                else:
                                    ai_chat_base_url = "http://localhost:8010/ai-chat/"

                                ai_chat_url = ai_chat_base_url + "canvas"

                                async with aiohttp.ClientSession() as session:
                                    async with session.post(
                                        ai_chat_url,
                                        json=canvas_data,
                                    ) as response_client:
                                        response_client_data = (
                                            await response_client.json()
                                        )
                                        logger.info(
                                            f"[Reporter] Slide {idx + 1} Canvas API 응답: {response_client_data}"
                                        )

                                        if response_client.status == 200:
                                            # 각 슬라이드에 대한 Canvas 메시지 추가
                                            uuid = response_client_data.get("uuid", "")
                                            self.message_manager.add_message(
                                                state=state,
                                                message_type=MessageType.AI_SLIDE,
                                                content=slide_html,
                                                description="",
                                                key=uuid,
                                            )
                                        else:
                                            logger.error(
                                                f"[Reporter] Slide {idx + 1} Canvas API 오류: {response_client.status}"
                                            )

                            except Exception as e:
                                logger.error(
                                    f"[Reporter] Slide {idx + 1} Canvas API 호출 중 예외 발생: {str(e)}"
                                )
                                continue

                    # 전체 프레젠테이션 완료 메시지
                    self.message_manager.add_message(
                        state=state,
                        message_type=MessageType.TOKEN,
                        content=f"프레젠테이션이 생성되었습니다. 총 {len(slides)}개의 슬라이드가 생성되었습니다.",
                        description="",
                        key="",
                    )

                else:
                    logger.error("[Reporter] PPT 결과에 slides 배열이 없습니다.")
                    # slides가 없으면 토큰 응답으로 폴백
                    await self._handle_token_response(state, response)

            except json.JSONDecodeError as e:
                logger.error(f"[Reporter] PPT 결과 JSON 파싱 오류: {str(e)}")
                # JSON 파싱 오류 시 토큰 응답으로 폴백
                await self._handle_token_response(state, response)

        except Exception as e:
            logger.error(
                f"[Reporter] Error executing PPT tool '{target_tool_name}': {str(e)}"
            )
            # PPT 도구 실행 오류 시 토큰 응답으로 폴백
            await self._handle_token_response(state, response)

    async def _handle_token_response(self, state, response):
        # 기본 로직: 토큰 응답 처리
        assistant_prompt = response.get("assistant_prompt")
        if assistant_prompt is not None and isinstance(assistant_prompt, str):
            # 연속되는 개행문자를 하나의 개행문자로 변경
            report = re.sub(r"\n+", "\n", assistant_prompt)
            # 개행 문자를 강제 개행으로 변경
            report = re.sub(r"\n", "  \n", report)
        else:
            report = assistant_prompt
        self.message_manager.add_message(
            state=state,
            message_type=MessageType.TOKEN,
            content=report,
            description="",
            key="",
        )

        logger.info(f"[Reporter] Report output: {report}")

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # state["messages"][-1]["Answer"] = report
        # state["messages"][-1]["Datetime"] = now


class ReplannerAgent:
    def __init__(
        self,
        llm: Union[ChatOpenAI, AzureChatOpenAI],
        tools: List[Dict[str, Any]],
    ):
        self.llm = llm
        self.tools = tools
        self.system_prompt = prompt_service.get_prompts()["Replanner_System_Prompt"]
        self.user_prompt = prompt_service.get_prompts()["Replanner_User_Prompt"]

    def planner(self, state: State) -> State:
        logger.info("[Replanner] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        current_time = get_kor_nowtime()

        dynamic_prompt = "\n"
        for i in state["dynamic_prompts"]:
            if "planner" in i[0]:
                dynamic_prompt += "- " + i[1] + "\n"

        user_basic_info, history = manage_history(state)

        prompt = ReplannerPrompt(
            user_basic_info=user_basic_info,
            agent_config=state["agent_config"],
            tools=self.tools,
            user_query=state["user_query"],
            history=history,
            plan=state["step_plan"],
            current_time=current_time,
            system_prompt=self.system_prompt + dynamic_prompt,
            user_prompt=self.user_prompt,
        )
        system_prompt = prompt.make_system_prompt()
        user_prompt = prompt.make_user_prompt()
        output_format = prompt.OutputFormat

        chat_messages = [
            ("system", system_prompt),
            ("human", user_prompt),
        ]

        session_id = state["chat_id"]
        structured_llm = self.llm.with_structured_output(output_format)
        response = structured_llm.invoke(
            chat_messages, config=get_llm_config(session_id)
        )
        response = response.model_dump()

        logger.debug(f"[Replanner] LLm response: {response}")

        plan = response["plan"]
        logger.info(f"[Replanner] Plan: {plan}")
        plan_message = ""
        for i in plan:
            plan_message += f"{i['order']}. {i['name']}: {i['goal']}\n"
        self.message_manager.add_message(
            state=state,
            message_type=MessageType.TOKEN,
            content=plan_message,
            description="",
            key="",
        )
        state["step_plan"] = plan

        if plan:
            state["next"] = "executor"
        else:
            state["next"] = "reporter"

        return state

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("planner", self.planner)

        workflow.add_edge(START, "planner")
        workflow.add_edge("planner", END)
        return workflow.compile()


class RecorderAgent:
    def __init__(self):
        pass

    def recorder(self, state: State) -> State:
        logger.info("[Recorder] Agent started")

        # view_messages 초기화
        clear_view_messages(state)

        state["start_recording"] = False
        self.message_manager.add_message(
            state=state,
            message_type=MessageType.TOKEN,
            content="녹음을 시작합니다.",
        )
        return state

    def get_agent(self) -> Any:
        workflow = StateGraph(State)
        workflow.add_node("recorder", self.recorder)

        workflow.add_edge(START, "recorder")
        workflow.add_edge("recorder", END)
        return workflow.compile()
