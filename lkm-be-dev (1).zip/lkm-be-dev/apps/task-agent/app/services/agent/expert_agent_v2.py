from typing import Any, Union

from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langgraph.graph import START, StateGraph
from sqlalchemy.ext.asyncio import AsyncSession

from core.config import get_setting
from core.log.logging import get_logging
from services.agent.base_agent import BaseAgent
from services.agent.nodes.executor_node import ExecutorNode
from services.agent.nodes.manager_node import ManagerNode
from services.agent.nodes.planner_node import PlannerNode
from services.agent.nodes.reporter_node import BaseReporterNode
from services.agent.nodes.retry_executor_node import RetryExecutorNode
from services.agent.nodes.router_node import RouterNode
from services.agent.nodes.state_init_node import StateInitNode
from services.agent.state import State

# from services.prompt.prompt_service import PromptService

logger = get_logging()
settings = get_setting()
# prompt_service = PromptService()


class ExpertAgent(BaseAgent):
    """회의실 예약 및 관리를 위한 에이전트"""

    def __init__(
        self, llm: Union[ChatOpenAI, AzureChatOpenAI], agent_id: int, canvas: str
    ):
        super().__init__(llm)
        self.agent_id = agent_id
        self.canvas = canvas

    def finish(self, state: State) -> State:
        """워크플로우를 종료하기 위한 빈 함수"""
        return state

    async def get_graph(self, db: AsyncSession, stream: bool) -> Any:
        """전체 워크플로우 그래프 구성"""

        # 각 에이전트 초기화
        state_init = StateInitNode(self.llm)
        router = RouterNode(self.agent_id, self.llm)
        # selector = SelectorNode(self.agent_id, self.llm)
        planner = PlannerNode(self.llm)
        executor = ExecutorNode(self.llm)
        retry_executor = RetryExecutorNode(self.llm)
        manager = ManagerNode(self.llm)
        # if stream:
        #     reporter = AsyncReporterNode(self.canvas)
        # else:
        #     reporter = SyncReporterNode(self.canvas)
        reporter = BaseReporterNode(self.llm, self.canvas)
        # 워크플로우 구성
        workflow = StateGraph(State)

        # 노드 추가
        workflow.add_node("state_init", state_init)
        workflow.add_node("router", router)
        # workflow.add_node("selector", selector)
        workflow.add_node("planner", planner)
        workflow.add_node("executor", executor)
        workflow.add_node("retry_executor", retry_executor)
        workflow.add_node("manager", manager)
        workflow.add_node("reporter", reporter)
        workflow.add_node("finish", self.finish)

        workflow.set_finish_point("finish")

        # 엣지 추가
        workflow.add_edge(START, "state_init")
        workflow.add_edge("state_init", "router")

        workflow.add_conditional_edges(
            "router",
            lambda x: x["next"],
            # ["finish", "selector", "executor", "reporter"],
            ["finish", "planner", "executor", "reporter"],
        )
        # workflow.add_edge("selector", "planner")

        workflow.add_conditional_edges(
            "planner",
            lambda x: x["next"],
            ["manager", "executor", "reporter"],
        )

        workflow.add_conditional_edges(
            "executor",
            lambda x: x["next"],
            ["manager"],
        )

        # workflow.add_conditional_edges(
        #     "executor",
        #     lambda x: x["next"],
        #     ["manager", "reverse_questioner"],
        # )

        # workflow.add_edge("reverse_questioner", "finish")

        workflow.add_conditional_edges(
            "manager",
            lambda x: x["next"],
            ["executor", "retry_executor", "reporter"],
        )

        workflow.add_conditional_edges(
            "retry_executor",
            lambda x: x["next"],
            ["manager"],
        )

        workflow.add_conditional_edges(
            "reporter",
            lambda x: x["next"],
            # ["finish", "recorder", "coordinator"],
            ["finish"],
        )
        # workflow.add_edge("recorder", "finish")
        # workflow.add_edge("coordinator", "finish")

        return workflow.compile(
            # checkpointer=MemorySaverSingleton.get_instance(db=db),
        )
