from datetime import datetime
from typing import Any, Dict, Optional

from .message_interfaces import (
    ActionMessage,
    BaseState,
    CurrentState,
    OtherEventMessage,
    PlanStartMessage,
    TokenMessage,
)
from .message_types import MessageType


class MessageFactory:
    @staticmethod
    def _create_base_state(state: Dict[str, Any]) -> BaseState:
        """기본 상태 객체를 생성합니다."""
        current = CurrentState(
            step=state.get("step_order", 0),
            action=f"{state.get('step_order', '0')}.{state.get('action_order', '0')}",
            completed=False,
            error=state.get("error"),
        )

        return BaseState(
            Query=state.get("user_query", ""),
            Used_tool=state.get("tool_calling_history", []),
            Datetime=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            current=current,
            Answer=state.get("response"),
        )

    @staticmethod
    def create_plan_start_message(
        state: dict[str, Any],
        step_plan: list[dict[str, Any]],
        description: Optional[str] = None,
    ) -> PlanStartMessage:
        """플랜 시작 메시지 생성 (간소화됨)

        참고: 이 메서드가 올바르게 작동하려면 message_interfaces.py의
        PlanStartMessage 데이터 클래스에서 'plan' 필드의 타입이
        PlanInfo가 아니라 list[dict[str, Any]] 또는 호환 가능한 타입(예: Any)으로
        정의되어 있어야 합니다.
        """
        plan_content = ", ".join(
            [step.get("name", "이름 없는 스텝") for step in step_plan]
        )

        return PlanStartMessage(
            type=MessageType.PLAN_START.value,
            content=plan_content,
            state=MessageFactory._create_base_state(state),
            description=description,
        )

    @staticmethod
    def create_action_message(
        message_type: MessageType,
        content: str,
        state: Dict[str, Any],
        description: Optional[str] = None,
    ) -> ActionMessage:
        """액션 관련 메시지를 생성합니다."""
        return ActionMessage(
            type=message_type.value,
            content=content,
            state=MessageFactory._create_base_state(state),
            description=description,
        )

    @staticmethod
    def create_step_message(
        message_type: MessageType,
        content: str,
        state: Dict[str, Any],
        description: Optional[str] = None,
    ) -> OtherEventMessage:
        """단계 관련 메시지를 생성합니다."""
        return OtherEventMessage(
            type=message_type.value,
            content=content,
            state=MessageFactory._create_base_state(state),
            description=description,
        )

    @staticmethod
    def create_error_message(
        content: str, state: Dict[str, Any], description: Optional[str] = None
    ) -> OtherEventMessage:
        """에러 메시지를 생성합니다."""
        return OtherEventMessage(
            type=MessageType.ERROR.value,
            content=content,
            state=MessageFactory._create_base_state(state),
            description=description,
        )

    @staticmethod
    def create_token_message(
        content: str,
        state: Dict[str, Any],
        canvas_information: Optional[Dict[str, Any]] = None,
        description: Optional[str] = None,
    ) -> TokenMessage:
        """토큰 메시지를 생성합니다."""
        return TokenMessage(
            type=MessageType.TOKEN.value,
            content=content,
            state=MessageFactory._create_base_state(state),
            canvas_information=canvas_information,
            description=description,
        )

    @staticmethod
    def create_step_start_message(
        state: Dict[str, Any],
        content: str = "step 시작",
        description: Optional[str] = None,
    ) -> OtherEventMessage:
        """
        스텝 시작 메시지를 생성합니다.
        """
        return OtherEventMessage(
            type=MessageType.STEP_START.value,
            content=content,
            state=MessageFactory._create_base_state(state),
            description=description,
        )

    @staticmethod
    def create_canvas_message(
        state: Dict[str, Any],
        content: str = "canvas 시작",
        description: Optional[str] = None,
    ) -> OtherEventMessage:
        """canvas 메시지를 생성합니다."""
        return OtherEventMessage(
            type=MessageType.CANVAS.value,
            content=content,
            state=MessageFactory._create_base_state(state),
            description=description,
        )
