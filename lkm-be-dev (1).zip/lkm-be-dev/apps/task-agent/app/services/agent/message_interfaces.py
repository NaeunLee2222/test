from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict


class CurrentState(BaseModel):
    step: Optional[int] = None
    action: Optional[str] = None
    completed: Optional[bool] = None
    error: Optional[str] = None


class BaseState(BaseModel):
    Query: str
    Used_tool: List[dict[str, Any]]
    Datetime: str
    current: CurrentState
    Answer: Optional[str] = None


class BaseMessage(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    type: str
    content: str
    state: BaseState
    description: Optional[str] = None


class PlanStartMessage(BaseMessage):
    type: str


class ActionMessage(BaseMessage):
    type: str


class TokenMessage(BaseMessage):
    type: str
    state: BaseState
    canvas_information: Optional[Dict[str, Any]] = None


class OtherEventMessage(BaseMessage):
    type: str
