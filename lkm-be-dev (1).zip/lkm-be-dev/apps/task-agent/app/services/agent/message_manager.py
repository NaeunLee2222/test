from typing import Any, Dict

from .message_types import MessageType
from .state import State


class MessageManager:
    """간소화된 메시지 매니저 - 메시지를 state의 view_messages에 직접 추가"""

    def add_message(
        self,
        state: State,
        message_type: MessageType,
        content: str,
        description: str = "",
        key: str = "",
        **kwargs: Any,
    ) -> None:
        """
        통합된 메시지 추가 메서드

        Args:
            state: 상태 객체
            message_type: 메시지 타입
            content: 메시지 내용
            description: 메시지 설명 (선택사항)
            **kwargs: 추가 데이터 (step_plan, canvas_information 등)
        """
        payload: Dict[str, Any] = {
            "content": content,
            "description": description,
            "key": key,
        }

        # 추가 데이터가 있으면 payload에 포함
        if kwargs:
            payload.update(kwargs)

        # view_messages가 없으면 초기화
        if "view_messages" not in state:
            state["view_messages"] = []

        state["view_messages"].append({message_type.value: payload})
