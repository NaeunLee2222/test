import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.routing import APIRoute
from fastapi.staticfiles import StaticFiles
from filelock import FileLock

from api.router import api_router
from api.routes.docs import docs_router

# from api.routes.health import router as health_router
from core.config import get_setting
from core.errors.error_handler import set_error_handlers
from core.log.logging import get_logging
from core.middleware import ChatMessageMiddleware, LoggingMiddleware
from database.init_database import (
    close_database_connections,
    initialize_database,
    sync_prompts_api_specs,
)

settings = get_setting()
logger = get_logging()


def custom_generate_unique_id(route: APIRoute) -> str:
    return f"{route.tags[0]}-{route.name}"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    try:
        # 파일 업로드 디렉토리 생성 (업무 절차서)
        os.makedirs(
            settings.FILE_UPLOAD_DIR, mode=settings.FILE_PATH_PERMISSIONS, exist_ok=True
        )
        logger.info(
            f"File upload directory created: {settings.FILE_UPLOAD_DIR}\nWith permissions: {settings.FILE_PATH_PERMISSIONS}"
        )

        # db lock 파일 경로 설정
        lock_file = settings.DATA_PATH + "/tmp/task_agent_init.lock"
        lock = FileLock(lock_file, timeout=0)

        try:
            with lock:
                logger.info(f"Environment: {settings.ENVIRONMENT}")
                logger.info(f"Worker Count: {settings.TASK_AGENT_WORKER_NUM}")
                logger.info("Initializing application...")

                await initialize_database()
                if settings.PROMPT_API_SPEC_DB_SYNC_ENABLED:
                    sync_prompts_api_specs()

                logger.info("Database initialization completed")
                logger.info(f"{settings.APP_NAME} service is ready and now running!")
        except TimeoutError:
            logger.info(
                "Lock already held by another process, skipping initialization..."
            )
        yield
    finally:
        logger.info("Shutting down database connections.")
        await close_database_connections()


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.APP_NAME,
        openapi_url=f"{settings.URI_PREFIX}/openapi.json",  # 기본 openapi.json 활성화
        docs_url=None,  # 기본 docs 비활성화 (커스텀 docs 사용)
        lifespan=lifespan,
        generate_unique_id_function=custom_generate_unique_id,
    )

    # Mount static files
    app.mount(
        f"{settings.URI_PREFIX}/static",
        StaticFiles(directory=Path(__file__).resolve().parent / "static"),
        name="static",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # 모든 출처 허용
        allow_credentials=True,
        allow_methods=["*"],  # 모든 HTTP 메소드 허용
        allow_headers=["*"],  # 모든 HTTP 헤더 허용
    )  # AGS 임시 CORS 추가

    app.add_middleware(ChatMessageMiddleware)
    app.add_middleware(LoggingMiddleware)

    # Register API routers
    # app.include_router(health_router, prefix=settings.URI_PREFIX)
    app.include_router(docs_router, prefix=settings.URI_PREFIX)  # 커스텀 docs 활성화
    app.include_router(api_router, prefix=settings.URI_PREFIX)

    return app


app = create_app()
set_error_handlers(app, logger)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=settings.TASK_AGENT_APP_PORT,
        access_log=False,
    )
