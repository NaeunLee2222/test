# Task Agent

AI 기반의 작업 처리 에이전트 서비스입니다.

## 디렉토리 구조 

apps/task-agent/
├── app/ # 애플리케이션 루트
│ ├── alembic/ # DB 마이그레이션
│ ├── api/ # API 관련
│ │ └── routes/ # 라우터 컨트롤러
│ │
│ ├── core/ # 핵심 유틸리티 및 설정
│ │ ├── config/ # 환경 설정
│ │ ├── log/ # 로깅 설정
│ │ ├── prompts/ # LLM 프롬프트 템플릿
│ │ └── utils/ # 공통 유틸리티
│ │
│ ├── crud/ # 데이터 접근 계층
│ │ ├── base/ # 기본 CRUD 기능
│ │ ├── crud_api_spec/ # API spec DB에 대한 CRUD
│ │ └── crud_prompt/ # 프롬프트 DB에 대한 CRUD
│ │
│ ├── scripts/ # 별도 실행 필요한 스크립트 파일
│ │ ├── sync_api_specs.py # core/settings/~.json 파일과 api_specs DB 동기화
│ │ └── sync_prompts.py # core/prompts/templates 파일과 prompt DB 동기화
│ │
│ └── services/ # 비즈니스 로직
│ │ ├── chat_service.py # 채팅 로직
│ │ ├── meeting_room_service.py # agent 외에 회의실 조율, 알림 발송 등 로직
│ │ ├── user_service.py # 유저 기본 정보 등 처리 로직
│ │ │ 
│ │ ├── company/ # 회사별 비즈니스 로직
│ │ │ ├── company_service.py
│ │ │ ├── skt/ # SKT 전용 서비스
│ │ │ └── skcc/ # SKCC 전용 서비스
│ │ │
│ │ ├── agent/ # Agent 관련
│ │ │ ├── agents/ # 각종 에이전트
│ │ │ ├── base_agent.py
│ │ │ ├── meeting_room_agent.py
│ │ │ └── search_agent.py
│ │ │
│ │ ├──  tools/ # LangChain 도구 관련
│ │ ├── factory/ # API spec 기반 도구 생성
│ │ │ ├── api_tool.py
│ │ │ └── tool_factory.py
│ │ └── meeting_tools.py
│
└── alembic.ini # Alembic 설정

## 주요 컴포넌트

### Controllers
- REST API 엔드포인트 정의
- 요청 유효성 검사 및 라우팅

### Core
- `config/`: 환경 변수 및 설정 관리
- `logging/`: 로깅 설정 및 유틸리티
- `prompts/`: LLM 프롬프트 템플릿 관리
- `utils/`: 공통으로 사용되는 유틸리티 함수

### Repository
- `service/`: 실제 서비스에서 사용하는 데이터 접근 계층
- `management/`: 관리용 데이터 접근 계층 (API 스펙 관리 등)

### Services
- `chat_service.py`: 채팅 서비스 핵심 로직
- `company/`: 회사별 커스텀 서비스 구현
- `graph/`: LangGraph 기반 에이전트 구현
  - `agents/`: 각 역할별 에이전트 (Planner, Executor 등)
  - `meeting_agent.py`: 회의실 예약 에이전트
  - `search_agent.py`: 웹 검색 에이전트
- `tools/`: LangChain 도구 구현
  - `factory/`: API 기반 도구 동적 생성
  - 각종 도구 구현 (회의실 예약, 검색 등)

### Schemas
- API 요청/응답 데이터 모델 정의
- Pydantic 기반 타입 검증

## 주요 기능

1. **채팅 기반 작업 처리**
   - OpenAI 호환 채팅 API 제공
   - 스트리밍 응답 지원

2. **회의실 예약**
   - 자연어로 회의실 예약 요청
   - 회사별 맞춤 예약 시스템 연동

3. **웹 검색**
   - 자연어 질문에 대한 웹 검색 수행
   - 검색 결과 요약 및 응답

4. **확장 가능한 도구 시스템**
   - API 스펙 기반 도구 자동 생성
   - 회사별 커스텀 도구 지원