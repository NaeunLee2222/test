-- ai_chat 스키마가 없으면 생성
CREATE SCHEMA ai_chat;

-- langfuse 스키마가 없으면 생성
CREATE SCHEMA langfuse;
