import asyncio
from typing import Dict, List

from core.config import get_setting
from core.log.logging import get_logging
from core.utils.docintelligence import AzureDocIntelligenceClient
from database.crud.files import CRUDFilesAsync
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()
settings = get_setting()


class FileService:
    def __init__(self):
        self.crud_files = CRUDFilesAsync()
        self.azureDocIntelligenceClient = AzureDocIntelligenceClient()

    async def get_file_summary(self, db: AsyncSession, file_id: int) -> str:
        """단일 파일의 summary 조회"""
        try:
            file = await self.crud_files.get(db, file_id)
            if not file:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"File with id {file_id} not found",
                )
            return file.summary or ""
        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get file summary, {str(e)}",
            )

    async def get_files_summary(
        self, db: AsyncSession, file_ids: List[int]
    ) -> Dict[int, str]:
        """파일 ID 목록으로 summary 조회"""
        try:
            files = await self.crud_files.get_multi_by_ids(db, file_ids)
            return {file.id: file.summary or "" for file in files}
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get files summary, {str(e)}",
            )

    async def get_file_by_id(self, db: AsyncSession, file_id: int):
        """파일 ID로 파일 정보 조회"""
        try:
            file = await self.crud_files.get(db, file_id)
            if not file:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"File with id {file_id} not found",
                )
            return file
        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get file, {str(e)}",
            )

    async def get_file_original_content(self, db: AsyncSession, file_id: int):
        """파일 원본 내용 조회"""
        try:
            file = await self.crud_files.get(db, file_id)

            if not file:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"File with id {file_id} not found",
                )

            if file.file_type in [
                "application/pdf",
                "image/png",
                "image.jpeg",
                "image/jpg",
                "image/gif",
                "image/bmp",
                "image/tiff",
                "image/webp",
            ]:
                return file.original_content
            else:
                # 텍스트 파일의 경우 파일 경로에서 읽어옴
                if file.file_path:
                    try:
                        with open(file.file_path, "r", encoding="utf-8") as f:
                            content = f.read()
                        return content
                    except FileNotFoundError:
                        raise ServiceException(
                            status_code=404,
                            error_code=ErrorCode.RESOURCE_NOT_FOUND,
                            detail=f"File not found at path: {file.file_path}",
                        )
                    except UnicodeDecodeError:
                        # UTF-8로 읽을 수 없는 경우 바이너리로 읽기
                        with open(file.file_path, "rb") as f:
                            content = f.read()
                        return content
                else:
                    return file.original_content or ""

        except ServiceException as se:
            raise se
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get file original content, {str(e)}",
            )

    async def wait_for_file_ready(
        self,
        db: AsyncSession,
        file_id: int,
        max_wait_time: int = 60,
        check_interval: int = 5,
    ):
        """
        파일 상태가 WAIT인 경우 처리 완료까지 대기

        Args:
            db: 데이터베이스 세션
            file_id: 파일 ID
            max_wait_time: 최대 대기 시간 (초)
            check_interval: 상태 확인 간격 (초)

        Returns:
            file: 처리 완료된 파일 객체

        Raises:
            ServiceException: 타임아웃, 처리 실패, 파일 삭제 등의 경우
        """

        file = await self.get_file_by_id(db, file_id)
        waited_time = 0

        while file.state == "WAIT" and waited_time < max_wait_time:
            logger.info(
                f"파일 처리 대기 중 [file_id: {file_id}, waited: {waited_time}s]"
            )
            await asyncio.sleep(check_interval)
            waited_time += check_interval

            await db.refresh(file)
            # 파일 상태 재확인

        # 여전히 WAIT 상태인 경우
        if file.state == "WAIT":
            raise ServiceException(
                status_code=202,  # Accepted - 처리 중
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"파일이 아직 처리 중입니다. 잠시 후 다시 시도해주세요. (대기 시간: {max_wait_time}초 초과)",
            )

        # FAILURE 상태인 경우
        if file.state == "FAILURE":
            raise ServiceException(
                status_code=422,  # Unprocessable Entity
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail="파일 처리에 실패했습니다. 파일을 다시 업로드해주세요.",
            )

        # DELETED 상태인 경우
        if file.state == "DELETED":
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="파일이 삭제되었습니다.",
            )

        return file
