from typing import Optional

from pydantic import BaseModel, Field


class ChatDocBase(BaseModel):
    user_id: Optional[int] = Field(None, description="사용자 ID")
    chat_id: str = Field(..., description="채팅 ID")
    file_id: int = Field(..., description="Files 테이블 참조 ID")


class ChatDocCreate(ChatDocBase):
    pass


class ChatDocUpdate(BaseModel):
    chat_id: Optional[str] = None
    file_id: Optional[int] = None


class ChatDocInDB(ChatDocBase):
    id: int
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True
