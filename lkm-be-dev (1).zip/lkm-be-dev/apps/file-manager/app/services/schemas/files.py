from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class FileBase(BaseModel):
    original_filename: str = Field(..., description="원본 파일명")
    uuid_filename: str = Field(..., description="UUID 파일명")
    file_type: Optional[str] = Field(None, description="파일 MIME 타입")
    file_path: Optional[str] = Field(None, description="파일 저장 경로")
    file_size: int = Field(..., description="파일 크기 (바이트)")
    state: str = Field("WAIT", description="파일 상태 (WAIT, READY, FAILURE, DELETED)")
    index_name: Optional[str] = Field(None, description="Azure AI Search 인덱스명")
    summary: Optional[str] = Field(None, description="파일 요약")
    original_content: Optional[str] = Field(None, description="파일 원본 텍스트 내용")


class FileCreate(FileBase):
    pass


class FileUpdate(BaseModel):
    state: Optional[str] = None
    index_name: Optional[str] = None
    summary: Optional[str] = None
    original_content: Optional[str] = None
    file_path: Optional[str] = None


class FileInDB(FileBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
