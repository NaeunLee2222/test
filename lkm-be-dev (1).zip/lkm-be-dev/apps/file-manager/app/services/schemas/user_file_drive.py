from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


# Base properties
class UserFileDriveBase(BaseModel):
    user_id: int = Field(..., description="사용자 ID")
    file_id: int = Field(..., description="Files 테이블 참조 ID")


# 프론트엔드에 안전하게 노출할 파일 정보만 포함하는 스키마
class FileForClient(BaseModel):
    id: int = Field(..., description="파일 ID")
    original_filename: str = Field(..., description="원본 파일명")
    file_type: Optional[str] = Field(None, description="파일 MIME 타입")
    file_size: int = Field(..., description="파일 크기 (바이트)")
    state: str = Field(..., description="파일 상태 (WAIT, READY, FAILURE, DELETED)")
    summary: Optional[str] = Field(None, description="파일 요약")
    created_at: datetime = Field(..., description="생성일시")
    updated_at: Optional[datetime] = Field(None, description="수정일시")

    model_config = ConfigDict(from_attributes=True)


class UserFileDriveWithFile(UserFileDriveBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    file: FileForClient

    model_config = ConfigDict(from_attributes=True)


# Properties to receive on item creation
class UserFileDriveCreate(UserFileDriveBase):
    pass


# Properties to receive on item update
class UserFileDriveUpdate(BaseModel):
    pass


# Properties shared by models stored in DB
class UserFileDriveInDBBase(UserFileDriveBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)


# Properties to return to client
class UserFileDrive(UserFileDriveInDBBase):
    pass


# Properties stored in DB
class UserFileDriveInDB(UserFileDriveBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# Response model for list
class UserFileDriveList(BaseModel):
    total: int
    files: List[UserFileDrive]


# 배치 첨부를 위한 스키마들
class AttachFilesToChatRequest(BaseModel):
    user_file_ids: List[int] = Field(..., description="첨부할 파일 ID 리스트")


class AttachFilesToAgentRequest(BaseModel):
    user_file_ids: List[int] = Field(..., description="첨부할 파일 ID 리스트")
    document_type: str = Field(
        default="KNOWLEDGE", description="문서 유형 (KNOWLEDGE 또는 PROCEDURE)"
    )


class FileAttachResult(BaseModel):
    file_id: int
    success: bool
    message: str
    doc_id: Optional[int] = None
    original_filename: Optional[str] = None


class BatchAttachResponse(BaseModel):
    total_files: int
    successful_files: int
    failed_files: int
    results: List[FileAttachResult]
