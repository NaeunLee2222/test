from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from .files import FileInDB


class AgentDocBase(BaseModel):
    document_type: str = Field(..., description="문서 타입 (KNOWLEDGE, PROCEDURE)")


class AgentDocCreate(AgentDocBase):
    file_id: int = Field(..., description="Files 테이블 참조 ID")


class AgentDocUpdate(BaseModel):
    agent_id: Optional[int] = None


class AgentDocInDB(AgentDocBase):
    agent_docs_id: int
    file_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class AgentDocWithFile(AgentDocInDB):
    file: FileInDB

    class Config:
        from_attributes = True
