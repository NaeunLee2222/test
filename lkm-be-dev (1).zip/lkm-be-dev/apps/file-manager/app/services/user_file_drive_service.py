# type: ignore  # SQLAlchemy 타입 추론 문제로 인한 임시 해결책
import os
from typing import List

from celery_config import cel
from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from database.crud.files import crud_files
from database.crud.user_file_drive import crud_user_file_drive
from fastapi import UploadFile
from services.agent_document_service import AgentDocumentService
from services.chat_document_service import ChatDocumentService
from services.file_upload_service import file_upload_service
from services.schemas.user_file_drive import (
    BatchAttachResponse,
    FileAttachResult,
    UserFileDriveCreate,
)
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()


class UserFileDriveService:
    def __init__(self):
        self.crud_user_file_drive = crud_user_file_drive
        self.crud_files = crud_files

    async def _create_user_file_drive_metadata(
        self, db: AsyncSession, file_result: dict, user_id: int
    ) -> int:
        """UserFileDrive 메타데이터 생성 후 ID 반환"""
        user_file_drive_schema = UserFileDriveCreate(
            user_id=user_id,
            file_id=file_result["file_id"],
        )
        created_user_file_drive = await self.crud_user_file_drive.create(
            db, obj_in=user_file_drive_schema.model_dump()
        )
        return created_user_file_drive.id

    async def upload_files(
        self, db: AsyncSession, user_id: int, files: List[UploadFile]
    ):
        results = []
        for file in files:
            try:
                if not file.filename:
                    continue

                # 공통 파일 업로드 서비스 사용
                file_result = await file_upload_service.upload_file_with_embedding(
                    db=db,
                    file=file,
                )

                # user_id 정보 추가
                file_result["user_id"] = user_id

                # UserFileDrive 메타데이터 생성
                user_drive_id = await self._create_user_file_drive_metadata(
                    db, file_result, user_id
                )

                task = cel.send_task(
                    name="embedding_file",
                    args=[file_result["file_id"], "user_drive", user_drive_id],
                )

                results.append(
                    {
                        "state": "FAILURE" if task.state == "FAILURE" else "WAIT",
                        "user_file_id": user_drive_id,
                        "filename": file.filename,
                        "file_size": file_result["file_size"],
                        "file_type": file_result["file_type"],
                        "user_id": user_id,
                        "created_at": file_result["created_at"],
                    }
                )

            except Exception as e:
                logger.error(f"Failed to process file {file.filename}: {e}")
                results.append(
                    {"state": "FAILURE", "error": str(e), "filename": file.filename}
                )

        return results

    async def get_files_by_user_id(
        self, db: AsyncSession, user_id: int, skip: int = 0, limit: int = 10
    ):
        total = await self.crud_user_file_drive.count_by_owner(db, user_id=user_id)
        # 최적화된 조인 메서드 사용 - 필요한 필드만 한 번에 조회
        files = await self.crud_user_file_drive.get_files_by_owner_optimized(
            db, user_id=user_id, skip=skip, limit=limit
        )

        return {"total": total, "files": files}

    async def get_file_by_user_id_and_user_file_id_with_file(
        self, db: AsyncSession, user_id: int, user_file_id: int
    ):
        file = await self.crud_user_file_drive.get_by_id_and_user_id_with_file(
            db, id=user_file_id, user_id=user_id
        )

        return file

    async def delete_file(self, db: AsyncSession, file_id: int):
        file_to_delete = await self.get_file_by_id(db, file_id=file_id)

        # Files 테이블에서 실제 파일 정보 가져오기
        actual_file = await self.crud_files.get(db, id=int(file_to_delete.file_id))
        if not actual_file:
            raise ServiceException(
                status_code=404,
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                detail="파일 정보를 찾을 수 없습니다.",
            )

        try:
            # 실제 파일 삭제
            os.remove(actual_file.file_path)
        except FileNotFoundError:
            logger.warning(
                f"File not found on disk, but proceeding with DB deletion: {actual_file.file_path}"
            )
        except Exception as e:
            logger.error(f"Error deleting file from disk {actual_file.file_path}: {e}")
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail="파일 삭제에 실패했습니다.",
            )

        # UserFileDrive 레코드 삭제
        await self.crud_user_file_drive.delete(db, id=file_id)

        # Files 테이블에서도 삭제 (또는 상태를 DELETED로 변경)
        await self.crud_files.update(
            db, db_obj=actual_file, obj_in={"state": "DELETED"}
        )

        return {"message": "파일이 성공적으로 삭제되었습니다."}

    async def attach_file_to_chat(
        self, db: AsyncSession, chat_id: str, file_id: int, user_id: int
    ):
        """
        UserFileDrive에 있는 파일을 채팅에 첨부합니다.
        - 파일이 사용자 소유인지 확인
        - ChatDocuments 테이블에 메타데이터 생성
        """
        chat_document_service = ChatDocumentService()

        try:
            # 1. 파일이 존재하고 사용자 소유인지 확인
            user_file = await self.get_file_by_id(db=db, file_id=file_id)

            # 2. Files 테이블에서 실제 파일 정보 조회
            actual_file = await self.crud_files.get(db, id=user_file.file_id)
            original_filename = (
                actual_file.original_filename if actual_file else "Unknown"
            )

            # 3. ChatDocumentService를 통해 파일 첨부
            created_doc = await chat_document_service.attach_file_to_chat(
                db=db,
                user_id=user_id,
                chat_id=chat_id,
                file_id=user_file.file_id,
            )

            return {
                "message": "파일이 채팅에 성공적으로 첨부되었습니다",
                "chat_id": chat_id,
                "file_id": file_id,
                "chat_doc_id": created_doc.chat_docs_id,
                "original_filename": original_filename,
            }

        except ServiceException:
            raise
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"채팅에 파일 첨부 중 오류가 발생했습니다: {str(e)}",
            )

    async def attach_file_to_agent(
        self,
        db: AsyncSession,
        agent_id: int,
        file_id: int,
        user_id: int,
        document_type: str = "KNOWLEDGE",
    ):
        """
        UserFileDrive에 있는 파일을 에이전트에 첨부합니다.
        - 파일이 사용자 소유인지 확인
        - AgentDocuments 테이블에 메타데이터 생성
        """
        agent_document_service = AgentDocumentService()

        try:
            # 1. 파일이 존재하고 사용자 소유인지 확인
            user_file = await self.get_file_by_id(db=db, file_id=file_id)

            # 2. Files 테이블에서 실제 파일 정보 조회
            actual_file = await self.crud_files.get(db, id=user_file.file_id)
            original_filename = (
                actual_file.original_filename if actual_file else "Unknown"
            )

            # 3. AgentDocumentService를 통해 파일 첨부
            created_doc = await agent_document_service.attach_file_to_agent(
                db=db,
                agent_id=agent_id,
                file_id=user_file.file_id,
                document_type=document_type,
            )

            return {
                "message": "파일이 에이전트에 성공적으로 첨부되었습니다",
                "agent_id": agent_id,
                "file_id": file_id,
                "agent_doc_id": created_doc.agent_docs_id,
                "document_type": document_type,
                "original_filename": original_filename,
            }

        except ServiceException:
            raise
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"에이전트에 파일 첨부 중 오류가 발생했습니다: {str(e)}",
            )

    async def attach_files_to_chat(
        self, db: AsyncSession, chat_id: str, user_file_ids: List[int]
    ) -> BatchAttachResponse:
        """
        UserFileDrive에 있는 여러 파일을 채팅에 첨부합니다.
        - 각 파일이 사용자 소유인지 확인
        - ChatDocuments 테이블에 메타데이터 생성
        """
        chat_document_service = ChatDocumentService()
        results = []
        successful_files = 0
        failed_files = 0

        # 1. 모든 파일을 한 번에 조회
        user_files = await self.crud_files.get_multi_by_ids(
            db=db, file_ids=user_file_ids
        )

        # 2. 조회 결과를 dict로 변환하여 빠른 lookup
        user_files_dict = {uf.id: uf for uf in user_files}

        # 3. 각 파일 ID에 대해 처리
        for file_id in user_file_ids:
            try:
                # 파일이 존재하고 사용자 소유인지 확인
                user_file = user_files_dict.get(file_id)
                if not user_file:
                    results.append(
                        FileAttachResult(
                            file_id=file_id,
                            success=False,
                            message="파일을 찾을 수 없습니다.",
                        )
                    )
                    failed_files += 1
                    continue

                # ChatDocumentService를 통해 파일 첨부
                created_doc = await chat_document_service.attach_file_to_chat(
                    db=db,
                    chat_id=chat_id,
                    file_id=user_file.id,  # type: ignore
                )

                results.append(
                    FileAttachResult(
                        file_id=file_id,
                        success=True,
                        message="파일이 채팅에 성공적으로 첨부되었습니다",
                        doc_id=created_doc.chat_docs_id,
                        original_filename=user_file.original_filename,
                    )
                )
                successful_files += 1

            except ServiceException as e:
                results.append(
                    FileAttachResult(
                        file_id=file_id,
                        success=False,
                        message=f"파일 첨부 실패: {str(e)}",
                    )
                )
                failed_files += 1
            except Exception as e:
                results.append(
                    FileAttachResult(
                        file_id=file_id,
                        success=False,
                        message=f"예상치 못한 오류: {str(e)}",
                    )
                )
                failed_files += 1

        return BatchAttachResponse(
            total_files=len(user_file_ids),
            successful_files=successful_files,
            failed_files=failed_files,
            results=results,
        )

    async def attach_files_to_agent(
        self,
        db: AsyncSession,
        agent_id: int,
        user_file_ids: List[int],
        document_type: str = "KNOWLEDGE",
    ) -> BatchAttachResponse:
        """
        UserFileDrive에 있는 여러 파일을 에이전트에 첨부합니다.
        - 각 파일이 사용자 소유인지 확인
        - AgentDocuments 테이블에 메타데이터 생성
        """
        agent_document_service = AgentDocumentService()
        results = []
        successful_files = 0
        failed_files = 0

        # 1. 모든 파일을 한 번에 조회
        user_files = await self.crud_user_file_drive.get_multi_by_ids(
            db=db, file_ids=user_file_ids
        )

        # 2. 조회 결과를 dict로 변환하여 빠른 lookup
        user_files_dict = {uf.id: uf for uf in user_files}

        # 3. 각 파일 ID에 대해 처리
        for file_id in user_file_ids:
            try:
                # 파일이 존재하고 사용자 소유인지 확인
                user_file = user_files_dict.get(file_id)
                if not user_file:
                    results.append(
                        FileAttachResult(
                            file_id=file_id,
                            success=False,
                            message="파일을 찾을 수 없습니다.",
                        )
                    )
                    failed_files += 1
                    continue

                # AgentDocumentService를 통해 파일 첨부
                created_doc = await agent_document_service.attach_file_to_agent(
                    db=db,
                    agent_id=agent_id,
                    file_id=user_file.file_id,
                    document_type=document_type,
                )

                results.append(
                    FileAttachResult(
                        file_id=file_id,
                        success=True,
                        message="파일이 에이전트에 성공적으로 첨부되었습니다",
                        doc_id=created_doc.agent_docs_id,
                        original_filename=user_file.original_filename,
                    )
                )
                successful_files += 1

            except ServiceException as e:
                results.append(
                    FileAttachResult(
                        file_id=file_id,
                        success=False,
                        message=f"파일 첨부 실패: {str(e)}",
                    )
                )
                failed_files += 1
            except Exception as e:
                results.append(
                    FileAttachResult(
                        file_id=file_id,
                        success=False,
                        message=f"예상치 못한 오류: {str(e)}",
                    )
                )
                failed_files += 1

        return BatchAttachResponse(
            total_files=len(user_file_ids),
            successful_files=successful_files,
            failed_files=failed_files,
            results=results,
        )


user_file_drive_service = UserFileDriveService()
