import os
import uuid
from typing import List, Optional

from celery_config import cel, check_celery_health
from core.config import get_setting
from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from database.crud.files import crud_files
from fastapi import HTTPException, UploadFile
from services.schemas.files import FileCreate
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()
settings = get_setting()


class FileUploadService:
    def __init__(self):
        self.crud_files = crud_files

    async def upload_file_with_embedding(
        self,
        db: AsyncSession,
        file: UploadFile,
        index_name: Optional[str] = None,
    ) -> dict:
        """
        파일 업로드 및 임베딩 작업을 처리하는 공통 메서드

        Args:
            db: 데이터베이스 세션
            file: 업로드할 파일
            domain_id: 도메인별 문서 ID
            index_name: AI Search 인덱스명 (선택사항)

        Returns:
            dict: 업로드 결과 정보
        """
        if not file.filename:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.UNSUPPORTED_FILE_TYPE,
                detail="파일명이 없는 파일은 업로드할 수 없습니다.",
            )

        _, f_ext = os.path.splitext(file.filename)
        uuid_filename = f"{uuid.uuid4().hex}{f_ext}"
        file_path = os.path.join(settings.SHARED_DATA_PATH, uuid_filename)

        try:
            # 파일 저장
            file_content = await file.read()
            with open(file_path, "wb") as f:
                f.write(file_content)
                f.flush()  # 버퍼를 강제로 디스크에 기록
                os.fsync(f.fileno())  # 파일 시스템 동기화로 완전한 저장 보장

            file_size = os.path.getsize(file_path)

            # Files 테이블에 파일 정보 저장 (WAIT 상태로)
            file_schema = FileCreate(
                original_filename=file.filename,
                uuid_filename=uuid_filename,
                file_path=file_path,
                file_type=f_ext,
                file_size=file_size,
                state="WAIT",
                index_name=index_name or settings.AZURE_AI_SEARCH_INDEX,
                summary=None,
                original_content=None,  # 업로드 시점에는 None, 임베딩 작업에서 추출 후 업데이트
            )
            created_file = await self.crud_files.create(
                db, obj_in=file_schema.model_dump()
            )

            # celery health check
            if not check_celery_health(cel):
                raise HTTPException(
                    status_code=400,
                    detail="Celery is not available. Please try again later.",
                )

            # celery 임베딩 작업 실행
            task = cel.send_task(
                name="embedding_file",
                args=[created_file.id],
            )

            logger.info(
                f"TASK [upload_file] state: {task.state}, ready: {task.ready()}"
            )

            # 결과 반환
            result = {
                "file_id": created_file.id,
                "original_filename": file.filename,
                "uuid_filename": uuid_filename,
                "file_path": file_path,
                "state": "FAILURE" if task.state == "FAILURE" else "WAIT",
                "file_size": file_size,
                "file_type": f_ext,
                "created_at": created_file.created_at,
            }

            if task.state == "FAILURE":
                await self.crud_files.update_state(
                    db, file_id=created_file.id, state="FAILURE"
                )

            return result

        except Exception as e:
            logger.error(f"Failed to upload file {file.filename}: {e}")
            # 실패 시 파일 정리
            if os.path.exists(file_path):
                os.remove(file_path)
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"파일 업로드에 실패했습니다: {file.filename}",
            )

    async def upload_multiple_files_with_embedding(
        self,
        db: AsyncSession,
        files: List[UploadFile],
        index_name: Optional[str] = None,
    ) -> List[dict]:
        """
        여러 파일을 업로드하고 임베딩 작업을 처리하는 메서드

        Args:
            db: 데이터베이스 세션
            files: 업로드할 파일들
            domain_type: 도메인 타입 (chat, agent, user_drive)
            get_domain_id_func: 도메인 ID를 가져오는 함수 (file_result를 받아서 domain_id 반환)
            index_name: AI Search 인덱스명 (선택사항)

        Returns:
            List[dict]: 업로드 결과들
        """
        results = []
        for file in files:
            try:
                if not file.filename:
                    continue

                # 먼저 파일을 업로드하고 Files 테이블에 저장
                file_result = await self.upload_file_with_embedding(
                    db=db,
                    file=file,
                    index_name=index_name,
                )

                results.append(file_result)

            except Exception as e:
                logger.error(f"Error processing file {file.filename}: {e}")
                results.append(
                    {
                        "state": "FAILURE",
                        "original_filename": (
                            file.filename if file.filename else "unknown"
                        ),
                        "error": str(e),
                    }
                )

        return results


file_upload_service = FileUploadService()
