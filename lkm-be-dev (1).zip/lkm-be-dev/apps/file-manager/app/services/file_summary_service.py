from core.config import get_setting
from langchain_core.prompts import PromptTemplate
from langchain_openai import AzureChatOpenAI
from services.prompt.file_summary_prompt import FILE_SUMMARY_PROMPT

settings = get_setting()


class FileSummaryService:
    def __init__(self):
        self.llm = AzureChatOpenAI(
            model=settings.OPENAI_MODEL,
            temperature=0,
            api_key=settings.OPENAI_API_KEY,
            api_version=settings.OPENAI_API_VERSION,
            azure_endpoint=settings.OPENAI_ENDPOINT,
            azure_deployment=settings.OPENAI_DEPLOYMENT,
        )

    def get_file_summary(self, text: str):
        prompt = self._get_file_summary_prompt()
        chain = prompt | self.llm
        response = chain.invoke({"text": text})
        return response.content

    def _get_file_summary_prompt(self):
        return PromptTemplate(
            template=FILE_SUMMARY_PROMPT,
            input_variables=["text"],
        )
