from typing import List

from core.clients import get_embedding_model
from core.config import get_setting
from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from core.utils.vector import VectorApproach
from database.crud.chat_documents import CRUDChatDocumentsAsync
from fastapi import UploadFile
from services.file_service import FileService
from services.file_upload_service import FileUploadService
from services.schemas.chat_documents import ChatDocCreate
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logging()
settings = get_setting()


class ChatDocumentService:
    def __init__(self):
        self.crud_chat_docs = CRUDChatDocumentsAsync()
        self.file_service = FileService()
        self.file_upload_service = FileUploadService()

    async def execute(self, db: AsyncSession, files: List[UploadFile], user_id: int):
        """파일 업로드 실행 - 직접 처리"""
        results = []

        for file in files:
            if not file.filename:
                continue

            try:
                # 1. FileUploadService로 파일 업로드 (Files 테이블 생성 + Celery 작업)
                file_result = await self.file_upload_service.upload_file_with_embedding(
                    db=db,
                    file=file,
                )

                # 2. ChatDocuments 메타데이터 생성
                chat_doc_data = ChatDocCreate(
                    user_id=user_id,
                    chat_id="",
                    file_id=file_result["file_id"],
                )
                created_doc = await self.crud_chat_docs.create(
                    db=db, obj_in=chat_doc_data.model_dump()
                )

                # 3. 결과 생성
                results.append(
                    {
                        "state": file_result["state"],
                        "chat_docs_id": created_doc.chat_docs_id,
                        "filename": file.filename,
                        "file_size": file_result["file_size"],
                        "file_type": file_result["file_type"],
                        "chat_id": created_doc.chat_id,
                        "created_at": file_result["created_at"],
                    }
                )

            except Exception as e:
                logger.error(f"파일 처리 실패 [{file.filename}]: {str(e)}")
                results.append(
                    {"state": "FAILURE", "error": str(e), "filename": file.filename}
                )

        return results

    async def get_document_summary(self, db: AsyncSession, *, chat_id: str):
        """채팅 문서 요약 조회 - 직접 JOIN"""
        try:
            db_docs = await self.crud_chat_docs.get_by_chat_id(db, chat_id=chat_id)

            # summary 매핑
            docs_summaries = {}
            for doc in db_docs:
                summary = doc.file.summary if doc.file and doc.file.summary else ""
                docs_summaries[doc.chat_docs_id] = summary

            return docs_summaries
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get document summary, {str(e)}",
            )

    async def search_vector(
        self, db: AsyncSession, chat_id: str, query: str, n: int = 3
    ):
        """벡터 검색 - 직접 JOIN으로 file_id 추출"""
        try:
            # 단순 JOIN 쿼리로 file_id 목록 추출
            db_docs = await self.crud_chat_docs.get_by_chat_id(db, chat_id=chat_id)
            file_ids = []
            for doc in db_docs:
                if hasattr(doc, "file_id") and doc.file_id is not None:
                    # file_id 값을 안전하게 추출
                    file_id_value = doc.file_id
                    if hasattr(file_id_value, "__int__"):
                        file_ids.append(int(file_id_value))
                    else:
                        # 직접 값을 가져오기
                        file_ids.append(file_id_value)

            if not file_ids:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail="검색 가능한 문서가 없습니다.",
                )

            # 벡터 검색 실행
            search_vector_client = VectorApproach(
                search_index=settings.AZURE_AI_SEARCH_INDEX,
                search_endpoint=settings.AZURE_AI_SEARCH_ENDPOINT,
                search_key=settings.AZURE_AI_SEARCH_KEY,
                embedding_approach=get_embedding_model(),
            )

            return search_vector_client.search_vector(
                file_ids=file_ids, query=query, n=n
            )

        except ServiceException:
            raise
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to search vector, {str(e)}",
            )

    async def search_vector_by_doc_id(
        self, db: AsyncSession, chat_doc_id: int, query: str, n: int = 3
    ):
        """벡터 검색 - 개별 문서 ID로 직접 조회"""
        try:
            # 단순 조회
            db_doc = await self.crud_chat_docs.get_by_chat_doc_id_with_file(
                db, chat_doc_id=chat_doc_id
            )
            if not db_doc:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"Document with id {chat_doc_id} not found",
                )

            file_ids = [db_doc.file_id] if db_doc.file_id is not None else []

            # 벡터 검색 실행
            search_vector_client = VectorApproach(
                search_index=settings.AZURE_AI_SEARCH_INDEX,
                search_endpoint=settings.AZURE_AI_SEARCH_ENDPOINT,
                search_key=settings.AZURE_AI_SEARCH_KEY,
                embedding_approach=get_embedding_model(),
            )

            return search_vector_client.search_vector(
                file_ids=file_ids, query=query, n=n
            )

        except ServiceException:
            raise
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to search vector, {str(e)}",
            )

    async def get_document_state(self, db: AsyncSession, *, doc_id: int):
        """개별 문서 상태 조회"""
        try:
            db_doc = await self.crud_chat_docs.get_by_chat_doc_id_with_file(
                db, chat_doc_id=doc_id
            )
            if not db_doc:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"Document with id {doc_id} not found",
                )

            file_state = db_doc.file.state if db_doc.file else "UNKNOWN"

            return {
                "chat_docs_id": db_doc.chat_docs_id,
                "file_id": db_doc.file_id,
                "chat_id": db_doc.chat_id,
                "user_id": db_doc.user_id,
                "state": file_state,
                "created_at": db_doc.created_at,
            }
        except ServiceException:
            raise
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get document state, {str(e)}",
            )

    async def get_documents_by_chat_id(self, db: AsyncSession, *, chat_id: str):
        """채팅 문서 목록 조회 - 직접 JOIN"""
        try:
            return await self.crud_chat_docs.get_by_chat_id(db, chat_id=chat_id)
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get chat documents, {str(e)}",
            )

    async def get_document_original(self, db: AsyncSession, doc_id: int):
        """원본 문서 조회"""
        try:
            db_doc = await self.crud_chat_docs.get_by_chat_doc_id_with_file(
                db, chat_doc_id=doc_id
            )
            if not db_doc:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"Document with id {doc_id} not found",
                )

            # file_id 안전하게 가져오기
            file_id = getattr(db_doc, "file_id", None)
            if not file_id:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail="파일 ID 정보를 찾을 수 없습니다.",
                )

            # 파일 상태 확인 및 대기를 가장 먼저 수행 (WAIT -> READY 될 때까지)
            file = await self.file_service.wait_for_file_ready(db, file_id)

            # READY 상태인 경우에만 content 조회
            content = ""
            try:
                # 파일 타입에 따른 content 조회 방식 결정
                file_type = getattr(file, "file_type", "") or ""
                is_text_file = file_type.startswith(
                    "text/"
                ) or file.original_filename.lower().endswith(
                    (
                        ".txt",
                        ".py",
                        ".md",
                        ".js",
                        ".css",
                        ".html",
                        ".sql",
                        ".json",
                        ".csv",
                    )
                )

                if is_text_file:
                    # 텍스트 파일: 파일 시스템에서 직접 읽기
                    try:
                        with open(file.file_path, "r", encoding="utf-8") as f:
                            content = f.read()
                        logger.info(f"텍스트 파일 직접 읽기 성공 [file_id: {file_id}]")
                    except Exception as text_e:
                        logger.warning(
                            f"텍스트 파일 읽기 실패 [file_id: {file_id}]: {str(text_e)}"
                        )
                        content = ""
                else:
                    # 이미지/PDF/Word: DB의 original_content 사용
                    content = getattr(file, "original_content", "") or ""
                    if not content:
                        logger.warning(
                            f"DB에 저장된 content가 없습니다 [file_id: {file_id}]"
                        )

                if content is None:
                    content = ""

            except Exception as e:
                logger.warning(f"파일 content 조회 실패 [file_id: {file_id}]: {str(e)}")
                content = ""

            return {
                "file_id": file.id,
                "filename": file.original_filename,
                "content": content,
                "file_path": file.file_path,
                "file_size": file.file_size,
                "file_type": file.file_type,
                "created_at": file.created_at,
            }
        except ServiceException:
            raise
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to get document original, {str(e)}",
            )

    async def update_chat_id(self, db: AsyncSession, *, chat_doc_id: int, chat_id: str):
        """채팅 ID 업데이트"""
        try:
            db_doc = await self.crud_chat_docs.get_by_chat_doc_id_with_file(
                db, chat_doc_id=chat_doc_id
            )
            if not db_doc:
                raise ServiceException(
                    status_code=404,
                    error_code=ErrorCode.RESOURCE_NOT_FOUND,
                    detail=f"Document with id {chat_doc_id} not found",
                )

            updated_doc = await self.crud_chat_docs.update(
                db, db_obj=db_doc, obj_in={"chat_id": chat_id}
            )

            return {
                "chat_docs_id": updated_doc.chat_docs_id,
                "chat_id": updated_doc.chat_id,
                "updated_at": updated_doc.updated_at,
            }
        except ServiceException:
            raise
        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to update chat id, {str(e)}",
            )

    async def attach_file_to_chat(
        self, db: AsyncSession, *, chat_id: str, file_id: int
    ):
        """파일을 채팅에 첨부하는 메서드"""
        try:
            chat_doc_data = {"chat_id": chat_id, "file_id": file_id}

            created_doc = await self.crud_chat_docs.create(db=db, obj_in=chat_doc_data)

            return created_doc

        except Exception as e:
            raise ServiceException(
                status_code=500,
                error_code=ErrorCode.UNEXPECTED_ERROR,
                detail=f"Failed to attach file to chat, {str(e)}",
            )
