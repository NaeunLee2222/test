from . import file_embedding_task

# This file makes the 'tasks' directory a Python package.
