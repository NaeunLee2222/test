import traceback

import docx2txt
import pandas as pd
from celery_config import cel
from core.clients import (
    get_doc_intelligence_client,
    get_vector_approach,
)
from core.config import get_setting
from core.log.logging import get_logging
from database.session import SyncSessionLocal
from pptx import Presentation
from services.file_summary_service import FileSummaryService
from services.schemas.files import FileUpdate

from tasks.celery.celery_file_service import CeleryFileService

logger = get_logging()
settings = get_setting()

celery_file_service = CeleryFileService()


def read_office_file_content(filepath: str, filename: str) -> str:
    """
    Office 문서를 라이브러리로 직접 읽어서 내용을 반환
    """
    try:
        file_extension = filename.lower().split(".")[-1] if "." in filename else ""

        if file_extension == "docx":
            # Word 문서
            content = docx2txt.process(filepath)
            return content if content else ""

        elif file_extension == "pptx":
            # PowerPoint 문서
            prs = Presentation(filepath)
            text_content = []
            for slide in prs.slides:
                for shape in slide.shapes:
                    try:
                        text = getattr(shape, "text", None)
                        if text:
                            text_content.append(str(text))
                    except (AttributeError, Exception):
                        continue
            return "\n".join(text_content)

        elif file_extension in ("xlsx", "xls"):
            # Excel 파일
            df = pd.read_excel(filepath, sheet_name=None)
            text_content = []
            for sheet_name, sheet_df in df.items():
                text_content.append(f"=== Sheet: {sheet_name} ===")
                text_content.append(sheet_df.to_string())
            return "\n".join(text_content)

        elif file_extension in (
            "txt",
            "py",
            "md",
            "js",
            "css",
            "html",
            "sql",
            "json",
            "csv",
            "xml",
            "yaml",
            "yml",
        ):
            # 텍스트 파일
            with open(filepath, "r", encoding="utf-8") as f:
                return f.read()

        else:
            return ""

    except Exception as e:
        logger.error(f"Failed to read office file {filepath}: {str(e)}")
        # 에러 발생 시 빈 문자열 반환 (DocIntelligence 폴백 유도)
        return ""


@cel.task(
    name="embedding_file",
    bind=True,
    max_retries=1,
    default_retry_delay=60,
)
def embedding_file_task(
    self,
    file_id: int,
):
    """
    통합된 파일 임베딩 태스크
    Args:
        file_id: Files 테이블의 파일 ID
        domain_type: 도메인 타입 (chat, agent, user_drive) - 로깅용
    """
    logger.info(f"Starting file embedding for file_id: {file_id}")

    with SyncSessionLocal() as db:
        try:
            # Files 테이블에서 파일 정보 조회
            file_info = celery_file_service.get_file(db, file_id=file_id)
            if not file_info:
                logger.error(f"File with id {file_id} not found.")
                return

            filepath = str(file_info.file_path)
            original_filename = str(file_info.original_filename)
            uuid_filename = str(file_info.uuid_filename)
            search_index_name = (
                str(file_info.index_name)
                if file_info.index_name is not None
                else settings.AZURE_AI_SEARCH_INDEX
            )

            # 파일 처리 방식 결정
            doc_client = get_doc_intelligence_client()
            vector_client = get_vector_approach(search_index_name)

            file_extension = (
                original_filename.lower().split(".")[-1]
                if "." in original_filename
                else ""
            )

            # 라이브러리로 직접 처리할 파일 타입들
            direct_processing_extensions = {
                "docx",
                "pptx",
                "xlsx",
                "xls",  # Office 문서 (DocIntelligence 지원 제한적)
                "txt",
                "py",
                "md",
                "js",
                "css",
                "html",
                "sql",
                "json",
                "csv",
                "xml",
                "yaml",
                "yml",  # 텍스트 파일
            }

            pages = []
            extracted_content = None
            processing_method = ""

            if file_extension in direct_processing_extensions:
                # 라이브러리로 직접 처리 시도
                try:
                    content = read_office_file_content(filepath, original_filename)
                    if content.strip():  # 빈 내용이 아닌 경우
                        # 텍스트를 페이지 형태로 변환
                        from core.utils.docintelligence import Page

                        pages = [
                            Page(
                                page_content=content,
                                metadata={
                                    "doc_id": file_id,
                                    "filepath": filepath,
                                    "filename": original_filename,
                                    "page_num": 1,
                                },
                            )
                        ]

                        # Office 문서만 original_content 저장
                        if file_extension in ("docx", "pptx", "xlsx", "xls"):
                            extracted_content = content

                        processing_method = "direct_library"
                        logger.info(
                            f"File processed directly with library: {original_filename}"
                        )
                    else:
                        logger.warning(
                            f"No content extracted from {original_filename}, falling back to DocIntelligence"
                        )
                        # 빈 내용이면 DocIntelligence로 폴백
                        raise Exception("Empty content, fallback to DocIntelligence")

                except Exception as e:
                    logger.warning(
                        f"Direct processing failed for {original_filename}, using DocIntelligence fallback: {str(e)}"
                    )
                    # 직접 처리 실패 시 DocIntelligence로 폴백
                    pages = doc_client.load_file(
                        doc_id=file_id, filepath=filepath, filename=uuid_filename
                    )
                    if pages:
                        extracted_content = "\n".join(
                            [page.page_content for page in pages]
                        )
                        processing_method = "docintelligence_fallback"
                        logger.info(
                            f"Content extracted via DocIntelligence (fallback): {original_filename}"
                        )
            else:
                # PDF, 이미지 등은 DocIntelligence로 처리
                pages = doc_client.load_file(
                    doc_id=file_id, filepath=filepath, filename=uuid_filename
                )
                if pages:
                    extracted_content = "\n".join([page.page_content for page in pages])
                    processing_method = "docintelligence"
                    logger.info(
                        f"Content extracted via DocIntelligence: {original_filename}"
                    )

            # 모든 파일은 반드시 임베딩 처리되어야 함
            if not pages:
                # 최후의 수단: 빈 페이지라도 생성하여 임베딩 처리
                from core.utils.docintelligence import Page

                pages = [
                    Page(
                        page_content=f"파일명: {original_filename}\n내용을 읽을 수 없습니다.",
                        metadata={
                            "doc_id": file_id,
                            "filepath": filepath,
                            "filename": original_filename,
                            "page_num": 1,
                        },
                    )
                ]
                processing_method = "fallback_empty"
                logger.warning(
                    f"Created fallback page for unprocessable file: {original_filename}"
                )

            # 파일 요약 생성
            file_summary_service = FileSummaryService()
            all_content = "\n".join([page.page_content for page in pages])
            file_summary_raw = file_summary_service.get_file_summary(all_content)
            file_summary = str(file_summary_raw) if file_summary_raw else None
            logger.info(f"File summary generated: {file_summary}")

            # 벡터 DB 업로드 (모든 파일 반드시 임베딩)
            uploaded = vector_client.upload_pages(file_id=file_id, pages=pages)
            logger.info(
                f"Uploaded {len(pages)} pages to vector database ({processing_method}): {uploaded}"
            )

            # 파일 상태 업데이트
            if uploaded:
                update_data = FileUpdate(
                    state="READY",
                    index_name=search_index_name,
                    summary=file_summary,
                    original_content=extracted_content,
                )
                celery_file_service.update_file(
                    db, file_id=file_id, update_data=update_data
                )
                logger.info(
                    f"File {file_id} processed and state set to READY. Method: {processing_method}"
                )
            else:
                update_data = FileUpdate(
                    state="FAILURE",
                    index_name=search_index_name,
                )
                celery_file_service.update_file(
                    db, file_id=file_id, update_data=update_data
                )
                raise Exception("Failed to upload pages to vector database")

            return {
                "file_id": file_id,
                "original_filename": original_filename,
                "processing_method": processing_method,
                "pages_count": len(pages),
            }

        except Exception as e:
            logger.error(f"Error during file embedding: {str(e)}")
            traceback.print_exc()

            if self.request.retries >= self.max_retries:
                logger.error(f"Task ID: {self.request.id} - Max retries exceeded.")
                update_data = FileUpdate(
                    state="FAILURE",
                    index_name=search_index_name,
                )
                celery_file_service.update_file(
                    db, file_id=file_id, update_data=update_data
                )
                raise e
            else:
                self.retry(exc=e)
        finally:
            logger.info(f"Task ID : {self.request.id} END.")
