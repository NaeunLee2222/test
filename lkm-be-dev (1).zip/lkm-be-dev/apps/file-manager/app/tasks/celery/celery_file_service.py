from typing import Optional

from database.crud.files import CRUDFilesAsync
from database.models.files import Files
from services.schemas.files import FileUpdate
from sqlalchemy.orm import Session


class CeleryFileService:
    def __init__(self):
        self.crud_files = CRUDFilesAsync()

    def get_file(self, db: Session, file_id: int) -> Optional[Files]:
        """파일 정보 조회"""
        return db.query(Files).filter(Files.id == file_id).first()

    def update_file(self, db: Session, file_id: int, update_data: FileUpdate):
        """파일 정보 업데이트"""
        db_file = self.get_file(db, file_id=file_id)
        if db_file:
            update_dict = update_data.model_dump(exclude_unset=True)
            for key, value in update_dict.items():
                setattr(db_file, key, value)
            db.commit()
            db.refresh(db_file)
        return db_file
