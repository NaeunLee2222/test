import time

from celery import Celery
from core.config import get_setting
from core.log.logging import get_logging

logger = get_logging()
settings = get_setting()


def make_celery(app_name=__name__):
    if settings.REDIS_USE_SENTINEL:
        # Redis Sentinel을 통한 연결 - Celery에서는 직접 Redis URL 사용
        # Sentinel을 통해 master 노드의 실제 주소를 얻어서 사용
        from redis.sentinel import Sentinel

        sentinel = Sentinel(
            [(settings.REDIS_SENTINEL_HOST, settings.REDIS_SENTINEL_PORT)],
            password=settings.REDIS_SENTINEL_PASSWORD,
        )

        # Master 노드의 실제 주소와 포트를 얻기
        master_host, master_port = sentinel.discover_master(
            settings.REDIS_SENTINEL_MASTER_NAME
        )
        password = settings.REDIS_ACCESS_KEY

        # 직접 Redis URL 사용
        connection_url = f"redis://:{password}@{master_host}:{master_port}/{settings.REDIS_USER_INFO_DB}"
        logger.info(f"Connected to Redis Master via Sentinel: {connection_url}")
    else:
        # 직접 Redis 연결
        if settings.REDIS_USE_SSL:
            connection_url = f"rediss://:{settings.REDIS_ACCESS_KEY}@{settings.REDIS_HOST}:{settings.REDIS_PORT}/{settings.REDIS_USER_INFO_DB}?ssl_cert_reqs=required"
        else:
            connection_url = f"redis://:{settings.REDIS_ACCESS_KEY}@{settings.REDIS_HOST}:{settings.REDIS_PORT}/{settings.REDIS_USER_INFO_DB}"
        logger.info(f"Connected to Redis on {connection_url}")

    backend = connection_url
    broker = connection_url
    return Celery(app_name, backend=backend, broker=broker)


# Celery 앱 초기화
cel = make_celery("file-manager")

# cel.autodiscover_tasks(["tasks"])
cel.conf.imports = "tasks.file_embedding_task"
cel.conf.update(worker_concurrency=settings.CELERY_WORKER)
cel.conf.broker_connection_retry_on_startup = True
cel.conf.broker_transport_options = {
    "max_retries": 1,
    "interval_start": 0,
    "interval_step": 0.2,
    "interval_max": 0.5,
}

# cel.conf.task_acks_late = True                       # ack after task end
# cel.conf.task_acks_on_failure_or_timeout = True      # ack if task exception
# cel.conf.task_reject_on_worker_lost = True           # no ack if worker killed

cel.conf.redis_backend_health_check_interval = 30

cel.conf.worker_max_memory_per_child = 400000  # 400MB


def get_celery_app() -> Celery:
    return cel


def check_celery_health(celery_app, max_retries=3, delay=5):
    for attempt in range(1, max_retries + 1):
        try:
            inspect = celery_app.control.inspect()
            availability = inspect.ping()
            logger.info(f"inspect.ping(): {availability}")
            if availability and any(
                server.get("ok") == "pong" for server in availability.values()
            ):
                logger.info("Celery health check passed.")
                return True

            logger.info(
                f"Celery health check attempt {attempt} failed. Retrying in {delay} seconds..."
            )
        except Exception as e:
            logger.error(f"Celery health check attempt {attempt} failed: {str(e)}")
            time.sleep(delay)

    logger.error("Celery is not available after retries.")
    return False
