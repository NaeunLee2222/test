from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import List, Optional

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging
from core.utils.docintelligence import Page

logger = get_logging()


class VectorApproach:
    def __init__(
        self,
        search_index: str,
        search_endpoint: str,
        search_key: str,
        embedding_approach,
    ):
        self.search_index = search_index
        self.search_endpoint = search_endpoint
        self.search_key = search_key
        self.embedding_approach = embedding_approach

    def get_search_client(self):
        logger.debug(f"Making {self.search_endpoint} client...")
        return SearchClient(
            self.search_endpoint, self.search_index, AzureKeyCredential(self.search_key)
        )

    def embedding_section(
        self,
        search_client: SearchClient,
        file_id: int,
        index: int,
        page: Page,
    ) -> int:

        document = {
            "id": f"file-{file_id}-page-{page.metadata.get('page_num')}-{index}",
            "content": page.page_content,
            "content_vector": self.embedding_approach.embed_query(
                text=page.page_content
            ),
            "sourcepage": f"{page.metadata.get('filename')}"
            + (f"#page={page.metadata.get('page_num')}"),
            "sourcefile": page.metadata.get("filename"),
            "sourcefile_id": page.metadata.get("doc_id"),
            "created_at": datetime.utcnow(),
            "file_id": file_id,
        }

        search_client.upload_documents([document])
        return index

    def upload_pages(
        self,
        file_id: int,
        pages: Optional[List[Page]] = None,
    ):
        """
        file_id를 사용하여 페이지들을 벡터 DB에 업로드
        """
        if not pages:
            return True

        succeed = True
        with self.get_search_client() as search_client:
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = [
                    executor.submit(
                        self.embedding_section,
                        search_client,
                        file_id,
                        i,
                        page,
                    )
                    for i, page in enumerate(pages)
                ]
                for future in as_completed(futures):
                    try:
                        result = future.result()
                    except Exception as e:
                        logger.error(f"An error occurred: {e}")
                        succeed = False
        logger.info(f"embedding complete")
        return succeed

    def create_filter(
        self,
        file_ids: Optional[list[int]] = None,
    ):
        """file_id를 사용한 필터 생성"""
        if not file_ids:
            return ""

        if len(file_ids) == 1:
            return f"file_id eq {file_ids[0]}"
        else:
            file_filter = " or ".join([f"file_id eq {file_id}" for file_id in file_ids])
            return f"({file_filter})"

    def search_vector(
        self,
        file_ids: Optional[list[int]] = None,
        query: str = "",
        n: int = 10,
    ):
        """
        file_id를 사용한 벡터 검색
        """
        if not self.embedding_approach:
            raise ServiceException(
                400, ErrorCode.NOT_DEFINED, "임베딩 모델이 정의되지 않았습니다."
            )

        search_client = self.get_search_client()

        # 필터 생성
        filter_str = self.create_filter(file_ids=file_ids)

        # 쿼리를 벡터로 변환
        embedding = self.embedding_approach.embed_query(query)

        # 벡터 쿼리 생성
        vector_query = VectorizedQuery(
            vector=embedding, k_nearest_neighbors=n, fields="content_vector"
        )

        select_fields = ["sourcepage", "content", "sourcefile_id", "file_id"]

        # 벡터 검색 실행
        docs = search_client.search(
            search_text=None,  # 순수 벡터 검색을 위해 텍스트 검색 비활성화
            filter=filter_str if filter_str else None,
            vector_queries=[vector_query],
            top=n,
            select=select_fields,
        )

        # 결과 포맷팅
        return [
            {
                "file_name": f"{doc['sourcefile_id']}/{doc['sourcepage']}",
                "content": doc["content"],
                "score": doc.get("@search.score", 0),
                "file_id": doc.get("file_id"),
            }
            for doc in docs
        ]

    def update_vector(
        self,
        file_id: int,
        updated_pages: List[Page],
    ):
        """
        특정 파일의 벡터 데이터를 업데이트
        기존 문서를 삭제하고 새로운 페이지들로 재생성
        """
        try:
            # 1. 기존 문서의 모든 섹션 삭제
            self.delete_document_vectors(file_id)

            # 2. 새로운 페이지들로 벡터 재생성
            success = self.upload_pages(file_id=file_id, pages=updated_pages)

            if success:
                logger.info(f"File {file_id} vectors updated successfully")
            else:
                logger.error(f"Failed to update vectors for file {file_id}")

            return success

        except Exception as e:
            logger.error(f"Error updating vectors for file {file_id}: {e}")
            raise ServiceException(
                500,
                ErrorCode.UNEXPECTED_ERROR,
                f"벡터 업데이트 중 오류가 발생했습니다: {str(e)}",
            )

    def delete_document_vectors(
        self,
        file_id: int,
    ):
        """
        특정 파일의 모든 벡터 데이터 삭제
        """
        try:
            search_client = self.get_search_client()

            # 삭제할 문서들 검색
            filter_str = f"file_id eq {file_id}"

            # 삭제할 문서 ID들 수집
            docs_to_delete = search_client.search(
                search_text="*",
                filter=filter_str,
                select=["id"],
                top=1000,  # 한 번에 가져올 최대 문서 수
            )

            # 문서 ID 리스트 생성
            document_ids = [{"id": doc["id"]} for doc in docs_to_delete]

            if document_ids:
                # 벡터 데이터 삭제
                search_client.delete_documents(document_ids)
                logger.info(f"Deleted {len(document_ids)} vectors for file {file_id}")
            else:
                logger.info(f"No vectors found for file {file_id}")

            return True

        except Exception as e:
            logger.error(f"Error deleting vectors for file {file_id}: {e}")
            raise ServiceException(
                500,
                ErrorCode.UNEXPECTED_ERROR,
                f"벡터 삭제 중 오류가 발생했습니다: {str(e)}",
            )
