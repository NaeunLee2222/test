import os
from io import BytesIO

from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from core.log.logging import get_logging

logger = get_logging()


class Page:
    def __init__(self, page_content: str, metadata: dict):
        self.page_content = page_content
        # medadata = {"doc_id": "", "filepath": "", "filename": "", "page_num": 1} . page_num > 0
        self.metadata = metadata


class AzureDocIntelligenceClient:
    def __init__(
        self,
        doc_intelligence_endpoint: str = "",
        doc_intelligence_key: str = "",
    ):

        self.doc_intelligence_endpoint: str = (
            doc_intelligence_endpoint
            if doc_intelligence_endpoint
            else os.getenv("AZURE_DOCINTELLIGENCE_ENDPOINT", "")
        )
        self.doc_intelligence_key: str = (
            doc_intelligence_key
            if doc_intelligence_key
            else os.getenv("AZURE_DOCINTELLIGENCE_KEY", "")
        )
        self.client = DocumentIntelligenceClient(
            endpoint=self.doc_intelligence_endpoint,
            credential=AzureKeyCredential(self.doc_intelligence_key),
        )

    def load_file(self, doc_id: int, filepath: str, filename: str) -> list[Page]:
        try:
            with open(filepath, "rb") as f:
                poller = self.client.begin_analyze_document(
                    model_id="prebuilt-layout",
                    analyze_request=BytesIO(f.read()),
                    content_type="application/octet-stream",
                )
                result = poller.result()

            docs = []
            for page_num, page in enumerate(result.pages, start=1):
                metadata = dict(
                    doc_id=doc_id,
                    filepath=filepath,
                    filename=filename,
                    page_num=page_num,
                )
                # page.lines가 None인 경우를 체크
                page_content = ""
                if page.lines:
                    page_content = "\n".join([line.content for line in page.lines])
                doc = Page(page_content=page_content, metadata=metadata)
                docs.append(doc)
            return docs

        except Exception as e:
            logger.error(f"Error in load_file for {filepath}: {str(e)}")
            return []


# TODO: page -> chunk
