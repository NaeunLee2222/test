from logging import Logger

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse

from core.errors.exceptions import ErrorCode, ServiceException
from core.log.logging import get_logging

logger = get_logging()


def set_error_handlers(app: FastAPI, logger: Logger) -> None:
    @app.exception_handler(ServiceException)
    async def predefined_exception_handler(
        request: Request, exc: ServiceException
    ) -> JSONResponse:
        logger.error(str(exc))
        return JSONResponse(
            status_code=exc.status_code,
            content={"code": exc.code.value, "src": exc.src, "detail": exc.detail},
        )

    @app.exception_handler(HTTPException)
    async def http_exception_handler(
        request: Request, exc: HTTPException
    ) -> JSONResponse:
        logger.error(str(exc))
        if exc.status_code < 200 or exc.status_code == 204 or exc.status_code == 304:
            return Response(status_code=exc.status_code)
        return JSONResponse(
            status_code=exc.status_code,
            content={"code": ErrorCode.UNEXPECTED_ERROR.value, "src": "task-agent"},
        )

    @app.exception_handler(Exception)
    async def base_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.error(str(exc))
        return JSONResponse(
            status_code=500,
            content={"code": ErrorCode.UNEXPECTED_ERROR.value, "src": "task-agent"},
        )
