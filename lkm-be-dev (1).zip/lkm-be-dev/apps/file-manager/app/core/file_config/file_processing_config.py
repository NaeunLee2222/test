from dataclasses import dataclass, field
from typing import List


@dataclass
class FileProcessingConfig:
    """파일 처리 관련 설정"""

    # 압축 설정
    enable_compression: bool = True
    compression_threshold: int = 1024 * 1024  # 1MB

    # 이미지 압축 설정
    image_compression_quality: int = 85
    image_max_width: int = 1920
    image_max_height: int = 1080

    # 지원 파일 확장자
    compressible_image_extensions: List[str] = field(
        default_factory=lambda: [".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp"]
    )
    compressible_document_extensions: List[str] = field(
        default_factory=lambda: [".txt", ".md", ".csv", ".json", ".xml", ".html"]
    )

    # 파일 크기 제한
    max_file_size: int = 100 * 1024 * 1024  # 100MB
    max_files_per_upload: int = 10

    # 스토리지 경로
    shared_data_path: str = ""

    def __post_init__(self):
        if self.compressible_image_extensions is None:
            self.compressible_image_extensions = [
                ".jpg",
                ".jpeg",
                ".png",
                ".bmp",
                ".tiff",
                ".webp",
            ]

        if self.compressible_document_extensions is None:
            self.compressible_document_extensions = [
                ".txt",
                ".md",
                ".csv",
                ".json",
                ".xml",
                ".html",
            ]

    @classmethod
    def from_settings(cls, settings) -> "FileProcessingConfig":
        """기존 settings 객체에서 설정 생성"""
        return cls(
            enable_compression=getattr(settings, "ENABLE_FILE_COMPRESSION", True),
            compression_threshold=getattr(
                settings, "COMPRESSION_THRESHOLD", 1024 * 1024
            ),
            image_compression_quality=getattr(
                settings, "IMAGE_COMPRESSION_QUALITY", 85
            ),
            image_max_width=getattr(settings, "IMAGE_MAX_WIDTH", 1920),
            image_max_height=getattr(settings, "IMAGE_MAX_HEIGHT", 1080),
            compressible_image_extensions=getattr(
                settings,
                "COMPRESSIBLE_IMAGE_EXTENSIONS",
                [".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp"],
            ),
            compressible_document_extensions=getattr(
                settings,
                "COMPRESSIBLE_DOCUMENT_EXTENSIONS",
                [".txt", ".md", ".csv", ".json", ".xml", ".html"],
            ),
            max_file_size=getattr(settings, "MAX_FILE_SIZE", 100 * 1024 * 1024),
            max_files_per_upload=getattr(settings, "MAX_FILES_PER_UPLOAD", 10),
            shared_data_path=getattr(settings, "SHARED_DATA_PATH", ""),
        )
