from typing import Optional

import jwt
from api.deps import get_redis
from core.config import get_setting
from core.log.logging import get_logging
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import Depends, HTTPException, Request, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from passlib.context import CryptContext
from redis import Redis
from services.schemas.auth import UserInfo

settings = get_setting()
logger = get_logging()

security = HTTPBearer(auto_error=False)
pwd_context = CryptContext(schemes=["bcrypt"])


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    return pwd_context.hash(password)


async def get_token_from_header(request: Request) -> str:
    credentials: HTTPAuthorizationCredentials = await security(request)
    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=401,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return credentials.credentials


async def verify_access_token(token: str, redis: Redis = Depends(get_redis)) -> dict:
    try:
        # 1. JWT 자체 검증
        payload = jwt.decode(
            token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM]
        )

        # 2. Redis에서 토큰 유효성 확인
        user_info_json = redis.get(f"token:{token}")
        if not user_info_json:
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.INVALID_AUTH,
                detail="Token not found in Redis or revoked",
            )

        return payload
    except jwt.ExpiredSignatureError:
        logger.error("Token has expired")
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.TOKEN_EXPIRED,
            detail=("Token has expired"),
        )
    except jwt.PyJWTError:
        logger.error("Invalid token")
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail=("Invalid token"),
        )


async def get_user_info_from_token(
    credentials: HTTPAuthorizationCredentials = Security(security),
    redis: Redis = Depends(get_redis),
) -> Optional[UserInfo]:
    """토큰에서 사용자 정보 가져오기"""

    if not credentials or not credentials.credentials:
        if settings.ENVIRONMENT == "LOCAL":
            logger.warning("No token provided, returning None")
            return None
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.NO_TOKEN,
            detail="Authentication required",
        )

    token = credentials.credentials

    # 토큰 검증
    await verify_access_token(token, redis)

    # Redis에서 사용자 정보 가져오기
    user_info_json = redis.get(f"token:{token}")
    if not user_info_json:
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail="User info not found",
        )

    # JSON 문자열을 UserInfo 객체로 변환
    try:
        user_info = UserInfo.model_validate_json(user_info_json)
        return user_info
    except Exception as e:
        logger.error(f"Failed to parse user info: {e}")
        raise ServiceException(
            status_code=500,
            error_code=ErrorCode.NOT_DEFINED,
            detail="Failed to parse user info",
        )


def create_access_token(user_info: UserInfo, iat: float) -> str:
    exp = iat + settings.TOKEN_EXPIRE_TIME
    payload = {
        "service": "ai-chat",
        "exp": exp,
        "iat": iat,
        "email": user_info.email,
        "username": user_info.username,
        "org_name": user_info.org_name,
        "team_name": user_info.team_name,
        "role": user_info.role,
    }
    token = jwt.encode(
        payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM
    )
    return token
