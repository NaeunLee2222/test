from functools import lru_cache

# from core.azure_blob import AzureBlobStorage
from core.config import get_setting
from core.utils.docintelligence import AzureDocIntelligenceClient
from core.utils.vector import VectorApproach
from langchain_openai import AzureOpenAIEmbeddings

settings = get_setting()


@lru_cache
def get_embedding_model() -> AzureOpenAIEmbeddings:
    return AzureOpenAIEmbeddings(
        azure_endpoint=settings.EMBEDDING_ENDPOINT,
        api_key=settings.EMBEDDING_KEY,
        azure_deployment=settings.EMBEDDING_DEPLOYMENT,
    )


# @lru_cache
# def get_blob_storage_client() -> AzureBlobStorage:
#     return AzureBlobStorage()


@lru_cache
def get_doc_intelligence_client() -> AzureDocIntelligenceClient:
    return AzureDocIntelligenceClient(
        doc_intelligence_endpoint=settings.AZURE_DOCINTELLIGENCE_ENDPOINT,
        doc_intelligence_key=settings.AZURE_DOCINTELLIGENCE_KEY,
    )


def get_vector_approach(search_index_name: str) -> VectorApproach:
    embedding_model = get_embedding_model()
    return VectorApproach(
        search_index=search_index_name,
        search_endpoint=settings.AZURE_AI_SEARCH_ENDPOINT,
        search_key=settings.AZURE_AI_SEARCH_KEY,
        embedding_approach=embedding_model,
    )
