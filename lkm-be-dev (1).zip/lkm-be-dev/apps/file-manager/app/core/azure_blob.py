from azure.storage.blob import BlobServiceClient
from core.config import get_setting

settings = get_setting()


class AzureBlobStorage:
    def __init__(self):
        self.connection_string = settings.AZURE_STORAGE_CONNECTION_STRING
        self.container_name = settings.AZURE_STORAGE_CONTAINER_NAME
        self.blob_service_client = BlobServiceClient.from_connection_string(
            self.connection_string
        )
        self.container_client = self.blob_service_client.get_container_client(
            self.container_name
        )

    def upload_blob(self, blob_name: str, data: bytes):
        blob_client = self.container_client.get_blob_client(blob_name)
        blob_client.upload_blob(data, overwrite=True)
        return blob_client.url

    def download_blob(self, blob_name: str) -> bytes:
        blob_client = self.container_client.get_blob_client(blob_name)
        return blob_client.download_blob().readall()

    def delete_blob(self, blob_name: str):
        blob_client = self.container_client.get_blob_client(blob_name)
        blob_client.delete_blob()

    def get_blob_uri(self, blob_name: str):
        blob_client = self.container_client.get_blob_client(blob_name)
        return blob_client.url
