import logging
import logging.config
import os

import yaml

from core.config import get_setting
from core.context import get_transaction_id

settings = get_setting()

log_dir = settings.DATA_PATH + settings.LOG_PATH
info_dir = os.path.join(log_dir, "info")
debug_dir = os.path.join(log_dir, "debug")
bing_dir = os.path.join(log_dir, "bing")

os.makedirs(info_dir, exist_ok=True)
os.makedirs(debug_dir, exist_ok=True)
os.makedirs(bing_dir, exist_ok=True)

# Load the config file
logging_file = os.path.join(os.path.dirname(__file__), "logging_config.yaml")
with open(logging_file, "rt") as f:
    config = yaml.safe_load(f.read())
    pod_name = os.getenv("POD_NAME", "default-pod")

    config["handlers"]["info_file"]["filename"] = os.path.join(
        info_dir, f"{pod_name}.log"
    )
    config["handlers"]["debug_file"]["filename"] = os.path.join(
        debug_dir, f"{pod_name}-debug.log"
    )
    config["handlers"]["bing_file"]["filename"] = os.path.join(
        bing_dir, f"{pod_name}-bing.log"
    )


class TransactionIDFilter(logging.Filter):
    """Custom filter to add transaction_id to log records"""

    def filter(self, record: logging.LogRecord) -> bool:
        record.transaction_id = get_transaction_id()
        return True


def get_logging() -> logging.Logger:
    # Configure the logging module with the config file
    logging.config.dictConfig(config)

    for handler in logging.root.handlers:
        if type(handler) is logging.StreamHandler:
            handler.setLevel(settings.LOG_LEVEL)
        handler.addFilter(TransactionIDFilter())

    external_loggers = [
        logging.getLogger("httpcore"),
        logging.getLogger("httpx"),
        logging.getLogger("azure"),
        logging.getLogger("openai"),
    ]
    if settings.ENVIRONMENT == "LOCAL":
        external_loggers.append(logging.getLogger("sqlalchemy.engine"))

    for logger in external_loggers:
        logger.setLevel("DEBUG")

    logger = logging.getLogger(settings.APP_NAME)
    logger.setLevel("DEBUG")

    return logger


def get_web_logging() -> logging.Logger:
    # Configure the logging module with the config file
    logging.config.dictConfig(config)

    for handler in logging.root.handlers:
        if isinstance(handler, logging.StreamHandler):
            handler.setLevel(settings.LOG_LEVEL)
        handler.addFilter(TransactionIDFilter())

    external_loggers = [
        logging.getLogger("httpcore"),
        logging.getLogger("httpx"),
        logging.getLogger("azure"),
        logging.getLogger("openai"),
    ]
    if settings.ENVIRONMENT != "PROD":
        external_loggers.append(logging.getLogger("sqlalchemy.engine"))

    for logger in external_loggers:
        logger.setLevel(logging.NOTSET)

    logger = logging.getLogger(settings.APP_NAME)
    logger.setLevel("CRITICAL")

    return logger
