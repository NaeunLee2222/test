from fastapi import Depends, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import json
import jwt
from core.config import get_setting
from core.log.logging import get_logging
from services.schemas.auth import UserInfo
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from redis import Redis, StrictRedis

settings = get_setting()
logger = get_logging()

security = HTTPBearer(auto_error=False)

def get_redis():
    r = StrictRedis(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT,
        password=settings.REDIS_ACCESS_KEY,
        ssl=settings.REDIS_USE_SSL,
        ssl_cert_reqs="none",
        decode_responses=True,
    )
    try:
        yield r
    finally:
        r.close()

async def validate_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
    redis_client: Redis = Depends(get_redis)
) -> UserInfo:
    try:

        # 로컬 환경에서는 토큰 검증을 하지 않음
        if not credentials or not credentials.credentials:
            if settings.ENVIRONMENT == "LOCAL":
                return None
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.NO_TOKEN,
                detail="인증에 실패했습니다. 다시 로그인해주세요."
            )

        token = credentials.credentials

        # Redis에서 사용자 정보 가져오기
        user_info_json = redis_client.get(f"token:{token}")
        if not user_info_json:
            raise ServiceException(
                status_code=401,
                error_code=ErrorCode.INVALID_AUTH,
                detail="인증에 실패했습니다. 다시 로그인해주세요."
            )

        # JWT 토큰 검증
        try:
            jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])
        except jwt.PyJWTError:
            # Redis에서 토큰 삭제
            redis_client.delete(f"token:{token}")
            raise ServiceException(
                status_code=401, 
                error_code=ErrorCode.INVALID_AUTH,
                detail="토큰이 유효하지 않습니다. 다시 로그인해주세요."
            )

        # 사용자 정보 반환
        user_info = json.loads(user_info_json)
        return UserInfo(**user_info)

    except Exception as e:
        logger.error(f"인증 처리 중 오류 발생: {str(e)}")
        raise ServiceException(
            status_code=401,
            error_code=ErrorCode.INVALID_AUTH,
            detail="인증에 실패했습니다. 다시 로그인해주세요."
        )