from typing import List

from core.config import get_setting
from database.session import get_async_db
from fastapi import APIRouter, Body, Depends, File, Form, Query, UploadFile
from services.schemas.user_file_drive import (
    AttachFilesToAgentRequest,
    AttachFilesToChatRequest,
    UserFileDriveWithFile,
)
from services.user_file_drive_service import UserFileDriveService
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()
settings = get_setting()
ALLOWED_EXTENSIONS = {
    ".pdf",
    ".docx",
    ".doc",
    ".txt",
    ".jpg",
    ".jpeg",
    ".png",
}


@router.post("/files/upload")
async def upload_files(
    files: List[UploadFile] = File(...),
    db: AsyncSession = Depends(get_async_db),
    user_id: int = Form(..., description="User ID"),
):
    user_file_drive_service = UserFileDriveService()
    return await user_file_drive_service.upload_files(
        db=db, user_id=user_id, files=files
    )


@router.get("/files")
async def get_files(
    db: AsyncSession = Depends(get_async_db),
    user_id: int = Query(..., description=""),
    skip: int = Query(0, description="Skip files"),
    limit: int = Query(10, description="Limit files"),
):
    user_file_drive_service = UserFileDriveService()
    return await user_file_drive_service.get_files_by_user_id(
        db=db, user_id=user_id, skip=skip, limit=limit
    )


@router.get("/files/{user_file_id}", response_model=UserFileDriveWithFile)
async def get_file(
    user_file_id: int,
    db: AsyncSession = Depends(get_async_db),
    user_id: int = Query(..., description=""),
):
    user_file_drive_service = UserFileDriveService()
    return await user_file_drive_service.get_file_by_user_id_and_user_file_id_with_file(
        db=db, user_id=user_id, user_file_id=user_file_id
    )


@router.delete("/files/{user_file_id}", status_code=204)
async def delete_file(
    user_file_id: int,
    db: AsyncSession = Depends(get_async_db),
    user_id: int = Query(..., description=""),
):
    user_file_drive_service = UserFileDriveService()
    await user_file_drive_service.delete_file(db=db, file_id=user_file_id)
    return


@router.post("/files/chat/{chat_id}/attach-files")
async def attach_files_to_chat(
    chat_id: str,
    request: AttachFilesToChatRequest = Body(...),
    db: AsyncSession = Depends(get_async_db),
):
    """
    UserFileDrive에 있는 여러 파일을 채팅에 첨부합니다.
    - 각 파일이 사용자 소유인지 확인
    - ChatDocuments 테이블에 메타데이터 생성
    """
    user_file_drive_service = UserFileDriveService()
    return await user_file_drive_service.attach_files_to_chat(
        db=db, chat_id=chat_id, user_file_ids=request.user_file_ids
    )


@router.post("/files/agent/{agent_id}/attach-files")
async def attach_files_to_agent(
    agent_id: int,
    request: AttachFilesToAgentRequest = Body(...),
    db: AsyncSession = Depends(get_async_db),
):
    """
    UserFileDrive에 있는 여러 파일을 에이전트에 첨부합니다.
    - 각 파일이 사용자 소유인지 확인
    - AgentDocuments 테이블에 메타데이터 생성
    """
    user_file_drive_service = UserFileDriveService()
    return await user_file_drive_service.attach_files_to_agent(
        db=db,
        agent_id=agent_id,
        user_file_ids=request.user_file_ids,
        document_type=request.document_type,
    )


# # 단일 파일 첨부 API는 하위 호환성을 위해 유지
# @router.post("/files/chat/{chat_id}/attach-file")
# async def attach_file_to_chat(
#     chat_id: str,
#     file_id: int,
#     db: AsyncSession = Depends(get_async_db),
#     user_id: int = Query(..., description="사용자 ID"),
# ):
#     """
#     UserFileDrive에 있는 파일을 채팅에 첨부합니다.
#     - 파일이 사용자 소유인지 확인
#     - ChatDocuments 테이블에 메타데이터 생성
#     """
#     user_file_drive_service = UserFileDriveService()
#     return await user_file_drive_service.attach_file_to_chat(
#         db=db, chat_id=chat_id, file_id=file_id, user_id=user_id
#     )


# @router.post("/files/agent/{agent_id}/attach-file")
# async def attach_file_to_agent(
#     agent_id: int,
#     file_id: int,
#     db: AsyncSession = Depends(get_async_db),
#     user_id: int = Query(..., description="사용자 ID"),
#     document_type: str = Query(
#         "KNOWLEDGE", description="문서 유형 (KNOWLEDGE 또는 PROCEDURE)"
#     ),
# ):
#     """
#     UserFileDrive에 있는 파일을 에이전트에 첨부합니다.
#     - 파일이 사용자 소유인지 확인
#     - AgentDocuments 테이블에 메타데이터 생성
#     """
#     user_file_drive_service = UserFileDriveService()
#     return await user_file_drive_service.attach_file_to_agent(
#         db=db,
#         agent_id=agent_id,
#         file_id=file_id,
#         user_id=user_id,
#         document_type=document_type,
#     )
