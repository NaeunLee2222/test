import os
from typing import List

from core.utils.files import normalize_unicode_files
from database.session import get_async_db
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import APIRouter, Depends, Form, Path, Query, UploadFile
from services.agent_document_service import AgentDocumentService
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()

# 파일 확장자 검증 (공통)
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt", ".jpg", ".jpeg", ".png"}

agent_document_service = AgentDocumentService()


def validate_files(files: List[UploadFile]) -> None:
    """파일 검증 공통 함수"""
    for file in files:
        if not file.filename:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.UNSUPPORTED_FILE_TYPE,
                detail="파일명이 없는 파일은 업로드할 수 없습니다.",
            )
        _, file_extension = os.path.splitext(file.filename)
        if file_extension.lower() not in ALLOWED_EXTENSIONS:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.UNSUPPORTED_FILE_TYPE,
                detail=f"허용되지 않는 파일 형식입니다: {file_extension}. 허용되는 형식은 {list(ALLOWED_EXTENSIONS)} 입니다.",
            )


@router.post("/")
async def upload_agent_documents(
    document_type: str = Form(
        ..., description="문서 유형: PROCEDURE(업무절차서) or KNOWLEDGE(지식)"
    ),
    files: List[UploadFile] = Depends(normalize_unicode_files),
    db: AsyncSession = Depends(get_async_db),
):
    """
    에이전트용 문서를 업로드하는 API
    - 파일 업로드 및 임베딩 처리
    - 허용 확장자: pdf, docx, doc, txt, jpg, jpeg, png
    """
    validate_files(files)

    result = await agent_document_service.execute(db, files, document_type)
    return result


@router.get("/{agent_id}")
async def get_agent_documents(
    agent_id: int = Path(..., description="에이전트 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 에이전트의 문서 목록을 조회하는 API
    """
    result = await agent_document_service.get_documents_by_expert_id(
        db, agent_id=agent_id
    )
    return result


@router.get("/{agent_id}/search")
async def search_agent_documents(
    agent_id: int = Path(..., description="에이전트 ID"),
    query: str = Query(..., description="검색 쿼리"),
    n: int = Query(5, description="검색 결과 개수"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 에이전트의 모든 문서에서 벡터 검색하는 API
    """
    result = await agent_document_service.search_vector(
        db, agent_id=agent_id, query=query, n=n
    )
    return result


@router.get("/{agent_id}/summary")
async def get_agent_summary(
    agent_id: int = Path(..., description="에이전트 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 에이전트의 문서 요약을 조회하는 API
    """
    result = await agent_document_service.get_document_summary(
        db, expert_agent_id=agent_id
    )
    return result


@router.get("/document/{agent_doc_id}/search")
async def search_single_document(
    agent_doc_id: int = Path(..., description="문서 ID"),
    query: str = Query(..., description="검색 쿼리"),
    n: int = Query(5, description="검색 결과 개수"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 문서에서만 벡터 검색하는 API
    """
    result = await agent_document_service.search_vector_by_doc_id(
        db, agent_doc_id=agent_doc_id, query=query, n=n
    )
    return result


@router.get("/document/{agent_doc_id}/state")
async def get_document_state(
    agent_doc_id: int = Path(..., description="문서 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 문서의 처리 상태를 조회하는 API
    - 상태: UPLOAD, WAIT, READY, FAILURE, DELETED
    """
    result = await agent_document_service.get_document_state(db, doc_id=agent_doc_id)
    return result


@router.get("/document/{agent_doc_id}/original")
async def get_original_file(
    agent_doc_id: int = Path(..., description="문서 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 문서의 원본 파일을 다운로드하는 API
    """
    return await agent_document_service.get_document_original(db, agent_doc_id)


@router.put("/document/{agent_doc_id}/agent")
async def update_agent_id(
    agent_doc_id: int = Path(..., description="문서 ID"),
    agent_id: int = Form(..., description="새 에이전트 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    문서의 에이전트 ID를 업데이트하는 API
    """
    result = await agent_document_service.update_agent_id(
        db, agent_doc_id=agent_doc_id, agent_id=agent_id
    )
    return result
