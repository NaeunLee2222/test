import time

from core.config import get_setting
from fastapi import APIRouter

settings = get_setting()
health_router = APIRouter(tags=["Health"])


@health_router.get("/health", summary="Health Check")
async def health_check() -> dict:
    return {
        "status": "healthy",
        "timestamp": time.time(),
    }
