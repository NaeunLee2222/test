import os
from typing import List

from core.config import get_setting
from core.utils.files import normalize_unicode_files
from database.session import get_async_db
from error.error_code import ErrorCode
from error.service_exception import ServiceException
from fastapi import APIRouter, Depends, Form, Path, Query, UploadFile
from services.chat_document_service import ChatDocumentService
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()
settings = get_setting()

# 파일 확장자 검증 (공통)
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt", ".jpg", ".jpeg", ".png", ".csv"}

chat_document_service = ChatDocumentService()


def validate_files(files: List[UploadFile]) -> None:
    """파일 검증 공통 함수"""
    for file in files:
        if not file.filename:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.UNSUPPORTED_FILE_TYPE,
                detail="파일명이 없는 파일은 업로드할 수 없습니다.",
            )
        _, file_extension = os.path.splitext(file.filename)
        if file_extension.lower() not in ALLOWED_EXTENSIONS:
            raise ServiceException(
                status_code=400,
                error_code=ErrorCode.UNSUPPORTED_FILE_TYPE,
                detail=f"허용되지 않는 파일 형식입니다: {file_extension}. 허용되는 형식은 {list(ALLOWED_EXTENSIONS)} 입니다.",
            )


@router.post("/")
async def upload_chat_documents(
    user_id: int = Form(..., description="사용자 ID"),
    files: List[UploadFile] = Depends(normalize_unicode_files),
    db: AsyncSession = Depends(get_async_db),
):
    """
    채팅용 문서를 업로드하는 API
    - 파일 업로드 및 임베딩 처리
    - 허용 확장자: pdf, docx, doc, txt, jpg, jpeg, png, csv
    """
    validate_files(files)

    result = await chat_document_service.execute(db, files, user_id)
    return result


@router.get("/{chat_id}")
async def get_chat_documents(
    chat_id: str = Path(..., description="채팅 ID"),
    db: AsyncSession = Depends(get_async_db),
    # user_info: UserInfo = Depends(get_user_info_from_token),
):
    """
    특정 채팅의 문서 목록을 조회하는 API
    """
    result = await chat_document_service.get_documents_by_chat_id(db, chat_id=chat_id)
    return result


@router.get("/{chat_id}/search")
async def search_chat_documents(
    chat_id: str = Path(..., description="채팅 ID"),
    query: str = Query(..., description="검색 쿼리"),
    n: int = Query(5, description="검색 결과 개수"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 채팅의 모든 문서에서 벡터 검색하는 API
    """
    result = await chat_document_service.search_vector(
        db, chat_id=chat_id, query=query, n=n
    )
    return result


@router.get("/{chat_id}/summary")
async def get_chat_summary(
    chat_id: str = Path(..., description="채팅 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 채팅의 문서 요약을 조회하는 API
    """
    result = await chat_document_service.get_document_summary(db, chat_id=chat_id)
    return result


@router.get("/document/{chat_doc_id}/search")
async def search_single_document(
    chat_doc_id: int = Path(..., description="문서 ID"),
    query: str = Query(..., description="검색 쿼리"),
    n: int = Query(5, description="검색 결과 개수"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 문서에서만 벡터 검색하는 API
    """
    result = await chat_document_service.search_vector_by_doc_id(
        db, chat_doc_id=chat_doc_id, query=query, n=n
    )
    return result


@router.get("/document/{chat_doc_id}/state")
async def get_document_state(
    chat_doc_id: int = Path(..., description="문서 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 문서의 처리 상태를 조회하는 API
    - 상태: UPLOAD, WAIT, READY, FAILURE, DELETED
    """
    result = await chat_document_service.get_document_state(db, doc_id=chat_doc_id)
    return result


@router.get("/document/{chat_doc_id}/original")
async def get_original_file(
    chat_doc_id: int = Path(..., description="문서 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    특정 문서의 원본 파일을 다운로드하는 API
    """
    return await chat_document_service.get_document_original(db, chat_doc_id)


@router.put("/document/{chat_doc_id}/chat")
async def update_chat_id(
    chat_doc_id: int = Path(..., description="문서 ID"),
    chat_id: str = Form(..., description="새 채팅 ID"),
    db: AsyncSession = Depends(get_async_db),
):
    """
    문서의 채팅 ID를 업데이트하는 API
    """
    result = await chat_document_service.update_chat_id(
        db, chat_doc_id=chat_doc_id, chat_id=chat_id
    )
    return result
