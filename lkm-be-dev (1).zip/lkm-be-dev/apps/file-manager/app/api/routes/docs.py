from typing import Any, Dict

from core.config import get_setting
from fastapi import APIRouter, Request
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from fastapi.responses import HTMLResponse

settings = get_setting()
docs_router = APIRouter()


@docs_router.get("/docs", tags=["documentation"], include_in_schema=False)
async def custom_swagger_ui_html(request: Request) -> HTMLResponse:

    return get_swagger_ui_html(
        openapi_url=f"{settings.URI_PREFIX}/openapi.json",
        title=f"{settings.APP_NAME} - Swagger UI",
        swagger_js_url=f"{settings.URI_PREFIX}/static/swagger-ui-bundle.js",
        swagger_css_url=f"{settings.URI_PREFIX}/static/swagger-ui.css",
    )


@docs_router.get("/openapi.json", tags=["documentation"], include_in_schema=False)
async def get_openapi_json(request: Request) -> Dict[str, Any]:

    app = request.app
    return get_openapi(
        title=settings.APP_NAME,
        version="1.0.0",
        routes=app.routes,
        description="File Manager API Documentation",
        servers=[{"url": ""}],
    )
