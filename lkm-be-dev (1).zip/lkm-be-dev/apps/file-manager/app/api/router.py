from fastapi import APIRouter

from api.routes import agent_documents, chat_documents, user_file_drive

file_manager = APIRouter()

file_manager.include_router(
    chat_documents.router, prefix="/chat_documents", tags=["chat_documents"]
)
file_manager.include_router(
    agent_documents.router, prefix="/agent_documents", tags=["agent_documents"]
)
file_manager.include_router(
    user_file_drive.router, prefix="/user_file_drive", tags=["user_file_drive"]
)
