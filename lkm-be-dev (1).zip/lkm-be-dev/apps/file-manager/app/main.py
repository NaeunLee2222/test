# from routers import upload
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator

from api.router import file_manager
from api.routes.docs import docs_router
from api.routes.health import health_router
from core.config import get_setting
from core.log.logging import get_logging
from core.middleware import LoggingMiddleware, UserInfoMiddleware
from database.init_database import close_database_connections, initialize_database
from error.error_handler import set_error_handlers
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.routing import APIRoute
from fastapi.staticfiles import StaticFiles
from filelock import FileLock

settings = get_setting()
logger = get_logging()


# API 경로의 고유 ID 생성을 위한 함수
def custom_generate_unique_id(route: APIRoute) -> str:
    return f"{route.tags[0]}-{route.name}"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    try:
        # db lock 파일 경로 설정
        lock_file = settings.DATA_PATH + "/tmp/file-manager.lock"
        lock = FileLock(lock_file, timeout=0)

        try:
            with lock:
                logger.info(f"Environment: {settings.ENVIRONMENT}")
                logger.info(f"Worker Count: {settings.FILE_MANAGER_WORKER_NUM}")
                logger.info("Initializing application...")

                # Create necessary directories
                Path(settings.SHARED_DATA_PATH).mkdir(parents=True, exist_ok=True)

                await initialize_database()

                logger.info("Database initialization completed")
                logger.info(f"{settings.APP_NAME} service is ready and now running!")
        except TimeoutError:
            logger.info(
                "Lock already held by another process, skipping initialization..."
            )

        yield
    finally:
        logger.info("Shutting down database connections.")
        await close_database_connections()


app = FastAPI(
    title="File Manager Service",
    openapi_url=f"{settings.URI_PREFIX}/openapi.json",  # 기본 openapi.json 활성화
    docs_url=None,  # 기본 docs 비활성화 (커스텀 docs 사용)
    lifespan=lifespan,  # lifespan을 통해 테이블 생성 및 초기화 처리
    generate_unique_id_function=custom_generate_unique_id,
)

# CORS 미들웨어 추가 (프론트엔드 호스트 허용)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        # "http://localhost:3000",
        # "http://localhost:5173",
        "*",  # AGS 임시 CORS 해결
    ],  # 프론트엔드 origin
    allow_credentials=True,
    allow_methods=["*"],  # 모든 HTTP 메서드 허용
    allow_headers=["*"],  # 모든 헤더 허용
)

app.mount(
    f"{settings.URI_PREFIX}/static",
    StaticFiles(directory=Path(__file__).resolve().parent / "static"),
    name="static",
)

app.add_middleware(UserInfoMiddleware)
app.add_middleware(LoggingMiddleware)


app.include_router(health_router, prefix=settings.URI_PREFIX)
app.include_router(docs_router, prefix=settings.URI_PREFIX)  # 커스텀 docs 활성화

app.include_router(file_manager, prefix=settings.URI_PREFIX)

set_error_handlers(app, logger)  # 에러 핸들러 설정

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=int(settings.FILE_MANAGER_APP_PORT),
        access_log=False,
    )
