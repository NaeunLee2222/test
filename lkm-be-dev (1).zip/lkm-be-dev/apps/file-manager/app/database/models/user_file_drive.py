from database.base import Base
from sqlalchemy import Column, DateTime, Integer
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


class UserFileDrive(Base):
    __tablename__ = "user_file_drive"

    id = Column(Integer, primary_key=True, autoincrement=True)
    file_id = Column(Integer, nullable=False)  # Files 테이블 참조 (FK 제약조건 없음)
    user_id = Column(Integer, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Files와의 관계 (단방향 참조)
    file = relationship(
        "Files", foreign_keys=[file_id], primaryjoin="UserFileDrive.file_id==Files.id"
    )
