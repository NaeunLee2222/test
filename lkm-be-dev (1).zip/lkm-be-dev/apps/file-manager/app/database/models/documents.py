from database.base import Base
from sqlalchemy import Column, DateTime, Enum, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


class ChatDocuments(Base):
    __tablename__ = "chat_documents"

    chat_docs_id = Column(Integer, primary_key=True, autoincrement=True)
    file_id = Column(Integer, nullable=False)  # Files 테이블 참조 (FK 제약조건 없음)
    user_id = Column(Integer, nullable=True)
    chat_id = Column(String(36), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Files와의 관계 (단방향 참조)
    file = relationship(
        "Files", foreign_keys=[file_id], primaryjoin="ChatDocuments.file_id==Files.id"
    )


class AgentDocuments(Base):
    __tablename__ = "agent_documents"

    agent_docs_id = Column(Integer, primary_key=True, autoincrement=True)
    file_id = Column(Integer, nullable=False)  # Files 테이블 참조 (FK 제약조건 없음)
    agent_id = Column(Integer, nullable=True)
    document_type = Column(
        Enum("KNOWLEDGE", "PROCEDURE", name="document_type"), nullable=False
    )

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Files와의 관계 (단방향 참조)
    file = relationship(
        "Files", foreign_keys=[file_id], primaryjoin="AgentDocuments.file_id==Files.id"
    )
