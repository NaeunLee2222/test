from database.base import Base
from sqlalchemy import Column, DateTime, Integer, String, Text
from sqlalchemy.sql import func


class Files(Base):
    __tablename__ = "files"

    id = Column(Integer, primary_key=True, autoincrement=True)
    original_filename = Column(String(255), nullable=False)
    uuid_filename = Column(String(64), nullable=False, unique=True)
    file_type = Column(String(255), nullable=True)
    file_path = Column(Text, nullable=True)
    file_size = Column(Integer, nullable=False)
    state = Column(String(50), nullable=False, default="WAIT")  # WAIT, READY, DELETED
    index_name = Column(Text, nullable=True)  # Elasticsearch/OpenSearch 인덱스명
    summary = Column(Text, nullable=True)  # 파일 요약 정보
    original_content = Column(Text, nullable=True)  # 파일 원본 텍스트 내용

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
