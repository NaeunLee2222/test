from typing import List, Optional

from database.crud.base import CRUDBaseAsync
from database.models.files import Files
from database.models.user_file_drive import UserFileDrive
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload


class CRUDUserFileDriveAsync(CRUDBaseAsync):
    def __init__(self):
        super().__init__(UserFileDrive)

    async def get_multi_by_owner(
        self, db: AsyncSession, *, user_id: int, skip: int = 0, limit: int = 100
    ) -> List[UserFileDrive]:
        result = await db.execute(
            select(self.model)
            .filter(self.model.user_id == user_id)
            .order_by(self.model.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_multi_by_owner_with_file(
        self, db: AsyncSession, *, user_id: int, skip: int = 0, limit: int = 100
    ) -> List[UserFileDrive]:
        """파일 정보와 함께 사용자의 UserFileDrive 목록 조회"""
        result = await db.execute(
            select(self.model)
            .options(selectinload(self.model.file))
            .filter(self.model.user_id == user_id)
            .order_by(self.model.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_files_by_owner_optimized(
        self, db: AsyncSession, *, user_id: int, skip: int = 0, limit: int = 100
    ) -> List[dict]:
        """효율적인 조인으로 필요한 필드만 선택해서 조회"""
        result = await db.execute(
            select(
                # UserFileDrive 필드들
                self.model.id.label("id"),
                self.model.file_id.label("file_id"),
                self.model.user_id.label("user_id"),
                self.model.created_at.label("created_at"),
                self.model.updated_at.label("updated_at"),
                # Files 필드들 (필요한 것만)
                Files.original_filename.label("original_filename"),
                Files.file_type.label("file_type"),
                Files.file_size.label("file_size"),
                Files.state.label("state"),
            )
            .join(Files, self.model.file_id == Files.id)
            .filter(self.model.user_id == user_id)
            .order_by(self.model.created_at.desc())
            .offset(skip)
            .limit(limit)
        )

        # 결과를 dict 형태로 변환
        files = []
        for row in result:
            files.append(
                {
                    "user_file_id": row.id,
                    "file_id": row.file_id,
                    "user_id": row.user_id,
                    "created_at": row.created_at,
                    "updated_at": row.updated_at,
                    "original_filename": row.original_filename,
                    "file_type": row.file_type,
                    "file_size": row.file_size,
                    "state": row.state,
                }
            )

        return files

    async def get_by_id_with_file(
        self, db: AsyncSession, *, id: int
    ) -> Optional[UserFileDrive]:
        """파일 정보와 함께 UserFileDrive 조회"""
        result = await db.execute(
            select(self.model)
            .options(selectinload(self.model.file))
            .filter(self.model.id == id)
        )
        return result.scalars().first()

    async def get_by_id_and_user_id_with_file(
        self, db: AsyncSession, *, id: int, user_id: int
    ) -> Optional[UserFileDrive]:
        """파일 정보와 함께 UserFileDrive 조회"""
        result = await db.execute(
            select(self.model)
            .options(selectinload(self.model.file))
            .filter(self.model.id == id, self.model.user_id == user_id)
        )
        return result.scalars().first()

    async def get_multi_by_ids(
        self, db: AsyncSession, *, file_ids: List[int]
    ) -> List[UserFileDrive]:
        """여러 파일 ID와 사용자 ID로 UserFileDrive 목록을 파일 정보와 함께 조회"""
        result = await db.execute(
            select(self.model)
            .options(selectinload(self.model.file))
            .filter(self.model.id.in_(file_ids))
        )
        return list(result.scalars().all())

    async def count_by_owner(self, db: AsyncSession, *, user_id: int) -> int:
        result = await db.execute(
            select(func.count(self.model.id)).where(self.model.user_id == user_id)
        )
        return result.scalar_one()


crud_user_file_drive = CRUDUserFileDriveAsync()
