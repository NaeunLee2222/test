from typing import List

from database.crud.base import CRUDBaseAsync
from database.models.files import Files
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


class CRUDFilesAsync(CRUDBaseAsync):
    def __init__(self):
        super().__init__(Files)

    async def get_by_uuid_filename(self, db: AsyncSession, *, uuid_filename: str):
        """UUID 파일명으로 파일 조회"""
        result = await db.execute(
            select(Files).filter(Files.uuid_filename == uuid_filename)
        )
        return result.scalars().first()

    async def get_by_state(self, db: AsyncSession, *, state: str):
        """상태별 파일 조회"""
        result = await db.execute(select(Files).filter(Files.state == state))
        return list(result.scalars().all())

    async def get_multi_by_ids(self, db: AsyncSession, file_ids: List[int]):
        """파일 ID 목록으로 여러 파일 조회"""
        result = await db.execute(select(Files).filter(Files.id.in_(file_ids)))
        return list(result.scalars().all())

    async def update_state(self, db: AsyncSession, *, file_id: int, state: str):
        """파일 상태 업데이트"""
        db_file = await self.get(db, id=file_id)
        if db_file:
            return await self.update(db, db_obj=db_file, obj_in={"state": state})
        return None


crud_files = CRUDFilesAsync()
