from database.crud.base import CRUDBase, CRUDBaseAsync
from database.models.documents import ChatDocuments
from database.models.files import Files
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session, joinedload


class CRUDChatDocumentsAsync(CRUDBaseAsync):
    def __init__(self):
        super().__init__(ChatDocuments)

    async def get_by_chat_id(self, db: AsyncSession, *, chat_id: str):
        """채팅 ID로 문서 조회 (파일 정보 포함)"""
        result = await db.execute(
            select(ChatDocuments)
            .options(joinedload(ChatDocuments.file))
            .filter(ChatDocuments.chat_id == chat_id)
        )
        return list(result.scalars().all())

    async def get_document_states_by_chat_id(self, db: AsyncSession, *, chat_id: str):
        """특정 chat_id의 문서들의 상태만 효율적으로 조회하는 메서드"""
        result = await db.execute(
            select(ChatDocuments.chat_docs_id, Files.state)
            .join(Files, ChatDocuments.file_id == Files.id)
            .filter(ChatDocuments.chat_id == chat_id)
        )
        doc_states = result.all()
        return [{"id": doc_id, "state": state} for doc_id, state in doc_states]

    async def get_with_file(self, db: AsyncSession, *, doc_id: int):
        """문서 ID로 파일 정보와 함께 조회"""
        result = await db.execute(
            select(ChatDocuments)
            .options(joinedload(ChatDocuments.file))
            .filter(ChatDocuments.chat_docs_id == doc_id)
        )
        return result.scalars().first()

    async def create_with_file(
        self, db: AsyncSession, *, chat_doc_data: dict, file_data: dict
    ):
        """파일과 함께 채팅 문서 생성"""
        # 먼저 파일 생성
        from database.crud.files import CRUDFilesAsync

        crud_files = CRUDFilesAsync()
        db_file = await crud_files.create(db, obj_in=file_data)

        # 채팅 문서 생성
        chat_doc_data["file_id"] = db_file.id
        db_chat_doc = await self.create(db, obj_in=chat_doc_data)

        # 파일 정보와 함께 반환
        await db.refresh(db_chat_doc)
        return await self.get_with_file(db, doc_id=db_chat_doc.chat_docs_id)

    async def get_by_chat_doc_id_with_file(self, db: AsyncSession, *, chat_doc_id: int):
        """채팅 문서 ID로 파일 정보와 함께 조회"""
        result = await db.execute(
            select(ChatDocuments)
            .options(joinedload(ChatDocuments.file))
            .filter(ChatDocuments.chat_docs_id == chat_doc_id)
        )
        return result.scalars().first()

    async def get_by_chat_doc_id(self, db: AsyncSession, *, chat_doc_id: int):
        """채팅 문서 ID로 조회 (파일 정보 없음)"""
        result = await db.execute(
            select(ChatDocuments).filter(ChatDocuments.chat_docs_id == chat_doc_id)
        )
        return result.scalars().first()


class CRUDChatDocuments(CRUDBase):
    def __init__(self):
        super().__init__(ChatDocuments)

    def get_by_chat_id(self, db: Session, *, chat_id: str):
        return db.query(ChatDocuments).filter(ChatDocuments.chat_id == chat_id).all()
