#!/bin/bash

# apps 경로로 이동
cd apps || exit

# 앱 리스트
apps=("ai-chat" "task-agent" "file-manager")

for app in "${apps[@]}"; do
  echo "Setting up virtual environment for $app..."
  cd "$app" || { echo "Failed to enter $app"; exit 1; }

  # venv 생성 (이미 있으면 건너뜀)
  if [ ! -d "venv" ]; then
    python3.10 -m venv venv
    echo "Created virtual environment in $app/venv"
  else
    echo "Virtual environment already exists in $app/venv"
  fi

  # requirements.txt 경로 설정
  req_path="app/requirements.txt"
  
  # requirements.txt 설치
  source venv/bin/activate
  if [ -f "$req_path" ]; then
    pip install --upgrade pip
    pip install -r "$req_path"
    echo "Installed requirements for $app from $req_path"
  else
    echo "No requirements.txt found at $req_path"
  fi
  deactivate

  # 상위 디렉토리로 이동
  cd ..
done

echo "✅ All done!"
